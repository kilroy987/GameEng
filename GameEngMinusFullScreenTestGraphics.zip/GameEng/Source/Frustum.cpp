#include "..\Headers\Frustum.h"

using namespace GameEng::Math;
using namespace GameEng::Storage;

LinkedList<FrustumPlane> LinkedList<FrustumPlane>::DeletedList("FrustumPlane");

// prepare for additions - empty the list
void Frustum::Initialize()
{
	planes.Clear();
#ifdef _DEBUG
	addedPlanes.Initialize();
#endif
	nullSet = true;
	empty = false;
	count = 0;
}

Frustum::Frustum()
{
	Initialize();
}

// intersection has nullified set
void Frustum::Empty()
{
	planes.Clear();
	nullSet = false;
	empty = true;
	count = 0;
}

bool Frustum::IsEmpty()
{
	return empty;
}

void Frustum::SetOrigin(Vector3d &p_origin)
{
	origin = p_origin;
}

bool Frustum::VectorsApproximatelyEqual(Vector3d &p_vector1, Vector3d &p_vector2)
{
	//double equalValue = 0.9999998;
	//double result = double(p_vector1.x) * double(p_vector2.x) + double(p_vector1.y) * double(p_vector2.y) + double(p_vector1.z) * double(p_vector2.z);
	//bool equal = (result >= equalValue);

	bool equal = false;

	if (p_vector1.Equals(p_vector2) == true)
		equal = true;
	else
	{
		// this is a better method - allows them to be closer to equal and prevents thin line artifacting at distant portal edges
		float biggestDifference = abs(p_vector1.x - p_vector2.x);
		float difference = abs(p_vector1.y - p_vector2.y);
		if (difference > biggestDifference)
			biggestDifference = difference;
		difference = abs(p_vector1.z - p_vector2.z);
		if (difference > biggestDifference)
			biggestDifference = difference;
		if (biggestDifference < 0.000001f)
			equal = true;
	}

#ifdef _DEBUG
	if (equal == false)
	{
		if (p_vector1.Equals(p_vector2) == true)
			throw gcnew System::Exception("But... they are equal!!!!");
	}
#endif
	return equal;
}

bool Frustum::VectorsApproximatelyOpposite(Vector3d &p_vector1, Vector3d &p_vector2)
{
	//double oppositeValue = -0.9999998;
	//double result = double(p_vector1.x) * double(p_vector2.x) + double(p_vector1.y) * double(p_vector2.y) + double(p_vector1.z) * double(p_vector2.z);
	//bool opposite = (result <= oppositeValue);

	bool opposite = false;

	if (p_vector1.Equals(p_vector2.ScalarMult(-1.0f)) == true)
		opposite = true;
	else
	{
		// this is a better method - allows them to be closer to equal and prevents thin line artifacting at distant portal edges
		float biggestDifference = abs(p_vector1.x + p_vector2.x);
		float difference = abs(p_vector1.y + p_vector2.y);
		if (difference > biggestDifference)
			biggestDifference = difference;
		difference = abs(p_vector1.z + p_vector2.z);
		if (difference > biggestDifference)
			biggestDifference = difference;
		if (biggestDifference < 0.000001f)
			opposite = true;
	}

#ifdef _DEBUG
	if (opposite == false)
	{
		if (p_vector1.Equals(p_vector2.ScalarMult(-1.0f)) == true)
			throw gcnew System::Exception("But... they are opposite!!!!");
	}
#endif
	return opposite;
}

bool Frustum::PlaneWillEmptyFrustum(Vector3d &p_normal, bool p_IsUnit)
{
	// don't call - there is a bug that breaks frustum assumptions

	// will adding this plane empty the list?
	if (empty == true)
		return true;

	if (count == 0)
		return false;

	Vector3d normalUnitToAdd = p_normal;
	if (p_IsUnit == false)
	{
		if (normalUnitToAdd.Normalize() == false)
		{
			return true;
		}
	}

	if (count == 1)
	{
		Vector3d normalUnit = planes.GetFirstNode()->data.normalUnit;
		if (VectorsApproximatelyOpposite(normalUnit, normalUnitToAdd) == true) // negative equals
		{
			return true;
		}
	}
	else // count >= 2
	{
		// loop through planes and find first occurrence of a plane not equal and opposite and at least one of its segments are inside
		// if this is true, frustum will not be emptied
		LinkedListEnumerator<FrustumPlane> planeTestEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
		bool anyPlanesWithSegmentsInside = false;
		while (planeTestEnumerator.MoveNext())
		{
			if (VectorsApproximatelyOpposite(planeTestEnumerator.Current()->data.normalUnit, normalUnitToAdd) == true) // negatives of each other - empty the set, it's impossible to keep
			{
				return true;
			}
			if (anyPlanesWithSegmentsInside == false)
			{
				if (planeTestEnumerator.Current()->data.intersectSegmentLeft * normalUnitToAdd >= 0.0f)
					anyPlanesWithSegmentsInside = true;
				if (anyPlanesWithSegmentsInside == false)
				{
					if (planeTestEnumerator.Current()->data.intersectSegmentRight * normalUnitToAdd >= 0.0f)
						anyPlanesWithSegmentsInside = true;
				}
			}
		}
		if (anyPlanesWithSegmentsInside == false)
			return true;
	}

	return false;
}

// add a plane and get rid of all other planes that this one culls out
// if a plane culls out all other planes, empty list and don't add plane
// if a plane isn't in front of any intersection segments, don't add it - it's outside everything
// if list is null, just add the plane
// if only one plane is in list, don't add new plane if it is entirely behind or equal with the other plane
// find the two planes whose left and right segments are behind this plane.  cut out all planes between them, put this plane between them, and replace the left and right segments
// determine case for planes missing a left or right intersection
// 1st addition: 1 plane with no intersections
// 2nd addition: 2 planes with one intersection between them, left or right
// 3rd+ addition: 3 planes with intersections between each
// for portal culling, watch out for case where a portal plane intersects with the origin.  if no part of the portal is in front, empty list.  When this happens make sure to process each side of the portal only once (avoid infinite loop in rendering parse).
// Important note: Planes are kept adjacent to make adding easier (collecting planes to exclude or modify and deciding where to inssrt or replace, etc.)
bool Frustum::AddPlane(Vector3d &p_normal, bool p_IsUnit, bool p_willNotEmpty)
{
	// do NOT call with p_willNotEmpty = true, breaks frustum assumptions
	// if p_willNotEmpty == true, it means PlaneWillEmptyFrustum was called and returned false - DO NOT call with true otherwise!!!

	// don't add if already empty set
	if (empty == true)
		return false;

	Vector3d normalUnitToAdd = p_normal;
	if (p_IsUnit == false)
	{
		if (normalUnitToAdd.Normalize() == false)
		{
#ifdef _DEBUG
			// Track for debugging
			if (count > addedPlanes.count)
				throw gcnew System::Exception("There was a problem - added Planes count should always be >= count");
			addedPlanes.AddNormal(p_normal);
#endif

			// actually this is possible with a portal segment that is parallel to the offset to the origin.  This can happen when you are perfectly in line with the portal but outside of it
			// so allow, but clear the frustum because you clearly can't see through it
			//System::Exception("Normal is zero length");
			Empty();
			return false;
		}
	}

#ifdef _DEBUG
	// Track for debugging
	if (count > addedPlanes.count)
		throw gcnew System::Exception("There was a problem - added Planes count should always be >= count");
	LinkedListNode<FrustumPlaneNormalAndResult> *addedPlanesNode = addedPlanes.AddNormal(normalUnitToAdd);
#endif

	// return true if list is still valid
	// return false if list is now empty
	if (count == 0)
	{
		// don't bother setting intersection segments
		LinkedListNode<FrustumPlane> *newPlane = planes.GetNewNode();
		newPlane->data.normalUnit = normalUnitToAdd;
		planes.AddNode(newPlane);
		count++;

#ifdef _DEBUG
		// Track results for debugging
		LinkedListEnumerator<FrustumPlane> planeEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
		while (planeEnumerator.MoveNext())
		{
			addedPlanesNode->data.resultPlanes.Add(FrustumPlaneNormal(planeEnumerator.Current()->data.normalUnit));
		}
#endif _DEBUG

		return true;
	}
	else if (count == 1)
	{
		// if == current plane, do nothing
		// there is no sense of in front or behind because a direction of view hasn't even been established yet
		// so place the plane, get the intersection segments and just place them on each with no rhyme about which direction things are going yet
		// not correct, the normals can be used to establish a direction and left and right can be determined, and it IS possibl for a plane to be behind another.
		// this is because the normals point towards the valid space.  The space on the other side of the planes are invalid
		// >>> note: it is possible for planes to keep piling on because they clearly are all in front one after the other or all behind one after the other.  When a plane finally arrives that makes it clear
		//   what the truth is by how the segments are included or not, the algorithm will kick out the ones excluded and place the new plane where it belongs between the two that make it clockwise
		// so check the segments may very well be the way to do this completely.
		// algorithm - if a plane only excludes one segment but not the next, just add it and fix the segment that is excluded
		// if it excludes both, the plane in the list gets replaced, and fix both segments.
		// if segments are exactly on the plane, not in front or behind, then just add the plane next to the one whose segments it equals if no other determination canbe made
		// if a plane is added due to deterministic exclusion, then all planes that have equal segments should immediately be checked against it, their segments recalculated, then those segments rechecked against
		//   the ones that are equal.  need a permutation test for this.

		// NEVER add if plane equals any in the list
		Vector3d normalUnit = planes.GetFirstNode()->data.normalUnit; // for debugging
		if (VectorsApproximatelyEqual(normalUnit, normalUnitToAdd) == true) // basically equal
		{
#ifdef _DEBUG
			// Track results for debugging
			LinkedListEnumerator<FrustumPlane> planeEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
			while (planeEnumerator.MoveNext())
			{
				addedPlanesNode->data.resultPlanes.Add(FrustumPlaneNormal(planeEnumerator.Current()->data.normalUnit));
			}
#endif _DEBUG

			return true;
		}

		if (p_willNotEmpty == false)
		{
			if (VectorsApproximatelyOpposite(normalUnit, normalUnitToAdd) == true) // negative equals
			{
				// allow, it's just an empty set now (imagine a point directly beside a portal trying to make a new frustum with it - you get opposite planes, which should in this case be an
				//  empty result.
				//throw gcnew System::Exception("Added plane is opposite of existing single plane");
				// todo: tolerance of 0.9999?
				Empty();
				return false;
			}
		}

		LinkedListNode<FrustumPlane> *newPlane = planes.GetNewNode();
		newPlane->data.normalUnit = normalUnitToAdd;
		planes.AddNode(newPlane);
		count++;

		// set intersection segments for left and right on each, no need to regard proper direction because that hasn't been determined yet
		// next plane to be added will determine the proper direction by the algorithm
		// Note: the planes are not prallel or coinicdent here.  Either the left segment is sensical or the right one is, and the other faces the opposite direction to guarantee
		//   that the next plane that comes in works properly with them to determine a good frustum.
		planes.GetFirstNode()->data.intersectSegmentLeft = planes.GetFirstNode()->data.normalUnit.CrossProd(newPlane->data.normalUnit);
		planes.GetFirstNode()->data.intersectSegmentLeft.Normalize();
		planes.GetFirstNode()->data.intersectSegmentRight = planes.GetFirstNode()->data.intersectSegmentLeft.ScalarMult(-1.0f);
		planes.GetFirstNode()->data.calculateLeftSegment = false;

		newPlane->data.intersectSegmentLeft = planes.GetFirstNode()->data.intersectSegmentRight;
		newPlane->data.intersectSegmentRight = planes.GetFirstNode()->data.intersectSegmentLeft;
		newPlane->data.calculateLeftSegment = false;


#ifdef _DEBUG
		// Track results for debugging
		LinkedListEnumerator<FrustumPlane> planeEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
		while (planeEnumerator.MoveNext())
		{
			addedPlanesNode->data.resultPlanes.Add(FrustumPlaneNormal(planeEnumerator.Current()->data.normalUnit));
		}
#endif _DEBUG

		return true;
	}
	else if (count >= 2)
	{
		// if == either plane, do nothing
		// if negative of any plane empty set
		// solution: throw an exception if there are 2 planes and in any case segments are equal opposites of each other, ONLY if there is already one plane and you're adding another.  This simplifies the algorithm HEAVILY.
		//   besides, usually these structures are initialized with a viewport frustum anyway which will never do this.
		// if both segments of a plane are excluded, remove the existing plane - don't put the new plane in yet.  if all planes have been removed return false
		// if the left segment is excluded, place the plane next, fix the left of the existing plane and set the new plane's right =
		// if the right segment is excluded, insert the plane before, fix the right of the exisiting plane and set the new plane's left
		// after the plane is inserted, continue looping without inserting, just fixing segments or removing planes
		// check: make sure all segments are set properly afterwards (debug only sanity check)

		// make sure the plane doesn't equal any of the planes in the list.  If it does, do nothing.
		LinkedListEnumerator<FrustumPlane> planeTestEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
		while (planeTestEnumerator.MoveNext())
		{
			if (VectorsApproximatelyEqual(planeTestEnumerator.Current()->data.normalUnit, normalUnitToAdd) == true) // basically equal, ignore this plane
			{
#ifdef _DEBUG
				// Track results for debugging
				LinkedListEnumerator<FrustumPlane> planeEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
				while (planeEnumerator.MoveNext())
				{
					addedPlanesNode->data.resultPlanes.Add(FrustumPlaneNormal(planeEnumerator.Current()->data.normalUnit));
				}
#endif _DEBUG
				return true;
			}

			if (p_willNotEmpty == false)
			{
				if (VectorsApproximatelyOpposite(planeTestEnumerator.Current()->data.normalUnit, normalUnitToAdd) == true) // negatives of each other - empty the set, it's impossible to keep
				{
					Empty();
					return false;
				}
			}
		}

		// now loop through the planes
		// get rid of any plane whose segments are both behind the new plane
		LinkedListNode<FrustumPlane> *planeNode = planes.GetFirstNode(); // not using enumerator here because we might delete a node while parsing
		int planeIndex = 0;
		bool added = false;
		// once dones are set, it is impossible to encounter a segment that is behind, so the loop can quit early.
		// have we encountered only a left segment that was behind?  Keep working until a neither segments are behind, and we are done
		bool working = false;
		bool leftSegmentGood = false;
		bool done = false;
		bool firstPlane = true;
		float rightDotProduct, leftDotProduct;
		while (planeNode != &(planes.footer))
		{
			// in case planeNode is deleted, we are tracking the next node in this list
			LinkedListNode<FrustumPlane> *nextNode = planeNode->next;
			bool useNextNode = true;

			if (firstPlane == true)
			{
				rightDotProduct = planeNode->data.intersectSegmentRight * normalUnitToAdd;
				firstPlane = false;
			}
			else
				rightDotProduct = leftDotProduct; // reuse from last loop
			leftDotProduct = planeNode->data.intersectSegmentLeft * normalUnitToAdd;

			if (rightDotProduct < 0.0f)
			{
				// right is behind
				if (leftDotProduct < 0.0f)
				{
					// both are behind
					if (added == false)
					{
						// replace the plane
						planeNode->data.normalUnit = normalUnitToAdd;
						planeNode->data.calculateLeftSegment = true;

						added = true;

						// no need to check if count == 1 for caused emptiness here - count is still >=2 at this place in the code - the count == 1 condition is checked in removals below

						// intersections will be fixed later
					}
					else
					{
						// remove the plane
						LinkedListNode<FrustumPlane> *tempNode = nextNode;
						planes.DeleteNode(planeNode);
						planeNode = tempNode;
						// don't use nextNode to advance
						useNextNode = false;
						count--;
						planeIndex--; // nextNode is now one index less, so reflect that in the new planeIndex for next iteration

						if (count == 1)
						{
							// new plane is the only one in the list
							// plane has cleared all the others.  Wipe it out, prevent further additions
							Empty();
							return false;
						}

						// intersections will be fixed later
					}
				}
				else
				{
					if (added == false)
					{
						// insert new plane just before existing
						LinkedListNode<FrustumPlane> *newPlane = planes.GetNewNode();
						newPlane->data.Initialize();
						newPlane->data.normalUnit = normalUnitToAdd;
						if (planeIndex > 0)
							// put just before
							planes.InsertNode(newPlane, planeNode->prev);
						else
							// put first
							planes.InsertNode(newPlane, nullptr);
						count++;
						planeIndex++;
						// nextNode still good, plane was added behind
						added = true;

						// intersections will be fixed later
					}
					else
					{
						// do nothing, right intersection will be fixed later
					}
				}
			}
			else
			{
				// right is in front
				if (leftDotProduct < 0.0f)
				{
					planeNode->data.calculateLeftSegment = true;

					// only left is behind
					if (working == false)
						working = true;

					if (added == false)
					{
						// insert new Plane just after existing
						LinkedListNode<FrustumPlane> *newPlane = planes.GetNewNode();
						newPlane->data.Initialize();
						newPlane->data.normalUnit = normalUnitToAdd;
						// put just after
						planes.InsertNode(newPlane, planeNode);
						count++;
						planeIndex++;
						// nextNode still good, will skip the inserted plane
						added = true;

						// intersections will be fixed later
					}
					else
					{
						// do nothing, right intersection will be fixed later
					}
				}
				else
				{
					// none behind - do nothing, keep going
					if (working == true)
						// both are in front - it's impossible to encounter another behind segment.  we're done
						break;

					// todo: is there any way to determine that plane cannot contribute at all early so that we know it will never be added?
					// it's possible that if the existing normal * the new normal > 0.0 this would be true.
				}
			}

			if (useNextNode == true)
				planeNode = nextNode;
			planeIndex++;
		} // while

		// since we may stop early, this is no longer a valid check
		//if (planeIndex != count)
		//	throw gcnew System::Exception("Something went wrong with plane addition - planeIndex does not reflect count");

#ifdef _DEBUG
		// Track results for debugging
		LinkedListEnumerator<FrustumPlane> planeEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
		while (planeEnumerator.MoveNext())
		{
			addedPlanesNode->data.resultPlanes.Add(FrustumPlaneNormal(planeEnumerator.Current()->data.normalUnit));
		}
#endif _DEBUG

		if (added == true)
		{
			if (count == 1)
				throw gcnew System::Exception("Should have returned with Empty() condition by now");
			if (count == 2)
				throw gcnew System::Exception("This should not happen!  Once a frustum has 2 planes, the next addition should be ignored, cause Empty(), or result in 3 planes!");

			// now fix all intersections
			// IMPORTANT!!!! COMPILER BUG!!! this variable used to be a new definition of planeNode, a re-use from the variable name from above.
			// For compilations for some classes and not others, the resulting code seemed to be intermittantly using the different values for each,
			//   causing the intersection calculations to be incorrect and causing assumption errors with the frustum class.  This took a long time to track down.
			//   DO NOT DEFINE NEW VARIABLE THAT USE NAMES FOR OTHER VARIABLES ALSO VISIBLE IN THE CURRENT SCOPE!  Make a new variable name, or re-use the prior one!
			//LinkedListNode<FrustumPlane> *planeNode = planes.GetFirstNode();  // <===== SUPERBAD here, although it normally works
			planeNode = planes.GetFirstNode();
			int planeIndex = 0;
			while (planeNode != &(planes.footer))
			{
				if (planeNode->data.calculateLeftSegment == true)
				{
					if (planeIndex != count - 1)
					{
						// fix left of current and right of next
						planeNode->data.intersectSegmentLeft = planeNode->data.normalUnit.CrossProd(planeNode->next->data.normalUnit);
						planeNode->data.intersectSegmentLeft.Normalize();
						planeNode->next->data.intersectSegmentRight = planeNode->data.intersectSegmentLeft;
					}
					else
					{
						// fix left of current and right of first
						planeNode->data.intersectSegmentLeft = planeNode->data.normalUnit.CrossProd(planes.GetFirstNode()->data.normalUnit);
						planeNode->data.intersectSegmentLeft.Normalize();
						planes.GetFirstNode()->data.intersectSegmentRight = planeNode->data.intersectSegmentLeft;
					}

					planeNode->data.calculateLeftSegment = false;
				}

#ifdef _DEBUG
				// all intersection segments (just check left, that's enough since all the rights equal the lefts as a group) must be contained within the plane that was added
				// this is the definition of the routine!!!
				float result;
				result = normalUnitToAdd * planeNode->data.intersectSegmentLeft;
				if (result < -0.00001f)
				{
					System::String^ analysisCode = "";
					analysisCode += System::String::Format("// all planes added (final count {0}):\r\n", count);
					analysisCode += "Frustum addedPlaneFrustum;\r\n";
					LinkedListEnumerator <FrustumPlaneNormalAndResult> addedPlaneEnumerator = addedPlanes.GetEnumerator();
					while (addedPlaneEnumerator.MoveNext())
					{
						analysisCode += "\r\n";
						LinkedListEnumerator<FrustumPlaneNormal> normalEnumerator = LinkedListEnumerator<FrustumPlaneNormal>(addedPlaneEnumerator.Current()->data.resultPlanes);
						int index = 0;
						while (normalEnumerator.MoveNext())
						{
							analysisCode += System::String::Format("// {0}: {1:F12}f, {2:F12}f, {3:F12}f));\r\n", index, normalEnumerator.Current()->data.normal.x, normalEnumerator.Current()->data.normal.y, normalEnumerator.Current()->data.normal.z);
							index++;
						}
						analysisCode += System::String::Format("addedPlaneFrustum.AddPlane(Vector3d({0:F12}f, {1:F12}f, {2:F12}f));\r\n", addedPlaneEnumerator.Current()->data.normal.x, addedPlaneEnumerator.Current()->data.normal.y, addedPlaneEnumerator.Current()->data.normal.z);
					}

					throw gcnew System::Exception(System::String::Format("Left segment not contained! (result = {0:F8})", result));
				}
#endif _DEBUG

				planeNode = planeNode->next;
				planeIndex++;
			} // while
		} // added

#ifdef _DEBUG
		// verify no normals are duplicated in the list to make sure planes are good
		LinkedListEnumerator<FrustumPlane> planeEnumerator1 = GetPlaneEnumerator();
		int countCheck = 0;
		while (planeEnumerator1.MoveNext())
		{
			countCheck++;
		}
		if (countCheck != count)
			throw gcnew System::Exception("Count != number of nodes!");
		planeEnumerator1 = GetPlaneEnumerator();
		while (planeEnumerator1.MoveNext())
		{
			if (count > 2)
			{
				// make sure all planes are contained by the plane just added (or even if it wasn't added)
				float result;
				result = normalUnitToAdd * planeEnumerator1.Current()->data.intersectSegmentLeft;
				if (result < -0.00001f)
					throw gcnew System::Exception(System::String::Format("Left segment not contained! (result = {0:F8})", result));
				result = normalUnitToAdd * planeEnumerator1.Current()->data.intersectSegmentRight;
				if (result < -0.00001f)
					throw gcnew System::Exception(System::String::Format("Right segment not contained! (result = {0:F8})", result));
			}

			if (planeEnumerator1.Current()->next != planes.GetLastNode())
			{
				LinkedListEnumerator<FrustumPlane> planeEnumerator2 = GetPlaneEnumerator(planeEnumerator1.Current()->next);
				while (planeEnumerator2.MoveNext())
				{
					//if (planeEnumerator1.Current()->data.normalUnit * planeEnumerator2.Current()->data.normalUnit > 0.9999f)
					if (planeEnumerator1.Current()->data.normalUnit.Equals(planeEnumerator2.Current()->data.normalUnit) == true)
						throw gcnew System::Exception("Planes in result frustum have equal normals!");
				}
			}
			else
				break;
		}
#endif _DEBUG

	} // count >= 2

	return true;

} // Add()

LinkedListEnumerator<FrustumPlane> Frustum::GetPlaneEnumerator(LinkedListNode<FrustumPlane> *p_startingNode)
{
	if (p_startingNode == nullptr)
		return LinkedListEnumerator<FrustumPlane>(planes);
	else
		return LinkedListEnumerator<FrustumPlane>(planes, p_startingNode);
}

void Frustum::CopyTo(Frustum *p_dstFrustum)
{
	p_dstFrustum->Initialize();

	p_dstFrustum->origin = origin;
	p_dstFrustum->empty = empty;
	p_dstFrustum->count = count;
	p_dstFrustum->nullSet = nullSet;
	LinkedListEnumerator<FrustumPlane> enumerator = GetPlaneEnumerator();
	while (enumerator.MoveNext())
	{
		p_dstFrustum->planes.Add(enumerator.Current()->data);
	}

#ifdef _DEBUG
	p_dstFrustum->addedPlanes.Clear();
	LinkedListEnumerator<FrustumPlaneNormalAndResult> addedPlaneEnumerator = addedPlanes.GetEnumerator();
	while (addedPlaneEnumerator.MoveNext())
	{
		LinkedListNode<FrustumPlaneNormalAndResult> *resultNode = p_dstFrustum->addedPlanes.AddNormal(addedPlaneEnumerator.Current()->data.normal);
		LinkedListEnumerator<FrustumPlaneNormal> resultEnumerator = LinkedListEnumerator<FrustumPlaneNormal>(addedPlaneEnumerator.Current()->data.resultPlanes);
		while (resultEnumerator.MoveNext())
		{
			resultNode->data.resultPlanes.Add(FrustumPlaneNormal(resultEnumerator.Current()->data.normal));
		}
	}
#endif
}

void Frustum::ReflectThroughPlane(Vector3d &p_position, Vector3d &p_normal, Frustum *p_dstFrustum)
{
	p_dstFrustum->Initialize();
	p_dstFrustum->origin = origin - p_normal.ScalarMult(2.0f * ((origin - p_position) * p_normal));
	LinkedListEnumerator<FrustumPlane> enumerator = GetPlaneEnumerator();
	while (enumerator.MoveNext())
	{
		// todo: could just reflect all the elements rather than adding plane for more speed, but this is ok for now.  It preserves the rotation adjacency
		///   for more AddPlane calls later
		p_dstFrustum->AddPlane(enumerator.Current()->data.normalUnit - p_normal.ScalarMult(2.0f * (enumerator.Current()->data.normalUnit * p_normal)));
	}
}

bool Frustum::Equals(Frustum *p_frustum)
{
	// are the two frustums effectively equal?  origin and normals and plane quantity should be the same. (normals should be extremely close)
	if (nullSet != p_frustum->nullSet)
		return false;
	if (empty != p_frustum->empty)
		return false;
	if (count != p_frustum->count)
		return false;
	if (origin.Equals(p_frustum->origin) == false)
		return false;
	LinkedListEnumerator<FrustumPlane> enumerator = GetPlaneEnumerator();
	LinkedListNode<FrustumPlane> *node = p_frustum->planes.GetFirstNode();
	while (enumerator.MoveNext())
	{
		if (VectorsApproximatelyEqual(node->data.normalUnit, enumerator.Current()->data.normalUnit) == false)
			return false;
		node = node->next;
	}

	return true;
}

bool Frustum::Contains(Frustum *p_frustum, float &p_failedresult)
{
	LinkedListEnumerator<FrustumPlane> frustumEnumerator = p_frustum->GetPlaneEnumerator();
	while (frustumEnumerator.MoveNext())
	{
		// this frustum must contain all the segments of the frustum
		LinkedListEnumerator<FrustumPlane> enumerator = GetPlaneEnumerator();
		while (enumerator.MoveNext())
		{
			Vector3d segment = frustumEnumerator.Current()->data.intersectSegmentLeft;
			Vector3d normal = enumerator.Current()->data.normalUnit;
			float result = segment * normal;
			if (result < -0.00001f) // tolerance
			{
				p_failedresult = result;
				return false;
			}

			segment = frustumEnumerator.Current()->data.intersectSegmentRight;
			result = segment * normal;
			if (result < -0.00001f) // tolerance
			{
				p_failedresult = result;
				return false;
			}
		}
	}

	return true;
}

// purely for debugging in other environments
System::String^ Frustum::WriteFrustumCreationCode()
{
	System::String ^code = "";
	code += "frustum = FrustumX;\r\n";
	code += "frustum->Initialize();\r\n";
	LinkedListEnumerator<FrustumPlane> planeEnumerator = LinkedListEnumerator<FrustumPlane>(planes);
	while (planeEnumerator.MoveNext())
	{
		code += System::String::Format("frustum->AddPlane(Vector3d({0:F12}f, {1:F12}f, {2:F12}f));\r\n", planeEnumerator.Current()->data.normalUnit.x, planeEnumerator.Current()->data.normalUnit.y, planeEnumerator.Current()->data.normalUnit.z);
	}

	return code;
}

void Frustum::Test()
{
	// just checking to make sure structure works

	AddPlane(Vector3d(0, 1, 0));// validates left
	if (count != 1)
		throw gcnew System::Exception(System::String::Format("Count should be 1, is {0}", count));
	AddPlane(Vector3d(1, 0, 0));// validates up
	if (count != 2)
		throw gcnew System::Exception(System::String::Format("Count should be 2, is {0}", count));
	AddPlane(Vector3d(-1, -1, 2));// validates lower right
	if (count != 3)
		throw gcnew System::Exception(System::String::Format("Count should be 3, is {0}", count));
	AddPlane(Vector3d(-1, -1, 1)); // replaces vec4 because it cuts its space
	if (count != 3)
		throw gcnew System::Exception(System::String::Format("Count should be 3, is {0}", count));
	AddPlane(Vector3d(-1, -1, 2)); // ignored because it is covered already
	if (count != 3)
		throw gcnew System::Exception(System::String::Format("Count should be 3, is {0}", count));
	AddPlane(Vector3d(1, 1, -0.5f)); // cuts space of vec1 and vec2
	if (count != 4)
		throw gcnew System::Exception(System::String::Format("Count should be 4, is {0}", count));
	if (IsEmpty() == true)
		throw gcnew System::Exception(System::String::Format("Should not be empty"));
	if (AddPlane(Vector3d(1, 1, -3)) == true) // invalidates entire space
		throw gcnew System::Exception(System::String::Format("Should have returned false, returned true"));
	if (IsEmpty() == false)
		throw gcnew System::Exception(System::String::Format("Should be empty"));

	// make sure add plane provides good results
	Initialize();
	AddPlane(Vector3d(0, 1, 1));
	AddPlane(Vector3d(1, 0, 1));
	AddPlane(Vector3d(0, -1, 1));
	AddPlane(Vector3d(-1, 0, 1));
	AddPlane(Vector3d(1, 1, 1.1f));
	AddPlane(Vector3d(-1, 1, 1.1f));
	AddPlane(Vector3d(1, -1, 1.1f));
	AddPlane(Vector3d(-1, -1, 1.1f));
	if (count != 8)
		throw gcnew System::Exception(System::String::Format("Should be count of 8"));

	TestDebugCode();
}

// paste analysis code here to help analyze frustum assumption problems
void Frustum::TestDebugCode()
{
	// all planes added (final count 6):
	Frustum addedPlaneFrustum;

	// 0: -0.998205000000f, 0.000000000000f, 0.059889860000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.998205000000f, 0.000000000000f, 0.059889860000f));

	// 0: -0.998205000000f, 0.000000000000f, 0.059889860000f));
	// 1: 0.000000000000f, -0.996815300000f, 0.079745220000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, -0.996815300000f, 0.079745220000f));

	// 0: 0.946772000000f, 0.000000000000f, 0.321904800000f));
	// 1: -0.998205000000f, 0.000000000000f, 0.059889860000f));
	// 2: 0.000000000000f, -0.996815300000f, 0.079745220000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.946772000000f, 0.000000000000f, 0.321904800000f));

	// 0: 0.946772000000f, 0.000000000000f, 0.321904800000f));
	// 1: 0.000000000000f, 0.952424100000f, 0.304775700000f));
	// 2: -0.998205000000f, 0.000000000000f, 0.059889860000f));
	// 3: 0.000000000000f, -0.996815300000f, 0.079745220000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, 0.952424100000f, 0.304775700000f));

	// 0: 0.946772000000f, 0.000000000000f, 0.321904800000f));
	// 1: 0.000000000000f, 0.952424100000f, 0.304775700000f));
	// 2: -0.999844300000f, 0.000000000000f, 0.017643590000f));
	// 3: 0.000000000000f, -0.996815300000f, 0.079745220000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.999844300000f, 0.000000000000f, 0.017643590000f));

	// 0: 0.000000000000f, -0.999723300000f, 0.023522900000f));
	// 1: 0.946772000000f, 0.000000000000f, 0.321904800000f));
	// 2: 0.000000000000f, 0.952424100000f, 0.304775700000f));
	// 3: -0.999844300000f, 0.000000000000f, 0.017643590000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, -0.999723300000f, 0.023522900000f));

	// 0: 0.000000000000f, -0.999723300000f, 0.023522900000f));
	// 1: 0.995037100000f, 0.000000000000f, 0.099504430000f));
	// 2: 0.000000000000f, 0.952424100000f, 0.304775700000f));
	// 3: -0.999844300000f, 0.000000000000f, 0.017643590000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.995037100000f, 0.000000000000f, 0.099504430000f));

	// 0: 0.000000000000f, -0.999723300000f, 0.023522900000f));
	// 1: 0.995037100000f, 0.000000000000f, 0.099504430000f));
	// 2: 0.000000000000f, 0.995600100000f, 0.093703540000f));
	// 3: -0.999844300000f, 0.000000000000f, 0.017643590000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, 0.995600100000f, 0.093703540000f));

	// 0: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 1: 0.000000000000f, -0.999723300000f, 0.023522900000f));
	// 2: 0.995037100000f, 0.000000000000f, 0.099504430000f));
	// 3: 0.000000000000f, 0.995600100000f, 0.093703540000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.996739300000f, 0.000000000000f, -0.080689000000f));

	// 0: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 1: -0.229037800000f, -0.973417500000f, 0.000000000000f));
	// 2: 0.000000000000f, -0.999723300000f, 0.023522900000f));
	// 3: 0.995037100000f, 0.000000000000f, 0.099504430000f));
	// 4: 0.000000000000f, 0.995600100000f, 0.093703540000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.229037800000f, -0.973417500000f, 0.000000000000f));

	// 0: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 1: -0.229037800000f, -0.973417500000f, 0.000000000000f));
	// 2: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	// 3: 0.000000000000f, 0.995600100000f, 0.093703540000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.996021000000f, 0.000000000000f, 0.089118310000f));

	// 0: -0.685362000000f, 0.728202400000f, 0.000000000000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.229037800000f, -0.973417500000f, 0.000000000000f));
	// 3: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.685362000000f, 0.728202400000f, 0.000000000000f));

	// 0: -0.685362000000f, 0.728202400000f, 0.000000000000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: -0.229037800000f, -0.973417500000f, 0.000000000000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.996739300000f, 0.000000000000f, -0.080689000000f));

	// 0: -0.685362000000f, 0.728202400000f, 0.000000000000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999818700000f, 0.019044160000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, -0.999818700000f, 0.019044160000f));

	// 0: -0.685362000000f, 0.728202400000f, 0.000000000000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999818700000f, 0.019044160000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.984830600000f, 0.000000000000f, 0.173518300000f));

	// 0: 0.000000000000f, 0.997110100000f, 0.075970290000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999818700000f, 0.019044160000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, 0.997110100000f, 0.075970290000f));

	// 0: 0.000000000000f, 0.997110100000f, 0.075970290000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999818700000f, 0.019044160000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.997279600000f, 0.000000000000f, -0.073712500000f));

	// 0: 0.000000000000f, 0.997110100000f, 0.075970290000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999848800000f, 0.017388680000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, -0.999848800000f, 0.017388680000f));

	// 0: 0.000000000000f, 0.997110100000f, 0.075970290000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999848800000f, 0.017388680000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.987306200000f, 0.000000000000f, 0.158828000000f));

	// 0: 0.000000000000f, 0.997589100000f, 0.069397500000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: 0.000000000000f, -0.999848800000f, 0.017388680000f));
	// 4: 0.996021000000f, 0.000000000000f, 0.089118310000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.000000000000f, 0.997589100000f, 0.069397500000f));

	// 0: -0.978434200000f, 0.000000000000f, -0.206558800000f));
	// 1: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.978434200000f, 0.000000000000f, -0.206558800000f));

	// 0: -0.978434200000f, 0.000000000000f, -0.206558800000f));
	// 1: -0.070003130000f, -0.997546800000f, 0.000000000000f));
	// 2: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 3: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.070003130000f, -0.997546800000f, 0.000000000000f));

	// 0: -0.978434200000f, 0.000000000000f, -0.206558800000f));
	// 1: -0.070003130000f, -0.997546800000f, 0.000000000000f));
	// 2: 0.974979300000f, 0.000000000000f, 0.222295800000f));
	// 3: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 4: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	addedPlaneFrustum.AddPlane(Vector3d(0.974979300000f, 0.000000000000f, 0.222295800000f));

	// 0: -0.270255900000f, 0.962788500000f, 0.000000000000f));
	// 1: -0.978434200000f, 0.000000000000f, -0.206558800000f));
	// 2: -0.070003130000f, -0.997546800000f, 0.000000000000f));
	// 3: 0.974979300000f, 0.000000000000f, 0.222295800000f));
	// 4: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	// 5: -0.996739300000f, 0.000000000000f, -0.080689000000f));
	addedPlaneFrustum.AddPlane(Vector3d(-0.270255900000f, 0.962788500000f, 0.000000000000f));

}