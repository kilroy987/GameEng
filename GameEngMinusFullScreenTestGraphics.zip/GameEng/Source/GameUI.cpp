#include "..\Headers\GameUI.h"
#include "..\Headers\GameViewport.h"

using namespace GameEng::UI;

LinkedList<GameUIFormNode> LinkedList<GameUIFormNode>::DeletedList("Deleted List for GameUIFormNode");
LinkedList<GameUIControlNode> LinkedList<GameUIControlNode>::DeletedList("Deleted List for GameUIControlNode");
LinkedList<GameUIMessageBoxNode> LinkedList<GameUIMessageBoxNode>::DeletedList("Deleted List for GameUIMessageBoxNode");

void MouseMoveArgs::Populate(GameMouse ^p_gameMouse, GameUIFormBase *p_form, GameUIControlBase *p_control)
{
	// here in .cpp so that GameUIForm and GameUIControl resolve
	scene.X = p_gameMouse->currentX;
	scene.Y = p_gameMouse->currentY;

	RectangleF formRect = ((GameUIForm *)p_form)->GetRect();
	form.X = p_gameMouse->currentX - int(formRect.Left);
	form.Y = p_gameMouse->currentY - int(formRect.Top);

	if (p_control != nullptr)
	{
		RectangleF controlRect = ((GameUIControl *)p_control)->GetRect();
		control.X = form.X - int(controlRect.Left);
		control.Y = form.Y - int(controlRect.Top);
	}
	else
	{
		control.X = 0;
		control.Y = 0;
	}
}

void GameUIControl::Focus()
{
	// definition is here to prevent having to cast GameUIForm pointer to a GameUiFormBase pointer, which causes problems inside SetControlFocus.
	GameContext::Instance->GetUI()->SetControlFocus(parentFormRef, this);
}

// placed here so that GameUIForm* is well formed
void GameUIButton::RenderBorder(GraphicsBase *p_graphics, ModelVertex *p_vertices)
{
	GameColor colors[2];
	float lineWidth = 1.0f;
	// if button is selected, render border wider
	if (parentFormRef->controlWithFocus == this)
		lineWidth = 2.0f;
	if (renderAsDown == false)
	{
		colors[0] = GetBorderColor();
		colors[1] = GetBorderColor().Modulate(0.65f);

		p_vertices[2].colorIndex = 1;
		p_vertices[3].colorIndex = 1;
		p_vertices[4].colorIndex = 1;
		p_graphics->RenderLineStrip(lineWidth, colors, 2, &(p_vertices[2]), 3, true);
		p_vertices[0].colorIndex = 0;
		p_vertices[1].colorIndex = 0;
		p_vertices[2].colorIndex = 0;
		p_graphics->RenderLineStrip(lineWidth, colors, 2, p_vertices, 3, true);
	}
	else
	{
		colors[0] = GetBorderColor().Modulate(0.65f);
		colors[1] = GetBorderColor();

		p_vertices[0].colorIndex = 0;
		p_vertices[1].colorIndex = 0;
		p_vertices[2].colorIndex = 0;
		p_graphics->RenderLineStrip(lineWidth, colors, 2, p_vertices, 3, true);
		p_vertices[2].colorIndex = 1;
		p_vertices[3].colorIndex = 1;
		p_vertices[4].colorIndex = 1;
		p_graphics->RenderLineStrip(lineWidth, colors, 2, &(p_vertices[2]), 3, true);
	}
}

// so that GameUIControl properly understands GameUIForm, just in case
void GameUI::ProcessKeyInput(GameInputEvent &p_event)
{
	// only works if a control has focus, including tabbing.
	if (currentFocusControl != nullptr)
	{
		switch (p_event.type)
		{
		case GameInputEventType::KeyDown:
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Tab && currentFocusControl->AcceptsTab() == false)
			{
				if (p_event.shiftModifier == false)
					MoveFocusToNextControl();
				else
					MoveFocusToNextControl(false);
			}
			else
			{
				GameUIControl *originalCurrentFocusControl = currentFocusControl;
				currentFocusForm->KeyDown(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
				if (p_event.handled == false)
				{
					if (originalCurrentFocusControl->IsEnabled() && originalCurrentFocusControl->parentFormRef->closed == false && originalCurrentFocusControl->parentFormRef->IsEnabled())
					{
						originalCurrentFocusControl->KeyDown(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
						//	break;
						//case GameInputEventType::KeyPress:
						if (p_event.keyPressed != 0 && p_event.suppressKeyPress == false)
						{
							// if the control is still active and the form is still open (focus could have changed)
							if (originalCurrentFocusControl->IsEnabled() && originalCurrentFocusControl->parentFormRef->closed == false && originalCurrentFocusControl->parentFormRef->IsEnabled())
								originalCurrentFocusControl->KeyPress(GameKeyPressEventArgs(p_event.keyPressed));
						}
					}
				}
			}
		}
		break;
		case GameInputEventType::KeyUp:
			currentFocusControl->KeyUp(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
			break;
		}
	}
	else if (currentFocusForm != nullptr)
	{
		switch (p_event.type)
		{
		case GameInputEventType::KeyDown:
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Tab)
			{
				if (p_event.shiftModifier == false)
					MoveFocusToNextControl();
				else
					MoveFocusToNextControl(false);
			}
			else
			{
				GameUIForm *originalCurrentFocusForm = currentFocusForm;
				currentFocusForm->KeyDown(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
				//	break;
				//case GameInputEventType::KeyPress:
				if (p_event.keyPressed != 0 && p_event.suppressKeyPress == false)
				{
					// as long as form is still open (focus could have changed)
					if (originalCurrentFocusForm->closed == false)
						originalCurrentFocusForm->KeyPress(GameKeyPressEventArgs(p_event.keyPressed));
				}
			}
			break;
		case GameInputEventType::KeyUp:
			currentFocusForm->KeyUp(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
			break;
		}
	}
	else
	{
		// not sure what this handles, I guess the topmost modal form or normal form without anything having focus
		GameUIForm *topForm = GetTopForm(true);
		if (topForm != nullptr)
		{
			switch (p_event.type)
			{
			case GameInputEventType::KeyDown:
			{
				GameUIForm *originalTopForm = topForm;
				if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Tab)
				{
					if (p_event.shiftModifier == false)
						MoveFocusToNextControl();
					else
						MoveFocusToNextControl(false);
				}
				else
					topForm->KeyDown(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
				//break;
				//case GameInputEventType::KeyPress:
				if (originalTopForm->IsEnabled() && originalTopForm->closed == false)
					topForm->KeyPress(GameKeyPressEventArgs(p_event.keyPressed));
					break;
			}
			case GameInputEventType::KeyUp:
				topForm->KeyUp(GameKeyEventArgs(p_event.keyCode, p_event.shiftModifier, p_event.ctrlModifier, p_event.altModifier));
				break;
			}
		}
	}
}

void GameUIMessageBoxMessageLabel::SetText(LinkedList<GameRichText> &p_richText, GameViewport ^p_viewport)
{
	// messagebox text is set when it's created.  This is the best time to determine the proper width of the message box according to the size of the screen.

	linedRichText.Clear();

	// split up the text
	int maxLabelWidth = p_viewport->GetWidth()/3;
	GameFontHelper::WrapText(p_richText, linedRichText, maxLabelWidth);

	ParseRichText();
}

void GameUIMessageBoxMessageLabel::ParseRichText(bool p_setControlSize, GraphicsBase *p_graphics, bool p_render, PointF *p_origin)
{
	// get the widest text width and number of lines, set control and form width accordingly
	LinkedListEnumerator<GameLinedRichText> linedEnum = LinkedListEnumerator<GameLinedRichText>(linedRichText);
	int currentLine = -1;
	int totalTextWidth = 0;
	int largestTextWidth = 0;
	int lineQty = 0;
	int largestLineHeight = 0; // tallest text in each line, not all of it
	int totalTextHeight = 0; // tallest text in each line, not all of it
	LinkedListNode<GameLinedRichText> *firstLineNode = nullptr;;
	LinkedListNode<GameLinedRichText> *lastLineNode = nullptr;
	PointF currentRender;
	if (p_render == true)
	{
		currentRender = *p_origin;
	}
	while (linedEnum.MoveNext())
	{
		if (currentLine != linedEnum.Current()->data.line)
		{
			if (currentLine != -1)
			{
				if (totalTextWidth > largestTextWidth)
					largestTextWidth = totalTextWidth;
				totalTextHeight += largestLineHeight;

				if (p_render == true)
				{
					// render the line
					float currentX = 0;
					LinkedListNode<GameLinedRichText> *node = firstLineNode;
					while (node != lastLineNode->next)
					{
						p_graphics->RenderFont(node->data.text, node->data.fontRef, int(currentRender.X + currentX), int(currentRender.Y + float(largestLineHeight - node->data.textSize.Y)), node->data.foreColor);
						currentX += float(node->data.textSize.X);
						node = node->next;
					}
					currentRender.Y += float(largestLineHeight);
				}
			}

			largestLineHeight = 0;
			totalTextWidth = 0;
			currentLine = linedEnum.Current()->data.line;
			lineQty++;
			firstLineNode = linedEnum.Current();
			lastLineNode = linedEnum.Current();
		}

		totalTextWidth += linedEnum.Current()->data.textSize.X;
		if (linedEnum.Current()->data.textSize.Y > largestLineHeight)
			largestLineHeight = linedEnum.Current()->data.textSize.Y;
		lastLineNode = linedEnum.Current();
	}
	if (currentLine != -1)
	{
		if (totalTextWidth > largestTextWidth)
			largestTextWidth = totalTextWidth;
		totalTextHeight += largestLineHeight;
		if (p_render == true)
		{
			// render the line
			float currentX = 0;
			LinkedListNode<GameLinedRichText> *node = firstLineNode;
			while (node != lastLineNode->next)
			{
				p_graphics->RenderFont(node->data.text, node->data.fontRef, int(currentRender.X + currentX), int(currentRender.Y + float(largestLineHeight - node->data.textSize.Y)), node->data.foreColor);
				currentX += float(node->data.textSize.X);
				node = node->next;
			}
			currentRender.Y += float(largestLineHeight);
		}
	}

	if (p_setControlSize == true)
	{
		// set control size
		SetSize(PointF(float(largestTextWidth), float(totalTextHeight)));

		// set parent form size
		parentFormRef->SetSize(PointF(float(largestTextWidth + 20.0f), float(totalTextHeight + 20.0f)));
	}
}



