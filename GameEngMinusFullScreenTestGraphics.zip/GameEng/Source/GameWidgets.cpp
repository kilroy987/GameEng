#include "..\Headers\GameWidgets.h"

using namespace GameEng::Widgets;

LinkedList<AlphaTrailPoint> LinkedList<AlphaTrailPoint>::DeletedList;