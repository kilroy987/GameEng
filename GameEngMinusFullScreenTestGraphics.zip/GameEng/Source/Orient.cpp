#pragma once

#include "..\Headers\Orient.h"
#include "..\Headers\MathConstants.h"

#include <Windows.h> // HWND, CopyMemory

using namespace GameEng::Math;

int Orient3d::NextNormalizeCounter = 1;

// rules:
// l, u, and f are unit vectors (length 1.0)
// l = u x f;
// u = f x l;
// f = l x u;
// so that they can represent a coordinate system within the parent space
// circumstances where they are meant to follow different rules are up to the implementer

Orient3d::Orient3d()
{
	l.Set(1, 0, 0);
	u.Set(0, 1, 0);
	f.Set(0, 0, 1);
	p.Set(0, 0, 0);

	normalizeCounter = NextNormalizeCounter++;
	if (NextNormalizeCounter > ORIENT3D_NORMALIZECOUNTERMAXVALUE)
		NextNormalizeCounter = 1;
}

Orient3d::Orient3d(Vector3d p_left, Vector3d p_up, Vector3d p_forward, Vector3d p_position)
{
	l = p_left;
	u = p_up;
	f = p_forward;
	p = p_position;

	InitializeNormalizationCounter();
}

Orient3d::Orient3d(Vector3d p_left, Vector3d p_up, Vector3d p_forward)
{
	l = p_left;
	u = p_up;
	f = p_forward;
	p.Set(0, 0, 0);

	InitializeNormalizationCounter();
}

void Orient3d::Set(Orient3d p_orient3d)
{
	l = p_orient3d.l;
	u = p_orient3d.u;
	f = p_orient3d.f;
	p = p_orient3d.p;

	InitializeNormalizationCounter();
}

void Orient3d::Set(Vector3d p_left, Vector3d p_up, Vector3d p_forward, Vector3d p_position)
{
	l = p_left;
	u = p_up;
	f = p_forward;
	p = p_position;

	InitializeNormalizationCounter();
}

bool Orient3d::Equals(Orient3d &p_orient)
{
	if (l.Equals(p_orient.l) == false)
		return false;
	if (u.Equals(p_orient.u) == false)
		return false;
	if (f.Equals(p_orient.f) == false)
		return false;
	if (p.Equals(p_orient.p) == false)
		return false;

	return true;
}


void Orient3d::LoadIdentity()
{
	l = Vector3d(1, 0, 0);
	u = Vector3d(0, 1, 0);
	f = Vector3d(0, 0, 1);
	p = Vector3d(0, 0, 0);
}

void Orient3d::LoadIdentity(Vector3d &p_position)
{
	l = Vector3d(1, 0, 0);
	u = Vector3d(0, 1, 0);
	f = Vector3d(0, 0, 1);
	p = p_position;
}

// factor is the tangent value (1.0 = 45.0 degrees of rotation, -1.0 = -45.0 degree, etc.)
void Orient3d::Rotate(Orient3dAxis p_axis, float p_factor)
{
	// no normalization required during this operation

	if (p_axis == Orient3dAxis::Up) // positive factor is to the left
	{
		f = f + l.ScalarMult(p_factor);
		if (f.Normalize() == true)
		{
			l = u.CrossProd(f);
		}
		else
			throw gcnew Exception("Normalize failed while rotating on Up axis");
	}
	else if (p_axis == Orient3dAxis::Left) // positive factor is up
	{
		f = f + u.ScalarMult(p_factor);
		if (f.Normalize() == true)
		{
			u = f.CrossProd(l);
		}
		else
			throw gcnew Exception("Normalize failed while rotating on Left axis");
	}
	else if (p_axis == Orient3dAxis::Forward) // positive factor is top towards the left
	{
		u = u + l.ScalarMult(p_factor);
		if (u.Normalize() == true)
		{
			l = u.CrossProd(f);
		}
		else
			throw gcnew Exception("Normalize failed while rotating on Forward axis");
	}
}

// if the rotation vector is pointing right at you and the degrees are positive, the spin is clockwise.
void Orient3d::Rotate(Vector3d &p_rotationAxis, float p_degrees, bool p_axisIsUnitLength) // p_axisIsUnitLength is default in declaration to true
{
	// Rotate on an arbitary vector in the world space that the orient3d is in
	// This affects the orientation only, not the position
	Vector3d UA;     //Unit axis
	Vector3d RotateL;
	Vector3d RotateU;
	Vector3d RotateF;
	float RA;            //radian angle
	float cosRA, sinRA, OneMinusCosRA;

	// if degrees = 0.0f, do nothing.
	if (p_degrees == 0.0f || p_degrees == -0.0f)
		return;

	// Unitize the incoming axis
	UA.Set(p_rotationAxis.x, p_rotationAxis.y, p_rotationAxis.z);

	RA = MathUtilities::DegreesToRadians(p_degrees);

	if (p_axisIsUnitLength == false)
		if (!UA.Normalize()) 
			throw gcnew Exception("Unable to normalize rotation vector");

	cosRA = float(cos(RA));
	sinRA = float(sin(RA));
	OneMinusCosRA = 1.0f - cosRA;

	// Got this one off the net!
	RotateL.Set(cosRA + UA.x * UA.x * OneMinusCosRA,
		-UA.z * sinRA + UA.x * UA.y * OneMinusCosRA,
		UA.y * sinRA + UA.x * UA.z * OneMinusCosRA);
	RotateU.Set(UA.z * sinRA + UA.y * UA.x * OneMinusCosRA,
		cosRA + UA.y * UA.y * OneMinusCosRA,
		-UA.x * sinRA + UA.y * UA.z * OneMinusCosRA);
	RotateF.Set(-UA.y * sinRA + UA.z * UA.x * OneMinusCosRA,
		UA.x * sinRA + UA.z * UA.y * OneMinusCosRA,
		cosRA + UA.z * UA.z * OneMinusCosRA);

	// This came out of the OpenGL manual knowing how the
	//   matrices are multiplied and what each element represents

	// Done this way to calculate all values before copying.
	//  If we did l.x =, l.y = etc. later calculations would be thrown
	// off
	SetAxes(
		l.x * RotateL.x + l.y * RotateU.x + l.z * RotateF.x,
		l.x * RotateL.y + l.y * RotateU.y + l.z * RotateF.y,
		l.x * RotateL.z + l.y * RotateU.z + l.z * RotateF.z,
		u.x * RotateL.x + u.y * RotateU.x + u.z * RotateF.x,
		u.x * RotateL.y + u.y * RotateU.y + u.z * RotateF.y,
		u.x * RotateL.z + u.y * RotateU.z + u.z * RotateF.z,
		f.x * RotateL.x + f.y * RotateU.x + f.z * RotateF.x,
		f.x * RotateL.y + f.y * RotateU.y + f.z * RotateF.y,
		f.x * RotateL.z + f.y * RotateU.z + f.z * RotateF.z);

	// After this is performed, decrement the normalization counter.
	CheckNormalize();
}

void Orient3d::SetAxes(float p_lx, float p_ly, float p_lz,
	float p_ux, float p_uy, float p_uz,
	float p_fx, float p_fy, float p_fz)
{
	l.x = p_lx;
	l.y = p_ly;
	l.z = p_lz;
	u.x = p_ux;
	u.y = p_uy;
	u.z = p_uz;
	f.x = p_fx;
	f.y = p_fy;
	f.z = p_fz;

}

Orient3d Orient3d::Interpolate(Orient3d &p_beginOrient, Orient3d &p_endOrient, float p_t, OrientInterpolationData *p_data, bool p_populateInterpolationData)
{
	// note: we are rotating to match up a primary vector, then a secondary rotation to match up the others.  I don't know if this is the best way currently.  Because if there is ANY
	//   way to get the solution using a single axis we should absolutely use that.
	// the problem with doing so is that determining the best rotation axis has to arrive at an angle that allows reaching the secondary result with another axis
	// what is here for now is godo enough, unless there is a need for more work - for example an orientation structure with an f vector that is at a 45 degree offset that has to swing
	//   around to an offset of 135, along a constant axis of f - u.  This routine may not result in that.  If a model needs to work that way, two joints may be preferred.

	// if p_data = nullptr, we need to calculate and use our own
	// if p_populateInterpolationData = true, p_data msut point to a structure we will populate

	Orient3d endOrient = p_endOrient;

	// basic rules:
	// t must be between 0.0 and 1.0
	// pt = p0 + (p1 - p0) * t
	// basic idea is to get the f vectors to tend towards each other, then one of the other two. Use the arbitrary rotate to accomplish this.
	// special case: if an axis is the exact opposite in the begin and end states, pick a direction to rotate - might depend on the orientation of the other vectors.
	Orient3d result;

	if (p_t < 0.0f)
		throw gcnew Exception("p_t must be at least 0.0");
	if (p_t > 1.0f)
		throw gcnew Exception("p_t must be no greater than 1.0");

	if (p_t == 0.0)
		return p_beginOrient;
	if (p_t == 1.0)
		return p_endOrient;

	// Calculate!

	OrientInterpolationData data; // Don't make static - it wouldn't be thread safe!
	if (p_data == nullptr || p_populateInterpolationData == true)
	{
		data.movementVector = p_endOrient.p - p_beginOrient.p;

		// find axis of largest rotation (between f's, u's or l's)
		char axisUsed = 'f';
		Vector3d longestAxis = p_beginOrient.f.CrossProd(p_endOrient.f);
		float longestAngle = -(p_beginOrient.f * p_endOrient.f) + 1.0f;
		// prevent errors on acos
		if (longestAngle < 0.0f)
			longestAngle = 0.0f;
		if (longestAngle > 2.0f)
			longestAngle = 2.0f;
		Vector3d tempAxis2 = p_beginOrient.u.CrossProd(p_endOrient.u);
		float tempAngle2 = -(p_beginOrient.u * p_endOrient.u) + 1.0f;
		// prevent errors on acos
		if (tempAngle2 < 0.0f)
			tempAngle2 = 0.0f;
		if (tempAngle2 > 2.0f)
			tempAngle2 = 2.0f;
		if (tempAngle2 > longestAngle)
		{
			longestAxis = tempAxis2;
			longestAngle = tempAngle2;
			axisUsed = 'u';
		}
		tempAxis2 = p_beginOrient.l.CrossProd(p_endOrient.l);
		tempAngle2 = -(p_beginOrient.l * p_endOrient.l) + 1.0f;
		// prevent errors on acos
		if (tempAngle2 < 0.0f)
			tempAngle2 = 0.0f;
		if (tempAngle2 > 2.0f)
			tempAngle2 = 2.0f;
		if (tempAngle2 > longestAngle)
		{
			longestAxis = tempAxis2;
			longestAngle = tempAngle2;
			axisUsed = 'l';
		}

		// if axis is a zero vector, tempAngle is likely 2.0.  If it's zero, we're done - there is no work to do
		if (longestAxis.Magnitude() < 0.00001f && longestAngle < 0.0001f)
			data.degrees1 = 0.0f; // flag to ignore all work
		else if (longestAxis.Magnitude() < 0.00001f && longestAngle > 1.9999f)
		{
			// 180 degree spin on widest angle
			// the axis of rotation here is one of the others added together.  If that results in a zero vector, then just any of them and spin 180 degrees because the whole thing is flipped
			Vector3d axis1;
			switch (axisUsed)
			{
			case 'f':
				axis1 = p_beginOrient.u + p_endOrient.u;
				break;
			case 'u':
				axis1 = p_beginOrient.f + p_endOrient.f;
				break;
			case 'l':
				axis1 = p_beginOrient.f + p_endOrient.f;
				break;
			}
			if (axis1.Magnitude() < 0.0001f)
			{
				data.axis1 = p_beginOrient.u; // use 'u', spinning it 180 degrees will get f lined up
				data.degrees1 = 180.0f;
				axisUsed = 'f';
			}
			else
			{
				axis1.Normalize();
				data.axis1 = axis1;
				data.degrees1 = 180.0f;
			}
		}
		else
		{
			// convert axis and angle to usable data
			data.axis1 = longestAxis;
			data.axis1.Normalize();
			data.degrees1 = -MathUtilities::RadiansToDegrees(acos(-(longestAngle - 1.0f)));
		}

		if (data.degrees1 != 0.0f)
		{
			// there is usually a secondary rotation to finish the job, so perform that partial rotation next
			// axisUsed determines which axis will line up after degrees1 is fully applied, so it will be the rotation axis to finish the secondary

			Orient3d tempOrient = p_beginOrient;
			tempOrient.Rotate(data.axis1, data.degrees1);
			float angle;
			switch (axisUsed)
			{
			case 'f':
				data.axis2 = tempOrient.f;
				// get rotation on either l or u, doesn't matter
				angle = tempOrient.l * p_endOrient.l;
				// prevent errors on acos
				if (angle > 1.0f)
					angle = 1.0f;
				if (angle < -1.0f)
					angle = -1.0f;
				if (tempOrient.l.CrossProd(p_endOrient.l) * data.axis2 > 0.0f)
					data.degrees2 = -MathUtilities::RadiansToDegrees(acos(angle));
				else
					data.degrees2 = MathUtilities::RadiansToDegrees(acos(angle));
				break;
			case 'u':
				data.axis2 = tempOrient.u;
				// get rotation on either l or f, doesn't matter
				angle = tempOrient.l * p_endOrient.l;
				// prevent errors on acos
				if (angle > 1.0f)
					angle = 1.0f;
				if (angle < -1.0f)
					angle = -1.0f;
				if (tempOrient.l.CrossProd(p_endOrient.l) * data.axis2 > 0.0f)
					data.degrees2 = -MathUtilities::RadiansToDegrees(acos(angle));
				else
					data.degrees2 = MathUtilities::RadiansToDegrees(acos(angle));
				break;
			case 'l':
				data.axis2 = tempOrient.l;
				// get rotation on either f or u, doesn't matter
				angle = tempOrient.f * p_endOrient.f;
				// prevent errors on acos
				if (angle > 1.0f)
					angle = 1.0f;
				if (angle < -1.0f)
					angle = -1.0f;
				if (tempOrient.f.CrossProd(p_endOrient.f) * data.axis2 > 0.0f)
					data.degrees2 = -MathUtilities::RadiansToDegrees(acos(angle));
				else
					data.degrees2 = MathUtilities::RadiansToDegrees(acos(angle));
				break;
			}
		}
	}

	if (p_populateInterpolationData == true)
	{
		if (p_data == nullptr)
			throw gcnew Exception("p_popualteInterpolationData requires a p_data pointer to populate");

		*p_data = data;
	}

	// now spin the orientation
	// start with the primary rotation axis that would get you from begin to end, then use secondary to finish

	// use structure sent
	if (p_data != nullptr)
	{
		result = p_beginOrient;
		result.p = p_beginOrient.p + p_data->movementVector.ScalarMult(p_t);
		if (p_data->degrees1 == 0.0f)
			// ignore all
			return p_beginOrient;

		result.Rotate(p_data->axis1, p_data->degrees1 * p_t);

		if (p_data->degrees2 == 0.0f)
			// ignore the rest
			return result;

		result.Rotate(p_data->axis2, p_data->degrees2 * p_t);
	}
	else // use the structure we populated
	{
		result = p_beginOrient;
		result.p = p_beginOrient.p + data.movementVector.ScalarMult(p_t);
		if (data.degrees1 == 0.0f)
			// ignore all
			return result;

		result.Rotate(data.axis1, data.degrees1 * p_t);

		if (data.degrees2 == 0.0f)
			// ignore the rest
			return result;

		result.Rotate(data.axis2, data.degrees2 * p_t);
	}

	return result;
}

Vector3d Orient3d::TransformToOrientSpace(Vector3d &p_vertex)
{
	Vector3d offset = p_vertex - p;
	return Vector3d(offset * l, offset * u, offset * f);
}

Vector3d Orient3d::TransformToWorldSpace(Vector3d &p_vertex)
{
	// include p
	return Vector3d(p + l.ScalarMult(p_vertex.x) + u.ScalarMult(p_vertex.y) + f.ScalarMult(p_vertex.z));
}

Vector3d Orient3d::TransformToWorldSpaceOffset(Vector3d &p_vertex)
{
	// don't include p
	return Vector3d(l.ScalarMult(p_vertex.x) + u.ScalarMult(p_vertex.y) + f.ScalarMult(p_vertex.z));
}

Matrix4d Orient3d::ConvertToMatrix4d()
{
	// beware of what this does to DirectX.  This works for OpenGL (it matches what happens when a matrix is built to transform an Orient3d)
	// this may need to change to a facade for the Graphics class.  But then even the matrix multiplication could be wrong.  Testing with DirectX will reveal this.
	Matrix4d mat(
		l.x, u.x, f.x, p.x,
		l.y, u.y, f.y, p.y,
		l.z, u.z, f.z, p.z,
		0.0f, 0.0f, 0.0f, 1.0f
		);
	return mat;
}

Orient3d Orient3d::TransformToSameSpace(Orient3d &p_orient, float p_positionScale)
{
	// Given p_orient which is in this orient's space, transform it to the same space this orient is in
	Orient3d result;
	result.p = p + (l.ScalarMult(p_orient.p.x) + u.ScalarMult(p_orient.p.y) + f.ScalarMult(p_orient.p.z)).ScalarMult(p_positionScale);
	result.l = l.ScalarMult(p_orient.l.x) + u.ScalarMult(p_orient.l.y) + f.ScalarMult(p_orient.l.z);
	result.u = l.ScalarMult(p_orient.u.x) + u.ScalarMult(p_orient.u.y) + f.ScalarMult(p_orient.u.z);
	result.f = l.ScalarMult(p_orient.f.x) + u.ScalarMult(p_orient.f.y) + f.ScalarMult(p_orient.f.z);

	return result;
}

Orient3d Orient3d::ScaleAxes(float p_scale)
{
	Orient3d result;
	result.p = p;
	result.l = l.ScalarMult(p_scale);
	result.u = u.ScalarMult(p_scale);
	result.f = f.ScalarMult(p_scale);
	return result;
}

Orient3d Orient3d::ReflectThroughPlane(Vector3d &p_planePoint, Vector3d &p_planeNormal)
{
	Orient3d result;
	result.p = p - p_planeNormal.ScalarMult(2.0f * ((p - p_planePoint) * p_planeNormal));
	result.l = l - p_planeNormal.ScalarMult(2.0f * (l * p_planeNormal));
	result.u = u - p_planeNormal.ScalarMult(2.0f * (u * p_planeNormal));
	result.f = f - p_planeNormal.ScalarMult(2.0f * (f * p_planeNormal));

	return result;
}

Matrix4d Orient3d::MakeMatrix()
{
	// makes a matrix good for OpenGL (DirectX matrixes are transposed)
	Matrix4d result;

	// bottom row
	result.m41 = 0;
	result.m42 = 0;
	result.m43 = 0;
	result.m44 = 1;

	// now store l, u, f, p
	// m11, m12, m13 and m14 are the top elements of columns - see Matrix4d class
	CopyMemory(&result.m11, &l, 12);
	CopyMemory(&result.m12, &u, 12);
	CopyMemory(&result.m13, &f, 12);
	CopyMemory(&result.m14, &p, 12);

	return result;
}

Matrix4d Orient3d::MakeInverseMatrix()
{
	// makes a matrix good for OpenGL (DirectX matrixes are transposed)
	Matrix4d result;

	// bottom row
	result.m41 = 0;
	result.m42 = 0;
	result.m43 = 0;
	result.m44 = 1;

	// transpose the upper left 3x3 (they are unit vectors, so no need to alter their values other than flipping them)
	result.m11 = l.x;
	result.m12 = l.y;
	result.m13 = l.z;
	result.m21 = u.x;
	result.m22 = u.y;
	result.m23 = u.z;
	result.m31 = f.x;
	result.m32 = f.y;
	result.m33 = f.z;

	result.m14 = -result.m11 * p.x - result.m12 * p.y - result.m13 * p.z;
	result.m24 = -result.m21 * p.x - result.m22 * p.y - result.m23 * p.z;
	result.m34 = -result.m31 * p.x - result.m32 * p.y - result.m33 * p.z;

	return result;
}

void Orient3d::InitializeNormalizationCounter()
{
	// do this whenever we know we are setting the orientation to a good set of values
	normalizeCounter = NextNormalizeCounter++;
	if (NextNormalizeCounter > ORIENT3D_NORMALIZECOUNTERMAXVALUE)
		NextNormalizeCounter = 1;
}

void Orient3d::CheckNormalize()
{
	normalizeCounter--;
	if (normalizeCounter == 0)
	{
		Normalize();
		normalizeCounter = ORIENT3D_NORMALIZECOUNTERMAXVALUE;
	}
}

void Orient3d::Normalize()
{
	// force orient3d structure to follow the rules accurately (axis vectors all length 1.0, all orthogonal to each other)
	// over time, rotations can cause the vectors to no longer be length 1.0 and orthogonal to each other within reasonable tolerance
	f = l.CrossProd(u);
	if (f.Normalize() == false)
		throw gcnew Exception("Failed to normalize f");
	if (l.Normalize() == false)
		throw gcnew Exception("Failed to normalize l");
	u = f.CrossProd(l);
}
