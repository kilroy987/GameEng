#include "..\Headers\GameFont.h"

using namespace GameEng::Graphics;
using namespace GameEng::Storage;

LinkedList<GameRichText> LinkedList<GameRichText>::DeletedList("Deleted list for GameRichText");
LinkedList<GameLinedRichText> LinkedList<GameLinedRichText>::DeletedList("Deleted list for GameLinedRichText");
