#include "..\Headers\Vector.h"
#include "..\Headers\MathConstants.h"

using namespace GameEng::Math;

Vector2d::Vector2d()
{

}

Vector2d::Vector2d(Vector2d &p_vector2d)
{
	x = p_vector2d.x;
	y = p_vector2d.y;
}

Vector2d::Vector2d(float p_x, float p_y)
{
	x = p_x;
	y = p_y;
}

Vector2d Vector2d::ZeroVector()
{
	Vector2d zeroVector(0, 0); // method is static - this isn't.  Returns a value - DO NOT RETURN a reference here!
	// All returned vectors from this method must be unique instances!

	return zeroVector;
}

Vector2d Vector2d::Vector(float p_x, float p_y)
{
	Vector2d vector(p_x, p_y); // method is static - this isn't.  Returns a value - DO NOT RETURN a reference here!
	// All returned vectors from this method must be unique instances!

	return vector;
}

Vector2d Vector2d::operator + (const Vector2d &p_vector)
{
	return Vector2d(x + p_vector.x, y + p_vector.y);
}

Vector2d Vector2d::operator - (const Vector2d &p_vector)
{
	return Vector2d(x - p_vector.x, y - p_vector.y);
}

float Vector2d::operator * (const Vector2d &p_vector)
{
	return x * p_vector.x + y * p_vector.y;
}

Vector2d Vector2d::ScalarMult(float p_factor)
{
	return Vector2d(p_factor * x, p_factor * y);
}

// if both vectors are unit length 1.0, this returns the sin of the angle between them
float Vector2d::CrossProd(Vector2d &p_vector)
{
	return (x * p_vector.y) - (y * p_vector.x);
}

bool Vector2d::Normalize()
{
	float length = Magnitude();
	if (abs(length) > 0.00001f)
	{
		x = x / length;
		y = y / length;
		return true;
	}
	else
		return false;
}

float Vector2d::Magnitude()
{
	return sqrt(x*x + y*y);
}

float Vector2d::MagnitudeSquared()
{
	return x*x + y*y;
}

void Vector2d::Set(Vector2d &p_vector)
{
	x = p_vector.x;
	y = p_vector.y;
}

void Vector2d::Set(float p_x, float p_y)
{
	x = p_x;
	y = p_y;
}

bool Vector2d::Equals(Vector2d &p_vector)
{
	if ((x != p_vector.x) || (y != p_vector.y))
		return false;

	return true;
}

// Vector 3d
Vector3d::Vector3d()
{

}

Vector3d::Vector3d(Vector3d &p_vector3d)
{
	x = p_vector3d.x;
	y = p_vector3d.y;
	z = p_vector3d.z;
}

Vector3d::Vector3d(float p_x, float p_y, float p_z)
{
	x = p_x;
	y = p_y;
	z = p_z;
}

Vector3d Vector3d::ZeroVector()
{
	Vector3d zeroVector(0, 0, 0); // method is static - this isn't.  Returns a value - DO NOT RETURN a reference here!
	// All returned vectors from this method must be unique instances!

	return zeroVector;
}

Vector3d Vector3d::Vector(float p_x, float p_y, float p_z)
{
	Vector3d vector(p_x, p_y, p_z); // method is static - this isn't.  Returns a value - DO NOT RETURN a reference here!
	// All returned vectors from this method must be unique instances!

	return vector;
}

Vector3d Vector3d::operator + (const Vector3d &p_vector)
{
	return Vector3d(x + p_vector.x, y + p_vector.y, z + p_vector.z);
}

Vector3d Vector3d::operator - (const Vector3d &p_vector)
{
	return Vector3d(x - p_vector.x, y - p_vector.y, z - p_vector.z);
}

float Vector3d::operator * (const Vector3d &p_vector)
{
	return x * p_vector.x + y * p_vector.y + z * p_vector.z;
}

Vector3d Vector3d::ScalarMult(float p_factor)
{
	return Vector3d(p_factor * x, p_factor * y, p_factor * z);
}

// if both vectors are unit length 1.0, this returns the sin of the angle between them
Vector3d Vector3d::CrossProd(Vector3d &p_vector)
{
	return Vector(
		y*p_vector.z - z*p_vector.y,
		z*p_vector.x - x*p_vector.z,
		x*p_vector.y - y*p_vector.x
		);
}

bool Vector3d::Normalize()
{
	float length = Magnitude();
	if (abs(length) > 0.00001f)
	{
		x = x / length;
		y = y / length;
		z = z / length;
		return true;
	}
	else
		return false;
}

float Vector3d::Magnitude()
{
	return sqrt(x*x + y*y + z*z);
}

float Vector3d::MagnitudeSquared()
{
	return x*x + y*y  + z*z;
}

void Vector3d::Set(Vector3d &p_vector)
{
	x = p_vector.x;
	y = p_vector.y;
	z = p_vector.z;
}

void Vector3d::Set(float p_x, float p_y, float p_z)
{
	x = p_x;
	y = p_y;
	z = p_z;
}

bool Vector3d::Equals(Vector3d &p_vector)
{
	if ((x != p_vector.x) || (y != p_vector.y) || (z != p_vector.z))
		return false;

	return true;
}

// if the rotation vector is pointing right at you and the degrees are positive, the spin is clockwise.
void Vector3d::Rotate(Vector3d &p_rotationAxis, float p_degrees, bool p_axisIsUnitLength) // p_axisIsUnitLength is default in declaration to true
{
	// Rotate on an arbitary vector in the world space that the orient3d is in
	// This affects the orientation only, not the position
	Vector3d UA;     //Unit axis
	Vector3d RotateL;
	Vector3d RotateU;
	Vector3d RotateF;
	float RA;            //radian angle
	float cosRA, sinRA, OneMinusCosRA;

	// if degrees = 0.0f, do nothing.
	if (p_degrees == 0.0f || p_degrees == -0.0f)
		return;

	// Unitize the incoming axis
	UA.Set(p_rotationAxis.x, p_rotationAxis.y, p_rotationAxis.z);

	RA = MathUtilities::DegreesToRadians(p_degrees);

	if (p_axisIsUnitLength == false)
		if (!UA.Normalize())
			throw gcnew System::Exception("Unable to normalize rotation vector");

	cosRA = float(cos(RA));
	sinRA = float(sin(RA));
	OneMinusCosRA = 1.0f - cosRA;

	// Got this one off the net!
	RotateL.Set(cosRA + UA.x * UA.x * OneMinusCosRA,
		-UA.z * sinRA + UA.x * UA.y * OneMinusCosRA,
		UA.y * sinRA + UA.x * UA.z * OneMinusCosRA);
	RotateU.Set(UA.z * sinRA + UA.y * UA.x * OneMinusCosRA,
		cosRA + UA.y * UA.y * OneMinusCosRA,
		-UA.x * sinRA + UA.y * UA.z * OneMinusCosRA);
	RotateF.Set(-UA.y * sinRA + UA.z * UA.x * OneMinusCosRA,
		UA.x * sinRA + UA.z * UA.y * OneMinusCosRA,
		cosRA + UA.z * UA.z * OneMinusCosRA);

	// This came out of the OpenGL manual knowing how the
	//   matrices are multiplied and what each element represents

	// Done this way to calculate all values before copying.
	//  If we did l.x =, l.y = etc. later calculations would be thrown
	// off
	Set(
		x * RotateL.x + y * RotateU.x + z * RotateF.x,
		x * RotateL.y + y * RotateU.y + z * RotateF.y,
		x * RotateL.z + y * RotateU.z + z * RotateF.z);
}

Vector3d Vector3d::Interpolate(Vector3d &p_start, Vector3d &p_end, float factor)
{
	return p_start + (p_end - p_start).ScalarMult(factor);
}


////////////////
// Vector 4d
Vector4d::Vector4d()
{
}

Vector4d::Vector4d(Vector4d &p_vector4d)
{
	x = p_vector4d.x;
	y = p_vector4d.y;
	z = p_vector4d.z;
	w = p_vector4d.w;
}

Vector4d::Vector4d(float p_x, float p_y, float p_z, float p_w)
{
	x = p_x;
	y = p_y;
	z = p_z;
	w = p_w;
}

Vector4d::Vector4d(Vector3d &p_vector3d, float p_w)
{
	x = p_vector3d.x;
	y = p_vector3d.y;
	z = p_vector3d.z;
	w = p_w;
}

void Vector4d::Set(float p_x, float p_y, float p_z, float p_w)
{
	x = p_x;
	y = p_y;
	z = p_z;
	w = p_w;
}

Vector4d Vector4d::ScalarMult(float p_scalar)
{
	Vector4d result;
	result.x = x * p_scalar;
	result.y = y * p_scalar;
	result.z = z * p_scalar;
	result.w = w * p_scalar;
	return result;
}

bool Vector4d::Equals(Vector4d &p_vector)
{
	if (x != p_vector.x)
		return false;
	if (y != p_vector.y)
		return false;
	if (z != p_vector.z)
		return false;
	if (w != p_vector.w)
		return false;

	return true;
}

bool Vector4d::ApproximatelyEquals(Vector4d &p_vector)
{
	float xFactor = x;
	if (abs(p_vector.x) > abs(x))
		xFactor = p_vector.x;
	if (abs(xFactor) < 1.0f)
		xFactor = 1.0f;
	float yFactor = y;
	if (abs(p_vector.y) > abs(y))
		yFactor = p_vector.y;
	if (abs(yFactor) < 1.0f)
		yFactor = 1.0f;
	float zFactor = z;
	if (abs(p_vector.z) > abs(z))
		zFactor = p_vector.z;
	if (abs(zFactor) < 1.0f)
		zFactor = 1.0f;
	float wFactor = y;
	if (abs(p_vector.w) > abs(w))
		wFactor = p_vector.w;
	if (abs(wFactor) < 1.0f)
		wFactor = 1.0f;

	if (abs(x - p_vector.x) / xFactor > 0.05f)
		return false;
	if (abs(y - p_vector.y) / yFactor > 0.05f)
		return false;
	if (abs(z - p_vector.z) / zFactor > 0.05f)
		return false;
	if (abs(w - p_vector.w) / wFactor > 0.05f)
		return false;

	return true;
}
