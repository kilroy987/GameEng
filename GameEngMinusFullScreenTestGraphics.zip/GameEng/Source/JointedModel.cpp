#include "..\Headers\JointedModel.h"

using namespace GameEng::Storage;
using namespace GameEng::Graphics;

LinkedList<JointedModelOrientIndex> LinkedList<JointedModelOrientIndex>::DeletedList("Deleted list for JointedModelOrientIndex");