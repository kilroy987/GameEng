#include "..\Headers\GameContext.h"
#include "..\Headers\GameNetwork.h"

// link winsock library
#pragma comment (lib, "ws2_32.lib") // prevents the need for adding ws2_32.lib to the import list in build linker, yay!

using namespace GameEng::Storage;
using namespace GameEng::Network;
using namespace GameEng::Game;

LinkedList<GameNetworkPacket> LinkedList<GameNetworkPacket>::DeletedList("Deleted List for GameNetworkPacket");
LinkedList<GameNetworkBandwidthTracking> LinkedList<GameNetworkBandwidthTracking>::DeletedList("Deleted List for GameNetworkBandwidthTracking");
LinkedList<GameNetworkPlayerNode> LinkedList<GameNetworkPlayerNode>::DeletedList("Deleted List for GameNetworkPlayerNode");

// here so that GameContext is well formed
void GameNetworkPacketQueue::SendPacket()
{
	if (IsEmpty() == false)
	{
		if (GameContext::Instance->GetNetwork()->IsClient())
		{
			switch (sendType)
			{
			case GameNetworkPacketSendType::Now:
				GameContext::Instance->GetNetwork()->SendToServerNow((char *)&queuePacket, queuePacket.length, flags);
				break;
			case GameNetworkPacketSendType::Send:
				GameContext::Instance->GetNetwork()->SendToServer((char *)&queuePacket, queuePacket.length, flags, channel);
				break;
			case GameNetworkPacketSendType::Guaranteed:
				GameContext::Instance->GetNetwork()->SendToServerGuaranteed((char *)&queuePacket, queuePacket.length, flags, channel);
				break;
			}
		}
		else if (GameContext::Instance->GetNetwork()->IsServer())
		{
			if (onlyClientId != -1)
			{
				GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByClientId(onlyClientId);
				if (client != nullptr)
				{
					switch (sendType)
					{
					case GameNetworkPacketSendType::Now:
						GameContext::Instance->GetNetwork()->SendToClientNow(client, (char *)&queuePacket, queuePacket.length, flags);
						break;
					case GameNetworkPacketSendType::Send:
						GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&queuePacket, queuePacket.length, flags, channel);
						break;
					case GameNetworkPacketSendType::Guaranteed:
						GameContext::Instance->GetNetwork()->SendToClientGuaranteed(client, (char *)&queuePacket, queuePacket.length, flags, channel);
						break;
					}
				}
			}
			else
			{
				switch (sendType)
				{
				case GameNetworkPacketSendType::Now:
					GameContext::Instance->GetNetwork()->SendToAllClientsNow((char *)&queuePacket, queuePacket.length, flags, excludedClientId);
					break;
				case GameNetworkPacketSendType::Send:
					GameContext::Instance->GetNetwork()->SendToAllClients((char *)&queuePacket, queuePacket.length, flags, channel, excludedClientId);
					break;
				case GameNetworkPacketSendType::Guaranteed:
					GameContext::Instance->GetNetwork()->SendToAllClientsGuaranteed((char *)&queuePacket, queuePacket.length, flags, channel, excludedClientId);
					break;
				}
			}
		}

		Clear();
	} // not empty
}

// overrides
void GameNetworkBase::OnInitializationFailed(int p_version, int p_subVersion)
{
	NetworkMessage(GameNetworkMessageType::Error, String::Format("Initialization Failed for Winsock {0}.{1}", p_version, p_subVersion));
}

void GameNetworkBase::OnHostSuccess()
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Host Success, supporting {0} clients", GetClientQty()));
}

void GameNetworkBase::OnHostFailure(String ^p_reason)
{
	NetworkMessage(GameNetworkMessageType::Error, "Host Failure - " + p_reason);
}

void GameNetworkBase::OnClientConnect(int p_slotsRemaining, int p_maxSlots)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Client Connected ({0:g}/{1:g} slots left)", p_slotsRemaining, p_maxSlots));
}

void GameNetworkBase::OnClientRejectedNoAvailableSlot()
{
	NetworkMessage(GameNetworkMessageType::Info, "Client Rejected - no slots");
}

void GameNetworkBase::OnClientLogin(GameNetworkClient &p_client)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Client '{0}' (ID={1:g}) Logged in", GameNetworkPacketHelper::CharArrayToString(p_client.name), p_client.id));
}

void GameNetworkBase::OnClientRejectedBadLogin(GameNetworkClient &p_client)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Client '{0}' Bad Login", GameNetworkPacketHelper::CharArrayToString(p_client.name)));
}

void GameNetworkBase::OnPendingClientTimingOut(GameNetworkClient &p_client, int p_timeOutQty, int p_maxTimeouts)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Pending Client ID {0} Timing Out ({1:g}/{2:g})", p_client.id, p_timeOutQty, p_maxTimeouts));
}

void GameNetworkBase::OnPendingClientTimedOut(GameNetworkClient &p_client)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Pending Client ID {0} Timed Out", p_client.id));
}

void GameNetworkBase::OnPendingClientNoLongerTimingOut(GameNetworkClient &p_client)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Pending Client ID {0} Timed Out", p_client.id));
}

void GameNetworkBase::OnPendingClientLeft(GameNetworkClient &p_client)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Pending Client ID {0} Left", p_client.id));
}

void GameNetworkBase::OnConnectSuccess()
{
	NetworkMessage(GameNetworkMessageType::Info, "Connect Success");
}

void GameNetworkBase::OnJoined()
{
	NetworkMessage(GameNetworkMessageType::Info, "Joined");
}

void GameNetworkBase::OnConnectFailure(String ^p_reason)
{
	NetworkMessage(GameNetworkMessageType::Error, "Connect Failure - " + p_reason);
}

void GameNetworkBase::OnConnectingPreProcess(String ^p_message)
{
	NetworkMessage(GameNetworkMessageType::Info, p_message);

	// display the information since gethostbyname() can freeze the process, as can a blocking connect()
	GameContext::Instance->GetGame()->BlockRender();
}

bool GameNetworkBase::OnConnectingContinue()
{
	return true;
}

void GameNetworkBase::OnConnectingCanceled()
{
}

void GameNetworkBase::OnConnectingPostProcess()
{
}

void GameNetworkBase::OnSocketNotReady()
{
	NetworkMessage(GameNetworkMessageType::Info, "Socket Not Ready");
}

void GameNetworkBase::OnSocketReady()
{
	NetworkMessage(GameNetworkMessageType::Info, "Socket Ready");
}

void GameNetworkBase::OnBadClientPacketReceived(GameNetworkClient &p_client, String ^p_error)
{
	String ^message = "Bad Packet Received";
	if (p_client.status == NetworkClientStatus::Pending)
		message += " from pending client";
	else
		message += String::Format(" from client '{0}'", GameNetworkPacketHelper::CharArrayToString(p_client.name));
	if (p_error != "")
		message += " - " + p_error;

	NetworkMessage(GameNetworkMessageType::Info, message);
}

void GameNetworkBase::OnBadUDPPacketReceived(String ^p_error)
{
	String ^message = "Bad UDP Packet Received";
	if (p_error != "")
		message += " - " + p_error;

	NetworkMessage(GameNetworkMessageType::Info, message);
}

void GameNetworkBase::OnBadServerPacketReceived(String ^p_error)
{
	String ^message = "Bad Packet Received";
	message += String::Format(" from Server");
	if (p_error != "")
		message += " - " + p_error;

	NetworkMessage(GameNetworkMessageType::Info, message);
}

void GameNetworkBase::OnDisconnect(String ^p_reason)
{
	NetworkMessage(GameNetworkMessageType::Disconnect, "Disconnected - " + p_reason);
}

void GameNetworkBase::OnServerTimingOut(int p_timeOutQty, int p_maxTimeouts)
{
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Server Timing Out ({0:g}/{1:g})", p_timeOutQty, p_maxTimeouts));
}

void GameNetworkBase::OnServerTimedOut()
{
	NetworkMessage(GameNetworkMessageType::Info, "Server Timed Out");
}

void GameNetworkBase::OnServerNoLongerTimingOut()
{
	NetworkMessage(GameNetworkMessageType::Info, "Server No Longer Timing Out");
}

void GameNetworkBase::OnClientReconnect(GameNetworkClient &p_client)
{
	NetworkMessage(GameNetworkMessageType::Info, "Client Reconnected");
}

void GameNetworkBase::OnNetworkClosed()
{
	NetworkMessage(GameNetworkMessageType::Info, "Network Closed");
}

void GameNetworkBase::OnKeepaliveSent(int p_keepaliveQty)
{
	if (server == true)
	{
		if (p_keepaliveQty == 1)
			NetworkMessage(GameNetworkMessageType::Info, "Keepalive sent to client");
		else
			NetworkMessage(GameNetworkMessageType::Info, "Keepalives sent to clients");
	}
	else
	{
		// no reason for keepalives sent to be > 1 on a client
		NetworkMessage(GameNetworkMessageType::Info, "Keepalive sent to server");
	}
}

void GameNetworkBase::OnKeepaliveReceived(GameNetworkClient *p_client)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Keepalive received from client '{0}'", GameNetworkPacketHelper::CharArrayToString(p_client->name)));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Keepalive received from server"));
}

void GameNetworkBase::OnWakeupSent(GameNetworkClient *p_client)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Wakeup sent to client '{0}'", GameNetworkPacketHelper::CharArrayToString(p_client->name)));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Wakeup sent to server"));
}

void GameNetworkBase::OnWakeupReceived(GameNetworkClient *p_client)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Wakeup received from client '{0}'", GameNetworkPacketHelper::CharArrayToString(p_client->name)));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Wakeup received from server"));
}

void GameNetworkBase::OnIAmAwakeSent(GameNetworkClient *p_client)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("IAmAwake sent to client '{0}'", GameNetworkPacketHelper::CharArrayToString(p_client->name)));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("IAmAwake send to server"));
}

void GameNetworkBase::OnIAmAwakeReceived(GameNetworkClient *p_client)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("IAmAwake received from client '{0}'", GameNetworkPacketHelper::CharArrayToString(p_client->name)));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("IAmAwake received from server"));
}

void GameNetworkBase::OnGuaranteedPacketSent(GameNetworkClient *p_client, int p_confirmationId, int p_channel)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Guaranteed Packet sent to client '{0}' - confirm id {1:g}, channel {2:g}", GameNetworkPacketHelper::CharArrayToString(p_client->name), p_confirmationId, p_channel));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Guaranteed Packet sent to server - confirm id {0:g}, channel {1:g}", p_confirmationId, p_channel));
}

void GameNetworkBase::OnGuaranteedPacketReSent(GameNetworkClient *p_client, int p_confirmationId, int p_channel)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Guaranteed Packet resent to client '{0}' - confirm id {1:g}, channel {2:g}", GameNetworkPacketHelper::CharArrayToString(p_client->name), p_confirmationId, p_channel));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Guaranteed Packet resent to server - confirm id {0:g}, channel {1:g}", p_confirmationId, p_channel));
}

void GameNetworkBase::OnGuaranteedPacketReceived(GameNetworkClient *p_client, int p_confirmationId, int p_channel)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Guaranteed Packet received from client '{0}' - confirm id {1:g}, channel {2:g}", GameNetworkPacketHelper::CharArrayToString(p_client->name), p_confirmationId, p_channel));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Guaranteed Packet received from server - confirm id {0:g}, channel {1:g}", p_confirmationId, p_channel));
}

void GameNetworkBase::OnConfirmationIdSent(GameNetworkClient *p_client, int p_confirmationId, int p_channel)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Confirmation Id sent to client '{0}' - confirm id {1:g}, channel {2:g}", GameNetworkPacketHelper::CharArrayToString(p_client->name), p_confirmationId, p_channel));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Confirmation Id sent to server - confirm id {0:g}, channel {1:g}", p_confirmationId, p_channel));
}

void GameNetworkBase::OnConfirmationIdReceived(GameNetworkClient *p_client, int p_confirmationId, int p_channel)
{
	if (p_client != nullptr)
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Confirmation Id received from client '{0}' - confirm id {1:g}, channel {2:g}", GameNetworkPacketHelper::CharArrayToString(p_client->name), p_confirmationId, p_channel));
	else
		NetworkMessage(GameNetworkMessageType::Info, String::Format("Confirmation Id received from server - confirm id {0:g}, channel {1:g}", p_confirmationId, p_channel));
}

///////////

void GameNetworkBase::NetworkMessage(GameNetworkMessageType p_type, String ^p_message) 
{
	// override in implementation to get a result somewhere
}

///////////

void GameNetworkBase::CustomProcess(int p_elapsedTimeMS)
{

}

bool GameNetworkBase::CustomValidatePacket(char *p_packet, int p_type)
{
	return false;
}

///////////
// players

GameNetworkPlayerBase * GameNetworkBase::CreatePlayer()
{
	return new GameNetworkPlayerBase();
}

GameNetworkPlayerBase * GameNetworkBase::ServerAddPlayer(GameNetworkClient &p_client, bool p_server, bool p_host)
{
	// client can be the localUser structure, which would be the host data.
	// implementation should perform extra maintenance and add extra information to the player in preparation for sending its information to the other clients

	// Do NOT destroy this pointer!  list will handle it.
	GameNetworkPlayerBase *newPlayer = CreatePlayer();
	newPlayer->id = p_client.id;
	strcpy_s(newPlayer->name, 33, p_client.name);
	newPlayer->server = p_server;
	newPlayer->host = p_host;

	players.AddPlayer(newPlayer);
	return newPlayer;
}

void GameNetworkBase::SendAddPlayerPacket(GameNetworkPlayerBase *p_player, GameNetworkClient *p_destinationClient) // when player joins
{
	NetworkAddPlayerPacketBase addPlayerPacket;
	if (p_destinationClient == nullptr)
	{
		// send to existing clients with echo
		GameNetworkPacketHelper::PopulateAddPlayerPacket(addPlayerPacket, p_player, true);

		// send to all except the joiner
		SendToAllClients((char *)&addPlayerPacket, addPlayerPacket.length, 0, 0, p_player->id);
	}
	else
	{
		// loop through all players and send their information to the new player
		LinkedListEnumerator<GameNetworkPlayerNode> playerEnum = players.GetEnumerator();
		while (playerEnum.MoveNext())
		{
			GameNetworkPlayerBase *player = playerEnum.Current()->data.player;
			GameNetworkPacketHelper::PopulateAddPlayerPacket(addPlayerPacket, player, false);
			SendToClient(p_destinationClient, (char *)&addPlayerPacket, addPlayerPacket.length, 0);
		}
	}
}

bool GameNetworkBase::ValidateAddPlayerPacket(NetworkAddPlayerPacketBase *p_packet)
{
	if (p_packet->id < 0)
		return false;
	int nameLength = strlen(p_packet->name);
	if (nameLength > 32)
		return false;
	if (p_packet->length != 49 + nameLength)
		return false;

	return true;
}

void GameNetworkBase::ClientAddPlayer(NetworkAddPlayerPacketBase *p_packet) // client adding player
{
	// implementation is expected to handle all of this and everything else in its version of NetworkAddPlayerPacketBase

	// do NOT deallocate this point!  list will take care of it!
	GameNetworkPlayerBase *newPlayer = CreatePlayer();
	newPlayer->id = p_packet->id;
	strcpy_s(newPlayer->name, 33, p_packet->name);
	newPlayer->server = p_packet->server;
	newPlayer->host = p_packet->host;
	players.AddPlayer(newPlayer);
}

void GameNetworkBase::OnPlayerJoined(int p_id)
{
	GameNetworkPlayerBasePtr player = players.GetPlayer(p_id);
	if (player == nullptr)
		throw gcnew Exception("player not found!");
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Player '{0}' Joined", GameNetworkPacketHelper::CharArrayToString(player->name)));
}

void GameNetworkBase::OnPlayerLeft(int p_id, bool p_echo)
{
	GameNetworkPlayerBasePtr player = players.GetPlayer(p_id);
	if (player != nullptr)
	{
		if (p_echo == true)
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Player '{0}' Left", GameNetworkPacketHelper::CharArrayToString(player->name)));
	}
}

void GameNetworkBase::OnPlayerTimingOut(int p_id, int p_timeOutQty, int p_maxTimeouts)
{
	GameNetworkPlayerBasePtr player = players.GetPlayer(p_id);
	if (player == nullptr)
		throw gcnew Exception("player not found!");
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Player '{0}' Timing Out {1}/{2}", GameNetworkPacketHelper::CharArrayToString(player->name), p_timeOutQty, p_maxTimeouts));
}

void GameNetworkBase::OnPlayerTimedOut(int p_id)
{
	GameNetworkPlayerBasePtr player = players.GetPlayer(p_id);
	if (player == nullptr)
		throw gcnew Exception("player not found!");
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Player '{0}' Timed Out", GameNetworkPacketHelper::CharArrayToString(player->name)));
}

void GameNetworkBase::OnPlayerNoLongerTimingOut(int p_id)
{
	GameNetworkPlayerBasePtr player = players.GetPlayer(p_id);
	if (player == nullptr)
		throw gcnew Exception("player not found!");
	NetworkMessage(GameNetworkMessageType::Info, String::Format("Player '{0}' No Longer Timing Out", GameNetworkPacketHelper::CharArrayToString(player->name)));
}

//void GameNetworkBase::SendPlayerServerDataPacket() // server sending everyone player's updated server data
//{
//}
//
//void GameNetworkBase::PopulatePlayerServerDataPacket(char *p_packet, int p_playerId) // player sends to server, server sends to everyone else
//{
//}

//void GameNetworkBase::PopulatePlayerLocalDataPacket() // client calls this and sends to server, server echoes to everyone else
//{
//}
//
//void GameNetworkBase::ProcessPopulatePlayerLocalDataPacket(char *p_packet)
//{
//}
//
//void GameNetworkBase::ProcessPopulatePlayerServerDataPacket(char *p_packet)
//{
//}
//
//// both
//void GameNetworkBase::SendPlayerLocalDataPacket(int p_excludePlayerId) // player sends to server, server sends to everyone else
//{
//}