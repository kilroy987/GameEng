#include "..\Headers\GameBase.h"

using namespace GameEng::Game;
using namespace GameEng::Input;

LinkedList<GameInputEvent> LinkedList<GameInputEvent>::DeletedList("DeletedList for GameInputEvent");

void GameBase::KeyDown(int p_keyCode, bool p_shift, bool p_alt, bool p_ctrl)
{
	keyboardKeys.GetKey(p_keyCode)->SetPressed();
	keyboardKeys.GetKey(p_keyCode)->SetClicked();

	//inputEvents->AddEvent(GameInputEvent(GameInputEventType::KeyDown, p_keyCode,
	//	p_shift, p_alt, p_ctrl));

	// also, convert character to typed character (KeyPress)
	// we do KeyPress here because some controls that house the rendered game scene don't execute KeyPress.  So this routine just does its own that matters

	// check for keys we don't want Keypress for (they don't display meaningful text - note that Back(backspace) doesn't either, but it's a common key that sends data to a text field,
	//   so we are keeping it to be sent with KeyPress, for now.
	char result = p_keyCode;
	bool handled = false;
	switch (System::Windows::Forms::Keys(p_keyCode))
	{
	case System::Windows::Forms::Keys::ShiftKey:
	case System::Windows::Forms::Keys::ControlKey:
	case System::Windows::Forms::Keys::Menu:
	case System::Windows::Forms::Keys::CapsLock:
	case System::Windows::Forms::Keys::NumLock:
	case System::Windows::Forms::Keys::PrintScreen:
	case System::Windows::Forms::Keys::Print:
	case System::Windows::Forms::Keys::Scroll:
	case System::Windows::Forms::Keys::Insert:
	case System::Windows::Forms::Keys::Delete:
	case System::Windows::Forms::Keys::Home:
	case System::Windows::Forms::Keys::End:
	case System::Windows::Forms::Keys::PageUp:
	case System::Windows::Forms::Keys::PageDown:
	case System::Windows::Forms::Keys::LWin:
	case System::Windows::Forms::Keys::RWin:
	case System::Windows::Forms::Keys::Apps:
	case System::Windows::Forms::Keys::Left:
	case System::Windows::Forms::Keys::Right:
	case System::Windows::Forms::Keys::Up:
	case System::Windows::Forms::Keys::Down:
	case System::Windows::Forms::Keys::Pause:
	case System::Windows::Forms::Keys::Clear:
	case System::Windows::Forms::Keys::Escape:
	case System::Windows::Forms::Keys::F1:
	case System::Windows::Forms::Keys::F2:
	case System::Windows::Forms::Keys::F3:
	case System::Windows::Forms::Keys::F4:
	case System::Windows::Forms::Keys::F5:
	case System::Windows::Forms::Keys::F6:
	case System::Windows::Forms::Keys::F7:
	case System::Windows::Forms::Keys::F8:
	case System::Windows::Forms::Keys::F9:
	case System::Windows::Forms::Keys::F10:
	case System::Windows::Forms::Keys::F11:
	case System::Windows::Forms::Keys::F12:
	case System::Windows::Forms::Keys::F13:
	case System::Windows::Forms::Keys::F14:
	case System::Windows::Forms::Keys::F15:
	case System::Windows::Forms::Keys::F16:
	case System::Windows::Forms::Keys::F17:
	case System::Windows::Forms::Keys::F18:
	case System::Windows::Forms::Keys::F19:
	case System::Windows::Forms::Keys::F20:
	case System::Windows::Forms::Keys::F21:
	case System::Windows::Forms::Keys::F22:
	case System::Windows::Forms::Keys::F23:
	case System::Windows::Forms::Keys::F24:
		// don't do anything extra for these keys
		result = 0;
		handled = true;
		break;
	}
	// shift tab, too.  If I knew the Keys::enum, I'd list that above.
	// Actually not sure if we need this - Shift Tab wasn't responding on a run and I debugged to get this value, but now Shift Tab is working
	if (p_keyCode == 65545)
	{
		result = 0;
		handled = true;
	}

	if (handled == false)
	{
		if ((GetKeyState(VK_NUMLOCK) & 1) != 0)
		{
			// numpad keys that function differently depending on numlock (shift automatically fires a different key in windows)
			switch (System::Windows::Forms::Keys(p_keyCode))
			{
			case System::Windows::Forms::Keys::NumPad0:
				result = '0';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad1:
				result = '1';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad2:
				result = '2';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad3:
				result = '3';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad4:
				result = '4';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad5:
				result = '5';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad6:
				result = '6';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad7:
				result = '7';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad8:
				result = '8';
				handled = true;
				break;
			case System::Windows::Forms::Keys::NumPad9:
				result = '9';
				handled = true;
				break;
			case System::Windows::Forms::Keys::Decimal:
				result = '.';
				handled = true;
				break;
			}
		}
	}
	if (handled == false)
	{
		// numpad operator keys
		switch (System::Windows::Forms::Keys(p_keyCode))
		{
		case System::Windows::Forms::Keys::Divide:
			result = '/';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Multiply:
			result = '*';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Subtract:
			result = '-';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Add:
			result = '+';
			handled = true;
			break;
		}
	}
	if (handled == false)
	{
		// special oem keys on the qwerty keyboard
		switch (System::Windows::Forms::Keys(p_keyCode))
		{
		case System::Windows::Forms::Keys::Oemtilde:
			if (p_shift == false)
				result = '`';
			else
				result = '~';
			handled = true;
			break;
		case System::Windows::Forms::Keys::OemMinus:
			if (p_shift == false)
				result = '-';
			else
				result = '_';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Oemplus:
			if (p_shift == false)
				result = '=';
			else
				result = '+';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Oemcomma:
			if (p_shift == false)
				result = ',';
			else
				result = '<';
			handled = true;
			break;
		case System::Windows::Forms::Keys::OemPeriod:
			if (p_shift == false)
				result = '.';
			else
				result = '>';
			handled = true;
			break;
		case System::Windows::Forms::Keys::OemQuestion:
			if (p_shift == false)
				result = '/';
			else
				result = '?';
			handled = true;
			break;
		case System::Windows::Forms::Keys::OemOpenBrackets: // [{
			if (p_shift == false)
				result = '[';
			else
				result = '{';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Oem6: // ]}
			if (p_shift == false)
				result = ']';
			else
				result = '}';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Oem5: // \|
			if (p_shift == false)
				result = '\\';
			else
				result = '|';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Oem1: // ;:
			if (p_shift == false)
				result = ';';
			else
				result = ':';
			handled = true;
			break;
		case System::Windows::Forms::Keys::Oem7: // '"
			if (p_shift == false)
				result = '\'';
			else
				result = '"';
			handled = true;
			break;
		}
	}
	if (handled == false)
	{
		if (p_alt == false && p_ctrl == false)
		{
			handled = true;

			if (p_shift == false)
			{
				// lowercase!
				if (p_keyCode >= 'A' && p_keyCode <= 'Z' && (GetKeyState(VK_CAPITAL) & 1) == 0)
					result = p_keyCode + ('a' - 'A');
			}
			else
			{
				// uppercase!
				if (p_keyCode >= 'A' && p_keyCode <= 'Z')
				{
					// caps lock + shift = lower case
					if ((GetKeyState(VK_CAPITAL) & 1) != 0)
						result = p_keyCode + ('a' - 'A');
				}
				else if (p_keyCode >= '0' && p_keyCode <= '9')
				{
					switch (p_keyCode)
					{
					case '0':
						result = ')';
						break;
					case '1':
						result = '!';
							break;
					case '2':
						result = '@';
						break;
					case '3':
						result = '#';
						break;
					case '4':
						result = '$';
						break;
					case '5':
						result = '%';
						break;
					case '6':
						result = '^';
						break;
					case '7':
						result = '&';
						break;
					case '8':
						result = '*';
						break;
					case '9':
						result = '(';
						break;
					}
				}
				else if (p_keyCode == '`')
					result = '~';
				else if (p_keyCode == '-')
					result = '_';
				else if (p_keyCode == '=')
					result = '+';
				//else if (p_keyCode == '[') // handled with Oem keys above
				//	result = '{';
				//else if (p_keyCode == ']')
				//	result = '}';
				//else if (p_keyCode == '\\')
				//	result = '|';
				else if (p_keyCode == ',')
					result = '<';
				else if (p_keyCode == '.')
					result = '>';
				else if (p_keyCode == '/')
					result = '?';
			}
		}
	}

	if (handled == true && result != 0)
	{
		// keydown with keypressed
		inputEvents->AddEvent(GameInputEvent(GameInputEventType::KeyDown, p_keyCode,
			p_shift, p_alt, p_ctrl, result));
	}
	else
		// just a keydown
		inputEvents->AddEvent(GameInputEvent(GameInputEventType::KeyDown, p_keyCode,
			p_shift, p_alt, p_ctrl));

}

void GameBase::KeyUp(int p_keyCode, bool p_shift, bool p_alt, bool p_ctrl)
{
	keyboardKeys.GetKey(p_keyCode)->ClearPressed();
	keyboardKeys.GetKey(p_keyCode)->ClearClicked();

	inputEvents->AddEvent(GameInputEvent(GameInputEventType::KeyUp, p_keyCode,
		p_shift, p_alt, p_ctrl));
}

void GameBase::MouseMove(int p_x, int p_y)
{
	GameInputEvent mouseEvent(System::Drawing::Point(p_x, p_y));

	mouse.ApplyMouseEvent(mouseEvent);
	inputEvents->AddEvent(mouseEvent);
}

void GameBase::MouseButtonEvent(MouseButton p_button, bool p_down)
{
	GameInputEvent mouseEvent(p_button, p_down);

	mouse.ApplyMouseEvent(mouseEvent);
	inputEvents->AddEvent(mouseEvent);
}

void GameBase::MouseWheel(int p_delta)
{
	GameInputEvent mouseEvent(p_delta);

	mouse.ApplyMouseEvent(mouseEvent);
	inputEvents->AddEvent(mouseEvent);
}

// Overridden methods

void GameBase::ApplicationActivated()
{
}

void GameBase::ApplicationDeactivated()
{
}

void GameBase::Initialize()
{
	mouse.InitializeOffsets(); // don't apply offsets on first entry of mouse/mouse wheel
	joystick->Initialize();
}

bool GameBase::DoGameLoop()
{
	return false; // override, otherwise main game loop should abort
}

void GameBase::PerformRender()
{
}

void GameBase::BlockRender()
{
}

void GameBase::Destroy()
{
	if (joystick != nullptr)
	{
		delete joystick;
		joystick = nullptr;
	}
}

JoystickValues * GameBase::GetJoystickValues()
{
	return &(joystick->values);
}
