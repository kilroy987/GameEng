#include "..\Headers\GameInput.h"

using namespace GameEng::Input;

LPDIRECTINPUT8 GameJoystick::dInput = nullptr;
LPDIRECTINPUTDEVICE8 GameJoystick::joystickDevice = nullptr;

BOOL CALLBACK GameJoystick::EnumJoysticksCallback(const DIDEVICEINSTANCE* pdidInstance, VOID* pContext)
{
	HRESULT hr;

	// Obtain an interface to the enumerated joystick.
	hr = dInput->CreateDevice(pdidInstance->guidInstance, &joystickDevice, NULL);

	// If it failed, then we can't use this joystick. (Maybe the user unplugged
	// it while we were in the middle of enumerating it.)
	if (FAILED(hr)) {
		return DIENUM_CONTINUE;
	}

	// Stop enumeration. Note: we're just taking the first joystick we get. You
	// could store all the enumerated joysticks and let the user pick.
	return DIENUM_STOP;
}

BOOL CALLBACK GameJoystick::EnumAxesCallback(const DIDEVICEOBJECTINSTANCE* instance, VOID* context)
{
	DIPROPRANGE propRange;
	propRange.diph.dwSize = sizeof(DIPROPRANGE);
	propRange.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	propRange.diph.dwHow = DIPH_BYID;
	propRange.diph.dwObj = instance->dwType;
	propRange.lMin = -1000;
	propRange.lMax = +1000;

	// Set the range for the axis
	if (FAILED(joystickDevice->SetProperty(DIPROP_RANGE, &propRange.diph))) {
		return DIENUM_STOP;
	}

	return DIENUM_CONTINUE;
}