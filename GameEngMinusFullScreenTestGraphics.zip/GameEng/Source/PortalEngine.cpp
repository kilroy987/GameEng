#include "..\Headers\PortalEngine.h"

using namespace GameEng::PortalEngine;

LinkedList<PortalNodeIndex> LinkedList<PortalNodeIndex>::DeletedList("PortalNodeIndex");
LinkedList<PortalNodeIndexAndDistance> LinkedList<PortalNodeIndexAndDistance>::DeletedList("PortalNodeIndexAndDistance");
LinkedList<PortalMirrorAndDistance> LinkedList<PortalMirrorAndDistance>::DeletedList("PortalMirrorAndDistance");
LinkedList<PortalParseResult> LinkedList<PortalParseResult>::DeletedList("PortalParseResult");
#ifdef _DEBUG
LinkedList<FrustumPlaneNormalAndResult> LinkedList<FrustumPlaneNormalAndResult>::DeletedList("FrustumPlaneNormalAndResult");
LinkedList<FrustumPlaneNormal> LinkedList<FrustumPlaneNormal>::DeletedList("FrustumPlaneNormal");
#endif