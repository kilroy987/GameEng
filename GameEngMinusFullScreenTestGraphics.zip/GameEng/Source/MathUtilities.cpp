#include "..\Headers\MathConstants.h"

using namespace GameEng::Math;

bool MathUtilities::SpherePlaneCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_planePoint, Vector3d &p_planeUnitNormal, float &p_collisionT)
{
	// sphere starting at startPoint, travelling along travelVector (t = 0 to 1) of radius, colliding with plane having a point and normal
	// planeUnitNormal MUST be a unit vector, otherwise the radius calclation will be off.
	// todo: Normalize normal if it isn't already (can slow things down - this routine will be called a LOT - support boolean that informs if normal is unit or not)

	// if not travelling towards the collidable part of the surface (plane normal faces outward from it), no collision
	float travelVectorDotplanarNormal = p_travelVector * p_planeUnitNormal;
	if (travelVectorDotplanarNormal >= 0.0f)
		return false;

	// if entire path is beyond redius distance from plane, no collision
	if (((p_startPoint - p_planePoint) * p_planeUnitNormal) > p_radius && ((p_startPoint + p_travelVector - p_planePoint) * p_planeUnitNormal) > p_radius)
		return false;

	// ok, calculate it.
	p_collisionT = (p_radius + ((p_planePoint - p_startPoint) * p_planeUnitNormal)) / travelVectorDotplanarNormal;

	if (p_collisionT >= 0.0f && p_collisionT <= 1.0f)
		return true;
	else
		return false;
}

bool MathUtilities::SpherePlaneIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_planePoint, Vector3d &p_planeUnitNormal, float &p_distance)
{
	float distance = (p_centerPoint - p_planePoint) * p_planeUnitNormal;
	// should we return true if it's deeply inside or just truly intersecting?
	if (distance < p_radius)
	{
		p_distance = distance;
		return true;
	}
	else
		return false;
}

bool MathUtilities::SphereLineCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_linePoint, Vector3d &p_lineUnitVector, float &p_collisionT)
{
	// This routine is VERY expensive.  avoid whenever possible.
	// or try to speed it up

	// sphere starting at startpoint, travelling along travelVector (t = 0 to 1) of radius, colliding with line lying along a point with a unit vector
	// lineUnitVector MUST be a unit vector, otherwise the readius calculation will be off
	// todo: normalize unit vector if it isn't already (can slow things down - this routine can be called a lot - support boolean that informs if vector is unit or not)

	// find t's where sphere is distance r from line
	// derived from formula: |(p_startPoint + p_travelVector * t) - (p_linePoint + (((p_startPoint + p_travelVector * t - p_linePoint) * p_lineUnitVector) scalar p_lineUnitVector))| = radius
	// concept of formula: get point along sphere travel at time t.  Get its position in line space.  Get the distance from that point to the point calculated along the sphere's path
	// leads to multiple t's since the sphere can be radius distance away twice along its path (or never, or always if travelling parallel - the always condition is a failure
	//   since this routine is geared to find the FIRST occurrence of t where the distance = radius)
	// another possibility: (|(p_startPoint + p_travelVector * t - p_linePoint)|^2 - (p_startPoint + p_travelVector * t - p_linePoint) * p_lineUnitVector)^2) = radius^2
	// this formula gets the orthogonal distance from the line by taking the magnitude squared of the travel point from the point on the line minus the distance of its line space position from the point on the line.
	// it might be simpler.
	// take earliest t since we want the first collision.

	// problem with this methodology.  It's a lovely formula and in theory it SHOULD work (and some unit tests suggested it works), but sqrtAmount is negative sometimes when it shouldn't be, causing
	//  some situations to fail to find a solution even though there is one.  So, transform it to a sphere travelling on a plane colliding with a point on the plane (see below)
	/*
	float travelComponent = (p_startPoint - p_linePoint) * p_travelVector; // not used to determine non-collision here, just used below

	// quadratic:
	// a = |travel|^2 - (vx*vx*unitx*unitx + ...)
	// b = 2 * (start - point) * travel - 2*((spx - pox)*travelx*unitx^2 + ...)
	// c = |start - point|^2 - ((spx - vox)*unitx)^2 + ...) - radius^2
	float a = p_travelVector.MagnitudeSquared() - Vector3d(p_travelVector.x * p_lineUnitVector.x, p_travelVector.y * p_lineUnitVector.y, p_travelVector.z * p_lineUnitVector.z).MagnitudeSquared();
	if (abs(a) < 0.00001f)
		return false;
	float b = 2.0f * travelComponent - 2.0f * ((p_startPoint.x - p_linePoint.x)*p_travelVector.x*p_lineUnitVector.x*p_lineUnitVector.x + (p_startPoint.y - p_linePoint.y)*p_travelVector.y*p_lineUnitVector.y*p_lineUnitVector.y + (p_startPoint.z - p_linePoint.z)*p_travelVector.z*p_lineUnitVector.z*p_lineUnitVector.z);
	float c = (p_startPoint - p_linePoint).MagnitudeSquared() - Vector3d((p_startPoint.x - p_linePoint.x)*p_lineUnitVector.x, (p_startPoint.y - p_linePoint.y)*p_lineUnitVector.y, (p_startPoint.z - p_linePoint.z)*p_lineUnitVector.z).MagnitudeSquared() - (p_radius * p_radius);

	// quadratic formula!
	float noCollision = 10.0f;
	p_collisionT = noCollision;
	float sqrtAmount = b * b - 4.0f * a * c;
	if (sqrtAmount < 0.0f)
		return false;
	sqrtAmount = sqrt(sqrtAmount);
	float t1 = (-b + sqrtAmount) / (2.0f * a);
	if (t1 >= 0.0f && t1 <= 1.0f)
		p_collisionT = t1;
	float t2 = (-b - sqrtAmount) / (2.0f * a);
	if (t2 >= 0.0f && t2 <= 1.0f)
	{
		if (t2 < p_collisionT)
			p_collisionT = t2;
	}

	if (p_collisionT != noCollision)
		return true;
	else
		return false;
	*/

	// an alternate way.  Use the line unit vector to tranform the whole problem to a sphere point collision on a plane with the line reduced to a point on the plane by using its unitSegement as the planar normal
	// If a collision happens, return T.  That simple.
	// This works because the line extends infinitely in both directions perpendicular to the plane
	Vector3d transformedTravelVector = p_travelVector - p_lineUnitVector.ScalarMult(p_travelVector * p_lineUnitVector);
	Vector3d transformedStartPoint = p_startPoint - p_lineUnitVector.ScalarMult((p_startPoint - p_linePoint) * p_lineUnitVector);
	if (SpherePointCollision(transformedStartPoint, transformedTravelVector, p_radius, p_linePoint, p_collisionT) == true)
		return true;
	else
		return false;
}

bool MathUtilities::SphereLineIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_linePoint, Vector3d &p_lineUnitVector, float &p_distance)
{
	Vector3d transformedStartPoint = p_centerPoint - p_lineUnitVector.ScalarMult((p_centerPoint - p_linePoint) * p_lineUnitVector);
	if (SpherePointIntersection(transformedStartPoint, p_radius, p_linePoint, p_distance) == true)
		return true;
	else
		return false;
}

bool MathUtilities::SphereLineSegmentCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_linePoint0, Vector3d &p_linePoint1, Vector3d *p_lineUnitVector, float &p_collisionT)
{
	// sphere starting at startpoint, travelling along travelVector (t = 0 to 1) of radius, colliding with line segment lying between point0 and point1 with an optional unit vector
	// lineUnitVector MUST be a unit vector, and lead point0 to point1, otherwise the radius calculation will be off
	// todo: normalize unit vector if it isn't already (can slow things down - this routine can be called a lot - support boolean that informs if vector is unit or not)
	Vector3d unitVector;
	if (p_lineUnitVector == nullptr)
	{
		unitVector = p_linePoint1 - p_linePoint0;
		if (unitVector.Normalize() == false)
			return false;
		p_lineUnitVector = &unitVector;
	}

	if (SphereLineCollision(p_startPoint, p_travelVector, p_radius, p_linePoint0, *p_lineUnitVector, p_collisionT) == true)
	{
		// collision must lie between the two points of the segment inclusive
		float collisionPointOffset = (p_startPoint + p_travelVector.ScalarMult(p_collisionT) - p_linePoint0) * *p_lineUnitVector;

		// todo: provide collision point (p0 + unitvector * offset), and normal or direction of collision if necessary (start + travel * t - collision point normalized or not)
		// calling routine can do this just as easily

		if (collisionPointOffset < 0.0f)
			return false;

		if (collisionPointOffset >(p_linePoint1 - p_linePoint0) * *p_lineUnitVector)
			return false;

		return true;
	}
	else
		return false;
}

bool MathUtilities::SphereLineSegmentIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_linePoint0, Vector3d &p_linePoint1, Vector3d *p_lineUnitVector, float &p_distance)
{
	// sphere starting at startpoint, travelling along travelVector (t = 0 to 1) of radius, colliding with line segment lying between point0 and point1 with an optional unit vector
	// lineUnitVector MUST be a unit vector, and lead point0 to point1, otherwise the radius calculation will be off
	// todo: normalize unit vector if it isn't already (can slow things down - this routine can be called a lot - support boolean that informs if vector is unit or not)
	// this routine does NOT test the endpoints, only the segment itself, because many times multiple segments use shared endpoints, so the test routine should check the endpoints separately
	//   to avoid overtesting
	Vector3d unitVector;
	if (p_lineUnitVector == nullptr)
	{
		unitVector = p_linePoint1 - p_linePoint0;
		if (unitVector.Normalize() == false)
			return false;
		p_lineUnitVector = &unitVector;
	}

	float distance = 0.0f;
	if (SphereLineIntersection(p_centerPoint, p_radius, p_linePoint0, *p_lineUnitVector, distance) == true)
	{
		// collision must lie between the two points of the segment inclusive
		float intersectionPointOffset = (p_centerPoint - p_linePoint0) * *p_lineUnitVector;

		// todo: provide collision point (p0 + unitvector * offset), and normal or direction of collision if necessary (start + travel * t - collision point normalized or not)
		// calling routine can do this just as easily

		if (intersectionPointOffset < 0.0f)
			return false;

		if (intersectionPointOffset >(p_linePoint1 - p_linePoint0) * *p_lineUnitVector)
			return false;

		// got a collision, assign distance
		p_distance = distance;
		return true;
	}
	else
		return false;
}

bool MathUtilities::SpherePointCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_point, float &p_collisionT)
{
	// sphere starting at startpoint, travelling along travelVector (t = 0 to 1) of radius, colliding with point
	// formula: |(p_startPoint + p_travelVector * t - p_point)| = radius, 2 possible values for t
	// take earliest t since we want the first collision
	// note: predictive collision (rather than determining the t of collision) can happen along a cylinder with spheres at each end, 
	//   but the math might not be so much simpler as to just get the collision position anyway

	// if sphere is travelling away or perpendicular don't bother
	float travelComponent = (p_startPoint - p_point) * p_travelVector;
	if (travelComponent >= 0.0f)
		return false;

	// if entire path is too far away in the x, y, or z direction, abort
	// this probably takes longer than just running the calculation below, but might save time
	if ((p_startPoint.y + p_radius) < p_point.y && (p_startPoint.y + p_travelVector.y + p_radius) < p_point.y)
		return false;
	if ((p_startPoint.y - p_radius) > p_point.y && (p_startPoint.y + p_travelVector.y - p_radius) > p_point.y)
		return false;
	if ((p_startPoint.x + p_radius) < p_point.x && (p_startPoint.x + p_travelVector.x + p_radius) < p_point.x)
		return false;
	if ((p_startPoint.x - p_radius) > p_point.x && (p_startPoint.x + p_travelVector.x - p_radius) > p_point.x)
		return false;
	if ((p_startPoint.z + p_radius) < p_point.z && (p_startPoint.z + p_travelVector.z + p_radius) < p_point.z)
		return false;
	if ((p_startPoint.z - p_radius) > p_point.z && (p_startPoint.z + p_travelVector.z - p_radius) > p_point.z)
		return false;

	// breakdown:
	// (spx + vxt - pox)^2 + (spy + vyt - poy)^2 + (spz + vzt - poz)^2 ... = r^2
	// (spx - pox)^2 + vx^2t^2 + 2(spx-pox)vxt + (y,z)... = r^2
	// (spx - pox)^2 + vx^2t^2 + 2(spx-pox)vxt + (y,z)... - r^2 = 0

	// quadratic:
	// a = |travel|^2
	// b = 2 * (start - point) * travel
	// c = |start - point|^2 - radius^2
	float a = p_travelVector.MagnitudeSquared();
	if (abs(a) < 0.00001f)
		return false;
	float b = 2.0f * travelComponent; // convenient!
	float c = (p_startPoint - p_point).MagnitudeSquared() - (p_radius * p_radius);

	// quadratic formula!
	float noCollision = 10.0f;
	p_collisionT = noCollision;
	float sqrtAmount = b * b - 4.0f * a * c;
	if (sqrtAmount < 0.0f)
		return false;
	sqrtAmount = sqrt(sqrtAmount);
	float t1 = (-b + sqrtAmount) / (2.0f * a);
	if (t1 >= 0.0f && t1 <= 1.0f)
		p_collisionT = t1;
	float t2 = (-b - sqrtAmount) / (2.0f * a);
	if (t2 >= 0.0f && t2 <= 1.0f)
	{
		if (t2 < p_collisionT)
			p_collisionT = t2;
	}

	if (p_collisionT != noCollision)
		return true;
	else
		return false;
}

bool MathUtilities::SpherePointIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_point, float &p_distance)
{
	float distanceSq = (p_centerPoint - p_point).MagnitudeSquared();
	if (distanceSq < p_radius * p_radius)
	{
		p_distance = float(sqrt(distanceSq));
		return true;
	}
	else
		return false;
}

bool MathUtilities::ProjectileStrikeObjectNoGravity(Vector3d &p_gunPosition, Vector3d &p_gunVelocity, float p_projectileSpeed, Vector3d &p_objectPosition, Vector3d &p_objectVelocity, float &p_resultT, Vector3d &p_resultProjectileDirection)
{
	// the idea behind this formula is that offset from the point the object travelled to from the gun position at time t equals the length of the travel vector of the bullet from the gun at time t.
	// This places the object and the bullet at the same location
	// To prevent also having to solve for the bellet vector, the formula is adjusted so that the object's velocity includes the relative gun velocity, and the gun remains stationary
	// Original formula: |op + ov*t - gp| = |(gv + pv) * t|
	// Altered formula: |op + (ov - gv)*t - gp| = |pv * t| = pspeed * t - MUCH simpler to solve.  
	// solve for earliest t >= 0
	// fire at position op + ov*t - gv*t because bullet will take on velocty gv+gorient.f*pspeed

	Vector3d positionOffset = p_objectPosition - p_gunPosition;
	Vector3d velocityOffset = p_objectVelocity - p_gunVelocity;
	float a = velocityOffset.MagnitudeSquared() - p_projectileSpeed*p_projectileSpeed;
	float b = 2.0f * (positionOffset * velocityOffset);
	float c = positionOffset.MagnitudeSquared();

	// quadratic formula!
	float noCollision = -10.0f;
	p_resultT = noCollision;
	float sqrtAmount = b * b - 4.0f * a * c;
	if (sqrtAmount < 0.0f)
		return false;
	sqrtAmount = sqrt(sqrtAmount);
	float t1 = (-b + sqrtAmount) / (2.0f * a);
	if (t1 >= 0.0f)
		p_resultT = t1;
	float t2 = (-b - sqrtAmount) / (2.0f * a);
	if (t2 >= 0.0f)
	{
		if (t2 < p_resultT || p_resultT == noCollision)
			p_resultT = t2;
	}

	if (p_resultT != noCollision)
	{
		p_resultProjectileDirection = p_objectPosition + velocityOffset.ScalarMult(p_resultT) - p_gunPosition;
		return true;
	}
	else
		return false;
}

bool MathUtilities::ProjectileStrikeObjectApproximateGravity(Vector3d &p_gunPosition, Vector3d &p_gunVelocity, float p_projectileSpeed, float p_gravityPerTimeSquared, Vector3d &p_objectPosition, Vector3d &p_objectVelocity, float &p_resultT, Vector3d &p_resultProjectileDirection)
{
	if (ProjectileStrikeObjectNoGravity(p_gunPosition, p_gunVelocity, p_projectileSpeed, p_objectPosition, p_objectVelocity, p_resultT, p_resultProjectileDirection) == true)
	{
		// approximate gravity - this ONLY works for a very light curve on the parabola, so it works best for very fast projectiles only
		p_resultProjectileDirection.y += 0.5f * p_gravityPerTimeSquared * p_resultT * p_resultT;

		return true;
	}
	else
		return false;
}
