#include "..\Headers\TerrainMesh.h"

using namespace GameEng::Graphics;
using namespace GameEng::Math;

using namespace System; // Exception

LinkedList<TerrainStitchNativeObjectContainer> LinkedList<TerrainStitchNativeObjectContainer>::DeletedList;

void TerrainMeshCell::CalculateNormalsAndSegments()
{
	Vector3d v1 = lowerLeftVertex - lowerRightVertex;
	Vector3d v2 = upperRightVertex - lowerRightVertex;
	Vector3d v3 = v2.CrossProd(v1); // flu rule knowing positivity along orient axes
	if (v3.Normalize() == true)
		lowerRightNormal = v3;
	else
		throw gcnew Exception("Failed to normalize normal vector");

	v1 = lowerLeftVertex - upperLeftVertex;
	v2 = upperRightVertex - upperLeftVertex;
	v3 = v1.CrossProd(v2); // flu rule knowing positivity along orient axes
	if (v3.Normalize() == true)
		upperLeftNormal = v3;
	else
		throw gcnew Exception("Failed to normalize normal vector");

	leftSegmentUnit = upperLeftVertex - lowerLeftVertex;
	leftSegmentUnit.Normalize();
	diagonalSegmentUnit = upperRightVertex - lowerLeftVertex;
	diagonalSegmentUnit.Normalize();
	upperSegmentUnit = upperRightVertex - upperLeftVertex;
	upperSegmentUnit.Normalize();
}

void TerrainMeshCell::CalculateBounds()
{
	minY = lowerRightVertex.y;
	maxY = lowerRightVertex.y;

	if (lowerLeftVertex.y < minY)
		minY = lowerLeftVertex.y;
	if (upperRightVertex.y < minY)
		minY = upperRightVertex.y;
	if (upperLeftVertex.y < minY)
		minY = upperLeftVertex.y;

	if (lowerLeftVertex.y > maxY)
		maxY = lowerLeftVertex.y;
	if (upperRightVertex.y > maxY)
		maxY = upperRightVertex.y;
	if (upperLeftVertex.y > maxY)
		maxY = upperLeftVertex.y;
}

void TerrainMesh::CreateCells(int p_cellHorizontalQty, int p_cellVerticalQty)
{
	if (cells == nullptr)
	{
		cells = new TerrainMeshCell[p_cellHorizontalQty * p_cellVerticalQty];
		cellHorizontalQty = p_cellHorizontalQty;
		cellVerticalQty = p_cellVerticalQty;
	}
	else
		throw gcnew Exception("Mesh already initialized");
}

void TerrainMesh::SetHeight(float p_height)
{
	for (int cellVerticalIndex = 0; cellVerticalIndex < cellVerticalQty; cellVerticalIndex++)
		for (int cellHorizontalIndex = 0; cellHorizontalIndex < cellHorizontalQty; cellHorizontalIndex++)
		{
			cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex].lowerRightVertex.y = p_height;
			cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex].lowerLeftVertex.y = p_height;
			cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex].upperRightVertex.y = p_height;
			cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex].upperLeftVertex.y = p_height;
		}

	// note: call CalculateLevelOfDetailHeights and CalculateNormals after done setting all main terrain height values
}

void TerrainMesh::SetGreatestXZHeight()
{
	for (int cellVerticalIndex = 0; cellVerticalIndex < cellVerticalQty; cellVerticalIndex++)
		for (int cellHorizontalIndex = 0; cellHorizontalIndex < cellHorizontalQty; cellHorizontalIndex++)
		{
			TerrainMeshCell *cell = &cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex];
			if (cell->lowerRightVertex.x > cell->lowerRightVertex.z)
				cell->lowerRightVertex.y = cell->lowerRightVertex.x;
			else
				cell->lowerRightVertex.y = cell->lowerRightVertex.z;
			if (cell->lowerLeftVertex.x > cell->lowerLeftVertex.z)
				cell->lowerLeftVertex.y = cell->lowerLeftVertex.x;
			else
				cell->lowerLeftVertex.y = cell->lowerLeftVertex.z;
			if (cell->upperRightVertex.x > cell->upperRightVertex.z)
				cell->upperRightVertex.y = cell->upperRightVertex.x;
			else
				cell->upperRightVertex.y = cell->upperRightVertex.z;
			if (cell->upperLeftVertex.x > cell->upperLeftVertex.z)
				cell->upperLeftVertex.y = cell->upperLeftVertex.x;
			else
				cell->upperLeftVertex.y = cell->upperLeftVertex.z;
		}

	// note: call CalculateLevelOfDetailHeights and CalculateNormals after done setting all main terrain height values
}

void TerrainMesh::CalculateLevelOfDetailHeights()
{
	// only doing this once, so speed doesn't matter much
	for (int regionHorizontalIndex = 0; regionHorizontalIndex < regionHorizontalQty; regionHorizontalIndex++)
	{
		for (int regionVerticalIndex = 0; regionVerticalIndex < regionVerticalQty; regionVerticalIndex++)
		{
			TerrainMeshRegion *region = &regions[regionVerticalIndex * regionHorizontalQty + regionHorizontalIndex];

			for (int lodIndex = 0; lodIndex < region->lodQty; lodIndex++)
			{
				for (int cellVerticalIndex = 0; cellVerticalIndex < region->lods[lodIndex].cellVerticalQty; cellVerticalIndex++)
				{
					for (int cellHorizontalIndex = 0; cellHorizontalIndex < region->lods[lodIndex].cellHorizontalQty; cellHorizontalIndex++)
					{
						float lowerRightY, lowerLeftY, upperRightY, upperLeftY;
						// set right and lower values according to pre-calculate next values
						// calculate left and upper values and save for next iteration
						if (region->lods[lodIndex].levelOfDetail == 1)
						{
							// todo: grab values straight from main mesh
							TerrainMeshCell *mainMeshCell = &cells[(region->verticalStartIndex + cellVerticalIndex) * cellHorizontalQty + (region->horizontalStartIndex + cellHorizontalIndex)];
							lowerRightY = mainMeshCell->lowerRightVertex.y;
							lowerLeftY = mainMeshCell->lowerLeftVertex.y;
							upperRightY = mainMeshCell->upperRightVertex.y;
							upperLeftY = mainMeshCell->upperLeftVertex.y;
						}
						else
						{
							TerrainMeshCell *cell = &(region->lods[lodIndex].cells[cellVerticalIndex * region->lods[lodIndex].cellHorizontalQty + cellHorizontalIndex]);

							lowerRightY = CalculateLevelOfDetailHeight(cell->lowerRightVertex.x, cell->lowerRightVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
							lowerLeftY = CalculateLevelOfDetailHeight(cell->lowerLeftVertex.x, cell->lowerLeftVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
							upperRightY = CalculateLevelOfDetailHeight(cell->upperRightVertex.x, cell->upperRightVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
							upperLeftY = CalculateLevelOfDetailHeight(cell->upperLeftVertex.x, cell->upperLeftVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
						}

						// set it!
						region->lods[lodIndex].cells[cellVerticalIndex * region->lods[lodIndex].cellHorizontalQty + cellHorizontalIndex].SetY(lowerRightY, lowerLeftY, upperRightY, upperLeftY);
					}
				}
			}
		}
	}
}

void TerrainMesh::CalculateLevelOfDetailColors()
{
	// only doing this once, so speed doesn't matter much
	for (int regionHorizontalIndex = 0; regionHorizontalIndex < regionHorizontalQty; regionHorizontalIndex++)
	{
		for (int regionVerticalIndex = 0; regionVerticalIndex < regionVerticalQty; regionVerticalIndex++)
		{
			TerrainMeshRegion *region = &regions[regionVerticalIndex * regionHorizontalQty + regionHorizontalIndex];

			for (int lodIndex = 0; lodIndex < region->lodQty; lodIndex++)
			{
				for (int cellVerticalIndex = 0; cellVerticalIndex < region->lods[lodIndex].cellVerticalQty; cellVerticalIndex++)
				{
					for (int cellHorizontalIndex = 0; cellHorizontalIndex < region->lods[lodIndex].cellHorizontalQty; cellHorizontalIndex++)
					{
						GameColor lowerRightColor, lowerLeftColor, upperRightColor, upperLeftColor;
						// set right and lower values according to pre-calculate next values
						// calculate left and upper values and save for next iteration
						if (region->lods[lodIndex].levelOfDetail == 1)
						{
							// todo: grab values straight from main mesh
							TerrainMeshCell *mainMeshCell = &cells[(region->verticalStartIndex + cellVerticalIndex) * cellHorizontalQty + (region->horizontalStartIndex + cellHorizontalIndex)];
							lowerRightColor = mainMeshCell->lowerRightColor;
							lowerLeftColor = mainMeshCell->lowerLeftColor;
							upperRightColor = mainMeshCell->upperRightColor;
							upperLeftColor = mainMeshCell->upperLeftColor;
						}
						else
						{
							TerrainMeshCell *cell = &(region->lods[lodIndex].cells[cellVerticalIndex * region->lods[lodIndex].cellHorizontalQty + cellHorizontalIndex]);

							lowerRightColor = CalculateLevelOfDetailColor(cell->lowerRightVertex.x, cell->lowerRightVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
							lowerLeftColor = CalculateLevelOfDetailColor(cell->lowerLeftVertex.x, cell->lowerLeftVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
							upperRightColor = CalculateLevelOfDetailColor(cell->upperRightVertex.x, cell->upperRightVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
							upperLeftColor = CalculateLevelOfDetailColor(cell->upperLeftVertex.x, cell->upperLeftVertex.z, cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1), cellWorldWidth * pow(lodFactor, region->lods[lodIndex].levelOfDetail - 1));
						}

						// set it!
						region->lods[lodIndex].cells[cellVerticalIndex * region->lods[lodIndex].cellHorizontalQty + cellHorizontalIndex].SetColor(lowerRightColor, lowerLeftColor, upperRightColor, upperLeftColor);
					}
				}
			}
		}
	}
}

// provide averaged Y for a set of vertices
float TerrainMesh::CalculateLevelOfDetailHeight(float p_worldX, float p_worldZ, float p_widthX, float p_widthZ)
{
	// worldX/worldZ is the center of the region being examined
	// widthX and widthZ are the total width of the region

	// look to main mesh for this value.  
	// Collect all the points in the mesh within that range nad just provide back the highest height.
	// This way, mountains don't get 'shorter' in the distance
	// Discourages ridiculous peaks that are only one main mesh cell wide
	// A more intelligent routine could make good compromises for any terrain, along with a more intelligent routine to decide level of details to render

	// get world coord values to check (include begin, exclude end so that peaks don't look like plateaus because two lod coords took on the same value)
	float beginX = p_worldX - p_widthX / 2.0f;
	float beginZ = p_worldZ - p_widthZ / 2.0f;
	float stopX = p_worldX + p_widthX / 2.0f;
	float stopZ = p_worldZ + p_widthZ / 2.0f;

	if (beginX < 0.0)
		beginX = 0.0f;
	if (beginZ < 0.0)
		beginZ = 0.0f;

	int cellHorizontalBeginIndex = int(beginX / cellWorldWidth);
	int cellVerticalBeginIndex = int(beginZ / cellWorldWidth);

	bool done = false;
	bool firstIteration = true;
	float largestY = 0.0;
	int horizontalIndex = cellHorizontalBeginIndex;
	for (float x = beginX; x < stopX; x += cellWorldWidth)
	{
		int verticalIndex = cellVerticalBeginIndex;
		for (float z = beginZ; z < stopZ; z += cellWorldWidth)
		{
			if (horizontalIndex <= cellHorizontalQty && verticalIndex <= cellVerticalQty)
			{
				bool useLeft = false;
				bool useUpper = false;
				int hAdjust = 0;
				int vAdjust = 0;

				// if we are at the uppermost or far left vertex, it's only on that end of the last cell, not in another cell as the lowerright point.
				if (horizontalIndex == cellHorizontalQty)
				{
					hAdjust = -1;
					useLeft = true;
				}
				if (verticalIndex == cellVerticalQty)
				{
					vAdjust = -1;
					useUpper = true;
				}

				TerrainMeshCell *cell = &cells[(verticalIndex + vAdjust) * cellHorizontalQty + (horizontalIndex + hAdjust)];

				if (firstIteration == true)
				{
					if (useLeft && useUpper)
						largestY = cell->upperLeftVertex.y;
					else if (useLeft)
						largestY = cell->lowerLeftVertex.y;
					else if (useUpper)
						largestY = cell->upperRightVertex.y;
					else
						largestY = cell->lowerRightVertex.y;
					firstIteration = false;
				}
				else
				{
					float testY;
					if (useLeft && useUpper)
						testY = cell->upperLeftVertex.y;
					else if (useLeft)
						testY = cell->lowerLeftVertex.y;
					else if (useUpper)
						testY = cell->upperRightVertex.y;
					else
						testY = cell->lowerRightVertex.y;

					if (testY > largestY)
						largestY = testY;
				}
			}

			verticalIndex++;
		}

		horizontalIndex++;
	}

	return largestY;
}

GameColor TerrainMesh::CalculateLevelOfDetailColor(float p_worldX, float p_worldZ, float p_widthX, float p_widthZ)
{
	// just get colors for all the points and average them

	// get world coord values to check (include begin, exclude end so that peaks don't look like plateaus because two lod coords took on the same value)
	float beginX = p_worldX - p_widthX / 2.0f;
	float beginZ = p_worldZ - p_widthZ / 2.0f;
	float stopX = p_worldX + p_widthX / 2.0f;
	float stopZ = p_worldZ + p_widthZ / 2.0f;

	if (beginX < 0.0)
		beginX = 0.0f;
	if (beginZ < 0.0)
		beginZ = 0.0f;

	int cellHorizontalBeginIndex = int(beginX / cellWorldWidth);
	int cellVerticalBeginIndex = int(beginZ / cellWorldWidth);

	Vector3d totalColor = Vector3d(0,0,0);
	int colorQty = 0;

	bool done = false;
	bool firstIteration = true;
	float largestY = 0.0;
	int horizontalIndex = cellHorizontalBeginIndex;
	for (float x = beginX; x < stopX; x += cellWorldWidth)
	{
		int verticalIndex = cellVerticalBeginIndex;
		for (float z = beginZ; z < stopZ; z += cellWorldWidth)
		{
			if (horizontalIndex <= cellHorizontalQty && verticalIndex <= cellVerticalQty)
			{
				bool useLeft = false;
				bool useUpper = false;
				int hAdjust = 0;
				int vAdjust = 0;

				// if we are at the uppermost or far left vertex, it's only on that end of the last cell, not in another cell as the lowerright point.
				if (horizontalIndex == cellHorizontalQty)
				{
					hAdjust = -1;
					useLeft = true;
				}
				if (verticalIndex == cellVerticalQty)
				{
					vAdjust = -1;
					useUpper = true;
				}

				TerrainMeshCell *cell = &cells[(verticalIndex + vAdjust) * cellHorizontalQty + (horizontalIndex + hAdjust)];

				if (firstIteration == true)
				{
					if (useLeft && useUpper)
					{
						totalColor = Vector3d(cell->upperLeftColor.red, cell->upperLeftColor.green, cell->upperLeftColor.blue);
					}
					else if (useLeft)
					{
						totalColor = Vector3d(cell->lowerLeftColor.red, cell->lowerLeftColor.green, cell->lowerLeftColor.blue);
					}
					else if (useUpper)
					{
						totalColor = Vector3d(cell->upperRightColor.red, cell->upperRightColor.green, cell->upperRightColor.blue);
					}
					else
					{
						totalColor = Vector3d(cell->lowerRightColor.red, cell->lowerRightColor.green, cell->lowerRightColor.blue);
					}
					firstIteration = false;

					colorQty++;
				}
				else
				{
					if (useLeft && useUpper)
						totalColor = totalColor + Vector3d(cell->upperLeftColor.red, cell->upperLeftColor.green, cell->upperLeftColor.blue);
					else if (useLeft)
						totalColor = totalColor + Vector3d(cell->lowerLeftColor.red, cell->lowerLeftColor.green, cell->lowerLeftColor.blue);
					else if (useUpper)
						totalColor = totalColor + Vector3d(cell->upperRightColor.red, cell->upperRightColor.green, cell->upperRightColor.blue);
					else
						totalColor = totalColor + Vector3d(cell->lowerRightColor.red, cell->lowerRightColor.green, cell->lowerRightColor.blue);

					colorQty++;
				}
			}

			verticalIndex++;
		}

		horizontalIndex++;
	}

	if (colorQty > 0)
		totalColor = totalColor.ScalarMult(1.0f / float(colorQty));
	GameColor result = GameColor(unsigned char(totalColor.x), unsigned char(totalColor.y), unsigned char(totalColor.z));
	return result;
}

void TerrainMesh::CalculateNormalsAndSegments()
{
	// only doing this once, so speed doesn't matter much
	// todo: do normals for lods too for lighting, etc.
	for (int cellVerticalIndex = 0; cellVerticalIndex < cellVerticalQty; cellVerticalIndex++)
		for (int cellHorizontalIndex = 0; cellHorizontalIndex < cellHorizontalQty; cellHorizontalIndex++)
		{
			cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex].CalculateNormalsAndSegments();
		}
}

void TerrainMesh::CalculateBoundingVolumes()
{
	// only doing this once, so speed doesn't matter much
	for (int regionVerticalIndex = 0; regionVerticalIndex < regionVerticalQty; regionVerticalIndex++)
		for (int regionHorizontalIndex = 0; regionHorizontalIndex < regionHorizontalQty; regionHorizontalIndex++)
		{
			regions[regionVerticalIndex * regionHorizontalQty + regionHorizontalIndex].CalculateBoundingVolume();
		}

	// main cell minY/maxY
	// initialize
	minY = cells[0].lowerLeftVertex.y;
	maxY = cells[0].lowerLeftVertex.y;
	for (int cellVerticalIndex = 0; cellVerticalIndex < cellVerticalQty; cellVerticalIndex++)
		for (int cellHorizontalIndex = 0; cellHorizontalIndex < cellHorizontalQty; cellHorizontalIndex++)
		{
			TerrainMeshCell *cell = &cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex];
			cell->CalculateBounds();

			if (cell->lowerLeftVertex.y < minY)
				minY = cell->lowerLeftVertex.y;
			if (cell->lowerLeftVertex.y > maxY)
				maxY = cell->lowerLeftVertex.y;
			if (cell->lowerRightVertex.y < minY)
				minY = cell->lowerRightVertex.y;
			if (cell->lowerRightVertex.y > maxY)
				maxY = cell->lowerRightVertex.y;
			if (cell->upperLeftVertex.y < minY)
				minY = cell->upperLeftVertex.y;
			if (cell->upperLeftVertex.y > maxY)
				maxY = cell->upperLeftVertex.y;
			if (cell->upperRightVertex.y < minY)
				minY = cell->upperRightVertex.y;
			if (cell->upperRightVertex.y > maxY)
				maxY = cell->upperRightVertex.y;
		}
}

void TerrainMesh::CalculateColors(Vector3d &p_lightSourceDirectionUnit, GameColor p_shadeColor, GameColor p_brightColor)
{
	// p_lightSourcedirectionUnit is pointing AT the light source.  If it is the direction of the travelling light, take the reverse of the dot product instead.

	// only doing this once, so speed doesn't matter much
	// todo: do normals for lods too for lighting, etc.
	for (int v = 0; v < cellVerticalQty; v++)
		for (int h = 0; h < cellHorizontalQty; h++)
		{
			TerrainMeshCell *cell = &cells[v * cellHorizontalQty + h];
			TerrainMeshCell 
				*cellUpperRight = nullptr, 
				*cellUpper = nullptr, 
				*cellUpperLeft = nullptr, 
				*cellLeft = nullptr, 
				*cellLowerLeft = nullptr, 
				*cellLower = nullptr, 
				*cellLowerRight = nullptr, 
				*cellRight = nullptr;
			if (h > 0)
				cellRight = &cells[v * cellHorizontalQty + h - 1];
			if (h < cellHorizontalQty - 1)
				cellRight = &cells[v * cellHorizontalQty + h + 1];
			if (v > 0)
				cellLower = &cells[(v - 1) * cellHorizontalQty + h];
			if (v < cellVerticalQty - 1)
				cellUpper = &cells[(v + 1) * cellHorizontalQty + h];
			if (h > 0 && v > 0)
				cellLowerRight = &cells[(v - 1) * cellHorizontalQty + h - 1];
			if (h < cellHorizontalQty - 1 && v > 0)
				cellLowerLeft = &cells[(v - 1) * cellHorizontalQty + h + 1];
			if (h > 0 && v < cellVerticalQty - 1)
				cellUpperRight = &cells[(v + 1) * cellHorizontalQty + h - 1];
			if (h < cellHorizontalQty - 1 && v < cellVerticalQty - 1)
				cellUpperLeft = &cells[(v + 1) * cellHorizontalQty + h + 1];

			// add up all the normals we can find then normalize them as the average
			Vector3d lowerRightNormal = cell->lowerRightNormal;
			Vector3d lowerLeftNormal = cell->lowerRightNormal + cell->upperLeftNormal;
			Vector3d upperRightNormal = cell->lowerRightNormal + cell->upperLeftNormal;
			Vector3d upperLeftNormal = cell->upperLeftNormal;

			if (cellUpperLeft != nullptr)
				upperLeftNormal = upperLeftNormal + cellUpperLeft->lowerRightNormal;
			if (cellLeft != nullptr)
			{
				upperLeftNormal = upperLeftNormal + cellLeft->upperLeftNormal + cellLeft->lowerRightNormal;
				lowerLeftNormal = lowerLeftNormal + cellLeft->lowerRightNormal;
			}
			if (cellLowerLeft != nullptr)
				lowerLeftNormal = lowerLeftNormal + cellLowerLeft->lowerRightNormal + cellLowerLeft->upperLeftNormal;
			if (cellLower != nullptr)
			{
				lowerLeftNormal = lowerLeftNormal + cellLower->upperLeftNormal;
				lowerRightNormal = lowerRightNormal + cellLower->upperLeftNormal + cellLower->lowerRightNormal;
			}
			if (cellLowerRight != nullptr)
				lowerRightNormal = lowerRightNormal + cellLowerRight->upperLeftNormal;
			if (cellRight != nullptr)
			{
				lowerRightNormal = lowerRightNormal + cellRight->upperLeftNormal + cellRight->lowerRightNormal;
				upperRightNormal = upperRightNormal + cellRight->upperLeftNormal;
			}
			if (cellUpperRight != nullptr)
				upperRightNormal = upperRightNormal + cellUpperRight->upperLeftNormal + cellUpperRight->lowerRightNormal;
			if (cellUpper != nullptr)
			{
				upperLeftNormal = upperLeftNormal + cellUpper->upperLeftNormal + cellUpper->lowerRightNormal;
				upperRightNormal = upperRightNormal + cellUpper->lowerRightNormal;
			}
			lowerRightNormal.Normalize();
			lowerLeftNormal.Normalize();
			upperRightNormal.Normalize();
			upperLeftNormal.Normalize();

			// for now, don't average the normals - just light flat surfaces
			// no, can't do flat because one vertex shares two surfaces...
			// just do it this way for now
			cell->lowerRightColor = GameColor::Interpolate(p_shadeColor, p_brightColor, lowerRightNormal * p_lightSourceDirectionUnit);
			cell->lowerLeftColor = GameColor::Interpolate(p_shadeColor, p_brightColor, lowerLeftNormal * p_lightSourceDirectionUnit);
			cell->upperLeftColor = GameColor::Interpolate(p_shadeColor, p_brightColor, upperLeftNormal * p_lightSourceDirectionUnit);
			cell->upperRightColor = GameColor::Interpolate(p_shadeColor, p_brightColor, upperRightNormal * p_lightSourceDirectionUnit);
		}
}

void TerrainMesh::ObscureColorByYValue(GameColor &p_color, float p_startingDepth, float p_factorPerUnit)
{
	// only doing this once, so speed doesn't matter much
	for (int cellVerticalIndex = 0; cellVerticalIndex < cellVerticalQty; cellVerticalIndex++)
		for (int cellHorizontalIndex = 0; cellHorizontalIndex < cellHorizontalQty; cellHorizontalIndex++)
		{
			TerrainMeshCell *cell = &cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex];

			// for now, don't average the normals - just light flat surfaces
			// no, can't do flat because one vertex shares two surfaces...
			// just do it this way for now
			float factor;
			if (cell->lowerRightVertex.y <= p_startingDepth)
			{
				factor = p_factorPerUnit * (p_startingDepth - cell->lowerRightVertex.y);
				cell->lowerRightColor = GameColor::Interpolate(cell->lowerRightColor, p_color, factor);
			}
			if (cell->lowerLeftVertex.y <= p_startingDepth)
			{
				factor = p_factorPerUnit * (p_startingDepth - cell->lowerLeftVertex.y);
				cell->lowerLeftColor = GameColor::Interpolate(cell->lowerLeftColor, p_color, factor);
			}
			if (cell->upperRightVertex.y <= p_startingDepth)
			{
				factor = p_factorPerUnit * (p_startingDepth - cell->upperRightVertex.y);
				cell->upperRightColor = GameColor::Interpolate(cell->upperRightColor, p_color, factor);
			}
			if (cell->upperLeftVertex.y <= p_startingDepth)
			{
				factor = p_factorPerUnit * (p_startingDepth - cell->upperLeftVertex.y);
				cell->upperLeftColor = GameColor::Interpolate(cell->upperLeftColor, p_color, factor);
			}
		}
}


void TerrainMesh::CalculateLevelOfDetailRegions(int p_largestRegionCellDimension)
{
	// note: region cell dimension is a quantity of cells, NOT a world measurement (so 64, or 128, not 367.75)
	if (regions == nullptr)
	{
		// figure out how many regions we need horizontally and vertically
		// pad it to make sure we don't have a tiny regoin at the end
		regionHorizontalQty = cellHorizontalQty / p_largestRegionCellDimension;
		if ((regionHorizontalQty * p_largestRegionCellDimension) < cellHorizontalQty)
			regionHorizontalQty++;
		regionVerticalQty = cellVerticalQty / p_largestRegionCellDimension;
		if ((regionVerticalQty * p_largestRegionCellDimension) < cellVerticalQty)
			regionVerticalQty++;

		// the temp values are now the target number of regions on each axis.
		// go for that number of regions, with each region dimension balanced so that the cell sizes are close to the same size across the entire mesh (they should differ
		//   by no more than 1 on a given axis).

		int baseRegionHorizontalCellSize = cellHorizontalQty / regionHorizontalQty;
		int baseRegionVerticalCellSize = cellVerticalQty / regionVerticalQty;

		// Get remainders so we can determine when to increase the size of the next region by one
		int horizontalRegionRemainder = cellHorizontalQty - baseRegionHorizontalCellSize * regionHorizontalQty;
		int verticalRegionRemainder = cellVerticalQty - baseRegionVerticalCellSize * regionVerticalQty;

		if (regionHorizontalQty == 0)
			throw gcnew Exception("Horizontal regions calculated as zero");
		if (regionVerticalQty == 0)
			throw gcnew Exception("Vertical regions calculated as zero");

		// create the regions
		regions = new TerrainMeshRegion[regionHorizontalQty * regionVerticalQty];

		// this remainer/increment method is a float-less way of handling fractions.
		// 8/3 = 2 2/3.  3 increments.  results: 2, 3, 3 - increment is 2 (2 < 3), then 4 (>=3, -3 = 1), then 3 (>=3, -3 = 0)
		int horizontalRemainderIncrement = 0;
		int horizontalSizeAdjust = 0; int verticalSizeAdjust = 0;
		int regionHorizontalStartIndex = 0;
		int regionVerticalStartIndex = 0;
		for (int horizontalRegionIndex = 0; horizontalRegionIndex < regionHorizontalQty; horizontalRegionIndex++)
		{
			horizontalRemainderIncrement += horizontalRegionRemainder;
			if (horizontalRemainderIncrement >= regionHorizontalQty)
			{
				horizontalSizeAdjust = 1;
				horizontalRemainderIncrement -= regionHorizontalQty;
			}
			else
				horizontalSizeAdjust = 0;

			int verticalRemainderIncrement = 0;
			regionVerticalStartIndex = 0;
			for (int verticalRegionIndex = 0; verticalRegionIndex < regionVerticalQty; verticalRegionIndex++)
			{
				verticalRemainderIncrement += verticalRegionRemainder;
				if (verticalRemainderIncrement >= regionVerticalQty)
				{
					verticalSizeAdjust = 1;
					verticalRemainderIncrement -= regionVerticalQty;
				}
				else
					verticalSizeAdjust = 0;

				int highestLevelOfDetailHorizontalCellSize = baseRegionHorizontalCellSize + horizontalSizeAdjust;
				int highestLevelOfDetailVerticalCellSize = baseRegionVerticalCellSize + verticalSizeAdjust;

				// figure out lods needed, based on powered division from highest detailed mesh
				int lodQty = 1;
				float dividedValue = float(highestLevelOfDetailHorizontalCellSize);
				if (highestLevelOfDetailVerticalCellSize > highestLevelOfDetailHorizontalCellSize)
					dividedValue = float(highestLevelOfDetailVerticalCellSize);
				while (dividedValue >= 3.0f) // assumes we are truncating divided results below, not rounding, otherwise use 2.5 here
				{
					lodQty++;
					dividedValue = dividedValue / lodFactor;
				}

				regions[verticalRegionIndex * regionHorizontalQty + horizontalRegionIndex].Initialize(lodQty, regionHorizontalStartIndex, regionVerticalStartIndex);

				int dividedValueHorizontal = highestLevelOfDetailHorizontalCellSize;
				int dividedValueVertical = highestLevelOfDetailVerticalCellSize;
				// because we determined lodQty above by dividing until we got 2 on the larger dimension, we shouldn't get multiple 2x2 lods here
				for (int lodIndex = 0; lodIndex < lodQty; lodIndex++)
				{
					regions[verticalRegionIndex * regionHorizontalQty + horizontalRegionIndex].lods[lodIndex].Initialize(dividedValueHorizontal, dividedValueVertical, lodIndex + 1);

					// adjust size for next iteration, base upon powered division from highest detail mesh
					// truncate, don't round
					dividedValueHorizontal = int(highestLevelOfDetailHorizontalCellSize / pow(lodFactor, lodIndex + 1));
					dividedValueVertical = int(highestLevelOfDetailVerticalCellSize / pow(lodFactor, lodIndex + 1));

					// force cell size >= 2 so that rendering at least has a center point to stitch to
					if (dividedValueHorizontal < 2)
						dividedValueHorizontal = 2;
					if (dividedValueVertical < 2)
						dividedValueVertical = 2;
				}

				regionVerticalStartIndex += (baseRegionVerticalCellSize + verticalSizeAdjust);
			}

			regionHorizontalStartIndex += (baseRegionHorizontalCellSize + horizontalSizeAdjust);
		}

		// validate regions cover the entire dimension of the mesh
		int totalHorizontalSize = 0;
		for (int horizontalRegionIndex = 0; horizontalRegionIndex < regionHorizontalQty; horizontalRegionIndex++)
		{
			totalHorizontalSize += regions[0 * regionHorizontalQty + horizontalRegionIndex].lods[0].cellHorizontalQty;

			int totalVerticalSize = 0;
			for (int verticalRegionIndex = 0; verticalRegionIndex < regionVerticalQty; verticalRegionIndex++)
			{
				totalVerticalSize += regions[verticalRegionIndex * regionHorizontalQty + horizontalRegionIndex].lods[0].cellVerticalQty;
			}
			if (totalVerticalSize != cellVerticalQty)
				throw gcnew Exception("Vertical region total size != total vertical mesh size");
		}
		if (totalHorizontalSize != cellHorizontalQty)
			throw gcnew Exception("Horizontal region total size != total horizontal mesh size");
	} // regions == nullptr

	// within each region, calculate all their levels of detail down to a minimum cell dimension of 2. (also figure out how many levels of detail we need)

	// set vertices, startZ, startZ, internal X,Z etc. on regions, and make sure no gaps are left.
	float regionStartX = 0.0f;
	float regionStartZ = 0.0f;
	float regionEndX = 0.0f;
	float regionEndZ = 0.0f;
	int cellCountHoriztonal = 0;
	int cellCountVertical = 0;
	for (int horizontalRegionIndex = 0; horizontalRegionIndex < regionHorizontalQty; horizontalRegionIndex++)
	{
		TerrainMeshRegion *region = &regions[0 * regionHorizontalQty + horizontalRegionIndex]; // init for loop only, changes below

		regionStartX = startX + float(region->horizontalStartIndex)*cellWorldWidth;
		regionEndX = startX + float(region->horizontalStartIndex + region->lods[0].cellHorizontalQty)*cellWorldWidth;

		int totalVerticalSize = 0;
		for (int verticalRegionIndex = 0; verticalRegionIndex < regionVerticalQty; verticalRegionIndex++)
		{
			region = &regions[verticalRegionIndex * regionHorizontalQty + horizontalRegionIndex];

			regionStartZ = startZ + float(region->verticalStartIndex)*cellWorldWidth;
			// lods intiialized above, so this is good
			regionEndZ = startZ + float(region->verticalStartIndex + region->lods[0].cellVerticalQty)*cellWorldWidth;

			region->startX = regionStartX;
			region->startZ = regionStartZ;
			region->endX = regionEndX;
			region->endZ = regionEndZ;

			for(int lodIndex = 0; lodIndex < region->lodQty; lodIndex++)
			{
				// lods have same start/end X/Z as parent region - they just each have a different number of cells
				region->lods[lodIndex].startX = regionStartX;
				region->lods[lodIndex].startZ = regionStartZ;
				region->lods[lodIndex].endX = regionEndX;
				region->lods[lodIndex].endZ = regionEndZ;

				float totalRegionSizeX = regionEndX - regionStartX;
				float totalRegionSizeZ = regionEndZ - regionStartZ;

				for (int lodHorizontalCellIndex = 0; lodHorizontalCellIndex < region->lods[lodIndex].cellHorizontalQty; lodHorizontalCellIndex++)
				{
					for (int lodVerticalCellIndex = 0; lodVerticalCellIndex < region->lods[lodIndex].cellVerticalQty; lodVerticalCellIndex++)
					{
						float currentX = regionStartX + totalRegionSizeX / float(region->lods[lodIndex].cellHorizontalQty) * float(lodHorizontalCellIndex);
						float currentZ = regionStartZ + totalRegionSizeZ / float(region->lods[lodIndex].cellVerticalQty) * float(lodVerticalCellIndex);
						float nextX = regionStartX + totalRegionSizeX / float(region->lods[lodIndex].cellHorizontalQty) * float(lodHorizontalCellIndex + 1);
						float nextZ = regionStartZ + totalRegionSizeZ / float(region->lods[lodIndex].cellVerticalQty) * float(lodVerticalCellIndex + 1);

						// make sure last numbers are perfect (first numbers are perfect because 0 was multipled)
						if (lodHorizontalCellIndex == (region->lods[lodIndex].cellHorizontalQty - 1))
							nextX = regionEndX;
						if (lodVerticalCellIndex == (region->lods[lodIndex].cellVerticalQty - 1))
							nextZ = regionEndZ;

						region->lods[lodIndex].cells[lodVerticalCellIndex * region->lods[lodIndex].cellHorizontalQty + lodHorizontalCellIndex].SetXZ(
							currentX, currentZ, nextX, nextZ
							);

						// y's will be calculated later with the CalculateLodHeights method
					}
				}
			}
		}
	}
}

TerrainMeshLevelOfDetail * TerrainMesh::DetermineLevelOfDetailToRender(Orient3d &p_camera, TerrainMeshRegion *p_region, int p_mininumLevelOfDetail, float p_worldDistancePerLevelOfDetail)
{
	// determine lod from basic orthogonal distance, for now
	// and use this wonky formula, for now
	float distance = p_region->boundingVolume.PointOrthogonalDistance(p_camera.p);
	int lodIndex = 0;
	//int lodIndex = int(log(distance/p_worldDistancePerLevelOfDetail)/log(1.5));
	if (distance < p_worldDistancePerLevelOfDetail * 1.0f)
		lodIndex = 0;
	else if (distance < p_worldDistancePerLevelOfDetail * 2.0f)
		lodIndex = 1;
	else if (distance < p_worldDistancePerLevelOfDetail * 3.5f)
		lodIndex = 2;
	else if (distance < p_worldDistancePerLevelOfDetail * 6.0f)
		lodIndex = 3;
	else if (distance < p_worldDistancePerLevelOfDetail * 10.0f)
		lodIndex = 4;
	else if (distance < p_worldDistancePerLevelOfDetail * 25.0f)
		lodIndex = 5;
	else
		lodIndex = 6;

	// cleanup
	if (lodIndex > p_mininumLevelOfDetail)
		lodIndex = p_mininumLevelOfDetail;
	if (lodIndex < 0)
		lodIndex = 0;
	if (lodIndex >(p_region->lodQty - 1))
		lodIndex = p_region->lodQty - 1;

	return &(p_region->lods[lodIndex]);
}

void TerrainMesh::Render(Orient3d &p_camera, GraphicsBase &p_graphics, int p_minimumLevelOfDetail, float p_worldDistancePerLevelOfDetail, gcroot<GameTexture^> *p_textures, float p_XZPerWrap)
{
	// if at least 2 textures, use blendmap - serves as a trigger for native object to expect a blendmap
	if (p_textures != nullptr && static_cast<GameTexture^>(p_textures[1]) != nullptr)
		p_textures[4] = blendMap;

	//TerrainMeshRegionStitchMap stitchMap; // set for each call
	_int64 beginTime = DateTime::Now.Ticks;
	float xzPerWrap = p_XZPerWrap;
	if (p_textures != nullptr && p_XZPerWrap == 0.0f)
	{
		// force a default
		xzPerWrap = (GetEndX() - GetStartX()) / 8.0f; // just wrap it 8 times across the mesh
	}

	// establish lods to use for each region
	for (int hIndex = 0; hIndex < regionHorizontalQty; hIndex++)
	{
		for (int vIndex = 0; vIndex < regionVerticalQty; vIndex++)
		{
			TerrainMeshRegion *region = &regions[vIndex * regionHorizontalQty + hIndex];

			region->lodToRenderRef = DetermineLevelOfDetailToRender(p_camera, region, p_minimumLevelOfDetail, p_worldDistancePerLevelOfDetail);
		}
	}

	// now render them
	TerrainMeshStitchMap stitchMap;
	for (int hIndex = 0; hIndex < regionHorizontalQty; hIndex++)
	{
		for (int vIndex = 0; vIndex < regionVerticalQty; vIndex++)
		{
			TerrainMeshRegion *region = &regions[vIndex * regionHorizontalQty + hIndex];

			// don't render if region is behind viewpoint
			// todo: also check if it intersects the viewing frustum for more speedup in rendering
			if (region->boundingVolume.IsBehind(p_camera.p, p_camera.f) == false)
			{
				// set up the stitch map for this region

				stitchMap.thisLOD = region->lodToRenderRef;

				// todo: support rendering adjacent terrain meshes, eventually

				// any region that does not need to be involved in stitching should be set to null so that the render can quickly determine which stitching to ignore
				if (hIndex == 0)
				{
					stitchMap.rightLOD = nullptr;
					stitchMap.lowerRightLOD = nullptr;
					stitchMap.upperRightLOD = nullptr;
				}
				else
				{
					if (regions[vIndex * regionHorizontalQty + hIndex - 1].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
					{
						stitchMap.rightLOD = regions[vIndex * regionHorizontalQty + hIndex - 1].lodToRenderRef;
					}
					else
						stitchMap.rightLOD = nullptr;
					if (vIndex > 0)
					{
						if (regions[(vIndex - 1) * regionHorizontalQty + hIndex - 1].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
							stitchMap.lowerRightLOD = regions[(vIndex - 1) * regionHorizontalQty + hIndex - 1].lodToRenderRef;
						else
							stitchMap.lowerRightLOD = nullptr;
					}
					else
						stitchMap.lowerRightLOD = nullptr;
					if (vIndex < regionVerticalQty - 1)
					{
						if (regions[(vIndex + 1) * regionHorizontalQty + hIndex - 1].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
							stitchMap.upperRightLOD = regions[(vIndex + 1) * regionHorizontalQty + hIndex - 1].lodToRenderRef;
						else
							stitchMap.upperRightLOD = nullptr;
					}
					else
						stitchMap.upperRightLOD = nullptr;
				}
				if (hIndex == regionHorizontalQty - 1)
				{
					stitchMap.leftLOD = nullptr;
					stitchMap.lowerLeftLOD = nullptr;
					stitchMap.upperLeftLOD = nullptr;
				}
				else
				{
					if (regions[vIndex * regionHorizontalQty + hIndex + 1].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
					{
						stitchMap.leftLOD = regions[vIndex * regionHorizontalQty + hIndex + 1].lodToRenderRef;
					}
					else
						stitchMap.leftLOD = nullptr;
					if (vIndex > 0)
					{
						if (regions[(vIndex - 1) * regionHorizontalQty + hIndex + 1].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
						{
							stitchMap.lowerLeftLOD = regions[(vIndex - 1) * regionHorizontalQty + hIndex + 1].lodToRenderRef;
						}
						else
							stitchMap.lowerLeftLOD = nullptr;
					}
					else
						stitchMap.lowerLeftLOD = nullptr;
					if (vIndex < regionVerticalQty - 1)
					{
						if (regions[(vIndex + 1) * regionHorizontalQty + hIndex + 1].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
						{
							stitchMap.upperLeftLOD = regions[(vIndex + 1) * regionHorizontalQty + hIndex + 1].lodToRenderRef;
						}
						else
							stitchMap.upperLeftLOD = nullptr;
					}
					else
						stitchMap.upperLeftLOD = nullptr;
				}
				if (vIndex == 0)
				{
					stitchMap.lowerLOD = nullptr;
				}
				else
				{
					if (regions[(vIndex - 1) * regionHorizontalQty + hIndex].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
					{
						stitchMap.lowerLOD = regions[(vIndex - 1) * regionHorizontalQty + hIndex].lodToRenderRef;
					}
					else
						stitchMap.lowerLOD = nullptr;
				}
				if (vIndex == regionVerticalQty - 1)
				{
					stitchMap.upperLOD = nullptr;
				}
				else
				{
					if (regions[(vIndex + 1) * regionHorizontalQty + hIndex].lodToRenderRef->levelOfDetail < region->lodToRenderRef->levelOfDetail)
					{
						stitchMap.upperLOD = regions[(vIndex + 1) * regionHorizontalQty + hIndex].lodToRenderRef;
					}
					else
						stitchMap.upperLOD = nullptr;
				}

				// render it!
				p_graphics.RenderTerrainRegion(*(region->lodToRenderRef), stitchMap, p_textures, xzPerWrap);
			}
		}
	}
	_int64 endTime = DateTime::Now.Ticks;
	int elapsedTimeMS = int((endTime - beginTime) / 10000);
}

void TerrainMeshLevelOfDetail::Initialize(int p_cellHorizontalQty, int p_cellVerticalQty, int p_levelOfDetail)
{
	if (cells == nullptr)
	{
		if ((p_cellHorizontalQty == 0) || (p_cellVerticalQty == 0))
			throw gcnew Exception("Invalid dimension zero");

		cells = new TerrainMeshCell[p_cellHorizontalQty * p_cellVerticalQty];
		cellHorizontalQty = p_cellHorizontalQty;
		cellVerticalQty = p_cellVerticalQty;

		levelOfDetail = p_levelOfDetail;

		// faster referencing later
		lowerRightCellIndex = 0;
		lowerLeftCellIndex = cellHorizontalQty - 1;
		upperRightCellIndex = (cellVerticalQty - 1) * cellHorizontalQty;
		upperLeftCellIndex = (cellVerticalQty - 1) * cellHorizontalQty + cellHorizontalQty - 1;
	}
	else
		throw gcnew Exception("Mesh already initialized");
}

void TerrainMeshRegion::Initialize(int p_lodQty, int p_horizontalStartIndex, int p_verticalStartIndex)
{
	if (lods == nullptr)
	{
		lods = new TerrainMeshLevelOfDetail[p_lodQty];
		lodQty = p_lodQty;
		horizontalStartIndex = p_horizontalStartIndex;
		verticalStartIndex = p_verticalStartIndex;
	}
	else
		throw gcnew Exception("Region already initialized");
}

void TerrainMeshRegion::CalculateBoundingVolume()
{
	for (int hIndex = 0; hIndex < lods[0].cellHorizontalQty; hIndex++)
		for (int vIndex = 0; vIndex < lods[0].cellVerticalQty; vIndex++)
		{
			boundingVolume.ProcessPoint(lods[0].cells[vIndex * lods[0].cellHorizontalQty + hIndex].lowerLeftVertex);
			boundingVolume.ProcessPoint(lods[0].cells[vIndex * lods[0].cellHorizontalQty + hIndex].lowerRightVertex);
			boundingVolume.ProcessPoint(lods[0].cells[vIndex * lods[0].cellHorizontalQty + hIndex].upperLeftVertex);
			boundingVolume.ProcessPoint(lods[0].cells[vIndex * lods[0].cellHorizontalQty + hIndex].upperRightVertex);
		}
}

/////////////////////////////
// File operations

void TerrainMesh::WriteMeshToFile(String ^p_filePath)
{
	System::IO::BinaryWriter ^binaryWriter = gcnew System::IO::BinaryWriter(System::IO::File::Open(p_filePath, System::IO::FileMode::Create));

	try{
		binaryWriter->Write(cellHorizontalQty);
		binaryWriter->Write(cellVerticalQty);

		int count = 0;
		for (int v = 0; v <= cellVerticalQty; v++)
		{
			for (int h = 0; h <= cellHorizontalQty; h++)
			{
				float value;
				if (v < cellVerticalQty && h < cellHorizontalQty)
				{
					value = cells[v * cellHorizontalQty + h].lowerRightVertex.y;
				}
				else if (v < cellVerticalQty && h == cellHorizontalQty)
				{
					value = cells[v * cellHorizontalQty + h-1].lowerLeftVertex.y;
				}
				else if (v == cellVerticalQty && h < cellHorizontalQty)
				{
					value = cells[(v-1) * cellHorizontalQty + h].upperRightVertex.y;
				}
				else if (v == cellVerticalQty && h == cellHorizontalQty)
				{
					value = cells[(v-1) * cellHorizontalQty + h-1].upperLeftVertex.y;
				}

				binaryWriter->Write(value);
			}
		}
	}
	catch (System::Exception ^ex)
	{
		String ^tst = ex->ToString(); // to avoid compile warning
	}
	finally
	{
		binaryWriter->Close();
		delete binaryWriter;
	}
}

bool TerrainMesh::LoadMeshFromFile(String ^p_filePath, float p_startWorldX, float p_startWorldZ, float p_cellWorldWidth, float p_lodFactor)
{
	System::IO::BinaryReader ^binaryReader = nullptr;
	try
	{
		binaryReader = gcnew System::IO::BinaryReader(System::IO::File::Open(p_filePath, System::IO::FileMode::Open));
	}
	catch (System::Exception ^ex)
	{
		String ^tst = ex->ToString(); // to avoid compile warning
		return false;
	}

	bool result = false;

	try
	{
		cellHorizontalQty = binaryReader->ReadInt32();
		cellVerticalQty = binaryReader->ReadInt32();

		CreateCells(cellHorizontalQty, cellVerticalQty);

		startX = p_startWorldX;
		startZ = p_startWorldZ;
		cellWorldWidth = p_cellWorldWidth;
		endX = startX + cellWorldWidth * float(cellHorizontalQty);
		endZ = startZ + cellWorldWidth * float(cellVerticalQty);

		lodFactor = p_lodFactor;

		SetXZ();

		int count = 0;
		for (int v = 0; v <= cellVerticalQty; v++)
		{
			for (int h = 0; h <= cellHorizontalQty; h++)
			{
				float value = binaryReader->ReadSingle();

				if (v == 0 && h == 0)
				{
					cells[v * cellHorizontalQty + h].lowerRightVertex.y = value;
				}
				else if (v > 0 && v < cellVerticalQty && h == 0)
				{
					cells[(v)* cellHorizontalQty + h].lowerRightVertex.y = value;
					cells[(v - 1) * cellHorizontalQty + h].upperRightVertex.y = value;
				}
				else if (v == 0 && h > 0 && h < cellHorizontalQty)
				{
					cells[(v)* cellHorizontalQty + h].lowerRightVertex.y = value;
					cells[(v)* cellHorizontalQty + h - 1].lowerLeftVertex.y = value;
				}
				else if (v > 0 && v < cellVerticalQty && h > 0 && h < cellHorizontalQty)
				{
					cells[(v) * cellHorizontalQty + h].lowerRightVertex.y = value;
					cells[(v-1) * cellHorizontalQty + h].upperRightVertex.y = value;
					cells[(v)* cellHorizontalQty + h-1].lowerLeftVertex.y = value;
					cells[(v-1)* cellHorizontalQty + h-1].upperLeftVertex.y = value;
				}
				if (v == cellVerticalQty && h == cellHorizontalQty)
				{
					cells[(v-1) * cellHorizontalQty + h-1].upperLeftVertex.y = value;
				}
				else if (v == cellVerticalQty && h > 0 && h < cellHorizontalQty)
				{
					cells[(v-1)* cellHorizontalQty + h].upperRightVertex.y = value;
					cells[(v-1)* cellHorizontalQty + h - 1].upperLeftVertex.y = value;
				}
				else if (v > 0 && v < cellVerticalQty && h == cellHorizontalQty)
				{
					cells[(v)* cellHorizontalQty + h - 1].lowerLeftVertex.y = value;
					cells[(v - 1)* cellHorizontalQty + h - 1].upperLeftVertex.y = value;
				}
				else if (v == cellVerticalQty && h == 0)
				{
					cells[(v-1)* cellHorizontalQty + h].upperRightVertex.y = value;
				}
				else if (v == 0 && h == cellHorizontalQty)
				{
					cells[(v)* cellHorizontalQty + h - 1].lowerLeftVertex.y = value;
				}
			}
		}

		result = true;
	}
	catch (System::Exception ^ex)
	{
		String ^tst = ex->ToString(); // to avoid compile warning
	}
	finally
	{
		binaryReader->Close();
		delete binaryReader;
	}

	return result;
}

void TerrainMesh::CreateBlendMap(float p_minimumHeight, int p_minimumHeightTerrainType, float p_maximumHeight, int p_maximumHeightTerrainType, float p_maximumSlope, int p_maximumSlopeTerrainType, int p_remainingType)
{
	if (static_cast<GameTexture^>(blendMap) != nullptr)
		throw gcnew System::Exception("Blend map already created");

	// note: graphicPtr[0] = red, [1] = green, [2] = blue, [3] = alpha.  Textures are blended in order of red, green, blue and alpha.  
	// red is the default and is determined by slope
	// green is determined by maximumHeight - everything at or below that level and green is set
	// blue is leftover when nothing else is set (besides red the default)
	// alpha is determined by minimumHeight.  everything at or above that height and alpha is set
	// all sets are to 255.
	// todo: if a color is set and all bordering texels have that same color set, the default red can be zeroed out - might speed up the shader.
	// todo: we shouldn't be using lr and ul normals for slopes - those are for triangles for collision detection.  We need POINT normals - the ones we used for lighting - we should store those.

	// trying a 16-bit blend map to see if it speeds things up at all

	blendMap = gcnew GameTexture(cellHorizontalQty + 1, cellVerticalQty + 1, GameTextureInternalFormatEnum::RGBA8);
	for (int v = 0; v < cellVerticalQty; v++)
	{
		TerrainMeshCell *cell = &cells[v * cellHorizontalQty + 0];
		unsigned char *graphicPtr = blendMap->GetTexelPointer(0, v);
		for (int h = 0; h < cellHorizontalQty; h++)
		{
			graphicPtr[0] = 0; // always rock as default to avoid artifacts
			graphicPtr[1] = 15 * 16;
			//graphicPtr[2] = 0;
			//graphicPtr[3] = 0;
			if (cell->lowerRightNormal.y > p_maximumSlope)
			{
				if (cell->lowerRightVertex.y >= p_minimumHeight)
					graphicPtr[0] = 15;
				else if (cell->lowerRightVertex.y <= p_maximumHeight)
					graphicPtr[1] = 255;
				else
					graphicPtr[0] = 15 * 16;
			}
			if (h == cellHorizontalQty - 1)
			{
				// check left side now too
				graphicPtr += 2;
				graphicPtr[0] = 0; // always rock as default to avoid artifacts
				graphicPtr[1] = 15 * 16;
				//graphicPtr[2] = 0;
				//graphicPtr[3] = 0;
				if (cell->lowerRightNormal.y > p_maximumSlope) // todo: need a lowerleftnormal - in fact we need vertex normals
				{
					if (cell->lowerRightVertex.y >= p_minimumHeight)
						graphicPtr[0] = 15;
					else if (cell->lowerRightVertex.y <= p_maximumHeight)
						graphicPtr[1] = 255;
					else
						graphicPtr[0] = 15 * 16;
				}
			}
			cell++;
			graphicPtr += 2;
		}

		if (v == cellVerticalQty - 1)
		{
			cell = &cells[v * cellHorizontalQty + 0];
			graphicPtr = blendMap->GetTexelPointer(0, v+1);

			// check upper side now too
			for (int h = 0; h < cellHorizontalQty; h++)
			{
				graphicPtr[0] = 0; // always rock as default to avoid artifacts
				graphicPtr[1] = 15 * 16;
				//graphicPtr[2] = 0;
				//graphicPtr[3] = 0;
				if (cell->upperLeftNormal.y > p_maximumSlope) // todo: need upperRightNormal - in fact we need vertex normals
				{
					if (cell->lowerRightVertex.y >= p_minimumHeight)
						graphicPtr[0] = 15;
					else if (cell->lowerRightVertex.y <= p_maximumHeight)
						graphicPtr[1] = 255;
					else
						graphicPtr[0] = 15 * 16;
				}
				if (h == cellHorizontalQty - 1)
				{
					// check left side now too
					graphicPtr += 2;
					graphicPtr[0] = 0; // always rock as default to avoid artifacts
					graphicPtr[1] = 15 * 16;
					//graphicPtr[2] = 0;
					//graphicPtr[3] = 0;
					if (cell->upperLeftNormal.y > p_maximumSlope)
					{
						if (cell->lowerRightVertex.y >= p_minimumHeight)
							graphicPtr[0] = 15;
						else if (cell->lowerRightVertex.y <= p_maximumHeight)
							graphicPtr[1] = 255;
						else
							graphicPtr[0] = 15 * 16;
					}
				}
				cell++;
				graphicPtr += 2;
			}
		}
	}

	// >>>> hold off on this - no real notifcable gain in speed in the shader
	// now, parse each texel and get rid of redundant 255's which also requires filling in other 255's to prevent holes in the result: 
	// if two neighboring texels have a given same highest component set to 255 and nothing higher between them, all lower components for both can be zero
	// if two neighboring components have a highest component between them set to 255, in the texel with the higher component, set that highest component to 255 and clear all lower ones
	// later texels can't invalidate the adjustments made to prior texels
}

bool TerrainMesh::SphereCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, float &p_collisionT, Vector3d &p_collisionLocation, Vector3d &p_collisionNormal)
{
	// A sphere at position startPoint is moving along the travelVector (t=0 => startPoint, t=1 => startPoint + travelVector).  Find first collision that occurs, if any
	// check for collision with all triangles in the primary mesh (regions lod 0)
	// upon first collision, set collisionT, location and collision normal (unit vector from collision point to startpoint+travel*collisionT) and return true
	// note: can collide with a surface, segment or point

	// exclude any cells that don't need checking (max height are all below startpoint + travelvector, etc. for a region, then a cell)
	// ignore any surfaces for which starting point is behind

	// for simplicity until it can be sped up, grab all cells that includes startpoint.x - radius, startPoint.z - radius to endpoint x,z + radius (not exactly, but yeah)

	// todo: collision with segment or point, too

	// get bounds of travel
	Vector3d collisionMinimum;
	Vector3d collisionMaximum;
	if (p_travelVector.x < 0.0f)
	{
		collisionMinimum.x = (p_startPoint + p_travelVector).x - p_radius;
		collisionMaximum.x = (p_startPoint).x + p_radius;
	}
	else
	{
		collisionMinimum.x = (p_startPoint).x - p_radius;
		collisionMaximum.x = (p_startPoint + p_travelVector).x + p_radius;
	}
	if (p_travelVector.y < 0.0f)
	{
		collisionMinimum.y = (p_startPoint + p_travelVector).y - p_radius;
		collisionMaximum.y = (p_startPoint).y + p_radius;
	}
	else
	{
		collisionMinimum.y = (p_startPoint).y - p_radius;
		collisionMaximum.y = (p_startPoint + p_travelVector).y + p_radius;
	}
	if (p_travelVector.z < 0.0f)
	{
		collisionMinimum.z = (p_startPoint + p_travelVector).z - p_radius;
		collisionMaximum.z = (p_startPoint).z + p_radius + p_radius;
	}
	else
	{
		collisionMinimum.z = (p_startPoint).z - p_radius;
		collisionMaximum.z = (p_startPoint + p_travelVector).z + p_radius;
	}

	float minimumY = collisionMinimum.y;

	// if lowest y object touches is above terrain's maxY, it's not going to collide.
	if (minimumY > maxY)
		return false;

	// get main mesh indices of cells to collect
	int startHorizontalIndex = int((collisionMinimum.x - startX) / cellWorldWidth);
	int endHorizontalIndex = int((collisionMaximum.x - startX) / cellWorldWidth);

	int startVerticalIndex = int((collisionMinimum.z - startZ) / cellWorldWidth);
	int endVerticalIndex = int((collisionMaximum.z - startZ) / cellWorldWidth);

	// avoid checking if we are outside of everything
	if (startHorizontalIndex < 0 && endHorizontalIndex < 0)
		return false;
	if (startVerticalIndex < 0 && endVerticalIndex < 0)
		return false;
	if (startHorizontalIndex > cellHorizontalQty - 1 && endHorizontalIndex > cellHorizontalQty - 1)
		return false;
	if (startVerticalIndex > cellVerticalQty - 1 && endVerticalIndex > cellVerticalQty - 1)
		return false;

	// check bounds on cells we are checking
	if (startHorizontalIndex < 0)
		startHorizontalIndex = 0;
	if (startVerticalIndex < 0)
		startVerticalIndex = 0;
	if (endHorizontalIndex < 0)
		endHorizontalIndex = 0;
	if (endVerticalIndex < 0)
		endVerticalIndex = 0;
	if (startHorizontalIndex > cellHorizontalQty - 1)
		startHorizontalIndex = cellHorizontalQty - 1;
	if (startVerticalIndex > cellVerticalQty - 1)
		startVerticalIndex = cellVerticalQty - 1;
	if (endHorizontalIndex > cellHorizontalQty - 1)
		endHorizontalIndex = cellHorizontalQty - 1;
	if (endVerticalIndex > cellVerticalQty - 1)
		endVerticalIndex = cellVerticalQty - 1;

	// now loop properly
	int loopStartHorizontalIndex = startHorizontalIndex;
	int loopEndHorizontalIndex = endHorizontalIndex;
	int loopHorizontalIncrement = 1;
	if (p_travelVector.x < 0.0f)
	{
		loopStartHorizontalIndex = endHorizontalIndex;
		loopEndHorizontalIndex = startHorizontalIndex;
		loopHorizontalIncrement = -1;
	}
	int loopStartVerticalIndex = startVerticalIndex;
	int loopEndVerticalIndex = endVerticalIndex;
	int loopVerticalIncrement = 1;
	if (p_travelVector.z < 0.0f)
	{
		loopStartVerticalIndex = endVerticalIndex;
		loopEndVerticalIndex = startVerticalIndex;
		loopVerticalIncrement = -1;
	}

	// todo: to speed up, exclude groups of cells that cannot be collided with (split by regions)
	// todo: If a given cell lacks the heigh bounds for a collision, skip the cell too (need min/max Y on the cell as part of terrain data prep)


	float noCollision = 10.0f;
	p_collisionT = noCollision;  // if it remains 10.0f there was no collision
	// terrain is rendered as follows (from main definition):
	// ----- z
	// | / |
	// ----- 0
	// x   0
	// we can't stop at the first collision because the next cell might offer a collision that happened sooner (think really steep cell with large radius sphere that strikes
	//   the near vertical surface in the next cell before it strikes the floor in the current cell)
	// so there really isn't a reason to handle cells in a certain order
	for (int v = loopStartVerticalIndex; ((loopVerticalIncrement > 0 && v <= loopEndVerticalIndex) || (loopVerticalIncrement < 0 && v >= loopEndVerticalIndex)); v += loopVerticalIncrement)
	{
		TerrainMeshCell *cell = &(cells[v * cellHorizontalQty + loopStartHorizontalIndex]);
		for (int h = loopStartHorizontalIndex; ((loopHorizontalIncrement > 0 && h <= loopEndHorizontalIndex) || (loopHorizontalIncrement < 0 && h >= loopEndHorizontalIndex)); h += loopHorizontalIncrement)
		{
			if (minimumY <= cell->maxY) // don't bother if the travelling sphere won't even reach the maxY of the cell from above
			{
				// use lowerleft point of each cell and the surface normal for each to define the plane being collided with
				float collisionT;
				if (MathUtilities::SpherePlaneCollision(p_startPoint, p_travelVector, p_radius, cell->lowerLeftVertex, cell->upperLeftNormal, collisionT) == true)
				{
					if (collisionT < p_collisionT)
					{
						Vector3d collisionLocation = p_startPoint + p_travelVector.ScalarMult(collisionT) - cell->upperLeftNormal.ScalarMult(p_radius);
						if (collisionLocation.x >= cell->lowerRightVertex.x && collisionLocation.x <= cell->lowerLeftVertex.x
							&& collisionLocation.z >= cell->lowerRightVertex.z && collisionLocation.z <= cell->upperRightVertex.z)
						{
							// has to be in upper left triangle
							Vector3d offsetWithinCell = collisionLocation - cell->lowerLeftVertex;
							if (-offsetWithinCell.x <= offsetWithinCell.z)
							{
								p_collisionT = collisionT;
								p_collisionNormal = cell->upperLeftNormal;
								p_collisionLocation = collisionLocation;
							}
						}
					}
				}
				if (MathUtilities::SpherePlaneCollision(p_startPoint, p_travelVector, p_radius, cell->lowerLeftVertex, cell->lowerRightNormal, collisionT) == true)
				{
					if (collisionT < p_collisionT)
					{
						Vector3d collisionLocation = p_startPoint + p_travelVector.ScalarMult(collisionT) - cell->lowerRightNormal.ScalarMult(p_radius);
						if (collisionLocation.x >= cell->lowerRightVertex.x && collisionLocation.x <= cell->lowerLeftVertex.x
							&& collisionLocation.z >= cell->lowerRightVertex.z && collisionLocation.z <= cell->upperRightVertex.z)
						{
							// has to be in lower right triangle
							Vector3d offsetWithinCell = collisionLocation - cell->lowerLeftVertex;
							if (-offsetWithinCell.x >= offsetWithinCell.z)
							{
								p_collisionT = collisionT;
								p_collisionNormal = cell->lowerRightNormal;
								p_collisionLocation = collisionLocation;
							}
						}
					}
				}

				// todo: make these checks more complete (might need more segments and points to check based on location in loop)

				// if no collisions occurred on the planes, and it isn't a ray, check the segments and point.  just the upper, diagonal, and left
				if (p_radius > 0.0f)
				{
					if (p_collisionT == noCollision)
					{
						if (MathUtilities::SphereLineSegmentCollision(p_startPoint, p_travelVector, p_radius, cell->lowerLeftVertex, cell->upperLeftVertex, &(cell->leftSegmentUnit), collisionT) == true)
						{
							if (collisionT < p_collisionT)
							{
								p_collisionT = collisionT;
								Vector3d sphereCollisionLocation = p_startPoint + p_travelVector.ScalarMult(collisionT);
								p_collisionLocation = cell->lowerLeftVertex + cell->leftSegmentUnit.ScalarMult((sphereCollisionLocation - cell->lowerLeftVertex) * cell->leftSegmentUnit);
								p_collisionNormal = sphereCollisionLocation - p_collisionLocation;
							}
						}

						if (MathUtilities::SphereLineSegmentCollision(p_startPoint, p_travelVector, p_radius, cell->lowerLeftVertex, cell->upperRightVertex, &(cell->diagonalSegmentUnit), collisionT) == true)
						{
							if (collisionT < p_collisionT)
							{
								p_collisionT = collisionT;
								Vector3d sphereCollisionLocation = p_startPoint + p_travelVector.ScalarMult(collisionT);
								p_collisionLocation = cell->lowerLeftVertex + cell->diagonalSegmentUnit.ScalarMult((sphereCollisionLocation - cell->lowerLeftVertex) * cell->diagonalSegmentUnit);
								p_collisionNormal = sphereCollisionLocation - p_collisionLocation;
							}
						}

						if (MathUtilities::SphereLineSegmentCollision(p_startPoint, p_travelVector, p_radius, cell->upperLeftVertex, cell->upperRightVertex, &(cell->upperSegmentUnit), collisionT) == true)
						{
							if (collisionT < p_collisionT)
							{
								p_collisionT = collisionT;
								Vector3d sphereCollisionLocation = p_startPoint + p_travelVector.ScalarMult(collisionT);
								p_collisionLocation = cell->upperLeftVertex + cell->upperSegmentUnit.ScalarMult((sphereCollisionLocation - cell->upperLeftVertex) * cell->upperSegmentUnit);
								p_collisionNormal = sphereCollisionLocation - p_collisionLocation;
							}
						}
					}

					// If still no collisions, check collision with upper right point
					if (p_collisionT == noCollision)
					{
						if (MathUtilities::SpherePointCollision(p_startPoint, p_travelVector, p_radius, cell->upperRightVertex, collisionT) == true)
						{
							if (collisionT < p_collisionT)
							{
								p_collisionT = collisionT;
								Vector3d sphereCollisionLocation = p_startPoint + p_travelVector.ScalarMult(collisionT);
								p_collisionLocation = cell->upperRightVertex;
								p_collisionNormal = sphereCollisionLocation - p_collisionLocation;
							}
						}
					}
				}
			}

			if (loopHorizontalIncrement > 0)
				cell++;
			else
				cell--;
		}
	}

	if (p_collisionT != noCollision)
	{
		return true;
	}
	else
		return false;
}

bool TerrainMesh::SphereIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_collisionNormal)
{
	// get bounds of sphere
	Vector3d collisionMinimum;
	Vector3d collisionMaximum;
	collisionMinimum.x = (p_centerPoint).x - p_radius;
	collisionMaximum.x = (p_centerPoint).x + p_radius;
	collisionMinimum.y = (p_centerPoint).y - p_radius;
	collisionMaximum.y = (p_centerPoint).y + p_radius;
	collisionMinimum.z = (p_centerPoint).z - p_radius;
	collisionMaximum.z = (p_centerPoint).z + p_radius;

	float minimumY = collisionMinimum.y;

	// if lowest y object touches is above terrain's maxY, it's not going to collide.
	if (minimumY > maxY)
		return false;

	// get main mesh indices of cells to collect
	int startHorizontalIndex = int((collisionMinimum.x - startX) / cellWorldWidth);
	int endHorizontalIndex = int((collisionMaximum.x - startX) / cellWorldWidth);

	int startVerticalIndex = int((collisionMinimum.z - startZ) / cellWorldWidth);
	int endVerticalIndex = int((collisionMaximum.z - startZ) / cellWorldWidth);

	// avoid checking if we are outside of everything
	if (startHorizontalIndex < 0 && endHorizontalIndex < 0)
		return false;
	if (startVerticalIndex < 0 && endVerticalIndex < 0)
		return false;
	if (startHorizontalIndex > cellHorizontalQty - 1 && endHorizontalIndex > cellHorizontalQty - 1)
		return false;
	if (startVerticalIndex > cellVerticalQty - 1 && endVerticalIndex > cellVerticalQty - 1)
		return false;

	// check bounds on cells we are checking
	if (startHorizontalIndex < 0)
		startHorizontalIndex = 0;
	if (startVerticalIndex < 0)
		startVerticalIndex = 0;
	if (endHorizontalIndex < 0)
		endHorizontalIndex = 0;
	if (endVerticalIndex < 0)
		endVerticalIndex = 0;
	if (startHorizontalIndex > cellHorizontalQty - 1)
		startHorizontalIndex = cellHorizontalQty - 1;
	if (startVerticalIndex > cellVerticalQty - 1)
		startVerticalIndex = cellVerticalQty - 1;
	if (endHorizontalIndex > cellHorizontalQty - 1)
		endHorizontalIndex = cellHorizontalQty - 1;
	if (endVerticalIndex > cellVerticalQty - 1)
		endVerticalIndex = cellVerticalQty - 1;

	// now loop properly
	int loopStartHorizontalIndex = startHorizontalIndex;
	int loopEndHorizontalIndex = endHorizontalIndex;
	int loopHorizontalIncrement = 1;
	int loopStartVerticalIndex = startVerticalIndex;
	int loopEndVerticalIndex = endVerticalIndex;
	int loopVerticalIncrement = 1;

	// todo: to speed up, exclude groups of cells that cannot be collided with (split by regions)
	// todo: If a given cell lacks the heigh bounds for a collision, skip the cell too (need min/max Y on the cell as part of terrain data prep)

	float noCollision = p_radius * 2.0f;
	float collisionDistance = noCollision;  // if it remains noCollision there was no intersection
	// terrain is rendered as follows (from main definition):
	// ----- z
	// | / |
	// ----- 0
	// x   0
	// we can't stop at the first collision because the next cell might offer a collision that happened sooner (think really steep cell with large radius sphere that strikes
	//   the near vertical surface in the next cell before it strikes the floor in the current cell)
	// so there really isn't a reason to handle cells in a certain order
	for (int v = loopStartVerticalIndex; ((loopVerticalIncrement > 0 && v <= loopEndVerticalIndex) || (loopVerticalIncrement < 0 && v >= loopEndVerticalIndex)); v += loopVerticalIncrement)
	{
		TerrainMeshCell *cell = &(cells[v * cellHorizontalQty + loopStartHorizontalIndex]);
		for (int h = loopStartHorizontalIndex; ((loopHorizontalIncrement > 0 && h <= loopEndHorizontalIndex) || (loopHorizontalIncrement < 0 && h >= loopEndHorizontalIndex)); h += loopHorizontalIncrement)
		{
			if (minimumY <= cell->maxY) // don't bother if the travelling sphere won't even reach the maxY of the cell from above
			{
				// use lowerleft point of each cell and the surface normal for each to define the plane being collided with
				float distanceT;
				if (MathUtilities::SpherePlaneIntersection(p_centerPoint, p_radius, cell->lowerLeftVertex, cell->upperLeftNormal, distanceT) == true)
				{
					if (distanceT < collisionDistance)
					{
						Vector3d collisionLocation = p_centerPoint - cell->upperLeftNormal.ScalarMult(distanceT);
						if (collisionLocation.x >= cell->lowerRightVertex.x && collisionLocation.x <= cell->lowerLeftVertex.x
							&& collisionLocation.z >= cell->lowerRightVertex.z && collisionLocation.z <= cell->upperRightVertex.z)
						{
							// has to be in upper left triangle
							Vector3d offsetWithinCell = collisionLocation - cell->lowerLeftVertex;
							if (-offsetWithinCell.x <= offsetWithinCell.z)
							{
								collisionDistance = distanceT;
								p_collisionNormal = cell->upperLeftNormal;
							}
						}
					}
				}
				if (MathUtilities::SpherePlaneIntersection(p_centerPoint, p_radius, cell->lowerLeftVertex, cell->lowerRightNormal, distanceT) == true)
				{
					if (distanceT < collisionDistance)
					{
						Vector3d collisionLocation = p_centerPoint - cell->lowerRightNormal.ScalarMult(distanceT);
						if (collisionLocation.x >= cell->lowerRightVertex.x && collisionLocation.x <= cell->lowerLeftVertex.x
							&& collisionLocation.z >= cell->lowerRightVertex.z && collisionLocation.z <= cell->upperRightVertex.z)
						{
							// has to be in lower right triangle
							Vector3d offsetWithinCell = collisionLocation - cell->lowerLeftVertex;
							if (-offsetWithinCell.x >= offsetWithinCell.z)
							{
								collisionDistance = distanceT;
								p_collisionNormal = cell->lowerRightNormal;
							}
						}
					}
				}

				// todo: make these checks more complete (might need more segments and points to check based on location in loop)

				// if no intersections occurred on the planes, and it isn't a point, check the segments and point.  just the upper, diagonal, and left
				if (p_radius > 0.0f)
				{
					if (collisionDistance == noCollision)
					{
						if (MathUtilities::SphereLineSegmentIntersection(p_centerPoint, p_radius, cell->lowerLeftVertex, cell->upperLeftVertex, &(cell->leftSegmentUnit), distanceT) == true)
						{
							if (distanceT < collisionDistance)
							{
								collisionDistance = distanceT;
								Vector3d collisionLocation = cell->lowerLeftVertex + cell->leftSegmentUnit.ScalarMult((p_centerPoint - cell->lowerLeftVertex) * cell->leftSegmentUnit);
								p_collisionNormal = p_centerPoint - collisionLocation;
							}
						}

						if (MathUtilities::SphereLineSegmentIntersection(p_centerPoint, p_radius, cell->lowerLeftVertex, cell->upperRightVertex, &(cell->diagonalSegmentUnit), distanceT) == true)
						{
							if (distanceT < collisionDistance)
							{
								collisionDistance = distanceT;
								Vector3d collisionLocation = cell->lowerLeftVertex + cell->diagonalSegmentUnit.ScalarMult((p_centerPoint - cell->lowerLeftVertex) * cell->diagonalSegmentUnit);
								p_collisionNormal = p_centerPoint - collisionLocation;
							}
						}

						if (MathUtilities::SphereLineSegmentIntersection(p_centerPoint, p_radius, cell->upperLeftVertex, cell->upperRightVertex, &(cell->upperSegmentUnit), distanceT) == true)
						{
							if (distanceT < collisionDistance)
							{
								collisionDistance = distanceT;
								Vector3d collisionLocation = cell->upperLeftVertex + cell->upperSegmentUnit.ScalarMult((p_centerPoint - cell->upperLeftVertex) * cell->upperSegmentUnit);
								p_collisionNormal = p_centerPoint - collisionLocation;
							}
						}
					}

					// If still no collisions, check collision with upper right point
					if (collisionDistance == noCollision)
					{
						if (MathUtilities::SpherePointIntersection(p_centerPoint, p_radius, cell->upperRightVertex, distanceT) == true)
						{
							if (distanceT < collisionDistance)
							{
								collisionDistance = distanceT;
								p_collisionNormal = p_centerPoint - cell->upperRightVertex;
							}
						}
					}
				}
			}

			if (loopHorizontalIncrement > 0)
				cell++;
			else
				cell--;
		}
	}

	if (collisionDistance != noCollision)
	{
		return true;
	}
	else
		return false;
}
