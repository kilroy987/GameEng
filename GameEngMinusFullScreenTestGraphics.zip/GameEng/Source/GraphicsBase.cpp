#include "..\Headers\GraphicsBase.h"

using namespace GameEng::Graphics;
using namespace GameEng::Storage;

LinkedList<GraphicsNativeObjectContainerPtr> LinkedList<GraphicsNativeObjectContainerPtr>::DeletedList;
LinkedList<GraphicsNativeParticlesContainerPtr> LinkedList<GraphicsNativeParticlesContainerPtr>::DeletedList;
LinkedList<GraphicsParticleQueuePtr> LinkedList<GraphicsParticleQueuePtr>::DeletedList;
LinkedList<GraphicsPolygonQueuePtr> LinkedList<GraphicsPolygonQueuePtr>::DeletedList;
LinkedList<GraphicsFrameBufferContainerPtr> LinkedList<GraphicsFrameBufferContainerPtr>::DeletedList;
LinkedList<GraphicsNativeProgramContainer> LinkedList<GraphicsNativeProgramContainer>::DeletedList;
LinkedList<GraphicsVertexDataList> LinkedList<GraphicsVertexDataList>::DeletedList;
LinkedList<GraphicsVertexData> LinkedList<GraphicsVertexData>::DeletedList;
LinkedList<GraphicsLoadedTextureContainer> LinkedList<GraphicsLoadedTextureContainer>::DeletedList;
LinkedList<GraphicsShaderLightTallyNode> LinkedList<GraphicsShaderLightTallyNode>::DeletedList;
LinkedList<GraphicsShaderLightPtr> LinkedList<GraphicsShaderLightPtr>::DeletedList("Deleted list for GraphicsShaderLightPtr");

void GraphicsBase::RenderTextBlock(String ^p_block, GameFont ^p_font, float p_startX, float p_startY, GameColor &p_color)
{
	array<String^, 1> ^separator = { "\n" };
	array<String ^,1> ^lines = p_block->Split(separator, StringSplitOptions::None);
	RenderTextLines(lines, p_font, p_startX, p_startY, p_color);
}

void GraphicsBase::RenderTextBlock(String ^p_block, GameFont ^p_font, int p_startX, int p_startY, GameColor &p_color)
{
	RenderTextBlock(p_block, p_font, float(p_startX), float(p_startY), p_color);
}

void GraphicsBase::RenderTextLines(array<String^, 1> ^p_lines, GameFont ^p_font, float p_startX, float p_startY, GameColor &p_color)
{
	p_font->Load();

	float x = p_startX;
	float y = p_startY;
	for each (String ^line in p_lines)
	{
		RenderFont(line, p_font, x, y, p_color);
		y += p_font->GetHeight();
	}
}

void GraphicsBase::RenderTextLines(array<String^, 1> ^p_lines, GameFont ^p_font, int p_startX, int p_startY, GameColor &p_color)
{
	RenderTextLines(p_lines, p_font, float(p_startX), float(p_startY), p_color);
}

void GraphicsBase::BuildViewFrustum(Orient3d &p_viewOrient, Frustum *p_frustum, float p_scale, bool p_left, StereoscopicCamera *p_camera)
{
	// p_scale is usually 1.0f, onyl changed for demonstration (ie displaying a partial view frustum)

	// works with a usual projection or anaglyph
	// ortho currently not supported

	// note: as long as the planes face the proper direction, the order in which they are added does not matter.  It's when they face backwards that you get an empty result.

	// note: This routine is usually called with a proper p_viewOrient, not a mirror reflected one.  However, if p_viewOrient is mirror reflected, l will be facing the wrong way
	//  for the Cross products.  todo: determine the correct way to calculate the crossproduct with a flipped l considering frustumData.left and right, and create an alternate if block
	//  for the calculation.

	p_frustum->Initialize();
	if (p_camera == nullptr)
	{
		p_frustum->SetOrigin(p_viewOrient.p);
		p_frustum->AddPlane((p_viewOrient.l.ScalarMult(-frustumData.left * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)).CrossProd(p_viewOrient.u));
		p_frustum->AddPlane(p_viewOrient.u.CrossProd(p_viewOrient.l.ScalarMult(-frustumData.right * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)));
		p_frustum->AddPlane(p_viewOrient.l.CrossProd(p_viewOrient.u.ScalarMult(frustumData.top * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)));
		p_frustum->AddPlane((p_viewOrient.u.ScalarMult(frustumData.bottom * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)).CrossProd(p_viewOrient.l));
	}
	else
	{
		if (p_left == true)
			p_frustum->SetOrigin(p_camera->CorrectedEyePositionLeft(p_viewOrient));
		else
			p_frustum->SetOrigin(p_camera->CorrectedEyePositionRight(p_viewOrient));
		p_frustum->AddPlane((p_viewOrient.l.ScalarMult(-frustumData.left * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)).CrossProd(p_viewOrient.u));
		p_frustum->AddPlane(p_viewOrient.u.CrossProd(p_viewOrient.l.ScalarMult(-frustumData.right * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)));
		p_frustum->AddPlane(p_viewOrient.l.CrossProd(p_viewOrient.u.ScalarMult(frustumData.top * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)));
		p_frustum->AddPlane((p_viewOrient.u.ScalarMult(frustumData.bottom * p_scale) + p_viewOrient.f.ScalarMult(frustumData.nearPlane)).CrossProd(p_viewOrient.l));
	}
}