#pragma once

#define FPSTEST_VERSIONSTRING "0.99.001" // app version for display
// guid format ............ "12345678-1234-1234-1234-123456789012"
#define FPSTEST_VERSIONGUID "4jkl2kj3-42es-gser-y45f-sdfsggdsf001" // verification for network login
#define FPSTEST_HOSTINGPORT 26010

#include "..\Headers\GameBase.h"
#include "..\Headers\GameApplicationContext.h"
#include "..\Headers\GameContext.h"
#include "..\Headers\Tools.h"
#include "..\Headers\GameNetwork.h"
#include "..\Headers\GameUI.h"
#include "..\Headers\Model.h"
#include "..\Headers\JointedModel.h"
#include "..\Headers\SkyBox.h"
#include <vcclr.h> // gcroot

namespace GameEngDev {

	using namespace GameEng::Game;
	using namespace GameEng::Tools::Timer;
	using namespace GameEng::Network;
	using namespace System::Drawing; // FontStyle
	using namespace GameEng::Graphics; // Model3d, JointedModel3d

	public class FPSPlayerAvatar
	{
	public:
		Vector3d position;
		Vector3d velocity;

		GameColor color;

		Vector3d targetVelocity; // velocity interpolates to this over time in Animate()

		////////////
		// controls
		bool forward;
		bool backward;
		bool left;
		bool right;
		// either crouch or prone or both false
		bool crouch;
		bool prone;
		// can't run while crouched or prone
		bool run;
		bool shoot; // is gun firing?

	private:
		// priorControls
		bool priorForward;
		bool priorBackward;
		bool priorLeft;
		bool priorRight;
		// either crouch or prone or both false
		bool priorCrouch;
		bool priorProne;
		// can't run while crouched or prone
		bool priorRun;
		bool priorShoot; // is gun firing?
		///////////

	public:
		float radius; // it's a square, so this is from center to an orthogonal edge.

		float health; // if this is > 0.0, you're standing
		float downedHealth; // health while downed - once this reaches zero, you're dead

		void Initialize(RectangleF &p_bounds)
		{
			Restore(p_bounds);
		}

		void Restore(RectangleF &p_bounds)
		{
			CancelControls();

			// center for now
			velocity = Vector3d::ZeroVector();
			targetVelocity = Vector3d::ZeroVector();
			position = Vector3d(p_bounds.Left + p_bounds.Width / 2.0f, p_bounds.Top + p_bounds.Height / 2.0f, 0.0f);

			radius = 10.0f;

			HealFull();
		}

		void CancelControls()
		{
			forward = false;
			backward = false;
			left = false;
			right = false;
			crouch = false;
			prone = false;
			run = false;
			shoot = false;
		}

		void RecordPriorControls()
		{
			priorForward = forward;
			priorBackward = backward;
			priorLeft = left;
			priorRight = right;
			priorCrouch = crouch;
			priorProne = prone;
			priorRun = run;
			priorShoot = shoot;
		}

		bool ControlsChanged()
		{
			return (
				priorForward != forward ||
				priorBackward != backward ||
				priorLeft != left ||
				priorRight != right ||
				priorCrouch != crouch ||
				priorProne != prone ||
				priorRun != run ||
				priorShoot != shoot
			);
		}

		void HealFull()
		{
			health = 100.0f;
			downedHealth = 100.0f;
		}

		void Animate(float p_elapsedTimeMS, RectangleF &p_bounds)
		{
			// keep avatar within bounds
			// move vector towards target vector at a specific linear rate
			// animate per ms to keep things consistent, check collisions against final position after all ms consumed.
			targetVelocity = Vector3d::ZeroVector();
			float runFactor = 1.5f;
			bool zero = true;
			bool runConsidered = false;
			// forwad/backward max one is set, left/right max one is set
			if (forward == true)
			{
				zero = false;
				if (run == false)
					targetVelocity = targetVelocity + Vector3d(0.0f, -1.0f, 0.0f);
				else
				{
					targetVelocity = targetVelocity + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(runFactor);
					runConsidered = true;
				}
			}
			if (backward == true)
			{
				zero = false;
				if (run == false)
					targetVelocity = targetVelocity + Vector3d(0.0f, 1.0f, 0.0f);
				else
				{
					targetVelocity = targetVelocity + Vector3d(0.0f, 1.0f, 0.0f).ScalarMult(runFactor);
					runConsidered = true;
				}
			}
			if (left == true)
			{
				zero = false;
				targetVelocity = targetVelocity + Vector3d(-1.0f, 0.0f, 0.0f);
			}
			if (right == true)
			{
				zero = false;
				targetVelocity = targetVelocity + Vector3d(1.0f, 0.0f, 0.0f);
			}
			float maxNormalSpeed = 0.2f;
			if (zero == false)
			{
				targetVelocity.Normalize();
				if (runConsidered == true)
					targetVelocity = targetVelocity.ScalarMult(runFactor);
				targetVelocity = targetVelocity.ScalarMult(maxNormalSpeed);
			}

			// get offset vector and time from current velocity to targetVelocity
			Vector3d offset = targetVelocity - velocity;
			bool interpolateVelocity = false;
			float timeToReachTargetVelocityMS = 0;
			float interpolateAmountPerMS = maxNormalSpeed / 250.0f; // 1/4 second to reach max speed from standstill
			if (offset.Normalize() == true)
			{
				interpolateVelocity = true;
				timeToReachTargetVelocityMS = (offset * (targetVelocity - velocity)) / interpolateAmountPerMS;
				offset = offset.ScalarMult(interpolateAmountPerMS);
			}
			else
				velocity = targetVelocity; // zero difference effectively, so just set velocity = target

			// todo: handle remainder

			int timeToConsumeMS = int(p_elapsedTimeMS);
			while (timeToConsumeMS > 0)
			{
				timeToConsumeMS -= 1;

				// interpolate velocity 1ms
				if (interpolateVelocity == true)
				{
					velocity = velocity + offset;

					timeToReachTargetVelocityMS -= 1.0f;
					if (timeToReachTargetVelocityMS <= 0.0f)
					{
						// done interpolating, set to target exactly
						velocity = targetVelocity;
						interpolateVelocity = false;
					}
				}

				// move 1ms
				position = position + velocity;
			}

			// shooting is handled in main game loop since it involves firing a bullet in the playfield
		}

		bool CanBeControlled()
		{
			return (health > 0.0f && downedHealth > 0.0f);
		}
	};

	// used by AsteroidsMessageList to render its contents
	public class FPSGameRenderMessage
	{
	public:
		// not rendered
		int line; // which message is this a part of? (line = 0, 1, 2 are messages 0, 1, 2 from the original list - not really lines 0, 1, 2)
		int feed; // which line feed within a message is this? (helps with location evaluation on the post parse
		float textHeight; // used to determine where to render a line (tall fonts shift the whole line down - nothing is centered vertically on a line)

		// rendered
		gcroot<String ^> message; // format string <color=ffddee> </color> <b></b> <font=Info></font> - note: font overrides font used by <b>
		gcroot<GameFont ^> fontRef;
		PointF location; // screen location to render
		GameColor color; // base color - alpha is determined during rendering - that way restore colors are less complicated
		float lifeMS; // helps with determination of alpha at render time (color is modulated by it)
		Point textSize; // might as well track this since we need to do multiple parses on the data
	};

	public class FPSGameMessage
	{
	public:
		gcroot<String ^> message; // format string <color=ffddee> </color> <b></b> <font=Info></font> - note: font overrides font used by <b>
		float lifeMS; // counts down to zero, last 500ms fades out
		bool persistAfterFade; // don't destroy after it fades out, so it can be rendered in a different mode

		void Initialize()
		{
			message = "";
			lifeMS = 0.0f;
			persistAfterFade = false;
		}

		void SetMessageAndLife(String ^p_message, float p_lifeMS = 4000.0f, bool p_persistAfterFade = false)
		{
			message = p_message;
			lifeMS = p_lifeMS;
			persistAfterFade = p_persistAfterFade;
		}

	};

	public class FPSGameMessageTag
	{
	public:
		gcroot<String ^> tag;

		// values to restore
		GameColor restoreColor;
		gcroot<GameFont ^> restoreFont;
	};

	// rules:  tags must be nested properly.  does NOT support straddled tags.  
	// Ex:  "<b><color=ff45223>Hello I am the smart</color></b>" is valid. 
	// "<color=ff><font=Big>Derp derp</b></color>derp" is not,
	// and will be rendered as "Derp derp</b></color>derp" entirely as blue and bold because the tags weren't properly terminated
	public class FPSGameMessageList
	{
	private:
		GameColor defaultColor;
		gcroot<GameFont^> defaultNormalFontRef;
		gcroot<GameFont^> defaultBoldFontRef;

		LinkedList<FPSGameMessage> messages;
		RectangleF outputRectangle; // coordinates of where output gooes (1st message is on bottom, message beyond top don't get displayed, sentences wrap)

		float messageLifeMS;
		float messageBeginFadeMS;

	public:
		FPSGameMessageList(GameColor &p_defaultColor, GameFont ^p_defaultNormalFont, GameFont ^p_defaultBoldFont, float p_messageLifeMS = 4000.0f, float p_messageBeginFadeMS = 500.0f)
		{
			defaultColor = p_defaultColor;
			defaultNormalFontRef = p_defaultNormalFont;
			defaultBoldFontRef = p_defaultBoldFont;

			messageLifeMS = p_messageLifeMS;
			messageBeginFadeMS = p_messageBeginFadeMS;
		}

		void SetFonts(GameFont ^p_defaultNormalFont, GameFont ^p_defaultBoldFont)
		{
			defaultNormalFontRef = p_defaultNormalFont;
			defaultBoldFontRef = p_defaultBoldFont;
		}

		~FPSGameMessageList()
		{
			// nothing needs destroying
		}

		void Clear()
		{
			messages.Clear();
		}

		// note: message is a tagged message (colors, bold, etc.), which might wrap when it's rendered
		// later messages are earlier in the list, so the first nodes render the lowest on the screen
		// Each insertion here represents a single message.  The render list built in Render() is arranged so that the parsing properly coarses through text to position the elements properly
		void AddMessage(String ^p_message, bool p_persistAfterFade = false)
		{
			LinkedListNode<FPSGameMessage> *newNode = messages.GetNewNode();
			newNode->data.Initialize();
			newNode->data.SetMessageAndLife(p_message, messageLifeMS, p_persistAfterFade);
			messages.InsertNode(newNode);
		}

		// elapsed time in this case is not dependent on game time as updated by the server - this is an independent game time.
		void Animate(float p_elapsedTimeMS)
		{
			LinkedListNode<FPSGameMessage> *messageNode = messages.GetFirstNode();
			if (messageNode != nullptr)
			{
				while (messageNode != &(messages.footer))
				{
					LinkedListNode<FPSGameMessage> *nextNode = messageNode->next;
					if (messageNode->data.lifeMS <= p_elapsedTimeMS)
					{
						if (messageNode->data.persistAfterFade == false)
							messages.DeleteNode(messageNode);
						else
							messageNode->data.lifeMS = 0.0f;
					}
					else
						messageNode->data.lifeMS -= p_elapsedTimeMS;

					messageNode = nextNode;
				}
			}
		}

		void Render(GraphicsBase *p_graphics, RectangleF &p_outputRectangle, int p_backgroundOffset, bool p_showPersistedMessages = false)
		{
			// todo:
			// if there are no new lines, none have been removed, and the shape of the outputRectangle (mroe notably its Width) has not changed, there is no reason to re-evaluate the
			//   render lines except to calculate their alpha again.
			// So for an upgrade, respond to appropriate changes and only re-evaluate or calculate what is necessary to accommodate the change.

			// assemble a render list of messages based on the output rectangle, lines are noted by the line number on each render node - line numbers will be together
			// a single line can be made up of different fonts, so the textheight for the line will be the tallest font, which then determines the y coordinate to render at for the whole line.

			// split by tags to determine attributes for each, start a new line of text when the current text wraps past the outputbox, stop when the bottom of the next line to render is
			// above the output box.
			// build a line with fonts and tagless text until a space or full word clips the end of the box, then start a new line, removing the space if the space caused the wrap.
			// spaces, dashes, periods and commas divide words.  dashes, periods and commas remain part of the word and wrap with the word if it clips the end of the box.
			// tags that don't evaluate validly are rendered exactly as they are, including a terminating tag (with no <b>, a </b> tag renders as is)
			// use stencil to clip upper vertical contents?  Is there a point to it?

			// how to render messages (will be discarded afterwards)
			LinkedList<FPSGameRenderMessage> renderMessages; // text here 

			// parse data, building the render data
			LinkedListEnumerator<FPSGameMessage> messageEnumerator = LinkedListEnumerator<FPSGameMessage>(messages);
			LinkedList<FPSGameMessageTag> tags;
			int currentLine = 1; // message, actually, not line, since a line is cut into feeds later
			float currentX = p_outputRectangle.Left; // never changes
			float currentY = p_outputRectangle.Bottom; // Y is always at the BOTTOM of the current line being worked, and will be changed when EvaluateLine is called.  Messages work their way up
			GameRichTextList richText;
			float lifeMS;
			bool skipped = false;
			while (messageEnumerator.MoveNext())
			{
				if (currentLine > 1 && skipped == false)
				{
					// Handle line feeds due of clipping right side, handle y coordinate placement, determine next Y to start at for future lines
					EvaluateLine(richText, renderMessages, currentLine - 1, p_outputRectangle.Width, currentX, currentY, lifeMS);
					richText.Clear();
				}
				skipped = false;

				FPSGameMessage *gameMessage = &(messageEnumerator.Current()->data);
				lifeMS = gameMessage->lifeMS;
				if (p_showPersistedMessages == true && gameMessage->persistAfterFade == true)
					lifeMS = messageBeginFadeMS + 1.0f; // render as solid
				if (lifeMS == 0.0f)
				{
					// don't work on a faded message (might be persisted)
					skipped = true;
					continue;
				}
				int startIndex = 0;

				// reset tags for each gameMessage
				GameFont ^currentFont = defaultNormalFontRef;
				GameColor currentColor = defaultColor;

				bool done = false;
				while (done == false)
				{
					// split up this line.
					// each iteration, startIndex advances.
					int nextTagStart = gameMessage->message->IndexOf("<", startIndex);
					if (nextTagStart >= startIndex)
					{
						// collect as much as we can before we investigate an actual tage
						// watch for another tag (we dont' support nesting, so if we find more before a > just add it
						bool done = false;
						while (done == false)
						{
							// if find false tags (not supporting nesting), continue advancing until we find a suspected true tag strength between <>
							// ex. <<<color> ignore the first two << and prepare to collect the <color> string
							int tagStart = gameMessage->message->IndexOf("<", nextTagStart + 1);
							int tagEnd = gameMessage->message->IndexOf(">", nextTagStart + 1);
							if (tagStart >= 0 && tagEnd > tagStart)
							{
								nextTagStart = tagStart;
							}
							else
								break;
						}
					}
					if (nextTagStart >= startIndex)
					{
						if (nextTagStart > startIndex) // not an empty string before the <
							richText.AddText(gameMessage->message->Substring(startIndex, nextTagStart - startIndex), currentFont, currentColor);

						int nextTagEnd = gameMessage->message->IndexOf(">", nextTagStart);
						if (nextTagEnd < 0)
						{
							// tag not terminated, just add the remaining text
							richText.AddText(gameMessage->message->Substring(nextTagStart), currentFont, currentColor);

							currentLine++;
							break;;
						}
						else
						{
							startIndex = nextTagEnd + 1;

							// get tag
							bool valid = false; // if remains false, skip the tag and add it as text
							String ^tagText = gameMessage->message->Substring(nextTagStart + 1, nextTagEnd - nextTagStart - 1); // strip off < and >
							String ^trimmedTag = tagText->Trim()->ToLower();
							if (trimmedTag->Substring(0, 1) == "/")
							{
								// it's a terminating tag - see if it matches the last tag
								String ^tag = trimmedTag->Substring(1);
								if (tags.GetLastNode() != nullptr)
								{
									if (tags.GetLastNode()->data.tag == tag) // if it matchs it's one of the three below or something went very wrong
									{
										if (tag == "b" || tag == "font")
										{
											currentFont = tags.GetLastNode()->data.restoreFont;
										}
										else if (tag == "color")
										{
											currentColor = tags.GetLastNode()->data.restoreColor;
										}

										valid = true;

										// remove last node
										RemoveLastTag(tags);
									}
								}
							}
							else
							{
								// it's a starting tag - see if it's valid
								String ^token = "b";
								if (valid == false)
								{
									if (trimmedTag == token)
									{
										AddTag(tags, trimmedTag, currentColor, currentFont);
										currentFont = defaultBoldFontRef;
										valid = true;
									}
								}
								if (valid == false)
								{
									token = "font=";
									if (trimmedTag->StartsWith(token))
									{
										AddTag(tags, "font", currentColor, currentFont);
										String ^fontName = trimmedTag->Substring(token->Length)->Trim();
										if (GameContext::Instance->FontRegistry.FontExists(fontName) == true)
											currentFont = GameContext::Instance->FontRegistry.GetFont(fontName);
										valid = true;
									}
								}
								if (valid == false)
								{
									token = "color=";
									if (trimmedTag->StartsWith(token))
									{
										AddTag(tags, "color", currentColor, currentFont);
										String ^color = trimmedTag->Substring(token->Length)->Trim();
										if (GameColor::FromHexStringIsValid(color) == true)
											currentColor = GameColor::FromHexString(color);
										valid = true;
									}
								}
							}

							if (valid == false)
							{
								// no valid result, just add the tag as text
								richText.AddText("<" + tagText + ">", currentFont, currentColor);
							}
						} // there is a full tag (not verified as valid yet)
					}
					else
					{
						// no tag, just add text
						richText.AddText(gameMessage->message->Substring(startIndex), currentFont, currentColor);

						currentLine++;
						break;
					}

					// we hit this if the string ends with a tag terminator.
					if (startIndex >= gameMessage->message->Length)
					{
						// no more string left
						currentLine++;
						break;
					}
				} // parsing line with tags

				tags.Clear();
			}
			// evaluate final line
			if (currentLine > 1 && skipped == false)
				EvaluateLine(richText, renderMessages, currentLine - 1, p_outputRectangle.Width, currentX, currentY, lifeMS);

			// render it all
			// background
			LinkedListEnumerator<FPSGameRenderMessage> renderMessageEnumerator = LinkedListEnumerator<FPSGameRenderMessage>(renderMessages);
			while (renderMessageEnumerator.MoveNext())
			{
				FPSGameRenderMessage *renderMessage = &(renderMessageEnumerator.Current()->data);

				GameColor renderColor = GameColor::Interpolate(renderMessage->color, GameColor(0, 0, 0), 0.75f);
				//GameColor renderColor = GameColor::Interpolate(renderMessage->color, GameColor(255, 255, 255), 0.50f);
				if (renderMessage->lifeMS < messageBeginFadeMS)
				{
					renderColor.alpha = int(float(renderColor.alpha) * renderMessage->lifeMS / messageBeginFadeMS);
				}
				p_graphics->RenderFont(renderMessage->message, renderMessage->fontRef, float(int(renderMessage->location.X + float(p_backgroundOffset) + 0.01f)), float(int(renderMessage->location.Y + float(p_backgroundOffset) + 0.01f)), renderColor);
			}
			// foreground
			renderMessageEnumerator = LinkedListEnumerator<FPSGameRenderMessage>(renderMessages);
			while (renderMessageEnumerator.MoveNext())
			{
				FPSGameRenderMessage *renderMessage = &(renderMessageEnumerator.Current()->data);

				GameColor renderColor = renderMessage->color;
				if (renderMessage->lifeMS < messageBeginFadeMS)
				{
					renderColor.alpha = int(float(renderColor.alpha) * renderMessage->lifeMS / messageBeginFadeMS);
				}
				// float(int()) cleans up a float to a whole number, otherwise characters under the character in the texture could show
				p_graphics->RenderFont(renderMessage->message, renderMessage->fontRef, float(int(renderMessage->location.X)), float(int(renderMessage->location.Y)), renderColor);
			}
		}

	private:
		void AddTag(LinkedList<FPSGameMessageTag> &p_tagList, String ^p_tag, GameColor &p_restoreColor, GameFont ^p_restoreFont)
		{
			// tag has qualifers stripped off (color=xxxxxx becomes color)
			LinkedListNode<FPSGameMessageTag> *newNode = p_tagList.GetNewNode();
			newNode->data.tag = p_tag;
			newNode->data.restoreColor = p_restoreColor;
			newNode->data.restoreFont = p_restoreFont;
			p_tagList.AddNode(newNode);
		}

		void RemoveLastTag(LinkedList<FPSGameMessageTag> &p_tagList)
		{
			if (p_tagList.GetLastNode() != nullptr)
				p_tagList.DeleteNode(p_tagList.GetLastNode());
		}

		// test:
		// try a simple line with no tags
		// try a long word that cuts-
		// try a line with a lot of spaces
		// try a line with many tags, etc.
		void EvaluateLine(GameRichTextList &p_richText, LinkedList<FPSGameRenderMessage> &p_renderMessages, int p_line, float p_maxWidth, float p_startX, float &p_renderY, float p_lifeMS)
		{
			// for clarity, a line represents a single long Asteroids message.  a feed is each line for that message split up because of the output rectangle
			// all line nodes are together, as are each feed, with the lower screen lines appearing after the upper ones, and the first node for each feed being the left most on the screen.

			// renderY represents the BOTTOM of the line currently
			// go through entire line, forcing new lines and raising text, and making sure the bottom Y of all text on a single line are equal
			// and return the Y for the bottom of the next line up (or top of the tallest font of the upper most line evaluated here) for new text.
			// New nodes can be put anywhere in the list since everything is rendered by coordinate, so ordering doesn't matter

			// find first node with that line number (this can be sped up by keeping it determined in the main loop) - there will be multiple nodes for a line depending on how tags affected colors, fonts, etc.
			// parse forward through nodes (earliest nodes are earliest text).  On each node, set feed = currentFeed
			// when a line feed is required, split the text in the current node and insert the duplicate node with the latter part of the text after the current node, currentFeed++ -
			//    can't lift the y's from the prior line until we know the tallest text in the new feed.  So evaluate all the y's backwards after all the feeds are done
			// Splitting the text is the hard part.  Track current word.  Words are split on . , - and space.  Spaces are consumed by the line feed, at the end of the prior line and the beginning of the new one.
			// parsing backwards, start with bottomY = Y of farthest feed forward.  when evaluating a finished feed, for each bit of text, set render y = bottomY - textHeight, collect tallestTextHeight, and when encoutner the next feed up,
			//    set bottomY for next line up = bottomY - tallestTextHeight and keep going
			// splitting is now done by Graphics->WrapText()
			if (p_richText.IsEmpty())
				return; // nothing to do

			LinkedList<GameLinedRichText> linedRichText;
			GameFontHelper::WrapText(p_richText, linedRichText, int(p_maxWidth));

			// move lined rich text nodes over to the render list, working up (later nodes are higher on the screen)
			LinkedListEnumerator<GameLinedRichText> linedEnumerator = LinkedListEnumerator<GameLinedRichText>(linedRichText);
			LinkedListNode<FPSGameRenderMessage> *firstLineNode = nullptr;
			LinkedListNode<FPSGameRenderMessage> *lastLineNode = nullptr;
			LinkedListNode<FPSGameRenderMessage> *insertAfter = nullptr;
			while (linedEnumerator.MoveNext())
			{
				LinkedListNode<FPSGameRenderMessage> *newNode = p_renderMessages.GetNewNode();
				newNode->data.color = linedEnumerator.Current()->data.foreColor;
				newNode->data.line = p_line;
				newNode->data.feed = linedEnumerator.Current()->data.line;
				newNode->data.fontRef = linedEnumerator.Current()->data.fontRef;
				newNode->data.lifeMS = p_lifeMS;
				newNode->data.message = linedEnumerator.Current()->data.text;
				newNode->data.textHeight = float(linedEnumerator.Current()->data.textSize.Y);
				newNode->data.textSize = linedEnumerator.Current()->data.textSize;
				p_renderMessages.InsertNode(newNode, insertAfter);
				if (firstLineNode == nullptr)
					firstLineNode = newNode;
				insertAfter = newNode;
				lastLineNode = newNode;
			}

			//////////////////////////////////////
			// now calculate X and Y renders for the nodes.  First node of a given feed always starts at startX.  Each feed has a bottomY.  The last feed starts at p_renderY - tallestText for the feed, 
			//    the prior feed adjust Y upward by tallestText for the current feed, and repeat until all feeds' Y's are set
			// first, set up text sizes

			// now, start with last node, establish render positions
			LinkedListNode<FPSGameRenderMessage> *node = lastLineNode;
			bool done = false;
			float bottomY = p_renderY;
			while (done == false)
			{
				LinkedListNode<FPSGameRenderMessage> *lastFeedNode = node;
				int currentFeed = node->data.feed;

				// find first node of feed
				LinkedListNode<FPSGameRenderMessage> *firstFeedNode = nullptr;
				while (node->data.feed == currentFeed)
				{
					firstFeedNode = node;
					if (node == firstLineNode) // if hit first node for line, break out
						break;
					node = node->prev;
				}
				// node is now last feed node of next feed up, for next loop iteration

				// set X's and establish tallest Text height
				// center the text
				LinkedListNode<FPSGameRenderMessage> *parseNode = firstFeedNode;
				int totalTextWidth = 0;
				while (parseNode->data.feed == currentFeed) // redundant, but we are sticking within the feed
				{
					totalTextWidth += parseNode->data.textSize.X;

					if (parseNode == lastFeedNode)
						break;

					parseNode = parseNode->next;
				}
				// start so that text is centered in area
				float x = p_startX + float(int((p_maxWidth - float(totalTextWidth)) / 2.0f)); // no half pixels, so int it - otherwise just start at p_startX
				int tallestTextHeight = 0;
				parseNode = firstFeedNode;
				while (parseNode->data.feed == currentFeed) // redundant, but we are sticking within the feed
				{
					parseNode->data.location.X = x;
					x += float(parseNode->data.textSize.X);
					// force text to be flush with bottom
					parseNode->data.location.Y = float(bottomY) - float(parseNode->data.textSize.Y);
					if (parseNode->data.textSize.Y > tallestTextHeight)
						tallestTextHeight = parseNode->data.textSize.Y;

					if (parseNode == lastFeedNode)
						break;

					parseNode = parseNode->next;
				}
				bottomY -= float(tallestTextHeight);

				if (firstFeedNode == firstLineNode) // if hit first node for line, break out, we are all done
				{
					p_renderY = bottomY; // tell main loop Y moved up
					break;
				}
			}
		}
	};

	enum class FPSGameType
	{
		None,
		SinglePlayer,
		Multiplayer
	};

	enum class FPSGameCameraMode
	{
		Spectate,
		Track,
		Stationary
	};

	public class TestFPSAvatar
	{
	public:

		float pitchAngle;
		float rotationAngle;

		Orient3d orient; // object's main position
		JointedModel3d *jointedModelRef; // which model are we using to render?
		Orient3d jointOrients[12]; // avatar only uses 8, but just in case
		int jointOrientQty;
		// interpolated to reach targetVelocity
		Vector3d velocity;
		Vector3d targetVelocity;

		JointedModelAnimationTracker bodyAnimationTracker;
		JointedModelAnimationTracker gunAnimationTracker;

		float health;

		bool run;

		// control events
		bool crouch;
		bool prone;
		bool scope;

		// avatar states
		bool standing;
		bool crouching;
		bool proning;
		bool scoping;

		bool priorStanding;
		bool priorCrouching;
		bool priorProning;
		bool priorScoping;

		// moving
		bool forward;
		bool backward;
		bool left;
		bool right;

		bool priorForward;
		bool priorBackward;
		bool priorLeft;
		bool priorRight;

		bool shoot;

		void Initialize(JointedModel3d *p_jointedModelRef)
		{
			// it's expected currently that p_jointedModelRef is the avatarJointedModel that was initialized, so we
			//   know exactly which orients to initialize and why
			jointedModelRef = p_jointedModelRef;
			jointOrientQty = 12;

			bodyAnimationTracker.SetAnimation(p_jointedModelRef->GetAnimation(0)); // standing
			gunAnimationTracker.SetAnimation(p_jointedModelRef->GetAnimation(4)); // non scope
			// stance states match animations set
			standing = true;
			crouching = false;
			proning = false;
			scoping = false;

			bodyAnimationTracker.InitializeStance(jointOrients);
			gunAnimationTracker.InitializeStance(jointOrients);

			// orients not covered by animations
			jointOrients[3].LoadIdentity();
			jointOrients[6].LoadIdentity();

			orient.LoadIdentity();
			velocity = Vector3d::ZeroVector();
			targetVelocity = Vector3d::ZeroVector();

			pitchAngle = 0;
			rotationAngle = 0;

			health = 100.0f;

			ResetMoveControls();
		}

	private:
		void SetHeadAndGunPitch(float p_pitchAngle)
		{
			// head and gun pitch orients are 3 and 6
			jointOrients[3].LoadIdentity();
			jointOrients[6].LoadIdentity();

			jointOrients[3].Rotate(jointOrients[3].l, p_pitchAngle);
			jointOrients[6].Rotate(jointOrients[6].l, p_pitchAngle);
		}

	public:

		bool CanBeControlled()
		{
			return (health > 0.0f);
		}

		void RecordPriorMoveControls()
		{
			priorForward = forward;
			priorBackward = backward;
			priorLeft = left;
			priorRight = right;
		}

		void ResetMoveControls()
		{
			forward = false;
			backward = false;
			left = false;
			right = false;

			run = false;
			shoot = false;
		}

		void ApplyMouseOffsets(int p_offsetX, int p_offsetY)
		{
			float mouseSensitivity = 0.2f;
			rotationAngle += float(p_offsetX) * mouseSensitivity;
			pitchAngle -= float(p_offsetY) * mouseSensitivity; // flipped

			if (pitchAngle < -90.0f)
				pitchAngle = -90.0f;
			if (pitchAngle > 90.0f)
				pitchAngle = 90.0f;

			while (rotationAngle >= 360.0f)
				rotationAngle -= 360.0f;
			while (rotationAngle < 0.0f)
				rotationAngle += 360.0f;

			Vector3d oldP = orient.p;
			orient.LoadIdentity();
			orient.Rotate(orient.u, rotationAngle);
			orient.p = oldP;
			SetHeadAndGunPitch(pitchAngle);
		}

		void ResetStanceControls()
		{
			crouch = false;
			prone = false;
			scope = false;
		}

		void ApplyCrouch(bool p_crouch)
		{
			crouch = p_crouch;
		}

		void ApplyProne(bool p_prone)
		{
			prone = p_prone;
		}

		void ApplyScoping(bool p_scoping)
		{
			scope = p_scoping;
		}
		
		// todo: don't allow rapid fire stand/prone/crouch - don't use control if it hasn't been lifted since the last use
		void ApplyControls()
		{
			// activate animations based on controls
			if (proning == true && prone == true)
			{
				proning = false;
				standing = true;
				crouching = false;
				bodyAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(0), 0.0f);
			}
			else if (proning == true && crouch == true)
			{
				proning = false;
				standing = false;
				crouching = true;
				bodyAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(2), 0.0f); // slow crouch
			}
			else if (crouching == true && crouch == true)
			{
				proning = false;
				standing = true;
				crouching = false;
				bodyAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(0), 0.0f);
			}
			else if (crouching == true && prone == true)
			{
				proning = true;
				standing = false;
				crouching = false;
				bodyAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(3), 0.0f);
			}
			else if (standing == true && prone == true)
			{
				proning = true;
				standing = false;
				crouching = false;
				bodyAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(3), 0.0f);
			}
			else if (standing == true && crouch == true)
			{
				proning = false;
				standing = false;
				crouching = true;
				bodyAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(1), 0.0f);
			}

			if (scoping == true && scope == true)
			{
				scoping = false;
				gunAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(4), 0.0f);
			}
			else if (scoping == false && scope == true)
			{
				scoping = true;
				gunAnimationTracker.SetAnimation(jointedModelRef->GetAnimation(5), 0.0f);
			}
		}

		void Animate(float p_elapsedTimeMS)
		{
			bodyAnimationTracker.Animate(p_elapsedTimeMS, jointOrients);
			gunAnimationTracker.Animate(p_elapsedTimeMS, jointOrients);

			// move with acceleration
			// consider run, prone, crouch for final speed
			// todo: also, consider state of animation - should be fully standing to run, not suddenly run when start to stand
			// todo:
			// keep avatar within bounds
			// move vector towards target vector at a specific linear rate
			// animate per ms to keep things consistent, check collisions against final position after all ms consumed.
			targetVelocity = Vector3d::ZeroVector();
			Vector3d forwardVector = orient.f;
			Vector3d leftVector = orient.l;
			float runFactor = 1.5f;
			bool zero = true;
			bool runConsidered = false;
			// forward/backward max one of them is set, left/right max one of them is set
			if (forward == true)
			{
				zero = false;
				if (run == false || proning == true || crouching == true || scoping == true)
					targetVelocity = targetVelocity + forwardVector;
				else
				{
					targetVelocity = targetVelocity + forwardVector.ScalarMult(runFactor);
					runConsidered = true;
				}
			}
			if (backward == true)
			{
				zero = false;
				if (run == false || proning == true || crouching == true || scoping == true)
					targetVelocity = targetVelocity - forwardVector;
				else
				{
					targetVelocity = targetVelocity - forwardVector.ScalarMult(runFactor);
					runConsidered = true;
				}
			}
			if (left == true)
			{
				zero = false;
				targetVelocity = targetVelocity + leftVector;
			}
			if (right == true)
			{
				zero = false;
				targetVelocity = targetVelocity - leftVector;
			}
			float maxNormalSpeed = 0.00146f; // approximate human run speed when running (15mph) otherwise a hustle
			if (zero == false)
			{
				targetVelocity.Normalize();

				float speedToApply = maxNormalSpeed;
				if (proning == true)
					speedToApply = speedToApply * 0.25f;
				if (crouching == true || scoping == true)
					speedToApply = speedToApply * 0.5f;
				if (runConsidered == true)
					targetVelocity = targetVelocity.ScalarMult(runFactor);
				targetVelocity = targetVelocity.ScalarMult(speedToApply);
			}

			// get offset vector and time from current velocity to targetVelocity
			Vector3d offset = targetVelocity - velocity;
			bool interpolateVelocity = false;
			float timeToReachTargetVelocityMS = 0;
			float interpolateAmountPerMS = maxNormalSpeed / 250; // 1/4 second to reach max speed from standstill
			if (offset.Normalize() == true)
			{
				interpolateVelocity = true;
				timeToReachTargetVelocityMS = (offset * (targetVelocity - velocity)) / interpolateAmountPerMS;
				offset = offset.ScalarMult(interpolateAmountPerMS);
			}
			else
				velocity = targetVelocity; // zero difference effectively, so just set velocity = target

			// todo: handle remainder

			int timeToConsumeMS = int(p_elapsedTimeMS);
			while (timeToConsumeMS > 0)
			{
				timeToConsumeMS -= 1;

				// interpolate velocity 1ms
				if (interpolateVelocity == true)
				{
					velocity = velocity + offset;

					timeToReachTargetVelocityMS -= 1.0f;
					if (timeToReachTargetVelocityMS <= 0.0f)
					{
						// done interpolating, set to target exactly
						velocity = targetVelocity;
						interpolateVelocity = false;
					}
				}

				// move 1ms
				orient.p = orient.p + velocity;
			}

			// shooting is handled in main game loop since it involves firing a bullet in the playfield
		}

		void Render(GraphicsBase *p_graphics)
		{
			// todo: use shader!
			p_graphics->PushMatrix();
			p_graphics->Transform(orient);
			jointedModelRef->Render(*p_graphics, jointOrients, jointOrientQty);
			p_graphics->PopMatrix();
		}
	};

	public class TestFPSGameData
	{
	public:
		gcroot<GameViewport ^> viewportRef;
		GameTimer *gameTimerRef;

		FPSGameType gameType;

		bool exitGame; // once true, game ends.

		TestFPSAvatar *localControlAvatarRef;
		TestFPSAvatar *localSpectateAvatarRef;

		FPSGameMessageList *messageList;

		int gameStateGameTimeMS; // when animate() done, this is set so that incoming packets have a base to work from (can't depend on timer->GetGameTimeMS() because it can be adjusted
								 // by an incoming packet, and that shouldn't effect how incoming gametime-tagged packets are interpreted

		LinkedList<TestFPSAvatar> playerAvatars;

	public:
		TestFPSGameData(GameViewport ^p_viewport, GameTimer *p_timer, GameColor &p_defaultMessageListColor, GameFont ^p_defaultMessageListFont, GameFont ^p_defaultMessageListBoldFont)
		{
			viewportRef = p_viewport;
			gameTimerRef = p_timer;
			exitGame = false;

			messageList = new FPSGameMessageList(p_defaultMessageListColor, p_defaultMessageListFont, p_defaultMessageListBoldFont);

			Reset();
		}

		~TestFPSGameData()
		{
			viewportRef = nullptr;
			gameTimerRef = nullptr;

			if (messageList != nullptr)
			{
				delete messageList;
				messageList = nullptr;
			}
		}

		void Reset()
		{
			gameType = FPSGameType::None;

			localControlAvatarRef = nullptr;
			localSpectateAvatarRef = nullptr;

			playerAvatars.Clear();
		}

		void CreatePlayfield(JointedModel3d *p_avatarJointedModel)
		{
			Reset();

			// new avatar for local player
			LinkedListNode<TestFPSAvatar> *newAvatar = playerAvatars.GetNewNode();
			newAvatar->data.Initialize(p_avatarJointedModel);
			newAvatar->data.orient.p = Vector3d(0, 0, 0);
			playerAvatars.AddNode(newAvatar);

			localControlAvatarRef = &(newAvatar->data);
			localSpectateAvatarRef = &(newAvatar->data);

			// another for testing
			newAvatar = playerAvatars.GetNewNode();
			newAvatar->data.Initialize(p_avatarJointedModel);
			newAvatar->data.orient.p = Vector3d(2, 0, 5);
			newAvatar->data.orient.Rotate(newAvatar->data.orient.u, 165.0f);
			playerAvatars.AddNode(newAvatar);

			gameType = FPSGameType::SinglePlayer;
		}

		void Animate(float p_elapsedTimeMS, int p_gameTimeMS)
		{
			// animate everything.
			LinkedListEnumerator<TestFPSAvatar> avatarEnum = LinkedListEnumerator<TestFPSAvatar>(playerAvatars);
			while (avatarEnum.MoveNext())
			{
				TestFPSAvatar *avatar = &(avatarEnum.Current()->data);

				avatar->Animate(p_elapsedTimeMS);
			}
		}

		float GetRenderScale()
		{
			return float(viewportRef->GetHeight()) / 1080.0f;
		}

		void Render(GraphicsBase *p_graphics)
		{
			RenderAvatars(p_graphics);
		}

	private:
		void RenderAvatars(GraphicsBase *p_graphics)
		{
			LinkedListEnumerator<TestFPSAvatar> avatarEnum = LinkedListEnumerator<TestFPSAvatar>(playerAvatars);
			while (avatarEnum.MoveNext())
			{
				TestFPSAvatar *avatar = &(avatarEnum.Current()->data);

				avatar->Render(p_graphics);
			}
		}
	};

	public class FPSNetworkPlayer : public GameNetworkPlayerBase
	{
	public:
		GameColor color;

		int ping;
		int smallestPing;

		FPSNetworkPlayer()
		{
			color = GameColor(255, 32, 32);

			ping = -1;
			smallestPing = -1;
		}
	};

	public class TestFPSNetwork : public GameNetworkBase
	{
	public:
		TestFPSGameData *gameDataRef;

		TestFPSNetwork(TestFPSGameData *p_gameDataRef, int p_clientQty, String ^p_appVersionString, String ^appGuid) : GameNetworkBase(p_clientQty, p_appVersionString, appGuid)
		{
			gameDataRef = p_gameDataRef;
		}

	protected:
		bool CustomValidatePacket(char *p_packet, int p_type) override
		{
			return false;
		}

		void CustomProcessPacketHost(GameNetworkClient *p_client, char *p_packet, int p_type) override
		{
		}

		void CustomProcessPacketPlayer(char *p_packet, int p_type) override
		{
		}
	};

	public ref class TestFPSGame : public GameBase
	{
	public:

		SkyboxColorDome *dome;
		Model3d *terrain;

		TestFPSGameData *gameData;
		GameTimer *timer;
		GameTimer *steadyTimer;
		Model3d *avatarLegModel;
		Model3d *avatarBodyModel;
		Model3d *avatarHeadModel;
		Model3d *avatarGunModel;
		JointedModel3d *avatarJointedModel;

		GameNetworkBase *fpsNetwork;
		GameUI *fpsUI;

		LinkedList<JointedModelOrientIndex> *cameraToGunProgression;
		LinkedList<JointedModelOrientIndex> *cameraToHeadProgression;
		FPSGameCameraMode cameraMode;

		bool showPlayerList;

		TestFPSGame(HWND p_hWnd) : GameBase(p_hWnd)
		{
			gameData = nullptr;
			timer = nullptr;
			steadyTimer = nullptr;
			fpsNetwork = nullptr;
			fpsUI = nullptr;

			avatarLegModel = nullptr;
			avatarBodyModel = nullptr;
			avatarHeadModel = nullptr;
			avatarGunModel = nullptr;
			avatarJointedModel = nullptr;
			cameraToGunProgression = nullptr;
			cameraToHeadProgression = nullptr;

			showPlayerList = false;

			dome = nullptr;
			terrain = nullptr;

			cameraMode = FPSGameCameraMode::Spectate;
		}

		virtual ~TestFPSGame()
		{
			Destroy();
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		void Initialize() override
		{
			GameContext::Instance->SetGame(this);

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Messages720", gcnew System::Drawing::Font("Verdana", 14));
			GameContext::Instance->FontRegistry.RegisterFont("MessagesBold720", gcnew System::Drawing::Font("Verdana", 14, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("Messages1080", gcnew System::Drawing::Font("Verdana", 18));
			GameContext::Instance->FontRegistry.RegisterFont("MessagesBold1080", gcnew System::Drawing::Font("Verdana", 18, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("Messages500", gcnew System::Drawing::Font("Verdana", 10));
			GameContext::Instance->FontRegistry.RegisterFont("MessagesBold500", gcnew System::Drawing::Font("Verdana", 10, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("MenuSmall", gcnew System::Drawing::Font("Verdana", 12));
			GameContext::Instance->FontRegistry.RegisterFont("MenuSmallBold", gcnew System::Drawing::Font("Verdana", 12, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("MenuLarge", gcnew System::Drawing::Font("Verdana", 16));
			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 10));
			GameContext::Instance->FontRegistry.RegisterFont("InfoBold", gcnew System::Drawing::Font("Verdana", 10, FontStyle::Bold));

			// set up file resources and textures
			GameContext::Instance->TextureRegistry.RegisterTexture("Star", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("star.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("AvatarFace1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("fpsface1.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("AvatarFace1Dead", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("fpsface1dead.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Meadow1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Grass_Meadows2.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("StraightReticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("straightreticle.jpg"));

			timer = new GameTimer();
			steadyTimer = new GameTimer();

			gameData = new TestFPSGameData(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), timer, GameColor(255,255,32), 
				GameContext::Instance->FontRegistry.GetFont("Messages720"),
				GameContext::Instance->FontRegistry.GetFont("MessagesBold720")
				);

			fpsNetwork = new TestFPSNetwork(gameData, 8, FPSTEST_VERSIONSTRING, FPSTEST_VERSIONGUID);
			GameContext::Instance->SetNetwork(fpsNetwork);
			fpsNetwork->Startup("1.0.2");

			fpsUI = new GameUI(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"),
				GameContext::Instance->FontRegistry.GetFont("Info"),
				GameColor(255,255,255)
				);
			GameContext::Instance->SetUI(fpsUI);

			dome = new SkyboxColorDome();
			// do this instead of calling new [] within the initialize call.  Putting a new array[] call in the initialize caused an exception on a second initialization.
			//  was it a problem with the Initialize() method being inline?
			GameColor beforeSunriseColor[10] = { GameColor(213, 125, 51), GameColor(234, 161, 70), GameColor(209, 170, 117),
				GameColor(152, 148, 134), GameColor(109, 125, 134), GameColor(75, 106, 129),
				GameColor(54, 87, 116), GameColor(43, 73, 103), GameColor(43, 73, 103),
				GameColor(43, 73, 103) };
			GameColor earlyMorningColor[10] = { GameColor(246, 212, 161), GameColor(226, 225, 219), GameColor(200, 207, 218),
				GameColor(167, 182, 206), GameColor(142, 159, 185), GameColor(119, 136, 166),
				GameColor(104, 121, 151), GameColor(86, 104, 134), GameColor(67, 86, 116),
				GameColor(60, 77, 106) };
			GameColor morningColor[10] = { GameColor(179, 224, 255), GameColor(152, 214, 255), GameColor(121, 189, 252),
				GameColor(99, 167, 238), GameColor(80, 146, 220), GameColor(66, 128, 201),
				GameColor(57, 115, 188), GameColor(47, 104, 173), GameColor(43, 97, 161),
				GameColor(42, 93, 156) };
			dome->Initialize(9, 40, &morningColor[0]);

			terrain = new Model3d();
			terrain->Initialize(1, 4, 1);
			terrain->GetColor(0)->Set(255, 255, 255);
			terrain->GetVertex(0)->colorIndex = 0;
			terrain->GetVertex(1)->colorIndex = 0;
			terrain->GetVertex(2)->colorIndex = 0;
			terrain->GetVertex(3)->colorIndex = 0;
			terrain->GetVertex(0)->vertex.Set(300.0f, 0.0f, 300.0f); // 6000 ft x 6000 ft
			terrain->GetVertex(1)->vertex.Set(-300.0f, 0.0f, 300.0f);
			terrain->GetVertex(2)->vertex.Set(-300.0f, 0.0f, -300.0f);
			terrain->GetVertex(3)->vertex.Set(300.0f, 0.0f, -300.0f);
			terrain->GetSurface(0)->Initialize(4, true);
			terrain->GetSurface(0)->SetVertexIndex(0, 0);
			terrain->GetSurface(0)->SetVertexIndex(1, 1);
			terrain->GetSurface(0)->SetVertexIndex(2, 2);
			terrain->GetSurface(0)->SetVertexIndex(3, 3);
			terrain->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Meadow1"));
			terrain->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
			terrain->GetSurface(0)->SetVertexTexCoords(1, 30.0f, 0.0f);
			terrain->GetSurface(0)->SetVertexTexCoords(2, 30.0f, 30.0f);
			terrain->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 30.0f);
			terrain->CalculateNormals();

			// total height 70 = 5'10", body and leg width/depth = head width/depth
			// these are radii
			float headScale = 9.0f / 120.0f;
			float bodyWidth = 10.0f / 120.0f;
			float bodyHeight = 12.5f / 120.0f;
			float legWidth = 9.0f / 120.0f;
			float legHeight = 12.5f / 120.0f;

			avatarHeadModel = new Model3d();
			avatarHeadModel->MakeCube();
			avatarHeadModel->ReScale(headScale);
			avatarHeadModel->GetColor(0)->Set(255, 255, 255);
			avatarHeadModel->GetColor(1)->Set(255, 255, 255);
			avatarHeadModel->GetColor(2)->Set(255, 255, 255);
			avatarHeadModel->GetColor(3)->Set(255, 255, 255);
			avatarHeadModel->GetColor(4)->Set(255, 255, 255);
			avatarHeadModel->GetColor(5)->Set(255, 255, 255);
			avatarHeadModel->GetColor(6)->Set(255, 255, 255);
			avatarHeadModel->GetColor(7)->Set(255, 255, 255);
			avatarHeadModel->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			avatarHeadModel->GetSurface(0)->SetVertexTexCoords(1, 0.0f, 0.0f);
			avatarHeadModel->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
			avatarHeadModel->GetSurface(0)->SetVertexTexCoords(3, 1.0f, 1.0f);
			avatarHeadModel->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("AvatarFace1"));

			avatarBodyModel = new Model3d();
			avatarBodyModel->MakeCube();
			avatarBodyModel->ReScale(Vector3d(bodyWidth, bodyHeight, bodyWidth));
			avatarBodyModel->GetColor(0)->Set(139, 69, 19);
			avatarBodyModel->GetColor(1)->Set(139, 69, 19);
			avatarBodyModel->GetColor(2)->Set(139, 69, 19);
			avatarBodyModel->GetColor(3)->Set(139, 69, 19);
			avatarBodyModel->GetColor(4)->Set(139, 69, 19);
			avatarBodyModel->GetColor(5)->Set(139, 69, 19);
			avatarBodyModel->GetColor(6)->Set(139, 69, 19);
			avatarBodyModel->GetColor(7)->Set(139, 69, 19);

			avatarLegModel = new Model3d();
			avatarLegModel->MakeCube();
			avatarLegModel->ReScale(Vector3d(legWidth, legHeight, legWidth));
			avatarLegModel->GetColor(0)->Set(139, 69, 19);
			avatarLegModel->GetColor(1)->Set(139, 69, 19);
			avatarLegModel->GetColor(2)->Set(139, 69, 19);
			avatarLegModel->GetColor(3)->Set(139, 69, 19);
			avatarLegModel->GetColor(4)->Set(139, 69, 19);
			avatarLegModel->GetColor(5)->Set(139, 69, 19);
			avatarLegModel->GetColor(6)->Set(139, 69, 19);
			avatarLegModel->GetColor(7)->Set(139, 69, 19);

			float gunRadius = 1.5f / 120.0f;
			float gunLength = 48.0f / 120.0f;
			float gunCenter = 12.0f / 120.0f; // 3 feet out front, 1 foot out back
			avatarGunModel = new Model3d();
			avatarGunModel->MakeCube();
			avatarGunModel->GetVertex(0)->vertex.Set(-gunRadius, -gunRadius, gunLength - gunCenter);
			avatarGunModel->GetVertex(1)->vertex.Set(-gunRadius, gunRadius, gunLength - gunCenter);
			avatarGunModel->GetVertex(2)->vertex.Set(gunRadius, gunRadius, gunLength - gunCenter);
			avatarGunModel->GetVertex(3)->vertex.Set(gunRadius, -gunRadius, gunLength - gunCenter);
			avatarGunModel->GetVertex(4)->vertex.Set(-gunRadius, -gunRadius, -gunCenter);
			avatarGunModel->GetVertex(5)->vertex.Set(-gunRadius, gunRadius, -gunCenter);
			avatarGunModel->GetVertex(6)->vertex.Set(gunRadius, gunRadius, -gunCenter);
			avatarGunModel->GetVertex(7)->vertex.Set(gunRadius, -gunRadius, -gunCenter);
			avatarGunModel->GetColor(0)->Set(44, 53, 57);
			avatarGunModel->GetColor(1)->Set(44, 53, 57);
			avatarGunModel->GetColor(2)->Set(44, 53, 57);
			avatarGunModel->GetColor(3)->Set(44, 53, 57);
			avatarGunModel->GetColor(4)->Set(44, 53, 57);
			avatarGunModel->GetColor(5)->Set(44, 53, 57);
			avatarGunModel->GetColor(6)->Set(44, 53, 57);
			avatarGunModel->GetColor(7)->Set(44, 53, 57);

			// 2 - 3 - head
			// |
			// 1 - body - 4 - 5 - 6 - gun - 7 - camera
			// |
			// 0 - leg
			// |
			// [] - orient
			// 0 - leg, straight from origin orient
			// 1 - body, straight from leg
			// 2 - head joint, vertically up and always aligned with 1
			// 3 - head mouse pitch joint, also render position for head
			// 4 - gun vertical position on body for scoping (moves to head and back to waist)
			// 5 - gun rotation off body, turns up 90 when prone
			// 6 - gun mouse pitch joint
			// 7 - camera off gun, always
			// todo: 0 could just a send one for leg waggle when move, just make it index 7?
			avatarJointedModel = new JointedModel3d();
			avatarJointedModel->Initialize(avatarLegModel, 0, 1);
			avatarJointedModel->GetJoint(0)->Initialize(avatarBodyModel, 1, 2);
			avatarJointedModel->GetJoint(0)->GetJoint(0)->Initialize(nullptr, 2, 1);
			avatarJointedModel->GetJoint(0)->GetJoint(0)->GetJoint(0)->Initialize(avatarHeadModel, 3, 0);
			avatarJointedModel->GetJoint(0)->GetJoint(1)->Initialize(nullptr, 4, 1);
			avatarJointedModel->GetJoint(0)->GetJoint(1)->GetJoint(0)->Initialize(nullptr, 5, 1);
			avatarJointedModel->GetJoint(0)->GetJoint(1)->GetJoint(0)->GetJoint(0)->Initialize(avatarGunModel, 6, 1);
			avatarJointedModel->GetJoint(0)->GetJoint(1)->GetJoint(0)->GetJoint(0)->GetJoint(0)->Initialize(nullptr, 7, 0);
			////

			// todo: 
			// animations (no loop) for body for stand, crouch and prone (affect 0, 1, and 2) (stand to crouch to stand are quick, stand/crouch to prone to stand/crouch are slow), and possibly jump!
			// animation (looping) for leg waggle when walking, crouching and crawling, animate and different speeds
			// animations for gun scope and gun back to normal (affect gun position 4 and camera 6)
			// (all 3 animations must be executed continually - make sure animations support noloop, track 3 animations on avatars)
			// default stance values on avatar instance (stand, noscope)
			// mouse pitch will affect 3 and 5
			// mouse spin will affect u rotation of main orient
			// animate loop will move model slowly with crouch, and very slowly when prone
			// mouse pitch of 3 and 5 are applied outside of avatar animation once per game tick since they are not interpolated.
			// might want to make gun position based directly off orient so that jump doesn't shake the camera
			// (camera might actually be better served as an offset from the scope position that the game can clamp against surrounding geometry)
			// todo: stand from crouch, crouch from prone, death.
			avatarJointedModel->AllocateAnimations(6);
			// animations that work with 0 1 2 5 (legs, chest, head prone tilt, gun prone tilt)
			// 0 fast stand
			int animationIndex = 0;
			avatarJointedModel->GetAnimation(animationIndex)->Initialize(1, false);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->Initialize(4, 500.0f); // todo: standing from prone should be slower, so might need another animation
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.p.Set(0.0f, legHeight, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 1;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.p.Set(0.0f, legHeight + bodyHeight, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 2;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.p.Set(0.0f, bodyHeight + headScale, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 5;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.p.Set(-bodyWidth - gunRadius, 0.0f, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->Commit();
			animationIndex++;
			// 1 crouch
			avatarJointedModel->GetAnimation(animationIndex)->Initialize(1, false);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->Initialize(4, 250.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.p.Set(0.0f, legHeight, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 1;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.p.Set(0.0f, legHeight, 0.0f); // body crouched into legs halfway
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 2;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.p.Set(0.0f, bodyHeight + headScale, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 5;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.p.Set(-bodyWidth - gunRadius, 0.0f, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->Commit();
			animationIndex++;
			// 2 slow crouch - when coming from prone
			avatarJointedModel->GetAnimation(animationIndex)->Initialize(1, false);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->Initialize(4, 500.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.p.Set(0.0f, legHeight, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 1;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.p.Set(0.0f, legHeight, 0.0f); // body crouched into legs halfway
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 2;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.p.Set(0.0f, bodyHeight + headScale, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 5;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.p.Set(-bodyWidth - gunRadius, 0.0f, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->Commit();
			animationIndex++;
			// 3 prone
			avatarJointedModel->GetAnimation(animationIndex)->Initialize(1, false);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->Initialize(4, 250.0f); // dive to prone should be fastish but standing or crouching from prone should be slow
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(avatarJointedModel->GetAnimation(2)->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -90.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.p.Set(0.0f, bodyWidth, -(legHeight + bodyHeight));
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 1;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.p.Set(0.0f, legHeight + bodyHeight, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 2;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.Rotate(avatarJointedModel->GetAnimation(2)->GetKeyframe(0)->GetStanceOrient(2)->orient.l, 90.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(2)->orient.p.Set(0.0f, bodyHeight + headScale, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 5;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(avatarJointedModel->GetAnimation(2)->GetKeyframe(0)->GetStanceOrient(3)->orient.l, 90.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(3)->orient.p.Set(-bodyWidth - gunRadius, 0.0f, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->Commit();
			animationIndex++;
			// animations that work with 4 (gun scope position along body) and 7 (camera position (scope/normal))
			// 4 gun normal, beside body
			avatarJointedModel->GetAnimation(animationIndex)->Initialize(1, false);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->Initialize(2, 250.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 4;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.p.Set(0.0f, 0.0f, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 7;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.p.Set(0.0f, 0.35f, -1.0f); // camera view over the shoulder
			avatarJointedModel->GetAnimation(animationIndex)->Commit();
			animationIndex++;
			// 5 gun scope, beside head
			avatarJointedModel->GetAnimation(animationIndex)->Initialize(1, false);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->Initialize(2, 250.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 4;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(0)->orient.p.Set(0.0f, bodyHeight + headScale, 0.0f);
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 7;
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			avatarJointedModel->GetAnimation(animationIndex)->GetKeyframe(0)->GetStanceOrient(1)->orient.p.Set(0.0f, gunRadius * 2.0f, 0.0f); // ca,era view down scope
			avatarJointedModel->GetAnimation(animationIndex)->Commit();
			animationIndex++;

			cameraToGunProgression = new LinkedList<JointedModelOrientIndex>();
			avatarJointedModel->GetOrientProgression(7, *cameraToGunProgression);
			cameraToHeadProgression = new LinkedList<JointedModelOrientIndex>();
			avatarJointedModel->GetOrientProgression(2, *cameraToHeadProgression);

			// make an avatar
			// todo:
			// initialize to stand position, normal scope, and initialize 3 and 6 just in case (although mouse pitch will set those before we animate at all)
			// todo: need avatar list, space for two animations, 2 stance initializations.
			// set orients 3 and 6 according to pitch
			// render!  and render with shader!  Need 3d projection.  Stationary camera to start, gun view mode toggle (f5?)
			// if change mind about stance or scope midanimation, should set the other animation mid-animation according to how far along the other animation was (will need to initialize
			//   beginning orients if set time inside, or keep orients, set to time 0 and animate it faster.  hmm)

			gameData->CreatePlayfield(avatarJointedModel);
		}

		void DestroyGameData()
		{
			if (dome != nullptr)
			{
				delete dome;
				dome = nullptr;
			}
			if (terrain != nullptr)
			{
				delete terrain;
				terrain = nullptr;
			}
			if (gameData != nullptr)
			{
				delete gameData;
				gameData = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (steadyTimer != nullptr)
			{
				delete steadyTimer;
				steadyTimer = nullptr;
			}
			if (fpsNetwork != nullptr)
			{
				delete fpsNetwork;
				fpsNetwork = nullptr;
			}
			if (fpsUI != nullptr)
			{
				delete fpsUI;
				fpsUI = nullptr;
			}

			if (avatarLegModel != nullptr)
			{
				delete avatarLegModel;
				avatarLegModel = nullptr;
			}
			if (avatarBodyModel != nullptr)
			{
				delete avatarBodyModel;
				avatarBodyModel = nullptr;
			}
			if (avatarHeadModel != nullptr)
			{
				delete avatarHeadModel;
				avatarHeadModel = nullptr;
			}
			if (avatarGunModel != nullptr)
			{
				delete avatarGunModel;
				avatarGunModel = nullptr;
			}
			if (avatarJointedModel != nullptr)
			{
				delete avatarJointedModel;
				avatarJointedModel = nullptr;
			}
			if (cameraToGunProgression != nullptr)
			{
				delete cameraToGunProgression;
				cameraToGunProgression = nullptr;
			}
			if (cameraToHeadProgression != nullptr)
			{
				delete cameraToHeadProgression;
				cameraToHeadProgression = nullptr;
			}
		}

		String ^ ApplicationName() override
		{
			return "FPS Test";
		}

		bool DoGameLoop() override
		{
			bool uiActive = (fpsUI->GetTopForm() != nullptr);

			if (uiActive == true)
				keyboardKeys.ClearClicked(); // prevent keys from affecting game (events are still good and will be consumed by the UI)

			// route controls to UI
			// if controls call for closing the last form, uiActive will be re-evaluated again
			// UI style: hit escape to bring up menu.  Click something to make the form close or hit Escape to close the menu and continue with game
			LinkedListEnumerator<GameInputEvent> inputEnumerator = inputEvents->GetEnumerator();
			while (inputEnumerator.MoveNext())
			{
				switch (inputEnumerator.Current()->data.type)
				{
				case GameInputEventType::MouseDown:
				case GameInputEventType::MouseUp:
				case GameInputEventType::MouseMove:
					// route mouse events so that ui can track mouse state even with no forms open, so that mouse is detected as up after something is clicked and form closes and ui deactivates
					fpsUI->ApplyInputEvent(inputEnumerator.Current()->data);
					break;
				case GameInputEventType::MouseWheel:
				case GameInputEventType::KeyDown:
				case GameInputEventType::KeyUp:
					//case GameInputEventType::KeyPress:
					if (uiActive == true)
						fpsUI->ApplyInputEvent(inputEnumerator.Current()->data); // only apply keys on UI when it is active
					break;
				}

				uiActive = (fpsUI->GetTopForm() != nullptr);
			}

			if (uiActive == false)
			{
				if (keyboardKeys.GetKey(27)->IsClicked())
				{
					// show a dialog for now to force uiActive to true to have a mouse
					fpsUI->MessageBox("Just a test to have a mouse");
					mouse.Show();
				}
				else
				{
					// all done, end game
					if (gameData->exitGame == true)
					{
						if (mouse.IsVisible() == false)
							mouse.Show();
						return false;
					}

					if (mouse.IsVisible() == true)
						mouse.Hide();
				}
			}


			joystick->Poll();
			timer->Poll();

			float slowMotionFactor = 1.0f;
			float elapsedTimeMS = timer->GetElapsedTimeMSFloat() * slowMotionFactor;
			float messageListElapsedTimeMS = steadyTimer->GetElapsedTimeMSFloat();

			// handle keyboard
			// reset spin on player ship, let keys determine its state
			if (gameData->localControlAvatarRef != nullptr)
			{
				if (gameData->localControlAvatarRef->CanBeControlled() == true)
				{
					// if can't be controlled, controls wont' be used below anyway
					gameData->localControlAvatarRef->RecordPriorMoveControls();
				}

				// but still good to cancel all controls so that flames aren't rendered, etc.
				gameData->localControlAvatarRef->ResetMoveControls();
				gameData->localControlAvatarRef->ResetStanceControls();
			}

			if (uiActive == false)
			{
				static bool okToShoot = true;

				// mouse
				if (mouse.leftButton.down == true)
				{
					// firing weapon.  do it!
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->shoot = true;
					}
				}
				if (mouse.rightButton.IsClicked() == true)
				{
					// firing weapon.  do it!
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->scope = true;
					}
				}
				if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
				{
					gameData->localControlAvatarRef->ApplyMouseOffsets(mouse.offsetX, mouse.offsetY);
				}

				if (mouse.IsVisible() == false && appActivated == true)
				{
					// move it to the middle of the viewport (should be screen position)
					// just to keep mouse within a form render window - this isn't really necessary in fullscreen
					GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
					mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
				}

				// keyboard
				if (keyboardKeys.GetKey('V')->IsClicked())
				{
					GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->SetVSyncEnabled(
						!(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->VSyncIsEnabled()));

					if (GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->VSyncIsEnabled() == true)
						gameData->messageList->AddMessage("VSync On");
					else
						gameData->messageList->AddMessage("VSync Off");
				}
				if (keyboardKeys.GetKey('A')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Left))->IsPressed())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->left = true;
					}
				}
				if (keyboardKeys.GetKey('D')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Right))->IsPressed())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->right = true;
					}
				}
				if (keyboardKeys.GetKey('W')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Up))->IsPressed())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->forward = true;
					}
				}
				if (keyboardKeys.GetKey('S')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Down))->IsPressed())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->backward = true;
					}
				}
				if (keyboardKeys.GetKey(int(System::Windows::Forms::Keys::ShiftKey))->IsPressed())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->run = true;
					}
				}
				if (keyboardKeys.GetKey(32)->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::ControlKey))->IsPressed())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->shoot = true;
					}
				}
				if (keyboardKeys.GetKey('C')->IsClicked())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->ApplyCrouch(true);
					}
				}
				if (keyboardKeys.GetKey('X')->IsClicked())
				{
					if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
					{
						gameData->localControlAvatarRef->ApplyProne(true);
					}
				}
				if (keyboardKeys.GetKey('Z')->IsClicked())
				{
					if (cameraMode == FPSGameCameraMode::Spectate)
						cameraMode = FPSGameCameraMode::Track;
					else if (cameraMode == FPSGameCameraMode::Track)
						cameraMode = FPSGameCameraMode::Stationary;
					else
						cameraMode = FPSGameCameraMode::Spectate;
				}
				if (keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Tab))->IsClicked())
				{
					if (fpsNetwork->IsActive())
						showPlayerList = !showPlayerList;
				}
				// resolve control conflicts
				if (gameData->localControlAvatarRef != nullptr && gameData->localControlAvatarRef->CanBeControlled() == true)
				{
					if (gameData->localControlAvatarRef->forward == true && gameData->localControlAvatarRef->backward == true)
					{
						// cancel forward/backward movement
						gameData->localControlAvatarRef->forward = false;
						gameData->localControlAvatarRef->backward = false;
					}
					if (gameData->localControlAvatarRef->left == true && gameData->localControlAvatarRef->right == true)
					{
						// cancel strafe movement
						gameData->localControlAvatarRef->left = false;
						gameData->localControlAvatarRef->right = false;
					}
					if (gameData->localControlAvatarRef->forward == false && gameData->localControlAvatarRef->backward == false)
					{
						// cancel run movement
						gameData->localControlAvatarRef->run = false;
					}

					// animated stance changes
					gameData->localControlAvatarRef->ApplyControls();
				}

				//if ((keyboardKeys.GetKey('C')->IsClicked() || keyboardKeys.GetKey(13)->IsClicked()) && gameData->gameType == AsteroidsGameType::Multiplayer)
				//{
				//	// send a chat message
				//	chatDlg->ShowModal();
				//	//gameData->SendChatMessage("Test <b><color=ff0000>chat</color></b> message");
				//}
			}
			mouse.ZeroOffsets();
			mouse.ClearClicked();
			keyboardKeys.ClearClicked();

			////////////////
			// Animate
			switch (gameData->gameType)
			{
			case FPSGameType::SinglePlayer:
				{
					float timeToConsumeMSf = elapsedTimeMS; // can't be negative in single player
					int timeToConsumeMS = int(timeToConsumeMSf + 0.01f); // to be safe

					// note: when slow motion is in effect, gameTimeMS is NOT accurate, sine slowMotion factor is applied to elapsedTime after it is retrieved, not within timer 
					//   - doesn't matter for single player game
					int gameTimeMS = timer->GetGameTimeMS() - int(elapsedTimeMS); // and if slowmotion, this will be badly off anyway because we are now truncating decimals

					float timeStepMSf = 10.0f;
					int timeStepMS = 10;
					// note: don't need to worry about elapsedTimeMS being negative in single player, just here to be consistent
					bool animated = false;
					while (timeToConsumeMSf > 0) // automatically avoids any animation until elapsedTimeMS > 0 (adjusting timer->GameTimeMS from server can cause even cause this to be negative)
					{
						animated = true;
						if (timeToConsumeMSf > timeStepMSf)
						{
							gameTimeMS += timeStepMS;
							gameData->Animate(timeStepMSf, gameTimeMS); // and check collisions
							timeToConsumeMSf -= timeStepMSf;
							timeToConsumeMS -= timeStepMS;
						}
						else
						{
							gameTimeMS += timeToConsumeMS;
							gameData->Animate(timeToConsumeMSf, gameTimeMS); // and check collisions
							timeToConsumeMSf = 0.0f;
						}
					}
					if (animated == true)
					{
						if (gameTimeMS != timer->GetGameTimeMS())
							throw gcnew Exception("gameTimeMS didn't advance properly!");

						// track gametimeMS of gamestate so that new objects from server can be caught up to current gamestate properly in the event that GameTimeMS() is adjusted from server before
						//   objects are received and before Poll() can be called here to catch the time up to positive again
						// vital that Process() only be called AFTER this, AFTER Animate() is finished, for the current method of how all obejcts now have the same gameTimeMS for their state
						gameData->gameStateGameTimeMS = timer->GetGameTimeMS();
					}

					gameData->messageList->Animate(messageListElapsedTimeMS);
				}
				break;
			case FPSGameType::Multiplayer: // until this needs a more specific section
				//fpsNetwork->AllocateBandwidth();
				//float timeToConsumeMSf = elapsedTimeMS; // negative time is possible if AdjustGameTimeMS() was called in Process().  If so, wait until elaspedTimeMS > 0
				//int timeToConsumeMS = int(timeToConsumeMSf + 0.01f); // to be safe

				//int gameTimeMS = timer->GetGameTimeMS() - int(elapsedTimeMS); // and if slowmotion, this will be badly off anyway because we are now truncating decimals

				//// send local ship updates to server prior to animation to reduce possibility of future gametime requiring holding of data
				//if (gameData->localPlayerShipRef != nullptr)
				//{
				//	gameData->localPlayerShipRef->timeSinceSentToPlayersMS += int(elapsedTimeMS);
				//	if (gameData->localPlayerShipRef->CanBeControlled() && (gameData->localPlayerShipRef->ControlsChanged() || gameData->localPlayerShipRef->timeSinceSentToPlayersMS >= 250))
				//	{
				//		// send to server
				//		if (asteroidsNetwork->IsClient())
				//			gameData->SendUpdateShipToServer(gameData->localPlayerShipRef, gameTimeMS); // controls and fuel and timers accurate to gameTimeMS variable (beginning of tick)
				//		else
				//			gameData->SendUpdateShipToClients(gameData->localPlayerShipRef, gameTimeMS); // controls and fuel and timers accurate to gameTimeMS variable (beginning of tick)
				//	}
				//}

				//float timeStepMSf = 10.0f;
				//int timeStepMS = 10;
				//bool animated = false;
				//while (timeToConsumeMSf > 0) // automatically avoids any animation until elapsedTimeMS > 0 (adjusting timer->GameTimeMS from server can even cause this to be negative)
				//{
				//	animated = true;
				//	if (timeToConsumeMSf > timeStepMSf)
				//	{
				//		gameTimeMS += timeStepMS;
				//		gameData->Animate(timeStepMSf, gameTimeMS); // and check collisions
				//		timeToConsumeMSf -= timeStepMSf;
				//		timeToConsumeMS -= timeStepMS;
				//	}
				//	else
				//	{
				//		gameTimeMS += timeToConsumeMS;
				//		gameData->Animate(timeToConsumeMSf, gameTimeMS); // and check collisions
				//		timeToConsumeMSf = 0.0f;
				//	}

				//	// remove expired bullets that didn't collide with anything
				//	gameData->RemoveExpiredBullets();
				//}
				//if (animated == true)
				//{
				//	if (timer->GetGameTimeMS() != gameTimeMS)
				//		throw gcnew Exception("game time out of sync with timer!");

				//	// record gameTimeMS of gamestate so that server objects sent in network->Process() can be properly caught up to the game state using this time (ping adjustments will
				//	//   alter timer->GameTimeMS() and throw it out of sync until the next Poll() above where elaspedTimeMS > 0 and Animate is called)
				//	// vital that Process() only be called AFTER this, AFTER Animate() is finished, for the current method of how all obejcts now have the same gameTimeMS for their state
				//	gameData->gameStateGameTimeMS = timer->GetGameTimeMS();
				//}

				//gameData->messageList->Animate(messageListElapsedTimeMS);

				//// gamestate object updates from server are received here, along with possible game time adjustments from pings, so gamestate from Animate must be caught up to the current GameTimeMS() and its value recorded there
				//// always call this AFTER getting elapsedTimeMS, after Animating and after setting gamestate's gameTime so that sent objects are properly caught up to gamestate if inside Process()
				////   an adjustment to the timer's GameTimeMS occurs (it's not longer good to catch objects up with in this tick because it doesn't match the game state anymore until elapsedTimeMS > 0
				////   and Animate() on a future tick)
				//asteroidsNetwork->Process();
				break;
			}

			return true;
		}

		void PerformRender() override
		{
			DoFPSRender();

			// don't reset if it's negative, let it catch up!
			if (timer->GetElapsedTimeMS() >= 0)
				timer->ResetElapsedTime();

			steadyTimer->ResetElapsedTime();
		}

		void BlockRender() override
		{
			DoFPSRender();
		}

		void DoFPSRender()
		{
			GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");

			// minimized?  Prevents errors
			if (viewport->GetWidth() == 0)
				return;

			GraphicsBase *graphics = viewport->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			// near 1.2 inches, far 3.78 miles
			graphics->SetPerspectiveProjection(45.0f, 0.01f, 2000.0f);
			graphics->DefaultTransform();

			static Orient3d cameraOrient;
			switch (cameraMode)
			{
			case FPSGameCameraMode::Spectate:
				if (gameData->localSpectateAvatarRef != nullptr)
				{
					cameraOrient = avatarJointedModel->CalculateOrientProgression(gameData->localSpectateAvatarRef->orient, *cameraToGunProgression, gameData->localSpectateAvatarRef->jointOrients);
					//cameraOrient.LoadIdentity();
					//cameraOrient.p.z = -2.0f;
					//cameraOrient.p.y = 0.7f;
				}
				else
				{
					// todo:
				}
				break;
			case FPSGameCameraMode::Track:
				if (gameData->localSpectateAvatarRef != nullptr)
				{
					Orient3d headPosition = avatarJointedModel->CalculateOrientProgression(gameData->localSpectateAvatarRef->orient, *cameraToHeadProgression, gameData->localSpectateAvatarRef->jointOrients);
					Vector3d offset = headPosition.p - cameraOrient.p;
					if (offset.Normalize() == true)
					{
						cameraOrient.f = offset;
						cameraOrient.l.Set(cameraOrient.f.z, 0.0f, -cameraOrient.f.x);
						if (cameraOrient.l.Normalize() == true)
						{
							cameraOrient.u = cameraOrient.f.CrossProd(cameraOrient.l);
						}
						else
						{
							if (cameraOrient.f.y > 0.0f)
							{
								cameraOrient.u = Vector3d(0.0f, 0.0f, -1.0f);
								cameraOrient.l = Vector3d(1.0f, 0.0f, 0.0f);
							}
							else
							{
								cameraOrient.u = Vector3d(0.0f, 0.0f, 1.0f);
								cameraOrient.l = Vector3d(1.0f, 0.0f, 0.0f);
							}
						}
					}
				}
				break;
			case FPSGameCameraMode::Stationary:
				// do nothing
				break;
			}
			graphics->ReverseTransform(cameraOrient);

			////////////////
			// render it!

			// skydome
			graphics->PushMatrix();
			Orient3d skyDomeOrient;
			skyDomeOrient.LoadIdentity();
			skyDomeOrient.p = cameraOrient.p;
			graphics->Transform(skyDomeOrient);
			dome->Render(*graphics);
			graphics->PopMatrix();

			// render terrain exactly where it is - its orient is basically the identity matrix, so transforming means no change
			terrain->Render(*graphics);

			// now render game objects
			gameData->Render(graphics);

			// now render other special stuff
			graphics->Set2dWindowProjection();

			graphics->SetDepthTestEnabled(false);
			graphics->SetDepthWriteEnabled(false);

			// reticle!
			if (cameraMode == FPSGameCameraMode::Spectate)
				RenderGunReticle(graphics, viewport);

			if (fpsNetwork->IsActive() && showPlayerList == true)
			{
				/////////////////
				// render players

				// show names
				float x = float(viewport->GetWidth() - 250);
				float y = float(viewport->GetHeight() / 2);
				GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MessagesBold500");
				int textHeight = font->GetHeight(); // assuming this is the greatest height - if not, use the height from the other font
				int widestTextWidth = 0;
				LinkedListEnumerator<GameNetworkPlayerNode> playerEnum = fpsNetwork->GetPlayerEnumerator();
				while (playerEnum.MoveNext())
				{
					FPSNetworkPlayer *player = (FPSNetworkPlayer *)playerEnum.Current()->data.player;
					GameColor renderColor = player->color;
					String ^message = player->GetName();

					Point textSize = font->GetTextSize(player->GetName() + " ");
					if (textSize.X > widestTextWidth)
						widestTextWidth = textSize.X;

					graphics->RenderFont(message, font, x, y, renderColor);

					y += font->GetHeight();
				}

				// show ping and data rate
				x += float(widestTextWidth);
				y = float(viewport->GetHeight() / 2);
				font = GameContext::Instance->FontRegistry.GetFont("Messages500");
				playerEnum = fpsNetwork->GetPlayerEnumerator();
				while (playerEnum.MoveNext())
				{
					FPSNetworkPlayer *player = (FPSNetworkPlayer *)playerEnum.Current()->data.player;
					GameColor renderColor = player->color;
					String ^message = "";
					if (fpsNetwork->IsServer())
					{
						if (player->host == true)
							message = message + " (" + Convert::ToString(int(fpsNetwork->GetSustainedUploadDataRate() / 1024.0f * 8.0f)) + "Kb/sec)";
						if (player->host != true)
						{
							if (player->ping >= 0)
								message = message + " " + Convert::ToString(player->ping) + "ms";
							message = message + " (" + Convert::ToString(int(fpsNetwork->GetClientByClientId(player->id)->GetSustainedUploadDataRate() / 1024.0f * 8.0f)) + "Kb/sec)";
						}
					}
					else if (fpsNetwork->IsClient())
					{
						if (player->host == true)
						{
							if (player->ping >= 0)
								message = message + " " + Convert::ToString(player->ping) + "ms";
							message = message + " (" + Convert::ToString(int(fpsNetwork->GetSustainedDownloadDataRate() / 1024.0f * 8.0f)) + "Kb/sec)";
						}
					}

					graphics->RenderFont(message, font, x, y, renderColor);

					y += font->GetHeight();
				}

				// render a clock to check game time calibration
				float scale = gameData->GetRenderScale();
				float radius = 1080.f / 12.0f * scale;

				ModelVertex handVertices[2];
				handVertices[0].colorIndex = 0;
				handVertices[1].colorIndex = 0;
				handVertices[0].vertex.Set(radius, radius, 0);

				// hour hand
				float dayDecimals = float((timer->GetGameTimeMS() / 1000) % 86400) / 86400.0f; // makes hour hand move slightly with second hand
				float dayAngle = 720.0f * dayDecimals; // two trips around for a day
				GameColor dayColor(255, 32, 32);
				float radians = MathUtilities::DegreesToRadians(dayAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 0.6f * sin(radians), -radius * 0.6f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &dayColor, 1, handVertices, 2);

				// minute hand
				float hourDecimals = float((timer->GetGameTimeMS() / 1000) % 3600) / 3600.0f; // makes minute hand move slightly with second hand
				float hourAngle = 360.0f * hourDecimals;
				GameColor hourColor(255, 128, 32);
				radians = MathUtilities::DegreesToRadians(hourAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 0.7f * sin(radians), -radius * 0.7f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &hourColor, 1, handVertices, 2);

				// second hand
				float minuteDecimals = float((timer->GetGameTimeMS() / 1000) % 60) / 60.0f;
				float minuteAngle = 360.0f * minuteDecimals;
				GameColor minuteColor(255, 255, 32);
				radians = MathUtilities::DegreesToRadians(minuteAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 0.85f * sin(radians), -radius * 0.85f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &minuteColor, 1, handVertices, 2);

				// ms hand
				float secondDecimals = float(timer->GetGameTimeMS() % 1000) / 1000.0f;
				float secondAngle = 360.0f * secondDecimals;
				GameColor secondColor(255, 255, 255);
				radians = MathUtilities::DegreesToRadians(secondAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 1.0f * sin(radians), -radius * 1.0f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &secondColor, 1, handVertices, 2);

				// time underneath
				GameColor clockColor(255, 255, 255);
				font = GameContext::Instance->FontRegistry.GetFont("MessagesBold500");
				String ^message = String::Format("{0}:{1}:{2}.{3}", int(dayDecimals*24.0f + 0.01f).ToString("D2"), int(hourDecimals*60.0f + 0.01f).ToString("D2"), int(minuteDecimals*60.0f + 0.01f).ToString("D2"), int(secondDecimals*1000.0f + 0.01f).ToString("D3"));
				int textSizeX = font->GetTextSize(message).X;
				x = radius - float(textSizeX) / 2.0f;
				y = radius * 2.0f + 5.0f;
				graphics->RenderFont(message, font, x, y, clockColor);

				///////////
			}
			graphics->SetDepthTestEnabled(true);
			graphics->SetDepthWriteEnabled(true);

			fpsUI->Render(graphics, true);
			//if (fpsUI->GetTopForm() != nullptr)
			//{
			//	// ui is up, render version
			//	GameFont ^font = GameContext::Instance->FontRegistry.GetFont("Info");
			//	String ^message = "FPS Test Version: " + FPSTEST_VERSIONSTRING;
			//	Point textSize = font->GetTextSize(message);
			//	int x = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() - textSize.X;
			//	int y = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - textSize.Y;
			//	graphics->RenderFont(message, font, float(x), float(y), GameColor(255, 255, 255));
			//}

			// done rendering
			/////////////////

			graphics->SwapBuffers();
		}

		void RenderGunReticle(GraphicsBase *p_graphics, GameViewport ^p_viewport)
		{
			GameTexture ^texture = GameContext::Instance->TextureRegistry.GetTexture("StraightReticle"); // verticle straight line

			Vector3d center(float(p_viewport->GetWidth()) / 2.0f, float(p_viewport->GetHeight()) / 2.0f, 0.0f);
			ModelVertex shape[4];
			shape[0].colorIndex = 0;
			shape[1].colorIndex = 0;
			shape[2].colorIndex = 0;
			shape[3].colorIndex = 0;
			ModelVertexTextureCoords texCoords[4];
			texCoords[0].Set(0.0f, 0.0f);
			texCoords[1].Set(1.0f, 0.0f);
			texCoords[2].Set(1.0f, 1.0f);
			texCoords[3].Set(0.0f, 1.0f);
			GameColor reticleColor(255, 255, 255);
			float distanceFromCenter = 25.0f * gameData->GetRenderScale(); // distance to reticle piece center from center of viewport - larger number = spread out reticle
			float reticleSize = 10.0f * gameData->GetRenderScale(); // radius of reticle piece

			for (int i = 0; i < 4; i++)
			{
				switch (i)
				{
				case 0:
				{
					Vector3d pieceCenter = center - Vector3d(0.0f, distanceFromCenter, 0.0f);
					shape[0].vertex = pieceCenter + Vector3d(-reticleSize, -reticleSize, 0.0f);
					shape[1].vertex = pieceCenter + Vector3d(reticleSize, -reticleSize, 0.0f);
					shape[2].vertex = pieceCenter + Vector3d(reticleSize, reticleSize, 0.0f);
					shape[3].vertex = pieceCenter + Vector3d(-reticleSize, reticleSize, 0.0f);
				}
				break;
				case 1:
				{
					Vector3d pieceCenter = center - Vector3d(distanceFromCenter, 0.0f, 0.0f);
					shape[0].vertex = pieceCenter + Vector3d(-reticleSize, reticleSize, 0.0f);
					shape[1].vertex = pieceCenter + Vector3d(-reticleSize, -reticleSize, 0.0f);
					shape[2].vertex = pieceCenter + Vector3d(reticleSize, -reticleSize, 0.0f);
					shape[3].vertex = pieceCenter + Vector3d(reticleSize, reticleSize, 0.0f);
				}
				break;
				case 2:
				{
					Vector3d pieceCenter = center + Vector3d(0.0f, distanceFromCenter, 0.0f);
					shape[0].vertex = pieceCenter + Vector3d(-reticleSize, -reticleSize, 0.0f);
					shape[1].vertex = pieceCenter + Vector3d(reticleSize, -reticleSize, 0.0f);
					shape[2].vertex = pieceCenter + Vector3d(reticleSize, reticleSize, 0.0f);
					shape[3].vertex = pieceCenter + Vector3d(-reticleSize, reticleSize, 0.0f);
				}
				break;
				case 3:
				{
					Vector3d pieceCenter = center + Vector3d(distanceFromCenter, 0.0f, 0.0f);
					shape[0].vertex = pieceCenter + Vector3d(-reticleSize, reticleSize, 0.0f);
					shape[1].vertex = pieceCenter + Vector3d(-reticleSize, -reticleSize, 0.0f);
					shape[2].vertex = pieceCenter + Vector3d(reticleSize, -reticleSize, 0.0f);
					shape[3].vertex = pieceCenter + Vector3d(reticleSize, reticleSize, 0.0f);
				}
				break;
				}

				p_graphics->RenderFilledQuad(&reticleColor, 1, shape, 4, true, texture, texCoords, 4);
			}
		}

	};
}