#include "TestAsteroids.h"

using namespace GameEng::Storage;
using namespace GameEngDev;

// app settings
const float AsteroidsAppSettings::asteroidsSaturationLevel = 1.0f; // recommended max 20 - 40+ makes it too difficult to find a safe space to spawn

int AsteroidsAsteroid::nextAsteroidId = 0;
int AsteroidsPowerup::nextPowerupId = 0;
int AsteroidsBullet::nextBulletId = 0;
int AsteroidsShip::nextShipId = 0;

LinkedList<AsteroidsShip> LinkedList<AsteroidsShip>::DeletedList("Deleted list for AsteroidsShip");
LinkedList<AsteroidsBullet> LinkedList<AsteroidsBullet>::DeletedList("Deleted list for AsteroidsBullet");
LinkedList<AsteroidsAsteroid> LinkedList<AsteroidsAsteroid>::DeletedList("Deleted list for AsteroidsAsteroid");
LinkedList<AsteroidsExplosion> LinkedList<AsteroidsExplosion>::DeletedList("Deleted list for AsteroidsExplosion");
LinkedList<AsteroidsPowerup> LinkedList<AsteroidsPowerup>::DeletedList("Deleted list for AsteroidsPowerup");
LinkedList<AsteroidsGameMessage> LinkedList<AsteroidsGameMessage>::DeletedList("Deleted list for AsteroidsGameMessage");
LinkedList<AsteroidsGameRenderMessage> LinkedList<AsteroidsGameRenderMessage>::DeletedList("Deleted list for AsteroidsGameRenderMessage");
LinkedList<AsteroidsGameMessageTag> LinkedList<AsteroidsGameMessageTag>::DeletedList("Deleted list for AsteroidsGameMessageTag");

void AsteroidsGameData::EchoChatMessage(String ^p_message, int p_fromPlayerId, bool p_tell)
{
	// this code has to be in the .cpp because AsteroidsNetworkPlayer isn't well formed
	AsteroidsNetworkPlayer *fromPlayer = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(p_fromPlayerId);
	if (fromPlayer != nullptr)
	{
		if (p_tell == true)
			messageList->AddMessage(String::Format("<color={0}>From <b>{1}:</b> {2}</color>", fromPlayer->color.ToString(), fromPlayer->GetName(), p_message), true);
		else
			messageList->AddMessage(String::Format("<color={0}><b>{1}:</b> {2}</color>", fromPlayer->color.ToString(), fromPlayer->GetName(), p_message), true);
	}
}

void AsteroidsGameData::EchoPlayerDestroyedPlayerMessage(int p_destroyingPlayerId, int p_destroyedPlayerId)
{
	// this code has to be in the .cpp because AsteroidsNetworkPlayer isn't well formed
	AsteroidsNetworkPlayer *destroyingPlayer = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(p_destroyingPlayerId);
	AsteroidsNetworkPlayer *destroyedPlayer = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(p_destroyedPlayerId);
	if (destroyingPlayer != nullptr && destroyedPlayer != nullptr)
	{
		messageList->AddMessage(String::Format("<b><color={0}>{1}</color></b> destroyed <b><color={2}>{3}</color></b>",
			destroyingPlayer->color.ToString(), destroyingPlayer->GetName(), destroyedPlayer->color.ToString(), destroyedPlayer->GetName()));
	}
}

void AsteroidsGameData::Animate(float p_elapsedTimeMS, int p_gameTimeMS)
{
	// all objects currently have a position representative of the beginning of the game tick (which is for this, the p_elaspedTimeMS being processed on this call), before p_elaspedTimeMS takes place.
	// move them all through their animations to their end points through p_elapsedTimeMS to arrive at the state at p_gameTimeMS.
	// The moveOffset each possesses then moves them from where they came from to their current positions, which sets them up well for CheckForCollisions, since their moveOffsets
	//    are all in the same domain of moving from 0.0 to 1.0 through p_elaspedTimeMS

	// gameTimeMS is the game time at the end of p_elapsedtimeMS
	// move all objects up to gameTimeMS (by applying p_elapsedtimeMS - current state of gamestate at this point is always up to the gametime of the prior call, including new objects
	//   and updates that arrived from the server).  Old moveOffsets are not used in any way here - they are ignored and replaced with moveOffsets for this game tick in preparation for CheckForCollisions

	// Asteroids
	LinkedListEnumerator<AsteroidsAsteroid> asteroidEnumerator = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
	while (asteroidEnumerator.MoveNext())
	{
		AsteroidsAsteroid *asteroid = &(asteroidEnumerator.Current()->data);
		asteroid->Animate(p_elapsedTimeMS, playfield);
	}

	// Ships (acclerate, etc.)
	LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
	while (shipEnumerator.MoveNext())
	{
		AsteroidsShip *ship = &(shipEnumerator.Current()->data);
		ship->Animate(p_elapsedTimeMS, playfield);
		bool flyShip = true;
		if (ship->IsTimeToExplode() == true)
		{
			flyShip = false;
			if (GameContext::Instance->GetNetwork()->IsClient() == false)
				DestroyShip(ship, 0.0f, p_elapsedTimeMS, p_gameTimeMS);
		}
		else if (ship->IsReadyToRespawn())
		{
			flyShip = false;
			if (GameContext::Instance->GetNetwork()->IsActive() == false)
			{
				RespawnShip(ship);
			}
			else if (GameContext::Instance->GetNetwork()->IsServer())
			{
				// if this is the server player's ship, do it, otherwise wait for player's game state to be set
				if (ship->playerId == GameContext::Instance->GetNetwork()->GetHostUserId())
					RespawnShip(ship);
				else
				{
					// if player's gamestate is initialized, allow respawn
					AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(ship->playerId);
					if (player != nullptr && player->gameStateInitialized == true)
						RespawnShip(ship);
				}
			}
		}
		else
		{
			// note: we are firing bullets at the end of the FIRST ship move here, meaning there can be second and third calls of Animate() from the main routine.  Bullets are created on
			//  the FIRST call.  No real reason for this - we could create the bullet before the first move or at the end of all of them, as long as it's a good bullet with a full moveOffset
			//  to the end gameTimeMS for CheckForCollisions
			if (ship->shoot == true && ship == localPlayerShipRef) // client ships fire and report their own bullets (todo: however, AI ships controlled by the local machine can fire)
			{
				// fire a bullet now
				ship->shoot = false; // only one bullet gets fired

				if (ship->shotsFired < 4)
				{
					LinkedListNode<AsteroidsBullet> *newBullet = bullets.GetNewNode();
					Vector3d bulletPosition = ship->GetBulletStartPosition(playfield);
					float bulletSpeed = 1.0f; // 1000.0f playfield per MS
					Vector3d bulletVelocity = ship->velocity + ship->GetForwardVector().ScalarMult(bulletSpeed);
					newBullet->data.Initialize();
					float radius = 2.0f;
					bool super = false;
					if (ship->superWeaponShots > 0)
					{
						super = true;
						radius = 10.0f;
						ship->superWeaponShots--;
					}
					newBullet->data.SetPositionVelocityLifeRadius(ship, bulletPosition, bulletVelocity, 1000.0f, radius, super);
					newBullet->data.minimumGameTimeMS = p_gameTimeMS - int(p_elapsedTimeMS); // when bullet was created
					bullets.AddBullet(newBullet);
				}
			}
		}
	}

	// Bullets (move to maximum distance at point of running out of life, wait until check for collisions before destroying)
	LinkedListEnumerator<AsteroidsBullet> bulletEnumerator = LinkedListEnumerator<AsteroidsBullet>(bullets);
	while (bulletEnumerator.MoveNext())
	{
		AsteroidsBullet *bullet = &(bulletEnumerator.Current()->data);
		bullet->Animate(p_elapsedTimeMS, playfield);
		if (bullet->newBullet == true)
		{
			bullet->newBullet = false;

			if (bullet->ownerRef == localPlayerShipRef)
			{
				if (GameContext::Instance->GetNetwork()->IsClient())
				{
					SendAddBulletToServer(bullet, p_gameTimeMS); // report bullet according to its position and the gametime of its position
				}
				else if (GameContext::Instance->GetNetwork()->IsServer())
				{
					SendAddBulletToClients(bullet, p_gameTimeMS); // report bullet according to its position and the gametime of its position
				}
			}
		}
	}

	// Explosions (expand, destroy)
	LinkedListNode<AsteroidsExplosion> *explosionNode = explosions.GetFirstNode();
	if (explosionNode != nullptr)
	{
		while (explosionNode != &(explosions.footer))
		{
			LinkedListNode<AsteroidsExplosion> *nextExplosionNode = explosionNode->next;

			AsteroidsExplosion *explosion = &(explosionNode->data);
			explosion->Animate(p_elapsedTimeMS);
			if (explosion->deleteIt == true)
				explosions.RemoveExplosion(explosionNode);

			explosionNode = nextExplosionNode;
		}
	}

	// Powerups
	LinkedListEnumerator<AsteroidsPowerup> powerupEnumerator = LinkedListEnumerator<AsteroidsPowerup>(powerups);
	while (powerupEnumerator.MoveNext())
	{
		AsteroidsPowerup *powerup = &(powerupEnumerator.Current()->data);
		powerup->Animate(p_elapsedTimeMS, playfield);
	}

	CheckForCollisions(p_elapsedTimeMS, p_gameTimeMS);
}

void AsteroidsGameData::SendAddExplosionToClients(Vector3d &p_position, GameColor &p_color, float p_radius, float p_expansionRatePerMS, float p_lifeMS)
{
	AsteroidsNetworkAddExplosionPacket addExplosion;
	AsteroidsNetworkPacketHelper::PopulateAddExplosionPacket(addExplosion, p_position, p_color, p_radius, p_expansionRatePerMS, p_lifeMS);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&addExplosion, addExplosion.length, 0);
		}
	}
}

void AsteroidsGameData::SendAsteroidToClients(AsteroidsAsteroid *p_asteroid, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS, bool p_add)
{
	// either add or update
	if (p_add == true)
	{
		AsteroidsNetworkAddAsteroidPacket addAsteroid;
		// correct position, since the actual creation position and gameTime of this state of the asteroid is NOT the position and gametime sent.  Instead, they reflect where
		//   the asteroid will be at the gameTime that is at the END of the iteration to be consistent with collision detection.
		Vector3d actualPosition = playfield.NormalizePositionWithPlayfield(p_asteroid->position - p_asteroid->velocity.ScalarMult(p_animationTimeMS * (1.0f - p_iterationFactor)));
		int actualGameTimeMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));
		AsteroidsNetworkPacketHelper::PopulateAddAsteroidPacket(addAsteroid, p_asteroid->Id, actualPosition, p_asteroid->velocity, p_asteroid->type, p_asteroid->radius, p_asteroid->minimumGameTimeMS, actualGameTimeMS);
		for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
		{
			GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
			if (client->IsValidated())
			{
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
				if (player->gameStateInitialized == true)
					GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&addAsteroid, addAsteroid.length, 0);
			}
		}
	}
	else
	{
		AsteroidsNetworkUpdateAsteroidPacket updateAsteroid;
		Vector3d actualPosition = playfield.NormalizePositionWithPlayfield(p_asteroid->position - p_asteroid->velocity.ScalarMult(p_animationTimeMS * (1.0f - p_iterationFactor)));
		int actualGameTimeMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));
		AsteroidsNetworkPacketHelper::PopulateUpdateAsteroidPacket(updateAsteroid, p_asteroid->Id, actualPosition, p_asteroid->velocity, p_asteroid->type, p_asteroid->radius, p_asteroid->minimumGameTimeMS, actualGameTimeMS);
		for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
		{
			GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
			if (client->IsValidated())
			{
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
				if (player->gameStateInitialized == true)
					GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&updateAsteroid, updateAsteroid.length, 0);
			}
		}
	}
}

void AsteroidsGameData::SendAddPowerupToClients(AsteroidsPowerup *p_powerup, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS)
{
	AsteroidsNetworkAddPowerupPacket addPowerup;
	// correct position, since the actual creation position and gameTime of this state of the asteroid is NOT the position and gametime sent.  Instead, they reflect where
	//   the asteroid will be at the gameTime that is at the END of the iteration to be consistent with collision detection.
	Vector3d actualPosition = playfield.NormalizePositionWithPlayfield(p_powerup->position - p_powerup->velocity.ScalarMult(p_animationTimeMS * (1.0f - p_iterationFactor)));
	int actualGameTimeMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));
	AsteroidsNetworkPacketHelper::PopulateAddPowerupPacket(addPowerup, p_powerup->Id, actualPosition, p_powerup->velocity, p_powerup->type, p_powerup->minimumGameTimeMS, actualGameTimeMS);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&addPowerup, addPowerup.length, 0);
		}
	}
}

void AsteroidsGameData::SendAddBulletToClients(AsteroidsBullet *p_bullet, int p_gameTimeMS)
{
	AsteroidsNetworkAddBulletPacket bulletPacket;
	AsteroidsNetworkPacketHelper::PopulateAddBulletPacket(bulletPacket, p_bullet->Id, p_bullet->ownerRef->Id, p_bullet->position, p_bullet->velocity, p_bullet->super, p_bullet->radius, p_bullet->lifeMS, p_bullet->minimumGameTimeMS, p_gameTimeMS);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&bulletPacket, bulletPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendAddShipToClients(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	AsteroidsNetworkAddShipPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateAddShipPacket(shipPacket, p_ship->playerId, p_ship->Id, 
		p_ship->spinDirection, p_ship->thrust, p_ship->backwards, p_ship->left, p_ship->right, p_ship->boost, //controls
		p_ship->position, p_ship->velocity, p_ship->rotationAngle, p_ship->color, p_ship->destroyed, 
		p_ship->health, p_ship->shield, p_ship->boostFuel, p_ship->cloakMS, p_ship->deathThroesMS, p_ship->deathThroeRotationAnglePerMS,
		p_ship->lastGameTimeUpdatedByServerMS, p_gameTimeMS);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			// player may not be made yet - that player doesn't need this anyway (routine called from within PlayerJoined when sending player's created ship to others, but hasn't sent
			//    gamestate down to the new player yet
			if (player != nullptr && player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendUpdateShipToServer(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	// only controlling machine sends this (client)

	// todo: pos/vel may not be accepted if server has evaluated a collision with other ships or ship can no longer be controlled
	AsteroidsNetworkUpdateShipFromClientPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateUpdateShipFromClientPacket(shipPacket, p_ship->Id,
		p_ship->spinDirection, p_ship->thrust, p_ship->backwards, p_ship->left, p_ship->right, p_ship->boost, //controls
		p_ship->position, p_ship->velocity, p_ship->rotationAngle, p_ship->boostFuel, p_ship->cloakMS,
		p_ship->lastGameTimeUpdatedByServerMS, p_gameTimeMS);
	GameContext::Instance->GetNetwork()->SendToServer((char *)&shipPacket, shipPacket.length, 0);
}

void AsteroidsGameData::SendUpdateShipToServerUDP(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	// only controlling machine sends this (client)

	// todo: pos/vel may not be accepted if server has evaluated a collision with other ships or ship can no longer be controlled
	AsteroidsNetworkUpdateShipFromClientPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateUpdateShipFromClientUDPPacket(shipPacket, p_ship->Id,
		p_ship->spinDirection, p_ship->thrust, p_ship->backwards, p_ship->left, p_ship->right, p_ship->boost, //controls
		p_ship->position, p_ship->velocity, p_ship->rotationAngle, p_ship->boostFuel, p_ship->cloakMS,
		p_ship->lastGameTimeUpdatedByServerMS, p_gameTimeMS);
	GameContext::Instance->GetNetwork()->SendToServerUDP((char *)&shipPacket, shipPacket.length, 0);
}

void AsteroidsGameData::SendUpdateShipToClients(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	// only controlling machine sends this (host)

	AsteroidsNetworkUpdateShipFromClientPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateUpdateShipFromClientPacket(shipPacket, p_ship->Id,
		p_ship->spinDirection, p_ship->thrust, p_ship->backwards, p_ship->left, p_ship->right, p_ship->boost, //controls
		p_ship->position, p_ship->velocity, p_ship->rotationAngle, p_ship->boostFuel, p_ship->cloakMS,
		p_ship->lastGameTimeUpdatedByServerMS, p_gameTimeMS);

	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			// player may not be made yet - that player doesn't need this anyway (routine called from within PlayerJoined when sending player's created ship to others, but hasn't sent
			//    gamestate down to the new player yet
			if (player != nullptr && player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}


void AsteroidsGameData::SendUpdateShipToClientsUDP(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	// only controlling machine sends this (host)

	AsteroidsNetworkUpdateShipFromClientPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateUpdateShipFromClientUDPPacket(shipPacket, p_ship->Id,
		p_ship->spinDirection, p_ship->thrust, p_ship->backwards, p_ship->left, p_ship->right, p_ship->boost, //controls
		p_ship->position, p_ship->velocity, p_ship->rotationAngle, p_ship->boostFuel, p_ship->cloakMS,
		p_ship->lastGameTimeUpdatedByServerMS, p_gameTimeMS);

	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			// player may not be made yet - that player doesn't need this anyway (routine called from within PlayerJoined when sending player's created ship to others, but hasn't sent
			//    gamestate down to the new player yet
			if (player != nullptr && player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClientUDP(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendUpdateShipPacketToOtherClients(AsteroidsNetworkUpdateShipFromClientPacket *p_packet, int p_excludeClientId)
{
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->GetId() == p_excludeClientId)
			continue;
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			// player may not be made yet - that player doesn't need this anyway (routine called from within PlayerJoined when sending player's created ship to others, but hasn't sent
			//    gamestate down to the new player yet
			if (player != nullptr && player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)p_packet, p_packet->length, 0);
		}
	}
}

void AsteroidsGameData::SendUpdateShipPacketToOtherClientsUDP(AsteroidsNetworkUpdateShipFromClientPacket *p_packet, int p_excludeClientId)
{
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->GetId() == p_excludeClientId)
			continue;
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			// player may not be made yet - that player doesn't need this anyway (routine called from within PlayerJoined when sending player's created ship to others, but hasn't sent
			//    gamestate down to the new player yet
			if (player != nullptr && player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClientUDP(client, (char *)p_packet, p_packet->length, 0);
		}
	}
}

void AsteroidsGameData::SendDyingShipPositionPacketToClients(AsteroidsNetworkDyingShipPositionPacket *p_packet, int p_excludeClientId)
{
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->GetId() == p_excludeClientId)
			continue;
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			// player may not be made yet - that player doesn't need this anyway (routine called from within PlayerJoined when sending player's created ship to others, but hasn't sent
			//    gamestate down to the new player yet
			if (player != nullptr && player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)p_packet, p_packet->length, 0);
		}
	}
}

void AsteroidsGameData::UpdateShipPositionAndVelocity(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	// sent from server when ship collides to all clients
	// clients: always accept
	// de-animate ship to p_gameTimeMS if not in future, and animate ship to local gameTimeMS using current controls
	// if this is the controlling machine, once get final state of ship to current gametime, send back to server with current controls (client's controls might not match what's on the server)
	// store on ship if in future and handle during animate
	// ??
}

void AsteroidsGameData::UpdateDyingShipPosition(AsteroidsShip *p_ship, Vector2d &p_position, Vector2d &p_velocity, float p_deathThroesMS)
{
	// prepping before calling animate retcon
	p_ship->position.Set(p_position.x, p_position.y, 0.0f);
	p_ship->velocity.Set(p_velocity.x, p_velocity.y, 0.0f);
	p_ship->deathThroesMS = p_deathThroesMS;
}

void AsteroidsGameData::SendRespawnShipToClients(AsteroidsShip *p_ship, float p_x, float p_y, float p_rotationAngle, int p_gameTimeVersion)
{
	AsteroidsNetworkRespawnShipPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateRespawnShipPacket(shipPacket, p_ship->Id, p_x, p_y, p_rotationAngle, p_gameTimeVersion);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendDamageShipToClients(AsteroidsShip *p_ship, float p_damage, int p_damagingPlayerId)
{
	AsteroidsNetworkDamageShipPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateDamageShipPacket(shipPacket, p_ship->Id, p_damage, p_damagingPlayerId);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendDyingShipPositionToClients(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	AsteroidsNetworkDyingShipPositionPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateDyingShipPositionPacket(shipPacket, p_ship->Id, p_ship->position, p_ship->velocity, p_gameTimeMS);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendDyingShipPositionToServer(AsteroidsShip *p_ship, int p_gameTimeMS)
{
	AsteroidsNetworkDyingShipPositionPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateDyingShipPositionPacket(shipPacket, p_ship->Id, p_ship->position, p_ship->velocity, p_gameTimeMS);
	GameContext::Instance->GetNetwork()->SendToServer((char *)&shipPacket, shipPacket.length, 0);
}

void AsteroidsGameData::SendDestroyShipToClients(AsteroidsShip *p_ship, Vector3d &p_destructionPosition)
{
	AsteroidsNetworkDestroyShipPacket shipPacket;
	AsteroidsNetworkPacketHelper::PopulateDestroyShipPacket(shipPacket, p_ship->Id, p_destructionPosition);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&shipPacket, shipPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendApplyPowerupToClients(AsteroidsPowerup *p_powerup, AsteroidsShip *p_ship)
{
	AsteroidsNetworkApplyPowerupPacket powerupPacket;
	AsteroidsNetworkPacketHelper::PopulateApplyPowerupPacket(powerupPacket, p_powerup->type, p_ship->Id);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&powerupPacket, powerupPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendEchoPlayerDestroyedPlayerMessage(int p_destroyingPlayerId, int p_destroyedPlayerId)
{
	AsteroidsNetworkEchoPlayerDestroyedPlayerPacket echoPacket;
	AsteroidsNetworkPacketHelper::PopulateEchoPlayerDestroyedPlayerPacket(echoPacket, p_destroyingPlayerId, p_destroyedPlayerId);
	for (int i = 0; i < GameContext::Instance->GetNetwork()->GetClientQty(); i++)
	{
		GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByIndex(i);
		if (client->IsValidated())
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(client->GetId());
			if (player->gameStateInitialized == true)
				GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&echoPacket, echoPacket.length, 0);
		}
	}
}

void AsteroidsGameData::SendTauntToClient(int p_playerId, int p_tauntType)
{
	AsteroidsNetworkTauntPacket tauntPacket;
	AsteroidsNetworkPacketHelper::PopulateTauntPacket(tauntPacket, p_tauntType);

	GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByClientId(p_playerId);
	if (client != nullptr)
	{
		AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GameContext::Instance->GetNetwork()->GetPlayer(p_playerId);
		if (player->gameStateInitialized == true)
			GameContext::Instance->GetNetwork()->SendToClient(client, (char *)&tauntPacket, tauntPacket.length, 0);
	}
}

AsteroidsShip * AsteroidsGameData::AddShip(GameNetworkPlayerBase *p_player, int p_id, 
	int p_spinDirection, bool p_thrust, bool p_backwards, bool p_left, bool p_right, bool p_boost,
	Vector3d &p_position, Vector3d &p_velocity, float p_rotationAngle, GameColor &p_color, bool p_destroyed, 
	float p_health, float p_shield, float p_boostFuel, float p_cloakMS, float p_deathThroesMS, float p_deathThroeRotationAnglePerMS,
	int p_gameTimeVersion)
{
	AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)p_player;

	LinkedListNode<AsteroidsShip> *newShip = ships.GetNewNode();
	newShip->data.Initialize(false);
	newShip->data.Id = p_id;
	newShip->data.playerId = p_player->id;

	newShip->data.spinDirection = p_spinDirection;
	newShip->data.thrust = p_thrust;
	newShip->data.backwards = p_backwards;
	newShip->data.left = p_left;
	newShip->data.right = p_right;
	newShip->data.boost = p_boost;

	newShip->data.position = p_position;
	newShip->data.velocity = p_velocity;
	newShip->data.rotationAngle = p_rotationAngle;
	newShip->data.color = p_color;
	newShip->data.destroyed = p_destroyed;

	newShip->data.health = p_health;
	newShip->data.shield = p_shield;
	newShip->data.boostFuel = p_boostFuel;
	newShip->data.cloakMS = p_cloakMS;
	newShip->data.deathThroesMS = p_deathThroesMS;
	newShip->data.deathThroeRotationAnglePerMS = p_deathThroeRotationAnglePerMS;
	newShip->data.lastGameTimeUpdatedByServerMS = p_gameTimeVersion;

	ships.AddNode(newShip);

	if (newShip->data.playerId == GameContext::Instance->GetNetwork()->GetLocalUserId())
	{
		localPlayerShipRef = &(newShip->data);
		renderFocusShipRef = localPlayerShipRef;
	}

	return &(newShip->data);
}

void AsteroidsGameData::UpdateShipFromClient(AsteroidsShip *p_ship,
	int p_spinDirection, int p_controls,
	Vector2d &p_position, Vector2d &p_velocity, float p_rotationAngle,
	float p_boostFuel, float p_cloakMS,
	int p_gameTimeVersion)
{
	p_ship->spinDirection = p_spinDirection;
	p_ship->thrust = (p_controls & ASTEROIDS_CONTROLS_THRUST_BIT) != 0;
	p_ship->backwards = (p_controls & ASTEROIDS_CONTROLS_BACKWARDS_BIT) != 0;
	p_ship->left = (p_controls & ASTEROIDS_CONTROLS_LEFT_BIT) != 0;
	p_ship->right = (p_controls & ASTEROIDS_CONTROLS_RIGHT_BIT) != 0;
	p_ship->boost = (p_controls & ASTEROIDS_CONTROLS_BOOST_BIT) != 0;

	p_ship->position = Vector3d(p_position.x, p_position.y, 0.0f);
	p_ship->velocity = Vector3d(p_velocity.x, p_velocity.y, 0.0f);
	p_ship->rotationAngle = p_rotationAngle;

	p_ship->boostFuel = p_boostFuel;
	p_ship->cloakMS = p_cloakMS;
	p_ship->lastGameTimeUpdatedByServerMS = p_gameTimeVersion;
}



