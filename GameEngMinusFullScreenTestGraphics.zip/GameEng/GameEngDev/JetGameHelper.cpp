#include "JetGameHelper.h"

using namespace GameEng::Storage;
using namespace GameEngDev::JetGameHelper;

// deleted lists for linked lists
LinkedList<JetGameObject> LinkedList<JetGameObject>::DeletedList("DeletedMain");
LinkedList<Waypoint> LinkedList<Waypoint>::DeletedList("DeletedWaypoint");
LinkedList<SurfaceDecal> LinkedList<SurfaceDecal>::DeletedList("DeletedSurfaceDecal");
LinkedList<AlphaBillboard> LinkedList<AlphaBillboard>::DeletedList("DeletedAlphaBillboard");
LinkedList<GameEngDev::JetGameHelper::Particle> LinkedList<GameEngDev::JetGameHelper::Particle>::DeletedList("DeletedGameEngDev::JetGameHelper::Particle");
LinkedList<EnergyEffect> LinkedList<EnergyEffect>::DeletedList("DeletedEnergyEffect");
LinkedList<HardpointConfiguration> LinkedList<HardpointConfiguration>::DeletedList("HardpointConfiguration");
LinkedList<HardpointWeaponConfigurationEntry> LinkedList<HardpointWeaponConfigurationEntry>::DeletedList("HardpointWeaponConfigurationEntry");

#pragma region Jet
void JetBehavior::Process(JetGameObject &p_jet, float p_elapsedTimeMSf)
{
	int elapsedTimeMS = int(p_elapsedTimeMSf);

	// increase ammo! (todo: could be a generic call with elapsedTimeMSf sent)
	for (int i = 0; i < p_jet.hardpointState->objectWeaponQty; i++)
	{
		for (int j = 0; j < p_jet.hardpointState->weaponStates[i].slotQty; j++)
		{
			// recharge ammo
			if (p_jet.hardpointState->weaponStates[i].slotStates[j].currentAmmo < float(p_jet.hardpointState->weaponStates[i].entryRef->maximumAmmoPool))
			{
				p_jet.hardpointState->weaponStates[i].slotStates[j].currentAmmo += p_jet.hardpointState->weaponStates[i].entryRef->ammoAmountRechargePerMS * p_elapsedTimeMSf;
				if (p_jet.hardpointState->weaponStates[i].slotStates[j].currentAmmo > float(p_jet.hardpointState->weaponStates[i].entryRef->maximumAmmoPool))
					p_jet.hardpointState->weaponStates[i].slotStates[j].currentAmmo = float(p_jet.hardpointState->weaponStates[i].entryRef->maximumAmmoPool);
			}

			// reduce weapon delay
			if (p_jet.hardpointState->weaponStates[i].slotStates[j].fireDelayMS > 0)
			{
				p_jet.hardpointState->weaponStates[i].slotStates[j].fireDelayMS -= elapsedTimeMS;
			}
		}
	}

	if (p_jet.dead == false)
		p_jet.behaviorDecisionDelay -= elapsedTimeMS;

	if (p_jet.gunDelayMS > 0)
		p_jet.gunDelayMS -= elapsedTimeMS; // this allows a small remainder for the next gun shot so that firing a stream results in the proper number of shots per second

	if (p_jet.missileAITimerMS > 0)
		p_jet.missileAITimerMS -= elapsedTimeMS; // prevent AI from firing missiles too often (will be replaced by hardpoint and ammo recharge later)

	if (p_jet.damageIndicatorTimerMS > 0)
	{
		if (p_jet.damageIndicatorTimerMS < elapsedTimeMS)
			p_jet.damageIndicatorTimerMS = 0;
		else
			p_jet.damageIndicatorTimerMS -= elapsedTimeMS;
	}

	if (p_jet.dead || p_jet.health < JetGameValues::JetStartingHealth())
	{
		p_jet.smokeDelayMS -= elapsedTimeMS;
	}
}

void JetBehavior::Behave(JetGameObject &p_jet, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS)
{
	p_jet.joystick.gunButton = false; // assume no gun firing until jet has target it is lined up with
	p_jet.joystick.secondaryButton = false;

	DetermineJoystickThrustAndWeaponUse(p_jet, p_terrain, p_worldYWaterLevel, *(p_gameStateData.mainGameObjectListRef));
	ProcessIntendedJoystickValues(p_jet.joystick, p_elapsedTimeMSf, p_userJoytickMoveAmountPerMS, p_userTwistMoveAmountPerMS);
}

void JetBehavior::ApplyPhysics(JetGameObject &p_jet, float p_gravityPerMS2, float p_elapsedTimeMS)
{
	float rudder = 0.0f; // - to the left, + to the right
	float leftAileron = 0.0f, rightAileron = 0.0f;  // - up + down
	// apply joystick, avoid dead area
	int primaryDeadArea = JetGameValues::JoystickPrimaryDeadArea();
	int twistDeadArea = JetGameValues::JoystickTwistDeadArea();

	if (p_jet.dead == false)
	{
		if (abs(p_jet.joystick.GetCurrentX()) > primaryDeadArea)
		{
			float value = 0;
			if (p_jet.joystick.GetCurrentX() > 0)
				value = float(p_jet.joystick.GetCurrentX() - primaryDeadArea);
			else
				value = float(p_jet.joystick.GetCurrentX() + primaryDeadArea);

			value = value / (1000.0f - primaryDeadArea);
			// apply adjustment
			if (value > 0.0)
				value = float(pow(value, 1.4f));
			else
				value = -float(pow(-value, 1.4f));

			leftAileron = -value;
			rightAileron = value;
		}
		if (abs(p_jet.joystick.GetCurrentY()) > primaryDeadArea)
		{
			float value = 0;
			if (p_jet.joystick.GetCurrentY() > 0)
				value = float(p_jet.joystick.GetCurrentY() - primaryDeadArea);
			else
				value = float(p_jet.joystick.GetCurrentY() + primaryDeadArea);

			value = value / (1000.0f - primaryDeadArea);
			// apply adjustment
			if (value > 0.0)
				value = float(pow(value, 1.4f));
			else
				value = -float(pow(-value, 1.4f));

			leftAileron += value;
			if (leftAileron < -1.0f)
				leftAileron = -1.0f;
			if (leftAileron > 1.0f)
				leftAileron = 1.0f;
			rightAileron += value;
			if (rightAileron < -1.0f)
				rightAileron = -1.0f;
			if (rightAileron > 1.0f)
				rightAileron = 1.0f;
		}
		if (abs(p_jet.joystick.GetCurrentTwist()) > twistDeadArea)
		{
			float value = 0;
			if (p_jet.joystick.GetCurrentTwist() > 0)
				value = float(p_jet.joystick.GetCurrentTwist() - twistDeadArea);
			else
				value = float(p_jet.joystick.GetCurrentTwist() + twistDeadArea);

			rudder = value / (1000.0f - twistDeadArea);
			// apply adjustment
			if (rudder > 0.0)
				rudder = float(pow(rudder, 1.4f));
			else
				rudder = -float(pow(-rudder, 1.4f));
		}

		// calculate thrust
		float thrust = p_jet.setThrust;
		if (p_jet.afterburner)
		{
			thrust = JetGameValues::AfterburnerThrust();
		}
		else if (p_jet.accelerate)
		{
			thrust += JetGameValues::AccelerateThrust();
			if (thrust > JetGameValues::MaxCruiseThrust())
				thrust = JetGameValues::MaxCruiseThrust();
		}
		else if (p_jet.decelerate)
		{
			thrust -= JetGameValues::AccelerateThrust();
			if (thrust < 0.0f)
				thrust = 0.0f;
		}

		p_jet.actualThrust = thrust;
		p_jet.rudder = rudder;
		p_jet.leftAileron = leftAileron;
		p_jet.rightAileron = rightAileron;
	}
	else
	{
		// dead
		p_jet.accelerate = false;
		p_jet.afterburner = false;
		p_jet.airBrake = false;
		p_jet.decelerate = false;
		// leave these as whatever the dead event set them to
		//p_jet.leftAileron = 0;
		//p_jet.rightAileron = 0;
		p_jet.rudder = 0;
		p_jet.setThrust = 0.0f;
		p_jet.actualThrust = 0.0f;
	}

	ApplyFlightPhysics(p_jet, p_gravityPerMS2, p_elapsedTimeMS);
}

void JetBehavior::DetermineJoystickThrustAndWeaponUse(JetGameObject &p_jet, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameObjectList &p_gameObjectList)
{
	// no weapons fire until behavior decides to fire.
	p_jet.joystick.gunButton = false;
	p_jet.joystick.secondaryButton = false;

	if (p_jet.dead == true)
	{
		// do nothing!
		return;
	}

	// cycle the timer here since we might not even make the checks on this pass but still want the timer to cycle so that all objects with the timers remain staggered
	bool checkObstruction = false;
	if (p_jet.behaviorDecisionDelay <= 0)
	{
		p_jet.behaviorDecisionDelay += JetGameValues::BehaviorDecisionDelayMS();
		checkObstruction = true;
	}

	// in case thrust on jet is not yet set to anything, set it to something now - if a trigger occurs that doesn't set thrust, we need a good value here
	if (p_jet.setThrust == 0.0f)
	{
		p_jet.setThrust = JetGameValues::MaxCruiseThrust();
	}

	// watch for passing waypoint even when panicking
	// if flew through waypoint (close enough), get next waypoint.  Keep grabbing until next waypoint isn't close enough anymore
	// todo: move this into general behavior in case jet is evading a collision but happens to pass the waypoint
	if ((p_jet.behavior == JetBehaviorEnum::FlyWaypoints || p_jet.behavior == JetBehaviorEnum::PatrolWaypoints) && p_jet.currentWaypointRef != nullptr)
	{
		LinkedListNode<Waypoint> *startingWaypoint = p_jet.currentWaypointRef;
		while ((p_jet.currentWaypointRef->data.point - p_jet.orient.p).MagnitudeSquared() < (400.0f / JetGameValues::FeetPerWorldUnit()))
		{
			p_jet.currentWaypointRef = p_jet.waypointListRef->GetNextWaypoint(p_jet.currentWaypointRef);

			// prevent infinite loop (100 points on top of each other)
			if (p_jet.currentWaypointRef == startingWaypoint)
				break;
		}
	}

	// trigger conditions
	Vector3d collisionNormal, evasionDirection;
	float preferredVelocity = 0.020f; // around 150
	float preferredVelocityMissile = 0.040f; // around 300
	if (TriggerWillCrashIntoTerrain(p_jet, p_terrain, p_worldYWaterLevel, collisionNormal) == true)
	{
		BehaviorFlyInDirectionCritical(p_jet, collisionNormal, &preferredVelocity); // speed up for maneuverability, slow down if too fast
		return;
	}

	if (TriggerIncomingMissile(p_jet, p_gameObjectList, collisionNormal) == true)
	{
		// Evasion direction is at a 45 degree angle against the approaching missile. Collision normal = offset from missile to jet
		Vector3d offsetToMissile = collisionNormal.ScalarMult(-1.0f);
		Vector3d axis = offsetToMissile.CrossProd(p_jet.orient.f);
		if (offsetToMissile.Normalize() == true && axis.Normalize() == true)
		{
			Vector3d axis2 = axis.CrossProd(offsetToMissile);
			// axis2 + offsetToMissile is the closest 45 degree angle against it from f
			BehaviorFlyInDirectionCritical(p_jet, axis2 + offsetToMissile, &preferredVelocityMissile); // afterburner!
		}
		return;
	}

	if (TriggerWillCrashIntoJet(p_jet, p_gameObjectList, collisionNormal) == true)
	{
		BehaviorFlyInDirectionCritical(p_jet, collisionNormal, &preferredVelocity); // speed up for maneuverability, slow down if too fast
		return;
	}

	// main call
	if (p_jet.behavior == JetBehaviorEnum::FlyWaypoints || p_jet.behavior == JetBehaviorEnum::PatrolWaypoints)
	{
		if (p_jet.currentWaypointRef == nullptr)
			p_jet.currentWaypointRef = p_jet.waypointListRef->GetNextWaypoint(nullptr);

		if (p_jet.currentWaypointRef == nullptr)
			// nothing to do
			return;

		// if flew through waypoint (close enough), get next waypoint.  Keep grabbing until next waypoint isn't close enough anymore
		// todo: move this into general behavior in case jet is evading a collision but happens to pass the waypoint
		// note: this is a repeat of above
		LinkedListNode<Waypoint> *startingWaypoint = p_jet.currentWaypointRef;
		while ((p_jet.currentWaypointRef->data.point - p_jet.orient.p).MagnitudeSquared() < (400.0f / JetGameValues::FeetPerWorldUnit()))
		{
			p_jet.currentWaypointRef = p_jet.waypointListRef->GetNextWaypoint(p_jet.currentWaypointRef);

			// prevent infinite loop (100 points on top of each other)
			if (p_jet.currentWaypointRef == startingWaypoint)
				break;
		}

		if (p_jet.behavior == JetBehaviorEnum::FlyWaypoints)
			p_jet.targetRef.Clear();
		else if (p_jet.behavior == JetBehaviorEnum::PatrolWaypoints && (p_jet.targetRef.IsValid() == false || p_jet.targetRef.IsDeleted() || ((JetGameObject *)p_jet.targetRef.Ptr())->dead == true))
		{
			// look for a new target
			p_jet.targetRef.Clear();

			JetGameObject *closestEnemyJet = nullptr;
			float closestEnemyJetDistanceSq = 0.0f;
			LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(p_gameObjectList);
			while (enumerator.MoveNext())
			{
				JetGameObject *jet = &(enumerator.Current()->data);
				if (jet->objectType != JetGameObjectEnum::Jet)
					continue;

				// if missile not targetting this jet, continue
				if (jet->deleted == true || jet->dead == true || jet->alliance == p_jet.alliance)
					continue;

				Vector3d offset = jet->orient.p - p_jet.orient.p;

				// if missile not heading towards jet, not an issue yet
				// actually, yes it is... it's coming around for a pass
				// todo: jet should be smart enough to know when the next missile will strike and prioritize that one, in addition preparing to dodge multiple by choose the right
				//   way to dodge them all (least angle difference between the target directions)
				//if (missile->velocity * (offset) <= 0.0f)
				//	continue;

				float distanceSq = offset.MagnitudeSquared(); // faster
				if (distanceSq < closestEnemyJetDistanceSq || closestEnemyJet == nullptr)
				{
					closestEnemyJet = jet;
					closestEnemyJetDistanceSq = distanceSq;
				}
			}

			if (closestEnemyJet != nullptr && closestEnemyJetDistanceSq <= (JetGameValues::JetEncounterDistance() * JetGameValues::JetEncounterDistance()))
			{
				p_jet.targetRef.Set(closestEnemyJet);
				// todo: announce target to squad.  Let each make their decision accordingly (should not depend on what others have decided, otherwise they can trade decisions back and
				//   forth to each other out of order
				// inform squad to attack that target if they don't already have a target - OR reassign under other circumstance - OR split up the squad each as a different target
				// todo: for now, assign all to same target
				LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(p_gameObjectList);
				bool valid = false;
				// assumes lesser squad members are always later in the list
				while (enumerator.MoveNext())
				{
					if (valid == false)
					{
						if (&(enumerator.Current()->data) == &p_jet) // or ids equal, whatever
							valid = true;
					}
					else
					{
						// same faction, lesser squad
						if (enumerator.Current()->data.objectType == JetGameObjectEnum::Jet && enumerator.Current()->data.faction == p_jet.faction && enumerator.Current()->data.targetRef.gameObjectRef == p_jet.targetRef.gameObjectRef && p_jet.dead == false && p_jet.deleted == false)
						{
							enumerator.Current()->data.targetRef.Set(closestEnemyJet);
						}
					}
				}
			}
		}

		if (p_jet.targetRef.IsValid() == false)
			// Fly to that point!
			BehaviorFlyThroughPoint(p_jet, p_jet.currentWaypointRef->data.point, nullptr, JetGameValues::WaypointFlightThrust());
	}
	else if (p_jet.behavior == JetBehaviorEnum::StayInFormation)
	{
		if (p_jet.squadRank == 0)
			throw gcnew Exception("Squad Leader cannot fly in formation!");

		if  (p_jet.targetRef.IsValid() == false || p_jet.targetRef.IsDeleted() || ((JetGameObject *)p_jet.targetRef.Ptr())->dead == true)
		{
			if (((JetGameObject*)(p_jet.squadLeader.Ptr()))->behavior == JetBehaviorEnum::FlyWaypoints)
				p_jet.targetRef.Clear();
			else if (((JetGameObject*)(p_jet.squadLeader.Ptr()))->behavior == JetBehaviorEnum::PatrolWaypoints)
				// use same target as leader
				p_jet.targetRef.Set(((JetGameObject*)(p_jet.squadLeader.Ptr()))->targetRef.Ptr());
		}

		// should always have a squad leader - just stay in formation if there is no current active target (this will change later - jets in a patrol behavior will look for other targets)
		if (p_jet.squadLeader.IsValid() && p_jet.squadLeader.IsDeleted() == false)
		{
			// if no target, just fly in formation
			if (p_jet.targetRef.IsValid() == false || p_jet.targetRef.IsDeleted() || ((JetGameObject *)p_jet.targetRef.Ptr())->dead == true)
			{
				p_jet.targetRef.Clear();

				// formation by rank:
				//      0
				//    1   2
				//  4   3   5
				// a little lower on each, 5 feet down each rank back

				// direction vector = velocity of lead jet
				Vector3d direction = ((JetGameObject *)p_jet.squadLeader.Ptr())->orient.f;
				// left vector will be crossproduct with 0,1,0 - only pitch on the lead jet affects the angle of the formation, not roll
				Vector3d left = Vector3d(0, 1, 0).CrossProd(direction);
				if (left.Normalize() == false)
					// fine, use orient.l for left since the jet is vertical
					left = ((JetGameObject *)p_jet.squadLeader.Ptr())->orient.l;
				// now get an up vector
				Vector3d up = direction.CrossProd(left);
				// and the start position
				Vector3d leadPosition = ((JetGameObject *)p_jet.squadPartner.Ptr())->orient.p;

				// for now only support 5 non leader ranks (1-5)
				float leftOffset = 0.0f;
				float directionOffset = 0.0f;
				float upOffset = 0.0f;
				// offsets are relative to the partner jet
				switch (p_jet.squadRank)
				{
				case 1:
					leftOffset = 30.0f / JetGameValues::FeetPerWorldUnit();
					directionOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					upOffset = -5.0f / JetGameValues::FeetPerWorldUnit();
					break;
				case 2:
					leftOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					directionOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					upOffset = -5.0f / JetGameValues::FeetPerWorldUnit();
					break;
				case 3:
					leftOffset = 30.0f / JetGameValues::FeetPerWorldUnit();
					directionOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					upOffset = -5.0f / JetGameValues::FeetPerWorldUnit();
					break;
				case 4:
					leftOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					directionOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					upOffset = -5.0f / JetGameValues::FeetPerWorldUnit();
					break;
				case 5:
					leftOffset = 30.0f / JetGameValues::FeetPerWorldUnit();
					directionOffset = -30.0f / JetGameValues::FeetPerWorldUnit();
					upOffset = -5.0f / JetGameValues::FeetPerWorldUnit();
					break;
				}

				// determine position to fly to and do so
				Vector3d position = leadPosition + direction.ScalarMult(directionOffset) + up.ScalarMult(upOffset) + left.ScalarMult(leftOffset);

				// see if jet should speed up or target a different point

				// for now, just fly through it
				// todo: the velocity here was updated by BehaviorFlyToPoint on the squad leader, so it isn't the same as the velocity at the beginning of this tick
				//    just keep it in mind if close up adjustments aren't working
				BehaviorFlyOnPoint(p_jet, position, ((JetGameObject *)p_jet.squadLeader.Ptr())->velocity);
			}
		}
		else
			throw gcnew Exception("Squad Leader is gone with no replacement! Make sure squad has a replacement leader when the leader is deleted or missing!");
	}
	else
	{
		// hard coded for now - default behavior
		p_jet.setThrust = JetGameValues::MaxCruiseThrust();
		p_jet.joystick.intendedX = 0;
		p_jet.joystick.intendedY = 400;
		p_jet.joystick.intendedTwist = 0;
	}

	// checked the behaviors and made decisions, one final check - if we have a target, attack!
	if (p_jet.targetRef.IsValid() == true)
	{
		// attack the target!

		// first, see if we are close to squadmates.  If so, put some distance away from them to avoid hitting them with weapons
		// if too close, fly away
		// if friendly is inside a cone projected at the target, fly away
		// otherwise, attack!
		LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(p_gameObjectList);
		JetGameObject *closestAlly = nullptr;
		float closestAllyDistanceSq = 0.0f;
		Vector3d offsetToTarget = ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p - p_jet.orient.p;
		Vector3d offsetToTargetUnit = offsetToTarget;
		offsetToTargetUnit.Normalize(); // if 0 length, we collided anyway
		Vector3d totalAllyInConeOffset = Vector3d(0, 0, 0);
		int allyInConeQty = 0;
		bool justGetCloser = false; // if allies are too close to get outside of cone, just get closer to the target
		while (enumerator.MoveNext())
		{
			if (&(enumerator.Current()->data) == &p_jet)
				continue;
			if (enumerator.Current()->data.alliance != p_jet.alliance)
				continue;
			if (enumerator.Current()->data.deleted == true || enumerator.Current()->data.dead == true)
				continue;
			// if ally is farther away than target, don't worry about it (farther away in facing from flier)
			Vector3d targetToAllyOffset = (enumerator.Current()->data.orient.p - ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p);
			if (targetToAllyOffset * p_jet.orient.f > 0.0f)
				continue;
			Vector3d offsetToAlly = (enumerator.Current()->data.orient.p - p_jet.orient.p);
			float distanceSq = offsetToAlly.MagnitudeSquared();
			// go for 20 feet away
			if (distanceSq < 400.0f / JetGameValues::FeetPerWorldUnit())
			{
				if (distanceSq < closestAllyDistanceSq || closestAlly == nullptr)
				{
					closestAlly = &(enumerator.Current()->data);
					closestAllyDistanceSq = distanceSq;
				}
				// done with this one, cone doesn't matter for this jet, it's too close
				continue;
			}
			// if we have a closest Ally to avoid, we have nothing else to check
			if (closestAlly != nullptr)
				continue;
			// how about the cone?
			// don't bother if we aren't even facing the target
			if (offsetToTarget * p_jet.orient.f > 0.0f)
			{
				offsetToAlly.Normalize(); // if 0 we collided anyway
				float angleBetweenOffsets = offsetToAlly * offsetToTargetUnit; // two unit vectors.
				// if result in within 10 degrees, they are too close in the cone
				if (angleBetweenOffsets > 0.985f)
				{
					if (justGetCloser == false)
					{
						// if ally is 4x closer, don't bother trying to get them out of the cone, just fly closer - otherwise this jet will cosntantly fly off and get farther away from the fight
						if ((targetToAllyOffset.MagnitudeSquared() / offsetToTarget.MagnitudeSquared()) < 0.0625f)
						{
							justGetCloser = true;
							allyInConeQty++;
						}
						else
						{
							totalAllyInConeOffset = totalAllyInConeOffset + enumerator.Current()->data.orient.p;
							allyInConeQty++;
						}
					}
				}
			}
		}
		if (closestAlly != nullptr)
		{
			// determine direction to fly
			Vector3d direction = p_jet.orient.p - closestAlly->orient.p;
			BehaviorFlyInDirectionCritical(p_jet, direction);
		}
		else if (allyInConeQty > 0)
		{
			if (justGetCloser == true)
			{
				// get closer to the fight fast and don't fire
				float flyFast = 0.040f; // afterburner
				BehaviorFlyInDirectionCritical(p_jet, offsetToTarget, &flyFast);
			}
			else
			{
				// determine direction to fly - 
				// multiple allies in cone means take the midpoint between all of them as the target direction to fly (offset from target)
				Vector3d direction = ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p - totalAllyInConeOffset.ScalarMult(1.0f / float(allyInConeQty));
				direction = direction - p_jet.orient.f.ScalarMult(direction * p_jet.orient.f);
				if (direction.Normalize() == false)
					direction = p_jet.orient.l; // just fly 45 degrees left
				BehaviorFlyInDirectionCritical(p_jet, direction + p_jet.orient.f); // fly in a 45 degree line that will get the ally out of the cone
			}
		}
		else
		{
			// attaaaaack!
			AttackTarget(p_jet, checkObstruction, p_terrain);
		}
	}
}

bool JetBehavior::CheckWeaponObstruction(JetGameObject &p_jet, TerrainMesh &p_terrain)
{
	float terrainCollisionT;
	Vector3d terrainCollisionLocation, terrainCollisionNormal;
	return p_terrain.SphereCollision(p_jet.orient.p, ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p - p_jet.orient.p, 0.1f, terrainCollisionT, terrainCollisionLocation, terrainCollisionNormal);
}

void JetBehavior::AttackTarget(JetGameObject &p_jet, bool p_checkObstruction, TerrainMesh &p_terrain)
{
	// see if weapon is obstructed by terrain - do NOT call this too often!  It's expensive!  Especially at long distances!!!
	// if obstructed, don't fire.
	if (p_checkObstruction == true)
	{
		p_jet.weaponObstructed = CheckWeaponObstruction(p_jet, p_terrain);
	}

	// fly at the bullet lead shot - if that's not possible just fly at the target
	float strikeT;
	Vector3d projectileDirection;
	// todo: jet position in list gives later objects an advantage.  same time stamp of velocity shoudl be used for everyone
	if (MathUtilities::ProjectileStrikeObjectApproximateGravity(p_jet.orient.p, p_jet.velocity, JetGameValues::BulletExitSpeedFeetPerMS(), JetGameValues::GravityAccelerationPerMSSquared(), ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p, ((JetGameObject *)p_jet.targetRef.Ptr())->velocity, strikeT, projectileDirection) == true)
	{
		// if pretty much pointing at that location, fire guns!
		Vector3d unitDirection = projectileDirection;
		if (unitDirection.Normalize() == true)
		{
			if (unitDirection * p_jet.orient.f >= 0.999f && (p_jet.orient.p - ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p).MagnitudeSquared() < 17424.0f) // quarter mile (132x132)
			{
				if (p_jet.weaponObstructed == false)
					p_jet.joystick.gunButton = true;
			}
		}
		float flyFast = 0.040f;
		float dogfightSpeed = 0.020f;
		float targetSpeed = dogfightSpeed;
		if ((p_jet.orient.p - ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p).MagnitudeSquared() > 4356.0f) // 1/8 mile
			// get closer for guns!
			targetSpeed = flyFast;
		BehaviorFlyInDirectionDogfight(p_jet, projectileDirection, &targetSpeed);
		//BehaviorFlyThroughPoint(p_jet, p_jet.orient.p + projectileDirection, nullptr, JetGameValues::MaxCruiseThrust());
	}
	else
	{
		// just fly at the target directly
		float flyFast = 0.040f;
		float dogfightSpeed = 0.020f;
		float targetSpeed = dogfightSpeed;
		if ((p_jet.orient.p - ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p).MagnitudeSquared() > 4356.0f) // 1/8 mile
			// get closer for guns!
			targetSpeed = flyFast;
		BehaviorFlyInDirectionDogfight(p_jet, ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p - p_jet.orient.p, &targetSpeed);
		//BehaviorFlyThroughPoint(p_jet, ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p, nullptr, JetGameValues::MaxCruiseThrust());
	}
	// fire a missile if basically pointing at target
	if (p_jet.missileAITimerMS <= 0)
	{
		Vector3d offsetToTarget = ((JetGameObject *)p_jet.targetRef.Ptr())->orient.p - p_jet.orient.p;
		if (offsetToTarget.Normalize() == true)
		{
			// todo: watch for missile ammo to be enough
			if (offsetToTarget * p_jet.orient.f >= 0.9848f) // within 10 degrees of center, same as for player controlled circle indicator
			{
				if (p_jet.weaponObstructed == false)
				{
					p_jet.joystick.secondaryButton = true;
				}
			}
		}
	}
}

void JetBehavior::BehaviorFlyOnPoint(JetGameObject &p_jet, Vector3d &p_point, Vector3d &p_pointVelocity)
{
	// decide only on rudder and joystick values here

	// if jet is fairly close and jet and point are pretty much flying in the same direction, alter velocity to match (small amount), pitch and rudder as appropriate, keeping jet level if it isn't already
	// if point is far away and is travelling in the opposite direction (towards the back), target a point far beside the target that is easy to get to from current orientation
	// if point is flying in same direction but is far away, increase thrust to catch up (a lot if very far away)
	// if point is getting close, reduce thrust a bit but still catch up to it

	bool accelerate = false;
	bool decelerate = false;
	bool afterburner = false;
	bool airBrake = false;

	Vector3d offset = (p_point - p_jet.orient.p);
	float pitchOffset = offset * p_jet.orient.u;
	float rudderOffset = offset * p_jet.orient.l;
	float angleOffFront = offset * p_jet.orient.f;

	// point flying in same direction as jet
	if (p_jet.velocity * p_pointVelocity > 0.0f)
	{
		// both basically travelling in the same direction
		if ((p_pointVelocity * p_jet.velocity) > 0.0f)
		{
			Vector3d targetPoint = p_point;
			float intendedThrust = JetGameValues::WaypointFlightThrust();

			if (angleOffFront > 800.0f / JetGameValues::FeetPerWorldUnit())
			{
				afterburner = true;
				targetPoint = p_point + p_pointVelocity.ScalarMult(4000.0f);
			}
			else if (angleOffFront > 10.0f / JetGameValues::FeetPerWorldUnit())
			{
				accelerate = true;
				targetPoint = p_point + p_pointVelocity.ScalarMult(500.0f);
			}
			/*
			else if (angleOffFront > 20.0f / JetGameValues::FeetPerWorldUnit())
			{
			intendedThrust = JetGameValues::WaypointFlightThrust() + JetGameValues::AdjustThrust() * 6.0f;
			targetPoint = p_point + p_pointVelocity.ScalarMult(1000.0f);
			}
			else if (angleOffFront > 10.0f / JetGameValues::FeetPerWorldUnit())
			{
			intendedThrust = JetGameValues::WaypointFlightThrust() + JetGameValues::AdjustThrust() * 4.0f;
			targetPoint = p_point + p_pointVelocity.ScalarMult(1000.0f);
			}
			*/
			else
			{
				// we're real close
				intendedThrust = JetGameValues::WaypointFlightThrust();
				targetPoint = p_point + p_pointVelocity.ScalarMult(200.0f);
			}

			// see how long it will take to pass the point we are flying to
			// if it will happen quickly, apply airBrakes.  If it will take a while, afterburner
			float velocityDotProd = (p_jet.velocity - p_pointVelocity) * p_pointVelocity;
			if (abs(velocityDotProd) > 0.00001f)
			{
				float timeToPass = ((p_point - p_jet.orient.p) * p_pointVelocity) / velocityDotProd;
				if ((timeToPass >= 0.0f && timeToPass <= 500.0f))
					airBrake = true; // slow down!!!
				if (timeToPass >= 3000.0f)
					afterburner = true; // go fast!!!
			}
			// if travelling in same direction but jet passed it, airbrake!
			if ((p_jet.velocity * p_pointVelocity) > 0.0f && angleOffFront < 0.0f)
				airBrake = true;

			// just fly normally with acceleration values
			BehaviorFlyThroughPoint(p_jet, targetPoint, nullptr, intendedThrust, false, accelerate, decelerate, afterburner, airBrake);
		}
		else
		{
			// point is flying opposite of jet
			// todo: pick a point off to the side of the target point so that a wide angle is chosen
			BehaviorFlyThroughPoint(p_jet, p_point, nullptr, JetGameValues::WaypointFlightThrust());
		}
	}
	else
	{
		if (abs(pitchOffset) < (5.0f / JetGameValues::FeetPerWorldUnit()) && abs(rudderOffset) < (5.0f / JetGameValues::FeetPerWorldUnit()) && abs(angleOffFront) < (10.0f / JetGameValues::FeetPerWorldUnit()))
		{
			decelerate = true;
			// just fly at a point a little bit ahead with deceleration values (don't change direction)
			BehaviorFlyThroughPoint(p_jet, p_point + p_pointVelocity.ScalarMult(1000.0f), nullptr, JetGameValues::WaypointFlightThrust(), false, accelerate, decelerate, afterburner, airBrake);
		}
		else
		{
			// do whatever it takes to get to the point
			BehaviorFlyThroughPoint(p_jet, p_point, nullptr, JetGameValues::WaypointFlightThrust());
		}
	}

}

void JetBehavior::BehaviorFlyInDirectionCritical(JetGameObject &p_jet, Vector3d &p_direction, float *p_preferredVelocity)
{
	// decide only on rudder and joystick values here, and thrust modifiers
	// the only goal is to generally get flying in that direction

	Vector3d unitDirection = p_direction;
	if (unitDirection.Normalize() == false)
		return;

	// turn hard to fly in direction
	p_jet.accelerate = false;
	p_jet.decelerate = false;
	p_jet.airBrake = false;

	if (p_preferredVelocity != nullptr)
	{
		p_jet.afterburner = false;

		float currentVelocity = p_jet.velocity.Magnitude();
		if (currentVelocity < (*p_preferredVelocity * 0.80f))
			p_jet.afterburner = true;
		else if (currentVelocity >(*p_preferredVelocity * 1.30f))
			p_jet.airBrake = true;
	}
	else
		p_jet.afterburner = false;

	p_jet.joystick.intendedX = 0;
	p_jet.joystick.intendedY = 0;
	p_jet.joystick.intendedTwist = 0;
	if (unitDirection * p_jet.orient.l > 0.02f)
	{
		p_jet.joystick.intendedX = -1000;
		p_jet.joystick.intendedTwist = -1000;
	}
	else if (unitDirection * p_jet.orient.l < -0.02f)
	{
		p_jet.joystick.intendedX = 1000;
		p_jet.joystick.intendedTwist = 1000;
	}
	else if (unitDirection * p_jet.orient.f < 0.0f) // if mostly behind, turn hard! LIKE A BOSS!
	{
		if (unitDirection * p_jet.orient.l < 0.0f)
		{
			p_jet.joystick.intendedX = 1000;
			p_jet.joystick.intendedTwist = 1000;
		}
		else
		{
			p_jet.joystick.intendedX = -1000;
			p_jet.joystick.intendedTwist = -1000;
		}
	}
	if (unitDirection * p_jet.orient.u > 0.02f)
		p_jet.joystick.intendedY = 1000;
	else if (unitDirection * p_jet.orient.u < -0.02f)
		p_jet.joystick.intendedY = -1000;
	else if (unitDirection * p_jet.orient.f < 0.0f) // if mostly behind, turn hard!  LIKE A BOSS!
	{
		if (unitDirection * p_jet.orient.u < 0.0f)
		{
			p_jet.joystick.intendedY = -1000;
		}
		else
		{
			p_jet.joystick.intendedY = 1000;
		}
	}

	// leave set thrust as is
}

void JetBehavior::BehaviorFlyInDirectionDogfight(JetGameObject &p_jet, Vector3d &p_direction, float *p_preferredVelocity)
{
	// decide only on rudder and joystick values here, and thrust modifiers
	// the goal is to quickly fly in the desired direction, but to fly there accurately so that guns can be brought to bare and to level out

	Vector3d unitDirection = p_direction;
	if (unitDirection.Normalize() == false)
		return;

	// turn hard to fly in direction
	p_jet.accelerate = false;
	p_jet.decelerate = false;
	p_jet.airBrake = false;

	if (p_preferredVelocity != nullptr)
	{
		p_jet.afterburner = false;

		float currentVelocity = p_jet.velocity.Magnitude();
		if (currentVelocity < (*p_preferredVelocity * 0.80f))
			p_jet.afterburner = true;
		else if (currentVelocity >(*p_preferredVelocity * 1.30f))
			p_jet.airBrake = true;
	}
	else
		p_jet.afterburner = false;

	p_jet.joystick.intendedX = 0;
	p_jet.joystick.intendedY = 0;
	p_jet.joystick.intendedTwist = 0;
	float rudderOffset = unitDirection * p_jet.orient.l;
	float pitchOffset = unitDirection * p_jet.orient.u;
	float angleOffFront = unitDirection * p_jet.orient.f;
	// rudder
	if (angleOffFront < 0.0f) // if mostly behind, turn hard! LIKE A BOSS!
	{
		if (rudderOffset < 0.0f)
		{
			p_jet.joystick.intendedX = 1000;
			p_jet.joystick.intendedTwist = 1000;
		}
		else
		{
			p_jet.joystick.intendedX = -1000;
			p_jet.joystick.intendedTwist = -1000;
		}
	}
	else if (rudderOffset > 0.0f)
	{
		if (rudderOffset > 0.05f)
		{
			p_jet.joystick.intendedX = -1000;
			p_jet.joystick.intendedTwist = -1000;
		}
		else
		{
			// delicate maneuvering to bring guns to bear
			if (rudderOffset > 0.01f)
				p_jet.joystick.intendedTwist = -800;
			else
				// very smooth near center
				p_jet.joystick.intendedTwist = -JetGameValues::JoystickTwistDeadArea() - int((800.f - float(JetGameValues::JoystickTwistDeadArea())) / 0.01f * rudderOffset);
		}
	}
	else if (rudderOffset < 0.0f)
	{
		if (rudderOffset < -0.05f)
		{
			p_jet.joystick.intendedX = 1000;
			p_jet.joystick.intendedTwist = 1000;
		}
		else
		{
			// delicate maneuvering to bring guns to bear
			if (rudderOffset < -0.01f)
				p_jet.joystick.intendedTwist = 800;
			else
				// very smooth near center
				p_jet.joystick.intendedTwist = JetGameValues::JoystickTwistDeadArea() - int((800.f - float(JetGameValues::JoystickTwistDeadArea())) / 0.01f * rudderOffset);
		}
	}

	// pitch
	if (angleOffFront < 0.0f) // if mostly behind, turn hard!  LIKE A BOSS!
	{
		if (pitchOffset < 0.0f)
		{
			p_jet.joystick.intendedY = -1000;
		}
		else
		{
			p_jet.joystick.intendedY = 1000;
		}
	}
	else if (pitchOffset > 0.0f)
	{
		if (pitchOffset > 0.05f)
			p_jet.joystick.intendedY = 1000;
		else
		{
			// delicate maneuver to bring guns to bear
			p_jet.joystick.intendedY = JetGameValues::JoystickPrimaryDeadArea() + int((1000.f - float(JetGameValues::JoystickPrimaryDeadArea())) / 0.05f * pitchOffset);
		}
	}
	else if (pitchOffset < 0.0f)
	{
		if (pitchOffset < -0.05f)
			p_jet.joystick.intendedY = -1000;
		else
		{
			// delicate maneuver to bring guns to bear
			p_jet.joystick.intendedY = -JetGameValues::JoystickPrimaryDeadArea() + int((1000.f - float(JetGameValues::JoystickPrimaryDeadArea())) / 0.05f * pitchOffset);
		}
	}
	
	// roll level if facing target
	if (angleOffFront > 0.8f)
	{
		if (p_jet.orient.u.y < 0.0f)
		{
			// upside down!  right yourself most directly!
			if (p_jet.orient.l.y > 0.02f)
				p_jet.joystick.intendedX = -1000;
			else
				p_jet.joystick.intendedX = 1000;
		}
		else
		{
			if (p_jet.orient.l.y > 0.02f)
				p_jet.joystick.intendedX = -600;
			else if (p_jet.orient.l.y < -0.02f)
				p_jet.joystick.intendedX = 600;
		}
	}

	// leave set thrust as is
}

bool JetBehavior::BehaviorFlyThroughPoint(JetGameObject &p_jet, Vector3d &p_point, Vector3d *p_targetDirection, float p_intendedThrust, bool p_allowAlternatePoint, bool p_accelerate, bool p_decelerate, bool p_afterburner, bool p_airBrake)
{
	// decide only on rudder and joystick values here

	// p_targetDirection is optional - instructs jet to fly through point within a certain direction (if in bad position, just target a point enough in front of the target point
	//   that will help with entering from the correct direction then just fly towards it)

	Vector3d targetPoint = p_point;

	// if at a distance and point is generally in front, level off if not already, rudder towards it and pitch down depending on severity of the need to alter direction
	// if generally close to the correct pitch and far away, level off if not already, pitch just a little
	// if generally close to the correct bearing and far away, level off if not already, rudder just a little
	// if off a bit from correct pitch and too close to be able to correct pitch, turn away from the point along a horizontal line from it (target a point some distance away)
	// if off a bit from correct bearing and too close to be able to correct bearing, turn away from the point (target a point some distance away)

	// (used for target point or a different point we just decided to fly towards)
	// if significantly off from correct bearing and far enough away, turn towards it (pitch if less than 90 degrees, or roll and pitch towards it, then level out)
	Vector3d offset = targetPoint - p_jet.orient.p;
	float distance = offset.Magnitude();
	if (distance > 0.00001f) // if on point just keep flying - main routine above already decided on next point that is supposed to be far enough away
	{
		offset = offset.ScalarMult(1.0f / distance);

		float pitchOffset = offset * p_jet.orient.u;
		float rudderOffset = offset * p_jet.orient.l;
		float angleOffFront = offset * p_jet.orient.f;

		// if diving towards the point and it is far away, obligate a more horizontal approach
		if (p_allowAlternatePoint == true && p_point.y < p_jet.orient.p.y && distance >(1000.0f / JetGameValues::FeetPerWorldUnit()))
		{
			Vector3d horizontalApproach = p_jet.orient.p + (p_point - p_jet.orient.p).ScalarMult(0.5f);
			horizontalApproach.y = p_point.y;
			BehaviorFlyThroughPoint(p_jet, horizontalApproach, nullptr, JetGameValues::WaypointFlightThrust(), false, p_accelerate, p_decelerate, p_afterburner, p_airBrake);
			return true;
		}

		// don't want to pitch endlessly in a circle around a point we can't reach
		if (p_allowAlternatePoint == true && angleOffFront < 0.40f && distance < (400.0f / JetGameValues::FeetPerWorldUnit()) && distance >(30.0f / JetGameValues::FeetPerWorldUnit()))
		{
			// fly through a point farther away to get a better approach - don't let this attempt try an alternate point
			BehaviorFlyThroughPoint(p_jet, p_jet.orient.p - offset.ScalarMult(100.0f), nullptr, JetGameValues::WaypointFlightThrust(), false);
			return true;
		}

		p_jet.joystick.intendedX = 0;
		if (pitchOffset < 0.0f)
		{
			// pitch hard if hard angle or behind
			if (pitchOffset < -0.3f || angleOffFront < 0.0f)
				p_jet.joystick.intendedY = -700;
			else if (pitchOffset < -0.05f)
				p_jet.joystick.intendedY = -400;
			else
				// very smooth near center
				p_jet.joystick.intendedY = -JetGameValues::JoystickPrimaryDeadArea() + int((400.f - float(JetGameValues::JoystickPrimaryDeadArea())) / 0.05f * pitchOffset);
		}
		else
		{
			// pitch hard if hard angle or behind
			if (pitchOffset > 0.3f || angleOffFront < 0.0f)
				p_jet.joystick.intendedY = 700;
			else if (pitchOffset > 0.05f)
				p_jet.joystick.intendedY = 400;
			else
				// very smooth near center
				p_jet.joystick.intendedY = JetGameValues::JoystickPrimaryDeadArea() + int((400.f - float(JetGameValues::JoystickPrimaryDeadArea())) / 0.05f * pitchOffset);
		}
		if (rudderOffset < 0.0f)
		{
			if (distance >(100.0f / JetGameValues::FeetPerWorldUnit()) && angleOffFront < 0.8f)
				// roll towards it to help pitch
				p_jet.joystick.intendedX = 600;

			// rudder hard if hard angle or behind
			if (rudderOffset < -0.2f || angleOffFront < 0.0f)
				p_jet.joystick.intendedTwist = 1000;
			else if (rudderOffset < -0.05f)
				p_jet.joystick.intendedTwist = 800;
			else if (rudderOffset < -0.01f)
				p_jet.joystick.intendedTwist = 600;
			else
				// very smooth near center
				p_jet.joystick.intendedTwist = JetGameValues::JoystickTwistDeadArea() - int((600.f - float(JetGameValues::JoystickTwistDeadArea())) / 0.01f * rudderOffset);
		}
		else
		{
			if (distance >(100.0f / JetGameValues::FeetPerWorldUnit()) && angleOffFront < 0.8f)
				// roll towards it to help pitch
				p_jet.joystick.intendedX = -600;

			// rudder hard if hard angle or behind
			if (rudderOffset > 0.2f || angleOffFront < 0.0f)
				p_jet.joystick.intendedTwist = -1000;
			else if (rudderOffset > 0.05f)
				p_jet.joystick.intendedTwist = -800;
			else if (rudderOffset > 0.01f)
				p_jet.joystick.intendedTwist = -600;
			else
				// very smooth near center
				p_jet.joystick.intendedTwist = -JetGameValues::JoystickTwistDeadArea() - int((600.f - float(JetGameValues::JoystickTwistDeadArea())) / 0.01f * rudderOffset);
		}

		if (angleOffFront >= 0.8f)
		{
			// level off
			if (p_jet.orient.l.y > 0.0f)
			{
				if (p_jet.orient.l.y > 0.3f)
					p_jet.joystick.intendedX = -400;
				else if (p_jet.orient.l.y > 0.1f)
					p_jet.joystick.intendedX = -250;
				else
					// very smooth near center
					p_jet.joystick.intendedX = -JetGameValues::JoystickPrimaryDeadArea() - int((250.f - float(JetGameValues::JoystickPrimaryDeadArea())) / 0.1f * p_jet.orient.l.y);
			}
			else
			{
				if (p_jet.orient.l.y < -0.3f)
					p_jet.joystick.intendedX = 400;
				else if (p_jet.orient.l.y < -0.1f)
					p_jet.joystick.intendedX = 250;
				else
					// very smooth near center
					p_jet.joystick.intendedX = JetGameValues::JoystickPrimaryDeadArea() - int((250.f - float(JetGameValues::JoystickPrimaryDeadArea())) / 0.1f * p_jet.orient.l.y);
			}
		}
	}

	// cruise thrust to fly waypoints, never accelerate or decelerate for this, or afterburner, for now
	p_jet.setThrust = p_intendedThrust;
	p_jet.accelerate = p_accelerate;
	p_jet.decelerate = p_decelerate;
	p_jet.afterburner = p_afterburner;
	p_jet.airBrake = p_airBrake;

	return true;
}

bool JetBehavior::TriggerFlewThroughPoint(JetGameObject &p_jet, Vector3d &p_point)
{
	Vector3d offset = p_point - p_jet.orient.p;
	if (offset * p_jet.orient.f < 0.0f && offset.MagnitudeSquared() < 1.0f)
		return true;

	return false;
}

bool JetBehavior::BehaviorAvoidCollision(JetGameObject &p_jet, Vector3d &p_point, Vector3d *p_surfaceNormal, Vector3d *p_pointVelocity, float *p_preferredVelocity)
{
	// fly such that a collision is avoided
	// optionally, surface normal is the orientation of the surface being collided with and guides where the jet should fly
	// optionally, pointVelocity is the travel direction of the colliding point and guides which way the jet should turn to avoid it
	// optionally, a preferred Velocity to use to achieve the effect (slow jets need to speed up, afterburner should be turned off if too fast, etc.)
	if (p_surfaceNormal != nullptr)
	{
		BehaviorFlyInDirectionCritical(p_jet, *p_surfaceNormal, p_preferredVelocity);
	}
	else
	{
		// do something about the point and its velocity (collision with jet)
	}
	return true;
}

bool JetBehavior::TriggerWillCrashIntoTerrain(JetGameObject &p_jet, TerrainMesh &p_terrain, float p_worldYWaterLevel, Vector3d &p_surfaceNormal)
{
	float timePredictionMS = 1500.0;  // if will crash into terrain in 1.5 second, respond (the larger this is, the slower the app)

	Vector3d startPoint = p_jet.orient.p;
	Vector3d travelVector = p_jet.velocity.ScalarMult(timePredictionMS);
	float radius = JetGameValues::JetFuselageTerrainCollisionPredictionRadius();
	float collisionT = 0.0f;
	Vector3d terrainCollisionLocation;
	Vector3d surfaceNormal;
	Vector3d waterNormal = Vector3d(0, 1, 0);

	if (p_terrain.SphereCollision(startPoint, travelVector, radius, collisionT, terrainCollisionLocation, p_surfaceNormal) == true)
	{
		return true;
	}
	else
	{
		// see if will crash into water
		if (MathUtilities::SpherePlaneCollision(startPoint, travelVector, radius, Vector3d(0, p_worldYWaterLevel, 0), waterNormal, collisionT) == true)
		{
			p_surfaceNormal = waterNormal;
			return true;
		}
	}

	// now see if the sphere has intersected what we are trying to avoid, as a last ditch effort to avoid a collision
	if (p_terrain.SphereIntersection(startPoint, radius, p_surfaceNormal) == true)
	{
		return true;
	}
	else if (startPoint.y - radius < p_worldYWaterLevel)
	{
		p_surfaceNormal = waterNormal;
		return true;
	}

	return false;
}

bool JetBehavior::TriggerWillCrashIntoJet(JetGameObject &p_thisJet, JetGameObjectList &p_gameObjectList, Vector3d &p_collisionNormal)
{
	float predictionTimeMS = 1500.0f; // if will collide in this many ms, respond (the larger this is, the slower the app)
	Vector3d travelVector = p_thisJet.velocity.ScalarMult(predictionTimeMS);
	LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(p_gameObjectList);
	bool valid = false;
	float noCollision = 10.0f;
	float earliestCollision = noCollision;
	while (enumerator.MoveNext())
	{
		JetGameObject *otherJet = &(enumerator.Current()->data);
		if (otherJet->objectType != JetGameObjectEnum::Jet)
			continue;

		// don't check jet against itself
		// but check ALL jets for making decisions against each other
		if (&(enumerator.Current()->data) != &p_thisJet && enumerator.Current()->data.deleted == false)
		{
			Vector3d offsetToOtherJet = p_thisJet.orient.p - otherJet->orient.p;
			// only care about jets that can be seen (jets in the same faction are more aware of each other - not jets on same team)
			if ((p_thisJet.faction == otherJet->faction) || (offsetToOtherJet * p_thisJet.orient.f) <= 0.0f)
			{
				float collisionT = 0.0f;
				// either this jet will hit that one, or that one will hit this one - handled by this one call
				float predictionRadius = JetGameValues::JetFuselageJetCollisionPredictionRadius();
				Vector3d velocity = travelVector - otherJet->velocity.ScalarMult(predictionTimeMS);
				//if (velocity.MagnitudeSquared() > 0.001f)
				// make it more stringent if jets are approaching each other at an uncomfortable rate
				//predictionRadius = predictionRadius * 2.5f;
				if (MathUtilities::SphereSphereCollision(p_thisJet.orient.p, velocity, predictionRadius, otherJet->orient.p, predictionRadius, collisionT) == true)
				{
					if (collisionT < earliestCollision)
					{
						earliestCollision = collisionT;
						// calculate position of colliding jets to get a normal to fly to avoid collision
						Vector3d thisJetPosition = p_thisJet.orient.p + p_thisJet.velocity.ScalarMult(earliestCollision);
						Vector3d otherJetPosition = otherJet->orient.p + otherJet->velocity.ScalarMult(earliestCollision);
						p_collisionNormal = thisJetPosition - otherJetPosition; // fly that way!  Away from the other jet!
					}
				}
			}
		}
	}

	if (earliestCollision != noCollision)
		return true;
	else
		return false;
}

bool JetBehavior::TriggerIncomingMissile(JetGameObject &p_thisJet, JetGameObjectList &p_gameObjectList, Vector3d &p_collisionNormal)
{
	JetGameObject *closestMissile = nullptr;
	float closestMissileDistanceSq = 0.0f;
	LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(p_gameObjectList);
	while (enumerator.MoveNext())
	{
		JetGameObject *missile = &(enumerator.Current()->data);
		if (missile->objectType != JetGameObjectEnum::Missile)
			continue;

		// if missile not targetting this jet, continue
		if (missile->deleted == true || missile->targetRef.IsValid() == false || ((JetGameObject *)missile->targetRef.Ptr()) != &(p_thisJet))
			continue;

		Vector3d offset = missile->orient.p - p_thisJet.orient.p;

		// if missile not heading towards jet, not an issue yet
		// actually, yes it is... it's coming around for a pass
		// todo: jet should be smart enough to know when the next missile will strike and prioritize that one, in addition preparing to dodge multiple by choose the right
		//   way to dodge them all (least angle difference between the target directions)
		//if (missile->velocity * (offset) <= 0.0f)
		//	continue;

		float distanceSq = offset.MagnitudeSquared(); // faster
		if (distanceSq < closestMissileDistanceSq || closestMissile == nullptr)
		{
			closestMissile = missile;
			closestMissileDistanceSq = distanceSq;
			p_collisionNormal = offset.ScalarMult(-1.0f);
		}
	}

	if (closestMissile != nullptr)
	{
		return true;
	}
	else
		return false;
}

bool JetBehavior::TriggerThereIsAnIncomingMissile(JetGameObject &p_jet)
{
	return false;
}

// simulate that AI is using joystick like a person
void JetBehavior::ProcessIntendedJoystickValues(GameJoystickValues &p_joystickValues, float p_elapsedTimeMSf, float p_userJoystickMoveAmountPerMS, float p_userTwistMoveAmountPerMS)
{
	int joystickValueToApply = int(p_userJoystickMoveAmountPerMS  * p_elapsedTimeMSf);
	int twistValueToApply = int(p_userTwistMoveAmountPerMS  * p_elapsedTimeMSf);
	p_joystickValues.ApplyValues(joystickValueToApply, twistValueToApply);
}

// rudder and ailerons range from -1.0f to 1.0f
void JetBehavior::ApplyFlightPhysics(JetGameObject &p_jet, float p_gravityPerMS2, float p_MS)
{
	// increase the coeefficients for higher encounter speed, decrease for lower
	// get good numbers for high speed and low speed, and ZERO speed.
	// good thrust and drag for front wind to establish max forward speed too

	// coefficients should change based on airspeed to give the craft different characteristics at different speeds
	// at very low speeds the craft should act like a stone
	// at very high speeds (300mph) it should act like a dart
	// at cruising speed (150mph) it should be a comfortable craft and fun to maneuver

	///////////////////////
	// TEST CONIDITIONS:

	// thrust:
	// max cruising speed should be 150mph or so
	// turbo max speed should be around 300mph or so
	// combination of thrust factor and forward drag factor

	// at thrust zero:
	// as speed decreases on a 45 degree climb, the craft should stall out on a climb and drop because the angle of attack on the wings is too much
	// From a vertical standstill position, the craft's rear wings should catch the wing and quickly turn it downwards
	// from a sideways position, near zero velocity, the plane shoudl quickly drop and turn downward

	// accelerating:
	// from a standstill to normal thrust, should appear 'fun' and energetic
	// from a standstill to turbo: very fast originally
	// from normal thrust to turbo: should feel impactful
	// max cruising speed should be 150mph
	// max turbo speed should be 300mph

	// decelerating:
	// from turbo to zero: should decrease rapidly at first (air collision drag, cavitating) then gradually drop to zero
	// from normal to zero: should generally slow than gradually drop to zero (surface drag), not too quickly << problem here (decrease drag, decrease thrust factors to match max speed)
	// on a climb: should move forward well on its own momentum then be slowed by gravity (not too much drag) << problem here

	// maneuvering:
	// joystick translation
	// at center should feel precise, at end impactful for extremes, and the curve in the center should make the gradual increase make sense instead of feel like a linear math curve

	// rudder operations:
	// at slow speeds should do little.
	// at cruising speed should be fairly maneuverable and have an enjoyable slide aspect (yawing) that corrects when return to center
	// at turbo speed should do little (travelling fast should sacrifice maneuverability a bit) with almost no slide
	// roll:
	// at cruising speed should be fairly maneuverable
	// at turbo speed should do not as much, but increase drag
	// pitch:
	// at cruising speed should be fairly maneuverable and have an enjoyable slide aspect that corrects when return to center (not as much slide as yawing though)
	// at turbo speed should do little (travelling fast should sacrifice maneuverability a bit) but increase drag
	// jet should quickly obey the direction of the wings, especially at higher speeds.  At lower speeds there can be some slippage

	// banking:
	// preferably, banking should be pronounced at cruising speed, not so much at turbo speed
	// I assume this is related to how the nose should be dropping at lower speeds

	// trick maneuvers:
	// travelling sideways - at lower speeds craft should slide downward unless compensated with the rudder.  at high speeds this shouldn't be so necessary
	// travelling upside down - at lower speeds craft should slide downward unless compensated with the ailerons.  at high speeds this shouldn't be so necessary

	// freefall
	// the jet's freefall speed straight down should theoretically be faster than a falling man

	// take a surface normal against wind approach

	Vector3d velocityAdjustment = Vector3d::ZeroVector();
	velocityAdjustment.y = -p_gravityPerMS2 * p_MS; // accelerate down!

	Vector3d velocityUnit = p_jet.velocity;
	float angleOfAttack = 0.0f;
	float liftCoefficient = 0.0f;
	// ignore if no velocity or velocity is backwards
	if ((velocityUnit * p_jet.orient.f > 0.0f) && velocityUnit.Normalize() == true && p_jet.dead == false)
	{
		Vector3d windAngleVector = p_jet.orient.f.CrossProd(velocityUnit);
		angleOfAttack = MathUtilities::RadiansToDegrees(atan(windAngleVector.Magnitude()));
		if (velocityUnit * p_jet.orient.u > 0.0f)
			angleOfAttack = -angleOfAttack;
		float minimumAngleOfAttack = -5.0f;
		float maximumAngleOfAttack = 20.0f;
		// triangle - past 20 degrees, all lift is gone
		// todo: make this more gradual to dropoff
		if (angleOfAttack >= minimumAngleOfAttack && angleOfAttack <= maximumAngleOfAttack)
		{
			liftCoefficient = angleOfAttack - minimumAngleOfAttack;
		}
		else if (angleOfAttack > maximumAngleOfAttack)
		{
			liftCoefficient = (maximumAngleOfAttack - minimumAngleOfAttack) - (angleOfAttack - maximumAngleOfAttack) * 2.0f;
			if (liftCoefficient < 0.0f)
				liftCoefficient = 0.0f;
		}
	}

	// forward lift, drag, pitch and roll
	float windStrikingFront = (p_jet.velocity * p_jet.orient.f);
	float forwardDrag = 0.001f; // too high and the jet slows too fast when drop to 0.0.  should be a good balance for airbraking comfortably and coming to a stop - thrust values for appropriate speeds should match this
	float forwardDragBrake = 0.0025f;
	if (windStrikingFront > 0.0f)
	{
		// lift the plane a bit (less than blowing upward on the bottom)
		// make 0 degrees lift for 150 mph, -4 degrees lift for 300 mph (300mph will generate 4* lift of 150mph due to v-squared in formula)
		// 0.22 = feet travelled per ms at 155 mph
		// this means a coefficient of 5 should generate a lift such that 0.022*0.022*5*c = gravity (0.0000032174049586) - c = 0.001329506
		float liftAmount = windStrikingFront * windStrikingFront * liftCoefficient * 0.001329506f;
		velocityAdjustment = velocityAdjustment + p_jet.orient.u.ScalarMult(liftAmount);
		// and drag it

		//make sure to preserve sign on this if a squared formula is ever used!
		if (p_jet.airBrake == false)
			velocityAdjustment = velocityAdjustment - p_jet.orient.f.ScalarMult(windStrikingFront * forwardDrag);
		else
			velocityAdjustment = velocityAdjustment - p_jet.orient.f.ScalarMult(windStrikingFront * forwardDragBrake);

		// spin it on the rudder and drag
		if (p_jet.rudder != 0.0f)
		{
			p_jet.orient.Rotate(p_jet.orient.u, p_jet.rudder * windStrikingFront * 1.6f * p_MS);
			velocityAdjustment = velocityAdjustment - p_jet.orient.f.ScalarMult(windStrikingFront * abs(p_jet.rudder) * 0.00010f);
		}
		// handle ailerons (pitch, roll, drag)
		float pitch = p_jet.leftAileron + p_jet.rightAileron; // -2.0 to 2.0
		float roll = p_jet.rightAileron - p_jet.leftAileron; // -2.0 to 2.0
		if (pitch != 0.0f)
		{
			p_jet.orient.Rotate(p_jet.orient.l, pitch * windStrikingFront * 2.0f * p_MS);
			//velocityAdjustment = velocityAdjustment - p_jetOrient.f.ScalarMult(windStrikingFront * abs(pitch) * 0.00010f);
		}
		if (roll != 0.0f)
		{
			p_jet.orient.Rotate(p_jet.orient.f, -roll * windStrikingFront * 5.0f * p_MS);
			//velocityAdjustment = velocityAdjustment - p_jetOrient.f.ScalarMult(windStrikingFront * abs(roll) * 0.00010f);
		}
	}

	// start with the tip-down
	p_jet.vaporTrails = false; // initialize
	float windStrikingUnderside = -(p_jet.velocity * p_jet.orient.u);
	if (windStrikingUnderside > 0.0f)
	{
		// lift the plane (wind push)
		if (liftCoefficient > 0.0f)
		{
			velocityAdjustment = velocityAdjustment + p_jet.orient.u.ScalarMult(windStrikingUnderside * 0.02f); // 0.1111); // 0.002f);
			// tip it towards the wind
			p_jet.orient.Rotate(p_jet.orient.l, -windStrikingUnderside * 1.0f * p_MS);
			if (windStrikingUnderside > 0.0015f) // 0.001 is too lenient.  0.0015 might work - makes things a little more attractive and active
			{
				// generating extra lift with a lift coefficient - make vapor trails
				p_jet.vaporTrails = true;
			}
		}
		else
		{
			velocityAdjustment = velocityAdjustment + p_jet.orient.u.ScalarMult(windStrikingUnderside * 0.001f); // 0.1111); // 0.002f);
			// tip it towards the wind
			p_jet.orient.Rotate(p_jet.orient.l, -windStrikingUnderside * 5.0f * p_MS);
		}
	}

	// and tip up
	float windStrikingUpperSide = p_jet.velocity * p_jet.orient.u;
	if (windStrikingUpperSide > 0.0f)
	{
		// drop the plane (wind push)
		velocityAdjustment = velocityAdjustment - p_jet.orient.u.ScalarMult(windStrikingUpperSide * 0.0016f);
		// tip it towards the wind
		p_jet.orient.Rotate(p_jet.orient.l, windStrikingUpperSide * 0.90f * p_MS);
	}

	// now the banks
	float windStrikingLeftSide = p_jet.velocity * p_jet.orient.l;
	if (windStrikingLeftSide > 0.0f)
	{
		// slide the plane a bit (wind push)
		velocityAdjustment = velocityAdjustment - p_jet.orient.l.ScalarMult(windStrikingLeftSide * 0.003f);
		// tip it left
		p_jet.orient.Rotate(p_jet.orient.u, -windStrikingLeftSide * 0.75f * p_MS);
	}

	float windStrikingRightSide = -(p_jet.velocity * p_jet.orient.l);
	if (windStrikingRightSide > 0.0f)
	{
		// slide the plane a bit (wind push)
		velocityAdjustment = velocityAdjustment + p_jet.orient.l.ScalarMult(windStrikingRightSide * 0.003f);
		// tip it right
		p_jet.orient.Rotate(p_jet.orient.u, windStrikingRightSide * 0.75f * p_MS);
	}

	// apply thrust
	velocityAdjustment = velocityAdjustment + p_jet.orient.f.ScalarMult(p_jet.actualThrust * 0.00001f * p_MS);

	// apply acceleration
	p_jet.velocity = p_jet.velocity + velocityAdjustment;
}


// this is in cpp because it requires access to GameObjectFactory
void JetBehavior::CreateOtherGameObjects(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
{
	static FastRandom fastRandom;

	if (p_jet.joystick.secondaryButton == false)
		p_jet.missileFired = false;

	if (p_jet.joystick.gunButton == true)
	{
		if (p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->slotStates[0].fireDelayMS <= 0 && p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->slotStates[0].currentAmmo >= p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->ammoAmountUsage)
		{
			// todo: these scalarmults correspond to the model and should change with the model. (named vertices would be good)

			// todo: check ammo!

			// use hardpoint state!  and subtract ammo!
			p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->slotStates[0].fireDelayMS += p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->fireDelayMS; // account for small remainder of time on delay
			p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->slotStates[0].currentAmmo -= p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->ammoAmountUsage;

			for (int i = 0; i < p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->fireableWeapons[0].locationQty; i++)
			{
				Vector3d bulletPosition = p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->fireableWeapons[0].locations[i].GetWeaponWorldLocation(p_jet.orient);

				// make a bullet!
				JetGameObjectNode *newNode = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Bullet, *(p_gameStateData.bulletListRef), *(p_gameStateData.gameObjectIdCounterRef), *(p_gameStateData.hardpointConfigurationRegistryRef));
				newNode->data.orient.Set(p_jet.orient);
				newNode->data.orient.p = bulletPosition;
				newNode->data.velocity = p_jet.velocity + p_jet.orient.f.ScalarMult(p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->speedPerMS);
				newNode->data.sourceRef.Set(&p_jet);

				// make muzzle flash effects, woo!
				LinkedListNode<EnergyEffect> *newEnergyNode = p_gameStateData.fastEffectsRef->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Set(&p_jet);
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::OrientSpace;
				newEnergyNode->data.radius = 1.5f / JetGameValues::FeetPerWorldUnit(); // 1.5 foot radius
				newEnergyNode->data.spacePosition = p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->entryRef->fireableWeapons[0].locations[i].GetLocation();
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
				newEnergyNode->data.rendered = false;
				p_gameStateData.fastEffectsRef->AddNode(newEnergyNode);
			}
		}
	}
	else if (p_jet.joystick.secondaryButton == true && p_jet.missileFired == false)
	{
		if (p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Bullet)->currentWeaponRef->fireDelayMS <= 0 && p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->currentWeaponRef->currentAmmo >= p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->entryRef->ammoAmountUsage)
		{
			// todo: these scalarmults correspond to the model and should change with the model. (named vertices would be good)

			p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->currentWeaponRef->fireDelayMS += p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->entryRef->fireDelayMS; // account for small remainder of time on delay

			int currentIndex = p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->currentWeaponRef->slotIndex;

			// make a missile!
			JetGameObjectNode *newNode = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Missile, *(p_gameStateData.mainGameObjectListRef), *(p_gameStateData.gameObjectIdCounterRef), *(p_gameStateData.hardpointConfigurationRegistryRef));
			newNode->data.orient.Set(p_jet.orient);
			newNode->data.orient.p = p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->entryRef->fireableWeapons[currentIndex].GetHardpointLocation(0).GetWeaponWorldLocation(p_jet.orient);
			newNode->data.velocity = p_jet.velocity + p_jet.orient.f.ScalarMult(p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->entryRef->speedPerMS);
			newNode->data.sourceRef.Set(&p_jet);
			newNode->data.canCollideWithSource = false; // prevent immediate collision with parent jet

			// don't assign target that is dead or deleted
			if (p_jet.targetRef.IsValid() && p_jet.targetRef.IsDeleted() == false && ((JetGameObject *)p_jet.targetRef.gameObjectRef)->dead == false)
				newNode->data.targetRef.Set(p_jet.targetRef.gameObjectRef);
			// prevent constant missile creation when button is held
			p_jet.missileFired = true;

			// todo: don't lock if target isn't within acceptable angle range (boolean on jet, affects player too)

			// affect ammo, switch slot that fires
			p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->currentWeaponRef->currentAmmo -= p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->entryRef->ammoAmountUsage;
			if (currentIndex == 0)
				p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->currentWeaponRef = &(p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->slotStates[1]);
			else
				p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->currentWeaponRef = &(p_jet.hardpointState->GetWeaponState(JetGameObjectEnum::Missile)->slotStates[0]);

			// now, depending on the squad, tall others to fire again in 1 and 2 seconds down the line that have the same target
			// or if alone, fire again in 1 second
			// todo: best to fire again in 1 second at a distance, but when close up, at optimal distance (< 200ft) and maneuvering (typically, mostly right behind)
			LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*p_gameStateData.mainGameObjectListRef);
			int timeToFireMissile = 1000; // increments for each the squad after the firer with the same target
			// assumes lesser squad members are always later in the list
			bool otherFactionJetWithSameTargetExists = false;
			while (enumerator.MoveNext())
			{
				if (&(enumerator.Current()->data) == &p_jet) // or ids equal, whatever
					continue;

				// same faction, same target
				if (enumerator.Current()->data.objectType == JetGameObjectEnum::Jet && enumerator.Current()->data.faction == p_jet.faction && enumerator.Current()->data.targetRef.gameObjectRef == p_jet.targetRef.gameObjectRef && p_jet.dead == false && p_jet.deleted == false)
				{
					if (enumerator.Current()->data.missileAITimerMS < timeToFireMissile)
					{
						enumerator.Current()->data.missileAITimerMS = timeToFireMissile;
						timeToFireMissile += 1000; // another second for the next in the squad
					}
					otherFactionJetWithSameTargetExists = true;
				}
			}
			if (otherFactionJetWithSameTargetExists == true)
				p_jet.missileAITimerMS += 15000;
			else
				p_jet.missileAITimerMS += 1000;

			//System::String ^message = newNode->data.orient.ToString();
			if (GameContext::Instance->LoggingEnabled)
			{
				GameContext::Instance->AddLog(String::Format("Adding Missile ID {0:D}, Orient {1}, Velocity {2}", newNode->data.id, newNode->data.orient.ToString(), newNode->data.velocity.ToString()));
			}
		} // enough ammo
	}

	bool useVaporTrails = true;
	if (p_jet.vaporTrails == true && useVaporTrails == true)
	{
		// make new smoke trail structures if necessary
		if (p_jet.smokeTrailRef1 == nullptr)
		{
			LinkedListNode<AlphaTrail> *newSmokeTrail = p_gameStateData.smokeTrailsRef->GetNewNode();
			newSmokeTrail->data.maxLifeMS = 1000;
			newSmokeTrail->data.beginningAlpha = 255;
			newSmokeTrail->data.type = SmokeTrailType::VaporTrail;
			p_gameStateData.smokeTrailsRef->AddNode(newSmokeTrail);
			p_jet.smokeTrailRef1 = &(newSmokeTrail->data);
		}
		if (p_jet.smokeTrailRef2 == nullptr)
		{
			LinkedListNode<AlphaTrail> *newSmokeTrail = p_gameStateData.smokeTrailsRef->GetNewNode();
			newSmokeTrail->data.maxLifeMS = 1000;
			newSmokeTrail->data.beginningAlpha = 255;
			newSmokeTrail->data.type = SmokeTrailType::VaporTrail;
			p_gameStateData.smokeTrailsRef->AddNode(newSmokeTrail);
			p_jet.smokeTrailRef2 = &(newSmokeTrail->data);
		}

		// add a point to each
		p_jet.smokeTrailRef1->Add(p_jet.orient.p + p_jet.orient.f.ScalarMult(-1.0f) + p_jet.orient.l.ScalarMult(0.75f) - p_jet.orient.u.ScalarMult(0.15f));
		p_jet.smokeTrailRef2->Add(p_jet.orient.p + p_jet.orient.f.ScalarMult(-1.0f) - p_jet.orient.l.ScalarMult(0.75f) - p_jet.orient.u.ScalarMult(0.15f));
	}
	else
	{
		p_jet.smokeTrailRef1 = nullptr;
		p_jet.smokeTrailRef2 = nullptr;
	}

	if (p_jet.dead == true || p_jet.health <  JetGameValues::JetStartingHealth())
	{
		if (p_jet.smokeDelayMS <= 0)
		{
			LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_jet.orient.p.x, p_jet.orient.p.y, p_jet.orient.p.z)->data);
			LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
			newParticleNode->data.Initialize();
			newParticleNode->data.SetPositionFormula(p_jet.orient.p); // no movement
			newParticleNode->data.SetAlphaFormula(1.0f, 1.0f / 10000.0f); // 10 seconds
			float radius = 0.0f;
			if (p_jet.dead == true)
			{
				radius = (float(fastRandom.GetRandomInteger(12, 24)) / 3.0f) / JetGameValues::FeetPerWorldUnit(); // 4-8 foot radius to start for visibility in the distance
			}
			else
			{
				int min = int(2.0f * (JetGameValues::JetStartingHealth() - p_jet.health) / JetGameValues::JetStartingHealth() + 1.0f);
				// 1-3 to 3-5 depending on damage
				radius = (float(fastRandom.GetRandomInteger(min * 3, (min + 2) * 3)) / 3.0f) / JetGameValues::FeetPerWorldUnit();
			}
			newParticleNode->data.SetRadiusFormula(radius, 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f);
			newParticleNode->data.textureIndex = 0; // GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");

			unsigned char colorComponent = fastRandom.GetRandomInteger(0, 64); // stagger the color from pitch black to dark gray
			newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop

			newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));

			particleList->AddNode(newParticleNode);

			if (p_jet.dead == true)
			{
				p_jet.smokeDelayMS += fastRandom.GetRandomInteger(25, 80); // release it staggered
			}
			else
			{
				// leave a trail of smoke to represent severity of damage
				int min = int(1000.0f * p_jet.health / JetGameValues::JetStartingHealth() + 100.0f);
				p_jet.smokeDelayMS += fastRandom.GetRandomInteger(min, min*4);
			}
		}
	}
}
#pragma endregion Jet

#pragma region Missile
/////////////////////////
// Missiles (a lot simpler than jets)

// note: missiles use leftaileron only for pitching.  rightaileron is ignored.  rudder used for turning, setThrust used for acceleration and rendering.  no brake, accelerate, decelerate, or afternurner
void MissileBehavior::Process(JetGameObject &p_missile, float p_elapsedTimeMSf)
{

}
void MissileBehavior::Behave(JetGameObject &p_missile, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS)
{
	// if far enough away from source, allow it to collide again
	if (p_missile.canCollideWithSource == false)
	{
		// 30 feet away ought to do it
		if (p_missile.sourceRef.IsValid() == false || p_missile.sourceRef.IsDeleted() == true || (p_missile.orient.p - ((JetGameObject *)p_missile.sourceRef.Ptr())->orient.p).MagnitudeSquared() > (90.0f / JetGameValues::FeetPerWorldUnit()))
			p_missile.canCollideWithSource = true;
	}

	// decide how it will alter its trajectory - don't apply physics yet
	// missiles have 3 important values for maneuvering: setThrust, leftaileron, rudder.
	if (p_missile.targetRef.IsValid() && p_missile.targetRef.IsDeleted() == false) // can still track a dead target, just not a deleted or null one
	{
		p_missile.setThrust = JetGameValues::LightAirMissileThrust();

		Vector3d offsetToTarget = ((JetGameObject *)p_missile.targetRef.Ptr())->orient.p - p_missile.orient.p;
		float horizontalOffset = offsetToTarget * p_missile.orient.l;
		float verticalOffset = offsetToTarget * p_missile.orient.u;
		float forwardOffset = offsetToTarget * p_missile.orient.f;

		if (forwardOffset <= 0.00001f)
		{
			bool cancelIfPass = true; // true in final version, or possibly leave false and set true only if on second pass for missile upgrade, etc.

			if (cancelIfPass)
			{
				// passed the target - will still check for collisions though later...
				p_missile.targetRef.Clear();
			}
			else
			{
				// todo: set up logic for second pass - each component has to turn away from the target, then use normal logic again once the plane of offset is crossed (target switches sides of missile)
				// watch out for complex components of switching sides (some horizontal, a lot of vertical, etc.)
				// will probably need a flag to tell the missile that it wants to turn away until a plane is crossed for a component, then switch back for normal chasing
				if (horizontalOffset < 0.0f)
					p_missile.rudder = 1.0f;
				else
					p_missile.rudder = -1.0f;

				if (verticalOffset < 0.0f)
					p_missile.leftAileron = -1.0f;
				else
					p_missile.leftAileron = 1.0f;
			}
		}
		else
		{
			float resultT = 0.0f;
			Vector3d resultDirection = Vector3d(0, 0, 0);
			//if (MathUtilities::ProjectileStrikeObjectNoGravity(p_missile.orient.p, Vector3d::ZeroVector(), p_missile.velocity.Magnitude(), ((JetGameObject *)p_missile.targetRef.Ptr())->orient.p, ((JetGameObject *)p_missile.targetRef.Ptr())->velocity, resultT, resultDirection) == true)
			if (true)
			{
				//float horizontalOffset = resultDirection * p_missile.orient.l;
				//float verticalOffset = resultDirection * p_missile.orient.u;
				//float forwardOffset = resultDirection * p_missile.orient.f;

				// track target!
				horizontalOffset /= forwardOffset;
				verticalOffset /= forwardOffset;

				// rudder
				if (horizontalOffset < -0.30f)
				{
					p_missile.rudder = 1.0f;
				}
				else if (horizontalOffset > 0.30f)
				{
					p_missile.rudder = -1.0f;
				}
				else
				{
					// specific to the angle in question
					// min max at what 0.05 uses
					// hard at the endpoints, light at the origin
					float value = horizontalOffset / 0.30f;
					if (value < 0.0f)
						value = -float(cbrt(-value)); // cubic root
					else
						value = float(cbrt(value)); // cubic root
					p_missile.rudder = -value;
				}

				// left aileron (right aileron is ignored)
				if (verticalOffset < -0.30f)
				{
					p_missile.leftAileron = -1.0f;
				}
				else if (verticalOffset > 0.30f)
				{
					p_missile.leftAileron = 1.0f;
				}
				else
				{
					// specific to the angle in question
					// min max at what 0.05 uses
					// hard at the endpoints, light at the origin
					float value = verticalOffset / 0.30f;
					if (value < 0.0f)
						value = -float(cbrt(-value)); // cubic root
					else
						value = float(cbrt(value)); // cubic root
					p_missile.leftAileron = value;
				}
			}
		}
	}
	
	if (p_missile.targetRef.IsValid() == false || p_missile.targetRef.IsDeleted()) // missile no longer as a valid target - could have been an else but the above block could remove the lock if the missile passes the target
	{
		p_missile.leftAileron = 0.0f;
		p_missile.rightAileron = 0.0f; // ignored anyway
		p_missile.rudder = 0.0f;
		p_missile.targetRef.Clear();

		// timer for thrust shut off
		if (p_missile.thrustShutOffMS == 0 && p_missile.setThrust != 0.0f)
		{
			p_missile.thrustShutOffMS = 1000;
		}
		else
		{
			// perform thrust shutoff
			if (p_missile.thrustShutOffMS > 0)
			{
				if (p_missile.thrustShutOffMS <= int(p_elapsedTimeMSf))
				{
					p_missile.setThrust = 0.0f;
					p_missile.thrustShutOffMS = 0;
				}
				else
					p_missile.thrustShutOffMS -= int(p_elapsedTimeMSf);
			}
		}
	}
}
void MissileBehavior::ApplyPhysics(JetGameObject &p_missile, float p_gravityPerMS2, float p_elapsedTimeMS)
{
	Vector3d velocityAdjustment = Vector3d::ZeroVector();
	velocityAdjustment.y -= p_gravityPerMS2 * p_elapsedTimeMS;
	// apply thrust, alter its angle, drag from turning and forward movement, and its velocity

	if (GameContext::Instance->LoggingEnabled)
	{
		GameContext::Instance->AddLog(System::String::Format("[{0:D}] Missile velocity and orient: {1}, {2}", p_missile.id, p_missile.velocity.ToString(), p_missile.orient.ToString()));
	}

	float forwardWind = p_missile.orient.f * p_missile.velocity; // used for turning and slowing from drag
	float sideWind = p_missile.orient.l * p_missile.velocity; // used for sliding
	float upWind = p_missile.orient.u * p_missile.velocity; // used for sliding

	// forward drag (max speed around 600mph) - but heavy acceleration, so need a drag coefficient that gets quickly smaller as speed decreases but is high enough at 600mph to keep it from
	//   going any faster.  This allows the missile to quickly accelerate on launch and not appear to stop as dead weight once its thrust is shut off because it passed its target

	// winds hitting sides - extreme knockback at high speeds.  not so much at lower speeds
	// force missile to turn in that direction too - causes slower turning at highest speed
	float slideFactor = fabs(forwardWind * forwardWind);
	if (slideFactor > 0.0073f)
		slideFactor = 0.0073f;
	slideFactor = slideFactor / 0.018301f;
	// todo: should this be per MS?  formula affects flight characteristic of missiles - be careful - you want similar behavior on 1ms/tick as 20ms/tick
	velocityAdjustment = velocityAdjustment - p_missile.orient.l.ScalarMult(sideWind * slideFactor);
	velocityAdjustment = velocityAdjustment - p_missile.orient.u.ScalarMult(upWind* slideFactor);
	// also, force turn towards side wind
	if (GameContext::Instance->LoggingEnabled)
	{
		GameContext::Instance->AddLog(System::String::Format("[{0:D}] Rotating {1:0.000} degrees on missile orient u: ", p_missile.id, -45.0f / 1.0f * sideWind) + p_missile.orient.u.ToString());
	}
	p_missile.orient.Rotate(p_missile.orient.u, -45.0f / 1.0f * sideWind);
	if (GameContext::Instance->LoggingEnabled)
	{
		GameContext::Instance->AddLog(System::String::Format("[{0:D}] Rotating {1:0.000} degrees on missile orient l: ", p_missile.id, 45.0f / 1.0f * upWind) + p_missile.orient.l.ToString());
	}
	p_missile.orient.Rotate(p_missile.orient.l, 45.0f / 1.0f * upWind);

	// drag, preserve sign
	velocityAdjustment = velocityAdjustment - p_missile.orient.f.ScalarMult(forwardWind * fabs(forwardWind) / 193.6f * p_elapsedTimeMS); // keeps max speed at 0.088 with thrust of 4.0 but allows easy acceleration at slower speeds
	// alter direction, don't worry about drag for now
	//Trace::WriteLine("Rudder: " + Convert::ToString(p_missile.rudder) + "; Aileron: " + Convert::ToString(p_missile.leftAileron));
	if (GameContext::Instance->LoggingEnabled)
	{
		GameContext::Instance->AddLog(System::String::Format("[{0:D}] Missile rudder and aileron: {1:0.000}, {2:0.000}", p_missile.id, p_missile.rudder, p_missile.leftAileron));
	}
	p_missile.orient.Rotate(p_missile.orient.u, p_missile.rudder * 120.0f / 1000.0f * forwardWind / 0.06f * p_elapsedTimeMS);
	p_missile.orient.Rotate(p_missile.orient.l, p_missile.leftAileron * 120.0f / 1000.0f * forwardWind / 0.06f * p_elapsedTimeMS);

	// apply thrust
	velocityAdjustment = velocityAdjustment + p_missile.orient.f.ScalarMult(p_missile.setThrust * 0.00001f * p_elapsedTimeMS);

	// apply acceleration
	p_missile.velocity = p_missile.velocity + velocityAdjustment;

	if (GameContext::Instance->LoggingEnabled)
	{
		GameContext::Instance->AddLog(System::String::Format("[{0:D}] Missile velocity and orient: {1}, {2}", p_missile.id, p_missile.velocity.ToString(), p_missile.orient.ToString()));
	}
}
void MissileBehavior::CreateOtherGameObjects(JetGameObject &p_missile, JetGameStateData &p_gameStateData)
{
	static FastRandom fastRandom;

	// missiles have smoke trails
	bool useSmokeTrail = false;
	if (useSmokeTrail == true)
	{
		if (p_missile.setThrust != 0.0f)
		{
			if (p_missile.smokeTrailRef1 == nullptr)
			{
				// make a new list
				LinkedListNode<AlphaTrail> *newSmokeTrail = p_gameStateData.smokeTrailsRef->GetNewNode();
				newSmokeTrail->data.type = SmokeTrailType::MissileTrail;
				newSmokeTrail->data.beginningAlpha = 255;
				newSmokeTrail->data.maxLifeMS = 10000;
				p_gameStateData.smokeTrailsRef->AddNode(newSmokeTrail);

				p_missile.smokeTrailRef1 = &(newSmokeTrail->data);
			}
			p_missile.smokeTrailRef1->Add(p_missile.orient.p);
		}
		else
			// turn off smoke, let main engine decide when to remove the list
			p_missile.smokeTrailRef1 = nullptr;
	}

	bool useSmokeParticle = true;
	if (useSmokeParticle == true)
	{
		if (p_missile.setThrust != 0.0f)
		{
			LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_missile.orient.p.x, p_missile.orient.p.y, p_missile.orient.p.z)->data);
			LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
			newParticleNode->data.Initialize();
			newParticleNode->data.SetPositionFormula(p_missile.orient.p - p_missile.orient.f.ScalarMult(1.0f)); // 2 foot length, 6 foot flame, 2 foot radius smoke - no movement
			newParticleNode->data.SetAlphaFormula(1.0f, 1.0f / 10000.0f); // 10 seconds
			newParticleNode->data.SetRadiusFormula(2.0f / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f);

			newParticleNode->data.textureIndex = 0; // GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");

			newParticleNode->data.color = GameColor(255, 255, 255); // alpha will be calculated in render loop

			newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));

			particleList->AddNode(newParticleNode);
		}
	}
}
#pragma endregion Missile

#pragma region Bullet
/////////////////////////
// Bullets! (very simple)
void BulletBehavior::Process(JetGameObject &p_missile, float p_elapsedTimeMSf)
{

}
void BulletBehavior::Behave(JetGameObject &p_bullet, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS)
{
	// nothing to do here... a bullet's a bullet
}
void BulletBehavior::ApplyPhysics(JetGameObject &p_bullet, float p_gravityPerMS2, float p_elapsedTimeMS)
{
	// just apply gravity, worry about drag later
	p_bullet.velocity.y -= (p_gravityPerMS2 * p_elapsedTimeMS);
}
void BulletBehavior::CreateOtherGameObjects(JetGameObject &p_object, JetGameStateData &p_gameStateData)
{
	// bullets don't create other objects
}
#pragma endregion Bullet
