#pragma once

#include "TestGame.h"
#include "..\Headers\GameApplicationContext.h"
#include "..\Headers\GameContext.h"
#include "JetGameHelper.h"
#include "TestNetwork.h"
#include "TestAsteroids.h"
#include "TestFPS.h"

namespace GameEngDev {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Diagnostics;
	using namespace GameEngDev::JetGameHelper;

	/// <summary>
	/// Summary for TestForm
	/// </summary>
	public ref class TestForm : public System::Windows::Forms::Form
	{
	public:
		TestForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			currentGame = nullptr;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~TestForm()
		{
			if (components)
			{
				delete components;
			}

			if (currentGame != nullptr)
			{
				delete currentGame;
				currentGame = nullptr;
			}
		}

	private: GameBase ^currentGame;
			 int viewportPictureBoxIndex = -1;

	private: System::Windows::Forms::PictureBox^  viewportPictureBox;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Label^  pictureBoxSizeLabel;
	private: System::Windows::Forms::Label^  mouseMiddleButtonLabel;
	private: System::Windows::Forms::Label^  mouseRightButtonLabel;
	private: System::Windows::Forms::Label^  mouseLeftButtonLabel;
	private: System::Windows::Forms::Label^  mouseCoordsLabel;
	private: System::Windows::Forms::Label^  formActivatedLabel;
	private: System::Windows::Forms::Label^  keyUpLabel;
	private: System::Windows::Forms::Label^  keyDownLabel;
	private: System::Windows::Forms::Button^  testDialogPopupButton;
	private: System::Windows::Forms::Label^  mouseWheelDeltaLabel;
	private: System::Windows::Forms::Timer^  testTimer;
	private: System::Windows::Forms::ListBox^  testListBox;
	private: System::ComponentModel::IContainer^  components;

			 bool firstTick = true;
			 // test names
			 String^ SimpleTriangle = "Simple Triangle";
			 String^ SimpleTextureString = "Simple Texture";
			 String^ RotatingJet = "Rotating Jet and Textured Cube";
			 String^ TerrainTest1String = "Terrain Test - LOD demo";
			 String^ TerrainTest2String = "Terrain Test - Heightmap";
			 String^ SkyboxString = "Skybox";
			 String^ StarfieldString = "Star field";
			 String^ AlphaTrailString = "Alpha Trail";
			 String^ JetFlight1String = "Jet Flight 1";
			 String^ FontTest1String = "Font Test 1";
			 String^ JetGame1String = "Jet Game 1";
			 String^ AlphaClipPlaneString = "Alpha Clip Plane";
			 String^ TrapezoidTextureString = "Trapezoid Texturing";
			 String^ ProjectedTextureString = "Projected Texture";
			 String^ TestVBOString = "Native Object Test";
			 String^ TestShaderString = "Shader Test";
			 String^ GLShaderString = "OpenGL 4.3 Shader Test";
			 String^ LightingString = "Lighting";
			 String^ AsteroidsString = "Asteroids";
			 String^ MazeRunnerString = "Maze Runner";
			 String^ PlatformerCellString = "2D Platformer (Cells)";
			 String^ BouncingBallString = "Bouncing Balls";
			 String^ OrientInterpolationString = "Orientation Interpolation";
			 String^ JointedModelTestString = "Jointed Model Test";
			 String^ AnimatedModelTestString = "Animated Model Test";
			 String^ AnaglyphSimpleString = "Anaglyph Simple";
			 String^ AnaglyphTrueString = "Anaglyph True";
			 String^ AnaglyphExperimentString = "Anaglyph Experiment";
			 String^ DungeonHallString = "Dungeon Hall";
			 String ^RenderBufferTextureString = "Render Buffer Texture (Spotlight Shadow)";
			 String ^CubemapBufferTextureString = "Cube Map Buffer Texture (Point Shadows)";
			 String ^OrthographicProjectionString = "Orthographic Projection";
			 String ^DirectionalLightShadowString = "Directional Lighting Test";
			 String ^FrustumString = "Frustum Intersections";
			 String ^Portal1String = "Portal Alpha Test";
			 String ^RandomDungeonString = "Random Dungeon";
			 String ^BitonicSortString = "Bitonic Sort";
			 String ^ParticlesString = "Particles";
			 String ^MirrorTestString = "Mirror Test";
			 String ^PostProcessTestString = "Post Process Shader";
			 String ^MotionBlurTestString = "Motion Blur";
			 String ^TestGoogleCardboardStubString = "Google Cardboard Depth Calibration";
			 String ^TestGoogleCardboardSceneStubString = "Google Cardboard Sample Scene";
			 String ^TestTetherSwingString = "Tether Swing";
			 String ^TestNetworkString = "Network test";
			 String ^TestUIString = "UI test";
			 String ^TestFPSString = "FPS test";
	private: System::Windows::Forms::Label^  joystickButton4Label;
	private: System::Windows::Forms::Label^  joystickButton3Label;
	private: System::Windows::Forms::Label^  joystickButton2Label;
	private: System::Windows::Forms::Label^  joystickButton1Label;
	private: System::Windows::Forms::Label^  joystickTwistLabel;
	private: System::Windows::Forms::Label^  joystickYLabel;
	private: System::Windows::Forms::Label^  joystickXLabel;





	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->viewportPictureBox = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->testDialogPopupButton = (gcnew System::Windows::Forms::Button());
			this->joystickButton4Label = (gcnew System::Windows::Forms::Label());
			this->joystickButton3Label = (gcnew System::Windows::Forms::Label());
			this->joystickButton2Label = (gcnew System::Windows::Forms::Label());
			this->joystickButton1Label = (gcnew System::Windows::Forms::Label());
			this->joystickTwistLabel = (gcnew System::Windows::Forms::Label());
			this->joystickYLabel = (gcnew System::Windows::Forms::Label());
			this->joystickXLabel = (gcnew System::Windows::Forms::Label());
			this->testListBox = (gcnew System::Windows::Forms::ListBox());
			this->mouseWheelDeltaLabel = (gcnew System::Windows::Forms::Label());
			this->keyUpLabel = (gcnew System::Windows::Forms::Label());
			this->keyDownLabel = (gcnew System::Windows::Forms::Label());
			this->formActivatedLabel = (gcnew System::Windows::Forms::Label());
			this->pictureBoxSizeLabel = (gcnew System::Windows::Forms::Label());
			this->mouseMiddleButtonLabel = (gcnew System::Windows::Forms::Label());
			this->mouseRightButtonLabel = (gcnew System::Windows::Forms::Label());
			this->mouseLeftButtonLabel = (gcnew System::Windows::Forms::Label());
			this->mouseCoordsLabel = (gcnew System::Windows::Forms::Label());
			this->testTimer = (gcnew System::Windows::Forms::Timer(this->components));
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->viewportPictureBox))->BeginInit();
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// viewportPictureBox
			// 
			this->viewportPictureBox->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->viewportPictureBox->BackColor = System::Drawing::Color::White;
			this->viewportPictureBox->Location = System::Drawing::Point(12, 12);
			this->viewportPictureBox->Name = L"viewportPictureBox";
			this->viewportPictureBox->Size = System::Drawing::Size(760, 518);
			this->viewportPictureBox->TabIndex = 0;
			this->viewportPictureBox->TabStop = false;
			this->viewportPictureBox->SizeChanged += gcnew System::EventHandler(this, &TestForm::viewportPictureBox_SizeChanged);
			this->viewportPictureBox->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &TestForm::viewportPictureBox_MouseDown);
			this->viewportPictureBox->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &TestForm::viewportPictureBox_MouseMove);
			this->viewportPictureBox->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &TestForm::viewportPictureBox_MouseUp);
			this->viewportPictureBox->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &TestForm::viewportPictureBox_PreviewKeyDown);
			// 
			// panel1
			// 
			this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->panel1->Controls->Add(this->testDialogPopupButton);
			this->panel1->Controls->Add(this->joystickButton4Label);
			this->panel1->Controls->Add(this->joystickButton3Label);
			this->panel1->Controls->Add(this->joystickButton2Label);
			this->panel1->Controls->Add(this->joystickButton1Label);
			this->panel1->Controls->Add(this->joystickTwistLabel);
			this->panel1->Controls->Add(this->joystickYLabel);
			this->panel1->Controls->Add(this->joystickXLabel);
			this->panel1->Controls->Add(this->testListBox);
			this->panel1->Controls->Add(this->mouseWheelDeltaLabel);
			this->panel1->Controls->Add(this->keyUpLabel);
			this->panel1->Controls->Add(this->keyDownLabel);
			this->panel1->Controls->Add(this->formActivatedLabel);
			this->panel1->Controls->Add(this->pictureBoxSizeLabel);
			this->panel1->Controls->Add(this->mouseMiddleButtonLabel);
			this->panel1->Controls->Add(this->mouseRightButtonLabel);
			this->panel1->Controls->Add(this->mouseLeftButtonLabel);
			this->panel1->Controls->Add(this->mouseCoordsLabel);
			this->panel1->Location = System::Drawing::Point(778, 12);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(200, 527);
			this->panel1->TabIndex = 6;
			// 
			// testDialogPopupButton
			// 
			this->testDialogPopupButton->Location = System::Drawing::Point(87, 107);
			this->testDialogPopupButton->Name = L"testDialogPopupButton";
			this->testDialogPopupButton->Size = System::Drawing::Size(113, 23);
			this->testDialogPopupButton->TabIndex = 14;
			this->testDialogPopupButton->Text = L"Test Dialog Popup";
			this->testDialogPopupButton->UseVisualStyleBackColor = true;
			this->testDialogPopupButton->Visible = false;
			this->testDialogPopupButton->Click += gcnew System::EventHandler(this, &TestForm::testDialogPopupButton_Click);
			// 
			// joystickButton4Label
			// 
			this->joystickButton4Label->Location = System::Drawing::Point(6, 234);
			this->joystickButton4Label->Name = L"joystickButton4Label";
			this->joystickButton4Label->Size = System::Drawing::Size(153, 16);
			this->joystickButton4Label->TabIndex = 24;
			this->joystickButton4Label->Text = L"Joystick Button 4: Up";
			// 
			// joystickButton3Label
			// 
			this->joystickButton3Label->Location = System::Drawing::Point(6, 218);
			this->joystickButton3Label->Name = L"joystickButton3Label";
			this->joystickButton3Label->Size = System::Drawing::Size(153, 16);
			this->joystickButton3Label->TabIndex = 23;
			this->joystickButton3Label->Text = L"Joystick Button 3: Up";
			// 
			// joystickButton2Label
			// 
			this->joystickButton2Label->Location = System::Drawing::Point(6, 202);
			this->joystickButton2Label->Name = L"joystickButton2Label";
			this->joystickButton2Label->Size = System::Drawing::Size(153, 16);
			this->joystickButton2Label->TabIndex = 22;
			this->joystickButton2Label->Text = L"Joystick Button 2: Up";
			// 
			// joystickButton1Label
			// 
			this->joystickButton1Label->Location = System::Drawing::Point(6, 186);
			this->joystickButton1Label->Name = L"joystickButton1Label";
			this->joystickButton1Label->Size = System::Drawing::Size(153, 16);
			this->joystickButton1Label->TabIndex = 21;
			this->joystickButton1Label->Text = L"Joystick Button 1: Up";
			// 
			// joystickTwistLabel
			// 
			this->joystickTwistLabel->Location = System::Drawing::Point(6, 170);
			this->joystickTwistLabel->Name = L"joystickTwistLabel";
			this->joystickTwistLabel->Size = System::Drawing::Size(153, 16);
			this->joystickTwistLabel->TabIndex = 20;
			this->joystickTwistLabel->Text = L"Joystick Twist: 0";
			// 
			// joystickYLabel
			// 
			this->joystickYLabel->Location = System::Drawing::Point(6, 154);
			this->joystickYLabel->Name = L"joystickYLabel";
			this->joystickYLabel->Size = System::Drawing::Size(153, 16);
			this->joystickYLabel->TabIndex = 19;
			this->joystickYLabel->Text = L"Joystick Y: 0";
			// 
			// joystickXLabel
			// 
			this->joystickXLabel->Location = System::Drawing::Point(6, 138);
			this->joystickXLabel->Name = L"joystickXLabel";
			this->joystickXLabel->Size = System::Drawing::Size(153, 16);
			this->joystickXLabel->TabIndex = 18;
			this->joystickXLabel->Text = L"Joystick X: 0";
			// 
			// testListBox
			// 
			this->testListBox->FormattingEnabled = true;
			this->testListBox->Location = System::Drawing::Point(6, 295);
			this->testListBox->Name = L"testListBox";
			this->testListBox->Size = System::Drawing::Size(171, 225);
			this->testListBox->TabIndex = 16;
			this->testListBox->SelectedIndexChanged += gcnew System::EventHandler(this, &TestForm::testListBox_SelectedIndexChanged);
			// 
			// mouseWheelDeltaLabel
			// 
			this->mouseWheelDeltaLabel->Location = System::Drawing::Point(3, 69);
			this->mouseWheelDeltaLabel->Name = L"mouseWheelDeltaLabel";
			this->mouseWheelDeltaLabel->Size = System::Drawing::Size(153, 16);
			this->mouseWheelDeltaLabel->TabIndex = 15;
			this->mouseWheelDeltaLabel->Text = L"Mouse Wheel Delta: 0";
			// 
			// keyUpLabel
			// 
			this->keyUpLabel->Location = System::Drawing::Point(3, 112);
			this->keyUpLabel->Name = L"keyUpLabel";
			this->keyUpLabel->Size = System::Drawing::Size(153, 16);
			this->keyUpLabel->TabIndex = 13;
			this->keyUpLabel->Text = L"Key Up:";
			// 
			// keyDownLabel
			// 
			this->keyDownLabel->Location = System::Drawing::Point(3, 96);
			this->keyDownLabel->Name = L"keyDownLabel";
			this->keyDownLabel->Size = System::Drawing::Size(153, 16);
			this->keyDownLabel->TabIndex = 12;
			this->keyDownLabel->Text = L"Key Down:";
			// 
			// formActivatedLabel
			// 
			this->formActivatedLabel->Location = System::Drawing::Point(6, 276);
			this->formActivatedLabel->Name = L"formActivatedLabel";
			this->formActivatedLabel->Size = System::Drawing::Size(153, 16);
			this->formActivatedLabel->TabIndex = 11;
			this->formActivatedLabel->Text = L"Form Activated: Yes";
			// 
			// pictureBoxSizeLabel
			// 
			this->pictureBoxSizeLabel->Location = System::Drawing::Point(6, 260);
			this->pictureBoxSizeLabel->Name = L"pictureBoxSizeLabel";
			this->pictureBoxSizeLabel->Size = System::Drawing::Size(153, 16);
			this->pictureBoxSizeLabel->TabIndex = 10;
			this->pictureBoxSizeLabel->Text = L"Picture Box Size: 760, 518";
			// 
			// mouseMiddleButtonLabel
			// 
			this->mouseMiddleButtonLabel->Location = System::Drawing::Point(3, 53);
			this->mouseMiddleButtonLabel->Name = L"mouseMiddleButtonLabel";
			this->mouseMiddleButtonLabel->Size = System::Drawing::Size(153, 16);
			this->mouseMiddleButtonLabel->TabIndex = 9;
			this->mouseMiddleButtonLabel->Text = L"Mouse Middle Button: Up";
			// 
			// mouseRightButtonLabel
			// 
			this->mouseRightButtonLabel->Location = System::Drawing::Point(3, 37);
			this->mouseRightButtonLabel->Name = L"mouseRightButtonLabel";
			this->mouseRightButtonLabel->Size = System::Drawing::Size(153, 16);
			this->mouseRightButtonLabel->TabIndex = 8;
			this->mouseRightButtonLabel->Text = L"Mouse Right Button: Up";
			// 
			// mouseLeftButtonLabel
			// 
			this->mouseLeftButtonLabel->Location = System::Drawing::Point(3, 21);
			this->mouseLeftButtonLabel->Name = L"mouseLeftButtonLabel";
			this->mouseLeftButtonLabel->Size = System::Drawing::Size(153, 16);
			this->mouseLeftButtonLabel->TabIndex = 7;
			this->mouseLeftButtonLabel->Text = L"Mouse Left Button: Up";
			// 
			// mouseCoordsLabel
			// 
			this->mouseCoordsLabel->Location = System::Drawing::Point(3, 5);
			this->mouseCoordsLabel->Name = L"mouseCoordsLabel";
			this->mouseCoordsLabel->Size = System::Drawing::Size(153, 16);
			this->mouseCoordsLabel->TabIndex = 6;
			this->mouseCoordsLabel->Text = L"Mouse X,Y:";
			// 
			// testTimer
			// 
			this->testTimer->Enabled = true;
			this->testTimer->Interval = 1;
			this->testTimer->Tick += gcnew System::EventHandler(this, &TestForm::testTimer_Tick);
			// 
			// TestForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1047, 542);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->viewportPictureBox);
			this->KeyPreview = true;
			this->MinimumSize = System::Drawing::Size(1063, 580);
			this->Name = L"TestForm";
			this->Text = L"TestForm";
			this->Activated += gcnew System::EventHandler(this, &TestForm::TestForm_Activated);
			this->Deactivate += gcnew System::EventHandler(this, &TestForm::TestForm_Deactivate);
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &TestForm::TestForm_FormClosing);
			this->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &TestForm::TestForm_KeyDown);
			this->KeyUp += gcnew System::Windows::Forms::KeyEventHandler(this, &TestForm::TestForm_KeyUp);
			this->MouseWheel += gcnew System::Windows::Forms::MouseEventHandler(this, &TestForm::TestForm_MouseWheel);
			this->Move += gcnew System::EventHandler(this, &TestForm::TestForm_Move);
			this->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &TestForm::TestForm_PreviewKeyDown);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->viewportPictureBox))->EndInit();
			this->panel1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion

	protected:
		// to capture TAB key
		bool ProcessCmdKey(Message %msg, Keys keyData) override
		{
			// any key not handled by the rest of the events should be handled here
			// this does NOT work on Keys::PrintScreen - this routine is not called for that key
			// Actually not sure if we need the 65545 - Shift Tab wasn't responding on a run and I debugged to get this value, but now Shift Tab is working
			if (keyData == Keys::Tab || int(keyData) == 65545) // tab or shift tab
			{
				Object ^sender = Control::FromHandle(msg.HWnd);
				KeyEventArgs ^e = gcnew KeyEventArgs(keyData);
				TestForm_KeyDown(sender, e);
				return true;
			}

			// let the rest of the form do its work with the key
			return Form::ProcessCmdKey(msg, keyData);
		}

	private: System::Void viewportPictureBox_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		mouseCoordsLabel->Text = "Mouse X,Y: " + e->X.ToString() + ", " + e->Y.ToString();
		// note: with borderstyle 3d, x,y ranged from 0,0 to width-5,height-5 (padding of 3)

		// pipe it to the game
		if (currentGame != nullptr)
			currentGame->MouseMove(e->X, e->Y);
	}
	private: System::Void viewportPictureBox_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		if (e->Button == System::Windows::Forms::MouseButtons::Left)
		{
			mouseLeftButtonLabel->Text = "Mouse Left Button: Down";

			// pipe it to the game
			if (currentGame != nullptr)
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Left, true);
		}
		else if (e->Button == System::Windows::Forms::MouseButtons::Right)
		{
			mouseRightButtonLabel->Text = "Mouse Right Button: Down";

			// pipe it to the game
			if (currentGame != nullptr)
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Right, true);
		}
		if (e->Button == System::Windows::Forms::MouseButtons::Middle)
		{
			mouseMiddleButtonLabel->Text = "Mouse Middle Button: Down";

			// pipe it to the game
			if (currentGame != nullptr)
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Middle, true);
		}
	}
private: System::Void viewportPictureBox_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
	if (e->Button == System::Windows::Forms::MouseButtons::Left)
	{
		mouseLeftButtonLabel->Text = "Mouse Left Button: Up";

		// pipe it to the game
		if (currentGame != nullptr)
			currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Left, false);
	}
	else if (e->Button == System::Windows::Forms::MouseButtons::Right)
	{
		mouseRightButtonLabel->Text = "Mouse Right Button: Up";

		// pipe it to the game
		if (currentGame != nullptr)
			currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Right, false);
	}
	if (e->Button == System::Windows::Forms::MouseButtons::Middle)
	{
		mouseMiddleButtonLabel->Text = "Mouse Middle Button: Up";

		// pipe it to the game
		if (currentGame != nullptr)
			currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Middle, false);
	}
}
private: System::Void TestForm_MouseWheel(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
	mouseWheelDeltaLabel->Text = "Mouse Wheel Delta: " + e->Delta.ToString();

	// pipe it to the game
	if (currentGame != nullptr)
		currentGame->MouseWheel(e->Delta);
}
private: System::Void viewportPictureBox_SizeChanged(System::Object^  sender, System::EventArgs^  e) {
	pictureBoxSizeLabel->Text = "Picture Box Size: " + viewportPictureBox->Size.Width.ToString() + ", " + viewportPictureBox->Size.Height.ToString();

	// don't attempt if not initialize yet
	if (viewportPictureBoxIndex != -1)
	{
		if (GameApplicationContext::ViewportRegistry.GetViewport(viewportPictureBoxIndex) != nullptr)
			GameApplicationContext::ViewportRegistry.GetViewport(viewportPictureBoxIndex)->SetViewportSizeAndScreenLocation(viewportPictureBox->Size.Width, viewportPictureBox->Size.Height, viewportPictureBox->PointToScreen(viewportPictureBox->Location));
		if (currentGame != nullptr)
			currentGame->ViewportSizeChanged(GameApplicationContext::ViewportRegistry.GetViewport(viewportPictureBoxIndex));
	}
}
private: System::Void TestForm_Move(System::Object^  sender, System::EventArgs^  e) {
	// don't attempt if not initialize yet
	if (viewportPictureBoxIndex != -1)
	{
		// really just reporting screen location here
		if (GameApplicationContext::ViewportRegistry.GetViewport(viewportPictureBoxIndex) != nullptr)
			GameApplicationContext::ViewportRegistry.GetViewport(viewportPictureBoxIndex)->SetViewportSizeAndScreenLocation(viewportPictureBox->Size.Width, viewportPictureBox->Size.Height, viewportPictureBox->PointToScreen(viewportPictureBox->Location));
	}
}
private: System::Void TestForm_Activated(System::Object^  sender, System::EventArgs^  e) {
	formActivatedLabel->Text = "Form Activated: Yes";
	Trace::WriteLine("Form activated");
	// called when app starts, but should not be used for initialization.  Although, it could be...

	// pipe it to the game
	if (currentGame != nullptr)
	{
		currentGame->appActivated = true;
		currentGame->ApplicationActivated();
	}
}
private: System::Void TestForm_Deactivate(System::Object^  sender, System::EventArgs^  e) {
	formActivatedLabel->Text = "Form Activated: No";
	Trace::WriteLine("Form deactivated");
	// note: form naturally deactivates when minimized

	// pipe it to the game
	if (currentGame != nullptr)
	{
		currentGame->appActivated = false;
		currentGame->ApplicationDeactivated();
	}
}
private: System::Void TestForm_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
	keyDownLabel->Text = "Key Down: " + e->KeyCode.ToString() + " (" + e->KeyValue.ToString() + ")";
	// note: PrtScn does not send a down event - it seems to be grabbed by the OS - for now, respond to the up event if needed.
	// Also, Function mode key registers as None(255)
	// F12 causes an unknown thread to exit
	e->Handled = true; // prevents Alt from stealing the next down press and cancelling Ctrl
	e->SuppressKeyPress = true; // prevents key presses from activating listboxes

	// pipe it to the game
	// also preps a KeyPress for text controls
	if (currentGame != nullptr)
		currentGame->KeyDown(e->KeyValue, 
			int(e->Modifiers & System::Windows::Forms::Keys::Shift) != 0,
			int(e->Modifiers & System::Windows::Forms::Keys::Alt) != 0,
			int(e->Modifiers & System::Windows::Forms::Keys::Control) != 0);
}
private: System::Void TestForm_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
	keyUpLabel->Text = "Key Up: " + e->KeyCode.ToString() + " (" + e->KeyValue.ToString() + ")";
	e->Handled = true; // prevents Alt from stealing the next down press and cancelling Ctrl
	e->SuppressKeyPress = true; // prevents key presses from activating listboxes

	// pipe it to the game
	if (currentGame != nullptr)
		currentGame->KeyUp(e->KeyValue, 
			int(e->Modifiers & System::Windows::Forms::Keys::Shift) != 0,
			int(e->Modifiers & System::Windows::Forms::Keys::Alt) != 0,
			int(e->Modifiers & System::Windows::Forms::Keys::Control) != 0);
}
private: System::Void testDialogPopupButton_Click(System::Object^  sender, System::EventArgs^  e) {
	MessageBox::Show("Test popup");
	// this deactivates the form.
}
private: System::Void testTimer_Tick(System::Object^  sender, System::EventArgs^  e) {
	GameContext::Metrics.WindowsIdleTimer.Stop();

	bool enableState = true;
	testTimer->Enabled = false;

	if (firstTick == true)
	{
		InitializeTestList();

		// Intialize app-level structures
		viewportPictureBoxIndex = GameApplicationContext::Instance->ViewportRegistry.RegisterViewport("Main", viewportPictureBox);
		InitializeGame();

		// by this time, all controls are properly initialized and we can start everything up
		firstTick = false;
	}
	if (currentGame != nullptr)
	{
		if (currentGame->BaseGameLoop() == false)
			enableState = false; // don't render anymore, game loop says to stop the game!
		else
		{
			currentGame->PerformRender();
		}

		// show joystick values
		JoystickValues *joystickValues = currentGame->GetJoystickValues();
		if (joystickValues->valid == true)
		{
			joystickXLabel->Text = "Joystick X: " + joystickValues->primaryX;
			joystickYLabel->Text = "Joystick Y: " + joystickValues->primaryY;
			joystickTwistLabel->Text = "Joystick Twist: " + joystickValues->twist;
			joystickButton1Label->Text = "Joystick Button 1: " + (joystickValues->button1Down ? "Down" : "Up");
			joystickButton2Label->Text = "Joystick Button 2: " + (joystickValues->button2Down ? "Down" : "Up");
			joystickButton3Label->Text = "Joystick Button 3: " + (joystickValues->button3Down ? "Down" : "Up");
			joystickButton4Label->Text = "Joystick Button 4: " + (joystickValues->button4Down ? "Down" : "Up");
		}
	}

	GameContext::Metrics.WindowsIdleTimer.Reset();
	GameContext::Metrics.WindowsIdleTimer.Start();

	testTimer->Enabled = enableState;
if (enableState == false)
	MessageBox::Show("Done");

}

private: void InitializeTestList()
{
	// until testing done, then put it at the bottom
	testListBox->Items->Add(gcnew TestListItem(TestNetworkString));
	testListBox->Items->Add(gcnew TestListItem(TestUIString));
	testListBox->Items->Add(gcnew TestListItem(AsteroidsString));
	testListBox->Items->Add(gcnew TestListItem(TestFPSString));

	testListBox->Items->Add(gcnew TestListItem(SimpleTriangle)); // this one tests the math routines
	testListBox->Items->Add(gcnew TestListItem(SimpleTextureString));
	testListBox->Items->Add(gcnew TestListItem(AlphaClipPlaneString));
	testListBox->Items->Add(gcnew TestListItem(TrapezoidTextureString));
	testListBox->Items->Add(gcnew TestListItem(ProjectedTextureString));
	testListBox->Items->Add(gcnew TestListItem(RotatingJet));
	testListBox->Items->Add(gcnew TestListItem(TerrainTest1String));
	testListBox->Items->Add(gcnew TestListItem(TerrainTest2String));
	testListBox->Items->Add(gcnew TestListItem(SkyboxString));
	testListBox->Items->Add(gcnew TestListItem(StarfieldString));
	testListBox->Items->Add(gcnew TestListItem(AlphaTrailString));
	testListBox->Items->Add(gcnew TestListItem(JetFlight1String));
	testListBox->Items->Add(gcnew TestListItem(FontTest1String));
	testListBox->Items->Add(gcnew TestListItem(JetGame1String));
	testListBox->Items->Add(gcnew TestListItem(GLShaderString));
	testListBox->Items->Add(gcnew TestListItem(TestVBOString));
	testListBox->Items->Add(gcnew TestListItem(TestShaderString));
	testListBox->Items->Add(gcnew TestListItem(LightingString));
	testListBox->Items->Add(gcnew TestListItem(MazeRunnerString));
	testListBox->Items->Add(gcnew TestListItem(PlatformerCellString));
	testListBox->Items->Add(gcnew TestListItem(BouncingBallString));
	testListBox->Items->Add(gcnew TestListItem(OrientInterpolationString));
	testListBox->Items->Add(gcnew TestListItem(JointedModelTestString));
	testListBox->Items->Add(gcnew TestListItem(AnimatedModelTestString));
	testListBox->Items->Add(gcnew TestListItem(AnaglyphSimpleString));
	testListBox->Items->Add(gcnew TestListItem(AnaglyphTrueString));
	testListBox->Items->Add(gcnew TestListItem(AnaglyphExperimentString));
	testListBox->Items->Add(gcnew TestListItem(DungeonHallString));
	testListBox->Items->Add(gcnew TestListItem(RenderBufferTextureString));
	testListBox->Items->Add(gcnew TestListItem(CubemapBufferTextureString));
	testListBox->Items->Add(gcnew TestListItem(OrthographicProjectionString));
	testListBox->Items->Add(gcnew TestListItem(DirectionalLightShadowString));
	testListBox->Items->Add(gcnew TestListItem(FrustumString));
	testListBox->Items->Add(gcnew TestListItem(Portal1String));
	testListBox->Items->Add(gcnew TestListItem(RandomDungeonString));
	testListBox->Items->Add(gcnew TestListItem(BitonicSortString));
	testListBox->Items->Add(gcnew TestListItem(ParticlesString));
	testListBox->Items->Add(gcnew TestListItem(MirrorTestString));
	testListBox->Items->Add(gcnew TestListItem(PostProcessTestString));
	testListBox->Items->Add(gcnew TestListItem(MotionBlurTestString));
	testListBox->Items->Add(gcnew TestListItem(TestGoogleCardboardStubString));
	testListBox->Items->Add(gcnew TestListItem(TestGoogleCardboardSceneStubString));
	testListBox->Items->Add(gcnew TestListItem(TestTetherSwingString));

	// trigger first test
	testListBox->SelectedItem = testListBox->Items[0];
}
private: System::Void TestForm_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
	if (currentGame != nullptr)
	{
		currentGame->Destroy(); // get rid of game data and context data that isn't app level like viewports
		GameApplicationContext::Instance->DestroyApp(); // get rid of app level data like viewports
		GameContext::Instance->DestroyApp(); // get rid of app level data
		delete currentGame;
	}
}
private: System::Void testListBox_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
	String ^selectedItem = testListBox->SelectedItem->ToString();

	if (currentGame != nullptr)
	{
		delete currentGame;
		currentGame = nullptr;
	}

	if (selectedItem == SimpleTriangle)
		currentGame = gcnew TestGame(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == SimpleTextureString)
		currentGame = gcnew TestTexture(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AlphaClipPlaneString)
		currentGame = gcnew AlphaClipPlane(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TrapezoidTextureString)
		currentGame = gcnew TrapezoidTexture(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == ProjectedTextureString)
		currentGame = gcnew ProjectedTexture(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == RotatingJet)
		currentGame = gcnew TestRotatingJet(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TerrainTest1String)
		currentGame = gcnew TerrainTest1(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TerrainTest2String)
		currentGame = gcnew TerrainTest2(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == SkyboxString)
		currentGame = gcnew SkyboxDomeTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == StarfieldString)
		currentGame = gcnew StarfieldTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AlphaTrailString)
		currentGame = gcnew SmokeTrailTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == JetFlight1String)
		currentGame = gcnew JetFlight1(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == FontTest1String)
		currentGame = gcnew FontTest1(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == JetGame1String)
		currentGame = gcnew JetGame1(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestVBOString)
		currentGame = gcnew TestNativeObject(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestShaderString)
		currentGame = gcnew TestShader(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == GLShaderString)
		currentGame = gcnew TestGLShader(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == LightingString)
		currentGame = gcnew TestLighting(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AsteroidsString)
		currentGame = gcnew AsteroidsGame(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == MazeRunnerString)
		currentGame = gcnew MazeRunnerGame(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == PlatformerCellString)
		currentGame = gcnew PlatformerCellGame(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == BouncingBallString)
		currentGame = gcnew BouncingBallGame(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == OrientInterpolationString)
		currentGame = gcnew OrientInterpolationTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == JointedModelTestString)
		currentGame = gcnew JointedModelTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AnimatedModelTestString)
		currentGame = gcnew AnimatedModelTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AnaglyphSimpleString)
		currentGame = gcnew AnaglyphSimpleTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AnaglyphTrueString)
		currentGame = gcnew AnaglyphTrueTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == AnaglyphExperimentString)
		currentGame = gcnew AnaglyphExperimentTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == DungeonHallString)
		currentGame = gcnew DungeonHallTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == RenderBufferTextureString)
		currentGame = gcnew RenderBufferTextureTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == CubemapBufferTextureString)
		currentGame = gcnew CubemapTextureTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == OrthographicProjectionString)
		currentGame = gcnew TestOrthographicProjection(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == DirectionalLightShadowString)
		currentGame = gcnew DirectionalLightShadowTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == FrustumString)
		currentGame = gcnew TestFrustum(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == Portal1String)
		currentGame = gcnew PortalAlphaTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == RandomDungeonString)
		currentGame = gcnew TestRandomDungeon(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == BitonicSortString)
		currentGame = gcnew BitonicSortTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == ParticlesString)
		currentGame = gcnew TestParticles(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == MirrorTestString)
		currentGame = gcnew TestMirror(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == PostProcessTestString)
		currentGame = gcnew PostProcessShaderTest(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == MotionBlurTestString)
		currentGame = gcnew TestMotionBlur(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestGoogleCardboardStubString)
		currentGame = gcnew TestGoogleCardboardStub(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestGoogleCardboardSceneStubString)
		currentGame = gcnew TestGoogleCardboardSceneStub(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestTetherSwingString)
		currentGame = gcnew TestTetherSwing(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestNetworkString)
		currentGame = gcnew TestNetwork(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestUIString)
		currentGame = gcnew TestUI(static_cast<HWND>(this->Handle.ToPointer()));
	else if (selectedItem == TestFPSString)
		currentGame = gcnew TestFPSGame(static_cast<HWND>(this->Handle.ToPointer()));

	// don't init if firsttick hasn't occurred yet - first init will be handled in firstTick block
	if (firstTick == false)
	{
		InitializeGame();
	}
}

private:
	void InitializeGame()
	{
		// initialize selected game and set main text caption
		currentGame->Initialize();

		if (currentGame->ApplicationName() != "")
		{
			Text = "GameEng Tests - " + currentGame->ApplicationName();
		}
		else
			Text = "GameEng Tests - " + testListBox->SelectedItem->ToString();
	}

private: System::Void TestForm_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
	// never called
}
private: System::Void viewportPictureBox_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
	// never called
}
};
}
