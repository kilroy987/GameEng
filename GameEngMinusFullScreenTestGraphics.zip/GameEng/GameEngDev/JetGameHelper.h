#pragma once

#include "..\Headers\Orient.h"
#include "..\Headers\Vector.h"
#include "..\Headers\TerrainMesh.h"
#include "..\Headers\LinkedListTemplate.h"
#include "..\Headers\Partition.h"
#include "..\Headers\GameBase.h"
#include "..\Headers\Model.h"
#include "..\Headers\Skybox.h"
#include "..\Headers\StarfieldPoint.h"
#include "..\Headers\Tools.h"
#include "..\Headers\GameContext.h"
#include "..\Headers\GameApplicationContext.h"
#include "..\Headers\MathConstants.h"
#include "..\Headers\GameObjectBase.h"
#include "..\Headers\GameWidgets.h"
#include <vcclr.h> // gcroot

namespace GameEngDev {
	namespace JetGameHelper {

		using namespace GameEng::Math;
		using namespace GameEng::Graphics;
		using namespace GameEng::Storage;
		using namespace GameEng::Game;
		using namespace GameEng::GameObject;
		using namespace GameEng::Tools::Timer;
		using namespace GameEng::Tools::Random;
		using namespace GameEng::Widgets;

		class GameJoystickValues
		{
		private:
			int currentX;
			int currentY;
			int currentTwist;

		public:
			int intendedX;
			int intendedY;
			int intendedTwist;
			bool gunButton;
			bool secondaryButton;

			GameJoystickValues()
			{
				currentX = 0;
				currentY = 0;
				currentTwist = 0;

				intendedX = 0;
				intendedY = 0;
				intendedTwist = 0;

				gunButton = false;
				secondaryButton = false;
			}

			int GetCurrentX()
			{
				return currentX;
			}
			int GetCurrentY()
			{
				return currentY;
			}
			int GetCurrentTwist()
			{
				return currentTwist;
			}
			bool GetCurrentGun()
			{
				return gunButton;
			}
			bool GetCurrentSecondary()
			{
				return secondaryButton;
			}

			void SetCurrentX(int p_x)
			{
				currentX = p_x;
			}
			void SetCurrentY(int p_y)
			{
				currentY = p_y;
			}
			void SetCurrentTwist(int p_twist)
			{
				currentTwist = p_twist;
			}
			void SetGunButton(bool p_gun)
			{
				gunButton = p_gun;
			}
			void SetSecondaryButton(bool p_secondary)
			{
				secondaryButton = p_secondary;
			}

			void ApplyValues(int p_joystickValueToApply, int p_twistValueToApply)
			{
				if (currentX < intendedX)
				{
					if ((currentX + p_joystickValueToApply) > intendedX)
						currentX = intendedX;
					else
						currentX += p_joystickValueToApply;
				}
				else if (currentX > intendedX)
				{
					if ((currentX - p_joystickValueToApply) < intendedX)
						currentX = intendedX;
					else
						currentX -= p_joystickValueToApply;
				}

				if (currentY < intendedY)
				{
					if ((currentY + p_joystickValueToApply) > intendedY)
						currentY = intendedY;
					else
						currentY += p_joystickValueToApply;
				}
				else if (currentY > intendedY)
				{
					if ((currentY - p_joystickValueToApply) < intendedY)
						currentY = intendedY;
					else
						currentY -= p_joystickValueToApply;
				}

				if (currentTwist < intendedTwist)
				{
					if ((currentTwist + p_twistValueToApply) > intendedTwist)
						currentTwist = intendedTwist;
					else
						currentTwist += p_twistValueToApply;
				}
				else if (currentTwist > intendedTwist)
				{
					if ((currentTwist - p_twistValueToApply) < intendedTwist)
						currentTwist = intendedTwist;
					else
						currentTwist -= p_twistValueToApply;
				}
			}

		};

		// primary behaviors - decision behaviors that is.  States on the jet itself may override these behaviors and force other states (such as a dead jet)
		enum class JetBehaviorEnum {
			StayInFormation,	// for the following jets
			FlyWaypoints,	// lead jet
			PatrolWaypoints // as flywaypoints, but will attack
		};

		// object types
		enum class JetGameObjectEnum {
			None, // for initializations only - not a valid active type
			Jet,
			Bullet,
			Missile
		};

		class JetGameObjectHelper
		{
		public:
			static System::String^ ConvertObjectTypeToString(JetGameObjectEnum p_objectType)
			{
				switch (p_objectType)
				{
				case JetGameObjectEnum::None:
					return "None";
					break;
				case JetGameObjectEnum::Jet:
					return "Jet";
					break;
				case JetGameObjectEnum::Bullet:
					return "Bullet";
					break;
				case JetGameObjectEnum::Missile:
					return "Missile";
					break;
				default:
					throw gcnew Exception("Unsupported object type - make sure JetGameObjectHelper::ConvertObjectTypeToString() covers all possible object types");
					break;
				}
			}
		};
		
		class JetGameValues {
		public:
			static float MaxCruiseThrust()
			{
				// applied as p_thrust * 0.00001f * p_MS
				return 0.53f; // about 150mph (0.022 units/sec with drag)
			}
			static float AccelerateThrust() // temporary adjustment with W/S key
			{
				return 0.10f;
			}
			static float AdjustThrust() // adjustment with +/- key
			{
				return 0.0125f;
			}
			static float WaypointFlightThrust()
			{
				return MaxCruiseThrust() * 0.9f;
			}
			static float AfterburnerThrust()
			{
				// applied as p_thrust * 0.00001f * p_MS
				return 1.06f; // about 300mph
			}
			static float FeetPerWorldUnit()
			{
				return 10.0f;
			}
			static float GravityAccelerationPerMSSquared()
			{
				return 9.80665f /* m/s^2 */ * 3.28084f /* conversion from 1 m/s^2 to 1 ft/s^2 */ / FeetPerWorldUnit() / 1000000.0f;  // since world 1.0f = simulated 10 ft, acceleration should be around 3.2 ft/s^2 instead of 32 ft/s^2
			}
			static int JoystickPrimaryDeadArea()
			{
				return 150;
			}
			static int JoystickTwistDeadArea()
			{
				return 250;
			}
			static float AIJoystickPrimaryMovePerMS()
			{
				return 4.0f;
			}
			static float AIJoystickTwistMovePerMS()
			{
				return 8.0f;
			}
			static float JetFuselageCollisionRadius()
			{
				return 5.0f / FeetPerWorldUnit(); // 5 foot radius sphere for now, used for actual collisions
			}
			static float JetFuselageJetCollisionPredictionRadius()
			{
				return 15.0f / FeetPerWorldUnit(); // 15 foot radius sphere for now, used for ai avoidance of collision (if >15 flying stable formation is shaky with current formation distances)
			}
			static float JetFuselageTerrainCollisionPredictionRadius()
			{
				return 30.0f / FeetPerWorldUnit(); // 20 foot radius sphere for now, used for ai avoidance of collision
			}
			static float BulletExitSpeedFeetPerMS()
			{
				// 1000 mph for now
				// converting to world units per ms
				return 1000.0f * 5280.0f / 3600.0f / FeetPerWorldUnit() / 1000.0f; 
			}
			static int BulletShotDelayMS()
			{
				return 125; // 8 shots per second
			}
			static float LightAirMissileThrust()
			{
				// applied as p_thrust * 0.00001f * p_MS
				return 4.0f; // with drag gets up to 600mph (0.088 units/ms, 1 unit = 10 feet) (so drag should reduce speed by 0.00004/ms at top speed)
			}
			static float LightAirMissileLaunchSpeed()
			{
				return 0.022f; // about 150mph
			}
			static float MissileCollisionRadius()
			{
				return 5.0f / FeetPerWorldUnit();
			}
			static float JetStartingHealth()
			{
				return 100.0f;
			}
			static float BulletDamage()
			{
				return 5.0f;
			}
			static float MissileFullImpactDamage()
			{
				return 100.0f;
			}
			static float MissileMaxDamageDistance() // at 20 feet, no damage, at 10 feet, 1/2 damage, etc.
			{
				return 20.0f / FeetPerWorldUnit();
			}
			static int DamageIndicatorTimerMS()
			{
				return 4000;	// 4 seconds after damage occurs (2 seconds provides deceptive feedback as if the jet died)
			}
			static float JetEncounterDistance()
			{
				return 2600.0f / FeetPerWorldUnit(); // about half a mile away
			}
			static float JetBulletDamageWaggle()
			{
				return 0.05f;
			}
			static float MissileStrikeForceOffset()
			{
				return 0.003f;
			}
			static int BehaviorDecisionDelayMS()
			{
				return 500;  // every 1/2 second
			}
		};

		// alternative to enum
		class SmokeTrailType {
		public:
			static const int MissileTrail = 1;
			static const int VaporTrail = 2;
		};

		class Waypoint {
		public:
			Vector3d point;
		};

		class WaypointList : public LinkedList<Waypoint>
		{
		public:
			virtual ~WaypointList()
			{
				LinkedList<Waypoint>::Destroy();
			}

			void Add(Vector3d &p_vector)
			{
				LinkedListNode<Waypoint> *newNode = GetNewNode();
				newNode->data.point = p_vector;
				LinkedList<Waypoint>::AddNode(newNode);
			}

			// todo: careful removing waypoints by interface - if a jet is currently flying to that waypoint it will need to get the next waypoint before this node is removed!
			LinkedListNode<Waypoint> * GetNextWaypoint(LinkedListNode<Waypoint> *currentNode)
			{
				if (currentNode == nullptr)
				{
					if (IsEmpty())
						return nullptr;
					else
						return header.next;
				}

				if (currentNode->next == &footer)
				{
					if (IsEmpty())
						return nullptr;
					else
						return header.next;
				}
				else
					return currentNode->next;
			}
		};

		//class Particle
		//{
		//public:
		//	Vector3d center;
		//	float radius;
		//	gcroot<GameTexture^> textureRef;
		//	int maxLifeMS;
		//	float radiusExpansionPerMS;
		//	unsigned char startAlpha;
		//	int rotationAngle;
		//	GameColor color;
		//	Vector3d renderOffset; // for bubble sorting and check during rendering

		//	int lifeMS;
		//};

		enum class EnergyEffectAnimationTypeEnum
		{
			SingleFrame // render for a single frame then remove it
		};

		enum class EnergyEffectPositionTypeEnum
		{
			OrientPosition, // add parent position to space position
			OrientSpace, // convert position to world space using full orient
			World // no parent, just use the position
		};

		class EnergyEffect
		{
		public:
			Vector3d renderCenter; // calculated before render

			Vector3d spacePosition;
			GameObjectRef parentRef;
			EnergyEffectAnimationTypeEnum animationType;
			EnergyEffectPositionTypeEnum positionType;
			GameColor color;
			gcroot<GameTexture^> textureRef;
			float degreeRotation;
			float radius;
			bool rendered; // was it rendered yet, or tried to?
		};
		
		/////////////////////////////////////////////////////
		// Hardpoints, general usage
		// If a weapon has two locations that are always linked, configure a single weapon with more than one location using the same ammo pool
		// If a weapon has more than one location but fire independently, configure a weapon with multiple fireableweapons, each with one or more locations
		class HardpointWeaponLocation
		{
			int *childOrientPathIndexes; // if weapon location isn't off from main orient (this point != nullptr), provide path to the orient the location is a child of
			int orientIndexQty;
			Vector3d location;

		public:
			HardpointWeaponLocation()
			{
				childOrientPathIndexes = nullptr;
				orientIndexQty = 0;
			}

			~HardpointWeaponLocation()
			{
				Destroy();
			}

			void Initialize(Vector3d &p_location, int p_childOrientQty = 0)
			{
				location = p_location;

				if (p_childOrientQty > 0)
				{
					childOrientPathIndexes = new int[p_childOrientQty];
					orientIndexQty = p_childOrientQty;
				}
			}

			void SetChildOrientIndex(int p_index, int p_value)
			{
				childOrientPathIndexes[p_index] = p_value;
			}

			Vector3d GetWeaponWorldLocation(Orient3d &p_mainOrient, Orient3d *p_childOrients = nullptr)
			{
				if (p_childOrients == nullptr || childOrientPathIndexes == nullptr)
					return p_mainOrient.TransformToWorldSpace(location);
				else
				{
					Orient3d *parentOrient = &p_mainOrient;
					Vector3d result = parentOrient->p;

					for (int i = 0; i < orientIndexQty; i++)
					{ 
						Orient3d *childOrient = &p_childOrients[childOrientPathIndexes[i]];
						result = result + parentOrient->TransformToWorldSpaceOffset(childOrient->p);
						parentOrient = childOrient;

						if (i == orientIndexQty - 1)
						{
							result = result + childOrient->TransformToWorldSpaceOffset(location);
						}
					}

					return result;
				}
			}

			Vector3d & GetLocation()
			{
				return location;
			}

		private:
			void Destroy()
			{
				if (childOrientPathIndexes != nullptr)
				{
					delete[] childOrientPathIndexes;
					childOrientPathIndexes = nullptr;
					orientIndexQty = 0;
				}
			}
		};

		// buttons to press to fire weapon
		enum class HardpointWeaponControlType
		{
			Primary,
			Secondary
		};

		// a single fireable weapon, possibly with multiple slots that always fire together as a single ammo unit
		// at the game object level, this is what has a fire delay and ammo pool
		class HardpointFireableWeapon
		{
		public:

			// if there are multiple locations, they are linked and fire together - later, multiple weapons of the same type can be linked by implementation
			HardpointWeaponLocation *locations;
			int locationQty;

		public:
			HardpointFireableWeapon()
			{
				locations = nullptr;
				locationQty = 0;
			}

			~HardpointFireableWeapon()
			{
				Destroy();
			}

			void Initialize(int p_locationQty = 1)
			{
				locations = new HardpointWeaponLocation[p_locationQty];
				locationQty = p_locationQty;
			}

			void SetHardpointLocation(int p_index, Vector3d &p_location, int p_childOrientQty = 0)
			{
				locations[p_index].Initialize(p_location, p_childOrientQty);
			}

			HardpointWeaponLocation & GetHardpointLocation(int p_index)
			{
				return locations[p_index];
			}

		private:
			void Destroy()
			{
				if (locations != nullptr)
				{
					delete[] locations;
					locationQty = 0;
				}
			}
		};

		// a single weapon type, listing the fireable units inside (a missile type can have multiple fireable weapons)
		class HardpointWeaponConfigurationEntry
		{
		public:
			JetGameObjectEnum weaponType; // objectType
			float ammoAmountUsage;
			int fireDelayMS;
			int maximumAmmoPool; // recharge stops
			float ammoAmountRechargePerMS;
			float speedPerMS; // exit velocity
			bool autoFire; // single press repeated fire vs. one shot per hold
			bool render; // is weapon visible when on main model it isn't fired?

			HardpointFireableWeapon *fireableWeapons;
			int fireableWeaponQty;

			HardpointWeaponConfigurationEntry()
			{
				fireableWeapons = nullptr;
				fireableWeaponQty = 0;
			}

			~HardpointWeaponConfigurationEntry()
			{
				Destroy();
			}

			void Destroy()
			{
				if (fireableWeapons != nullptr)
				{
					delete[] fireableWeapons;
					fireableWeapons = nullptr;
					fireableWeaponQty = 0;
				}
			}

			void Initialize(JetGameObjectEnum p_weaponType, float p_ammoAmountUsage, float p_ammoRechargePerMS, int p_maximumAmmoPool, float p_speedPerMS, int p_fireDelayMS, bool p_autoFire, int p_fireableWeaponQty = 1, bool p_render = false)
			{
				weaponType = p_weaponType;

				ammoAmountUsage = p_ammoAmountUsage;
				maximumAmmoPool = p_maximumAmmoPool;
				speedPerMS = p_speedPerMS;
				ammoAmountRechargePerMS = p_ammoRechargePerMS;
				autoFire = p_autoFire;
				render = p_render;
				fireDelayMS = p_fireDelayMS;

				fireableWeapons = new HardpointFireableWeapon[p_fireableWeaponQty];
				fireableWeaponQty = p_fireableWeaponQty;
			}

			HardpointFireableWeapon & GetFireableWeapon(int p_index)
			{
				return fireableWeapons[p_index];
			}

			int GetWeaponSlotCount()
			{
				return fireableWeaponQty;
			}
		};

		// all fireable weapon units (can be multiple of the same type, each a fireable weapon, some can be linked later by implementation)
		// list of weapons (type unique), each having multiple fireable weapons elements with multiple locations (missile can have 2 fireable weapons, each with 2 locations so that each fires 2 for a total of 4)
		class HardpointConfiguration
		{
			JetGameObjectEnum objectType; // which object is using these weapons? (Jet, ScoutBuggy, Hovercraft, etc.)
			LinkedList<HardpointWeaponConfigurationEntry> weapons;

		public:
			HardpointConfiguration() // need this to support linked lists
			{
				objectType = JetGameObjectEnum::None;
			}

			~HardpointConfiguration()
			{
				Destroy();
			}

			int GetWeaponQty()
			{
				return weapons.Count();
			}

			void Initialize(JetGameObjectEnum p_objectType)
			{
				objectType = p_objectType;
				weapons.Clear(); // might have been pulled from the deleted list after a game recycle, so make sure it's empty
			}

			HardpointWeaponConfigurationEntry * Add(JetGameObjectEnum p_weaponType, float p_ammoAmountUsage, float p_ammoRechargePerMS, int p_maximumAmmoPool, float p_speedPerMS, int p_fireDelayMS, bool p_autoFire, int p_fireableWeaponQty = 1, bool p_render = false)
			{
				// make sure that weapon isn't already in the registry
				if (GetWeaponEntry(p_weaponType, false) != nullptr)
					throw gcnew System::Exception("Weapon type '" + JetGameObjectHelper::ConvertObjectTypeToString(p_weaponType) + "' weapon configuration is already registered");

				LinkedListNode<HardpointWeaponConfigurationEntry> *newNode = weapons.GetNewNode();
				newNode->data.Initialize(p_weaponType, p_ammoAmountUsage, p_ammoRechargePerMS, p_maximumAmmoPool, p_speedPerMS, p_fireDelayMS, p_autoFire, p_fireableWeaponQty, p_render);
				weapons.AddNode(newNode);
				return &(newNode->data);
			}

			HardpointWeaponConfigurationEntry * GetWeaponEntry(JetGameObjectEnum p_weaponType, bool p_exceptionOnNotFound = true)
			{
				LinkedListEnumerator<HardpointWeaponConfigurationEntry> enumerator = LinkedListEnumerator<HardpointWeaponConfigurationEntry>(weapons);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.weaponType == p_weaponType)
						return &(enumerator.Current()->data);
				}

				if (p_exceptionOnNotFound == true)
					throw gcnew Exception("Weapon type '" + JetGameObjectHelper::ConvertObjectTypeToString(p_weaponType) + "' not found");
				else
					return nullptr;
			}

			LinkedListEnumerator<HardpointWeaponConfigurationEntry> GetWeaponEnumerator()
			{
				return LinkedListEnumerator<HardpointWeaponConfigurationEntry>(weapons);
			}


			JetGameObjectEnum GetObjectType()
			{
				return objectType;
			}

		private:
			void Destroy()
			{
				weapons.Clear();
			}
		};

		// track ammo amount for each weapon
		// track current weapon slot for each weapon type (for those with only one slot, it will always be the same.  For others, cycle forward through them, with an option to set the current one manually)
		// also, if not repeatFire, should the player lift up to fire again? (per weapon type - this requires a change to the structure - Missile has two configs, for example, with a header that provides current and whether or not the control needs to be lifted to fire again)
		class HardpointWeaponSlotState
		{
		public:
			float currentAmmo;
			int fireDelayMS; // if <= 0 can fire if ammo is high enough
			int slotIndex;
		};

		// one for each weapon type, as a general header for the actual slots
		// slotStates should always be created as the max number of slots any weapon could possibly have so it can be reused
		class HardpointWeaponState
		{
		public:
			JetGameObjectEnum weaponType;
			HardpointWeaponSlotState *slotStates;
			int slotQty; // how many are actually used?
			HardpointWeaponSlotState *currentWeaponRef;	// which one is 'current'?  For weapons with multiple slots, which one will fire? (doesn't cover multi slot linking yet)
			bool controlDown; // if control is down, must be lifted to fire again (todo: will will need an upgrade when multiple weapons use the same button but only one is selected at a time)
			HardpointWeaponConfigurationEntry *entryRef;

			HardpointWeaponState()
			{
				slotStates = nullptr;
				currentWeaponRef = nullptr;
			}

			~HardpointWeaponState()
			{
				if (slotStates != nullptr)
				{
					delete[] slotStates;
					slotStates = nullptr;
				}
			}
		};

		// All data necessary to maintain weapon hard points for a single game object
		// Should have as many slots as the maximum number of weapons in a configuration for reusability
		// every game object requiring hardpoints will have one of these if it doesn't already when the node is retrieved from the deleted list
		// will need to be initialized
		class HardpointObjectGameState
		{
		public:
			int objectWeaponQty; // how many slots is this game object using? (not the same as the max number of slots used by all objects)
			HardpointWeaponState *weaponStates;
			HardpointConfiguration *configRef;
			HardpointWeaponConfigurationEntry *entryRef;

			HardpointObjectGameState()
			{
				weaponStates = nullptr;
				configRef = nullptr;
				entryRef = nullptr;
			}

			~HardpointObjectGameState()
			{
				Destroy();
			}

			void Destroy()
			{
				if (weaponStates != nullptr)
				{
					delete [] weaponStates;
					weaponStates = nullptr;
				}
			}

			HardpointWeaponState * GetWeaponState(JetGameObjectEnum p_weaponType)
			{
				for (int i = 0; i < objectWeaponQty; i++)
				{
					if (weaponStates[i].entryRef->weaponType == p_weaponType)
						return &(weaponStates[i]);
				}

				throw gcnew System::Exception("Weapon state for '" + JetGameObjectHelper::ConvertObjectTypeToString(p_weaponType) + "' not found");
			}
		};


		class HardpointConfigurationRegistry
		{
		private:
			// these values are used to create a game object's hardpoint tracker
			int maxWeaponTypeQty; // how many total configs are there in the largest hardpointconfiguration (ammo to track, etc.)
			int maxWeaponSlots; // what is the largest number of slots a single weapon uses? (for a weapon type, which one is the current selected)
			// still need a counter for different weapon types - todo: config should have a weapon type as a header and slots as children.
			// except right now multiple slots as children mean they are linked.

			LinkedList<HardpointConfiguration> weaponConfigs;

		public:
			HardpointConfigurationRegistry()
			{
				maxWeaponSlots = 0;
				maxWeaponTypeQty = 0;
			}

			~HardpointConfigurationRegistry()
			{
				Destroy();
			}

			void Destroy()
			{
				weaponConfigs.Clear();
			}

			HardpointConfiguration * Add(JetGameObjectEnum p_objectType)
			{
				// make sure that weapon isn't already in the registry
				if (GetWeaponConfiguration(p_objectType, false) != nullptr)
					throw gcnew System::Exception("Object type '" + JetGameObjectHelper::ConvertObjectTypeToString(p_objectType) + "' hardpoint configuration is already registered");

				LinkedListNode<HardpointConfiguration> *newNode = weaponConfigs.GetNewNode();
				newNode->data.Initialize(p_objectType);
				weaponConfigs.AddNode(newNode);
				return &(newNode->data);
			}

			void Evaluate(JetGameObjectEnum p_objectType)
			{
				if (GetWeaponConfiguration(p_objectType)->GetWeaponQty() > maxWeaponTypeQty)
					maxWeaponTypeQty = GetWeaponConfiguration(p_objectType)->GetWeaponQty();
				LinkedListEnumerator<HardpointWeaponConfigurationEntry> enumerator = GetWeaponConfiguration(p_objectType)->GetWeaponEnumerator();
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.fireableWeaponQty > maxWeaponSlots)
						maxWeaponSlots = enumerator.Current()->data.fireableWeaponQty;
				}
			}

			HardpointConfiguration * GetWeaponConfiguration(JetGameObjectEnum p_objectType, bool p_exceptionOnNull = true)
			{
				LinkedListEnumerator<HardpointConfiguration> enumerator = LinkedListEnumerator<HardpointConfiguration>(weaponConfigs);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.GetObjectType() == p_objectType)
						return &(enumerator.Current()->data);
				}

				if (p_exceptionOnNull == true)
					throw gcnew System::Exception("Hardpoint configuration not found for object '" + JetGameObjectHelper::ConvertObjectTypeToString(p_objectType) + "'"); // might need a converter here

				return nullptr;
			}

			HardpointObjectGameState * CreateObjectHardpointGameState(JetGameObjectEnum p_objectType)
			{
				HardpointObjectGameState *result = new HardpointObjectGameState();

				HardpointConfiguration *config = GetWeaponConfiguration(p_objectType);
				result->weaponStates = new HardpointWeaponState[maxWeaponTypeQty];
				result->objectWeaponQty = config->GetWeaponQty();
				for (int i = 0; i < maxWeaponTypeQty; i++)
				{
					result->weaponStates[i].slotStates = new HardpointWeaponSlotState[maxWeaponSlots];
				}

				return result;
			}

			void InitializeObjectHardpointGameState(JetGameObjectEnum p_objectType, HardpointObjectGameState *p_state)
			{
				HardpointConfiguration *config = GetWeaponConfiguration(p_objectType);
				p_state->configRef = config;
				LinkedListEnumerator<HardpointWeaponConfigurationEntry> enumerator = config->GetWeaponEnumerator();
				int weaponIndex = 0;
				while (enumerator.MoveNext())
				{
					p_state->weaponStates[weaponIndex].controlDown = false;
					p_state->weaponStates[weaponIndex].weaponType = enumerator.Current()->data.weaponType;
					p_state->weaponStates[weaponIndex].entryRef = config->GetWeaponEntry(enumerator.Current()->data.weaponType);
					p_state->weaponStates[weaponIndex].slotQty = enumerator.Current()->data.GetWeaponSlotCount();

					for (int i = 0; i < p_state->weaponStates[weaponIndex].slotQty; i++)
					{
						p_state->weaponStates[weaponIndex].slotStates[i].currentAmmo = float(enumerator.Current()->data.maximumAmmoPool);
						p_state->weaponStates[weaponIndex].slotStates[i].fireDelayMS = 0;
						p_state->weaponStates[weaponIndex].slotStates[i].slotIndex = i;
					}

					p_state->weaponStates[weaponIndex].currentWeaponRef = &(p_state->weaponStates[weaponIndex].slotStates[0]);

					weaponIndex++;
				}
			}
		};

		class BehaviorBase;
		class JetGameObject : public GameObjectBase // can't be protected since we need to convert this class to a pointer to a GameObjectBase
		{
		public:
			JetBehaviorEnum behavior; // behavior to perform (within domain handled by the specific behavior class)

			// these should be in sync
			BehaviorBase *behaviorRef; // class to execute behavior (= object type - JetBehavior, BulletBehavior, MissileBehavior, etc.)
			JetGameObjectEnum objectType; // Jet, Bullet, Behavior

			GameJoystickValues joystick; // set by ai (maneuver and weapon controls)
			float setThrust; // manual setting of thrust by AI/controls
			bool afterburner; // ai
			bool accelerate; // ai
			bool decelerate; // ai
			bool airBrake; // ai

			// values needed for rendering, not necessary for anything else really
			float actualThrust; // thrust applied to physics (setthrust with optional +/- accel/decel or afterburner)
			float rudder;
			float leftAileron;
			float rightAileron;
			
			// todo: remove these when hardpoints running
			int gunDelayMS; // delay until bullets can be fired - can have remainder from last tick so that bullets truly fire at the correct rate
			bool missileFired; // if missileFired, must release button to fire another
			// ai only
			int missileAITimerMS; // prevent AI from firing missile too often, for now (will be replaced by hardpoint, ammo recharge and optimal firing time later)

			HardpointObjectGameState *hardpointState; // this is actual storage that should be deleted when this node is destroyed if != nullptr

			// affected by physics
			Orient3d orient;
			Vector3d velocity;
			Vector3d priorPosition;
			bool priorPositionValid;

			// which faction is this squad part of? (team would have multiple factions)
			int faction;
			// factions are part of an alliance - usually just = themselves, but objects with the same team are allies
			int alliance;

			float health; // at 0.0, dead - applies only to objects with health
			int damageIndicatorTimerMS; // local only - show a damage indicator above the target on the hud - at zero, don't show it
			bool dead; // if dead, is an ai-less object - it can still have physics applied to it, but anything that would be set by ai will be blank
			// when set to true, ranks or leader will be reassigned (the same will occur when the jet is deleted but was not dead at the time)

			// rendering
			bool alphaRender; // is alpha blending involved in this object? (render solids first, then alphas without writing to z-buffer later)

			// for flying waypoints
			WaypointList *waypointListRef;
			LinkedListNode<Waypoint> *currentWaypointRef;

			// for formation flying
			GameObjectRef squadLeader;
			GameObjectRef squadPartner; // who does this jet depend on to get into formation?
			int squadRank; // which position does this jet have in the squadron? 0 = leader, 1, 2 etc. (assumed to be in order of appearance in list)

			// note: object refs dont' necessarily have to be in the same list (ex. bullets are in one list, the jet that fired them is in another)
			// primary target being attacked
			GameObjectRef targetRef;
			// which object did this come from
			GameObjectRef sourceRef;
			bool canCollideWithSource;

			// used for missiles to decide when they should shut off their thrust due to having no target
			int thrustShutOffMS;
			// used for jet to make vapor trails in routine that is supplied the smoketrails structure
			bool vaporTrails;
			// used for dropping black smoke after dead, randomly repopulated
			int smokeDelayMS;

			// jets use both for vapor trails, missiles use 1 for smoke trail.  These alpha trails exist in a master list that the renderer is aware of
			// if a trail is empty, that means no object is using it and the master list can remove the trail - but that decision is not made in the object ai behavior
			// the object ai will place a point where appropriate - if the pointer is null, a new list is made.  If a trail is not needed, the ref is set to null so that
			//   a new one is made when it is needed.
			AlphaTrail *smokeTrailRef1;
			AlphaTrail *smokeTrailRef2;

			// water skimming effects - so that they aren't created every tick
			//float leftWingTipWaterRippleDistanceDelay;
			//float rightWingTipWaterRippleDistanceDelay;
			float leftWingTipWaterFountainDistanceDelay;
			float rightWingTipWaterFountainDistanceDelay;

			// for display - bullet hits cause waggle
			Vector3d damageReticleWaggle;
			int damagePulseMS[8]; // 8 step arc around object determining where damage is coming from - timer to show and fade when rendering reticle, understood to start at 500ms

			int behaviorDecisionDelay; // amount of time to wait until a behavior decision is made
			// value not re-evaluated until behavior decision delay reaches zero again
			bool weaponObstructed;

			// flame rendering (preserved values for left and right eye)
			GameColor flameIntensity;
			Vector3d flameOffset1Main;
			Vector3d flameOffset2Main;

			JetGameObject()
			{
				hardpointState = nullptr; // when create new, leave it null, it might get set later.  Don't change this pointer during Initialize(), let the method creating the object take care
										  // of this pointer if needed.
			}

			~JetGameObject()
			{
				if (hardpointState != nullptr)
				{
					delete hardpointState;
					hardpointState = nullptr;
				}
			}

			void Initialize(GameObjectIdCounter &p_counter)
			{
				GameObjectBase::Initialize(p_counter);

				// any other initializations necessary in general (also see CreateGameObjects - either move them all there or here)
				priorPositionValid = false;
				if (objectType != JetGameObjectEnum::Bullet) // save time when making bullets since we make a lot of them.  not a huge deal but these values aren't used for bullets anyway
				{
					setThrust = 0.0f;
					gunDelayMS = 0;
					missileFired = false;
					dead = false;
					targetRef.Clear();
					sourceRef.Clear();
					alphaRender = false;
					smokeTrailRef1 = nullptr;
					smokeTrailRef2 = nullptr;
					vaporTrails = false;
					damageIndicatorTimerMS = 0;
					smokeDelayMS = 0;
					thrustShutOffMS = 0;
					missileAITimerMS = 0;
					canCollideWithSource = true;
					leftWingTipWaterFountainDistanceDelay = 0;
					rightWingTipWaterFountainDistanceDelay = 0;
				}

				// other initializations are expected to be handled by the game code, such as:
				// position, velocity, behavior and any other variables that are required for that behavior, etc.
			}

			// damage pulse could be moved off as its own class and realistically should only be handled on the client controlled craft, but this is ok for now
			void SetDamagePulse(float p_incomingDegrees) // 0 is from straight ahead, 90 is from the right, etc,
			{
				float cyclicDegrees = MathUtilities::NormalizeCyclicDegrees(p_incomingDegrees + 360.0f / float(GetDamagePulseQty() * 2)); // add 1/(16*2) so that -n to m uses slot 0, etc.
				int index = int(cyclicDegrees / (360.0f / float(GetDamagePulseQty())));
				if (index < 0)
					index = 0;
				if (index > GetDamagePulseQty() - 1)
					index = GetDamagePulseQty() - 1;
				damagePulseMS[index] = 500;
			}

			void ResetDamagePulses()
			{
				for (int i = 0; i < GetDamagePulseQty(); i++)
				{
					damagePulseMS[i] = 0;
				}
			}

			void AnimateDamagePulses(int p_MS)
			{
				for (int i = 0; i < GetDamagePulseQty(); i++)
				{
					if (damagePulseMS[i] < p_MS)
						damagePulseMS[i] = 0;
					else
						damagePulseMS[i] -= p_MS;

				}
			}

			int GetDamagePulseQty()
			{
				return 8;
			}

			Tuple<unsigned char, float> ^ GetDamagePulseAlphaAndDegrees(int p_index)
			{
				int value = int(255 * damagePulseMS[p_index] / 500);
				unsigned char alpha;
				if (value < 0)
					alpha = 0;
				else if (value > 255)
					alpha = 255;
				else
					alpha = (unsigned char)value;

				float degrees = p_index * 360.0f / float(GetDamagePulseQty());

				return gcnew Tuple<unsigned char, float>(alpha, degrees);
			}
		};

		class JetGameObjectNode : public LinkedListNode<JetGameObject>
		{
		};

		class JetGameObjectList : public LinkedList<JetGameObject>
		{
		public:
			// no members here, just an indicator of our game list and what it does
			JetGameObjectList::JetGameObjectList() : LinkedList<JetGameObject>() {};
			JetGameObjectList::JetGameObjectList(char *p_name) : LinkedList<JetGameObject>(p_name) {};

			virtual ~JetGameObjectList()
			{
				// just in case
				LinkedList<JetGameObject>::Destroy();
			}
		};

		// single structure that supplies all gamestate data in a single structure - makes it easy to pass around in Behavior routines, and prevents haveing to upgrade
		//   method signatures every time something new is added
		// no constructor or destructor here. It's all pointer references
		class JetGameStateData
		{
		public:
			GameObjectIdCounter *gameObjectIdCounterRef; // object counter for all JetGameObjects (even if not in same list - IDs will not duplicate across lists)

			JetGameObjectList *mainGameObjectListRef; // behaving objects that can collide with each other
			JetGameObjectList *bulletListRef; // bullets only - can't collide with each other, but can collide with jets (not missiles, but that's ok, there usually aren't a lot of missiles flying)
			//LinkedList<Particle> *particleListRef; // all particles
			LinkedList<AlphaTrail> *smokeTrailsRef; // smoke trails
			LinkedList<EnergyEffect> *fastEffectsRef; // fast energy effects
			VolumePartition<LinkedList<Particle>> *particlePartitionRef;
			HardpointConfigurationRegistry *hardpointConfigurationRegistryRef;
		};

		class BehaviorBase
		{
		public:
			// do this for all obejcts, ai or not
			virtual void Process(JetGameObject &p_object, float p_elapsedTimeMSf) {}
			// ai ONLY
			virtual void Behave(JetGameObject &p_object, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS) {}
			// do this for all obejcts, ai or not
			virtual void ApplyPhysics(JetGameObject &p_jet, float p_gravityPerMS2, float p_elapsedTimeMS) {}
			// do this for all obejcts, ai or not
			virtual void CreateOtherGameObjects(JetGameObject &p_object, JetGameStateData &p_gameStateData) {}
		};

		class MissileBehavior : public BehaviorBase
		{
		public:
			// Overrides
			void Process(JetGameObject &p_missile, float p_elapsedTimeMSf) override;
			void Behave(JetGameObject &p_missile, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS) override;
			void ApplyPhysics(JetGameObject &p_missile, float p_gravityPerMS2, float p_elapsedTimeMS) override;
			void CreateOtherGameObjects(JetGameObject &p_object, JetGameStateData &p_gameStateData) override;
		};

		class BulletBehavior : public BehaviorBase
		{
		public:
			// Overrides
			void Process(JetGameObject &p_missile, float p_elapsedTimeMSf) override;
			void Behave(JetGameObject &p_bullet, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS) override;
			void ApplyPhysics(JetGameObject &p_bullet, float p_gravityPerMS2, float p_elapsedTimeMS) override;
			void CreateOtherGameObjects(JetGameObject &p_object, JetGameStateData &p_gameStateData) override;
		};

		// behavior helper class for a specific vehicle type
		// There are no collision routines here, just decision making routines that ultimately determines what the craft is doing
		// todo: 100ms delay on sudden decisions
		// todo: manager class that decides what to call here from the outside
		class JetBehavior : public BehaviorBase
		{
		public:
			// note: behavior functions don't cause any changes in orientationd or velocity - they alter the intent of the jet - physics is applied later
			// return false if behavior will fail for any reason

			// Overrides
			void Process(JetGameObject &p_jet, float p_elapsedTimeMSf) override;
			void Behave(JetGameObject &p_jet, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameStateData &p_gameStateData, float p_elapsedTimeMSf, float p_userJoytickMoveAmountPerMS, float p_userTwistMoveAmountPerMS) override;
			void ApplyPhysics(JetGameObject &p_jet, float p_gravityPerMS2, float p_elapsedTimeMS) override;
			void CreateOtherGameObjects(JetGameObject &p_object, JetGameStateData &p_gameStateData) override;

		private:
			static void DetermineJoystickThrustAndWeaponUse(JetGameObject &p_jet, TerrainMesh &p_terrain, float p_worldYWaterLevel, JetGameObjectList &p_gameObjectList);
			static bool CheckWeaponObstruction(JetGameObject &p_jet, TerrainMesh &p_terrain);
			static void AttackTarget(JetGameObject &p_jet, bool p_checkObstruction, TerrainMesh &p_terrain);
			static void BehaviorFlyOnPoint(JetGameObject &p_jet, Vector3d &p_point, Vector3d &p_pointVelocity);
			static void BehaviorFlyInDirectionCritical(JetGameObject &p_jet, Vector3d &p_unitDirection, float *p_preferredVelocity = nullptr);
			static void BehaviorFlyInDirectionDogfight(JetGameObject &p_jet, Vector3d &p_unitDirection, float *p_preferredVelocity = nullptr);
			static bool BehaviorFlyThroughPoint(JetGameObject &p_jet, Vector3d &p_point, Vector3d *p_targetDirection, float p_intendedThrust, bool p_allowAlternatePoint = true, bool p_accelerate = false, bool p_decelerate = false, bool p_afterburner = false, bool p_airBrake = false);
			static bool TriggerFlewThroughPoint(JetGameObject &p_jet, Vector3d &p_point);
			static bool BehaviorAvoidCollision(JetGameObject &p_jet, Vector3d &p_point, Vector3d *p_surfaceNormal, Vector3d *p_pointVelocity, float *p_preferredVelocity);
			static bool TriggerWillCrashIntoTerrain(JetGameObject &p_jet, TerrainMesh &p_terrain, float p_worldYWaterLevel, Vector3d &p_surfaceNormal);
			static bool TriggerWillCrashIntoJet(JetGameObject &p_thisJet, JetGameObjectList &p_gameObjectList, Vector3d &p_collisionNormal);
			static bool TriggerIncomingMissile(JetGameObject &p_thisJet, JetGameObjectList &p_gameObjectList, Vector3d &p_collisionNormal);
			static bool TriggerThereIsAnIncomingMissile(JetGameObject &p_jet);
		public:
			// simulate that AI is using joystick like a person
			static void ProcessIntendedJoystickValues(GameJoystickValues &p_joystickValues, float p_elapsedTimeMSf, float p_userJoystickMoveAmountPerMS, float p_userTwistMoveAmountPerMS);
			// rudder and ailerons range from -1.0f to 1.0f
		private:
			static void ApplyFlightPhysics(JetGameObject &p_jet, float p_gravityPerMS2, float p_MS);
		};

		// handled as a static class because both the main game class and the game object factory class needs access to this
		// (although the game object factory class could be static and just contain these, for cleanup later)
		public ref class JetGameObjectBehaviors
		{
		public:
			BehaviorBase *JetBehaviorHandler;
			BehaviorBase *BulletBehaviorHandler;
			BehaviorBase *MissileBehaviorHandler;

			static property JetGameObjectBehaviors^ Instance { JetGameObjectBehaviors^ get() { return %instance; }}
			JetGameObjectBehaviors(const GameContext%) { throw gcnew Exception("singleton cannot be copy constructed"); }
			static JetGameObjectBehaviors instance;

			JetGameObjectBehaviors()
			{
				JetBehaviorHandler = new JetBehavior();
				BulletBehaviorHandler = new BulletBehavior();
				MissileBehaviorHandler = new MissileBehavior();
			}

			void Destroy()
			{
				// note: app will not destroy these - these are app-level structures and the game class doesn't perform app-level deletions.
				// ??
				delete JetBehaviorHandler;
				delete BulletBehaviorHandler;
				delete MissileBehaviorHandler;
			}
		};

		class JetGameObjectFactory
		{
		public:
			static JetGameObjectNode * CreateObject(JetGameObjectEnum p_type, JetGameObjectList &p_gameObjectList, GameObjectIdCounter &p_idCounter, HardpointConfigurationRegistry &p_hardpointRegistry, bool p_addToList = true)
			{
				JetGameObjectNode *newNode = (JetGameObjectNode *)(p_gameObjectList.GetNewNode());
				newNode->data.objectType = p_type;
				newNode->data.Initialize(p_idCounter);

				static FastRandom fastRandom;

				// type specific initializations
				switch (p_type)
				{
				case JetGameObjectEnum::Jet:
					newNode->data.behaviorRef = JetGameObjectBehaviors::Instance->JetBehaviorHandler;
					newNode->data.alphaRender = false; // todo: part of it is alpha (the flames) - will need to submit that to a list to render with alphas later
					newNode->data.health = JetGameValues::JetStartingHealth();
					newNode->data.ResetDamagePulses(); // not a problem here since jets aren't made nearly as often as bullets
					newNode->data.behaviorDecisionDelay = fastRandom.GetRandomInteger(0, JetGameValues::BehaviorDecisionDelayMS());
					// reuse!
					if (newNode->data.hardpointState == nullptr)
					{
						newNode->data.hardpointState = p_hardpointRegistry.CreateObjectHardpointGameState(JetGameObjectEnum::Jet);
					}
					// initialize!
					p_hardpointRegistry.InitializeObjectHardpointGameState(JetGameObjectEnum::Jet, newNode->data.hardpointState);
					break;
				case JetGameObjectEnum::Bullet:
					newNode->data.behaviorRef = JetGameObjectBehaviors::Instance->BulletBehaviorHandler;
					newNode->data.alphaRender = true;
					break;
				case JetGameObjectEnum::Missile:
					newNode->data.behaviorRef = JetGameObjectBehaviors::Instance->MissileBehaviorHandler;
					newNode->data.alphaRender = false; // todo: part of it is alpha (the flames) - will need to submit that to a list to render with alphas later
					// since applyphysics might get called on this missile before it can choose to behave, rudder and leftaileron may be garbled and cause NaNs, so initialize them
					newNode->data.rudder = 0.0f;
					newNode->data.leftAileron = 0.0f;
					break;
				}

				// additional initializations (position, velocity, specific behavior, variable associated with that behavior, etc.) will need to be handled by the caller

				if (p_addToList == true)
					p_gameObjectList.AddNode(newNode);

				return newNode;
			}
		};

		class SurfaceDecal
		{
		public:
			// how the implementation uses all these values is up to the implementation only.  nothing here is standard
			gcroot<GameTexture^> textureRef;
			ModelVertex vertices[4];
			GameColor color;

			Vector3d center;
			float width, height;
			int lifeMS;
			int maxLifeMS; // how long should it last? (helps with calculation of alpha)

			void CalculateVertices()
			{
				// for now, but this is wrong for non-horizontal decals
				vertices[0].vertex = Vector3d(center.x - width / 2.0f, center.y, center.z - height / 2.0f);
				vertices[1].vertex = Vector3d(center.x + width / 2.0f, center.y, center.z - height / 2.0f);
				vertices[2].vertex = Vector3d(center.x + width / 2.0f, center.y, center.z + height / 2.0f);
				vertices[3].vertex = Vector3d(center.x - width / 2.0f, center.y, center.z + height / 2.0f);
			}
		};

		// billboards spin on a vertical axis (y) to face the viewpoint for rendering.
		class AlphaBillboard
		{
		public:
			// how the implementation uses all these values is up to the implementation only.  nothing here is standard
			gcroot<GameTexture^> textureRef;
			GameColor color;
			float widthAdjustPerMS, heightAdjustPerMS;
			int lifeMS;
			Vector3d startCenter;
			Vector3d startVelocity;

			// used to calculate vertices
			float width, height;
			Vector3d center;

			void CalculateVertices(Orient3d &p_orient, ModelVertex *p_vertices)
			{
				p_vertices[0].vertex = p_orient.p + p_orient.l.ScalarMult(width / 2.0f) + p_orient.u.ScalarMult(height / 2.0f);
				p_vertices[1].vertex = p_orient.p - p_orient.l.ScalarMult(width / 2.0f) + p_orient.u.ScalarMult(height / 2.0f);
				p_vertices[2].vertex = p_orient.p - p_orient.l.ScalarMult(width / 2.0f) - p_orient.u.ScalarMult(height / 2.0f);
				p_vertices[3].vertex = p_orient.p + p_orient.l.ScalarMult(width / 2.0f) - p_orient.u.ScalarMult(height / 2.0f);
			}
		};

		class JetGameBubbleSortHelper
		{
		public:
			static bool SmokeParticleOrderInvalid(Particle *data, Particle *nextData)
			{
				return (data->zDepth < nextData->zDepth);
			}
		};

		public ref class JetGame1 : public GameBase
		{
		public:

			TerrainMesh *terrain;
			Orient3d *cameraOrient;
			bool cameraTrackTargetFromUserJet;
			Vector3d *cameraTrackPosition;
			Orient3d *cubeOrient;
			Orient3d *priorStarfieldCameraOrient;
			Orient3d *priorTrackRef;
			Starfield *starField;
			SkyboxColorDome *dome;
			Model3d *lowerSky;
			Model3d *jetEngineFlame;
			Model3d *missileEngineFlame;
			GameTimer *timer;
			GameObjectIdCounter *gameObjectCounter;
			JetGameObject *userControlJetRef;
			JetGameObject *cameraJetRef;
			JetGameObject *cameraTarget;
			WaypointList *waypointList1, *waypointList2, *waypointList3, *waypointList4, *waypointList5;
			HardpointConfigurationRegistry *hardpointConfigurationRegistry;

			GraphicsParticleQueue *smokeParticleQueue;
			bool useParticleQueue;
			GraphicsPolygonQueue *polygonQueue;
			bool usePolygonQueue;

			LinkedList<SurfaceDecal> *waterDecals;
			LinkedList<AlphaBillboard> *waterFountains;

			// game object lists share the same ID counter to avoid confusion with IDs
			JetGameObjectList *gameObjectList; // jets, missiles (can collide with each other)
			JetGameObjectList *bulletList; // bullets (they don't collide with each other, but can collide with jets)

			LinkedList<AlphaTrail> *smokeTrails;
			//LinkedList<Particle> *particles;
			VolumePartition<LinkedList<Particle>> *particlePartition;
			LinkedList<EnergyEffect> *fastEffects; // particles that exist for a very small span of time, no need for partitioning

			Model3d *cube;
			Model3d *jet;
			System::Drawing::Bitmap ^bitmap1;

			LecuyerRandom *random;

			JetGameObject *missileTarget = nullptr;

			float terrainWorldHeightPerColorValue;
			float terrainWaterHeightmapValue;
			float terrainWaterYWorldValue;

			bool showInfo;
			int stereoScopicMode;	// 0 normal, 1 analgyph, 2 splitscreen
			float splitScreenCalibrationValue; // where to place the eye vanishing points in split screen (0-100, 60 is average, 70 is friendly for most but denies those in the 55-65 range the degree of depth perception)
			float defaultSplitScreenCalibrationValue;
			float splitScreenDisplayTimerMS;
			float eyeSeparationInches;

			bool showDeathStar;

			JetGame1(HWND p_hWnd) : GameBase(p_hWnd)
			{
				terrain = nullptr;
				cubeOrient = nullptr;
				cameraTrackTargetFromUserJet = false;
				cameraTrackPosition = nullptr;
				cameraOrient = nullptr;
				priorStarfieldCameraOrient = nullptr;
				priorTrackRef = nullptr;
				cube = nullptr;
				jet = nullptr;
				bitmap1 = nullptr;
				starField = nullptr;
				dome = nullptr;
				lowerSky = nullptr;
				jetEngineFlame = nullptr;
				missileEngineFlame = nullptr;
				timer = nullptr;
				gameObjectList = nullptr;
				bulletList = nullptr;
				smokeTrails = nullptr;
				waterDecals = nullptr;
				gameObjectCounter = nullptr;
				//particles = nullptr;
				particlePartition = nullptr;
				fastEffects = nullptr;
				waypointList1 = nullptr;
				waypointList2 = nullptr;
				waypointList3 = nullptr;
				waypointList4 = nullptr;
				waypointList5 = nullptr;
				hardpointConfigurationRegistry = nullptr;

				smokeParticleQueue = nullptr;
				useParticleQueue = true;
				polygonQueue = nullptr;
				usePolygonQueue = true;

				userControlJetRef = nullptr;
				cameraJetRef = nullptr;
				random = nullptr;
				cameraTarget = nullptr;

				showInfo = true;
				stereoScopicMode = 0;
				defaultSplitScreenCalibrationValue = 60.0f;
				splitScreenCalibrationValue = defaultSplitScreenCalibrationValue;
				splitScreenDisplayTimerMS = 0.0f;
				eyeSeparationInches = 2.75f;

				showDeathStar = false;
			}

			virtual ~JetGame1()
			{
				Destroy();
			}

			void Initialize() override
			{
				DestroyGameData();

				GameContext::Instance->Name = "Test";
				if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
					GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

				// for recording fraps
				//GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->SetVSyncEnabled(false);

				GameContext::Instance->LoggingEnabled = false; // enable when need to debug issues
				GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));
				GameContext::Instance->FileRegistry.RegisterFileResource("DeathStarTransp-SWE_512_512.png"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("water512.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("WaterRipple.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("WaterSplash3.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("TileSmokeTexture.png"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("SmokePuff1.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("muzzleflash_usered_grayscale.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("spark.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("Grass_Meadows2.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("EngineFlameAlpha.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("JetEngineArray.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("MissileEngineArray.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("flare.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("dirt1.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("Grass_Meadows2.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("icetexture.jpg"); // no subfolder for now
				GameContext::Instance->FileRegistry.RegisterFileResource("rocktexture.jpg"); // no subfolder for now
				GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, GameContext::Instance->FileRegistry.GetFile("DeathStarTransp-SWE_512_512.png"));
				GameContext::Instance->TextureRegistry.RegisterTexture("JetBullet", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("lightmap9.bmp"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Water", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, GameContext::Instance->FileRegistry.GetFile("water512.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("WaterRipple", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("WaterRipple.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("WaterSplash", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("WaterSplash3.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("MissileTileSmoke", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("TileSmokeTexture.png"));
				GameContext::Instance->TextureRegistry.RegisterTexture("SmokePuff1", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("SmokePuff1.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("MuzzleFlash1", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("muzzleflash_usered_grayscale.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Spark", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("spark.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("GreenTerrain", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("Grass_Meadows2.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("EngineFlame", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("EngineFlameAlpha.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("JetEngineArray", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("JetEngineArray.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("MissileEngineArray", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("MissileEngineArray.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Flare", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.GetFile("flare.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Dirt1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("dirt1.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Rock1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("rocktexture.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Meadow1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("Grass_Meadows2.jpg"));
				GameContext::Instance->TextureRegistry.RegisterTexture("Ice1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("icetexture.jpg"));

				// pre-load textures to prevent pauses
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("JetBullet"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("Water"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("WaterRipple"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("WaterSplash"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("MissileTileSmoke"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("Spark"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("JetEngineArray"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("MissileEngineArray"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("Dirt1"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("Rock1"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("Meadow1"));
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("Ice1"));

				random = new LecuyerRandom();

				cubeOrient = new Orient3d();
				cubeOrient->LoadIdentity();
				cameraOrient = new Orient3d();
				cameraTrackPosition = new Vector3d();

				priorStarfieldCameraOrient = new Orient3d();
				priorTrackRef = nullptr;

				polygonQueue = new GraphicsPolygonQueue();
				usePolygonQueue = true;

				try
				{
					bitmap1 = gcnew System::Drawing::Bitmap("heightmap1.jpg");
					terrainWorldHeightPerColorValue = 0.5f;
					terrainWaterHeightmapValue = 40.0f;  // color 40 = height of water
					terrainWaterYWorldValue = terrainWorldHeightPerColorValue * terrainWaterHeightmapValue + terrainWorldHeightPerColorValue / 2.0f; // prevent z-fighting somewhat
				}
				catch (System::Exception ^ex)
				{
					Trace::WriteLine(ex->ToString());
				}

				cube = new Model3d();
				cube->MakeCube();
				jet = new Model3d();
				jet->MakeJet(0.50f); // rendering it smaller helps with the external perception of speed

				// make an engine flame, place first polygon at origin so that when scale on z, it only affects the length of the flame
				jetEngineFlame = new Model3d();
				jetEngineFlame->Initialize(2, 6, 9);
				jetEngineFlame->GetVertex(0)->vertex.Set(0.15f, 0.05f, 0.0f);
				jetEngineFlame->GetVertex(1)->vertex.Set(-0.15f, 0.05f, 0.0f);
				jetEngineFlame->GetVertex(2)->vertex.Set(-0.2f, -0.05f, 0.0f);
				jetEngineFlame->GetVertex(3)->vertex.Set(0.2f, -0.05f, 0.0f);
				jetEngineFlame->GetVertex(4)->vertex.Set(0.12f, 0.0f, -1.0f); // scale on z pure to determine length of flame in world size
				jetEngineFlame->GetVertex(5)->vertex.Set(-0.12f, 0.0f, -1.0f); // scale on z pure to determine length of flame in world size
				float shortTrapezoidWidth = 0.3f;
				float longTrapezoidWidth = 0.4f; 
				float flametipWidth = 0.24f * 2.0f; // adjusted for size of texture use at that end
				jetEngineFlame->GetVertex(0)->colorIndex = 0;
				jetEngineFlame->GetVertex(1)->colorIndex = 0;
				jetEngineFlame->GetVertex(2)->colorIndex = 0;
				jetEngineFlame->GetVertex(3)->colorIndex = 0;
				jetEngineFlame->GetVertex(4)->colorIndex = 1; // flame tip
				jetEngineFlame->GetVertex(5)->colorIndex = 1; // flame tip
				jetEngineFlame->GetColor(0)->Set(98, 194, 250, 128); // average flame color for now (will be set in render)
				//jetEngineFlame->GetColor(0)->Set(255, 255, 255, 128); // average flame color for now (will be set in render)
				jetEngineFlame->GetColor(1)->Set(1, 145, 253, 0); // disappearing flame tip
				jetEngineFlame->GetSurface(0)->Initialize(4);
				jetEngineFlame->GetSurface(0)->SetVertexIndex(0, 0);
				jetEngineFlame->GetSurface(0)->SetVertexIndex(1, 1);
				jetEngineFlame->GetSurface(0)->SetVertexIndex(2, 2);
				jetEngineFlame->GetSurface(0)->SetVertexIndex(3, 3);
				jetEngineFlame->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("JetEngineArray"));
				jetEngineFlame->GetSurface(0)->SetVertexTexCoords(0, 0.1f, 0.0f);
				jetEngineFlame->GetSurface(0)->SetVertexTexCoords(1, 0.9f, 0.0f);
				jetEngineFlame->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
				jetEngineFlame->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);
				// inner surfaces - render FIRST!
				jetEngineFlame->GetSurface(1)->Initialize(4);
				jetEngineFlame->GetSurface(1)->SetVertexIndex(0, 1);
				jetEngineFlame->GetSurface(1)->SetVertexIndex(1, 0);
				jetEngineFlame->GetSurface(1)->SetVertexIndex(2, 4);
				jetEngineFlame->GetSurface(1)->SetVertexIndex(3, 5);
				jetEngineFlame->GetSurface(1)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f, shortTrapezoidWidth);
				jetEngineFlame->GetSurface(1)->SetVertexTexCoords(1, 1.0f, 0.0f, shortTrapezoidWidth);
				jetEngineFlame->GetSurface(1)->SetVertexTexCoords(2, 0.75f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(1)->SetVertexTexCoords(3, 0.25f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(2)->Initialize(3);
				jetEngineFlame->GetSurface(2)->SetVertexIndex(0, 2);
				jetEngineFlame->GetSurface(2)->SetVertexIndex(1, 1);
				jetEngineFlame->GetSurface(2)->SetVertexIndex(2, 5);
				jetEngineFlame->GetSurface(2)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(2)->SetVertexTexCoords(0, 0.0f, 0.0f);
				jetEngineFlame->GetSurface(2)->SetVertexTexCoords(1, 1.0f, 0.0f);
				jetEngineFlame->GetSurface(2)->SetVertexTexCoords(2, 0.5f, 0.5f);
				jetEngineFlame->GetSurface(3)->Initialize(4);
				jetEngineFlame->GetSurface(3)->SetVertexIndex(0, 3);
				jetEngineFlame->GetSurface(3)->SetVertexIndex(1, 2);
				jetEngineFlame->GetSurface(3)->SetVertexIndex(2, 5);
				jetEngineFlame->GetSurface(3)->SetVertexIndex(3, 4);
				jetEngineFlame->GetSurface(3)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(3)->SetVertexTexCoords(0, 0.0f, 0.0f, longTrapezoidWidth);
				jetEngineFlame->GetSurface(3)->SetVertexTexCoords(1, 1.0f, 0.0f, longTrapezoidWidth);
				jetEngineFlame->GetSurface(3)->SetVertexTexCoords(2, 0.75f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(3)->SetVertexTexCoords(3, 0.25f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(4)->Initialize(3);
				jetEngineFlame->GetSurface(4)->SetVertexIndex(0, 0);
				jetEngineFlame->GetSurface(4)->SetVertexIndex(1, 3);
				jetEngineFlame->GetSurface(4)->SetVertexIndex(2, 4);
				jetEngineFlame->GetSurface(4)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(4)->SetVertexTexCoords(0, 0.0f, 0.0f);
				jetEngineFlame->GetSurface(4)->SetVertexTexCoords(1, 1.0f, 0.0f);
				jetEngineFlame->GetSurface(4)->SetVertexTexCoords(2, 0.5f, 0.5f);
				// outer surfaces - render LAST!
				jetEngineFlame->GetSurface(5)->Initialize(4);
				jetEngineFlame->GetSurface(5)->SetVertexIndex(0, 0);
				jetEngineFlame->GetSurface(5)->SetVertexIndex(1, 1);
				jetEngineFlame->GetSurface(5)->SetVertexIndex(2, 5);
				jetEngineFlame->GetSurface(5)->SetVertexIndex(3, 4);
				jetEngineFlame->GetSurface(5)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(5)->SetVertexTexCoords(0, 0.0f, 0.0f, shortTrapezoidWidth);
				jetEngineFlame->GetSurface(5)->SetVertexTexCoords(1, 1.0f, 0.0f, shortTrapezoidWidth);
				jetEngineFlame->GetSurface(5)->SetVertexTexCoords(2, 0.75f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(5)->SetVertexTexCoords(3, 0.25f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(6)->Initialize(3);
				jetEngineFlame->GetSurface(6)->SetVertexIndex(0, 1);
				jetEngineFlame->GetSurface(6)->SetVertexIndex(1, 2);
				jetEngineFlame->GetSurface(6)->SetVertexIndex(2, 5);
				jetEngineFlame->GetSurface(6)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(6)->SetVertexTexCoords(0, 0.0f, 0.0f);
				jetEngineFlame->GetSurface(6)->SetVertexTexCoords(1, 1.0f, 0.0f);
				jetEngineFlame->GetSurface(6)->SetVertexTexCoords(2, 0.5f, 0.5f);
				jetEngineFlame->GetSurface(7)->Initialize(4);
				jetEngineFlame->GetSurface(7)->SetVertexIndex(0, 2);
				jetEngineFlame->GetSurface(7)->SetVertexIndex(1, 3);
				jetEngineFlame->GetSurface(7)->SetVertexIndex(2, 4);
				jetEngineFlame->GetSurface(7)->SetVertexIndex(3, 5);
				jetEngineFlame->GetSurface(7)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(7)->SetVertexTexCoords(0, 0.0f, 0.0f, longTrapezoidWidth);
				jetEngineFlame->GetSurface(7)->SetVertexTexCoords(1, 1.0f, 0.0f, longTrapezoidWidth);
				jetEngineFlame->GetSurface(7)->SetVertexTexCoords(2, 0.75f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(7)->SetVertexTexCoords(3, 0.25f, 0.5f, flametipWidth);
				jetEngineFlame->GetSurface(8)->Initialize(3);
				jetEngineFlame->GetSurface(8)->SetVertexIndex(0, 3);
				jetEngineFlame->GetSurface(8)->SetVertexIndex(1, 0);
				jetEngineFlame->GetSurface(8)->SetVertexIndex(2, 4);
				jetEngineFlame->GetSurface(8)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
				jetEngineFlame->GetSurface(8)->SetVertexTexCoords(0, 0.0f, 0.0f);
				jetEngineFlame->GetSurface(8)->SetVertexTexCoords(1, 1.0f, 0.0f);
				jetEngineFlame->GetSurface(8)->SetVertexTexCoords(2, 0.5f, 0.5f);

				// engine flame - engine surface, a slight taper, inside and out surfaces, trapezoids
				missileEngineFlame = new Model3d();
				int missileEngineFlameFaces = 6;
				missileEngineFlame->Initialize(2, missileEngineFlameFaces * 2, missileEngineFlameFaces * 2 + 1);
				float missileEngineFlameAngleIncrement = 360.0f / missileEngineFlameFaces;
				float missileEngineFaceOuterRadius = 0.25f / JetGameValues::FeetPerWorldUnit(); // 3 in. radius
				float missileEngineFaceInnerRadius = 0.20f / JetGameValues::FeetPerWorldUnit();
				// initialize vertices and surfaces in a loop

				missileEngineFlame->GetColor(0)->Set(255, 255, 255, 128); // will be set during render
				missileEngineFlame->GetColor(1)->Set(1, 145, 253, 0); // disappearing flame tip
				missileEngineFlame->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("MissileEngineArray"));
				missileEngineFlame->GetSurface(0)->Initialize(missileEngineFlameFaces);
				for (int i = 0; i < missileEngineFlameFaces; i++)
				{
					Orient3d missileEngineFaceOrient;
					missileEngineFaceOrient.LoadIdentity();
					missileEngineFaceOrient.Rotate(missileEngineFaceOrient.f, -missileEngineFlameAngleIncrement * float(i));

					// calculate vertices
					missileEngineFlame->GetVertex(i)->vertex = Vector3d(missileEngineFaceOrient.l.x, missileEngineFaceOrient.l.y, 0.0f).ScalarMult(missileEngineFaceOuterRadius);
					missileEngineFlame->GetVertex(i + missileEngineFlameFaces)->vertex = Vector3d(missileEngineFaceOrient.l.x, missileEngineFaceOrient.l.y, 0.0f).ScalarMult(missileEngineFaceInnerRadius);
					missileEngineFlame->GetVertex(i + missileEngineFlameFaces)->vertex.z = -1.0f; // so that length scaling works, and face it backwards
					missileEngineFlame->GetVertex(i)->colorIndex = 0;
					missileEngineFlame->GetVertex(i + missileEngineFlameFaces)->colorIndex = 1;

					// establish surface for engine surface
					missileEngineFlame->GetSurface(0)->SetVertexIndex(i, i);
					missileEngineFlame->GetSurface(0)->SetVertexTexCoords(i, 0.5f - missileEngineFaceOrient.l.x * 0.5f, 0.5f - missileEngineFaceOrient.l.y * 0.5f);

					// set up inside trapezoids
					missileEngineFlame->GetSurface(i + 1)->Initialize(4);
					if (i < missileEngineFlameFaces - 1)
					{
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(0, i + 1);
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(1, i);
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(2, i + missileEngineFlameFaces);
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(3, i + missileEngineFlameFaces + 1);
					}
					else
					{
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(0, 0);
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(1, i);
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(2, i + missileEngineFlameFaces);
						missileEngineFlame->GetSurface(i + 1)->SetVertexIndex(3, missileEngineFlameFaces);
					}
					missileEngineFlame->GetSurface(i + 1)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(0, 0.0f, 0.0f, missileEngineFaceOuterRadius);
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(1, 1.0f, 0.0f, missileEngineFaceOuterRadius);
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(2, 0.75f, 0.25f, missileEngineFaceInnerRadius * 2.0f); // 2.0f compensates for the smaller trapezoid texture usage
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(3, 0.25f, 0.25f, missileEngineFaceInnerRadius * 2.0f);

					// set up outside trapezoids
					missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->Initialize(4);
					if (i < missileEngineFlameFaces - 1)
					{
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(0, i);
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(1, i + 1);
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(2, i + missileEngineFlameFaces + 1);
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(3, i + missileEngineFlameFaces);
					}
					else
					{
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(0, i);
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(1, 0);
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(2, missileEngineFlameFaces);
						missileEngineFlame->GetSurface(i + 1 + missileEngineFlameFaces)->SetVertexIndex(3, i + missileEngineFlameFaces);
					}
					missileEngineFlame->GetSurface(i + 1)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("EngineFlame"));
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(0, 0.0f, 0.0f, missileEngineFaceOuterRadius);
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(1, 1.0f, 0.0f, missileEngineFaceOuterRadius);
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(2, 0.75f, 0.25f, missileEngineFaceInnerRadius * 2.0f); // 2.0f compensates for the smaller trapezoid texture usage
					missileEngineFlame->GetSurface(i + 1)->SetVertexTexCoords(3, 0.25f, 0.25f, missileEngineFaceInnerRadius * 2.0f);
				}

				dome = new SkyboxColorDome();
				// do this instead of calling new [] within the initialize call.  Putting a new array[] call in the initialize caused an exception on a second initialization.
				//  was it a problem with the Initialize() method being inline?
				GameColor beforeSunriseColor[10] = { GameColor(213, 125, 51), GameColor(234, 161, 70), GameColor(209, 170, 117),
					GameColor(152, 148, 134), GameColor(109, 125, 134), GameColor(75, 106, 129),
					GameColor(54, 87, 116), GameColor(43, 73, 103), GameColor(43, 73, 103),
					GameColor(43, 73, 103) };
				GameColor earlyMorningColor[10] = { GameColor(246, 212, 161), GameColor(226, 225, 219), GameColor(200, 207, 218),
					GameColor(167, 182, 206), GameColor(142, 159, 185), GameColor(119, 136, 166),
					GameColor(104, 121, 151), GameColor(86, 104, 134), GameColor(67, 86, 116),
					GameColor(60, 77, 106) };
				GameColor morningColor[10] = { GameColor(179, 224, 255), GameColor(152, 214, 255), GameColor(121, 189, 252),
					GameColor(99, 167, 238), GameColor(80, 146, 220), GameColor(66, 128, 201),
					GameColor(57, 115, 188), GameColor(47, 104, 173), GameColor(43, 97, 161),
					GameColor(42, 93, 156) };
				dome->Initialize(9, 40, &morningColor[0]);

				// build lower sky
				lowerSky = new Model3d();
				lowerSky->Initialize(1, 5, 4);

				// match color with lowest color of sky
				//lowerSky->GetColor(0)->Set(dome->colors[0]);
				// give lower sky a distinct horizon
				lowerSky->GetColor(0)->Set(GameColor(50, 79, 100)); // ocean color

				lowerSky->GetVertex(0)->vertex = Vector3d(0,-1, 0);
				lowerSky->GetVertex(1)->vertex = Vector3d(1, 0, 1);
				lowerSky->GetVertex(2)->vertex = Vector3d(-1, 0, 1);
				lowerSky->GetVertex(3)->vertex = Vector3d(-1, 0, -1);
				lowerSky->GetVertex(4)->vertex = Vector3d(1, 0, -1);
				lowerSky->GetVertex(0)->colorIndex = 0;
				lowerSky->GetVertex(1)->colorIndex = 0;
				lowerSky->GetVertex(2)->colorIndex = 0;
				lowerSky->GetVertex(3)->colorIndex = 0;
				lowerSky->GetVertex(4)->colorIndex = 0;

				lowerSky->GetSurface(0)->Initialize(3);
				lowerSky->GetSurface(0)->SetVertexIndex(0, 0);
				lowerSky->GetSurface(0)->SetVertexIndex(1, 1);
				lowerSky->GetSurface(0)->SetVertexIndex(2, 2);
				lowerSky->GetSurface(1)->Initialize(3);
				lowerSky->GetSurface(1)->SetVertexIndex(0, 0);
				lowerSky->GetSurface(1)->SetVertexIndex(1, 2);
				lowerSky->GetSurface(1)->SetVertexIndex(2, 3);
				lowerSky->GetSurface(2)->Initialize(3);
				lowerSky->GetSurface(2)->SetVertexIndex(0, 0);
				lowerSky->GetSurface(2)->SetVertexIndex(1, 3);
				lowerSky->GetSurface(2)->SetVertexIndex(2, 4);
				lowerSky->GetSurface(3)->Initialize(3);
				lowerSky->GetSurface(3)->SetVertexIndex(0, 0);
				lowerSky->GetSurface(3)->SetVertexIndex(1, 4);
				lowerSky->GetSurface(3)->SetVertexIndex(2, 1);

				// set up starfield
				starField = new Starfield();
				starField->Initialize(2000, GameColor(255, 255, 255), GameColor(255, 225, 255), 224, 0.0f); // 0.0f = horizon.  bright so that stars don't darken the skybox
				// ideally, the stars would be rendered on black then the skydome would be rendered in alpha over it, set to give the proper color when alpha'd against black at 50%

				terrain = new TerrainMesh();
				bool useBitmap = true;
				if (useBitmap == false)
				{
					terrain->Initialize(1013, 1007, 0.0f, 0.0f, 1.0f); // irregular size to test region calculation
					terrain->SetHeight(0.0f);
				}
				else
				{
					String ^terrainFileName = "JetGame1Terrain.dat";

					if (terrain->LoadMeshFromFile(terrainFileName, 0.0f, 0.0f, 1.0f) == false)
					{
						terrain->Initialize(bitmap1, 0.0f, 0.0f, 1.0f, terrainWorldHeightPerColorValue);
						terrain->WriteMeshToFile(terrainFileName);
					}

					particlePartition = new VolumePartition<LinkedList<Particle>>(terrain->GetStartX(), 0.0f, terrain->GetStartZ(), terrain->GetEndX(), terrainWorldHeightPerColorValue * 255.0f, terrain->GetEndZ(), 50.0f, terrainWorldHeightPerColorValue * 128.0f, 50.0f);
				}

				terrain->CalculateNormalsAndSegments();
				terrain->CalculateColors(Vector3d(0,1,0), GameColor(128,128,128), GameColor(255,255,255));
				terrain->ObscureColorByYValue(GameColor(50, 79, 100), terrainWaterYWorldValue, 0.075f); // ocean color - obscure the bottom
				//terrain->CalculateLevelOfDetailRegions(37); // irregular region size to test region calculation
				// shaders!
				terrain->CalculateLevelOfDetailRegions(125); // irregular region size to test region calculation
				terrain->CalculateLevelOfDetailHeights();
				terrain->CalculateLevelOfDetailColors();
				terrain->CalculateBoundingVolumes();
				// the 1,2,3,4 are ice, dirt, rock, meadow respectively which will be constants later and can be determined as terrain type for contact points when queried.
				terrain->CreateBlendMap(terrainWorldHeightPerColorValue * 180.0f, 1, terrainWaterYWorldValue + 30.0f / JetGameValues::FeetPerWorldUnit(), 2, 0.5f, 3, 4);

				/*
				Interesting Waypoint list for this heightmap with 1.0f per cell and 0.5f per heightmap value: 
				0 - 0, 300, 0
				1 - 142, 69, 260
				2 - 192, 56, 474
				3 - 438, 26, 620
				4 - 613, 28, 562
				5 - 732, 31, 614
				6 - 896, 31, 659
				7 - 965, 56, 469
				8 - 985, 63, 355
				9 - 915, 106, 316
				10 - 848, 120, 312
				11 - 744, 63, 254
				12 - 666, 23, 135
				13 - 454, 71, 117
				14 - 331, 49, 211
				*/
				waypointList1 = new WaypointList();
				waypointList1->Add(Vector3d(0, 300, 0));
				waypointList1->Add(Vector3d(142, 69, 260));
				waypointList1->Add(Vector3d(192, 56, 474));
				waypointList1->Add(Vector3d(438, 26, 620));
				waypointList1->Add(Vector3d(613, 28, 562));
				waypointList1->Add(Vector3d(732, 31, 614));
				waypointList1->Add(Vector3d(896, 31, 659));
				waypointList1->Add(Vector3d(965, 56, 469));
				waypointList1->Add(Vector3d(985, 63, 355));
				waypointList1->Add(Vector3d(915, 106, 316));
				waypointList1->Add(Vector3d(848, 120, 312));
				waypointList1->Add(Vector3d(744, 63, 254));
				waypointList1->Add(Vector3d(666, 23, 135));
				waypointList1->Add(Vector3d(454, 71, 117));
				waypointList1->Add(Vector3d(331, 49, 211));

				// same list just backwards
				waypointList2 = new WaypointList();
				waypointList2->Add(Vector3d(331, 49, 211));
				waypointList2->Add(Vector3d(454, 71, 117));
				waypointList2->Add(Vector3d(666, 23, 135));
				waypointList2->Add(Vector3d(744, 63, 254));
				waypointList2->Add(Vector3d(848, 120, 312));
				waypointList2->Add(Vector3d(915, 106, 316));
				waypointList2->Add(Vector3d(985, 63, 355));
				waypointList2->Add(Vector3d(965, 56, 469));
				waypointList2->Add(Vector3d(896, 31, 659));
				waypointList2->Add(Vector3d(732, 31, 614));
				waypointList2->Add(Vector3d(613, 28, 562));
				waypointList2->Add(Vector3d(438, 26, 620));
				waypointList2->Add(Vector3d(192, 56, 474));
				waypointList2->Add(Vector3d(142, 69, 260));
				waypointList2->Add(Vector3d(0, 300, 0));


				// waypoint lists that force squadrons to collide
				waypointList3 = new WaypointList();
				waypointList3->Add(Vector3d(200, 200, 200));
				waypointList3->Add(Vector3d(800, 200, 200));
				waypointList3->Add(Vector3d(800, 200, 800));
				waypointList3->Add(Vector3d(200, 200, 800));

				waypointList4 = new WaypointList();
				waypointList4->Add(Vector3d(800, 200, 800));
				waypointList4->Add(Vector3d(800, 200, 200));
				waypointList4->Add(Vector3d(200, 200, 200));
				waypointList4->Add(Vector3d(200, 200, 800));

				waypointList5 = new WaypointList();
				waypointList5->Add(Vector3d(800, 200, 200));
				waypointList5->Add(Vector3d(200, 200, 200));
				waypointList5->Add(Vector3d(800, 200, 200));
				waypointList5->Add(Vector3d(800, 200, 800));

				hardpointConfigurationRegistry = new HardpointConfigurationRegistry();
				hardpointConfigurationRegistry->Add(JetGameObjectEnum::Jet);
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->Add(JetGameObjectEnum::Bullet, 1.0f, 0.002f, 50, JetGameValues::BulletExitSpeedFeetPerMS(), 125, true, 1, false);
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Bullet)->GetFireableWeapon(0).Initialize(2);
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Bullet)->GetFireableWeapon(0).GetHardpointLocation(0).Initialize(Vector3d(0.25f, -0.15f, 0.25f));
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Bullet)->GetFireableWeapon(0).GetHardpointLocation(1).Initialize(Vector3d(-0.25f, -0.15f, 0.25f));
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->Add(JetGameObjectEnum::Missile, 30.0f, 0.001f, 30, JetGameValues::LightAirMissileLaunchSpeed(), 0, false, 2, true);
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Missile)->GetFireableWeapon(0).Initialize(1);
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Missile)->GetFireableWeapon(0).GetHardpointLocation(0).Initialize(Vector3d(0.55f, -0.2f, -0.8f));
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Missile)->GetFireableWeapon(1).Initialize(1);
				hardpointConfigurationRegistry->GetWeaponConfiguration(JetGameObjectEnum::Jet)->GetWeaponEntry(JetGameObjectEnum::Missile)->GetFireableWeapon(1).GetHardpointLocation(0).Initialize(Vector3d(-0.55f, -0.2f, -0.8f));
				hardpointConfigurationRegistry->Evaluate(JetGameObjectEnum::Jet);
				
				cameraOrient->LoadIdentity();
				//cameraOrient->p.Set((terrain->GetStartX() + terrain->GetEndX()) / 2.0f, 200.0f, (terrain->GetStartZ() + terrain->GetEndZ()) / 2.0f - 40.0f); // center of the terrain, 2000 feet in the air, a little behind the jet
				cameraOrient->p.Set(100,200,100); // center of the terrain, 2000 feet in the air, a little behind the jet
				// point it at the origin
				cameraOrient->Rotate(cameraOrient->u, 135.0f);

				timer = new GameTimer();

				GameBase::Initialize(); // call base initialize too.

				timer->ResetGameTime();

				gameObjectList = new JetGameObjectList("Main");
				bulletList = new JetGameObjectList("Bullets");
				gameObjectCounter = new GameObjectIdCounter();
				smokeTrails = new LinkedList<AlphaTrail>("SmokeTrails");
				waterDecals = new LinkedList<SurfaceDecal>("WaterDecals");
				waterFountains = new LinkedList<AlphaBillboard>("WaterFountains");
				//particles = new LinkedList<Particle>();
				fastEffects = new LinkedList<EnergyEffect>("FatEffects");

				// add jets
				JetGameObjectNode *newJet = nullptr;
				JetGameObjectNode *squadLeader = nullptr;

				//////////////////
				// Blue faction
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				squadLeader = newJet;
				newJet->data.faction = 0;
				newJet->data.alliance = 0;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(500, 300, 500); // way on the other side of the map
				// these go together
				newJet->data.behavior = JetBehaviorEnum::FlyWaypoints;
				newJet->data.waypointListRef = waypointList1;
				newJet->data.currentWaypointRef = waypointList1->GetFirstNode()->next; // will automatically get first waypoint
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadRank = 0;
				
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 0;
				newJet->data.alliance = 0;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(20, 300, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->data));
				newJet->data.squadRank = 1;
				
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 0;
				newJet->data.alliance = 0;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(40, 300, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 2;
				
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 0;
				newJet->data.alliance = 0;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(60, 300, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 3;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 0;
				newJet->data.alliance = 0;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(80, 300, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 4;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 0;
				newJet->data.alliance = 0;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(100, 300, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 5;

				///////////////////////
				// Red faction
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				squadLeader = newJet;
				newJet->data.faction = 1;
				newJet->data.alliance = 1;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(500, 400, 500); // way on the other side of the map
				// these go together
				newJet->data.behavior = JetBehaviorEnum::FlyWaypoints;
				newJet->data.waypointListRef = waypointList2;
				newJet->data.currentWaypointRef = waypointList2->GetFirstNode()->next; // pick one to test with
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadRank = 0;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 1;
				newJet->data.alliance = 1;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 300, 20); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->data));
				newJet->data.squadRank = 1;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 1;
				newJet->data.alliance = 1;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 300, 40); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 2;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 1;
				newJet->data.alliance = 1;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 300, 60); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 3;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 1;
				newJet->data.alliance = 1;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 300, 80); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 4;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 1;
				newJet->data.alliance = 1;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 300, 100); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 5;

				///////////////////////
				// White faction
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				squadLeader = newJet;
				newJet->data.faction = 2;
				newJet->data.alliance = 2;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 200, 0);
				// these go together
				newJet->data.behavior = JetBehaviorEnum::FlyWaypoints;
				newJet->data.waypointListRef = waypointList3;
				newJet->data.currentWaypointRef = nullptr;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadRank = 0;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 2;
				newJet->data.alliance = 2;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(40, 220, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->data));
				newJet->data.squadRank = 1;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 2;
				newJet->data.alliance = 2;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(80, 240, 0); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 2;
				missileTarget = &(newJet->data); // have missile go after this one
				
				///////////////////////
				// Purple faction
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				squadLeader = newJet;
				newJet->data.faction = 3;
				newJet->data.alliance = 3;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.Rotate(newJet->data.orient.u, 180.0f);
				newJet->data.orient.p.Set(1000, 200, 1000);
				// these go together
				newJet->data.behavior = JetBehaviorEnum::FlyWaypoints;
				newJet->data.waypointListRef = waypointList4;
				newJet->data.currentWaypointRef = nullptr;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadRank = 0;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 3;
				newJet->data.alliance = 3;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.Rotate(newJet->data.orient.u, 180.0f);
				newJet->data.orient.p.Set(980, 220, 1000); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->data));
				newJet->data.squadRank = 1;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 3;
				newJet->data.alliance = 3;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.Rotate(newJet->data.orient.u, 180.0f);
				newJet->data.orient.p.Set(960, 240, 1000); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 2;				

				///////////////////
				// Death black evil - Crimson Widow
				/*
				The jet came from places unknown.  Its pilot... relentless and utterly evil.  The jet's black and red markings announce its undeniable nature.
				Those that know speak of it only in hushed whispers.  Those brave enough to give it a name know of it only as... the Crimson Widow.  
				No one knows how to appease its deadly appetite.  There are those who know better... some things of this world are just too profane to be reasoned with.
				*/
				//int blackSquadAlliance = 5; // will attack blue
				int blackSquadAlliance = 0; // friendly to blue
				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				squadLeader = newJet;
				newJet->data.faction = 4; // death black evil
				newJet->data.alliance = blackSquadAlliance;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.Rotate(newJet->data.orient.u, 180.0f);
				newJet->data.orient.p.Set(0, 240, 1000); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::PatrolWaypoints;
				newJet->data.waypointListRef = waypointList5;
				newJet->data.currentWaypointRef = nullptr;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 0;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 4; // death black evil
				newJet->data.alliance = blackSquadAlliance;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 240, 1010); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->data));
				newJet->data.squadRank = 1;

				newJet = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Jet, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newJet->data.faction = 4; // death black evil
				newJet->data.alliance = blackSquadAlliance;
				newJet->data.velocity.Set(0, 0, 0);
				newJet->data.orient.LoadIdentity();
				newJet->data.orient.p.Set(0, 240, 1020); // start high enough so it has a chance to recover, and far away from first jet
				// these go together
				newJet->data.behavior = JetBehaviorEnum::StayInFormation;
				newJet->data.squadLeader.Set(&(squadLeader->data));
				newJet->data.squadPartner.Set(&(gameObjectList->GetLastNode()->prev->prev->data));
				newJet->data.squadRank = 2;

				// to debug the first red jet crashing into the cliff every time without interference
				bool killAllBlue = false;
				if (killAllBlue == true)
				{
					LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.faction == 0)
						{
							enumerator.Current()->data.dead = true;
						}
					}
				}

				// test missiles
				JetGameObjectNode *newMissile = nullptr;

				// missile that drops and points downward
				newMissile = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Missile, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newMissile->data.velocity.Set(0, 0, 0);
				newMissile->data.orient.LoadIdentity();
				newMissile->data.orient.p.Set(0, 200, 0);
				newMissile->data.targetRef.Clear();

				// missile that lost power - should gradually fall, pointing the direction it's travelling
				newMissile = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Missile, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newMissile->data.orient.LoadIdentity();
				newMissile->data.orient.Rotate(newMissile->data.orient.l, 45.0f);
				newMissile->data.velocity = newMissile->data.orient.f.ScalarMult(0.088f); // 600 mph
				newMissile->data.orient.p.Set(0, 200, 0);
				newMissile->data.targetRef.Clear();

				newMissile = JetGameObjectFactory::CreateObject(JetGameObjectEnum::Missile, *gameObjectList, *gameObjectCounter, *hardpointConfigurationRegistry);
				newMissile->data.velocity.Set(0, 0, 0);
				newMissile->data.orient.LoadIdentity();
				newMissile->data.orient.Rotate(newMissile->data.orient.u, 180.0f);
				newMissile->data.orient.p.Set(0, 200, 500);
				newMissile->data.targetRef.Set(missileTarget);
				cameraTarget = &(newMissile->data);
			}

			void DestroyGameData()
			{
				if (terrain != nullptr)
				{
					delete terrain;
					terrain = nullptr;
				}
				if (cameraOrient != nullptr)
				{
					delete cameraOrient;
					cameraOrient = nullptr;
				}
				if (cameraTrackPosition != nullptr)
				{
					delete cameraTrackPosition;
					cameraTrackPosition = nullptr;
				}
				if (priorStarfieldCameraOrient != nullptr)
				{
					delete priorStarfieldCameraOrient;
					priorStarfieldCameraOrient = nullptr;
				}
				if (cube != nullptr)
				{
					delete cube;
					cube = nullptr;
				}
				if (jet != nullptr)
				{
					delete jet;
					jet = nullptr;
				}
				if (bitmap1 != nullptr)
				{
					delete bitmap1;
					bitmap1 = nullptr;
				}
				if (dome != nullptr)
				{
					delete dome;
					dome = nullptr;
				}
				if (lowerSky != nullptr)
				{
					delete lowerSky;
					lowerSky = nullptr;
				}
				if (jetEngineFlame != nullptr)
				{
					delete jetEngineFlame;
					jetEngineFlame = nullptr;
				}
				if (missileEngineFlame != nullptr)
				{
					delete missileEngineFlame;
					missileEngineFlame = nullptr;
				}
				if (starField != nullptr)
				{
					delete starField;
					starField = nullptr;
				}
				if (gameObjectList != nullptr)
				{
					delete gameObjectList;
					gameObjectList = nullptr;
				}
				if (bulletList != nullptr)
				{
					delete bulletList;
					bulletList = nullptr;
				}
				if (smokeTrails != nullptr)
				{
					delete smokeTrails;
					smokeTrails = nullptr;
				}
				if (waterDecals != nullptr)
				{
					delete waterDecals;
					waterDecals = nullptr;
				}
				if (waterFountains != nullptr)
				{
					delete waterFountains;
					waterFountains = nullptr;
				}
				//if (particles != nullptr)
				//{
				//	delete particles;
				//	particles = nullptr;
				//}
				if (particlePartition != nullptr)
				{
					delete particlePartition;
					particlePartition = nullptr;
				}
				if (fastEffects != nullptr)
				{
					delete fastEffects;
					fastEffects = nullptr;
				}
				if (gameObjectCounter != nullptr)
				{
					delete gameObjectCounter;
					gameObjectCounter = nullptr;
				}
				if (waypointList1 != nullptr)
				{
					delete waypointList1;
					waypointList1 = nullptr;
				}
				if (waypointList2 != nullptr)
				{
					delete waypointList2;
					waypointList2 = nullptr;
				}
				if (waypointList3 != nullptr)
				{
					delete waypointList3;
					waypointList3 = nullptr;
				}
				if (waypointList4 != nullptr)
				{
					delete waypointList4;
					waypointList4 = nullptr;
				}
				if (waypointList5 != nullptr)
				{
					delete waypointList5;
					waypointList5 = nullptr;
				}
				if (hardpointConfigurationRegistry != nullptr)
				{
					delete hardpointConfigurationRegistry;
					hardpointConfigurationRegistry = nullptr;
				}
				if (smokeParticleQueue != nullptr)
				{
					delete smokeParticleQueue;
					smokeParticleQueue = nullptr;
				}
				if (random != nullptr)
				{
					delete random;
					random = nullptr;
				}
			}

			void Destroy() override
			{
				GameBase::Destroy();
				// get rid of common game-level resources, leave app-level resources alone
				GameApplicationContext::Instance->DestroyGame();
				// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
				//  game instances)
				DestroyGameData();
				GameContext::Instance->DestroyGame();
			}
			bool DoGameLoop() override
			{
				GameContext::Metrics.GameloopTimer.Reset();
				GameContext::Metrics.GameloopTimer.Start();
				joystick->Poll();

				// reset here instead of just after game state updated, because renderer might need it
				timer->ResetElapsedTime();
				timer->Poll();

				////////////////////
				// Interpret controls
				if (HandleControls() == false)
					return false;

				///////////////////////////
				// update game state
				float elapsedTimef = timer->GetElapsedTimeMSFloat();
				int elapsedTime = timer->GetElapsedTimeMS();

				if (elapsedTime > 0)
				{
					UpdateGameState(elapsedTime, elapsedTimef);
				}
				GameContext::Metrics.GameloopTimer.Stop();
				return true;
			}

			bool HandleControls()
			{
				if (keyboardKeys.GetKey(27)->IsPressed())
					return false;

				// apply mouse moves based on last collected movement
				if (mouse.rightButton.down)
				{
					cameraOrient->Rotate(cameraOrient->f, -float(mouse.offsetX));
				}
				if (mouse.leftButton.down)
				{
					// move camera according to mouse and keyboard
					cameraOrient->Rotate(cameraOrient->u, float(mouse.offsetX) / 2.0f);
					cameraOrient->Rotate(cameraOrient->l, -float(mouse.offsetY) / 2.0f);
				}

				if (userControlJetRef != nullptr)
				{
					// joystick
					JoystickValues *jValues = joystick->GetJoystickValues();
					GameJoystickValues *gameJoystick = &(userControlJetRef->joystick);
					if (jValues->valid)
					{
						gameJoystick->SetCurrentX(jValues->primaryX);
						gameJoystick->SetCurrentY(jValues->primaryY);
						gameJoystick->SetCurrentTwist(jValues->twist);
						gameJoystick->SetGunButton(jValues->button1Down);
						gameJoystick->SetSecondaryButton(jValues->button2Down);
					}
					else
					{
						gameJoystick->SetCurrentX(0);
						gameJoystick->SetCurrentY(0);
						gameJoystick->SetCurrentTwist(0);
						gameJoystick->SetGunButton(false);
						gameJoystick->SetSecondaryButton(false);
					}

					// reset control values
					userControlJetRef->accelerate = false;
					userControlJetRef->decelerate = false;
					userControlJetRef->afterburner = false;
					userControlJetRef->airBrake = false;
				}

				if (keyboardKeys.GetKey(17)->IsPressed() == false) // ctrl not pressed
				{
					if (keyboardKeys.GetKey('W')->IsPressed())
					{
						if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
							cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(1.0f);
						else
							cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(0.5f);
					}
					if (keyboardKeys.GetKey('S')->IsPressed())
					{
						if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
							cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(1.0f);
						else
							cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(0.5f);
					}
					if (keyboardKeys.GetKey('A')->IsPressed())
						cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(1.0f);
					if (keyboardKeys.GetKey('D')->IsPressed())
						cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(1.0f);
					if (keyboardKeys.GetKey('Q')->IsPressed())
						cameraOrient->Rotate(cameraOrient->f, 2.0f);
					if (keyboardKeys.GetKey('E')->IsPressed()) // note: E is also handled below so don't clear any click events here
						cameraOrient->Rotate(cameraOrient->f, -2.0f);

					// F2 - switch jet view and control
					if (keyboardKeys.GetKey(113)->clicked)
					{
						// camera attach to lead jet
						if (cameraJetRef == nullptr && userControlJetRef == nullptr)
						{
							//cameraJetRef = &(gameObjectList->GetFirstNode()->data); // jet #1
							//cameraJetRef = &(gameObjectList->GetFirstNode()->next->data); // jet #2
							cameraJetRef = cameraTarget; // jet #7 - first red jet
							cameraTrackTargetFromUserJet = false;
						}
						// switch jet to show/control
						else if (userControlJetRef == nullptr)
						{
							cameraJetRef = nullptr;

							// find 3rd jet
							LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
							int jetCount = 0;
							while (enumerator.MoveNext())
							{
								jetCount++;
								if (jetCount == 3)
								{
									userControlJetRef = &(enumerator.Current()->data);
									// reset damage waggle
									userControlJetRef->damageReticleWaggle = Vector3d(0, 0, 0);
									// and damage pulses
									userControlJetRef->ResetDamagePulses();
									cameraTrackTargetFromUserJet = false;
									break;
								}
							}
						}
						else
						{
							// put camera on the controlled jet and detach
							cameraOrient->p.Set(userControlJetRef->orient.p);
							userControlJetRef = nullptr;
							cameraTrackTargetFromUserJet = false;
							cameraJetRef = nullptr;
						}

						// flag it handled
						keyboardKeys.GetKey(113)->ClearClicked();

						// avoid star lines in render
						priorTrackRef = nullptr;
					}

					// F3 - when controlling a jet, track target
					if (keyboardKeys.GetKey(114)->clicked)
					{
						if (userControlJetRef != nullptr)
						{
							cameraTrackTargetFromUserJet = !cameraTrackTargetFromUserJet;
							// don't let stars make lines
							priorTrackRef = nullptr;
						}

						// flag it handled
						keyboardKeys.GetKey(114)->ClearClicked();
					}

					// P - Pause
					if (keyboardKeys.GetKey('P')->IsClicked())
					{
						if (keyboardKeys.GetKey(17)->IsPressed() == false) // ctrl
						{
							if (timer->IsPaused())
								timer->Unpause();
							else
								timer->Pause();
						}
						else
						{
							useParticleQueue = !useParticleQueue; // ctrl-P
						}

						// flag it handled
						keyboardKeys.GetKey('P')->ClearClicked();
					}

					if (userControlJetRef != nullptr)
					{
						// keys
						if (keyboardKeys.GetKey(220)->clicked) // \ - zero speed
						{
							userControlJetRef->setThrust = 0.0f;
							keyboardKeys.GetKey(220)->ClearClicked();
						}
						if (keyboardKeys.GetKey(8)->clicked) // backspace - max speed
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust();
							keyboardKeys.GetKey(8)->ClearClicked();
						}
						if (keyboardKeys.GetKey(187)->clicked) // +
						{
							userControlJetRef->setThrust += JetGameValues::AdjustThrust();
							if (userControlJetRef->setThrust > JetGameValues::MaxCruiseThrust())
								userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust();
							keyboardKeys.GetKey(187)->ClearClicked();
						}
						if (keyboardKeys.GetKey(189)->clicked) // -
						{
							userControlJetRef->setThrust -= JetGameValues::AdjustThrust();
							if (userControlJetRef->setThrust < 0.0f)
								userControlJetRef->setThrust = 0.0f;
							keyboardKeys.GetKey(189)->ClearClicked();
						}

						if (keyboardKeys.GetKey('1')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.10f;
							keyboardKeys.GetKey('1')->ClearClicked();
						}
						if (keyboardKeys.GetKey('2')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.20f;
							keyboardKeys.GetKey('2')->ClearClicked();
						}
						if (keyboardKeys.GetKey('3')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.30f;
							keyboardKeys.GetKey('3')->ClearClicked();
						}
						if (keyboardKeys.GetKey('4')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.40f;
							keyboardKeys.GetKey('4')->ClearClicked();
						}
						if (keyboardKeys.GetKey('5')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.50f;
							keyboardKeys.GetKey('5')->ClearClicked();
						}
						if (keyboardKeys.GetKey('6')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.60f;
							keyboardKeys.GetKey('6')->ClearClicked();
						}
						if (keyboardKeys.GetKey('7')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.70f;
							keyboardKeys.GetKey('7')->ClearClicked();
						}
						if (keyboardKeys.GetKey('8')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.80f;
							keyboardKeys.GetKey('8')->ClearClicked();
						}
						if (keyboardKeys.GetKey('9')->clicked) // waypoint cruise!
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 0.90f;
							keyboardKeys.GetKey('9')->ClearClicked();
						}
						if (keyboardKeys.GetKey('0')->clicked)
						{
							userControlJetRef->setThrust = JetGameValues::MaxCruiseThrust() * 1.00f; // or max, whatever
							keyboardKeys.GetKey('0')->ClearClicked();
						}

						// handle temporary accel/decel
						if (keyboardKeys.GetKey('Z')->pressed)
						{
							userControlJetRef->airBrake = true; // significant drag
						}
						if (keyboardKeys.GetKey('W')->pressed && keyboardKeys.GetKey('S')->pressed == false)
						{
							userControlJetRef->accelerate = true;
						}
						if (keyboardKeys.GetKey('S')->pressed && keyboardKeys.GetKey('W')->pressed == false)
						{
							userControlJetRef->decelerate = true;
						}
						// override it all with afterburner
						if (keyboardKeys.GetKey(16)->pressed)
						{
							userControlJetRef->afterburner = true;
						}

						// note: applied thrust is calculated in ApplyPhysics

						// targeting
						// target closest enemy jet (for now, not same faction, but later, not same alliance)
						if (keyboardKeys.GetKey('R')->clicked)
						{
							LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
							float closestDistance = 0.0f;
							JetGameObject *closestJet = nullptr;
							while (enumerator.MoveNext())
							{
								if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
									continue;
								if (enumerator.Current()->data.dead == true)
									continue;
								if (enumerator.Current()->data.deleted == true)
									continue;
								if (enumerator.Current()->data.alliance == userControlJetRef->alliance) // only target enemies
									continue;
								if (&(enumerator.Current()->data) == userControlJetRef) // should be covered by condition above, but just in case...
									continue;

								float distance = (enumerator.Current()->data.orient.p - userControlJetRef->orient.p).MagnitudeSquared(); // squared is faster, gets same result
								if (distance < closestDistance || closestJet == nullptr)
								{
									closestDistance = distance;
									closestJet = &(enumerator.Current()->data);
								}
							}
							if (closestJet != nullptr && userControlJetRef->targetRef.Ptr() != closestJet)
							{
								userControlJetRef->targetRef.Set(closestJet);
							}

							keyboardKeys.GetKey('R')->ClearClicked();
						}

						// target closest or next friendly jet (friendly in same faction, not same alliance, for now)
						if (keyboardKeys.GetKey('F')->clicked)
						{
							// if already targeting a friendly, get the NEXT one
							if (userControlJetRef->targetRef.IsValid() && userControlJetRef->targetRef.IsDeleted() == false && ((JetGameObject *)userControlJetRef->targetRef.Ptr())->faction == userControlJetRef->faction && ((JetGameObject *)userControlJetRef->targetRef.Ptr())->dead == false)
							{
								bool valid = false;
								bool done = false;
								LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList); // would create one starting with a node, but we don't have the node info
								while (enumerator.MoveNext())
								{
									if (valid == false)
									{
										if (&(enumerator.Current()->data) == userControlJetRef->targetRef.Ptr())
											valid = true;
										else
											continue;
									}
									else
									{
										if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
											continue;
										if (enumerator.Current()->data.dead == true)
											continue;
										if (enumerator.Current()->data.deleted == true)
											continue;
										if (enumerator.Current()->data.faction != userControlJetRef->faction)
											continue;
										if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
											continue;

										userControlJetRef->targetRef.Set(&(enumerator.Current()->data));
										done = true;
										break;
									}
								}
								if (done == false)
								{
									// didn't find one after the current target.  Try from the beginning
									LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList); // would create one starting with a node, but we don't have the node info
									while (enumerator.MoveNext())
									{
										// stop at current target
										if (&(enumerator.Current()->data) == userControlJetRef->targetRef.Ptr())
											break;
										else
										{
											if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
												continue;
											if (enumerator.Current()->data.dead == true)
												continue;
											if (enumerator.Current()->data.deleted == true)
												continue;
											if (enumerator.Current()->data.faction != userControlJetRef->faction)
												continue;
											if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
												continue;

											userControlJetRef->targetRef.Set(&(enumerator.Current()->data));
											done = true;
											break;
										}
									}
								}
							}
							else
							{
								// target the closest friendly one
								LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
								float closestDistance = 0.0f;
								JetGameObject *closestJet = nullptr;
								while (enumerator.MoveNext())
								{
									if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
										continue;
									if (enumerator.Current()->data.dead == true)
										continue;
									if (enumerator.Current()->data.deleted == true)
										continue;
									if (enumerator.Current()->data.faction != userControlJetRef->faction)
										continue;
									if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
										continue;

									float distance = (enumerator.Current()->data.orient.p - userControlJetRef->orient.p).MagnitudeSquared(); // squared is faster, gets same result
									if (distance < closestDistance || closestJet == nullptr)
									{
										closestDistance = distance;
										closestJet = &(enumerator.Current()->data);
									}
								}
								if (closestJet != nullptr && userControlJetRef->targetRef.Ptr() != closestJet)
								{
									userControlJetRef->targetRef.Set(closestJet);
								}
							}

							keyboardKeys.GetKey('F')->ClearClicked();
						}

						// target closest or next enemy jet targetting this jet (enemy = not same alliance)
						if (keyboardKeys.GetKey('E')->clicked)
						{
							// if already targeting am enemy targeting this jet
							if (userControlJetRef->targetRef.IsValid() && userControlJetRef->targetRef.IsDeleted() == false && ((JetGameObject *)userControlJetRef->targetRef.Ptr())->alliance != userControlJetRef->alliance && ((JetGameObject *)userControlJetRef->targetRef.Ptr())->dead == false && ((JetGameObject *)userControlJetRef->targetRef.Ptr())->targetRef.Ptr() == userControlJetRef)
							{
								bool valid = false;
								bool done = false;
								LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList); // would create one starting with a node, but we don't have the node info
								while (enumerator.MoveNext())
								{
									if (valid == false)
									{
										if (&(enumerator.Current()->data) == userControlJetRef->targetRef.Ptr())
											valid = true;
										else
											continue;
									}
									else
									{
										if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
											continue;
										if (enumerator.Current()->data.dead == true)
											continue;
										if (enumerator.Current()->data.deleted == true)
											continue;
										if (enumerator.Current()->data.alliance == userControlJetRef->alliance)
											continue;
										if (enumerator.Current()->data.targetRef.Ptr() != userControlJetRef)
											continue;
										if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
											continue;

										userControlJetRef->targetRef.Set(&(enumerator.Current()->data));
										done = true;
										break;
									}
								}
								if (done == false)
								{
									// didn't find one after the current target.  Try from the beginning
									LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList); // would create one starting with a node, but we don't have the node info
									while (enumerator.MoveNext())
									{
										// stop at current target
										if (&(enumerator.Current()->data) == userControlJetRef->targetRef.Ptr())
											break;
										else
										{
											if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
												continue;
											if (enumerator.Current()->data.dead == true)
												continue;
											if (enumerator.Current()->data.deleted == true)
												continue;
											if (enumerator.Current()->data.alliance == userControlJetRef->alliance)
												continue;
											if (enumerator.Current()->data.targetRef.Ptr() != userControlJetRef)
												continue;
											if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
												continue;

											userControlJetRef->targetRef.Set(&(enumerator.Current()->data));
											done = true;
											break;
										}
									}
								}
							}
							else
							{
								// target the closest enemy one targeting this jet
								LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
								float closestDistance = 0.0f;
								JetGameObject *closestJet = nullptr;
								while (enumerator.MoveNext())
								{
									if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
										continue;
									if (enumerator.Current()->data.dead == true)
										continue;
									if (enumerator.Current()->data.deleted == true)
										continue;
									if (enumerator.Current()->data.alliance == userControlJetRef->alliance)
										continue;
									if (enumerator.Current()->data.targetRef.Ptr() != userControlJetRef)
										continue;
									if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
										continue;

									float distance = (enumerator.Current()->data.orient.p - userControlJetRef->orient.p).MagnitudeSquared(); // squared is faster, gets same result
									if (distance < closestDistance || closestJet == nullptr)
									{
										closestDistance = distance;
										closestJet = &(enumerator.Current()->data);
									}
								}
								if (closestJet != nullptr && userControlJetRef->targetRef.Ptr() != closestJet)
								{
									userControlJetRef->targetRef.Set(closestJet);
								}
							}

							keyboardKeys.GetKey('E')->ClearClicked();
						}

						// target most centered jet in the reticle
						if (keyboardKeys.GetKey('G')->clicked)
						{
							// target closest craft in reticle regardless of faction
							// x and y offset / distanceZ < some tolerance
							float maxOffsetDistance = 0.04f;
							float maxOffsetDistanceSq = maxOffsetDistance * maxOffsetDistance;
							JetGameObject *mostCenteredJet = nullptr;
							float closestDistanceSq = 0.0f;
							LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList); // would create one starting with a node, but we don't have the node info
							while (enumerator.MoveNext())
							{
								if (enumerator.Current()->data.objectType != JetGameObjectEnum::Jet)
									continue;
								if (enumerator.Current()->data.dead == true)
									continue;
								if (enumerator.Current()->data.deleted == true)
									continue;
								if (&(enumerator.Current()->data) == userControlJetRef) // don't target self!  ever!
									continue;

								Vector3d offset = enumerator.Current()->data.orient.p - userControlJetRef->orient.p;
								float fOffset = offset * userControlJetRef->orient.f;
								if (fOffset > 0.00001f)
								{
									// get intersection at z 1.0f
									float lOffset = (offset * userControlJetRef->orient.l) / fOffset;
									float uOffset = (offset * userControlJetRef->orient.u) / fOffset;
									float distanceSq = lOffset * lOffset + uOffset * uOffset;
									if (distanceSq <= maxOffsetDistanceSq)
									{
										if (mostCenteredJet == nullptr || distanceSq < closestDistanceSq)
										{
											closestDistanceSq = distanceSq;
											mostCenteredJet = &(enumerator.Current()->data);
										}
									}
								}
							}

							if (mostCenteredJet != nullptr)
								userControlJetRef->targetRef.Set(mostCenteredJet);

							keyboardKeys.GetKey('G')->ClearClicked();
						}
					}

					if (keyboardKeys.GetKey('I')->IsClicked())
					{
						showInfo = !showInfo;
						keyboardKeys.GetKey('I')->ClearClicked();
					}

					if (keyboardKeys.GetKey(13)->IsClicked())
					{
						stereoScopicMode++;
						if (stereoScopicMode > 3)
							stereoScopicMode = 0;
						if (stereoScopicMode > 2)
						{
							splitScreenCalibrationValue = defaultSplitScreenCalibrationValue; // start with average eye separation (70 would be friendlier to everyone)
							eyeSeparationInches = 2.75f;
						}

						keyboardKeys.GetKey(13)->ClearClicked();
					}
				}

				// ctrl pressed
				if (keyboardKeys.GetKey(17)->IsPressed())
				{
					if (keyboardKeys.GetKey('Z')->IsClicked())
					{
						// cycle split screen calibration
						if (splitScreenCalibrationValue == 50.0f)
							splitScreenCalibrationValue = 55.0f;
						else if (splitScreenCalibrationValue == 55.0f)
							splitScreenCalibrationValue = 60.0f;
						else if (splitScreenCalibrationValue == 60.0f)
							splitScreenCalibrationValue = 65.0f;
						else if (splitScreenCalibrationValue == 65.0f)
							splitScreenCalibrationValue = 70.0f;
						else if (splitScreenCalibrationValue == 70.0f)
							splitScreenCalibrationValue = 75.0f;
						else if (splitScreenCalibrationValue == 75.0f)
							splitScreenCalibrationValue = 80.0f;
						else if (splitScreenCalibrationValue == 80.0f)
							splitScreenCalibrationValue = 85.0f;
						else if (splitScreenCalibrationValue == 85.0f)
							splitScreenCalibrationValue = 90.0f;
						else if (splitScreenCalibrationValue == 90.0f)
							splitScreenCalibrationValue = 95.0f;
						else if (splitScreenCalibrationValue == 95.0f)
							splitScreenCalibrationValue = 100.0f;
						else if (splitScreenCalibrationValue == 100.0f)
							splitScreenCalibrationValue = 50.0f;

						splitScreenDisplayTimerMS = 2000.0f;

						keyboardKeys.GetKey('Z')->ClearClicked();
					}
					if (keyboardKeys.GetKey('X')->IsClicked())
					{
						// cycle split screen calibration
						if (eyeSeparationInches == 2.75f)
							eyeSeparationInches = 27.5f;
						else if (eyeSeparationInches == 27.5f)
							eyeSeparationInches = 2.75f;

						keyboardKeys.GetKey('X')->ClearClicked();
					}
					if (keyboardKeys.GetKey('D')->IsClicked())
					{
						showDeathStar = !showDeathStar;
					}
					// ctrl V - vsync
					if (keyboardKeys.GetKey('V')->IsClicked())
					{
						if (GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->VSyncIsEnabled() == true)
							GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->SetVSyncEnabled(false);
						else
							GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->SetVSyncEnabled(true);

						// flag it handled
						keyboardKeys.GetKey('V')->ClearClicked();
					}

					// ctrl t - smoke trails native
					if (keyboardKeys.GetKey('T')->IsClicked())
					{
						usePolygonQueue = !usePolygonQueue;

						// flag it handled
						keyboardKeys.GetKey('T')->ClearClicked();
					}
				}

				mouse.ZeroOffsets();

				return true;
			}

			void UpdateGameState(int elapsedTime, float elapsedTimef)
			{
				JetGameStateData gameStateData;

				gameStateData.mainGameObjectListRef = gameObjectList;
				gameStateData.bulletListRef = bulletList;
				gameStateData.gameObjectIdCounterRef = gameObjectCounter;
				gameStateData.particlePartitionRef = particlePartition;
				gameStateData.smokeTrailsRef = smokeTrails;
				gameStateData.fastEffectsRef = fastEffects;
				gameStateData.hardpointConfigurationRegistryRef = hardpointConfigurationRegistry;

				// establish joystick values and thrust values to apply, maintain timers
				// placing behave here gives no object an advantage over any other due to placement in the object list - unless one object's decisions is based on what values Behave() sets on the object - 
				//   best not to do that.
				LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
				while (enumerator.MoveNext())
				{
					enumerator.Current()->data.behaviorRef->Process(enumerator.Current()->data, elapsedTimef);
					if (userControlJetRef != &(enumerator.Current()->data) && enumerator.Current()->data.deleted == false)
					{
						enumerator.Current()->data.behaviorRef->Behave(enumerator.Current()->data, *terrain, terrainWaterYWorldValue, gameStateData, elapsedTimef, JetGameValues::AIJoystickPrimaryMovePerMS(), JetGameValues::AIJoystickTwistMovePerMS());
					}
				}

				enumerator = LinkedListEnumerator<JetGameObject>(*bulletList);
				while (enumerator.MoveNext())
				{
					enumerator.Current()->data.behaviorRef->Process(enumerator.Current()->data, elapsedTimef);
					if (userControlJetRef != &(enumerator.Current()->data) && enumerator.Current()->data.deleted == false)
					{
						enumerator.Current()->data.behaviorRef->Behave(enumerator.Current()->data, *terrain, terrainWaterYWorldValue, gameStateData, elapsedTimef, JetGameValues::AIJoystickPrimaryMovePerMS(), JetGameValues::AIJoystickTwistMovePerMS());
					}
				}

				// apply physics and joystick controls! (worry about accurately and effectively applying 10ms chunks across ticks later)
				float elapsedTimeIncrement = 5.0f;
				while (elapsedTimef > elapsedTimeIncrement)
				{
					// todo: move this to another method so we aren't duplicating code (see block after loop)
					LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						enumerator.Current()->data.behaviorRef->ApplyPhysics(enumerator.Current()->data, JetGameValues::GravityAccelerationPerMSSquared(), elapsedTimeIncrement);
						// move the object (could be done in physics)
						enumerator.Current()->data.priorPosition = enumerator.Current()->data.orient.p;
						enumerator.Current()->data.priorPositionValid = true;
						enumerator.Current()->data.orient.p = enumerator.Current()->data.orient.p + enumerator.Current()->data.velocity.ScalarMult(elapsedTimeIncrement);
						enumerator.Current()->data.behaviorRef->CreateOtherGameObjects(enumerator.Current()->data, gameStateData);
					}
					enumerator = LinkedListEnumerator<JetGameObject>(*bulletList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						enumerator.Current()->data.behaviorRef->ApplyPhysics(enumerator.Current()->data, JetGameValues::GravityAccelerationPerMSSquared(), elapsedTimeIncrement);
						// move the object (could be done in physics)
						enumerator.Current()->data.priorPosition = enumerator.Current()->data.orient.p;
						enumerator.Current()->data.priorPositionValid = true;
						enumerator.Current()->data.orient.p = enumerator.Current()->data.orient.p + enumerator.Current()->data.velocity.ScalarMult(elapsedTimeIncrement);
						enumerator.Current()->data.behaviorRef->CreateOtherGameObjects(enumerator.Current()->data, gameStateData);
					}

					// after all moved, check for collisions
					enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						if (enumerator.Current()->data.priorPositionValid == true) // should be true for all right now
						{
							TestForCollisions(enumerator.Current(), gameStateData);
						}
					}
					enumerator = LinkedListEnumerator<JetGameObject>(*bulletList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						if (enumerator.Current()->data.priorPositionValid == true) // should be true for all right now
						{
							TestForCollisions(enumerator.Current(), gameStateData);
						}
					}

					elapsedTimef -= elapsedTimeIncrement;
				}
				if (elapsedTimef > 0.0)
				{
					// apply one last time for rest of elapsedTime
					LinkedListEnumerator<JetGameObject> enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						enumerator.Current()->data.behaviorRef->ApplyPhysics(enumerator.Current()->data, JetGameValues::GravityAccelerationPerMSSquared(), elapsedTimef);
						// move the object (could be done in physics)
						enumerator.Current()->data.priorPosition = enumerator.Current()->data.orient.p;
						enumerator.Current()->data.priorPositionValid = true;
						enumerator.Current()->data.orient.p = enumerator.Current()->data.orient.p + enumerator.Current()->data.velocity.ScalarMult(elapsedTimef);
						enumerator.Current()->data.behaviorRef->CreateOtherGameObjects(enumerator.Current()->data, gameStateData);
					}
					enumerator = LinkedListEnumerator<JetGameObject>(*bulletList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						enumerator.Current()->data.behaviorRef->ApplyPhysics(enumerator.Current()->data, JetGameValues::GravityAccelerationPerMSSquared(), elapsedTimef);
						// move the object (could be done in physics)
						enumerator.Current()->data.priorPosition = enumerator.Current()->data.orient.p;
						enumerator.Current()->data.priorPositionValid = true;
						enumerator.Current()->data.orient.p = enumerator.Current()->data.orient.p + enumerator.Current()->data.velocity.ScalarMult(elapsedTimef);
						enumerator.Current()->data.behaviorRef->CreateOtherGameObjects(enumerator.Current()->data, gameStateData);
					}

					// after all moved, check for collisions
					enumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						if (enumerator.Current()->data.priorPositionValid == true) // should be true for all right now
						{
							TestForCollisions(enumerator.Current(), gameStateData);
						}
					}
					enumerator = LinkedListEnumerator<JetGameObject>(*bulletList);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.deleted == true)
							continue;

						if (enumerator.Current()->data.priorPositionValid == true) // should be true for all right now
						{
							TestForCollisions(enumerator.Current(), gameStateData);
						}
					}
				}

				// get rid of deleted things
				// todo: make a safe delete as part of the enumerator so that movenext works and current() is invalidated by a delete! (will probably need to store a reference to the game object list)
				LinkedListNode<JetGameObject> *node = gameObjectList->GetFirstNode();
				if (node != nullptr)
				{
					while (node != &(gameObjectList->footer))
					{
						if ((node->data.objectType != JetGameObjectEnum::Jet) && (node->data.deleted == true))
						{
							LinkedListNode<JetGameObject> *tempNode = node->prev;
							gameObjectList->DeleteNode(node);
							node = tempNode;
						}

						node = node->next;
					}
				}
				node = bulletList->GetFirstNode();
				if (node != nullptr)
				{
					while (node != &(bulletList->footer))
					{
						if ((node->data.objectType != JetGameObjectEnum::Jet) && (node->data.deleted == true))
						{
							LinkedListNode<JetGameObject> *tempNode = node->prev;
							bulletList->DeleteNode(node);
							node = tempNode;
						}

						node = node->next;
					}
				}
			}

			void TestForCollisions(LinkedListNode<JetGameObject> *p_objectNode, JetGameStateData &p_gameStateData)
			{
				switch (p_objectNode->data.objectType)
				{
					// todo: move to jet behavior class?  or keep out here?
					case JetGameObjectEnum::Jet:
						{
							JetGameObject *jet = &(p_objectNode->data);
							if (jet->priorPositionValid == false)
								return;

							// check for collisions and respond accordingly
							float terrainCollisionT;
							Vector3d collisionPosition;
							Vector3d collisionNormal;
							// todo: get earliest collision, might have collided with a jet first
							if (terrain->SphereCollision(jet->priorPosition, jet->orient.p - jet->priorPosition, JetGameValues::JetFuselageCollisionRadius(), terrainCollisionT, collisionPosition, collisionNormal) == true)
							{
								// see if bullet hit the water first
								Vector3d fullMove = jet->orient.p - jet->priorPosition;
								float waterCollisionT;
								if (MathUtilities::SpherePlaneCollision(jet->priorPosition, fullMove, JetGameValues::JetFuselageCollisionRadius(), Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0), waterCollisionT) == false)
									waterCollisionT = 10.0f;

								if (waterCollisionT <= terrainCollisionT)
								{
									Vector3d collisionPoint = jet->priorPosition + fullMove.ScalarMult(waterCollisionT);
									collisionPoint.y = terrainWaterYWorldValue; // for accuracy
									if (collisionPoint.x >= terrain->GetStartX() && collisionPoint.x <= terrain->GetEndX() && collisionPoint.z >= terrain->GetStartZ() && collisionPoint.z <= terrain->GetEndZ())
									{
										MissileHitWater(p_objectNode->data, collisionPoint, p_gameStateData);
									}
								}
								else
								{
									// hit terrain
									jet->orient.p = jet->priorPosition + (jet->orient.p - jet->priorPosition).ScalarMult(terrainCollisionT); // for now until we come up with a better response
									JetHitTerrain(*jet, p_gameStateData);
								}

							}
							else
							{
								// if any collisions happened between two jets, delete both jets
								// only check jet AFTER the current one so we are checking half as many times (which is enough)
								LinkedListEnumerator<JetGameObject> enumerator2 = LinkedListEnumerator<JetGameObject>(*(p_gameStateData.mainGameObjectListRef), p_objectNode);
								bool valid = false;
								while (enumerator2.MoveNext())
								{
									if (enumerator2.Current()->data.deleted == true)
										continue;
									if (enumerator2.Current()->data.priorPositionValid == false)
										continue;

									float collisionT = 0.0;

									switch (enumerator2.Current()->data.objectType)
									{
									case JetGameObjectEnum::Jet:
									{
										// todo: get earliest collision
										Vector3d fullMove = jet->orient.p - jet->priorPosition - (enumerator2.Current()->data.orient.p - enumerator2.Current()->data.priorPosition);
										if (MathUtilities::SphereSphereCollision(jet->priorPosition, fullMove, JetGameValues::JetFuselageCollisionRadius(), enumerator2.Current()->data.priorPosition, JetGameValues::JetFuselageCollisionRadius(), collisionT) == true)
										{
											JetHitJet(enumerator2.Current()->data, *jet, collisionT, p_gameStateData);
										}
									}
										break;
									case JetGameObjectEnum::Missile:
									{
										// missile can't hit parent unless it comes back on a return trip
										// avoids collision on launch
										if (enumerator2.Current()->data.canCollideWithSource == false && enumerator2.Current()->data.sourceRef.Ptr() == jet)
											continue;

										// todo: get earliest collision
										Vector3d fullMove = jet->orient.p - jet->priorPosition - (enumerator2.Current()->data.orient.p - enumerator2.Current()->data.priorPosition);
										if (MathUtilities::SphereSphereCollision(jet->priorPosition, fullMove, JetGameValues::JetFuselageCollisionRadius(), enumerator2.Current()->data.priorPosition, JetGameValues::MissileCollisionRadius(), collisionT) == true)
										{
											// advance jet to its position
											// delete jet
											MissileHitJet(enumerator2.Current()->data, *jet, collisionT, p_gameStateData);
										}
									}
										break;
									//case JetGameObjectEnum::Bullet:
									//{
									//	// todo: get earliest collision
									//	Vector3d fullMove = jet->orient.p - jet->priorPosition - (enumerator2.Current()->data.orient.p - enumerator2.Current()->data.priorPosition);
									//	if (MathUtilities::SpherePointCollision(jet->priorPosition, fullMove, JetGameValues::JetFuselageCollisionRadius(), enumerator2.Current()->data.priorPosition, collisionT) == true)
									//	{
									//		BulletHitJet(enumerator2.Current()->data, *jet, p_gameObjectList);
									//	}
									//}
									break;
									}
								}
							}

							if (jet->deleted == false)
							{
								// if jet still exists, check if it hit the water
								Vector3d fullMove = jet->orient.p - jet->priorPosition;
								float collisionT;
								bool deleted = false;
								if (MathUtilities::SpherePlaneCollision(jet->priorPosition, fullMove, JetGameValues::JetFuselageCollisionRadius(), Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0), collisionT) == true)
								{
									Vector3d collisionPoint = jet->priorPosition + fullMove.ScalarMult(collisionT);
									collisionPoint.y = terrainWaterYWorldValue; // for accuracy
									if (collisionPoint.x >= terrain->GetStartX() && collisionPoint.x <= terrain->GetEndX() && collisionPoint.z >= terrain->GetStartZ() && collisionPoint.z <= terrain->GetEndZ())
									{
										JetHitWater(p_objectNode->data, collisionPoint, p_gameStateData);
									}
								}
							}

							if (jet->deleted == false)
							{
								// if jet still exists, see if either of its wingtips skimmed the water!
								JetSkimmingWater(p_objectNode->data, p_gameStateData);
							}
						}
						break;
					case JetGameObjectEnum::Missile:
						{
							JetGameObject *missile = &(p_objectNode->data);
							if (missile->priorPositionValid == false)
								return;

							// check for collisions and respond accordingly
							float terrainCollisionT;
							Vector3d collisionPosition;
							Vector3d collisionNormal;
							// todo: get earliest collision, might have collided with jet first
							if (terrain->SphereCollision(missile->priorPosition, missile->orient.p - missile->priorPosition, JetGameValues::MissileCollisionRadius(), terrainCollisionT, collisionPosition, collisionNormal) == true)
							{
								// see if bullet hit the water first
								Vector3d fullMove = missile->orient.p - missile->priorPosition;
								float waterCollisionT;
								if (MathUtilities::SpherePlaneCollision(missile->priorPosition, fullMove, JetGameValues::MissileCollisionRadius(), Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0), waterCollisionT) == false)
									waterCollisionT = 10.0f;

								if (waterCollisionT <= terrainCollisionT)
								{
									Vector3d collisionPoint = missile->priorPosition + fullMove.ScalarMult(waterCollisionT);
									collisionPoint.y = terrainWaterYWorldValue; // for accuracy
									if (collisionPoint.x >= terrain->GetStartX() && collisionPoint.x <= terrain->GetEndX() && collisionPoint.z >= terrain->GetStartZ() && collisionPoint.z <= terrain->GetEndZ())
									{
										MissileHitWater(p_objectNode->data, collisionPoint, p_gameStateData);
									}
								}
								else
								{
									// hit terrain
									Vector3d collisionPoint = missile->priorPosition + (missile->orient.p - missile->priorPosition).ScalarMult(terrainCollisionT); // for now until we come up with a better response
									MissileHitTerrain(*missile, collisionPoint, p_gameStateData);
								}

							}
							else
							{
								// check for collision with jet
								// only check jet AFTER the current one so we are checking half as many times (which is enough)
								LinkedListEnumerator<JetGameObject> enumerator2 = LinkedListEnumerator<JetGameObject>(*(p_gameStateData.mainGameObjectListRef), p_objectNode);
								float collisionT = 0.0f;
								float noCollision = 10.0f;
								float earliestCollisionT = noCollision;
								JetGameObject *jetStruck = nullptr;
								while (enumerator2.MoveNext())
								{
									if (enumerator2.Current()->data.objectType != JetGameObjectEnum::Jet)
										continue;
									// missile can't hit parent unless it comes back on a return trip
									// avoids collision on launch
									if (missile->canCollideWithSource == false && missile->sourceRef.Ptr() == &(enumerator2.Current()->data))
										continue;
									if (enumerator2.Current()->data.priorPositionValid == false)
										continue;

									Vector3d fullMove = missile->orient.p - missile->priorPosition - (enumerator2.Current()->data.orient.p - enumerator2.Current()->data.priorPosition);
									if (MathUtilities::SphereSphereCollision(missile->priorPosition, fullMove, JetGameValues::JetFuselageCollisionRadius(), enumerator2.Current()->data.priorPosition, JetGameValues::MissileCollisionRadius(), collisionT) == true)
									{
										if (collisionT < earliestCollisionT)
										{
											earliestCollisionT = collisionT;
											jetStruck = &(enumerator2.Current()->data);
										}
									}
								}

								if (earliestCollisionT != noCollision)
								{
									MissileHitJet(*missile, *jetStruck, earliestCollisionT, p_gameStateData);
								}
								else
								{
									// see if missile hit the water
									Vector3d fullMove = missile->orient.p - missile->priorPosition;
									float collisionT;
									bool deleted = false;
									if (MathUtilities::SpherePlaneCollision(missile->priorPosition, fullMove, JetGameValues::MissileCollisionRadius(), Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0), collisionT) == true)
									{
										Vector3d collisionPoint = missile->priorPosition + fullMove.ScalarMult(collisionT);
										collisionPoint.y = terrainWaterYWorldValue; // for accuracy
										if (collisionPoint.x >= terrain->GetStartX() && collisionPoint.x <= terrain->GetEndX() && collisionPoint.z >= terrain->GetStartZ() && collisionPoint.z <= terrain->GetEndZ())
										{
											MissileHitWater(p_objectNode->data, collisionPoint, p_gameStateData);
											deleted = true;
										}
									}

									// finally, if bullet went off the bottom of the world, get rid of it
									if (deleted == false)
									{
										if (missile->orient.p.y < 0.0f)
										{
											// left playfield
											DeleteMissile(p_objectNode->data, p_gameStateData);
										}
									}
								}
							}
						}
						break;
					case JetGameObjectEnum::Bullet:
					{
						JetGameObject *bullet = &(p_objectNode->data);
						if (bullet->priorPositionValid == false)
							return;

						float terrainCollisionT;
						Vector3d collisionPosition;
						Vector3d collisionNormal;
						Vector3d fullMove = bullet->orient.p - bullet->priorPosition;
						if (terrain->SphereCollision(bullet->priorPosition, fullMove, 0.0f, terrainCollisionT, collisionPosition, collisionNormal) == true)
						{
							// see if bullet hit the water first
							Vector3d fullMove = bullet->orient.p - bullet->priorPosition;
							float waterCollisionT;
							if (MathUtilities::SpherePlaneCollision(bullet->priorPosition, fullMove, 0.0f, Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0), waterCollisionT) == false)
								waterCollisionT = 10.0f;

							if (waterCollisionT <= terrainCollisionT)
							{
								Vector3d collisionPoint = bullet->priorPosition + fullMove.ScalarMult(waterCollisionT);
								collisionPoint.y = terrainWaterYWorldValue; // for accuracy
								if (collisionPoint.x >= terrain->GetStartX() && collisionPoint.x <= terrain->GetEndX() && collisionPoint.z >= terrain->GetStartZ() && collisionPoint.z <= terrain->GetEndZ())
								{
									BulletHitWater(p_objectNode->data, collisionPoint);
								}
							}
							else
							{
								Vector3d collisionPoint = bullet->priorPosition + fullMove.ScalarMult(terrainCollisionT);
								Vector3d moveUnit = fullMove;
								moveUnit.Normalize();
								collisionPoint = collisionPoint - moveUnit.ScalarMult(0.2f); // move it back 2 feet for the bullet strike
								// hit terrain
								BulletHitTerrain(*bullet, collisionPoint, p_gameStateData);
							}
						}
						else
						{
							// check for collisions and respond accordingly
							// can only collide with jets and missiles in main list, not each other in bulletList
							LinkedListEnumerator<JetGameObject> enumerator2 = LinkedListEnumerator<JetGameObject>(*(p_gameStateData.mainGameObjectListRef)); // check all jets in main list only
							bool valid = false;
							float noCollision = 10.0f;
							float earliestCollisionT = noCollision;
							JetGameObject *jetStruck = nullptr;
							while (enumerator2.MoveNext())
							{
								if (enumerator2.Current()->data.deleted == true)
									continue;
								if (enumerator2.Current()->data.objectType != JetGameObjectEnum::Jet)
									continue;
								if (enumerator2.Current()->data.priorPositionValid == false)
									continue;

								Vector3d fullMove = bullet->orient.p - bullet->priorPosition - (enumerator2.Current()->data.orient.p - enumerator2.Current()->data.priorPosition);
								float collisionT = 0.0f;
								if (MathUtilities::SphereSphereCollision(bullet->priorPosition, fullMove, 0.0f, enumerator2.Current()->data.priorPosition, JetGameValues::JetFuselageCollisionRadius(), collisionT) == true)
								{
									if (collisionT < earliestCollisionT)
									{
										earliestCollisionT = collisionT;
										jetStruck = &(enumerator2.Current()->data);
									}
								}
							}

							if (earliestCollisionT != noCollision)
							{
								Vector3d bulletPosition = bullet->priorPosition + (bullet->orient.p - bullet->priorPosition).ScalarMult(earliestCollisionT);
								Vector3d jetPosition = jetStruck->priorPosition + (jetStruck->orient.p - jetStruck->priorPosition).ScalarMult(earliestCollisionT);
								BulletHitJet(*bullet, *jetStruck, p_gameStateData, jetPosition - bulletPosition);
							}
							else
							{
								// see if bullet hit the water
								Vector3d fullMove = bullet->orient.p - bullet->priorPosition;
								float collisionT;
								bool deleted = false;
								if (MathUtilities::SpherePlaneCollision(bullet->priorPosition, fullMove, 0.0f, Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0), collisionT) == true)
								{
									Vector3d collisionPoint = bullet->priorPosition + fullMove.ScalarMult(collisionT);
									collisionPoint.y = terrainWaterYWorldValue; // for accuracy
									if (collisionPoint.x >= terrain->GetStartX() && collisionPoint.x <= terrain->GetEndX() && collisionPoint.z >= terrain->GetStartZ() && collisionPoint.z <= terrain->GetEndZ())
									{
										BulletHitWater(p_objectNode->data, collisionPoint);
										deleted = true;
									}
								}

								// finally, if bullet went off the bottom of the world or too far out, get rid of it
								if (deleted == false)
								{
									if (bullet->orient.p.y < 0.0f || bullet->orient.p.y > 5000.0f || bullet->orient.p.x < -120.0f || bullet->orient.p.z < -120.0f || bullet->orient.p.x > terrain->GetEndX() + 120.0f || bullet->orient.p.z > terrain->GetEndZ() + 120.0f)
									{
										// left playfield
										DeleteBullet(p_objectNode->data);
									}
								}
							}
						}
					}
					break;
				}
			}

			void JetHitTerrain(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
			{
				// explosion on jet
				static FastRandom fastRandom;
				LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_jet.orient.p.x, p_jet.orient.p.y, p_jet.orient.p.z)->data);
				LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
				newParticleNode->data.Initialize();
				newParticleNode->data.SetPositionFormula(p_jet.orient.p); // no movement
				newParticleNode->data.SetRadiusFormula((30.0f) / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f); // 30 foot radius to start for visibility in the distance
				newParticleNode->data.SetAlphaFormula(1.0f, 1.0f/20000.0f); // 20 second life
				newParticleNode->data.textureIndex = 0; // = GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
				unsigned char colorComponent = 32; // very dark gray
				newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop
				newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
				particleList->AddNode(newParticleNode);

				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Clear();
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
				newEnergyNode->data.radius = 30.0f / JetGameValues::FeetPerWorldUnit(); // 30.0 foot radius
				newEnergyNode->data.spacePosition = p_jet.orient.p;
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				DeleteJet(p_jet, p_gameStateData);
			}

			void JetHitWater(JetGameObject &p_jet, Vector3d &p_collisionPoint, JetGameStateData &p_gameStateData)
			{
				// make 4 decals
				LinkedListNode<SurfaceDecal> *newDecal = nullptr;
				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint - Vector3d(5.0f / JetGameValues::FeetPerWorldUnit(), 0, 0);
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint + Vector3d(5.0f / JetGameValues::FeetPerWorldUnit(), 0, 0);
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint + Vector3d(0, 0, 5.0f / JetGameValues::FeetPerWorldUnit());
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint - Vector3d(0, 0, 5.0f / JetGameValues::FeetPerWorldUnit());
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				// make a big fountain
				LinkedListNode<AlphaBillboard> *newBillboard = waterFountains->GetNewNode();
				newBillboard->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterSplash");
				newBillboard->data.color = GameColor(255, 255, 255, 255);
				newBillboard->data.startCenter = p_collisionPoint;
				newBillboard->data.startCenter.y -= 1.0f; // hide the stem a little
				newBillboard->data.startVelocity = Vector3d(0, 0, 0);
				//newBillboard->data.startVelocity.y = sqrt((1.5f * 2.0f) / JetGameValues::GravityAccelerationPerMSSquared()) * JetGameValues::GravityAccelerationPerMSSquared(); // must rise 15 feet with upward velcoity acted upon by gravity.  So, speed at which something reaches with a 4.5 foot drop
				newBillboard->data.startVelocity.y = 0.0f;
				newBillboard->data.width = 20.0f / JetGameValues::FeetPerWorldUnit(); // start 2 foot wide and widen
				newBillboard->data.height = 20.0f / JetGameValues::FeetPerWorldUnit(); // 2 foot high fountain, make taller
				newBillboard->data.lifeMS = 0;
				newBillboard->data.widthAdjustPerMS = 40.f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread
				newBillboard->data.heightAdjustPerMS = 100.0f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread

				waterFountains->AddNode(newBillboard);


				DeleteJet(p_jet, p_gameStateData);
			}

			void JetSkimmingWater(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
			{
				// see if jet is travelling fast enough and is close enough to the water to raise fountains and/or cause ripples

				// wingTip is the 'control point'
				// todo: these scalarmults correspond to the model and should change with the model. (named vertices would be good)
				float speed = p_jet.velocity.Magnitude();
				Vector3d wingTip = p_jet.orient.p - p_jet.orient.f.ScalarMult(1.0f) + p_jet.orient.l.ScalarMult(0.75f) - p_jet.orient.u.ScalarMult(0.15f);
				WingtipSkimmingWater(wingTip, p_jet.orient.p - p_jet.priorPosition, speed, &(p_jet.leftWingTipWaterFountainDistanceDelay), p_gameStateData);

				wingTip = p_jet.orient.p - p_jet.orient.f.ScalarMult(1.0f) - p_jet.orient.l.ScalarMult(0.75f) - p_jet.orient.u.ScalarMult(0.15f);
				WingtipSkimmingWater(wingTip, p_jet.orient.p - p_jet.priorPosition, speed, &(p_jet.rightWingTipWaterFountainDistanceDelay), p_gameStateData);
			}

			void WingtipSkimmingWater(Vector3d &p_wingtipPosition, Vector3d &p_wingtipTravel, float jetSpeed, float *p_wingtipDistanceDelay, JetGameStateData &p_gameStateData)
			{
				// todo: if there is no fountain created, don't place a distance delay on the jet - let it remain zero
			
				float totalTravelDistance = p_wingtipTravel.Magnitude();
				if (*p_wingtipDistanceDelay >= totalTravelDistance)
				{
					*p_wingtipDistanceDelay -= totalTravelDistance;
					return;
				}

				// iterate along travel path
				float distanceRemaining = totalTravelDistance;
				while (distanceRemaining >= 0) // the while actually never becomes false, the return is hit first
				{
					if (*p_wingtipDistanceDelay <= distanceRemaining)
					{
						distanceRemaining -= *p_wingtipDistanceDelay;
						*p_wingtipDistanceDelay = 0;
					}
					else
					{
						*p_wingtipDistanceDelay -= distanceRemaining;
						return;
					}

					Vector3d wingTipTestPosition = p_wingtipPosition + p_wingtipTravel.ScalarMult((totalTravelDistance - distanceRemaining) / totalTravelDistance);

					// check every 10 feet
					*p_wingtipDistanceDelay += 1.0f;

					// don't check if outside terrain
					if (wingTipTestPosition.x < terrain->GetStartX() || wingTipTestPosition.x > terrain->GetEndX() || wingTipTestPosition.z < terrain->GetStartZ() || wingTipTestPosition.z > terrain->GetEndZ())
						continue;

					// velocity and distance about water determine if a fountain is raised
					// also point must be above water and not terrain, so make a downward collision test at each point that is planned to make a fountain
					float distanceAboveWater = wingTipTestPosition.y - terrainWaterYWorldValue;
					float factor = distanceAboveWater;
					if (factor < 0.5f)
						factor = 4.0f;
					else
						factor = 4.5f - distanceAboveWater;

					// 0.16 is MASSIVE = 10 x 25
					// 0.02 is small and minimum
					float fountainStrength = jetSpeed * factor;
					//fountainStrength = fountainStrength * fountainStrength;
					if (fountainStrength >= 0.02f)
					{
						Vector3d fountainPosition = wingTipTestPosition;
						fountainPosition.y = terrainWaterYWorldValue;
						// make sure we are above water
						float collisionT;
						Vector3d collisionLocation, collisionNormal;
						if (terrain->SphereCollision(wingTipTestPosition, fountainPosition - wingTipTestPosition, 0.01f, collisionT, collisionLocation, collisionNormal) == false)
						{
							// make a fountain
							LinkedListNode<AlphaBillboard> *newBillboard = waterFountains->GetNewNode();
							newBillboard->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterSplash");
							newBillboard->data.color = GameColor(255, 255, 255, 255);
							newBillboard->data.startCenter = fountainPosition;
							newBillboard->data.startCenter.y -= 0.0f; // hide the stem
							newBillboard->data.startVelocity = Vector3d(0, 0, 0);
							//newBillboard->data.startVelocity.y = sqrt((1.5f * 2.0f) / JetGameValues::GravityAccelerationPerMSSquared()) * JetGameValues::GravityAccelerationPerMSSquared(); // must rise 15 feet with upward velcoity acted upon by gravity.  So, speed at which something reaches with a 4.5 foot drop
							newBillboard->data.startVelocity.y = 0.0f;
							newBillboard->data.width = 2.0f / JetGameValues::FeetPerWorldUnit(); // start 2 foot wide and widen
							newBillboard->data.height = 2.0f / JetGameValues::FeetPerWorldUnit(); // 2 foot high fountain, make taller
							newBillboard->data.lifeMS = 0;
							newBillboard->data.widthAdjustPerMS = 15.0f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread
							newBillboard->data.heightAdjustPerMS = 40.0f / JetGameValues::FeetPerWorldUnit() / 1000.0f * (fountainStrength / 0.12f); // speed of spread

							waterFountains->AddNode(newBillboard);

							// todo: adjust distance delay
							// todo: subtract distance delay
						}
					}
				}
			}

			void BulletHitWater(JetGameObject &p_bullet, Vector3d p_collisionPoint)
			{
				// make a decal
				LinkedListNode<SurfaceDecal> *newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue

				newDecal->data.center = p_collisionPoint;
				// 4 ft disturbance to start ought to do it
				newDecal->data.width = 4.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 4.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 5000;
				newDecal->data.CalculateVertices();

				waterDecals->AddNode(newDecal);

				// make a fountain
				LinkedListNode<AlphaBillboard> *newBillboard = waterFountains->GetNewNode();
				newBillboard->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterSplash");
				newBillboard->data.color = GameColor(255, 255, 255, 255);
				newBillboard->data.startCenter = p_collisionPoint;
				newBillboard->data.startCenter.y -= 0.0f; // hide the stem
				newBillboard->data.startVelocity = Vector3d(0, 0, 0);
				//newBillboard->data.startVelocity.y = sqrt((1.5f * 2.0f) / JetGameValues::GravityAccelerationPerMSSquared()) * JetGameValues::GravityAccelerationPerMSSquared(); // must rise 15 feet with upward velcoity acted upon by gravity.  So, speed at which something reaches with a 4.5 foot drop
				newBillboard->data.startVelocity.y = 0.0f;
				newBillboard->data.width = 2.0f / JetGameValues::FeetPerWorldUnit(); // start 2 foot wide and widen
				newBillboard->data.height = 2.0f / JetGameValues::FeetPerWorldUnit(); // 2 foot high fountain, make taller
				newBillboard->data.lifeMS = 0;
				newBillboard->data.widthAdjustPerMS = 10.0f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread
				newBillboard->data.heightAdjustPerMS = 25.0f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread

				waterFountains->AddNode(newBillboard);

				// add a strike animation
				static FastRandom fastRandom;
				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(255, 255, 255); // white water foam
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Clear();
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
				newEnergyNode->data.radius = 6.0f / JetGameValues::FeetPerWorldUnit(); // 6.0 foot radius
				newEnergyNode->data.spacePosition = p_collisionPoint;
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				// remove the bullet
				DeleteBullet(p_bullet);
			}

			void BulletHitTerrain(JetGameObject &p_bullet, Vector3d &p_collisionLocation, JetGameStateData p_gameStateData)
			{
				static FastRandom fastRandom;

				LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_collisionLocation.x, p_collisionLocation.y, p_collisionLocation.z)->data);
				LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
				newParticleNode->data.Initialize();
				newParticleNode->data.SetPositionFormula(p_collisionLocation); // no movement
				newParticleNode->data.SetAlphaFormula(1.0f, 1.0f/5000.0f); // 5 seconds
				newParticleNode->data.SetRadiusFormula((5.0f) / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f); // 5 foot radius to start for visibility in the distance
				newParticleNode->data.textureIndex = 0; //GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
				unsigned char colorComponent = 32; // very dark gray
				newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop
				newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
				particleList->AddNode(newParticleNode);

				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Clear();
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
				newEnergyNode->data.radius = 6.0f / JetGameValues::FeetPerWorldUnit(); // 6.0 foot radius
				newEnergyNode->data.spacePosition = p_collisionLocation;
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("Spark");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				// remove the bullet
				DeleteBullet(p_bullet);
			}

			// todo: move to jet behavior class?  or keep out here?
			void DeleteJet(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
			{
				p_jet.Delete();

				// hide damage indicator, no need for it anymore
				p_jet.damageIndicatorTimerMS = 0;

				if (p_jet.squadRank == 0 && p_jet.dead == false)
				{
					ReassignSquadLeader(p_jet, p_gameStateData);
				}
				else if (p_jet.dead == false)
				{
					ReassignSquadRanks(p_jet, p_gameStateData);
				}
			}

			void ReassignSquadRanks(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
			{
				JetGameObject *priorSquadJet = nullptr;
				JetGameObject *priorpriorSquadJet = nullptr;
				// re rank the remaining subordinate jets in the squad (assumed to be in order of appearance in list, 0 should always be the first nondeleted one)
				LinkedListEnumerator<JetGameObject> enumerator2 = LinkedListEnumerator<JetGameObject>(*p_gameStateData.mainGameObjectListRef);
				JetGameObject *existingSquadLeader = (JetGameObject *)(p_jet.squadLeader.Ptr());
				priorSquadJet = (JetGameObject *)(p_jet.squadLeader.Ptr());
				int rank = 1;
				while (enumerator2.MoveNext())
				{
					if (enumerator2.Current()->data.deleted == true)
						continue;
					if (enumerator2.Current()->data.dead == true)
						continue;
					if (enumerator2.Current()->data.objectType != JetGameObjectEnum::Jet)
						continue;
					if (enumerator2.Current()->data.faction != p_jet.faction)
						continue;

					if (enumerator2.Current()->data.squadLeader.Ptr() == existingSquadLeader && enumerator2.Current()->data.squadRank != 0)
					{
						enumerator2.Current()->data.squadRank = rank;
						if (rank == 1)
							enumerator2.Current()->data.squadPartner.Set(priorSquadJet);
						else
							enumerator2.Current()->data.squadPartner.Set(priorpriorSquadJet);
						rank++;
					}

					priorpriorSquadJet = priorSquadJet;
					priorSquadJet = &(enumerator2.Current()->data);
				}

			}

			void ReassignSquadLeader(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
			{
				JetGameObject *priorSquadJet = nullptr;
				JetGameObject *priorpriorSquadJet = nullptr;
				// find the next available jet to assign as squad leader, give it the same waypoint list and current waypoint, and make it squad leader to the rest of
				//   that squad
				LinkedListEnumerator<JetGameObject> enumerator2 = LinkedListEnumerator<JetGameObject>(*p_gameStateData.mainGameObjectListRef);
				JetGameObject *newSquadLeader = nullptr;
				int rank = 0;
				while (enumerator2.MoveNext())
				{
					if (enumerator2.Current()->data.deleted == true)
						continue;
					if (enumerator2.Current()->data.dead == true)
						continue;
					if (enumerator2.Current()->data.objectType != JetGameObjectEnum::Jet)
						continue;
					if (enumerator2.Current()->data.faction != p_jet.faction)
						continue;

					if (newSquadLeader == nullptr)
					{
						if (enumerator2.Current()->data.squadLeader.Ptr() == &(p_jet))
						{
							enumerator2.Current()->data.behavior = p_jet.behavior; // patrol or fly waypoints
							enumerator2.Current()->data.currentWaypointRef = p_jet.currentWaypointRef;
							enumerator2.Current()->data.waypointListRef = p_jet.waypointListRef;
							enumerator2.Current()->data.squadRank = rank;
							rank++;
							enumerator2.Current()->data.squadLeader.Clear();
							enumerator2.Current()->data.squadPartner.Clear();
							newSquadLeader = &(enumerator2.Current()->data);
						}
					}
					else
					{
						if (enumerator2.Current()->data.squadLeader.Ptr() == &(p_jet))
						{
							enumerator2.Current()->data.squadRank = rank;
							if (rank == 1)
								enumerator2.Current()->data.squadPartner.Set(priorSquadJet);
							else
								enumerator2.Current()->data.squadPartner.Set(priorpriorSquadJet);
							enumerator2.Current()->data.squadLeader.Set(newSquadLeader);
							rank++;
						}
					}

					priorpriorSquadJet = priorSquadJet;
					priorSquadJet = &(enumerator2.Current()->data);
				}

			}

			void JetHitJet(JetGameObject &p_jet1, JetGameObject &p_jet2, float p_collisionT, JetGameStateData &p_gameStateData)
			{
				// advance both jets to their positions
				// delete each
				p_jet1.orient.p = p_jet1.priorPosition + (p_jet1.orient.p - p_jet1.priorPosition).ScalarMult(p_collisionT);
				p_jet2.orient.p = p_jet2.priorPosition + (p_jet2.orient.p - p_jet2.priorPosition).ScalarMult(p_collisionT);
				DeleteJet(p_jet1, p_gameStateData);
				DeleteJet(p_jet2, p_gameStateData);
			}

			void BulletHitJet(JetGameObject &p_bullet, JetGameObject &p_jet, JetGameStateData &p_gameStateData, Vector3d &p_collisionOffset)
			{
				DamageJet(p_jet, JetGameValues::BulletDamage(), p_gameStateData, p_bullet.sourceRef, p_collisionOffset, p_bullet.velocity, true);

				static FastRandom fastRandom;
				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Set(&p_jet);
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::OrientPosition;
				newEnergyNode->data.radius = 10.0f / JetGameValues::FeetPerWorldUnit(); // 10.0 foot radius for visibility
				newEnergyNode->data.spacePosition = p_collisionOffset.ScalarMult(-1.0f);
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("Spark");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				DeleteBullet(p_bullet);
			}

			void MissileHitJet(JetGameObject &p_missile, JetGameObject &p_jet, float p_collisionT, JetGameStateData &p_gameStateData)
			{
				DamageJet(p_jet, JetGameValues::MissileFullImpactDamage(), p_gameStateData, p_missile.sourceRef, Vector3d(0, 0, 0), Vector3d(0,0,0), true);

				// explosion on missile
				static FastRandom fastRandom;
				LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_missile.orient.p.x, p_missile.orient.p.y, p_missile.orient.p.z)->data);
				LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
				newParticleNode->data.Initialize();
				newParticleNode->data.SetPositionFormula(p_missile.orient.p); // no movement
				newParticleNode->data.SetRadiusFormula((20.0f) / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f);
				newParticleNode->data.SetAlphaFormula(1.0f, 1.0f / 15000.0f); // 15 seconds
				newParticleNode->data.textureIndex = 0; // Ref = GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
				unsigned char colorComponent = 32; // very dark gray
				newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop
				newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
				particleList->AddNode(newParticleNode);

				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Clear();
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
				newEnergyNode->data.radius = 20.0f / JetGameValues::FeetPerWorldUnit(); // 20.0 foot radius
				newEnergyNode->data.spacePosition = p_missile.orient.p;
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				Vector3d offset = p_jet.orient.p - p_missile.orient.p;
				offset.Normalize();
				p_jet.velocity = p_jet.velocity + offset.ScalarMult(JetGameValues::MissileStrikeForceOffset());

				DeleteMissile(p_missile, p_gameStateData);
			}

			void MissileHitTerrain(JetGameObject &p_missile, Vector3d &p_collisionPoint, JetGameStateData &p_gameStateData)
			{
				// explosion on missile
				static FastRandom fastRandom;
				LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_missile.orient.p.x, p_missile.orient.p.y, p_missile.orient.p.z)->data);
				LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
				newParticleNode->data.Initialize();
				newParticleNode->data.SetPositionFormula(p_missile.orient.p); // no movement
				newParticleNode->data.SetAlphaFormula(1.0f, 1.0f / 15000.0f); // 15 seconds
				newParticleNode->data.SetRadiusFormula((20.0f) / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f);
				newParticleNode->data.textureIndex = 0; // GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
				unsigned char colorComponent = 32; // very dark gray
				newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop
				newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
				particleList->AddNode(newParticleNode);

				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Clear();
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
				newEnergyNode->data.radius = 20.0f / JetGameValues::FeetPerWorldUnit(); // 20.0 foot radius
				newEnergyNode->data.spacePosition = p_missile.orient.p;
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				DeleteMissile(p_missile, p_gameStateData);
			}

			void MissileHitWater(JetGameObject &p_missile, Vector3d &p_collisionPoint, JetGameStateData &p_gameStateData)
			{
				// make 4 decals
				LinkedListNode<SurfaceDecal> *newDecal = nullptr;
				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint - Vector3d(5.0f / JetGameValues::FeetPerWorldUnit(), 0, 0);
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint + Vector3d(5.0f / JetGameValues::FeetPerWorldUnit(), 0, 0);
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint + Vector3d(0, 0, 5.0f / JetGameValues::FeetPerWorldUnit());
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				newDecal = waterDecals->GetNewNode();
				newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
				newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue
				newDecal->data.center = p_collisionPoint - Vector3d(0, 0, 5.0f / JetGameValues::FeetPerWorldUnit());
				// 16 ft disturbance
				newDecal->data.width = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.height = 16.0f / JetGameValues::FeetPerWorldUnit();
				newDecal->data.vertices[0].colorIndex = 0;
				newDecal->data.vertices[1].colorIndex = 0;
				newDecal->data.vertices[2].colorIndex = 0;
				newDecal->data.vertices[3].colorIndex = 0;
				newDecal->data.lifeMS = 0;
				newDecal->data.maxLifeMS = 10000;
				newDecal->data.CalculateVertices();
				waterDecals->AddNode(newDecal);

				// make a big fountain
				LinkedListNode<AlphaBillboard> *newBillboard = waterFountains->GetNewNode();
				newBillboard->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterSplash");
				newBillboard->data.color = GameColor(255, 255, 255, 255);
				newBillboard->data.startCenter = p_collisionPoint;
				newBillboard->data.startCenter.y -= 1.0f; // hide the stem a little
				newBillboard->data.startVelocity = Vector3d(0, 0, 0);
				//newBillboard->data.startVelocity.y = sqrt((1.5f * 2.0f) / JetGameValues::GravityAccelerationPerMSSquared()) * JetGameValues::GravityAccelerationPerMSSquared(); // must rise 15 feet with upward velcoity acted upon by gravity.  So, speed at which something reaches with a 4.5 foot drop
				newBillboard->data.startVelocity.y = 0.0f;
				newBillboard->data.width = 20.0f / JetGameValues::FeetPerWorldUnit(); // start 2 foot wide and widen
				newBillboard->data.height = 20.0f / JetGameValues::FeetPerWorldUnit(); // 2 foot high fountain, make taller
				newBillboard->data.lifeMS = 0;
				newBillboard->data.widthAdjustPerMS = 40.f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread
				newBillboard->data.heightAdjustPerMS = 100.0f / JetGameValues::FeetPerWorldUnit() / 1000.0f; // speed of spread

				waterFountains->AddNode(newBillboard);

				// explosion
				static FastRandom fastRandom;
				LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
				newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
				newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
				newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
				newEnergyNode->data.parentRef.Clear();
				newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
				newEnergyNode->data.radius = 20.0f / JetGameValues::FeetPerWorldUnit(); // 20.0 foot radius
				newEnergyNode->data.spacePosition = p_missile.orient.p;
				newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
				newEnergyNode->data.rendered = false;
				fastEffects->AddNode(newEnergyNode);

				// remove missile
				DeleteMissile(p_missile, p_gameStateData);
			}

			void DamageJet(JetGameObject &p_jet, float p_damage, JetGameStateData &p_gameStateData, GameObjectRef &p_source, Vector3d &p_collisionOffset, Vector3d &p_incomingVelocity, bool p_showDamageIndicator)
			{
				// Let user controlled jet be invulnerable for now
				if (userControlJetRef != &p_jet)
					p_jet.health -= p_damage;

				// todo: if significantly damaged, explode it now (delete and replace)
				if (p_jet.health <= 0.0f)
				{
					KillJet(p_jet, p_gameStateData);
				}
				else
				{
					// only show damage indicator when damage was done by the controller's weapon
					if (p_showDamageIndicator == true && p_source.IsValid() && p_source.Ptr() == userControlJetRef)
					{
						p_jet.damageIndicatorTimerMS = JetGameValues::DamageIndicatorTimerMS();
					}

					// release some damage smoke
					static FastRandom fastRandom;
					LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_jet.orient.p.x, p_jet.orient.p.y, p_jet.orient.p.z)->data);
					LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
					newParticleNode->data.Initialize();
					newParticleNode->data.SetPositionFormula(p_jet.orient.p); // no movement
					newParticleNode->data.SetAlphaFormula(1.0f, 1.0f / 10000.0f); // 10 seconds
					newParticleNode->data.SetRadiusFormula((4.0f) / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f);
					newParticleNode->data.textureIndex = 0; // GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
					unsigned char colorComponent = fastRandom.GetRandomInteger(0, 64); // stagger the color from pitch black to dark gray
					newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop
					newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
					particleList->AddNode(newParticleNode);
				}

				if (&p_jet == userControlJetRef)
				{
					// do a damage waggle (shifts reticles durring rendering)
					Vector3d waggle = p_collisionOffset - p_jet.orient.f.ScalarMult(p_collisionOffset * p_jet.orient.f);
					waggle.z = 0.0f;
					if (waggle.Normalize() == false) // if hit straight on or straight back, just shoot reticles upward
						waggle = Vector3d(0, 1, 0);
					p_jet.damageReticleWaggle = waggle.ScalarMult(JetGameValues::JetBulletDamageWaggle());

					// and record a damage pulse for display (angle is rotated around the craft horizontally)
					Vector3d jetSpaceIncoming = p_jet.orient.TransformToOrientSpace(p_jet.orient.p - p_incomingVelocity);
					Vector3d strikeDirection = jetSpaceIncoming - p_jet.orient.u.ScalarMult(jetSpaceIncoming * p_jet.orient.u);
					strikeDirection.y = 0.0f;
					if (strikeDirection.Normalize() == false) // if hit from straight below or above, record as straight forward
						strikeDirection = Vector3d(0, 0, 1);
					float strikeDegrees = -MathUtilities::RadiansToDegrees(float(asin(strikeDirection.x)));
					if (strikeDirection.z < 0.0f)
						strikeDegrees = 180.0f - strikeDegrees;
					p_jet.SetDamagePulse(strikeDegrees);

					//p_jet.health += p_damage; // don't allow death just yet - testing
				}
			}

			void KillJet(JetGameObject &p_jet, JetGameStateData &p_gameStateData)
			{
				if (p_jet.dead == false)
				{
					p_jet.dead = true;

					// other maintenance of freshly killed jet
					if (p_jet.squadRank == 0)
						ReassignSquadLeader(p_jet, p_gameStateData);
					else
						ReassignSquadRanks(p_jet, p_gameStateData);

					// put an explosion on the jet
					// explosion on jet
					static FastRandom fastRandom;
					LinkedList<Particle> *particleList = &(p_gameStateData.particlePartitionRef->GetPartitionSection(p_jet.orient.p.x, p_jet.orient.p.y, p_jet.orient.p.z)->data);
					LinkedListNode<Particle> *newParticleNode = particleList->GetNewNode();
					newParticleNode->data.Initialize();
					newParticleNode->data.SetPositionFormula(p_jet.orient.p); // no movement
					newParticleNode->data.SetAlphaFormula(1.0f, 1.0f/12000.0f); // 12 seconds
					newParticleNode->data.SetRadiusFormula((12.0f) / JetGameValues::FeetPerWorldUnit(), 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f);
					newParticleNode->data.textureIndex = 0; // GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
					unsigned char colorComponent = 32; // very dark gray
					newParticleNode->data.color = GameColor(colorComponent, colorComponent, colorComponent); // alpha will be calculated in render loop
					newParticleNode->data.rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
					particleList->AddNode(newParticleNode);

					// and a flash
					LinkedListNode<EnergyEffect> *newEnergyNode = fastEffects->GetNewNode();
					newEnergyNode->data.animationType = EnergyEffectAnimationTypeEnum::SingleFrame;
					newEnergyNode->data.color = GameColor(236, 236, 90); // same as bullet day color
					newEnergyNode->data.degreeRotation = float(fastRandom.GetRandomInteger(0, 359));
					newEnergyNode->data.parentRef.Clear();
					newEnergyNode->data.positionType = EnergyEffectPositionTypeEnum::World;
					newEnergyNode->data.radius = 30.0f / JetGameValues::FeetPerWorldUnit(); // 30.0 foot radius
					newEnergyNode->data.spacePosition = p_jet.orient.p;
					newEnergyNode->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("MuzzleFlash1");
					newEnergyNode->data.rendered = false;
					fastEffects->AddNode(newEnergyNode);
				}

				// hide damage indicator, no need for it anymore
				p_jet.damageIndicatorTimerMS = 0;
				// allow smoke to happen more regularly starting now
				p_jet.smokeDelayMS = 0;

				// random spin
				float aileron = random->GetRandomFloat() * 2.0f - 1.0f;
				p_jet.leftAileron = aileron;
				p_jet.rightAileron = -aileron;
			}

			void DeleteBullet(JetGameObject &p_bullet)
			{
				// nothing else to do for now
				p_bullet.Delete();
			}

			void DeleteMissile(JetGameObject &p_missile, JetGameStateData &p_gameStateData)
			{
				// nothing else to do for now
				p_missile.Delete();
			}

			////////////////////////

			void PerformRender() override
			{
				GameContext::Instance->Metrics.RenderedTriangles.Clear();
				GameContext::Instance->Metrics.RenderedLines.Clear();
				GameContext::Instance->Metrics.RenderedPoints.Clear();
				GameContext::Instance->Metrics.RenderedVertexArrays.Clear();
				GameContext::Instance->Metrics.PreppingVAOTimer.Reset();
				GameContext::Instance->Metrics.RenderingVAOTimer.Reset();
				GameContext::Instance->Metrics.RenderingTerrainTimer.Reset();
				GameContext::Instance->Metrics.SwapBuffersTimer.Reset();
				GameContext::Instance->Metrics.RenderingTimer.Reset();
				//GameContext::Instance->Metrics.GameloopTimer.Reset(); // don't reset this here!!!

				GameContext::Instance->Metrics.RenderingTimer.Start();
				GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
				graphics->MakeCurrent();
				graphics->ClearScreen(GameColor(0, 0, 0));

				if (stereoScopicMode == 0)
				{
					graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0); // 90 is nice with a huge monitor viewed closely but reticles and indicators are small (but still correct)
					graphics->DefaultTransform();

					DrawElements(graphics, nullptr, false);
				}
				else if (stereoScopicMode == 1)
				{
					//StereoscopicCamera camera(0.05f, 2.75f / 12.0f / 10.0f); // converge at 6" with an eye separation of 

					StereoscopicCamera stereoCamera(0.2f, 0.031f); // dungeon app settings, but ideally the convergence distance would be the reticles, but not necessarily.  get artistic here!

					Vector3d eyePosition;

					graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, 0.1, 2000.0, stereoCamera);
					graphics->DefaultTransformStereoscopicLeft(stereoCamera);
					graphics->ColorMask(true, false, false, true);
					DrawElements(graphics, &stereoCamera, true);

					graphics->FinishRender();
					graphics->ClearDepth();

					graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, 0.1, 2000.0, stereoCamera);
					graphics->DefaultTransformStereoscopicRight(stereoCamera);
					graphics->ColorMask(false, true, true, true);
					DrawElements(graphics, &stereoCamera, false);

					graphics->ColorMask(true, true, true, true);
				}
				else if (stereoScopicMode == 2 || stereoScopicMode == 3)
				{
					// 4" wide screen google cardboard
					StereoscopicCamera stereoCamera(
						4.0f / 1334.0f, 
						-0.225f, // 60
						0.0f, 
						2.75f / 12.0f / 10.0f); // real world eye separation
					stereoCamera.leftVanishingPointX = (((2.8f + splitScreenCalibrationValue / 100.0f) / 8.0f) - 0.5f) * 2.0f;
					stereoCamera.eyeSeparationLength = eyeSeparationInches / 12.0f / 10.0f;
					if (stereoScopicMode == 3)
						stereoCamera.screenWidthPercentage = 0.8546f; // 1334/1920redx401/336ppi - iPhone7 plus
						//stereoCamera.screenWidthPercentage = 0.1f; // 1334/1920redx401/336ppi - iPhone7 plus

					graphics->SetPerspectiveProjectionStereoscopicLeft(77.8f, 0.1, 2000.0, stereoCamera);
					graphics->DefaultTransformStereoscopicLeft(stereoCamera);
					DrawElements(graphics, &stereoCamera, true);

					graphics->FinishRender();

					graphics->SetPerspectiveProjectionStereoscopicRight(77.8f, 0.1, 2000.0, stereoCamera);
					graphics->DefaultTransformStereoscopicRight(stereoCamera);
					DrawElements(graphics, &stereoCamera, false);

					graphics->SetViewportSize(
						GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
						GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()
						);

					// Render division
					graphics->Set2dWindowProjection();
					ModelVertex quad[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
					GameColor white(255, 255, 255);
					float width = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth());
					float viewportHeight = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());
					float height = viewportHeight * stereoCamera.screenWidthPercentage;
					float centerX = width / 2.0f;
					float centerY = width / 2.0f;
					quad[0].vertex.Set(centerX - width * stereoCamera.divisionWidth * stereoCamera.screenWidthPercentage / 2.0f, viewportHeight - height, 0);
					quad[1].vertex.Set(centerX + width * stereoCamera.divisionWidth * stereoCamera.screenWidthPercentage / 2.0f, viewportHeight - height, 0);
					quad[2].vertex.Set(centerX + width * stereoCamera.divisionWidth * stereoCamera.screenWidthPercentage / 2.0f, viewportHeight, 0);
					quad[3].vertex.Set(centerX - width * stereoCamera.divisionWidth * stereoCamera.screenWidthPercentage / 2.0f, viewportHeight, 0);
					graphics->RenderFilledQuad(&white, 1, quad, 4);
				}

				///////////////////////
				// render text
				bool renderText = showInfo;
				GameContext::Instance->Metrics.RenderingTimer.Stop();
				if (renderText == true)
				{
					graphics->Set2dWindowProjection();
					graphics->SetDepthTestEnabled(false);
					if (userControlJetRef != nullptr)
					{
						graphics->RenderFont(String::Format("X:{0:0.000}, Y:{1:0.000}, Z:{2:0.000}", userControlJetRef->orient.p.x, userControlJetRef->orient.p.y, userControlJetRef->orient.p.z),
							GameContext::Instance->FontRegistry.GetFont("Info"),
							10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 1 - 10),
							GameColor(255, 255, 0));
						graphics->RenderFont(String::Format("Air speed:{0:0.0}", userControlJetRef->velocity.Magnitude() * JetGameValues::FeetPerWorldUnit() * 1000.0f * 3600.0f / 5280.0f),
							GameContext::Instance->FontRegistry.GetFont("Info"),
							10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 2 - 10),
							GameColor(255, 255, 0));
					}
					if (cameraJetRef != nullptr)
					{
						graphics->RenderFont(String::Format("Air speed:{0:0.0}", cameraJetRef->velocity.Magnitude() * JetGameValues::FeetPerWorldUnit() * 1000.0f * 3600.0f / 5280.0f),
							GameContext::Instance->FontRegistry.GetFont("Info"),
							10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 2 - 10),
							GameColor(255, 255, 0));
					}
					LinkedListNode<JetGameObject> *jet1Node = gameObjectList->GetFirstNode();
					graphics->RenderFont("Lead Jet Joystick: " + String::Format("X:{0:0}, Y:{1:0}, Twist:{2:0}", jet1Node->data.joystick.GetCurrentX(), jet1Node->data.joystick.GetCurrentY(), jet1Node->data.joystick.GetCurrentTwist()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 3 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Triangles: " + String::Format("{0:0}", GameContext::Metrics.RenderedTriangles.GetCount()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 4 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Vertex Arrays: " + String::Format("{0:0}", GameContext::Metrics.RenderedVertexArrays.GetCount()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 5 - 10),
						GameColor(255, 255, 0));
					// need this timer because when paused, timer doesn't register any elapsed time
					static GameTimer renderTimer;
					renderTimer.Poll();
					GameContext::Metrics.FramesPerSecond.SubmitFrameMS(renderTimer.GetElapsedTimeMS());
					renderTimer.ResetElapsedTime();
					graphics->RenderFont("FPS: " + String::Format("{0:G}", GameContext::Metrics.FramesPerSecond.GetFramesPerSecond()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 6 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Prep Vertex Arrays Time: " + String::Format("{0:G}", GameContext::Metrics.PreppingVAOTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 7 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Render Vertex Arrays Time: " + String::Format("{0:G}", GameContext::Metrics.RenderingVAOTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 8 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Render Terrain Time: " + String::Format("{0:G}", GameContext::Metrics.RenderingTerrainTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 9 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Swap Buffers Time: " + String::Format("{0:G}", GameContext::Metrics.SwapBuffersTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 10 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Render Time: " + String::Format("{0:G}", GameContext::Metrics.RenderingTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 11 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Gameloop Time: " + String::Format("{0:G}", GameContext::Metrics.GameloopTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 12 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Windows Idle Time: " + String::Format("{0:G}", GameContext::Metrics.WindowsIdleTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 13 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Finish Render Time: " + String::Format("{0:G}", GameContext::Metrics.FinishRenderTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 14 - 10),
						GameColor(255, 255, 0));
					int totalElements = GameContext::Metrics.SwapBuffersTimer.GetElapsedMS() + GameContext::Metrics.RenderingTimer.GetElapsedMS() + GameContext::Metrics.GameloopTimer.GetElapsedMS() + GameContext::Metrics.WindowsIdleTimer.GetElapsedMS() + GameContext::Metrics.FinishRenderTimer.GetElapsedMS();
					graphics->RenderFont("Total Elements Time: " + String::Format("{0:G}", totalElements),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 15 - 10),
						GameColor(255, 255, 0));
					GameContext::Metrics.FullLoopTimer.Stop();
					graphics->RenderFont("VSync (ctrl-V): " + (graphics->VSyncIsEnabled() ? "ON" : "OFF"),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 16 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Native smoke (ctrl-P): " + (useParticleQueue ? "ON" : "OFF"),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 17 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Native vapor trails (ctrl-T): " + (usePolygonQueue ? "ON" : "OFF"),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 18 - 10),
						GameColor(255, 255, 0));
					graphics->RenderFont("Full loop Time: " + String::Format("{0:G}", GameContext::Metrics.FullLoopTimer.GetElapsedMS()),
						GameContext::Instance->FontRegistry.GetFont("Info"),
						10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 19 - 10),
						GameColor(255, 255, 0));
					GameContext::Metrics.FullLoopTimer.Reset();
					GameContext::Metrics.FullLoopTimer.Start();

					graphics->SetDepthTestEnabled(true);
				}

				graphics->FinishRender();
				graphics->SwapBuffers();
			}

			void DrawElements(GraphicsBase *graphics, StereoscopicCamera *p_camera, bool p_left)
			{

				bool animate = (p_camera == nullptr || p_left == true); // for anything that is animated or progressed in the renderer, so it ONLY in the left scene when in stereoscopic
				bool finalScene = (p_camera == nullptr || p_left == false); // anything done on the final scene only (removing and tagging deleted items, etc.)

				// multiple rendering sections can use the polygon queue (vapor trails, water ripples, flash effects, bullets), but each should commit at the end of its section
				//   because they may use different texture blending options and different mvps
				GraphicsShaderPolygonOptions polygonQueueOptions; // used for all polygonQueue rendering
				Matrix4d mvpMatrix; // general use by polygonQueueOptions
				if (usePolygonQueue == true)
				{
					if (polygonQueue->nativePolygonQueueRef == nullptr)
						graphics->CreatePolygonQueue(polygonQueue, 8000);
					polygonQueueOptions.mvpMatrixRef = &mvpMatrix;
				}

				// establish camera position
				LinkedListEnumerator<JetGameObject> gameObjectEnumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
				bool renderReticles = false;
				if (userControlJetRef != nullptr)
				{
					cameraOrient->Set(userControlJetRef->orient);
					renderReticles = true;
					// todo: place in cockpit location on jet instead of at center of jet

					// this way if the target goes away we still have something to latch on to after it's gone if we press F3 later
					if (userControlJetRef->targetRef.IsValid())
					{
						*cameraTrackPosition = ((JetGameObject *)userControlJetRef->targetRef.Ptr())->orient.p;
					}

					if (cameraTrackTargetFromUserJet == false)
					{
						// place pov from joystick hat - if it changes, cancel line rendering of starfield
						static float currentPovAngle = 0.0f;
						float intendedPovAngle = 0.0f;
						if (joystick->values.valid == true)
							intendedPovAngle = float(joystick->values.povAngle);

						if (currentPovAngle != intendedPovAngle)
						{
							MathUtilities::InterpolateCyclicDegrees(currentPovAngle, intendedPovAngle, float(timer->GetElapsedTimeMS() / 2)); // turn 1 degree per 2 ms (~0.36 seconds for 180)
							priorTrackRef = nullptr; // don't render stars as lines for spinning pov
						}

						cameraOrient->Rotate(cameraOrient->u, currentPovAngle);
					}
					else
					{
						// point camera at target
						// spin horizontal then look up or down at it
						Vector3d offsetToTarget = *cameraTrackPosition - userControlJetRef->orient.p;
						// flatten along l and f plane
						Vector3d newFVector = offsetToTarget - cameraOrient->u.ScalarMult(cameraOrient->u * offsetToTarget);
						if (newFVector.Normalize() == true)
						{
							cameraOrient->f = newFVector;
							cameraOrient->l = cameraOrient->u.CrossProd(cameraOrient->f);
							offsetToTarget.Normalize();
							cameraOrient->f = offsetToTarget;
							cameraOrient->u = cameraOrient->f.CrossProd(cameraOrient->l);
						}
						else
						{
							// just leave it what it was before.  this cirumstance is rare (the target is perfectly above or below the jet's orientation)
						}
					}

					// if there is a live missile flying, put it there instead
					//while (gameObjectEnumerator.MoveNext())
					//{
					//	if (gameObjectEnumerator.Current()->data.objectType == JetGameObjectEnum::Missile)
					//	{
					//		if (gameObjectEnumerator.Current()->data.targetRef.Ptr() != nullptr)
					//		{
					//			cameraOrient->Set(gameObjectEnumerator.Current()->data.orient);
					//			renderReticles = false;
					//			break;
					//		}
					//	}
					//}
				}
				else if (cameraJetRef != nullptr)
				{
					cameraOrient->Set(cameraJetRef->orient);
					// todo: place in cockpit area instead of at center
				}
				else
				{
					// render camera wherever it is.
				}

				// Render skybox and starfield

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);
				Vector3d eyePositionOffset = Vector3d(0,0,0);
				if (p_camera != nullptr)
				{
					if (p_left == true)
						eyePositionOffset = cameraOrient->l.ScalarMult(p_camera->eyeSeparationLength / 2.0f);
					else
						eyePositionOffset = Vector3d(0,0,0) - cameraOrient->l.ScalarMult(p_camera->eyeSeparationLength / 2.0f);
				}

#pragma region Skybox
				// skybox
				graphics->PushMatrix();
				Orient3d skyboxOrient;
				skyboxOrient.LoadIdentity();
				skyboxOrient.p = cameraOrient->p + eyePositionOffset;
				graphics->Transform(skyboxOrient);
				graphics->SetDepthWriteEnabled(false); // todo: push current depth value then pop it later
				lowerSky->Render(*graphics); // let dome overwrite lower sky at horizon
				dome->Render(*graphics);
				graphics->SetDepthWriteEnabled(true);
				graphics->PopMatrix();

				// starfield
				graphics->PushMatrix();
				// render the starfield with the same world value as the camera point with no depth value
				Orient3d starfieldCameraOrient;
				starfieldCameraOrient.Set(*cameraOrient);
				starfieldCameraOrient.p = Vector3d(0, 0, 0);
				Orient3d starfieldRenderOrient;
				starfieldRenderOrient.LoadIdentity();
				//starfieldRenderOrient.p = cameraOrient->p + eyePositionOffset;
				// doing it this way makes priorTrack work for both eyes
				graphics->DefaultTransform();
				graphics->Transform(starfieldRenderOrient);
				//static Orient3d priorStarfieldCameraOrient = starfieldCameraOrient; // track each render (no way to reset and draw points only in this test)
				graphics->SetDepthWriteEnabled(false); // todo: push current depth value then pop it later
				starField->Render(*graphics, starfieldCameraOrient, priorTrackRef);
				if (finalScene == true)
				{
					priorStarfieldCameraOrient->Set(starfieldCameraOrient); // track for next time
					// note: only way to preserve rendered lines on a paused game is to keep track of the priorpriorTrackRef and use that, because the first render of a pause will make current = prior
					//   so for now, paused stars will always be points
					priorTrackRef = priorStarfieldCameraOrient;
				}
				graphics->SetDepthWriteEnabled(true);
				graphics->PopMatrix();

				// death star!
				if (showDeathStar == true)
				{
					Orient3d deathStarOrient;
					deathStarOrient.LoadIdentity();
					deathStarOrient.Rotate(deathStarOrient.u, -45.0f);
					deathStarOrient.Rotate(deathStarOrient.l, 20.0f);
					deathStarOrient.p = deathStarOrient.f.ScalarMult(5.0f) + cameraOrient->p + eyePositionOffset;
					deathStarOrient.Rotate(deathStarOrient.u, 180.0f);
					GameColor deathStarColors[1] = { GameColor(255, 255, 255, 85) };
					ModelVertex deathStarVertices[4] = { ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0) };
					//ModelVertex deathStarVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
					graphics->PushMatrix();
					graphics->Transform(deathStarOrient);
					graphics->SetDepthWriteEnabled(false);
					graphics->RenderFilledQuad(deathStarColors, 1, deathStarVertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar"));
					//graphics->RenderFilledQuad(deathStarColors, 1, deathStarVertices, 4, nullptr, true);
					graphics->SetDepthWriteEnabled(true);
					graphics->PopMatrix();
				}
#pragma endregion Skybox

				/*
				// original blue jet colors
				GameColor base(0, 0, 255);
				// sort of a cool sheen given off by making the cockpit 2 colors
				GameColor cockpitColor1(128, 128, 255);
				GameColor cockpitColor2(0, 255, 255);

				GetColor(0)->Set(base.Modulate(5.0f / 6.0f)); // 212
				GetColor(1)->Set(base.Modulate(2.0f / 3.0f)); // 170
				GetColor(2)->Set(base.Modulate(1.0f / 3.0f)); // 85
				GetColor(3)->Set(cockpitColor1);
				GetColor(4)->Set(cockpitColor2);
				*/

				// render solid objects
#pragma region Render Solids

				GameContext::Metrics.RenderingTerrainTimer.Start();
				gcroot<GameTexture^> terrainTextures[5]; // slot 4 is for the blendmap, will be left unpopulated if there isn't more than 1 texture
				terrainTextures[0] = nullptr;
				terrainTextures[1] = nullptr;
				terrainTextures[2] = nullptr;
				terrainTextures[3] = nullptr;
				terrainTextures[4] = nullptr;
				terrainTextures[0] = GameContext::Instance->TextureRegistry.GetTexture("Rock1"); // assumed
				terrainTextures[1] = GameContext::Instance->TextureRegistry.GetTexture("Dirt1"); // r
				terrainTextures[2] = GameContext::Instance->TextureRegistry.GetTexture("Meadow1"); // g
				terrainTextures[3] = GameContext::Instance->TextureRegistry.GetTexture("Ice1"); // b
				// render the terrain (no transform) - water is rendered later since it is alpha
				//terrain->Render(*cameraOrient, *graphics, 10, 50.0f, terrainTextures, 32.0f);
				//terrain->Render(*cameraOrient, *graphics, 10, 100.0f, terrainTextures, 32.0f);
				//terrain->Render(*cameraOrient, *graphics, 10, 200.0f, GameContext::Instance->TextureRegistry.GetTexture("Dirt1"), 32.0f);
				terrain->Render(*cameraOrient, *graphics, 10, 500.0f, terrainTextures, 32.0f);
				//terrain->Render(*cameraOrient, *graphics, 10, 1000.0f, GameContext::Instance->TextureRegistry.GetTexture("Dirt1"), 32.0f);
				GameContext::Metrics.RenderingTerrainTimer.Stop();

				if (usePolygonQueue == true)
				{
					*(polygonQueueOptions.mvpMatrixRef) = graphics->GetMVPMatrix();
				}

				gameObjectEnumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
				while (gameObjectEnumerator.MoveNext())
				{
					if (gameObjectEnumerator.Current()->data.alphaRender == true)
						continue;

					switch (gameObjectEnumerator.Current()->data.objectType)
					{
					case JetGameObjectEnum::Jet:
					{
						// don't render jet if it is where the camera is at
						if ((userControlJetRef != &(gameObjectEnumerator.Current()->data) || cameraTrackTargetFromUserJet == true || (joystick->values.valid == true && joystick->values.povAngle != 0)) && cameraJetRef != &(gameObjectEnumerator.Current()->data))
						{
							RenderSolid(graphics, gameObjectEnumerator.Current()->data.orient, gameObjectEnumerator.Current()->data.objectType, &(gameObjectEnumerator.Current()->data), polygonQueueOptions);
						}
					}
					break;
					case JetGameObjectEnum::Missile:
					{
						RenderSolid(graphics, gameObjectEnumerator.Current()->data.orient, gameObjectEnumerator.Current()->data.objectType, &(gameObjectEnumerator.Current()->data), polygonQueueOptions);
					}
					break;
					} // switch
				}

				// render waypoints(cubes for now)
				Orient3d cubeOrient;
				cubeOrient.LoadIdentity();
				LinkedListEnumerator<Waypoint> waypointEnumerator = LinkedListEnumerator<Waypoint>(*waypointList1);
				while (waypointEnumerator.MoveNext())
				{
					if (usePolygonQueue == false)
					{
						graphics->PushMatrix();
						cubeOrient.p = waypointEnumerator.Current()->data.point;
						graphics->Transform(cubeOrient);
						cube->Render(*graphics);
						graphics->PopMatrix();
					}
					else
					{
						cubeOrient.p = waypointEnumerator.Current()->data.point;
						graphics->SubmitModelToPolygonQueue(polygonQueue, polygonQueueOptions, cube->GetColors(), cube->GetColorQty(), cube->GetSurfaces(), cube->GetSurfaceQty(), cube->GetVertices(), cube->GetVertexQty(), cubeOrient, Vector3d(1, 1, 1));
					}
				}

				waypointEnumerator = LinkedListEnumerator<Waypoint>(*waypointList3);
				while (waypointEnumerator.MoveNext())
				{
					if (usePolygonQueue == false)
					{
						graphics->PushMatrix();
						cubeOrient.p = waypointEnumerator.Current()->data.point;
						graphics->Transform(cubeOrient);
						cube->Render(*graphics);
						graphics->PopMatrix();
					}
					else
					{
						cubeOrient.p = waypointEnumerator.Current()->data.point;
						graphics->SubmitModelToPolygonQueue(polygonQueue, polygonQueueOptions, cube->GetColors(), cube->GetColorQty(), cube->GetSurfaces(), cube->GetSurfaceQty(), cube->GetVertices(), cube->GetVertexQty(), cubeOrient, Vector3d(1, 1, 1));
					}
				}

				if (usePolygonQueue == true)
				{
					graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);
				}
#pragma endregion Render Solids

				// render alpha objects
				// todo: render them back to front with proper graphic tree splitting

#pragma region Render Water
				// render water
				static float waterTextureS = 0.0f;
				static float waterTextureT = 0.0f;
				static float waterTextureSPerMS = 4.0f / 20000.0f; // cycle through whole texture in 5 seconds
				static float waterTextureTPerMS = 2.0f / 20000.0f;
				static float waterTextureSizeFactor = 8.0f;
				static float waterTextureXWorldPerMS = 32.0f / 20000.0f; // I'll figure out the conversion later
				static float waterTextureZWorldPerMS = 16.0f / 20000.0f;
				static float waterTextureRadiusIncreasePerMS = 8.0f / JetGameValues::FeetPerWorldUnit() / 1000.f; // 2 ft per second is world realistic, 8 is more visible
				if (animate == true) // todo: change this to a render id
				{
					waterTextureS += (waterTextureSPerMS * timer->GetElapsedTimeMS());
					waterTextureT += (waterTextureTPerMS * timer->GetElapsedTimeMS());
				}
				if (waterTextureS < 0.0f)
					waterTextureS += 1.0f;
				if (waterTextureT < 0.0f)
					waterTextureT += 1.0f;
				if (waterTextureT > 1.0f)
					waterTextureT -= 1.0f;
				if (waterTextureT > 1.0f)
					waterTextureT -= 1.0f;
				//GameColor waterColor[1] = { GameColor(255, 255, 255, 235) }; // see-through with polygons
				GameColor waterColor[1] = { GameColor(255, 255, 255, 192) }; // see-through with texture
				ModelVertex waterVertices[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
				// water is at pixel color height 40 for heightmap1
				// put a z bias on the y's so we don't have depth fighting
				waterVertices[0].vertex.y = terrainWaterYWorldValue;
				waterVertices[1].vertex.y = terrainWaterYWorldValue;
				waterVertices[2].vertex.y = terrainWaterYWorldValue;
				waterVertices[3].vertex.y = terrainWaterYWorldValue;
				waterVertices[0].vertex.x = terrain->GetStartX();
				waterVertices[1].vertex.x = terrain->GetEndX();
				waterVertices[2].vertex.x = terrain->GetEndX();
				waterVertices[3].vertex.x = terrain->GetStartX();
				waterVertices[0].vertex.z = terrain->GetStartZ();
				waterVertices[1].vertex.z = terrain->GetStartZ();
				waterVertices[2].vertex.z = terrain->GetEndZ();
				waterVertices[3].vertex.z = terrain->GetEndZ();
				// water texture looks like 10 feet across of water, but make it 80 feet for grins
				graphics->RenderFilledQuad(waterColor, 1, waterVertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("Water"), nullptr, 0, waterTextureS, waterTextureT, (terrain->GetEndX() - terrain->GetStartX()) / waterTextureSizeFactor, (terrain->GetEndZ() - terrain->GetStartZ()) / waterTextureSizeFactor);

				// now render the decals on the water
				// todo:
				// make them drift with the water
				// make them fade away (new color, remove when gone)
				// expand them, adjust shape for being over edge (texture coordinates, etc.)
				// set zbias to prevent fighting with the water surface
				// depth writing OFF so they dont' fight with each other!
				// render each
				graphics->SetZBias(-1.0f, -1.0f);
				graphics->SetDepthWriteEnabled(false); // don't need depth now, the water takes care of the depth.  we're jsut rendering decals on it now
				if (usePolygonQueue == true)
				{
					*(polygonQueueOptions.mvpMatrixRef) = graphics->GetMVPMatrix();
				}
				LinkedListEnumerator<SurfaceDecal> waterDecalEnumerator = LinkedListEnumerator<SurfaceDecal>(*waterDecals);
				while (waterDecalEnumerator.MoveNext())
				{
					SurfaceDecal *decal = &(waterDecalEnumerator.Current()->data);
					if (decal->lifeMS > decal->maxLifeMS)
						decal->color.alpha = 0;
					else if (decal->lifeMS < 0)
						decal->color.alpha = 255;
					else
						decal->color.alpha = unsigned char(255.0f  * (float(decal->maxLifeMS - decal->lifeMS) / float(decal->maxLifeMS)));

					if (decal->color.alpha != 0)
					{
						if (usePolygonQueue == false)
							graphics->RenderFilledQuad(&(decal->color), 1, decal->vertices, 4, true, decal->textureRef);
						else
							graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, &(decal->color), 1, decal->vertices, 4, true, decal->textureRef);

						// animate it for next turn
						if (animate == true)
						{
							decal->center.x -= waterTextureXWorldPerMS * timer->GetElapsedTimeMSFloat();
							decal->center.z -= waterTextureZWorldPerMS * timer->GetElapsedTimeMSFloat();
							decal->width += waterTextureRadiusIncreasePerMS * timer->GetElapsedTimeMSFloat() * 2.0f;
							decal->height += waterTextureRadiusIncreasePerMS * timer->GetElapsedTimeMSFloat() * 2.0f;
							decal->CalculateVertices();
							decal->lifeMS += timer->GetElapsedTimeMS();
						}
					}
				}
				if (usePolygonQueue == true)
					graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);
				// get rid of alpha zero ripples
				if (finalScene == true)
				{
					LinkedListNode<SurfaceDecal> *waterDecalNode = waterDecals->GetFirstNode();
					if (waterDecalNode != nullptr)
					{
						while (waterDecalNode != &(waterDecals->footer))
						{
							if (waterDecalNode->data.color.alpha == 0)
							{
								// delete it!
								LinkedListNode<SurfaceDecal> *tempNode = waterDecalNode->next;
								waterDecals->DeleteNode(waterDecalNode);
								waterDecalNode = tempNode;
							}
							else
							{
								waterDecalNode = waterDecalNode->next;
							}
						}
					}
				}
				graphics->DisableZBias();
				graphics->SetDepthWriteEnabled(true);
#pragma endregion Render Water

#pragma region Water Fountains
				// Now that water surface is rendered, render the fountains on it and remove the fountains that are done
				graphics->SetClipPlane(0, Vector3d(0, terrainWaterYWorldValue, 0), Vector3d(0, 1, 0));
				graphics->SetDepthWriteEnabled(false); // ideally all alpha objects with a non-surface presence should be sorted back to front by now.  rendering with depth write off is faster
				if (usePolygonQueue == true)
				{
					*(polygonQueueOptions.mvpMatrixRef) = graphics->GetMVPMatrix();
				}
				LinkedListEnumerator<AlphaBillboard> waterFountainEnumerator = LinkedListEnumerator<AlphaBillboard>(*waterFountains);
				ModelVertex waterBillboardVertices[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
				while (waterFountainEnumerator.MoveNext())
				{
					AlphaBillboard *billboard = &(waterFountainEnumerator.Current()->data);

					// animate it
					if (animate == true)
					{
						float oldTopPortion = billboard->center.y + billboard->height / 4.0f;
						billboard->width += (billboard->widthAdjustPerMS * timer->GetElapsedTimeMSFloat());
						billboard->height += (billboard->heightAdjustPerMS * timer->GetElapsedTimeMSFloat());
						billboard->center = billboard->startCenter;
						billboard->center.y = billboard->startCenter.y + (billboard->startVelocity.y * float(billboard->lifeMS)) - (0.5f * JetGameValues::GravityAccelerationPerMSSquared() * float(billboard->lifeMS) * float(billboard->lifeMS)) + billboard->height / 2.0f;

						// make a new ripple for the fountain as it falls
						if ((oldTopPortion >= (terrainWaterYWorldValue)) && ((billboard->center.y + billboard->height / 4.0f) < (terrainWaterYWorldValue)))
						{
							LinkedListNode<SurfaceDecal> *newDecal = waterDecals->GetNewNode();
							newDecal->data.textureRef = GameContext::Instance->TextureRegistry.GetTexture("WaterRipple");
							newDecal->data.color = GameColor(224, 224, 255, 255); // very light blue

							newDecal->data.center = billboard->center;
							newDecal->data.center.y = terrainWaterYWorldValue;
							// base it on the falling fountain billboard size
							newDecal->data.width = billboard->width / 4.0f;
							newDecal->data.height = billboard->width / 4.0f;
							newDecal->data.vertices[0].colorIndex = 0;
							newDecal->data.vertices[1].colorIndex = 0;
							newDecal->data.vertices[2].colorIndex = 0;
							newDecal->data.vertices[3].colorIndex = 0;
							newDecal->data.lifeMS = 0;
							newDecal->data.maxLifeMS = 5000;
							newDecal->data.CalculateVertices();

							waterDecals->AddNode(newDecal);
						}
					}

					// don't render if under the water
					if ((billboard->center.y + billboard->height / 2.0f) > (terrainWaterYWorldValue))
					{
						Vector3d offset = billboard->center - (cameraOrient->p + eyePositionOffset); // billboard orient will face AWAY and render a backwards facing polygon
						offset.y = 0.0f; // force horizontal rotation
						if (offset.Normalize() == true)
						{
							Orient3d billboardOrient;
							billboardOrient.f = offset;
							billboardOrient.u = Vector3d(0, 1, 0);
							billboardOrient.l = billboardOrient.u.CrossProd(billboardOrient.f);
							billboardOrient.p = billboard->center;

							billboard->CalculateVertices(billboardOrient, waterBillboardVertices);
							// could have had the 3d renderer do this calculation for us, but whatever - actually for the screen graph for splitting alpha objects, non scaled world-positioned alpha objects are preferred
							if (usePolygonQueue == false)
								graphics->RenderFilledQuad(&(billboard->color), 1, waterBillboardVertices, 4, true, billboard->textureRef);
							else
								graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, &(billboard->color), 1, waterBillboardVertices, 4, true, billboard->textureRef);
						}
					}

					if (animate == true)
						billboard->lifeMS += timer->GetElapsedTimeMS();
				}
				if (usePolygonQueue == true)
					graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);

				// get rid of fountains under water
				if (finalScene == true)
				{
					LinkedListNode<AlphaBillboard> *waterFountainNode = waterFountains->GetFirstNode();
					if (waterFountainNode != nullptr)
					{
						while (waterFountainNode != &(waterFountains->footer))
						{
							if ((waterFountainNode->data.center.y + waterFountainNode->data.height / 2.0f) <= (terrainWaterYWorldValue))
							{
								// delete it!
								LinkedListNode<AlphaBillboard> *tempNode = waterFountainNode->next;
								waterFountains->DeleteNode(waterFountainNode);
								waterFountainNode = tempNode;
							}
							else
							{
								waterFountainNode = waterFountainNode->next;
							}
						}
					}
				}
				graphics->SetDepthWriteEnabled(true);
				graphics->DisableClipPlane(0);
#pragma endregion Water Fountains

#pragma region Smoke Trails
				bool renderSmokeTrails = true;
				if (renderSmokeTrails == true)
				{
					// for using polygon Queue
					Matrix4d mvpMatrix;
					if (usePolygonQueue == true)
					{
						mvpMatrix = graphics->GetMVPMatrix();
						polygonQueueOptions.mvpMatrixRef = &mvpMatrix;
					}

					graphics->SetDepthWriteEnabled(false);
					// parse as linked list instead of an enumerator because we will be deleting from it inside the loop
					LinkedListNode<AlphaTrail> *smokeTrailNode = smokeTrails->GetFirstNode();
					if (smokeTrailNode != nullptr)
					{
						GameColor smokeColors[2] = { GameColor(255, 255, 255, 255), GameColor(255, 255, 255, 255) };
						ModelVertex smokeVertices[4];
						GameTexture ^missileSmokeTexture = GameContext::Instance->TextureRegistry.GetTexture("MissileTileSmoke");
						while (smokeTrailNode != &(smokeTrails->footer))
						{
							if (animate == true)
								smokeTrailNode->data.FadeTrail(timer->GetElapsedTimeMS());

							if (smokeTrailNode->data.IsEmpty() == true)
							{
								// remove empty list
								LinkedListNode<AlphaTrail> *tempNode = smokeTrailNode->next;
								smokeTrails->DeleteNode(smokeTrailNode);
								smokeTrailNode = tempNode;
							}
							else
							{
								// render a list
								LinkedListEnumerator<AlphaTrailPoint> smokeTrailEnumerator = LinkedListEnumerator<AlphaTrailPoint>(smokeTrailNode->data);
								LinkedListNode<AlphaTrailPoint> *priorPoint = nullptr;
								while (smokeTrailEnumerator.MoveNext())
								{
									if (priorPoint != nullptr)
									{
										// set alphas - also make endpoints fade out so they don't end in block shapes
										if (smokeTrailEnumerator.Current() != smokeTrailNode->data.GetLastNode())
											smokeColors[0].alpha = smokeTrailEnumerator.Current()->data.alpha;
										else
											smokeColors[0].alpha = 0; // doesn't really matter since segments are 5ms apart
										if (priorPoint != smokeTrailNode->data.GetLastNode())
											smokeColors[1].alpha = priorPoint->data.alpha;
										else
											smokeColors[1].alpha = 0; // doesn't really matter since segments are 5ms apart

										smokeVertices[0].colorIndex = 0; // front left
										smokeVertices[1].colorIndex = 0; // front right
										smokeVertices[2].colorIndex = 1; // back right
										smokeVertices[3].colorIndex = 1; // back left

										float startRadius = 1.0f / JetGameValues::FeetPerWorldUnit();
										float expandRadiusPerMS = 0.5f / JetGameValues::FeetPerWorldUnit() / 1000.0f;
										if (smokeTrailNode->data.type == SmokeTrailType::VaporTrail)
										{
											startRadius = 0.50f / JetGameValues::FeetPerWorldUnit();
											expandRadiusPerMS = -0.25f / JetGameValues::FeetPerWorldUnit() / 1000.0f;
										}

										float frontRadius = startRadius + float(smokeTrailEnumerator.Current()->data.lifeMS) * expandRadiusPerMS;
										float backRadius = startRadius + float(priorPoint->data.lifeMS) * expandRadiusPerMS;
										if (smokeTrailEnumerator.Current() == smokeTrailNode->data.GetLastNode())
											frontRadius /= 2.0f; // narrow front endpoint - doesn't really matter since segments are 5ms apart
										if (priorPoint == smokeTrailNode->data.GetLastNode())
											backRadius /= 2.0f; // narrow back endpoint - doesn't really matter since segments are 5ms apart

										Orient3d billboardOrient;
										Vector3d offsetFrontPointFromCamera = smokeTrailEnumerator.Current()->data.location - (cameraOrient->p + eyePositionOffset);
										Vector3d offsetBackPointFromCamera = priorPoint->data.location - (cameraOrient->p + eyePositionOffset);
										// only render if in front
										if ((offsetFrontPointFromCamera * cameraOrient->f) > 0.0f || (offsetBackPointFromCamera * cameraOrient->f) > 0.0f)
										{
											billboardOrient.u = smokeTrailEnumerator.Current()->data.location - priorPoint->data.location; // up axis is along travel line of quad
											if (billboardOrient.u.Normalize() == true)
											{
												billboardOrient.l = billboardOrient.u.CrossProd(offsetFrontPointFromCamera); // can be front or back, doesn't matter
												if (billboardOrient.l.Normalize() == true)
												{
													smokeVertices[0].vertex = smokeTrailEnumerator.Current()->data.location + billboardOrient.l.ScalarMult(frontRadius);
													smokeVertices[1].vertex = smokeTrailEnumerator.Current()->data.location - billboardOrient.l.ScalarMult(frontRadius);
													smokeVertices[2].vertex = priorPoint->data.location - billboardOrient.l.ScalarMult(backRadius);
													smokeVertices[3].vertex = priorPoint->data.location + billboardOrient.l.ScalarMult(backRadius);

													//graphics->RenderLineStrip(2.0f, smokeColors, 2, smokeVertices, 2, true);
													float lengthFactor = 10.0f; // repeat texture every 100 feet
													float startT = smokeTrailEnumerator.Current()->data.totalLength / lengthFactor;
													float scaleT = -(smokeTrailEnumerator.Current()->data.totalLength - priorPoint->data.totalLength) / lengthFactor; // render as much as is extending from prior point to this one
													if (renderSmokeTrails == true) // another if here to test speed of the calculations
													{
														if (usePolygonQueue == false)
														{
															graphics->RenderFilledQuad(smokeColors, 2, smokeVertices, 4, true, missileSmokeTexture, nullptr, 0, 0.0f, startT, 1.0f, scaleT);
														}
														else
														{
															graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, smokeColors, 2, smokeVertices, 4, true, missileSmokeTexture, nullptr, 0, 0.0f, startT, 1.0f, scaleT);
														}
													}
												}
											}
										}
									}
									priorPoint = smokeTrailEnumerator.Current();
								}
								// advance
								smokeTrailNode = smokeTrailNode->next;
							}
						}

						if (usePolygonQueue == true)
							graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);
					}

					graphics->SetDepthWriteEnabled(true);
				}
#pragma endregion Smoke Trails

#pragma region Particles
				bool renderParticles = true;
				if (renderParticles == true)
				{
					graphics->SetDepthWriteEnabled(false);
					graphics->PushMatrix();
					graphics->DefaultTransform();

					GraphicsShaderParticlesOptions particleOptions;
					Matrix4d mvpMatrix;
					if (useParticleQueue == true)
					{
						if (p_camera != nullptr)
						{
							if (p_left == true)
								graphics->DefaultTransformStereoscopicLeft(*p_camera);
							else
								graphics->DefaultTransformStereoscopicRight(*p_camera);
						}
						graphics->ReverseTransform(*cameraOrient);
						mvpMatrix = graphics->GetMVPMatrix();
						particleOptions.mvpMatrixRef = &mvpMatrix;
						particleOptions.leftVPAxisRef = &(cameraOrient->l);
						particleOptions.upVPAxisRef = &(cameraOrient->u);
						particleOptions.textures[0] = GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");
						particleOptions.minimumZ = 0.01f; // corresponds to sort criteria limit
					}

					VolumePartitionSection<LinkedList<Particle>> *cameraSection = particlePartition->GetPartitionSection(cameraOrient->p.x, cameraOrient->p.y, cameraOrient->p.z);
					// Render particles in outer sections and work inward to cameraSection on all axes
					for (int x = 0; x < cameraSection->xIndex; x++)
					{
						for (int y = 0; y < cameraSection->yIndex; y++)
						{
							for (int z = 0; z < cameraSection->zIndex; z++)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, cameraSection->zIndex)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int y = particlePartition->ySectionQty - 1; y > cameraSection->yIndex; y--)
						{
							for (int z = 0; z < cameraSection->zIndex; z++)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, cameraSection->zIndex)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int z = 0; z < cameraSection->zIndex; z++)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, cameraSection->yIndex, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, cameraSection->yIndex, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, cameraSection->yIndex, cameraSection->zIndex)->data);
						RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
					}
					for (int x = particlePartition->xSectionQty - 1; x > cameraSection->xIndex; x--)
					{
						for (int y = 0; y < cameraSection->yIndex; y++)
						{
							for (int z = 0; z < cameraSection->zIndex; z++)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, cameraSection->zIndex)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int y = particlePartition->ySectionQty - 1; y > cameraSection->yIndex; y--)
						{
							for (int z = 0; z < cameraSection->zIndex; z++)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
							{
								LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, z)->data);
								RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
							}
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, y, cameraSection->zIndex)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int z = 0; z < cameraSection->zIndex; z++)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, cameraSection->yIndex, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, cameraSection->yIndex, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(x, cameraSection->yIndex, cameraSection->zIndex)->data);
						RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
					}
					for (int y = 0; y < cameraSection->yIndex; y++)
					{
						for (int z = 0; z < cameraSection->zIndex; z++)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, y, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, y, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, y, cameraSection->zIndex)->data);
						RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
					}
					for (int y = particlePartition->ySectionQty - 1; y > cameraSection->yIndex; y--)
					{
						for (int z = 0; z < cameraSection->zIndex; z++)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, y, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
						{
							LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, y, z)->data);
							RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
						}
						LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, y, cameraSection->zIndex)->data);
						RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
					}
					for (int z = 0; z < cameraSection->zIndex; z++)
					{
						LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, cameraSection->yIndex, z)->data);
						RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
					}
					for (int z = particlePartition->zSectionQty - 1; z > cameraSection->zIndex; z--)
					{
						LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, cameraSection->yIndex, z)->data);
						RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);
					}
					LinkedList<Particle> *particles = &(particlePartition->GetPartitionSectionByIndex(cameraSection->xIndex, cameraSection->yIndex, cameraSection->zIndex)->data);
					RenderParticles(particles, graphics, cameraOrient, particleOptions, animate, eyePositionOffset);

					if (useParticleQueue == true && smokeParticleQueue != nullptr)
						graphics->CommitParticleQueue(smokeParticleQueue, particleOptions);

					graphics->PopMatrix();
					graphics->SetDepthWriteEnabled(true);
				}
#pragma endregion Particles

#pragma region Engine Flames
				graphics->SetDepthWriteEnabled(false);
				graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One); // additive!
				if (usePolygonQueue == true)
					*(polygonQueueOptions.mvpMatrixRef) = graphics->GetMVPMatrix();
				gameObjectEnumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
				while (gameObjectEnumerator.MoveNext())
				{
					if (gameObjectEnumerator.Current()->data.deleted == true)
						continue;
					if (gameObjectEnumerator.Current()->data.dead == true)
						continue;

					static FastRandom fastRandom;
					switch (gameObjectEnumerator.Current()->data.objectType)
					{
					case JetGameObjectEnum::Jet:
					{
						// don't render jet if it is where the camera is at
						if ((userControlJetRef != &(gameObjectEnumerator.Current()->data) || cameraTrackTargetFromUserJet == true || (joystick->values.valid == true && joystick->values.povAngle != 0)) && cameraJetRef != &(gameObjectEnumerator.Current()->data))
						{
							// don't vary flames if paused
							// todo: This doesn't preserve the jet flames for left and right eye!  We must store the values on the jet object and reuse them!
							// flameIntensity, offset1Main and offset2Main must be calculated and stored on the jet during animate, then used for the render outside of animate!
							if (timer->GetElapsedTimeMS() > 0 && animate == true)
							{
								// determine rand color intensity of engine grid
								float factor = float(fastRandom.GetRandomInteger(0, 100)) / 100.0f;
								// random between intense color and hot white
								gameObjectEnumerator.Current()->data.flameIntensity = GameColor::Interpolate(GameColor(1, 145, 253, 128), GameColor(255, 255, 255, 128), factor);

								// determine random texture coordinates for rendering to give flames variance
								float degrees = float(fastRandom.GetRandomInteger(0, 359));
								float radians1 = MathUtilities::DegreesToRadians(degrees + 45.0f);
								float radians2 = MathUtilities::DegreesToRadians(degrees - 45.0f);
								gameObjectEnumerator.Current()->data.flameOffset1Main = Vector3d(sin(radians1), cos(radians1), 0.0f);
								gameObjectEnumerator.Current()->data.flameOffset2Main = Vector3d(sin(radians2), cos(radians2), 0.0f);
							}

							// render it!
							float flameLength = 2.0f * gameObjectEnumerator.Current()->data.actualThrust / JetGameValues::AfterburnerThrust();
							Orient3d enginePosition = gameObjectEnumerator.Current()->data.orient;
							// place engine where it belongs according to parent
							enginePosition.p = enginePosition.p + enginePosition.f.ScalarMult(-1.0f) + enginePosition.u.ScalarMult(-0.10f);
							float radius = 0.5f;

							jetEngineFlame->GetColor(0)->Set(gameObjectEnumerator.Current()->data.flameIntensity);

							Vector3d origin = Vector3d(0.5f, 0.5f, 0.0f);
							float s1 = (origin + gameObjectEnumerator.Current()->data.flameOffset1Main.ScalarMult(radius)).x;
							float t1 = (origin + gameObjectEnumerator.Current()->data.flameOffset1Main.ScalarMult(radius)).y;
							float s2 = (origin + gameObjectEnumerator.Current()->data.flameOffset2Main.ScalarMult(radius)).x;
							float t2 = (origin + gameObjectEnumerator.Current()->data.flameOffset2Main.ScalarMult(radius)).y;
							float s3 = (origin + gameObjectEnumerator.Current()->data.flameOffset2Main.ScalarMult(radius / 2.0f)).x;
							float t3 = (origin + gameObjectEnumerator.Current()->data.flameOffset2Main.ScalarMult(radius / 2.0f)).y;
							float s4 = (origin + gameObjectEnumerator.Current()->data.flameOffset1Main.ScalarMult(radius / 2.0f)).x;
							float t4 = (origin + gameObjectEnumerator.Current()->data.flameOffset1Main.ScalarMult(radius / 2.0f)).y;
							// todo: despite the * 2.0f originally placed on the short end of the trapezoid for texture usage, the texture mapping is still deformed.
							jetEngineFlame->GetSurface(1)->SetVertexTexCoords(0, s1, t1, jetEngineFlame->GetSurface(1)->GetVertexTexCoords(0).q);
							jetEngineFlame->GetSurface(1)->SetVertexTexCoords(1, s2, t2, jetEngineFlame->GetSurface(1)->GetVertexTexCoords(1).q);
							jetEngineFlame->GetSurface(1)->SetVertexTexCoords(2, s3, t3, jetEngineFlame->GetSurface(1)->GetVertexTexCoords(2).q);
							jetEngineFlame->GetSurface(1)->SetVertexTexCoords(3, s4, t4, jetEngineFlame->GetSurface(1)->GetVertexTexCoords(3).q);
							jetEngineFlame->GetSurface(2)->SetVertexTexCoords(0, s1, t1);
							jetEngineFlame->GetSurface(2)->SetVertexTexCoords(1, s2, t2);
							jetEngineFlame->GetSurface(3)->SetVertexTexCoords(0, s1, t1, jetEngineFlame->GetSurface(3)->GetVertexTexCoords(0).q);
							jetEngineFlame->GetSurface(3)->SetVertexTexCoords(1, s2, t2, jetEngineFlame->GetSurface(3)->GetVertexTexCoords(1).q);
							jetEngineFlame->GetSurface(3)->SetVertexTexCoords(2, s3, t3, jetEngineFlame->GetSurface(3)->GetVertexTexCoords(2).q);
							jetEngineFlame->GetSurface(3)->SetVertexTexCoords(3, s4, t4, jetEngineFlame->GetSurface(3)->GetVertexTexCoords(3).q);
							jetEngineFlame->GetSurface(4)->SetVertexTexCoords(0, s1, t1);
							jetEngineFlame->GetSurface(4)->SetVertexTexCoords(1, s2, t2);
							jetEngineFlame->GetSurface(5)->SetVertexTexCoords(0, s1, t1, jetEngineFlame->GetSurface(5)->GetVertexTexCoords(0).q);
							jetEngineFlame->GetSurface(5)->SetVertexTexCoords(1, s2, t2, jetEngineFlame->GetSurface(5)->GetVertexTexCoords(1).q);
							jetEngineFlame->GetSurface(5)->SetVertexTexCoords(2, s3, t3, jetEngineFlame->GetSurface(5)->GetVertexTexCoords(2).q);
							jetEngineFlame->GetSurface(5)->SetVertexTexCoords(3, s4, t4, jetEngineFlame->GetSurface(5)->GetVertexTexCoords(3).q);
							jetEngineFlame->GetSurface(6)->SetVertexTexCoords(0, s1, t1);
							jetEngineFlame->GetSurface(6)->SetVertexTexCoords(1, s2, t2);
							jetEngineFlame->GetSurface(7)->SetVertexTexCoords(0, s1, t1, jetEngineFlame->GetSurface(7)->GetVertexTexCoords(0).q);
							jetEngineFlame->GetSurface(7)->SetVertexTexCoords(1, s2, t2, jetEngineFlame->GetSurface(7)->GetVertexTexCoords(1).q);
							jetEngineFlame->GetSurface(7)->SetVertexTexCoords(2, s3, t3, jetEngineFlame->GetSurface(7)->GetVertexTexCoords(2).q);
							jetEngineFlame->GetSurface(7)->SetVertexTexCoords(3, s4, t4, jetEngineFlame->GetSurface(7)->GetVertexTexCoords(3).q);
							jetEngineFlame->GetSurface(8)->SetVertexTexCoords(0, s1, t1);
							jetEngineFlame->GetSurface(8)->SetVertexTexCoords(1, s2, t2);

							// todo: make it native by building and submitting a list of polygons to the polygon queue
							if (usePolygonQueue == false)
							{
								graphics->PushMatrix();
								graphics->Transform(enginePosition);
								graphics->Scale(1.0f, 1.0f, flameLength);
								jetEngineFlame->Render(*graphics);
								graphics->PopMatrix();
							}
							else
							{
								graphics->SubmitModelToPolygonQueue(polygonQueue, polygonQueueOptions, jetEngineFlame->GetColors(), jetEngineFlame->GetColorQty(), jetEngineFlame->GetSurfaces(), jetEngineFlame->GetSurfaceQty(), jetEngineFlame->GetVertices(), jetEngineFlame->GetVertexQty(), enginePosition, Vector3d(1.0f, 1.0f, flameLength));
							}
						}
					}
					break;
					case JetGameObjectEnum::Missile:
					{
						if (gameObjectEnumerator.Current()->data.setThrust > 0.0f)
						{
							// render missile version of engine flame
							Orient3d enginePosition = gameObjectEnumerator.Current()->data.orient;
							// place engine where it belongs according to parent
							enginePosition.p = enginePosition.p + enginePosition.f.ScalarMult(-0.201f); // 2 feet back (4 feet long missile), with a little bias
							float flameLength = 0.6f * gameObjectEnumerator.Current()->data.setThrust / JetGameValues::LightAirMissileThrust(); // 6 foot flame

							// flames on missile are so small, don't bother varying them
							// but DO vary the intensity
							// don't vary flames if paused
							if (timer->GetElapsedTimeMS() > 0 && animate == true)
							{
								float factor = float(fastRandom.GetRandomInteger(0, 100)) / 100.0f;
								// random between intense color and hot white
								GameColor flameIntensity = GameColor::Interpolate(GameColor(1, 145, 253, 128), GameColor(255, 255, 255, 128), factor);
								missileEngineFlame->GetColor(0)->Set(flameIntensity);
							}

							if (usePolygonQueue == false)
							{
								graphics->PushMatrix();
								graphics->Transform(enginePosition);
								graphics->Scale(1.0f, 1.0f, flameLength);
								missileEngineFlame->Render(*graphics);
								graphics->PopMatrix();
							}
							else
							{
								graphics->SubmitModelToPolygonQueue(polygonQueue, polygonQueueOptions, missileEngineFlame->GetColors(), missileEngineFlame->GetColorQty(), missileEngineFlame->GetSurfaces(), missileEngineFlame->GetSurfaceQty(), missileEngineFlame->GetVertices(), missileEngineFlame->GetVertexQty(), enginePosition, Vector3d(1.0f, 1.0f, flameLength));
							}

							// render a z-hidden flare with the same color as the flame
							Vector3d flarePosition = enginePosition.p + gameObjectEnumerator.Current()->data.orient.f.ScalarMult(-0.05f); // 6 inches further back
							Vector3d renderOffset = cameraOrient->TransformToOrientSpace(flarePosition);
							ModelVertex flareVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
							// for use with polygon queue
							ModelVertex flarePolygonVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
							if (renderOffset.z > 0.01f)
							{
								float radius = 0.75f * float(missileEngineFlame->GetColor(0)->green) / 255.0f;

								if (usePolygonQueue == false)
								{
									graphics->PushMatrix();
									graphics->DefaultTransform();
									graphics->Translate(renderOffset.x, renderOffset.y, renderOffset.z);
									graphics->Scale(radius, radius, 1.0f);
									graphics->RenderFilledQuad(missileEngineFlame->GetColor(0), 1, flareVertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("Flare"));
									graphics->PopMatrix();
								}
								else
								{
									flarePolygonVertices[0].vertex = flarePosition + cameraOrient->l.ScalarMult(radius) + cameraOrient->u.ScalarMult(radius);
									flarePolygonVertices[1].vertex = flarePosition - cameraOrient->l.ScalarMult(radius) + cameraOrient->u.ScalarMult(radius);
									flarePolygonVertices[2].vertex = flarePosition - cameraOrient->l.ScalarMult(radius) - cameraOrient->u.ScalarMult(radius);
									flarePolygonVertices[3].vertex = flarePosition + cameraOrient->l.ScalarMult(radius) - cameraOrient->u.ScalarMult(radius);
									graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, missileEngineFlame->GetColor(0), 1, flarePolygonVertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("Flare"));
								}
							}
						}
					}
					break;
					} // switch
				}
				if (usePolygonQueue == true)
					graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);
				graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One_Minus_Source_Alpha);
				graphics->SetDepthWriteEnabled(true);
#pragma endregion Engine Flames

#pragma region Fast Effects
				// fast effects don't last long so they don't need special partitioning maintenance
				// for now we won't even sort them
				graphics->SetDepthWriteEnabled(false);
				graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One);
				graphics->PushMatrix();
				graphics->DefaultTransform();

				if (usePolygonQueue == true)
				{
					*(polygonQueueOptions.mvpMatrixRef) = graphics->GetMVPMatrix();
				}
				ModelVertex effectVertices[4] = { ModelVertex(Vector3d(1, 1, 0), 0), ModelVertex(Vector3d(-1, 1, 0), 0), ModelVertex(Vector3d(-1, -1, 0), 0), ModelVertex(Vector3d(1, -1, 0), 0) };
				// used for polygonqueue
				ModelVertex effectPolygonVertices[4] = { ModelVertex(Vector3d(1, 1, 0), 0), ModelVertex(Vector3d(-1, 1, 0), 0), ModelVertex(Vector3d(-1, -1, 0), 0), ModelVertex(Vector3d(1, -1, 0), 0) };
				LinkedListNode<EnergyEffect> *energyNode = fastEffects->GetFirstNode();
				if (energyNode != nullptr)
				{
					while (energyNode != &(fastEffects->footer))
					{
						bool deleted = false;
						bool valid = true; // is it even possible to render?
						bool expired = false; // rendered but now get rid of it?

						// so that single effects will render on a pause
						// do this on animate (first scene), not final scene, since rendered was set at end of animate last frame
						if (animate == true && energyNode->data.rendered == true && energyNode->data.animationType == EnergyEffectAnimationTypeEnum::SingleFrame && timer->GetElapsedTimeMS() > 0)
							expired = true;

						// calculate position
						if (expired == false)
						{
							switch (energyNode->data.positionType)
							{
							case EnergyEffectPositionTypeEnum::OrientSpace:
								if (energyNode->data.parentRef.IsValid() && energyNode->data.parentRef.IsDeleted() == false)
								{
									energyNode->data.renderCenter = ((JetGameObject *)(energyNode->data.parentRef.Ptr()))->orient.TransformToWorldSpace(energyNode->data.spacePosition);
								}
								else
									valid = false;
								break;
							case EnergyEffectPositionTypeEnum::OrientPosition:
								if (energyNode->data.parentRef.IsValid() && energyNode->data.parentRef.IsDeleted() == false)
								{
									energyNode->data.renderCenter = ((JetGameObject *)(energyNode->data.parentRef.Ptr()))->orient.p + energyNode->data.spacePosition;
								}
								else
									valid = false;
								break;
							case EnergyEffectPositionTypeEnum::World:
								energyNode->data.renderCenter = energyNode->data.spacePosition; // no parent
								break;
							}
						}

						if (expired == false && valid == true)
						{
							// render it!
							Orient3d trueCameraOrient = *cameraOrient;
							trueCameraOrient.p = trueCameraOrient.p + eyePositionOffset;
							Vector3d offset = trueCameraOrient.TransformToOrientSpace(energyNode->data.renderCenter);
							if (offset.z > 0.00001f)
							{
								if (useParticleQueue == false)
								{
									graphics->PushMatrix();
									graphics->Translate(offset.x, offset.y, offset.z);
									graphics->Rotate(energyNode->data.degreeRotation, Vector3d(0, 0, 1));
									graphics->Scale(energyNode->data.radius, energyNode->data.radius, 1.0f);
									graphics->RenderFilledQuad(&(energyNode->data.color), 1, effectVertices, 4, true, energyNode->data.textureRef);
									graphics->PopMatrix();
								}
								else
								{
									// build a polygon out of the values and submit it
									Orient3d effectOrient;
									effectOrient.LoadIdentity();
									effectOrient.p = offset;
									effectOrient.Rotate(effectOrient.f, energyNode->data.degreeRotation);
									effectPolygonVertices[0].vertex = effectOrient.p + effectOrient.l.ScalarMult(energyNode->data.radius) + effectOrient.u.ScalarMult(energyNode->data.radius);
									effectPolygonVertices[1].vertex = effectOrient.p - effectOrient.l.ScalarMult(energyNode->data.radius) + effectOrient.u.ScalarMult(energyNode->data.radius);
									effectPolygonVertices[2].vertex = effectOrient.p - effectOrient.l.ScalarMult(energyNode->data.radius) - effectOrient.u.ScalarMult(energyNode->data.radius);
									effectPolygonVertices[3].vertex = effectOrient.p + effectOrient.l.ScalarMult(energyNode->data.radius) - effectOrient.u.ScalarMult(energyNode->data.radius);
									graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, &(energyNode->data.color), 1, effectPolygonVertices, 4, true, energyNode->data.textureRef);
								}
							}

							// we at least tried to - single frame effects must be removed
							energyNode->data.rendered = true;
						}

						// get rid of it if it's only for one frame or it's no longer valid or it was rendered and is now expired
						if (valid == false || expired == true)
						{
							LinkedListNode<EnergyEffect> *tempNode = energyNode->next;
							fastEffects->DeleteNode(energyNode);
							energyNode = tempNode;
							deleted = true;
						}

						if (deleted == false)
						{
							energyNode = energyNode->next;
						}
					}

					if (usePolygonQueue == true)
						graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);
				}
				graphics->PopMatrix();
				// put old blending back
				graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One_Minus_Source_Alpha);
				graphics->SetDepthWriteEnabled(true);
#pragma endregion Fast Effects

#pragma region Bullets
				GameTexture ^bulletTexture = GameContext::Instance->TextureRegistry.GetTexture("JetBullet");
				GameColor bulletColorNight[1] = { GameColor(216, 164, 119) }; // nighttime shot color, we'll see how this looks in daylight
				GameColor bulletColorDay[1] = { GameColor(236, 236, 90) }; // daytime shot color
				//GameColor bulletColorDay[1] = { GameColor(255, 255, 128) }; // daytime shot color
				//GameColor bulletColorDay[1] = { GameColor(255, 255, 192) }; // daytime shot color
				// polygon facing backwards
				ModelVertex bulletVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
				// for use with polygon queue
				ModelVertex bulletPolygonVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };

				if (usePolygonQueue == true)
				{
					*(polygonQueueOptions.mvpMatrixRef) = graphics->GetMVPMatrix();
				}
				graphics->SetDepthWriteEnabled(false);
				// additive blending!
				graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One);
				gameObjectEnumerator = LinkedListEnumerator<JetGameObject>(*bulletList);
				while (gameObjectEnumerator.MoveNext())
				{
					if (gameObjectEnumerator.Current()->data.alphaRender == false)
						continue;

					switch (gameObjectEnumerator.Current()->data.objectType)
					{
					case JetGameObjectEnum::Bullet:
					{
						JetGameObject *bullet = &(gameObjectEnumerator.Current()->data);
						bool renderAsCircle = false;

						Vector3d bulletVelocity = bullet->velocity;

						if (bulletVelocity.Normalize() == false)
							renderAsCircle = true;
						else
						{
							Vector3d offsetFromCamera = bullet->orient.p - (cameraOrient->p + eyePositionOffset);
							if (offsetFromCamera.Normalize() == true)
							{
								if ((bulletVelocity * offsetFromCamera) > 0.9999f) // this looks good, nice transition from long texture to circle
									renderAsCircle = true;
								else
								{
									// render it as a billboard lying along the velocity line with the texture surface pointing right at the camera
									Vector3d lAxis = offsetFromCamera.ScalarMult(-1.0f).CrossProd(bulletVelocity);
									lAxis.Normalize();
									Vector3d fAxis = lAxis.CrossProd(bulletVelocity);
									Orient3d billboardOrient = Orient3d(lAxis, bulletVelocity, fAxis, bullet->orient.p);

									if (usePolygonQueue == false)
									{
										graphics->PushMatrix();
										graphics->Transform(billboardOrient);
										graphics->Scale(0.035f, (bulletVelocity * bullet->velocity) * 20.0f, 0.035f); // lengthened texture, longer for fast velocities, same x/z dimension as circle
										graphics->RenderFilledQuad(bulletColorDay, 1, bulletVertices, 4, true, bulletTexture);
										graphics->PopMatrix();
									}
									else
									{
										// build a polygon out of the values and submit it
										float uScale = (bulletVelocity * bullet->velocity) * 20.0f;
										bulletPolygonVertices[0].vertex = billboardOrient.p + billboardOrient.l.ScalarMult(0.035f) + billboardOrient.u.ScalarMult(uScale);
										bulletPolygonVertices[1].vertex = billboardOrient.p - billboardOrient.l.ScalarMult(0.035f) + billboardOrient.u.ScalarMult(uScale);
										bulletPolygonVertices[2].vertex = billboardOrient.p - billboardOrient.l.ScalarMult(0.035f) - billboardOrient.u.ScalarMult(uScale);
										bulletPolygonVertices[3].vertex = billboardOrient.p + billboardOrient.l.ScalarMult(0.035f) - billboardOrient.u.ScalarMult(uScale);
										graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, bulletColorDay, 1, bulletPolygonVertices, 4, true, bulletTexture);
									}
								}
							}
						}

						if (renderAsCircle == true)
						{
							Orient3d bulletRelativeOrient;
							bulletRelativeOrient.LoadIdentity();
							bulletRelativeOrient.p = cameraOrient->TransformToOrientSpace(bullet->orient.p);

							// render as little circle
							if (bulletRelativeOrient.p.z > 0.00001f)
							{
								if (usePolygonQueue == false)
								{
									graphics->PushMatrix();
									graphics->DefaultTransform();
									graphics->Transform(bulletRelativeOrient);
									graphics->Scale(0.035f, 0.035f, 0.035f); // <1ftx1ft bullettexture for visibility, for now
									graphics->RenderFilledQuad(bulletColorDay, 1, bulletVertices, 4, true, bulletTexture);
									graphics->PopMatrix();
								}
								else
								{
									// build a polygon out of the values and submit it
									bulletPolygonVertices[0].vertex = bullet->orient.p + cameraOrient->l.ScalarMult(0.035f) + cameraOrient->u.ScalarMult(0.035f);
									bulletPolygonVertices[1].vertex = bullet->orient.p - cameraOrient->l.ScalarMult(0.035f) + cameraOrient->u.ScalarMult(0.035f);
									bulletPolygonVertices[2].vertex = bullet->orient.p - cameraOrient->l.ScalarMult(0.035f) - cameraOrient->u.ScalarMult(0.035f);
									bulletPolygonVertices[3].vertex = bullet->orient.p + cameraOrient->l.ScalarMult(0.035f) - cameraOrient->u.ScalarMult(0.035f);
									graphics->SubmitPolygonToQueue(polygonQueue, polygonQueueOptions, bulletColorDay, 1, bulletPolygonVertices, 4, true, bulletTexture);
								}
							}
						}
					}
					break;
					}
				}
				if (usePolygonQueue == true)
					graphics->CommitPolygonQueue(polygonQueue, polygonQueueOptions);
				// put old blending back
				graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One_Minus_Source_Alpha);
				graphics->SetDepthWriteEnabled(true);
#pragma endregion Bullets

#pragma region Reticles
				///////////////////////
				// render 2d stuff at 1.0f z distance
				graphics->DefaultTransform();
				graphics->Translate(0.0f, 0.0f, 1.0f);
				graphics->SetDepthTestEnabled(false);
				graphics->SetDepthWriteEnabled(false);

				GameColor mainReticleColors[2] = { GameColor(0, 192, 90), GameColor(0, 192, 90, 0) };
				GameColor brightReticleColors[2] = { GameColor(255, 255, 0), GameColor(255, 255, 0, 0) };
				GameColor brightReticleColorsFaint[2] = { GameColor(255, 255, 0, 128), GameColor(255, 255, 0, 0) };
				GameColor reticleTargetingEnemyColors[2] = { GameColor(192, 0, 0), GameColor(192, 0, 0, 0) };
				GameColor reticleTargetingEnemyTargetingSelfColors[2] = { GameColor(192, 192, 0), GameColor(192, 192, 0, 0) };
				float mainReticleLineWidth = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 350.0f; // use height because that determines the size of everything (zoom angle determined by angle across vertical axis of screen)
				if (userControlJetRef != nullptr && userControlJetRef->dead == false && userControlJetRef->deleted == false && renderReticles == true)
				{
					graphics->PushMatrix();

					graphics->DefaultTransform();
					graphics->Translate(userControlJetRef->damageReticleWaggle.x, userControlJetRef->damageReticleWaggle.y, 1.0f);

					// reduce waggle
					int elapsedTimeMS = timer->GetElapsedTimeMS();
					while (elapsedTimeMS > 5)
					{
						userControlJetRef->damageReticleWaggle = userControlJetRef->damageReticleWaggle.ScalarMult(0.9f);
						elapsedTimeMS -= 5;
					}

					// render center reticle (at pov 0 this will be rendered center)
					Vector3d centerReticlePosition = cameraOrient->TransformToOrientSpace(userControlJetRef->orient.f + userControlJetRef->orient.p);
					if (centerReticlePosition.z > 0.00001f)
					{
						centerReticlePosition = centerReticlePosition.ScalarMult(1.0f / centerReticlePosition.z);
						graphics->PushMatrix();
						graphics->Translate(centerReticlePosition.x, centerReticlePosition.y, 0.0f);
						ModelVertex centerRightVertices[4] = { ModelVertex(Vector3d(0.5f, 1.0f, 0.0f), 1), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(0.5f, -1.0f, 0.0f), 1) };
						ModelVertex centerLeftVertices[4] = { ModelVertex(Vector3d(-0.5f, 1.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(-0.5f, -1.0f, 0.0f), 1) };
						graphics->Scale(0.02f, 0.02f, 1.0f);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, centerRightVertices, 4, true);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, centerLeftVertices, 4, true);
						graphics->PopMatrix();
					}

					// render travel reticle
					Vector3d travelVector = cameraOrient->TransformToOrientSpace(userControlJetRef->velocity + userControlJetRef->orient.p);
					if (travelVector.z >= 0.00001f)
					{
						travelVector = travelVector.ScalarMult(1.0f / travelVector.z);
						graphics->PushMatrix();
						graphics->Translate(travelVector.x, travelVector.y, 0.0f);
						ModelVertex travelBottomVertices[2] = { ModelVertex(Vector3d(-0.7f, -0.2f, 0.0f), 0), ModelVertex(Vector3d(0.7f, -0.2f, 0.0f), 0) };
						ModelVertex travelCenterLeftVertices[2] = { ModelVertex(Vector3d(0.0f, -0.2f, 0.0f), 0), ModelVertex(Vector3d(0.0f, 0.2f, 0.0f), 0) };
						graphics->Scale(0.02f, 0.02f, 1.0f);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, travelBottomVertices, 2, true);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, travelCenterLeftVertices, 2, true);
						graphics->PopMatrix();
					}

					// render target reticle
#pragma region Jet Target Reticle
					if (userControlJetRef->targetRef.Ptr() != nullptr)
					{
						if (userControlJetRef->targetRef.IsDeleted() == false && ((JetGameObject *)(userControlJetRef->targetRef.Ptr()))->dead == false)
						{
							// determine color of indicators for this target
							GameColor *targetReticleColors;
							if (((JetGameObject *)(userControlJetRef->targetRef.Ptr()))->alliance != userControlJetRef->alliance && ((JetGameObject *)(userControlJetRef->targetRef.Ptr()))->targetRef.Ptr() == userControlJetRef)
							{
								targetReticleColors = reticleTargetingEnemyTargetingSelfColors;
							}
							else if (((JetGameObject *)(userControlJetRef->targetRef.Ptr()))->alliance != userControlJetRef->alliance)
							{
								targetReticleColors = reticleTargetingEnemyColors;
							}
							else
							{
								targetReticleColors = mainReticleColors;
							}

							Vector3d targetOffset = cameraOrient->TransformToOrientSpace((((JetGameObject *)(userControlJetRef->targetRef.Ptr()))->orient.p));
							float distanceZ = targetOffset.z;
							bool renderDirectorReticle = false;
							Vector3d directorOffset;
							float maxDistanceOffCenter = 0.4f;
							float maxDirectorOutOfViewFactor = 1.0f;
							float directorOutOfViewFactor = 0.0f;
							if (distanceZ > 0.00001f)
							{
								targetOffset = targetOffset.ScalarMult(1.0f / distanceZ);
								float distanceOffCenter = sqrt(targetOffset.x*targetOffset.x + targetOffset.y*targetOffset.y);

								// render targetting reticle in front regardless, add director on top if necessary
								graphics->PushMatrix();
								graphics->Translate(targetOffset.x, targetOffset.y, 0.0f);
								float scaleNumeratorX = 1.0f; // differs depending on target
								float scaleNumeratorY = 1.0f; // differs depending on target
								// todo: min and max size too
								// todo: render alternate side reticle that directs player to target and gets smaller the closer the target is to being in view
								graphics->Scale(scaleNumeratorX / distanceZ, scaleNumeratorY / distanceZ, 1.0f);
								ModelVertex targetLRVertices[3] = { ModelVertex(Vector3d(-1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, -1.0f, 0.0f), 1) };
								ModelVertex targetLLVertices[3] = { ModelVertex(Vector3d(1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, -1.0f, 0.0f), 1) };
								ModelVertex targetULVertices[3] = { ModelVertex(Vector3d(-1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, 1.0f, 0.0f), 1) };
								ModelVertex targetURVertices[3] = { ModelVertex(Vector3d(1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, 1.0f, 0.0f), 1) };
								graphics->RenderLineStrip(mainReticleLineWidth, targetReticleColors, 2, targetLRVertices, 3, true);
								graphics->RenderLineStrip(mainReticleLineWidth, targetReticleColors, 2, targetLLVertices, 3, true);
								graphics->RenderLineStrip(mainReticleLineWidth, targetReticleColors, 2, targetULVertices, 3, true);
								graphics->RenderLineStrip(mainReticleLineWidth, targetReticleColors, 2, targetURVertices, 3, true);
								graphics->PopMatrix();

								if (distanceOffCenter > maxDistanceOffCenter) // around 30 degrees off center
								{
									renderDirectorReticle = true;
									// render a director reticle instead, distance between arrows based on angle
									// todo: it jerks at the 90 degree mark - make it smooth
									float minAngle = MathUtilities::RadiansToDegrees(atan(maxDistanceOffCenter));
									float maxAngle = 80.0f; // for some reason 90 degrees jerks about at the limit, probably related to the 0.00001 distance Z without normalizing first, etc..  this is fine for now
									targetOffset.Normalize();
									float angle = MathUtilities::RadiansToDegrees(acos(targetOffset.z));
									if (angle > maxAngle)
										angle = maxAngle;
									targetOffset.z = 0.0f;
									targetOffset.Normalize(); // shouldn't ever fail since x and y had a non zero magnitude
									directorOffset = targetOffset.ScalarMult(maxDistanceOffCenter);
									float maxDirectorOffsetDistance = 5.0f;
									if (distanceOffCenter > maxDirectorOffsetDistance)
										directorOutOfViewFactor = maxDirectorOutOfViewFactor;
									else
										directorOutOfViewFactor = ((angle - minAngle) / (maxAngle - minAngle)) * maxDirectorOutOfViewFactor;
								}
							}
							else
							{
								renderDirectorReticle = true;
								targetOffset.z = 0.0f;
								if (targetOffset.Normalize() == false)
									renderDirectorReticle = false;
								else
								{
									directorOffset = targetOffset.ScalarMult(maxDistanceOffCenter);
									directorOutOfViewFactor = maxDirectorOutOfViewFactor;
								}
							}

							// directorOffset is the main point of the director reticle
							// render two arrows, distance apart depending on how far out of the view the target is
							if (renderDirectorReticle && centerReticlePosition.z > 0.00001f)
							{
								graphics->PushMatrix();
								graphics->Translate(centerReticlePosition.x, centerReticlePosition.y, 0.0f);

								Vector3d unitOffset = directorOffset;
								unitOffset.Normalize();
								Vector3d unitOffsetOrtho = Vector3d(-unitOffset.y, unitOffset.x, 0);

								ModelVertex directorReticle[3];
								directorReticle[0].colorIndex = 0;
								directorReticle[1].colorIndex = 0;
								directorReticle[2].colorIndex = 0;

								directorReticle[0].vertex = directorOffset - unitOffset.ScalarMult(directorOutOfViewFactor * 0.02f) - unitOffset.ScalarMult(0.03f) - unitOffsetOrtho.ScalarMult(0.03f);
								directorReticle[1].vertex = directorOffset - unitOffset.ScalarMult(directorOutOfViewFactor * 0.02f);
								directorReticle[2].vertex = directorOffset - unitOffset.ScalarMult(directorOutOfViewFactor * 0.02f) - unitOffset.ScalarMult(0.03f) + unitOffsetOrtho.ScalarMult(0.03f);
								graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, directorReticle, 3, true);

								directorReticle[0].vertex = directorOffset - unitOffset.ScalarMult(0.03f) - unitOffsetOrtho.ScalarMult(0.03f);
								directorReticle[1].vertex = directorOffset;
								directorReticle[2].vertex = directorOffset - unitOffset.ScalarMult(0.03f) + unitOffsetOrtho.ScalarMult(0.03f);
								graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, directorReticle, 3, true);

								// draw straight line to center of arrow
								directorReticle[0].vertex = Vector3d(0, 0, 0);
								graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, directorReticle, 2, true);

								graphics->PopMatrix();
							}

							// lead shot reticle
							Vector3d projectileDirection;
							float strikeT;
							if (MathUtilities::ProjectileStrikeObjectApproximateGravity(userControlJetRef->orient.p, userControlJetRef->velocity, JetGameValues::BulletExitSpeedFeetPerMS(), JetGameValues::GravityAccelerationPerMSSquared(), ((JetGameObject *)userControlJetRef->targetRef.Ptr())->orient.p, ((JetGameObject *)userControlJetRef->targetRef.Ptr())->velocity, strikeT, projectileDirection) == true)
							{
								// tweak it with gravity acceleration - this won't be 100% accurate, especially with a slow projectile, but it will be close with fast ones and a light parabola curve.
								projectileDirection = cameraOrient->TransformToOrientSpace(projectileDirection + userControlJetRef->orient.p);
								if (projectileDirection.z >= 0.00001f)
								{
									projectileDirection = projectileDirection.ScalarMult(1.0f / projectileDirection.z);
									projectileDirection.z = 0.0f;
									// render a small circle there
									graphics->PushMatrix();
									graphics->Translate(projectileDirection.x, projectileDirection.y, 0.0f);
									// todo: 0.01 instead
									graphics->Scale(0.01f, 0.01f, 1.0f);

									// todo: render a circle instead
									ModelVertex leadShotVertices[5] = { ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0) };
									graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, leadShotVertices, 5, true);
									graphics->PopMatrix();
								}
							}
						} // target valid
					} // user controlled jet has something targeted
#pragma endregion Jet Target Reticle

#pragma region Track View Director
					if (cameraTrackTargetFromUserJet == true && cameraTrackPosition != nullptr)
					{
						Vector3d directorOffset;
						float maxDistanceOffCenter = 0.4f;
						float maxDirectorOutOfViewFactor = 1.0f;
						float directorOutOfViewFactor = 0.0f;

						// see if center reticle is far off the center of the camera.  If so, render a director that helps the pilot bring the center reticle back into view again
						// skip the line from the center of the screen since that would disrupt the track view
						Vector3d trackViewCenterReticleOffset = userControlJetRef->orient.TransformToOrientSpace(*cameraTrackPosition); // reuse
						trackViewCenterReticleOffset.Normalize();
						bool skipTrackDirector = false;
						if (trackViewCenterReticleOffset.z <= 0.00001f)
						{
							trackViewCenterReticleOffset.z = 0.0f;
							directorOutOfViewFactor = maxDirectorOutOfViewFactor;
							if (trackViewCenterReticleOffset.Normalize() == false)
								skipTrackDirector = true;
							else
								directorOffset = trackViewCenterReticleOffset.ScalarMult(maxDistanceOffCenter);
						}
						else
						{
							float originalZ = trackViewCenterReticleOffset.z;
							trackViewCenterReticleOffset = trackViewCenterReticleOffset.ScalarMult(1.0f / trackViewCenterReticleOffset.z);
							trackViewCenterReticleOffset.z = 0.0f;
							float distanceOffCenter = trackViewCenterReticleOffset.Magnitude();
							trackViewCenterReticleOffset.Normalize();

							if (distanceOffCenter > maxDistanceOffCenter) // around 30 degrees off center
							{
								// render a director reticle instead, distance between arrows based on angle
								// todo: it jerks at the 90 degree mark - make it smooth
								float minAngle = MathUtilities::RadiansToDegrees(atan(maxDistanceOffCenter));
								float maxAngle = 80.0f; // for some reason 90 degrees jerks about at the limit, probably related to the 0.00001 distance Z without normalizing first, etc..  this is fine for now
								float angle = MathUtilities::RadiansToDegrees(acos(originalZ));
								if (angle > maxAngle)
									angle = maxAngle;
								directorOffset = trackViewCenterReticleOffset.ScalarMult(maxDistanceOffCenter);
								float maxDirectorOffsetDistance = 5.0f;
								if (distanceOffCenter > maxDirectorOffsetDistance)
									directorOutOfViewFactor = maxDirectorOutOfViewFactor;
								else
									directorOutOfViewFactor = ((angle - minAngle) / (maxAngle - minAngle)) * maxDirectorOutOfViewFactor;
							}
							else
								skipTrackDirector = true;
						}

						if (skipTrackDirector == false)
						{
							// render off center of view regardless of camera orientation to help guide pilot

							graphics->PushMatrix();

							Vector3d unitOffset = trackViewCenterReticleOffset;
							Vector3d unitOffsetOrtho = Vector3d(-unitOffset.y, unitOffset.x, 0);

							ModelVertex directorReticle[3];
							directorReticle[0].colorIndex = 0;
							directorReticle[1].colorIndex = 0;
							directorReticle[2].colorIndex = 0;

							directorReticle[0].vertex = directorOffset - unitOffset.ScalarMult(directorOutOfViewFactor * 0.02f) - unitOffset.ScalarMult(0.03f) - unitOffsetOrtho.ScalarMult(0.03f);
							directorReticle[1].vertex = directorOffset - unitOffset.ScalarMult(directorOutOfViewFactor * 0.02f);
							directorReticle[2].vertex = directorOffset - unitOffset.ScalarMult(directorOutOfViewFactor * 0.02f) - unitOffset.ScalarMult(0.03f) + unitOffsetOrtho.ScalarMult(0.03f);
							graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, directorReticle, 3, true);

							directorReticle[0].vertex = directorOffset - unitOffset.ScalarMult(0.03f) - unitOffsetOrtho.ScalarMult(0.03f);
							directorReticle[1].vertex = directorOffset;
							directorReticle[2].vertex = directorOffset - unitOffset.ScalarMult(0.03f) + unitOffsetOrtho.ScalarMult(0.03f);
							graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 2, directorReticle, 3, true);

							graphics->PopMatrix();

						}
					}
#pragma endregion Track View Director

#pragma region Damaged Jet Indicators
					// render jet damage indicators
					gameObjectEnumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
					while (gameObjectEnumerator.MoveNext())
					{
						switch (gameObjectEnumerator.Current()->data.objectType)
						{
						case JetGameObjectEnum::Jet:
						{
							// just render a damage indicator
							Vector3d targetOffset = cameraOrient->TransformToOrientSpace((((JetGameObject *)(&gameObjectEnumerator.Current()->data))->orient.p));
							float distanceZ = targetOffset.z;
							if (distanceZ > 0.00001f)
							{
								// does target have a damage indicator?
								if (gameObjectEnumerator.Current()->data.damageIndicatorTimerMS > 0)
								{
									// get offset of center
									targetOffset = targetOffset.ScalarMult(1.0f / distanceZ);
									float distanceOffCenter = sqrt(targetOffset.x*targetOffset.x + targetOffset.y*targetOffset.y);

									graphics->PushMatrix();
									graphics->Translate(targetOffset.x, targetOffset.y, 0.0f);
									float scaleNumeratorX = 0.03f;
									float scaleNumeratorY = 0.0025f;
									// render it a little above the jet
									graphics->Translate(0.0f, 1.0f / distanceZ + 0.02f, 0.0f);
									// render a rectangle and a filled quad inside
									graphics->Scale(scaleNumeratorX, scaleNumeratorY, 1.0f);
									// clockwise so that RenderQuad works
									ModelVertex damageIndicatorVertices[5] = { ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
									GameColor damageMeterColor[1] = { GameColor(0, 0, 0) };
									float damageRatio = gameObjectEnumerator.Current()->data.health / JetGameValues::JetStartingHealth();
									damageMeterColor[0] = GetDamageMeterColor(damageRatio);
									// only draw meter as far to the right as is necessary
									damageIndicatorVertices[2].vertex.x = 1.0f - 2.0f * damageRatio;
									damageIndicatorVertices[3].vertex.x = 1.0f - 2.0f * damageRatio;
									graphics->RenderFilledQuad(damageMeterColor, 1, damageIndicatorVertices, 4, true, nullptr); // only use first 4
									damageIndicatorVertices[2].vertex.x = -1.0f;
									damageIndicatorVertices[3].vertex.x = -1.0f;
									graphics->RenderLineStrip(mainReticleLineWidth / 2.0f, mainReticleColors, 2, damageIndicatorVertices, 5, true);
									graphics->PopMatrix();
								}
							}
						}
						break;
						} // switch
					} // render damage indicators
#pragma endregion Damaged Jet Indicators

#pragma region Incoming Missiles Indicators
					// render missile reticles and jet damage indicators
					// flicker them when not paused
					static bool renderMissileReticles = true;
					if (renderMissileReticles == true || timer->GetElapsedTimeMS() == 0)
					{
						int evasionArcSectorQty = 64; // 64 around
						ModelVertex evasionArcVertices[4]; // each arc is calculated in the loop, vertex n copied to n-1 for next iteration
						// vertices calculated later
						evasionArcVertices[0].colorIndex = 0;
						evasionArcVertices[1].colorIndex = 0;
						evasionArcVertices[2].colorIndex = 1;
						evasionArcVertices[3].colorIndex = 1;

						gameObjectEnumerator = LinkedListEnumerator<JetGameObject>(*gameObjectList);
						while (gameObjectEnumerator.MoveNext())
						{
							switch (gameObjectEnumerator.Current()->data.objectType)
							{
							case JetGameObjectEnum::Missile:
							{
								if (gameObjectEnumerator.Current()->data.targetRef.Ptr() != userControlJetRef)
									continue;

								// missile reticle to show flying missile
								Vector3d missileOffset = cameraOrient->TransformToOrientSpace((((JetGameObject *)(&gameObjectEnumerator.Current()->data))->orient.p));
								float distanceZ = missileOffset.z;
								bool renderDirectorReticle = false;
								Vector3d directorOffset;
								float maxDistanceOffCenter = 0.4f;
								float maxDirectorOutOfViewFactor = 1.0f;
								float directorOutOfViewFactor = 0.0f;
								if (distanceZ > 0.00001f)
								{
									// get offset of center
									missileOffset = missileOffset.ScalarMult(1.0f / distanceZ);
									float distanceOffCenter = sqrt(missileOffset.x*missileOffset.x + missileOffset.y*missileOffset.y);

									// render targetting reticle in front regardless, add director on top if necessary
									graphics->PushMatrix();
									graphics->Translate(missileOffset.x, missileOffset.y, 0.0f);
									float scaleNumeratorX = 1.0f; // differs depending on target
									float scaleNumeratorY = 1.0f; // differs depending on target
									// todo: min and max size too
									// todo: render alternate side reticle that directs player to target and gets smaller the closer the target is to being in view
									graphics->Scale(scaleNumeratorX / distanceZ, scaleNumeratorY / distanceZ, 1.0f);
									ModelVertex targetLRVertices[3] = { ModelVertex(Vector3d(-1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, -1.0f, 0.0f), 1) };
									ModelVertex targetLLVertices[3] = { ModelVertex(Vector3d(1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, -1.0f, 0.0f), 1) };
									ModelVertex targetULVertices[3] = { ModelVertex(Vector3d(-1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, 1.0f, 0.0f), 1) };
									ModelVertex targetURVertices[3] = { ModelVertex(Vector3d(1.0f, 0.0f, 0.0f), 1), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(0.0f, 1.0f, 0.0f), 1) };
									graphics->RenderLineStrip(mainReticleLineWidth * 1.5f, brightReticleColors, 2, targetLRVertices, 3, true);
									graphics->RenderLineStrip(mainReticleLineWidth * 1.5f, brightReticleColors, 2, targetLLVertices, 3, true);
									graphics->RenderLineStrip(mainReticleLineWidth * 1.5f, brightReticleColors, 2, targetULVertices, 3, true);
									graphics->RenderLineStrip(mainReticleLineWidth * 1.5f, brightReticleColors, 2, targetURVertices, 3, true);
									graphics->PopMatrix();
								}

								// render an evasion arc, the thickness determined by how close the missile is as an indicator of where to fly first
								missileOffset = (((JetGameObject *)(&gameObjectEnumerator.Current()->data))->orient.p - userControlJetRef->orient.p);
								float missileDistance = missileOffset.Magnitude();
								if (missileOffset.Normalize() == true) // if zero, it hit us anyway
								{
									float arcFactor = 0.01f + 1.0f / missileDistance; // minimum 0.01f, max 0.125f
									if (arcFactor > 0.125f)
										arcFactor = 0.125f;

									// establish a 3d world cone to fly in, intersect it with the 1.0f z plane of the viewport, calculate the vertices (set negative z on the ones behind) and draw an arc there (only the ones without a negative z)
									// get the 45 degree vector first, and rotate it around (to keep it accurate, restore to the original and just rotate an extra n degrees on each loop
									// same calc as in JetBehavior (might want to move this to a JetGameTools class?)
									Vector3d axis = missileOffset.CrossProd(userControlJetRef->orient.f);
									if (axis.Normalize() == false)
									{
										axis = userControlJetRef->orient.l;
									}
									Vector3d axis2 = axis.CrossProd(missileOffset);
									axis2.Normalize();
									// axis2 + offsetToMissile is the closest 45 degree angle against it from f
									Vector3d missileEvadeDirection = axis2 + missileOffset; // not used for display, used for director (below)
									Vector3d originalMissileEvadeDirectionOuter = axis2.ScalarMult(1.0f + arcFactor) + missileOffset;
									Vector3d originalMissileEvadeDirectionInner = axis2 + missileOffset.ScalarMult(1.0f + arcFactor);

									float angleIncrement = 360.0f / float(evasionArcSectorQty);
									float angle = 0.0f;
									for (int i = 0; i <= evasionArcSectorQty; i++)
									{
										// force full circle
										if (i == evasionArcSectorQty)
											angle = 0.0f;

										Vector3d evasionVectorOuter = originalMissileEvadeDirectionOuter;
										Vector3d evasionVectorInner = originalMissileEvadeDirectionInner;
										evasionVectorOuter.Rotate(missileOffset, -angle);
										evasionVectorInner.Rotate(missileOffset, -angle);

										Vector3d screenSpaceOuter = userControlJetRef->orient.TransformToOrientSpace(evasionVectorOuter + userControlJetRef->orient.p);
										Vector3d screenSpaceInner = userControlJetRef->orient.TransformToOrientSpace(evasionVectorInner + userControlJetRef->orient.p);
										if (screenSpaceOuter.z > 0.00001f && screenSpaceInner.z > 0.00001f)
										{
											screenSpaceOuter = screenSpaceOuter.ScalarMult(1.0f / screenSpaceOuter.z);
											screenSpaceInner = screenSpaceInner.ScalarMult(1.0f / screenSpaceInner.z);
											screenSpaceOuter.z = 0.0f;
											screenSpaceInner.z = 0.0f;
											evasionArcVertices[1].vertex = screenSpaceOuter;
											evasionArcVertices[2].vertex = screenSpaceInner;
										}
										else
										{
											// flag the vertices as behind the viewpoint
											evasionArcVertices[1].vertex.z = -1.0f;
											evasionArcVertices[2].vertex.z = -1.0f;
										}

										if (i > 0)
										{
											if (evasionArcVertices[0].vertex.z >= 0.0f && evasionArcVertices[1].vertex.z >= 0.0f && evasionArcVertices[2].vertex.z >= 0.0f && evasionArcVertices[3].vertex.z >= 0.0f)
											{
												// render completed set of vertices
												graphics->RenderFilledQuad(brightReticleColorsFaint, 2, &evasionArcVertices[0], 4, true, nullptr);
											}
										}

										angle += angleIncrement;

										// copy vertices back for next quad
										evasionArcVertices[0].vertex = evasionArcVertices[1].vertex;
										evasionArcVertices[3].vertex = evasionArcVertices[2].vertex;
									}

									// if closest best target of arc is too far out, render a director to the best direction to evade, the thickness determined by how close the missile is								
									// get position of best flight direction on 1.0f plane.  If too far off center or behind, draw a director
									Vector3d directorPosition = userControlJetRef->orient.TransformToOrientSpace(missileEvadeDirection + userControlJetRef->orient.p);
									bool behind = false;
									if (directorPosition.z < 0.0f)
										behind = true;
									if (fabs(directorPosition.z) > 0.00001f) // if not just set z = 0.0f below, we'll unitize later
										directorPosition = directorPosition.ScalarMult(1.0f / fabs(directorPosition.z));
									directorPosition.z = 0.0f; // just make it good
									float directorOffsetFromCenter = directorPosition.Magnitude();
									float maxDistanceOffCenter = 0.4f;
									if ((directorOffsetFromCenter > maxDistanceOffCenter || behind == true) && (directorPosition.Normalize() == true))
									{
										directorPosition = directorPosition.ScalarMult(maxDistanceOffCenter);

										// draw a director, its thickness determined by distance of missile
										ModelVertex evadeDirectorVertices[4]; // left arrowhead

										// note really needed here, but just in case
										graphics->PushMatrix();

										Vector3d unitOffset = directorPosition;
										unitOffset.Normalize();
										Vector3d unitOffsetOrtho = Vector3d(-unitOffset.y, unitOffset.x, 0);

										ModelVertex directorReticle[3];
										evadeDirectorVertices[0].colorIndex = 0;
										evadeDirectorVertices[1].colorIndex = 0;
										evadeDirectorVertices[2].colorIndex = 1;
										evadeDirectorVertices[3].colorIndex = 1;

										evadeDirectorVertices[0].vertex = directorPosition;
										evadeDirectorVertices[1].vertex = directorPosition - unitOffset.ScalarMult(0.03f) + unitOffsetOrtho.ScalarMult(0.03f);
										evadeDirectorVertices[2].vertex = directorPosition - unitOffset.ScalarMult(0.03f) + unitOffsetOrtho.ScalarMult(0.03f) - unitOffset.ScalarMult(arcFactor);
										evadeDirectorVertices[3].vertex = directorPosition - unitOffset.ScalarMult(arcFactor);
										graphics->RenderFilledQuad(brightReticleColorsFaint, 2, evadeDirectorVertices, 4, true, nullptr);

										evadeDirectorVertices[1].vertex = directorPosition;
										evadeDirectorVertices[0].vertex = directorPosition - unitOffset.ScalarMult(0.03f) - unitOffsetOrtho.ScalarMult(0.03f);
										evadeDirectorVertices[3].vertex = directorPosition - unitOffset.ScalarMult(0.03f) - unitOffsetOrtho.ScalarMult(0.03f) - unitOffset.ScalarMult(arcFactor);
										evadeDirectorVertices[2].vertex = directorPosition - unitOffset.ScalarMult(arcFactor);
										graphics->RenderFilledQuad(brightReticleColorsFaint, 2, evadeDirectorVertices, 4, true, nullptr);

										// and pop because of the push
										graphics->PopMatrix();
									}

								}
							}
							break;
							} // switch
						} // while loop
					} // render missile reticles
					// if not paused, flicker the incoming missile reticles
					if (timer->GetElapsedTimeMS() > 0)
						renderMissileReticles = !renderMissileReticles;
#pragma endregion Incoming Missiles Indicators

#pragma region Damage Pulses
					// render damage pulses
					userControlJetRef->AnimateDamagePulses(timer->GetElapsedTimeMS());
					//float startDegrees = -360.0f / float(userControlJetRef->GetDamagePulseQty() * 2);
					//float endDegrees = 360.0f / float(userControlJetRef->GetDamagePulseQty() * 2);
					float degreeIncrement = 360.0f / float(userControlJetRef->GetDamagePulseQty());
					ModelVertex damagePulseVertices[4] = { ModelVertex(Vector3d(1, 1, 0), 0), ModelVertex(Vector3d(-1, 1, 0), 0), ModelVertex(Vector3d(-1, -1, 0), 1), ModelVertex(Vector3d(1, -1, 0), 1) };
					GameColor damagePulseColors[2] = { GameColor(255, 0, 0, 255), GameColor(255, 0, 0, 0) };
					graphics->PushMatrix();
					for (int i = 0; i < userControlJetRef->GetDamagePulseQty(); i++)
					{
						Tuple<unsigned char, float> ^renderValues = userControlJetRef->GetDamagePulseAlphaAndDegrees(i);

						if (renderValues->Item1 != 0)
						{
							graphics->PushMatrix();
							graphics->Translate(0.0f, 0.25f, 0.0f); // sends the quad in the direction graphics is currently rotated (see below)
							graphics->Scale(0.10f, 0.01f, 1.0f); // 0.10f is for 8-step arc, 0.05 worked for 16-step arc

							// render an arc from startDegrees to endDegrees
							damagePulseColors[0].alpha = renderValues->Item1;
							//damagePulseColors[0].alpha = 255;

							graphics->RenderFilledQuad(damagePulseColors, 2, damagePulseVertices, 4, true, nullptr);
							graphics->PopMatrix();
						}

						graphics->Rotate(degreeIncrement, Vector3d(0, 0, 1));
						//startDegrees += degreeIncrement;
						//endDegrees += degreeIncrement;
					}
					graphics->PopMatrix();
#pragma endregion Damage Pulses

#pragma region Damage Indicator
					// render damage indicator at bottom of screen
					graphics->PushMatrix();
					float scaleDamageIndicatorX = 0.3f;
					float scaleDamageIndicatorY = 0.01f;
					// render it a little above the bottom of the screen (assuming vertical 45 degree projection)
					graphics->Translate(0.0f, -0.35f, 0.0f);
					// render a rectangle and a filled quad inside
					graphics->Scale(scaleDamageIndicatorX, scaleDamageIndicatorY, 1.0f);
					// clockwise so that RenderQuad works
					ModelVertex damageIndicatorVertices[5] = { ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
					GameColor damageMeterColor[1] = { GameColor(0, 0, 0) };
					float damageRatio = userControlJetRef->health / JetGameValues::JetStartingHealth();
					damageMeterColor[0] = GetDamageMeterColor(damageRatio);
					// only draw meter as far to the right as is necessary
					damageIndicatorVertices[2].vertex.x = 1.0f - 2.0f * damageRatio;
					damageIndicatorVertices[3].vertex.x = 1.0f - 2.0f * damageRatio;
					graphics->RenderFilledQuad(damageMeterColor, 1, damageIndicatorVertices, 4, true, nullptr); // only use first 4
					damageIndicatorVertices[2].vertex.x = -1.0f;
					damageIndicatorVertices[3].vertex.x = -1.0f;
					graphics->RenderLineStrip(mainReticleLineWidth * 4.0f / 2.0f, mainReticleColors, 2, damageIndicatorVertices, 5, true);
					graphics->PopMatrix();
#pragma endregion Damage Indicator

					// render a horizon indicator below center that shows the player where the horizon is and where to fly to get back to center
#pragma region Track View Horizon
					if (cameraTrackTargetFromUserJet == true)
					{
						// main line
						ModelVertex horizonCenterMain[5] = { ModelVertex(Vector3d(-0.0025f, -0.0025f, 0.0f), 0), ModelVertex(Vector3d(0.0025f, -0.0025f, 0.0f), 0), ModelVertex(Vector3d(0.0025f, 0.0025f, 0.0f), 0), ModelVertex(Vector3d(-0.0025f, 0.0025f, 0.0f), 0), ModelVertex(Vector3d(-0.0025f, -0.0025f, 0.0f), 0) };
						ModelVertex horizonVerticesMain[2] = { ModelVertex(Vector3d(-0.125f, 0.0f, 0.0f), 0), ModelVertex(Vector3d(0.125f, 0.0f, 0.0f), 0) };
						// small line under horizon
						ModelVertex horizonVerticesMinor1[2] = { ModelVertex(Vector3d(-0.025f, -0.01f, 0.0f), 0), ModelVertex(Vector3d(0.025f, -0.01f, 0.0f), 0) };
						// larger line under horizon
						ModelVertex horizonVerticesMinor2[2] = { ModelVertex(Vector3d(-0.05f, -0.02f, 0.0f), 0), ModelVertex(Vector3d(0.05f, -0.02f, 0.0f), 0) };

						float horizonOffset = userControlJetRef->orient.f.y; // -1.0f to 1.0f
						Orient3d tempOrient = userControlJetRef->orient;
						// rotate it to the horizon to get a roll amount for display
						float degrees = -MathUtilities::RadiansToDegrees(asin(horizonOffset));
						Vector3d spinAxis = Vector3d(0.0f, 1.0f, 0.0f).CrossProd(userControlJetRef->orient.f);
						if (spinAxis.Normalize() == false)
							spinAxis = Vector3d::Vector3d(1.0f, 0.0f, 0.0f);
						tempOrient.Rotate(spinAxis, degrees);
						// take u and l as the rotation for the line display
						float rollDegrees = MathUtilities::RadiansToDegrees(asin(tempOrient.l.y));
						if (tempOrient.u.y < 0.0f)
							rollDegrees = 180.0f - rollDegrees;

						graphics->PushMatrix();

						graphics->Translate(0.0f, -0.25f, 0.0f);  // main line center
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 1, horizonCenterMain, 5, false);

						graphics->Rotate(-rollDegrees, Vector3d(0.0f, 0.0f, 1.0f));
						graphics->Translate(0.0f, -horizonOffset * 0.125f, 0.0f);  // main line center

						// Draw them!
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 1, horizonVerticesMain, 2, false);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 1, horizonVerticesMain, 2, false);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 1, horizonVerticesMinor1, 2, false);
						graphics->RenderLineStrip(mainReticleLineWidth, mainReticleColors, 1, horizonVerticesMinor2, 2, false);

						graphics->PopMatrix();
					}
#pragma endregion Track View Horizon


					graphics->PopMatrix();

				}  // user controlled jet

				graphics->SetDepthTestEnabled(true);
				graphics->SetDepthWriteEnabled(true);
#pragma endregion Reticles

			}

			void RenderSolid(GraphicsBase *p_graphics, Orient3d &p_orient, JetGameObjectEnum p_type, JetGameObject *p_object, GraphicsShaderPolygonOptions &p_polygonQueueOptions)
			{
				static GameColor redJetColors[5] = {
					GameColor(212, 0, 0),
					GameColor(170, 0, 0),
					GameColor(85, 0, 0),
					GameColor(128, 128, 255),
					GameColor(0, 255, 255)
				};

				static GameColor whiteJetColors[5] = {
					GameColor(212, 212, 212),
					GameColor(170, 170, 170),
					GameColor(85, 85, 85),
					GameColor(128, 128, 255),
					GameColor(0, 255, 255)
				};

				static GameColor purpleJetColors[5] = {
					GameColor(212, 0, 212),
					GameColor(170, 0, 170),
					GameColor(85, 0, 85),
					GameColor(128, 128, 255),
					GameColor(0, 255, 255)
				};

				static GameColor blackEvilJetColors[5] = {
					GameColor(32, 32, 32),
					GameColor(255, 0, 0),
					GameColor(0, 0, 0),
					GameColor(128, 128, 255),
					GameColor(0, 255, 255)
				};

				JetGameObjectEnum objectType = p_type;
				if (p_object != nullptr)
					objectType = p_object->objectType;

				switch (objectType)
				{
					case JetGameObjectEnum::Jet:
					{
						if (usePolygonQueue == false)
						{
							p_graphics->PushMatrix();
							// p_orient is the actual world position (not a child of a parent in the case of recursive calls)
							p_graphics->Transform(p_orient);
							// render deleted jets at 4 times the size for demonstration for now
							//if (gameObjectEnumerator.Current()->data.deleted == true)
							//	graphics->Scale(4.0f, 4.0f, 4.0f);
							switch (p_object->faction)
							{
							case 0:
								jet->Render(*p_graphics); // blue
								break;
							case 1:
								jet->Render(*p_graphics, redJetColors, 5);
								break;
							case 2:
								jet->Render(*p_graphics, whiteJetColors, 5);
								break;
							case 3:
								jet->Render(*p_graphics, purpleJetColors, 5);
								break;
							case 4:
								jet->Render(*p_graphics, blackEvilJetColors, 5);
								break;
							}
							p_graphics->PopMatrix();
						}
						else
						{
							GameColor *colors = nullptr;
							switch (p_object->faction)
							{
							case 0:
								colors = jet->GetColors();
								break;
							case 1:
								colors = redJetColors;
								break;
							case 2:
								colors = whiteJetColors;
								break;
							case 3:
								colors = purpleJetColors;
								break;
							case 4:
								colors = blackEvilJetColors;
								break;
							}

							p_graphics->SubmitModelToPolygonQueue(polygonQueue, p_polygonQueueOptions, colors, 5, jet->GetSurfaces(), jet->GetSurfaceQty(), jet->GetVertices(), jet->GetVertexQty(), p_orient, Vector3d(1,1,1));
						}

						// render weapons
						for (int i = 0; i < p_object->hardpointState->objectWeaponQty; i++)
						{
							HardpointWeaponState *weapon = &(p_object->hardpointState->weaponStates[i]);
							if (weapon->entryRef->render == true)
							{
								for (int j = 0; j < weapon->slotQty; j++)
								{
									if (weapon->slotStates[j].currentAmmo >= weapon->entryRef->ammoAmountUsage)
									{
										// render it!
										for (int k = 0; k < weapon->entryRef->GetFireableWeapon(j).locationQty; k++)
										{
											Vector3d worldPosition = weapon->entryRef->GetFireableWeapon(j).GetHardpointLocation(k).GetWeaponWorldLocation(p_object->orient);
											Orient3d weaponOrient = p_object->orient;
											weaponOrient.p = worldPosition;

											RenderSolid(p_graphics, weaponOrient, weapon->entryRef->weaponType, nullptr, p_polygonQueueOptions);
										}
									}
								}
							}
						}
					}
					break;
					case JetGameObjectEnum::Missile:
					{
						if (usePolygonQueue == false)
						{
							p_graphics->PushMatrix();
							p_graphics->Transform(p_orient);
							p_graphics->Scale(0.025f, 0.025f, 0.20f);  // 6 in x 4 feet
							//graphics->Scale(20.0f,20.0f,20.0f);  // debugging
							cube->Render(*p_graphics);
							p_graphics->PopMatrix();
						}
						else
						{
							p_graphics->SubmitModelToPolygonQueue(polygonQueue, p_polygonQueueOptions, cube->GetColors(), cube->GetColorQty(), cube->GetSurfaces(), cube->GetSurfaceQty(), cube->GetVertices(), cube->GetVertexQty(), p_orient, Vector3d(0.025f, 0.025f, 0.20f));
						}
					}
					break;
				}
			}

			void RenderParticles(LinkedList<Particle> *p_particles, GraphicsBase *p_graphics, Orient3d *p_cameraOrient, GraphicsShaderParticlesOptions &p_particleOptions, bool p_animate, Vector3d p_eyePositionOffset)
			{
				// p_particleOptions is only used when using the particle queue to render them all natively

				// set the important value on the particles so they can be sorted
				LinkedListNode<Particle> *particleNode = p_particles->GetFirstNode();
				if (p_animate == true)
				{
					if (particleNode != nullptr)
					{
						while (particleNode != &(p_particles->footer))
						{
							// apply elapsed time
							particleNode->data.SetLife(timer->GetElapsedTimeMSFloat());

							if (particleNode->data.IsDead() == false)
							{
								// animate position and calcualte zdepth
								particleNode->data.PreparePosition();
								particleNode->data.PrepareZDepth(p_cameraOrient->p, p_cameraOrient->f);

								particleNode = particleNode->next;
							}
							else
							{
								// remove particle, it's done
								LinkedListNode<Particle> *tempNode = particleNode->next;
								p_particles->DeleteNode(particleNode);
								particleNode = tempNode;
							}
						}
					}

					SortParticles(p_particles);
				}

				bool renderParticles = true;

				// render the sorted list
				particleNode = p_particles->GetFirstNode();
				if (particleNode != nullptr)
				{
					GameTexture ^particleTexture = GameContext::Instance->TextureRegistry.GetTexture("SmokePuff1");  // same for all for now
					ModelVertex particleVertices[4] = { ModelVertex(Vector3d(1, 1, 0), 0), ModelVertex(Vector3d(-1, 1, 0), 0), ModelVertex(Vector3d(-1, -1, 0), 0), ModelVertex(Vector3d(1, -1, 0), 0) };
					while (particleNode != &(p_particles->footer))
					{
						// animate it the rest of the way using applied life amount
						if (p_animate == true)
						{
							particleNode->data.PrepareAlpha();
							particleNode->data.PrepareRadius();
						}
						//if (particleNode->data.lifeMS >= particleNode->data.maxLifeMS)
						//	particleNode->data.color.alpha = 0;
						//else if (particleNode->data.lifeMS <= 0)
						//	particleNode->data.color.alpha = particleNode->data.startAlpha;
						//else
						//	particleNode->data.color.alpha = unsigned char(float(particleNode->data.startAlpha) * float(particleNode->data.maxLifeMS - particleNode->data.lifeMS) / float(particleNode->data.maxLifeMS));

						//particleNode->data.radius += (particleNode->data.radiusExpansionPerMS * timer->GetElapsedTimeMSFloat());

						//if (particleNode->data.color.alpha == 0)
						//{
						//	LinkedListNode<Particle> *tempNode = particleNode->next;
						//	p_particles->DeleteNode(particleNode);
						//	particleNode = tempNode;
						//}
						//else
						//{
						// render it
						// don't render if not in front
						if (useParticleQueue == false && particleNode->data.zDepth > 0.01f && renderParticles == true) // same depth tolerance as bubble sort
						{
							p_graphics->PushMatrix();
							Orient3d trueCameraOrient = *p_cameraOrient;
							trueCameraOrient.p = trueCameraOrient.p + p_eyePositionOffset;
							Vector3d renderOffset = trueCameraOrient.TransformToOrientSpace(particleNode->data.position);
							p_graphics->Translate(renderOffset.x, renderOffset.y, renderOffset.z);
							p_graphics->Rotate(float(particleNode->data.rotationAngleDegrees), Vector3d(0, 0, 1));
							p_graphics->Scale(particleNode->data.radius, particleNode->data.radius, 1.0f);
							GameColor color = GameColor(particleNode->data.color.red, particleNode->data.color.green, particleNode->data.color.blue, unsigned char(particleNode->data.alpha * 255.0f));
							p_graphics->RenderFilledQuad(&color, 1, particleVertices, 4, true, particleTexture);
							p_graphics->PopMatrix();
						}

						//particleNode->data.lifeMS += timer->GetElapsedTimeMS();

						particleNode = particleNode->next;

						//}
					}
				}

				if (useParticleQueue == true && renderParticles == true)
				{
					if (p_particles->IsEmpty() == false)
					{
						if (smokeParticleQueue == nullptr)
							smokeParticleQueue = new GraphicsParticleQueue();
						if (smokeParticleQueue->IsInitialized() == false)
							p_graphics->CreateParticleQueue(smokeParticleQueue, 8000);

						p_graphics->SubmitParticlesToQueue(smokeParticleQueue, *p_particles, p_particleOptions);
					}
				}
			}

			void SortParticles(LinkedList<Particle> *p_particles)
			{
				if (p_particles->IsEmpty())
					return;
				// only one item, no need to sort
				if (p_particles->header.next->next == &(p_particles->footer))
					return;

				// evaluate which bubble sort to use
				int firstNodesGoodQty = 0;
				int consecutiveNodesGoodQty = 0;
				int nodeQty = 1; // counting last node already

				LinkedListNode<Particle> *node = p_particles->GetFirstNode();
				LinkedListNode<Particle> *halfWayNode = p_particles->GetFirstNode();
				bool anyBad = false;
				while (node->next != &(p_particles->footer))
				{
					if (node->data.zDepth > node->next->data.zDepth)
					{
						if (anyBad == false)
							firstNodesGoodQty++;
						consecutiveNodesGoodQty++;
					}
					else
					{
						anyBad = true;
						consecutiveNodesGoodQty = 0;
					}

					nodeQty++;
					node = node->next;
					if ((nodeQty & 1) != 0)
						halfWayNode = halfWayNode->next;
				}
				if (anyBad == false)
					return; // nothing to sort

				// if bad nodes found between first and last bad Qty, just do a quick sort
				if (firstNodesGoodQty > consecutiveNodesGoodQty && (nodeQty > 0)) // all the bad nodes are in the last half (nodeQty > 0 here to keep Release Build from optimizing it out)
					BubbleSortParticlesLastToFirst(p_particles);
				else
					BubbleSortParticlesFirstToLast(p_particles);
			}

			// quicksort source
			// http://www.geeksforgeeks.org/quicksort-for-linked-list/

			void QuickSortParticlesSwap(LinkedListNode<Particle> *node1, LinkedListNode<Particle> *node2)
			{
				Particle temp = node1->data;
				node1->data = node2->data;
				node2->data = temp;
			}

			LinkedListNode<Particle> * QuickSortParticlesPartition(LinkedList<Particle> *p_particles, LinkedListNode<Particle> *l, LinkedListNode<Particle> *h)
			{
				if (l == h)
					return l;

				LinkedListNode<Particle> *sm = l, *piv = h, *curr = l;

				while (curr != p_particles->GetLastNode() && curr != h)
				{
					if (curr->data.zDepth > piv->data.zDepth)
					{
						QuickSortParticlesSwap(sm, curr);
						sm = sm->next;
					}
					curr = curr->next;
				}
				QuickSortParticlesSwap(sm, piv);
				return sm;
			}

			void QuickSortParticlesRecursive(LinkedList<Particle> *p_particles, LinkedListNode<Particle> *l, LinkedListNode<Particle> *h)
			{
				LinkedListNode<Particle> *p = QuickSortParticlesPartition(p_particles, l, h);
				if (l != p)
					QuickSortParticlesRecursive(p_particles, l, p->prev);
				if (p != h)
					QuickSortParticlesRecursive(p_particles, p->next, h);
			}

			void QuickSortParticles(LinkedList<Particle> *p_particles)
			{
				QuickSortParticlesRecursive(p_particles, p_particles->GetFirstNode(), p_particles->GetLastNode());
			}

			void BubbleSortParticlesLastToFirst(LinkedList<Particle> *p_particles)
			{
				// don't use the delegate bubblesort - it's slower
				//p_particles->BubbleSortLastToFirst(JetGameBubbleSortHelper::SmokeParticleOrderInvalid);
				//return;

				// This routine works best when the node inserted that might be in a bad place is at the end of an already sorted list, since each main loop starts at the end and works backwards
				// fast when there are a few nodes at the end that need correction
				// slow with even one node at the front that needs correction, however that could be handled with a front to back bubble sort

				// todo: take a detach node, work backwards and place node where it fits approach rather than constantly swapping it to bubble it up

				// 10 7 2 1
				// =
				// 10 7 (1 2)
				// 10 (1 7) 2
				// (1 10) 7 2
				// -
				// 1 10 (2 7)
				// 1 (2 10) 7
				// -
				// 1 2 (7 10)

				// nothing to sort
				if (p_particles->IsEmpty())
					return;
				// only one item, no need to sort
				if (p_particles->header.next->next == &(p_particles->footer))
					return;

				LinkedListNode<Particle> *stopNode = &(p_particles->header);
				if (stopNode != nullptr)
				{
					while (stopNode != p_particles->footer.prev->prev) // stop when we just finished a list and only one node is left to parse
					{
						LinkedListNode<Particle> *node2 = p_particles->GetLastNode();
						bool anySwap = false;
						while (node2->prev != stopNode) // stop when we approach the stop node
						{
							// node compare values (determined by delegate) should be in increased order of comparison from header to footer
							if (node2->data.zDepth > node2->prev->data.zDepth)
							{
								// swap the nodes
								LinkedListNode<Particle> *preNode = node2->prev->prev; // node before the two
								LinkedListNode<Particle> *postNode = node2->next; // node after the two
								LinkedListNode<Particle> *firstNode = node2->prev; // the first of the two nodes (node2 = firstNode->next)

								preNode->next = node2;
								node2->prev = preNode;
								node2->next = firstNode;
								firstNode->prev = node2;
								firstNode->next = postNode;
								postNode->prev = firstNode;

								anySwap = true;

								// leave node2 point where it is.  It just auto advanced
							}
							else
								node2 = node2->prev;
						}

						// if nothing fixed, leave.  We are done.
						if (anySwap == false)
							break;

						// move the stop node forwards
						stopNode = stopNode->next;
					}
				}

				// check results
				bool checkResults = false;
				if (checkResults == true)
				{
					int nodeQty = 0;
					LinkedListNode<Particle> *node = p_particles->GetFirstNode();
					bool anyBad = false;
					while (node->next != &(p_particles->footer))
					{
						if (node->data.zDepth < node->next->data.zDepth)
						{
							anyBad = true;
						}

						nodeQty++;
						node = node->next;
					}
					if (anyBad == true && nodeQty > 0) // nodeQty > 0 here to prevent Release build from optimizing it out
					{
						throw gcnew Exception("BubbleSortParticlesLastToFirst: Sort failed - particles still out of order");
					}
				}
			}

			void BubbleSortParticlesFirstToLast(LinkedList<Particle> *p_particles)
			{
				// don't use the delegate bubblesort - it's slower
				//p_particles->BubbleSortFirstToLast(JetGameBubbleSortHelper::SmokeParticleOrderInvalid);
				//return;

				// This routine works best when the node inserted that might be in a bad place is at the end of an already sorted list, since each main loop starts at the end and works backwards
				// fast when there are a few nodes at the end that need correction
				// slow with even one node at the front that needs correction, however that could be handled with a front to back bubble sort

				// todo: take a detach node, work backwards and place node where it fits approach rather than constantly swapping it to bubble it up

				// 10 7 2 1
				// =
				// (7 10) 2 1
				// 7 (2 10) 1
				// 7 2 (1 10)
				// -
				// (2 7) 1 10
				// 2 (1 7) 10
				// -
				// (1 2) 7 10

				// nothing to sort
				if (p_particles->IsEmpty())
					return;
				// only one item, no need to sort
				if (p_particles->header.next->next == &(p_particles->footer))
					return;

				LinkedListNode<Particle> *stopNode = &(p_particles->footer);
				if (stopNode != nullptr)
				{
					while (stopNode != p_particles->header.next->next) // stop when we just finished a list and only one node is left to parse
					{
						LinkedListNode<Particle> *node2 = p_particles->GetFirstNode();
						bool anySwap = false;
						while (node2->next != stopNode) // stop when we approach the stop node
						{
							// node compare values (determined by delegate) should be in increased order of comparison from header to footer
							if (node2->data.zDepth < node2->next->data.zDepth)
							{
								// swap the nodes
								LinkedListNode<Particle> *preNode = node2->prev; // node before the two
								LinkedListNode<Particle> *postNode = node2->next->next; // node after the two
								LinkedListNode<Particle> *secondNode = node2->next; // the first of the two nodes (node2 = firstNode->next)

								preNode->next = secondNode;
								secondNode->prev = preNode;
								secondNode->next = node2;
								node2->prev = secondNode;
								node2->next = postNode;
								postNode->prev = node2;

								anySwap = true;

								// leave node2 point where it is.  It just auto advanced
							}
							else
								node2 = node2->next;
						}

						// if nothing fixed, leave.  We are done.
						if (anySwap == false)
							break;

						// move the stop node forwards
						stopNode = stopNode->prev;
					}
				}

				// check results
				bool checkResults = false;
				if (checkResults == true)
				{
					int nodeQty = 0;
					LinkedListNode<Particle> *node = p_particles->GetFirstNode();
					bool anyBad = false;
					while (node->next != &(p_particles->footer))
					{
						if (node->data.zDepth < node->next->data.zDepth)
						{
							anyBad = true;
						}

						nodeQty++;
						node = node->next;
					}
					if (anyBad == true && nodeQty > 0) // nodeQty > 0 here to prevent Release build from optimizing it out
					{
						throw gcnew Exception("BubbleSortParticlesFirstToLast: Sort failed - particles still out of order");
					}
				}
			}

			GameColor GetDamageMeterColor(float p_damageRatio)
			{
				if (p_damageRatio > 0.7f)
					return GameColor(0, 255, 0); // green
				else if (p_damageRatio > 0.3f)
					return GameColor(255, 255, 0); // yellow
				else
					return GameColor(255, 0, 0); // red
			}
		};
	}
}