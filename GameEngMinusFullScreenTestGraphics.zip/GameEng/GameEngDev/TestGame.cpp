#include "TestGame.h"

using namespace GameEng::Storage;
using namespace GameEngDev;
using namespace System::Diagnostics;
using namespace GameEng::Math;

LinkedList<TestGameObject> LinkedList<TestGameObject>::DeletedList("Deleted list for TestGameObject");
LinkedList<AlphaTrail> LinkedList<AlphaTrail>::DeletedList("Deleted list for AlphaTrail");
LinkedList<AlphaTrailPoint> LinkedList<AlphaTrailPoint>::DeletedList("Deleted list for AlphaTrailPoint");
LinkedList<MazeRunnerGameObject> LinkedList<MazeRunnerGameObject>::DeletedList("Deleted list for MazeRunnerGameObject");
LinkedList<MazeRunnerWall> LinkedList<MazeRunnerWall>::DeletedList("Deleted list for MazeRunnerWall");
LinkedList<PlatformerPlatform> LinkedList<PlatformerPlatform>::DeletedList("Deleted list for PlatformerPlatform");
LinkedList<BouncingBallWall> LinkedList<BouncingBallWall>::DeletedList("Deleted list for BouncingBallWall");
LinkedList<BouncingBall> LinkedList<BouncingBall>::DeletedList("Deleted list for BouncingBall");
LinkedList<DungeonPoint> LinkedList<DungeonPoint>::DeletedList("Deleted list for DungeonPoint");
LinkedList<DungeonVertex> LinkedList<DungeonVertex>::DeletedList("Deleted list for DungeonVertex");
LinkedList<DungeonPortal> LinkedList<DungeonPortal>::DeletedList("Deleted list for DungeonPortal");
LinkedList<DungeonNode> LinkedList<DungeonNode>::DeletedList("Deleted list for DungeonNode");
LinkedList<RandomDungeonBall> LinkedList<RandomDungeonBall>::DeletedList("Deleted list for RandomDungeonBall");
LinkedList<RandomDungeonBallPtr> LinkedList<RandomDungeonBallPtr>::DeletedList("Deleted list for RandomDungeonBallPtr");
LinkedList<RandomDungeonLight> LinkedList<RandomDungeonLight>::DeletedList("Deleted list for RandomDungeonLight");
LinkedList<RandomDungeonLightPtr> LinkedList<RandomDungeonLightPtr>::DeletedList("Deleted list for RandomDungeonLightPtr");
LinkedList<RandomDungeonDressing> LinkedList<RandomDungeonDressing>::DeletedList("Deleted list for RandomDungeonDressing");
LinkedList<RandomDungeonDressingPtr> LinkedList<RandomDungeonDressingPtr>::DeletedList("Deleted list for RandomDungeonDressingPtr");
LinkedList<RandomDungeonCreature> LinkedList<RandomDungeonCreature>::DeletedList("Deleted list for RandomDungeonCreature");
LinkedList<RandomDungeonCreaturePtr> LinkedList<RandomDungeonCreaturePtr>::DeletedList("Deleted list for RandomDungeonCreaturePtr");
LinkedList<MotionBlurTestWaypoint> LinkedList<MotionBlurTestWaypoint>::DeletedList("Deleted list for MotionBlurTestWaypoint");
LinkedList<MotionBlurObject> LinkedList<MotionBlurObject>::DeletedList("Deleted list for MotionBlurObject");
LinkedList<MotionBlurCamera> LinkedList<MotionBlurCamera>::DeletedList("Deleted list for MotionBlurCamera");
LinkedList<RandomDungeonBullet> LinkedList<RandomDungeonBullet>::DeletedList("Deleted list for RandomDungeonBullet");
LinkedList<RandomDungeonBulletPtr> LinkedList<RandomDungeonBulletPtr>::DeletedList("Deleted list for RandomDungeonBulletPtr");
LinkedList<TetherSwingStructure> LinkedList<TetherSwingStructure>::DeletedList("Deleted list for TetherSwingStructure");
//int RandomDungeonBall::potentialEnergyCheck = 0; // can't initialize in class

////////////
// OpenGL test
// standard gl headers from Microsoft - OpenGL 1.1

// for some reason despite them being in the linker options, I need these here to compile otherwise I get unresolved external errors.
#pragma comment(lib, "user32.lib") // GetDC
#pragma comment(lib, "gdi32.lib") // ChoosePixelFormat, SetPixelFormat, etc.
// opengl
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

void TestGame::Initialize()
{
	GameContext::Instance->Name = "Test";
	if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
		GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

	InitializeTests();

	GameBase::Initialize(); // call base initialize too.
}

void TestGame::InitializeTests()
{
	DestroyTests();
	linkedList = new LinkedList<TestGameObject>();
}

void TestGame::PerformTests()
{
	TestColor();
	TestLinkedList();
	TestVectors();
	TestOrients();
	TestAlgebra();
	TestMatrix();
	TestFrustum();
	TestModelSurface();
	TestHexConversion();
}

void TestGame::TestColor()
{
	GameColor white(255, 255, 255, 255);
	GameColor purple(255, 0, 255, 255);
	GameColor mixed(255, 147, 64, 128);
	unsigned int whiteInt = white.ToInt();
	unsigned int purpleInt = purple.ToInt();
	unsigned int mixedInt = mixed.ToInt();

	if (whiteInt != 0xffffffff)
		throw gcnew Exception("White conversion did not work!");
	if (purpleInt != 0xffff00ff)
		throw gcnew Exception("Purple conversion did not work!");
	if (mixedInt != 0x80ff9340)
		throw gcnew Exception("Mixed conversion did not work!");

	GameColor whiteTest(whiteInt);
	GameColor purpleTest(purpleInt);
	GameColor mixedTest(mixedInt);

	if (whiteTest.red != 255)
		throw gcnew Exception("White R failed");
	if (whiteTest.green != 255)
		throw gcnew Exception("White G failed");
	if (whiteTest.blue != 255)
		throw gcnew Exception("White B failed");
	if (whiteTest.alpha != 255)
		throw gcnew Exception("White A failed");
	if (purpleTest.red != 255)
		throw gcnew Exception("Purple R failed");
	if (purpleTest.green != 0)
		throw gcnew Exception("Purple G failed");
	if (purpleTest.blue != 255)
		throw gcnew Exception("Purple B failed");
	if (purpleTest.alpha != 255)
		throw gcnew Exception("Purple A failed");
	if (mixedTest.red != 255)
		throw gcnew Exception("Mixed R failed");
	if (mixedTest.green != 147)
		throw gcnew Exception("Mixed G failed");
	if (mixedTest.blue != 64)
		throw gcnew Exception("Mixed B failed");
	if (mixedTest.alpha != 128)
		throw gcnew Exception("Mixed A failed");
}

void TestGame::TestLinkedList()
{
	LinkedListNode<TestGameObject> *node = nullptr;
	node = linkedList->GetNewNode();
	linkedList->AddNode(node);
	node = linkedList->GetNewNode();
	linkedList->AddNode(node);
	node = linkedList->GetNewNode();
	linkedList->AddNode(node);

	LinkedListEnumerator<TestGameObject> enumerator(*linkedList);
	int count = 0;
	while (enumerator.MoveNext())
	{
		if (enumerator.Current() == nullptr)
			throw gcnew Exception("Null current - this is bad");
		count++;
	}
	if (count != 3)
		throw gcnew Exception("Parse was not 3 nodes");

	LinkedListEnumerator<TestGameObject> enumeratorBackwards(*linkedList, false);
	count = 0;
	while (enumeratorBackwards.MoveNext())
	{
		if (enumeratorBackwards.Current() == nullptr)
			throw gcnew Exception("Null current - this is bad");
		count++;
	}
	if (count != 3)
		throw gcnew Exception("Reverse parse was not 3 nodes");

	if (linkedList->Count() != 3)
		throw gcnew Exception("Linked List node count is not three");
	if (linkedList->DeletedList.Count() != 0)
		throw gcnew Exception("Deleted Linked List node count is not zero");

	linkedList->Clear();

	if (linkedList->Count() != 0)
		throw gcnew Exception("Linked List node count is not zero");
	if (linkedList->DeletedList.Count() != 3)
		throw gcnew Exception("Deleted Linked List node count is not three");

	node = linkedList->GetNewNode();
	linkedList->AddNode(node);

	if (linkedList->Count() != 1)
		throw gcnew Exception("Linked List node count is not one");
	if (linkedList->DeletedList.Count() != 2)
		throw gcnew Exception("Deleted Linked List node count is not two");

	linkedList->Clear();

	if (linkedList->Count() != 0)
		throw gcnew Exception("Linked List node count is not zero");
	if (linkedList->DeletedList.Count() != 3)
		throw gcnew Exception("Deleted Linked List node count is not three");
}

void TestGame::TestVectors()
{
	Vector2d zeroVector1(0,0);
	Vector2d zeroVector2 = Vector2d::ZeroVector();
	Vector2d v1(5, 6);
	Vector2d v2(3, -2);
	Vector2d v3, v4, v5, v6;
	v3.Set(v1);
	v4.Set(4, 3);
	v5 = v1 - v2;
	v6 = v1 + v2;
	float dp = v1 * v2;
	float cp = v1.CrossProd(v2);

	if (zeroVector1.Equals(zeroVector2) == false)
		throw gcnew Exception("2d Zero vectors aren't equal");

	if (v1.x != 5 || v1.y != 6)
		throw gcnew Exception("2d Constructor(x,y) failed");
	if (v3.Equals(v1) == false)
		throw gcnew Exception("2d Set(v) failed");
	if (v4.x != 4 || v4.y != 3)
		throw gcnew Exception("2d Set(x,y) failed");
	if (v5.x != 2 || v5.y != 8)
		throw gcnew Exception("2d Subtract failed");
	if (v6.x != 8 || v6.y != 4)
		throw gcnew Exception("2d add failed");
	if (dp != 3)
		throw gcnew Exception("2d dot product failed");
	if (cp != -28)
		throw gcnew Exception("2d cross product failed");
	if (v2.MagnitudeSquared() != 13)
		throw gcnew Exception("2d MagnitudeSquared failed");
	if (Vector2d::Vector(3, 4).Magnitude() != 5)
		throw gcnew Exception("2d Magnitude failed");
	if (Vector2d::Vector(1, 2).ScalarMult(4).Equals(Vector2d::Vector(4, 8)) == false)
		throw gcnew Exception("2d ScmVec failed");

	Vector2d unit = Vector2d::Vector(6, 8);
	unit.Normalize();
	if (unit.Magnitude() != 1)
		throw gcnew Exception("2d normalize failed");

	Vector3d zeroVector13(0, 0, 0);
	Vector3d zeroVector23 = Vector3d::ZeroVector();
	Vector3d v13(5, 6, 7);
	Vector3d v23(3, -2, 1);
	Vector3d v33, v43, v53, v63;
	v33.Set(v13);
	v43.Set(4, 3, 5);
	v53 = v13 - v23;
	v63 = v13 + v23;
	dp = v13 * v23;
	Vector3d cpv = v13.CrossProd(v23);

	if (zeroVector13.Equals(zeroVector23) == false)
		throw gcnew Exception("3d Zero vectors aren't equal");

	if (v13.x != 5 || v13.y != 6 || v13.z != 7)
		throw gcnew Exception("3d Constructor(x,y,z) failed");
	if (v33.Equals(v13) == false)
		throw gcnew Exception("3d Set(v) failed");
	if (v43.x != 4 || v43.y != 3 || v43.z != 5)
		throw gcnew Exception("3d Set(x,y,z) failed");
	if (v53.x != 2 || v53.y != 8 || v53.z != 6)
		throw gcnew Exception("3d Subtract failed");
	if (v63.x != 8 || v63.y != 4 || v63.z != 8)
		throw gcnew Exception("3d add failed");
	if (dp != 10)
		throw gcnew Exception("3d dot product failed");
	if (cpv.Equals(Vector3d::Vector(20, 16, -28)) == false)
		throw gcnew Exception("3d cross product failed");
	if (v23.MagnitudeSquared() != 14)
		throw gcnew Exception("3d MagnitudeSquared failed");
	if (Vector3d::Vector(3, 4, 5).Magnitude() != sqrt(50.0f))
		throw gcnew Exception("3d Magnitude failed");
	if (Vector3d::Vector(1, 2, 3).ScalarMult(4).Equals(Vector3d::Vector(4, 8, 12)) == false)
		throw gcnew Exception("3d ScmVec failed");

	Vector3d unit3 = Vector3d::Vector(6, 8, 9);
	unit.Normalize();
	if (unit.Magnitude() != 1)
		throw gcnew Exception("3d normalize failed");
}

void TestGame::TestOrients()
{
	Orient3d o1;
	Orient3d o2(Vector3d(1, 2, 3), Vector3d(4, 5, 6), Vector3d(7, 8, 9), Vector3d(10, 11, 12));
	if (o2.l.Equals(Vector3d(1, 2, 3)) == false || o2.u.Equals(Vector3d(4, 5, 6)) == false || o2.f.Equals(Vector3d(7, 8, 9)) == false || o2.p.Equals(Vector3d(10, 11, 12)) == false)
		throw gcnew Exception("Orient3d Constructore(l,u,f,p) failed");
	Orient3d o3(Vector3d(1, 2, 3), Vector3d(4, 5, 6), Vector3d(7, 8, 9));
	if (o3.l.Equals(Vector3d(1, 2, 3)) == false || o3.u.Equals(Vector3d(4, 5, 6)) == false || o3.f.Equals(Vector3d(7, 8, 9)) == false || o3.p.Equals(Vector3d(0, 0, 0)) == false)
		throw gcnew Exception("Orient3d Constructore(l,u,f) failed");
	Orient3d o4(o2);
	if (o4.l.Equals(o2.l) == false || o4.u.Equals(o2.u) == false || o4.f.Equals(o2.f) == false || o4.p.Equals(o2.p) == false)
		throw gcnew Exception("Orient3d Constructor(o) failed");
	Orient3d o5;
	o5.Set(o2);
	if (o5.l.Equals(o2.l) == false || o5.u.Equals(o2.u) == false || o5.f.Equals(o2.f) == false || o5.p.Equals(o2.p) == false)
		throw gcnew Exception("Orient3d set(o) failed");
	o5.Set(o3.l,o3.u,o3.f,o3.p);
	if (o5.l.Equals(o3.l) == false || o5.u.Equals(o3.u) == false || o5.f.Equals(o3.f) == false || o5.p.Equals(o3.p) == false)
		throw gcnew Exception("Orient3d set(l,u,f,p) failed");

	Orient3d test, id;
	test.LoadIdentity();
	id.LoadIdentity();
	Matrix4d idMatrix = id.MakeMatrix();
	test.Rotate(Vector3d(4, 5, 1), 60.0f, false);
	test.p = Vector3d(-4, 5, -3);
	Matrix4d forward = test.MakeMatrix();
	Matrix4d inverse = test.MakeInverseMatrix();
	Matrix4d mult = forward * inverse;
	if (mult.ApproximatelyEquals(idMatrix) == false)
		throw gcnew Exception("Inverse matrix failed");
	mult = forward * inverse;
	if (mult.ApproximatelyEquals(idMatrix) == false)
		throw gcnew Exception("Inverse matrix failed");
}

void TestGame::TestAlgebra()
{
	// various tests of meth utility functions to make sure they are correct and accurate
	
	// start with sphere colliding with a plane
	Vector3d sphereLocation(200, 100, 150);
	float sphereRadius = 10.0f;
	Vector3d sphereTravel(-200, -100, -150); // traveling to origin
	Vector3d planePoint1(0, 0, 0);
	Vector3d planePoint2(0, -100, 0);
	Vector3d planeNormal1(0, 1, 0);
	Vector3d planeNormal2(1, 0, 0);
	Vector3d planeNormal3(0, 0, 1);
	Vector3d planeNormal4(0, -1, 0);

	float collisionT = 0.0f;

	// 1 - sphere strikes plane
	if (MathUtilities::SpherePlaneCollision(sphereLocation, sphereTravel, sphereRadius, planePoint1, planeNormal1, collisionT) == false)
		throw gcnew Exception("1 - Sphere should have hit plane");
	else
	{
		Vector3d travelTo = sphereLocation + sphereTravel.ScalarMult(collisionT);
		if (travelTo.y != sphereRadius)
			throw gcnew Exception("1 - collision T is incorrect");
	}

	// 2 - sphere strikes plane
	if (MathUtilities::SpherePlaneCollision(sphereLocation, sphereTravel, sphereRadius, planePoint1, planeNormal2, collisionT) == false)
		throw gcnew Exception("2 - Sphere should have hit plane");
	else
	{
		Vector3d travelTo = sphereLocation + sphereTravel.ScalarMult(collisionT);
		if (travelTo.x != sphereRadius)
			throw gcnew Exception("3 - collision T is incorrect");
	}

	// 3 - sphere strikes plane
	if (MathUtilities::SpherePlaneCollision(sphereLocation, sphereTravel, sphereRadius, planePoint1, planeNormal3, collisionT) == false)
		throw gcnew Exception("3 - Sphere should have hit plane");
	else
	{
		Vector3d travelTo = sphereLocation + sphereTravel.ScalarMult(collisionT);
		if (travelTo.z != sphereRadius)
			throw gcnew Exception("3 - collision T is incorrect");
	}

	// 4 - sphere can't collide with plane facing the other way
	if (MathUtilities::SpherePlaneCollision(sphereLocation, sphereTravel, sphereRadius, planePoint1, planeNormal4, collisionT) == true)
		throw gcnew Exception("4 - Sphere should not have hit plane");

	// 5 - sphere can't collide with plane too far away
	if (MathUtilities::SpherePlaneCollision(sphereLocation, sphereTravel, sphereRadius, planePoint2, planeNormal1, collisionT) == true)
		throw gcnew Exception("5 - Sphere should not have hit plane");

	// 6 - sphere strikes point
	if (MathUtilities::SpherePointCollision(sphereLocation, sphereTravel, sphereRadius, planePoint1, collisionT) == false)
		throw gcnew Exception("6 - Sphere should have hit point");
	else
	{
		float correctValue = (sphereTravel.Magnitude() - sphereRadius) / sphereTravel.Magnitude();
		if (collisionT != correctValue)
			throw gcnew Exception(String::Format("6 - collision T should be {0.000000}", correctValue));
	}

	// 7 - sphere does not strike point
	if (MathUtilities::SpherePointCollision(sphereLocation, sphereTravel, sphereRadius, Vector3d(200,200,200), collisionT) == true)
		throw gcnew Exception("7 - Sphere should not have hit point");

	// 8 - sphere does not strike point
	if (MathUtilities::SpherePointCollision(sphereLocation, sphereTravel, sphereRadius, Vector3d(50,50,100), collisionT) == true)
		throw gcnew Exception("8 - Sphere should not have hit point");

	// 9 - sphere strikes line
	if (MathUtilities::SphereLineCollision(sphereLocation, sphereTravel, sphereRadius, Vector3d(0,0,0), Vector3d(0,1,0), collisionT) == false)
		throw gcnew Exception("9 - Sphere should have hit line");
	else
	{
		// check distance from projected collision point on line to sphere center
		Vector3d travelTo1 = sphereLocation + sphereTravel.ScalarMult(collisionT);
		Vector3d pointAlongLine1(0, travelTo1.y, 0);
		float magnitude1 = round(10000.f * (travelTo1 - pointAlongLine1).Magnitude())/10000.0f;
		if (magnitude1 != sphereRadius)
			throw gcnew Exception("9 - collision T is incorrect");
	}

	// 10 - sphere strikes line
	if (MathUtilities::SphereLineCollision(sphereLocation, sphereTravel, sphereRadius, Vector3d(0, 0, 0), Vector3d(1, 0, 0), collisionT) == false)
		throw gcnew Exception("10 - Sphere should have hit line");
	else
	{
		// check distance from projected collision point on line to sphere center
		Vector3d travelTo2 = sphereLocation + sphereTravel.ScalarMult(collisionT);
		Vector3d pointAlongLine2(travelTo2.x, 0, 0);
		float magnitude2 = round(10000.f * (travelTo2 - pointAlongLine2).Magnitude()) / 10000.0f;
		if (magnitude2 != sphereRadius)
			throw gcnew Exception("10 - collision T is incorrect");
	}

	// 11 - sphere strikes line
	if (MathUtilities::SphereLineCollision(sphereLocation, sphereTravel, sphereRadius, Vector3d(0, 0, 0), Vector3d(0, 0, 1), collisionT) == false)
		throw gcnew Exception("11 - Sphere should have hit line");
	else
	{
		// check distance from projected collision point on line to sphere center
		Vector3d travelTo3 = sphereLocation + sphereTravel.ScalarMult(collisionT);
		Vector3d pointAlongLine3(0, 0, travelTo3.z);
		float magnitude3 = round(10000.f * (travelTo3 - pointAlongLine3).Magnitude()) / 10000.0f;
		if (magnitude3 != sphereRadius)
			throw gcnew Exception("11 - collision T is incorrect");
	}

	// 12 - sphere does not strike line
	if (MathUtilities::SphereLineCollision(sphereLocation, sphereTravel, sphereRadius, Vector3d(40, 0, 0), Vector3d(0, 1, 0), collisionT) == true)
		throw gcnew Exception("12 - Sphere should not have hit line");
}

void TestGame::TestMatrix()
{
	//Matrix3d matrix1(1, 2, 3, 4, 5, 6, 7, 8, 9); // NO!!! They are all parallel!!!
	//Matrix3d matrix1(1, 4, 7, 2, 5, 8, 3, 6, 9); // This fails too!
	//Matrix3d matrix1(1, -4, -2, 5, -7, 2, -3, 1, 3);
	Matrix3d matrix1(-4, 8, -2, 5, 3, 8, 1, -7, 9);
	Matrix3d inverse1 = matrix1.Inverse();
	Matrix3d result1 = matrix1 * inverse1;
	Matrix3d result2 = inverse1 * matrix1;

	if (result1.m11 != 1.0f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result1.m12) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result1.m13) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result1.m21) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (result1.m22 != 1.0f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result1.m23) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result1.m31) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result1.m32) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (result1.m33 != 1.0f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");

	if (result2.m11 != 1.0f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result2.m12) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result2.m13) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result2.m21) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (result2.m22 != 1.0f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result2.m23) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result2.m31) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (abs(result2.m32) > 0.00001f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");
	if (result2.m33 != 1.0f)
		throw gcnew Exception("Inverse Matrix3d calculation failed");

	// Matrix4d operations
	// rotate mvpmatrix
	// calculate screen space point from world point
	// get inverse of mvpmatrix
	// calculate world point from screen space point
	// if resulting world point != original world point (approximately), inverse did not work
	// note: if a shader is reading a depth buffer along a x,y texcoord (x,y,z = 0.0-1.0), they must be converted to (-1.0-1.0) each before multiplying with the inverse projection matrix to get a workd point.
	GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
	graphics->SetPerspectiveProjection(45.0f, 0.01f, 100.0f);
	Orient3d orient;
	orient.LoadIdentity();
	orient.p = Vector3d(3.0f, -4.0f, 7.0f);
	orient.Rotate(Vector3d(1, 3, 5), 40.0f, false);
	graphics->DefaultTransform();
	graphics->ReverseTransform(orient);
	Matrix4d mvpMatrix = graphics->GetMVPMatrix();
	Vector4d worldPoint(1.0f, 4.0f, 5.0f, 1.0f);
	Vector4d v1 = mvpMatrix * worldPoint;
	if (abs(v1.w) < 0.00001f)
		throw gcnew System::Exception("Bad test - make sure w != 0.0");
	v1 = v1.ScalarMult(1.0f / v1.w);
	Matrix4d inverseMatrix = mvpMatrix.GetInverse();
	Vector4d v2 = inverseMatrix * v1;
	if (abs(v2.w) < 0.00001f)
		throw gcnew System::Exception("Bad test - make sure w != 0.0");
	v2 = v2.ScalarMult(1.0f / v2.w);
	if (worldPoint.ApproximatelyEquals(v2) == false)
		throw gcnew Exception("Matrix 4x4 inverse failed - World points are not equal");

	orient.LoadIdentity();
	orient.p = Vector3d(-13.0f, 45.0f, -64.0f);
	orient.Rotate(Vector3d(-1, 3, -5), -130.0f, false);
	graphics->DefaultTransform();
	graphics->ReverseTransform(orient);
	mvpMatrix = graphics->GetMVPMatrix();
	worldPoint.Set(53.0f, -64.0f, 105.0f, 1.0f);
	v1 = mvpMatrix * worldPoint;
	if (abs(v1.w) < 0.00001f)
		throw gcnew System::Exception("Bad test - make sure w != 0.0");
	v1 = v1.ScalarMult(1.0f / v1.w);
	inverseMatrix = mvpMatrix.GetInverse();
	v2 = inverseMatrix * v1;
	if (abs(v2.w) < 0.00001f)
		throw gcnew System::Exception("Bad test - make sure w != 0.0");
	v2 = v2.ScalarMult(1.0f / v2.w);
	if (worldPoint.ApproximatelyEquals(v2) == false)
		throw gcnew Exception("Matrix 4x4 inverse failed - World points are not equal");

}

void TestGame::TestFrustum()
{
	Frustum frustum;
	frustum.Test();
}

void TestGame::TestModelSurface()
{
	ModelVertex vertices[8] = {
		ModelVertex(Vector3d(30, 0, 30), 0),
		ModelVertex(Vector3d(30, 0, 27), 0),
		ModelVertex(Vector3d(30, 0, 23), 0),
		ModelVertex(Vector3d(30, 0, 20), 0),
		ModelVertex(Vector3d(27, 0, 20), 0),
		ModelVertex(Vector3d(23, 0, 20), 0),
		ModelVertex(Vector3d(20, 0, 20), 0),
		ModelVertex(Vector3d(20, 0, 30), 0)
	};
	ModelVertex vertices2[8] = {
		ModelVertex(Vector3d(30, 0, 20), 0),
		ModelVertex(Vector3d(30, 0, 23), 0),
		ModelVertex(Vector3d(30, 0, 27), 0),
		ModelVertex(Vector3d(30, 0, 30), 0),
		ModelVertex(Vector3d(27, 0, 30), 0),
		ModelVertex(Vector3d(23, 0, 30), 0),
		ModelVertex(Vector3d(20, 0, 30), 0),
		ModelVertex(Vector3d(20, 0, 20), 0)
	};
	// texture dimension don't matter, just needed a texture element
	GameTexture ^texture1 = gcnew GameTexture(false, false, 24, 24);
	GameTexture ^texture2 = gcnew GameTexture(false, false, 24, 24);
	ModelSurface surface1;
	surface1.Initialize(3, true);
	surface1.SetTexture0(texture1);
	surface1.SetBumpMapTexture(texture2);
	surface1.SetVertexIndex(0, 7);
	surface1.SetVertexIndex(1, 2);
	surface1.SetVertexIndex(2, 1);
	surface1.SetVertexTexCoords(0, vertices[surface1.GetSurfaceVertex(0)->vertexIndex].vertex.x, vertices[surface1.GetSurfaceVertex(0)->vertexIndex].vertex.z);
	surface1.SetVertexTexCoords(1, vertices[surface1.GetSurfaceVertex(1)->vertexIndex].vertex.x, vertices[surface1.GetSurfaceVertex(1)->vertexIndex].vertex.z);
	surface1.SetVertexTexCoords(2, vertices[surface1.GetSurfaceVertex(2)->vertexIndex].vertex.x, vertices[surface1.GetSurfaceVertex(2)->vertexIndex].vertex.z);
	// manually check normals
	surface1.CalculateNormals(vertices);

	ModelSurface surface2;
	surface2.Initialize(3, true);
	surface2.SetTexture0(texture1);
	surface2.SetBumpMapTexture(texture2);
	surface2.SetVertexIndex(0, 7);
	surface2.SetVertexIndex(1, 5);
	surface2.SetVertexIndex(2, 4);
	surface2.SetVertexTexCoords(0, vertices[surface2.GetSurfaceVertex(0)->vertexIndex].vertex.x, vertices[surface2.GetSurfaceVertex(0)->vertexIndex].vertex.z);
	surface2.SetVertexTexCoords(1, vertices[surface2.GetSurfaceVertex(1)->vertexIndex].vertex.x, vertices[surface2.GetSurfaceVertex(1)->vertexIndex].vertex.z);
	surface2.SetVertexTexCoords(2, vertices[surface2.GetSurfaceVertex(2)->vertexIndex].vertex.x, vertices[surface2.GetSurfaceVertex(2)->vertexIndex].vertex.z);
	// manually check normals
	surface2.CalculateNormals(vertices);

	ModelSurface surface3;
	surface3.Initialize(3, true);
	surface3.SetTexture0(texture1);
	surface3.SetBumpMapTexture(texture2);
	surface3.SetVertexIndex(0, 7);
	surface3.SetVertexIndex(1, 2);
	surface3.SetVertexIndex(2, 1);
	surface3.SetVertexTexCoords(0, vertices2[surface3.GetSurfaceVertex(0)->vertexIndex].vertex.x, vertices2[surface3.GetSurfaceVertex(0)->vertexIndex].vertex.z);
	surface3.SetVertexTexCoords(1, vertices2[surface3.GetSurfaceVertex(1)->vertexIndex].vertex.x, vertices2[surface3.GetSurfaceVertex(1)->vertexIndex].vertex.z);
	surface3.SetVertexTexCoords(2, vertices2[surface3.GetSurfaceVertex(2)->vertexIndex].vertex.x, vertices2[surface3.GetSurfaceVertex(2)->vertexIndex].vertex.z);
	// manually check normals
	surface3.CalculateNormals(vertices);

	ModelSurface surface4;
	surface4.Initialize(3, true);
	surface4.SetTexture0(texture1);
	surface4.SetBumpMapTexture(texture2);
	surface4.SetVertexIndex(0, 7);
	surface4.SetVertexIndex(1, 2);
	surface4.SetVertexIndex(2, 1);
	surface4.SetVertexTexCoords(0, vertices2[surface4.GetSurfaceVertex(0)->vertexIndex].vertex.x, vertices2[surface4.GetSurfaceVertex(0)->vertexIndex].vertex.z);
	surface4.SetVertexTexCoords(1, vertices2[surface4.GetSurfaceVertex(1)->vertexIndex].vertex.x, vertices2[surface4.GetSurfaceVertex(1)->vertexIndex].vertex.z);
	surface4.SetVertexTexCoords(2, vertices2[surface4.GetSurfaceVertex(2)->vertexIndex].vertex.x, vertices2[surface4.GetSurfaceVertex(2)->vertexIndex].vertex.z);
	// manually check normals
	surface4.CalculateNormals(vertices);

	delete texture1;
	delete texture2;
}

void TestGame::TestHexConversion()
{
	// sure enough this blows up, so we need an IsValid routine when the user is allowed to specify a hex string for conversion
	//int hex = Convert::ToInt32("h4k6895", 16);
}

//////////////
// OpenGL shader test
void TestGLShader::InitializeGL(HWND p_hWnd, int p_viewportWidth, int p_viewportHeight)
{
	hWnd = p_hWnd;

	glDC = GetDC(hWnd);

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof(PIXELFORMATDESCRIPTOR),
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER,    //Flags
		PFD_TYPE_RGBA,            //The kind of framebuffer. RGBA or palette.
		32,                        //Colordepth of the framebuffer.
		0, 0, 0, 0, 0, 0,
		0,
		0,
		0,
		0, 0, 0, 0,
		24,                        //Number of bits for the depthbuffer (supposedly 32 is only accomplished with special methods, 24 is best we can do?)
		8,                        //Number of bits for the stencilbuffer
		0,                        //Number of Aux buffers in the framebuffer.
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	};

	int pixelFormat = ChoosePixelFormat(glDC, &pfd);
	SetPixelFormat(glDC, pixelFormat, &pfd);

	glRC = wglCreateContext(glDC);
	// todo: should this be destroyed before we reassign the ARB RC?

	wglMakeCurrent(glDC, glRC);

	GetExtensionRoutines();
	bool useARBAttribs = true;
	if (useARBAttribs == true)
	{
		wglDeleteContext(glRC);

		// set up shader version to use (4.3 core)
		// 1.1 allows everything else to work.  4.3 breaks it all if compatibility isn't set
		GLint attribs[] = {
			WGL_CONTEXT_MAJOR_VERSION_ARB, 4,
			WGL_CONTEXT_MINOR_VERSION_ARB, 3,
			// use either this line or the next, not both
			//WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB,
			WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_CORE_PROFILE_BIT_ARB,
			0
		};
		glRC = wglCreateContextAttribsARB(glDC, 0, attribs);
		wglMakeCurrent(glDC, glRC);
	}

	//// set up initial parameters
	glFrontFace(GL_CW); // clockwise faces are front
	glCullFace(GL_BACK); // cull the back faces
	glEnable(GL_CULL_FACE);

	glDepthMask(GL_TRUE); // write to depth buffer
	glEnable(GL_DEPTH_TEST); // perform test
	glDepthFunc(GL_LESS); // occlude farther or equal objects

	//// usual alpha blending - will need to change for additive blending (like energy emitting particles as opposed to smoke)
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// force viewport size - don't let OpenGL predict what it is - let the width/height as decided by the main app be enforced - otherwise some things might seem a little off
	glViewport(0, 0, p_viewportWidth, p_viewportHeight);
}

void TestGLShader::GetExtensionRoutines()
{
	glGetProgramiv = (PFNGLGETPROGRAMIVPROC)wglGetProcAddress("glGetProgramiv");
	glGetProgramInfoLog = (PFNGLGETPROGRAMINFOLOGPROC)wglGetProcAddress("glGetProgramInfoLog");
	glDeleteProgram = (PFNGLDELETEPROGRAMPROC)wglGetProcAddress("glDeleteProgram");
	glCreateProgram = (PFNGLCREATEPROGRAMPROC)wglGetProcAddress("glCreateProgram");
	glAttachShader = (PFNGLATTACHSHADERPROC)wglGetProcAddress("glAttachShader");
	glDeleteShader = (PFNGLDELETESHADERPROC)wglGetProcAddress("glDeleteShader");
	glCreateShader = (PFNGLCREATESHADERPROC)wglGetProcAddress("glCreateShader");
	glShaderSource = (PFNGLSHADERSOURCEPROC)wglGetProcAddress("glShaderSource");
	glGetShaderiv = (PFNGLGETSHADERIVPROC)wglGetProcAddress("glGetShaderiv");
	glGetShaderInfoLog = (PFNGLGETSHADERINFOLOGPROC)wglGetProcAddress("glGetShaderInfoLog");
	glGetUniformLocation = (PFNGLGETUNIFORMLOCATIONPROC)wglGetProcAddress("glGetUniformLocation");
	glUseProgram = (PFNGLUSEPROGRAMPROC)wglGetProcAddress("glUseProgram");
	glUniform3fvARB = (PFNGLUNIFORM3FVARBPROC)wglGetProcAddress("glUniform3fvARB");
	glLinkProgram = (PFNGLLINKPROGRAMPROC)wglGetProcAddress("glLinkProgram");
	glCompileShader = (PFNGLCOMPILESHADERPROC)wglGetProcAddress("glCompileShader");
	glDeleteBuffers = (PFNGLDELETEBUFFERSPROC)wglGetProcAddress("glDeleteBuffers");
	glDeleteVertexArrays = (PFNGLDELETEVERTEXARRAYSPROC)wglGetProcAddress("glDeleteVertexArrays");
	glGenBuffers = (PFNGLGENBUFFERSPROC)wglGetProcAddress("glGenBuffers");
	glBindBuffer = (PFNGLBINDBUFFERPROC)wglGetProcAddress("glBindBuffer");
	glBufferData = (PFNGLBUFFERDATAPROC)wglGetProcAddress("glBufferData");
	glGenVertexArrays = (PFNGLGENVERTEXARRAYSPROC)wglGetProcAddress("glGenVertexArrays");
	glBindVertexArray = (PFNGLBINDVERTEXARRAYPROC)wglGetProcAddress("glBindVertexArray");
	glEnableVertexAttribArray = (PFNGLENABLEVERTEXATTRIBARRAYPROC)wglGetProcAddress("glEnableVertexAttribArray");
	glVertexAttribPointer = (PFNGLVERTEXATTRIBPOINTERPROC)wglGetProcAddress("glVertexAttribPointer");
	glUniform4fv = (PFNGLUNIFORM4FVPROC)wglGetProcAddress("glUniform4fv");
	glUniformMatrix4fv = (PFNGLUNIFORMMATRIX4FVPROC)wglGetProcAddress("glUniformMatrix4fv");
	wglCreateContextAttribsARB = (PFNWGLCREATECONTEXTATTRIBSARBPROC)wglGetProcAddress("wglCreateContextAttribsARB");
}

void TestGLShader::CompileShaderProgram()
{
	const GLchar * vertexShaderSource = (const GLchar*)R"(
		#version 430
		
		layout (location=0) in vec3 VertexPosition;
		layout (location=1) in vec3 VertexColor;

		out vec3 Color;

		void main()
		{
			Color = VertexColor;
			// seems this is called once for every vertex, whereas the fragment shader is called for EVERY pixel, and the color the fragment shader receives is already interpolated
			// a wave effect with vertex displacement calcualted at the vertex shader level is done on a tesselated quad, so it is adding more vertices inside to be intercepted by the
			//    vertex shader
			//if (VertexPosition.x > 0.0f)
			//	gl_Position = vec4(VertexPosition.x + 0.5, VertexPosition.y, VertexPosition.z, 1.0);
			//else 
				gl_Position = vec4(VertexPosition.x, VertexPosition.y, VertexPosition.z, 1.0);  // the 1.0 is distance (not depth) and automatically positions the vertex afterwards:  If 10.0, triangle renders small, 0.0 renders entire screen as a solid color, -1.0 nothing renders - ignores near and far of projection
			// so the 4th element automatically tends the vertex towards the vanishing point - but doesn't that mean the volume is by default a perspective?  How would an ortho scene handle this for a high depth?
		}
		)";
	const GLchar * fragmentShaderSource = (const GLchar*)R"(
		#version 430

		in vec3 Color;

		out vec4 FragColor;

		void main() {
			// so... since the triangle rendered with Gourand shading, that means this routine is only hit at each vertex.  Right?  So how does a fragment shader intercept EVERY pixel then?
			// or is the vertex shader pseudo executed for every pixel?
			// seems it's run for every pixel, so I don't understand what data is passed with VertexColor:  Apparently it's already interpolated when it arrives and doesn't match the individual vertex colors.
			//if (Color.r > 0.5 || Color.g > 0.5)
			//	FragColor = vec4(1.0,1.0,1.0,1.0);
			//else
				FragColor = vec4(Color.r, Color.g, Color.b, 1.0); // the 1.0 is alpha and is automatically blended afterwards
		}
		)";

	int vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	char* sourceDebug = (char *)vertexShaderSource;
	int length = strlen(sourceDebug);
	glShaderSource(vertexShaderId, 1, &vertexShaderSource, &length);
	glCompileShader(vertexShaderId);
	int param;
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &param);
	if (param == GL_FALSE)
	{
		int length;
		char log[1001];
		glGetShaderInfoLog(vertexShaderId, 1000, &length, log);
		glDeleteShader(vertexShaderId);
		throw gcnew System::Exception("Failed to compile vertex shader : " + gcnew System::String(log));
	}

	int fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
	sourceDebug = (char *)fragmentShaderSource;
	length = strlen(sourceDebug);
	glShaderSource(fragmentShaderId, 1, &fragmentShaderSource, &length);
	glCompileShader(fragmentShaderId);
	//int param;
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &param);
	if (param == GL_FALSE)
	{
		int length;
		char log[1001];
		glGetShaderInfoLog(fragmentShaderId, 1000, &length, log);
		glDeleteShader(fragmentShaderId);
		throw gcnew System::Exception("Failed to compile fragment shader : " + gcnew System::String(log));
	}

	// link it up
	programId = glCreateProgram();
	if (vertexShaderId != -1)
		glAttachShader(programId, vertexShaderId);
	if (fragmentShaderId != -1)
		glAttachShader(programId, fragmentShaderId);
	glLinkProgram(programId);

	// check link
	glGetProgramiv(programId, GL_LINK_STATUS, &param);
	if (param == GL_FALSE)
	{
		int length;
		char log[1001];
		glGetProgramInfoLog(programId, 1000, &length, log);

		glDeleteProgram(programId);
		throw gcnew System::Exception("Failed to link program: " + gcnew System::String(log));
	}

	// get rid of linked shaders to keep memory free
	glDeleteShader(vertexShaderId);
	glDeleteShader(fragmentShaderId);
}

void TestGLShader::SetupVAO()
{
	// version using array buffers only without indices
	//float positionData[] = {
	//	0.8f, -0.8f, 0.0f,
	//	-0.8f, -0.8f, 0.0f,
	//	0.0f, 0.8f, 0.0f,
	//	-0.8f, -0.8f, 0.0f,
	//	0.8f, -0.8f, 0.0f,
	//	0.0f, -1.6f, 0.0f
	//};
	//float colorData[] = {
	//	1.0f, 0.0f, 0.0f,
	//	0.0f, 1.0f, 0.0f,
	//	0.0f, 0.0f, 1.0f,
	//	1.0f, 0.0f, 0.0f,
	//	0.0f, 1.0f, 0.0f,
	//	0.0f, 0.0f, 1.0f
	//};

	// version using element indices
	float positionData[] = {
		0.8f, -0.8f, 0.0f,
		-0.8f, -0.8f, 0.0f,
		0.0f, 0.8f, 0.0f,
		0.0f, -1.6f, 0.0f
	};
	float colorData[] = {
		1.0f, 0.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 1.0f,
		1.0f, 1.0f, 1.0f
	};
	unsigned short indices[] = {
		0, 1, 2,
		1, 0, 3
	};

	GLuint vboHandles[2];
	glGenBuffers(2, vboHandles);
	GLuint positionBufferHandle = vboHandles[0];
	GLuint colorBufferHandle = vboHandles[1];

	// only needed for element version
	GLuint tempElementArrayId;
	glGenBuffers(1, &tempElementArrayId);
	elementArrayId = tempElementArrayId;

	// Popualte the position buffer
	glBindBuffer(GL_ARRAY_BUFFER, positionBufferHandle);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(float), positionData, GL_STATIC_DRAW); // two triangles (18 * with vertex array version)

	// Populate the color buffer
	glBindBuffer(GL_ARRAY_BUFFER, colorBufferHandle);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(float), colorData, GL_STATIC_DRAW); // two triangles (18 * with vertex array version)

	// Create and set up the vertex array object
	GLuint tempVaoId;
	glGenVertexArrays(1, &tempVaoId); // CLR doesn't like &vaoId on a class member
	vaoId = tempVaoId;
	glBindVertexArray(vaoId);

	// Enable the vertex attribute arrays;
	glEnableVertexAttribArray(0); // position
	glEnableVertexAttribArray(1); // color

	// Map index 0 to the position buffer
	glBindBuffer(GL_ARRAY_BUFFER, positionBufferHandle);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);

	// Map index 1 to the color buffer
	glBindBuffer(GL_ARRAY_BUFFER, colorBufferHandle);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, nullptr);

	// set up element index array (element version only)
	// apparently this is automatically part of the vao that was bound
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementArrayId);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, 6 * sizeof(unsigned short), &indices[0], GL_STATIC_DRAW);

	// done with setup
	glBindVertexArray(0);
	// for testing to see how render handles things
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); // element version only
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void TestGLShader::ClearScreen(GameColor &p_color)
{
	glClearColor(float(p_color.red) / 255.0f, float(p_color.green) / 255.0f, float(p_color.blue) / 255.0f, float(p_color.alpha) / 255.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// no effect on rendering, as expected
	//glMatrixMode(GL_PROJECTION);
	//glLoadIdentity();
	//gluPerspective(45.0f, 
	//	float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth())/
	//	float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight()),
	//	10.0f, 1000.0f);
	//glMatrixMode(GL_MODELVIEW);
	//glLoadIdentity();
	//glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
	//glTranslatef(0.0f, 0.0f, -10.0f);
}

void TestGLShader::RenderVAO()
{
	glUseProgram(programId);
	glBindVertexArray(vaoId);
	// not needed, apparently
	//glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementArrayId);
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, nullptr); // two triangles
	//glDrawArrays(GL_TRIANGLES, 0, 6);  // vertex array version
	glBindVertexArray(0);
}

void TestGLShader::SwapBuffers()
{
	::SwapBuffers(glDC);
}

void TestGLShader::DestroyGLObjects()
{
	glDeleteProgram(programId);
	GLuint tempVaoId = vaoId;
	glDeleteVertexArrays(1, &tempVaoId); // CLR doesn't like &vaoId on a class member

	// element version only
	// do we need this?  I'm guessing no since it binds with the vao
	GLuint tempElementArrayId = elementArrayId;
	glDeleteBuffers(1, &tempElementArrayId);
}

#pragma region TestRandomDungeon
//////////////////////////////////////////////////////////
// TestRandomDungeon

TestRandomDungeon::TestRandomDungeon(HWND p_hWnd) : GameBase(p_hWnd)
{
	dungeon = nullptr;
	randomDungeonGenerateIteration = nullptr;
	randomDungeonMakePortalIteration = nullptr;
	portalMap = nullptr;
	portalPartition = nullptr;
	mapLights = nullptr;

	playerOrient = nullptr;
	playerLightRef = nullptr;
	playerLightAttached = true;
	playerRun = true;
	playerLightType = 0;

	ball = nullptr;
	ballNativeObject = nullptr;
	balls = nullptr;
	currentPlayerControlBallId = 0;
	ballsRendered = 0;

	dungeonModelRegistry = nullptr;
	dressings = nullptr;
	creatures = nullptr;

	nodeObjectLists = nullptr;

	shadowMapRegistry = nullptr;

	timer = nullptr;

	postProcessingFrameBuffer = nullptr;
	postProcessingPingPongFrameBuffer = nullptr;
	currentMainFramebuffer = nullptr; // point to main

	showInformation = true;
	showInstructions = false;
	fullFrustum = true;
	stereoScopicMode = 0;
	splitScreenEyeSeparationInches = 2.75f;
	splitScreenCalibrationValue = 60.0f;
	usePartition = true;
	useLighting = true;
	useShadowMaps = true;
	useBackSideOfNodesForShadows = false;
	useWireframe = false;
	showExploredMap = false;
	freezeBalls = false;
	slowMotionFactor = 1.0f;
	maxLightQty = 8;
	portalDepth = -1;
	renderShadowNodes = true;
	checkLightNodeBounds = true;
	checkLightNodeBoundsHeavy = true; // ok for now until frame rate loss from heavy parsing becomes too much of a problem (sometimes losing 4 nodes bumps the fps up by 4 - that's worth keeping it)
	useDarkvision = false;
	grayScale = 0.0;
	renderHiddenCreatures = false;
	renderMirrorsWithNodesForDepthCulling = true;
	useClipPlanes = true;
	useSingleClipPlane = true; // this is the correct usage
	allowShadowMapUpdating = false; // reparse of lights while rendering second scene of anaglyph or mirrors - not needed with the deep parse, so keep false until we want to do a non-deep parse compare for speed
	useExceptionTest = false;
	joystickControl = false;
	joystickSlideFactor = 0.0f;
	joystickMoveFactor = 0.0f;
	exceptionTestNodeTimerMS = 0;
	useZeroMirrorAlpha = false;
	gamma = 1.0f;
	fade = 0.0f;
	allowScreenRender = true;
	allowShadowMapRender = true;
	minimumMirrorLightingDepth = 0;
	maximumRenderSectionAllowed = 100;
	allowObjectsInRender = true;
	allowObjectsInShadowMaps = true;
	allowParticles = true;
	uniqueNodeList = "";
	uniqueNodeQty = 0;
	fastPortalParse;
	blurRadius = 0.0f;
	focusByDepthRadius = 0.0f;
	blurKernel = nullptr;
	blurKernelElementQty = 0;
	lens = 1.0f;

	useMirrors = true;
	placeCreatures = true;
	placeWallLights = true;
	placeFlames = true;
	placeDressings = true;

	mirrorClipPlaneNormalAdjustment = 0.0008f; // world value of 1/10 inch or so, prevents artifacting at mirror's edge
	mirrorOrientAdjustment = 0.0008f; // world value of 1/10 inch or so, prevents artifacting at mirror's edge

	maxMirrorDepth = 5;

	sconceMode = 0;
	ambientColor = nullptr;
	ambientColorStart = nullptr;
	ambientColorEnd = nullptr;
	ambientColorBase = nullptr;
	ambientInterpolationMS = 0.0f;
	totalAmbientInterpolationMS = 0.0f;

	gravityPerMSMS = 32.0f / 10.0f / 1000.0f / 1000.0f;

	triguy = nullptr;
	triguyRedEyes = nullptr;
	triguyOrient = nullptr;
	triguyRedEyesOrient = nullptr;
	triguyJointOrients = nullptr;
	triguyAnimationTracker = nullptr;
	triguyNativeObject = nullptr;
	triguyRedEyesNativeObject = nullptr;
	sarahOrient = nullptr;
	sarahModel = nullptr;
	particleQueue = nullptr;

	jumpScareTimerMSf = 0;
	lightScale = 1.0f;

	shaderAppSettings = nullptr;
}

TestRandomDungeon::~TestRandomDungeon()
{
	Destroy();
}

void TestRandomDungeon::Initialize() 
{
	DestroyGameData();
	GameContext::Instance->Name = "Test";
	if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
		GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);
	shaderAppSettings = new GraphicsShaderAppSettings();
	shaderAppSettings->useShadowDepthBias = true;
	GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->SetShaderAppSettings(*shaderAppSettings);

	GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

	GameContext::Instance->TextureRegistry.RegisterTexture("TileDirt", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("tiledirt.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("TileDirtBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("tiledirt_normal.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Stonework", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Medieval_Stonework.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("StoneworkBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Medieval_Stonework_normal.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Brick2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Brick2BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2_normal_map.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Earth", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("EarthBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth_normal.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("EarthSpecularMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth_specular.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("EarthCityLights", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth_lights_lrg.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("EarthClouds", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::WhiteColorAlphaRed, GameContext::Instance->FileRegistry.RegisterFileResource("3b-over.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("EarthCloudsSpecular", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("3b-over_specmap.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Reticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"));
	GameContext::Instance->TextureRegistry.RegisterTexture("SarahMorgan", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, GameContext::Instance->FileRegistry.RegisterFileResource("Samara_morgan.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("TriGuyFace1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("TrFace1.bmp"));
	GameContext::Instance->TextureRegistry.RegisterTexture("TriGuyRedEyes", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, GameContext::Instance->FileRegistry.RegisterFileResource("TriguyRedEyes.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Flashlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flashlight2.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Hellraiser1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("cf001_diffuse.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Hellraiser1BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("cf001-01_normal.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("Hellraiser1SpecularMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("cf001_specular.png"));
	GameContext::Instance->TextureRegistry.RegisterTexture("MarbleTexture", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("A4240_3A.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("MarbleSpecular", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("A4240_3A_specular.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("CrackedStone", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("9691-diffuse.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("CrackedStoneBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("9691-normal.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("MetalTexture", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("metal-1561.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("MetalSpecular", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("metal-1561_specular.jpg"));
	GameContext::Instance->TextureRegistry.RegisterTexture("FireParticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"));

	dungeon = new RandomDungeon();
#ifdef _DEBUG
	int cellWidth = 40;
	int cellHeight = 30;
#else
	int cellWidth = 400;
	int cellHeight = 300;
#endif
	int cellSize = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() / cellHeight;
	if (cellSize == 0)
		cellSize = 1;
	int tempSize = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() / cellWidth;
	if (tempSize == 0)
		tempSize = 1;
	if (tempSize < cellSize)
		cellSize = tempSize;
	dungeon->Initialize(cellWidth, cellHeight,
		float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() / 2 - cellSize * cellWidth / 2),
		float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() / 2 - cellSize * cellHeight / 2),
		float(cellSize));

	randomDungeonGenerateIteration = new TestRandomDungeonGenerateIteration();
	//randomDungeonGenerateIteration->roomDensity = 0.0095f; // (95 rooms in a 100x100 grid) - keeps hallway winding at a minimum with a decent distribution
	randomDungeonGenerateIteration->roomDensity = 0.03f; // (300 rooms in a 100x100 grid) - keeps hallway winding at a minimum with a decent distribution
	randomDungeonGenerateIteration->maxRoomQty = int((cellWidth * cellHeight) * randomDungeonGenerateIteration->roomDensity);
	randomDungeonGenerateIteration->rooms = new DungeonRoom[randomDungeonGenerateIteration->maxRoomQty];

	randomDungeonMakePortalIteration = new TestRandomDungeonMakePortalIteration(cellWidth, cellHeight, 1.0f, 10, 6);
	randomDungeonMakePortalIteration->wallTextureRef = GameContext::TextureRegistry.GetTexture("Brick2");
	randomDungeonMakePortalIteration->ceilingTextureRef = GameContext::TextureRegistry.GetTexture("Stonework");
	randomDungeonMakePortalIteration->floorTextureRef = GameContext::TextureRegistry.GetTexture("TileDirt");
	randomDungeonMakePortalIteration->mirrorTextureRef = GameContext::TextureRegistry.GetTexture("MarbleTexture");
	randomDungeonMakePortalIteration->mirrorSpecularTextureRef = GameContext::TextureRegistry.GetTexture("MarbleSpecular");
	randomDungeonMakePortalIteration->wallBumpMapTextureRef = GameContext::TextureRegistry.GetTexture("Brick2BumpMap");
	randomDungeonMakePortalIteration->ceilingBumpMapTextureRef = GameContext::TextureRegistry.GetTexture("StoneworkBumpMap");
	randomDungeonMakePortalIteration->floorBumpMapTextureRef = GameContext::TextureRegistry.GetTexture("TileDirtBumpMap");
	randomDungeonMakePortalIteration->mirrorBumpMapTextureRef = nullptr;
	randomDungeonMakePortalIteration->wallSpecularTextureRef = nullptr;
	randomDungeonMakePortalIteration->ceilingSpecularTextureRef = nullptr;
	randomDungeonMakePortalIteration->floorSpecularTextureRef = nullptr;
	dressingsPlaced = false;

	portalMap = new PortalMap();
	// partition is initialized later

	fov = 45.0f;
	fovInterpolationMS = 0.0f;

	ambientColor = new Vector3d();
	ambientColor->Set(0, 0, 0);
	ambientColorStart = new Vector3d();
	ambientColorEnd = new Vector3d();
	ambientColorBase = new Vector3d();

	playerOrient = new Orient3d();
	playerOrient->LoadIdentity();
	rotateAngleDegrees = 315.0f;
	pitchAngleDegrees = 0.0f;
	playerOrient->Rotate(playerOrient->u, rotateAngleDegrees);
	playerOrient->Rotate(playerOrient->l, pitchAngleDegrees);
	playerRun = true;

	bulletDelayMS = 0;
	bulletSpeedPerMS = 0.01f; // 1000 ms per second = speed of 10 units per second = 100 world feet per MS.

	ball = new Model3d();
	ball->MakeSphere(GameContext::TextureRegistry.GetTexture("Earth"), GameContext::TextureRegistry.GetTexture("EarthBumpMap"), GameContext::TextureRegistry.GetTexture("EarthSpecularMap"));
	ball->SkinTexture1(GameContext::TextureRegistry.GetTexture("EarthCityLights"), GraphicsShaderCompositionTextureBlendOption::BlendInverseSqrtLight, GraphicsShaderCompositionTextureLightOption::Emittive);
	ball->SkinTexture2(GameContext::TextureRegistry.GetTexture("EarthClouds"), GraphicsShaderCompositionTextureBlendOption::DecalSaturateAlpha, GraphicsShaderCompositionTextureLightOption::Diffuse, GameContext::TextureRegistry.GetTexture("EarthCloudsSpecular"), GraphicsShaderCompositionSpecularBlendOption::Modulate);
	// fix the colors
	for (int c = 0; c < ball->GetColorQty(); c++)
		ball->GetColor(c)->Set(255, 255, 255);
	balls = new LinkedList<RandomDungeonBall>();
	playerBallLaunchPower = 0.0f;
	playerBallMaxLaunchPower = 30.0f / 10.0f / 1000.0f; // 30 feet per second, (don't allow 120, balls lose vertical bounce when let go for a long while if launched horizontally)
	//playerBallMaxLaunchPower = 120.0f / 10.0f / 1000.0f; // 120 feet per second, enough to fly over 200 feet in the air
	//playerBallLaunchPowerIncreasePerMSf = playerBallMaxLaunchPower / 500.0f; // 1/2 second to reach it
	//playerBallLaunchPowerIncreasePerMSf = playerBallMaxLaunchPower / 2000.0f; // 2 seconds to reach it
	playerBallLaunchPowerIncreasePerMSf = playerBallMaxLaunchPower / 250.0f; // 1/4 second to reach it

	timer = new GameTimer();
	gameTimeMSf = 0.0f; // Animate block will advance this

	shadowMapRegistry = new GraphicsShadowMapRegistry(16, 16, 2, 512, 1024); // having more than enough buffers helps prevent a re-render of a shadow map for a primary render

	blurKernel = new float[MAX_BLUR_KERNEL_ELEMENT_QTY];
	SetBlurKernel(MAX_BLUR_KERNEL_ELEMENT_QTY);

	// silly Halloween stuff
	triguy = new JointedModel3d();
	triguy->MakeTriGuy(GameContext::TextureRegistry.GetTexture("TriGuyFace1"));
	triguyRedEyes = new JointedModel3d();
	triguyRedEyes->MakeTriGuy(GameContext::TextureRegistry.GetTexture("TriGuyFace1"));
	triguyOrient = new Orient3d();
	triguyOrient->LoadIdentity();
	triguyRedEyesOrient = new Orient3d();
	triguyRedEyesOrient->LoadIdentity();
	triguyAnimationTracker = new JointedModelAnimationTracker();
	triguyAnimationTracker->SetAnimation(triguy->GetDefaultAnimation());
	triguyJointOrients = triguy->CreateGameObjectJointOrients(); // shared, used for both triguy and triguyredeyes for animation and rendering
	triguyRedEyes->GetJoint(0)->GetJointModel()->GetSurface(0)->SetTexture1(GameContext::TextureRegistry.GetTexture("TriGuyRedEyes"), GraphicsShaderCompositionTextureBlendOption::BlendInverseSqrtLight, GraphicsShaderCompositionTextureLightOption::Emittive);

	sarahModel = new Model3d();
	sarahModel->Initialize(2, 4, 1);
	sarahModel->GetColor(0)->Set(255, 255, 255, 128);
	sarahModel->GetColor(1)->Set(255, 255, 255, 0);
	sarahModel->GetVertex(0)->vertex = Vector3d(-489.0f, 1024.0f, 0.0f);
	sarahModel->GetVertex(1)->vertex = Vector3d(489.0f, 1024.0f, 0.0f);
	sarahModel->GetVertex(2)->vertex = Vector3d(489.0f, -1024.0f, 0.0f);
	sarahModel->GetVertex(3)->vertex = Vector3d(-489.0f, -1024.0f, 0.0f);
	sarahModel->GetVertex(0)->colorIndex = 0;
	sarahModel->GetVertex(1)->colorIndex = 0;
	sarahModel->GetVertex(2)->colorIndex = 1;
	sarahModel->GetVertex(3)->colorIndex = 1;
	sarahModel->GetSurface(0)->Initialize(4, true);
	sarahModel->GetSurface(0)->SetTexture0(GameContext::TextureRegistry.GetTexture("SarahMorgan"));
	sarahModel->GetSurface(0)->SetVertexIndex(0, 0);
	sarahModel->GetSurface(0)->SetVertexIndex(1, 1);
	sarahModel->GetSurface(0)->SetVertexIndex(2, 2);
	sarahModel->GetSurface(0)->SetVertexIndex(3, 3);
	sarahModel->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
	sarahModel->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.0f);
	sarahModel->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
	sarahModel->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);

	sarahOrient = new Orient3d();
	sarahOrient->LoadIdentity();

	// dressings
	dressings = new LinkedList<RandomDungeonDressing>();
	creatures = new LinkedList<RandomDungeonCreature>();
	bullets = new LinkedList<RandomDungeonBullet>();

	dungeonModelRegistry = new RandomDungeonModel[RandomDungeonObjectTypeEnum::Quantity];
	// 0 - simple cube
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube].model = new Model3d();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube].model->MakeCube();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube].material.shininess = 250.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube].material.specularReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube].material.ambientReflectivity.Set(1, 1, 1);

	// 1 - Hellraiser cube
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].model = new Model3d();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].model->MakeCube();
	Model3d *cube = dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].model;
	cube->GetColor(0)->Set(255, 255, 255);
	cube->GetColor(1)->Set(255, 255, 255);
	cube->GetColor(2)->Set(255, 255, 255);
	cube->GetColor(3)->Set(255, 255, 255);
	cube->GetColor(4)->Set(255, 255, 255);
	cube->GetColor(5)->Set(255, 255, 255);
	cube->GetColor(6)->Set(255, 255, 255);
	cube->GetColor(7)->Set(255, 255, 255);
	cube->GetSurface(0)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
	cube->GetSurface(1)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
	cube->GetSurface(2)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
	cube->GetSurface(3)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
	cube->GetSurface(4)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
	cube->GetSurface(5)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
	cube->GetSurface(0)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
	cube->GetSurface(1)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
	cube->GetSurface(2)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
	cube->GetSurface(3)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
	cube->GetSurface(4)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
	cube->GetSurface(5)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
	cube->GetSurface(0)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
	cube->GetSurface(1)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
	cube->GetSurface(2)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
	cube->GetSurface(3)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
	cube->GetSurface(4)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
	cube->GetSurface(5)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
	cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
	cube->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.0f);
	cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
	cube->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);
	cube->GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f);
	cube->GetSurface(1)->SetVertexTexCoords(1, 1.0f, 0.0f);
	cube->GetSurface(1)->SetVertexTexCoords(2, 1.0f, 1.0f);
	cube->GetSurface(1)->SetVertexTexCoords(3, 0.0f, 1.0f);
	cube->GetSurface(2)->SetVertexTexCoords(0, 0.0f, 0.0f);
	cube->GetSurface(2)->SetVertexTexCoords(1, 1.0f, 0.0f);
	cube->GetSurface(2)->SetVertexTexCoords(2, 1.0f, 1.0f);
	cube->GetSurface(2)->SetVertexTexCoords(3, 0.0f, 1.0f);
	cube->GetSurface(3)->SetVertexTexCoords(0, 0.0f, 0.0f);
	cube->GetSurface(3)->SetVertexTexCoords(1, 1.0f, 0.0f);
	cube->GetSurface(3)->SetVertexTexCoords(2, 1.0f, 1.0f);
	cube->GetSurface(3)->SetVertexTexCoords(3, 0.0f, 1.0f);
	cube->GetSurface(4)->SetVertexTexCoords(0, 0.0f, 0.0f);
	cube->GetSurface(4)->SetVertexTexCoords(1, 1.0f, 0.0f);
	cube->GetSurface(4)->SetVertexTexCoords(2, 1.0f, 1.0f);
	cube->GetSurface(4)->SetVertexTexCoords(3, 0.0f, 1.0f);
	cube->GetSurface(5)->SetVertexTexCoords(0, 0.0f, 0.0f);
	cube->GetSurface(5)->SetVertexTexCoords(1, 1.0f, 0.0f);
	cube->GetSurface(5)->SetVertexTexCoords(2, 1.0f, 1.0f);
	cube->GetSurface(5)->SetVertexTexCoords(3, 0.0f, 1.0f);
	// now calculate all the normals again now that we have tex coords
	//cube->ReScale(cubescale);
	cube->CalculateNormals();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].material.shininess = 500.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].material.specularReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube].material.ambientReflectivity.Set(1, 1, 1);

	// obelisk
	GameTexture ^crackStoneTexture = GameContext::Instance->TextureRegistry.GetTexture("CrackedStone");
	GameTexture ^crackStoneBumpMap = GameContext::Instance->TextureRegistry.GetTexture("CrackedStoneBumpMap");
	GameTexture ^marbleTexture = GameContext::Instance->TextureRegistry.GetTexture("MarbleTexture");
	GameTexture ^marbleSpecular = GameContext::Instance->TextureRegistry.GetTexture("MarbleSpecular");
	Model3d *obelisk = new Model3d();
	obelisk->Initialize(1, 12, 9);
	obelisk->GetColor(0)->Set(0, 0, 0);

	obelisk->GetVertex(0)->colorIndex = 0;
	obelisk->GetVertex(1)->colorIndex = 0;
	obelisk->GetVertex(2)->colorIndex = 0;
	obelisk->GetVertex(3)->colorIndex = 0;
	obelisk->GetVertex(4)->colorIndex = 0;
	obelisk->GetVertex(5)->colorIndex = 0;
	obelisk->GetVertex(6)->colorIndex = 0;
	obelisk->GetVertex(7)->colorIndex = 0;
	obelisk->GetVertex(8)->colorIndex = 0;
	obelisk->GetVertex(9)->colorIndex = 0;
	obelisk->GetVertex(10)->colorIndex = 0;
	obelisk->GetVertex(11)->colorIndex = 0;
	obelisk->GetVertex(0)->vertex.Set(0.025f, 0.7f, 0.025f);
	obelisk->GetVertex(1)->vertex.Set(-0.025f, 0.7f, 0.025f);
	obelisk->GetVertex(2)->vertex.Set(-0.025f, 0.7f, -0.025f);
	obelisk->GetVertex(3)->vertex.Set(0.025f, 0.7f, -0.025f);
	obelisk->GetVertex(4)->vertex.Set(0.05f, 0.625f, 0.05f);
	obelisk->GetVertex(5)->vertex.Set(-0.05f, 0.625f, 0.05f);
	obelisk->GetVertex(6)->vertex.Set(-0.05f, 0.625f, -0.05f);
	obelisk->GetVertex(7)->vertex.Set(0.05f, 0.625f, -0.05f);
	obelisk->GetVertex(8)->vertex.Set(0.1f, 0.0f, 0.1f);
	obelisk->GetVertex(9)->vertex.Set(-0.1f, 0.0f, 0.1f);
	obelisk->GetVertex(10)->vertex.Set(-0.1f, 0.0f, -0.1f);
	obelisk->GetVertex(11)->vertex.Set(0.1f, 0.0f, -0.1f);

	obelisk->GetSurface(0)->Initialize(4, true);
	obelisk->GetSurface(0)->SetVertexIndex(0, 0);
	obelisk->GetSurface(0)->SetVertexIndex(1, 1);
	obelisk->GetSurface(0)->SetVertexIndex(2, 2);
	obelisk->GetSurface(0)->SetVertexIndex(3, 3);
	obelisk->GetSurface(1)->Initialize(4, true);
	obelisk->GetSurface(1)->SetVertexIndex(0, 3);
	obelisk->GetSurface(1)->SetVertexIndex(1, 2);
	obelisk->GetSurface(1)->SetVertexIndex(2, 6);
	obelisk->GetSurface(1)->SetVertexIndex(3, 7);
	obelisk->GetSurface(2)->Initialize(4, true);
	obelisk->GetSurface(2)->SetVertexIndex(0, 2);
	obelisk->GetSurface(2)->SetVertexIndex(1, 1);
	obelisk->GetSurface(2)->SetVertexIndex(2, 5);
	obelisk->GetSurface(2)->SetVertexIndex(3, 6);
	obelisk->GetSurface(3)->Initialize(4, true);
	obelisk->GetSurface(3)->SetVertexIndex(0, 1);
	obelisk->GetSurface(3)->SetVertexIndex(1, 0);
	obelisk->GetSurface(3)->SetVertexIndex(2, 4);
	obelisk->GetSurface(3)->SetVertexIndex(3, 5);
	obelisk->GetSurface(4)->Initialize(4, true);
	obelisk->GetSurface(4)->SetVertexIndex(0, 0);
	obelisk->GetSurface(4)->SetVertexIndex(1, 3);
	obelisk->GetSurface(4)->SetVertexIndex(2, 7);
	obelisk->GetSurface(4)->SetVertexIndex(3, 4);
	obelisk->GetSurface(5)->Initialize(4, true);
	obelisk->GetSurface(5)->SetVertexIndex(0, 7);
	obelisk->GetSurface(5)->SetVertexIndex(1, 6);
	obelisk->GetSurface(5)->SetVertexIndex(2, 10);
	obelisk->GetSurface(5)->SetVertexIndex(3, 11);
	obelisk->GetSurface(6)->Initialize(4, true);
	obelisk->GetSurface(6)->SetVertexIndex(0, 6);
	obelisk->GetSurface(6)->SetVertexIndex(1, 5);
	obelisk->GetSurface(6)->SetVertexIndex(2, 9);
	obelisk->GetSurface(6)->SetVertexIndex(3, 10);
	obelisk->GetSurface(7)->Initialize(4, true);
	obelisk->GetSurface(7)->SetVertexIndex(0, 5);
	obelisk->GetSurface(7)->SetVertexIndex(1, 4);
	obelisk->GetSurface(7)->SetVertexIndex(2, 8);
	obelisk->GetSurface(7)->SetVertexIndex(3, 9);
	obelisk->GetSurface(8)->Initialize(4, true);
	obelisk->GetSurface(8)->SetVertexIndex(0, 4);
	obelisk->GetSurface(8)->SetVertexIndex(1, 7);
	obelisk->GetSurface(8)->SetVertexIndex(2, 11);
	obelisk->GetSurface(8)->SetVertexIndex(3, 8);
	obelisk->CalculateNormals();

	dungeonModelRegistry[RandomDungeonObjectTypeEnum::BlackObelisk].model = obelisk; // preserved for deletion later
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::BlackObelisk].material.shininess = 1000.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::BlackObelisk].material.specularReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::BlackObelisk].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::BlackObelisk].material.ambientReflectivity.Set(1, 1, 1);

	Model3d *marbleObelisk = new Model3d();
	obelisk->CopyTo(marbleObelisk);
	marbleObelisk->GetColor(0)->Set(255, 255, 255, 255);
	marbleObelisk->GetSurface(0)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(0)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
	marbleObelisk->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.0f);
	marbleObelisk->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
	marbleObelisk->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);
	marbleObelisk->GetSurface(1)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(1)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(1)->SetVertexTexCoords(1, 0.25f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(1)->SetVertexTexCoords(2, 0.25f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(1)->SetVertexTexCoords(3, 0.0f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(2)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(2)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(2)->SetVertexTexCoords(0, 0.25f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(2)->SetVertexTexCoords(1, 0.5f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(2)->SetVertexTexCoords(2, 0.5f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(2)->SetVertexTexCoords(3, 0.25f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(3)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(3)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(3)->SetVertexTexCoords(0, 0.5f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(3)->SetVertexTexCoords(1, 0.75f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(3)->SetVertexTexCoords(2, 0.75f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(3)->SetVertexTexCoords(3, 0.5f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(4)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(4)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(4)->SetVertexTexCoords(0, 0.75f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(4)->SetVertexTexCoords(1, 1.0f, 0.0f, 1.0f);
	marbleObelisk->GetSurface(4)->SetVertexTexCoords(2, 1.0f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(4)->SetVertexTexCoords(3, 0.75f, 0.2f, 2.0f);
	marbleObelisk->GetSurface(5)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(5)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(5)->SetVertexTexCoords(0, 0.0f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(5)->SetVertexTexCoords(1, 0.25f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(5)->SetVertexTexCoords(2, 0.25f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(5)->SetVertexTexCoords(3, 0.0f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(6)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(6)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(6)->SetVertexTexCoords(0, 0.25f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(6)->SetVertexTexCoords(1, 0.5f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(6)->SetVertexTexCoords(2, 0.5f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(6)->SetVertexTexCoords(3, 0.25f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(7)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(7)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(7)->SetVertexTexCoords(0, 0.5f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(7)->SetVertexTexCoords(1, 0.75f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(7)->SetVertexTexCoords(2, 0.75f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(7)->SetVertexTexCoords(3, 0.5f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(8)->SetTexture0(marbleTexture);
	marbleObelisk->GetSurface(8)->SetSpecularMapTexture0(marbleSpecular);
	marbleObelisk->GetSurface(8)->SetVertexTexCoords(0, 0.75f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(8)->SetVertexTexCoords(1, 1.0f, 0.2f, 1.0f);
	marbleObelisk->GetSurface(8)->SetVertexTexCoords(2, 1.0f, 1.0f, 2.0f);
	marbleObelisk->GetSurface(8)->SetVertexTexCoords(3, 0.75f, 1.0f, 2.0f);
	marbleObelisk->CalculateNormals();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::MarbleObelisk].model = marbleObelisk; // preserved for deletion later
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::MarbleObelisk].material.shininess = 250.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::MarbleObelisk].material.specularReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::MarbleObelisk].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::MarbleObelisk].material.ambientReflectivity.Set(1, 1, 1);

	Model3d *stoneObelisk = new Model3d();
	marbleObelisk->CopyTo(stoneObelisk);
	stoneObelisk->GetSurface(0)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(0)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(1)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(1)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(2)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(2)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(3)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(3)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(4)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(4)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(5)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(5)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(6)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(6)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(7)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(7)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->GetSurface(8)->SetTexture0(crackStoneTexture);
	stoneObelisk->GetSurface(8)->SetBumpMapTexture(crackStoneBumpMap);
	stoneObelisk->CalculateNormals();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::StoneObelisk].model = stoneObelisk; // preserved for deletion later
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::StoneObelisk].material.shininess = 50.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::StoneObelisk].material.specularReflectivity.Set(0.15f, 0.15f, 0.15f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::StoneObelisk].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::StoneObelisk].material.ambientReflectivity.Set(1, 1, 1);

	// triguy
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel = new JointedModel3d();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->MakeTriGuy(GameContext::TextureRegistry.GetTexture("TriGuyFace1"));
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetJoint(0)->GetJointModel()->GetSurface(0)->SetTexture1(GameContext::TextureRegistry.GetTexture("TriGuyRedEyes"), GraphicsShaderCompositionTextureBlendOption::BlendInverseSqrtLight, GraphicsShaderCompositionTextureLightOption::Emittive);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].material.shininess = 5.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].material.specularReflectivity.Set(0.0f, 0.0f, 0.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].material.ambientReflectivity.Set(1, 1, 1);

	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model = new Model3d();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->Initialize(1, 6, 8);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetColor(0)->Set(255, 255, 255);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(0)->colorIndex = 0;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(1)->colorIndex = 0;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(2)->colorIndex = 0;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(3)->colorIndex = 0;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(4)->colorIndex = 0;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(5)->colorIndex = 0;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(0)->vertex.Set(0.0f, 0.05f, 0.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(1)->vertex.Set(0.0f, 0.0f, -0.05f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(2)->vertex.Set(0.05f, 0.0f, 0.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(3)->vertex.Set(0.0f, 0.0f, 0.05f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(4)->vertex.Set(-0.05f, 0.0f, 0.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetVertex(5)->vertex.Set(0.0f, -0.05f, 0.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(0)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(0)->SetVertexIndex(0, 0);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(0)->SetVertexIndex(1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(0)->SetVertexIndex(2, 2);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(1)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(1)->SetVertexIndex(0, 0);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(1)->SetVertexIndex(1, 2);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(1)->SetVertexIndex(2, 3);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(2)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(2)->SetVertexIndex(0, 0);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(2)->SetVertexIndex(1, 3);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(2)->SetVertexIndex(2, 4);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(3)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(3)->SetVertexIndex(0, 0);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(3)->SetVertexIndex(1, 4);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(3)->SetVertexIndex(2, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(4)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(4)->SetVertexIndex(0, 5);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(4)->SetVertexIndex(1, 2);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(4)->SetVertexIndex(2, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(5)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(5)->SetVertexIndex(0, 5);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(5)->SetVertexIndex(1, 3);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(5)->SetVertexIndex(2, 2);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(6)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(6)->SetVertexIndex(0, 5);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(6)->SetVertexIndex(1, 4);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(6)->SetVertexIndex(2, 3);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(7)->Initialize(3, true);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(7)->SetVertexIndex(0, 5);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(7)->SetVertexIndex(1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->GetSurface(7)->SetVertexIndex(2, 4);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].model->CalculateNormals();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].material.shininess = 1000.0f;
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].material.specularReflectivity.Set(1.0f, 1.0f, 1.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].material.diffuseReflectivity.Set(1, 1, 1);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter].material.ambientReflectivity.Set(1, 1, 1);

	dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].model = new Model3d();
	Model3d *model = dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].model;
	model->Initialize(1, 8, 7);
	model->GetColor(0)->Set(255, 255, 255);
	model->GetVertex(0)->colorIndex = 0;
	model->GetVertex(1)->colorIndex = 0;
	model->GetVertex(2)->colorIndex = 0;
	model->GetVertex(3)->colorIndex = 0;
	model->GetVertex(4)->colorIndex = 0;
	model->GetVertex(5)->colorIndex = 0;
	model->GetVertex(6)->colorIndex = 0;
	model->GetVertex(7)->colorIndex = 0;
	model->GetVertex(0)->vertex.Set(-0.02f, 0.0f, -0.15f);
	model->GetVertex(1)->vertex.Set(0.02f, 0.0f, -0.15f);
	model->GetVertex(2)->vertex.Set(0.01f, 0.0f, 0.0f);
	model->GetVertex(3)->vertex.Set(0.00707f, 0.0f, 0.00707f);
	model->GetVertex(4)->vertex.Set(0.0f, 0.0f, 0.01f);
	model->GetVertex(5)->vertex.Set(-0.00707f, 0.0f, 0.00707f);
	model->GetVertex(6)->vertex.Set(-0.01f, 0.0f, 0.0f);
	model->GetVertex(7)->vertex.Set(0.0f, -0.075f, -0.15f);
	model->GetSurface(0)->Initialize(7, true);
	model->GetSurface(0)->SetVertexIndex(0, 0);
	model->GetSurface(0)->SetVertexIndex(1, 1);
	model->GetSurface(0)->SetVertexIndex(2, 2);
	model->GetSurface(0)->SetVertexIndex(3, 3);
	model->GetSurface(0)->SetVertexIndex(4, 4);
	model->GetSurface(0)->SetVertexIndex(5, 5);
	model->GetSurface(0)->SetVertexIndex(6, 6);
	model->GetSurface(0)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(0)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(0)->SetVertexTexCoords(0, (model->GetVertex(0)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(0)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(0)->SetVertexTexCoords(1, (model->GetVertex(1)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(1)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(0)->SetVertexTexCoords(2, (model->GetVertex(2)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(2)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(0)->SetVertexTexCoords(3, (model->GetVertex(3)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(3)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(0)->SetVertexTexCoords(4, (model->GetVertex(4)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(4)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(0)->SetVertexTexCoords(5, (model->GetVertex(5)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(5)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(0)->SetVertexTexCoords(6, (model->GetVertex(6)->vertex.x + 0.02f) * 5.0f, (model->GetVertex(6)->vertex.x + 0.15f) * 5.0f);
	model->GetSurface(1)->Initialize(3, true);
	model->GetSurface(1)->SetVertexIndex(0, 0);
	model->GetSurface(1)->SetVertexIndex(1, 6);
	model->GetSurface(1)->SetVertexIndex(2, 7);
	model->GetSurface(1)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(1)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f);
	model->GetSurface(1)->SetVertexTexCoords(1, 0.40f, 0.0f);
	model->GetSurface(1)->SetVertexTexCoords(2, 0.5f, 0.75f);
	model->GetSurface(2)->Initialize(3, true);
	model->GetSurface(2)->SetVertexIndex(0, 6);
	model->GetSurface(2)->SetVertexIndex(1, 5);
	model->GetSurface(2)->SetVertexIndex(2, 7);
	model->GetSurface(2)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(2)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(2)->SetVertexTexCoords(0, 0.40f, 0.0f);
	model->GetSurface(2)->SetVertexTexCoords(1, 0.45f, 0.0f);
	model->GetSurface(2)->SetVertexTexCoords(2, 0.5f, 0.75f);
	model->GetSurface(3)->Initialize(3, true);
	model->GetSurface(3)->SetVertexIndex(0, 5);
	model->GetSurface(3)->SetVertexIndex(1, 4);
	model->GetSurface(3)->SetVertexIndex(2, 7);
	model->GetSurface(3)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(3)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(3)->SetVertexTexCoords(0, 0.45f, 0.0f);
	model->GetSurface(3)->SetVertexTexCoords(1, 0.5f, 0.0f);
	model->GetSurface(3)->SetVertexTexCoords(2, 0.5f, 0.75f);
	model->GetSurface(4)->Initialize(3, true);
	model->GetSurface(4)->SetVertexIndex(0, 4);
	model->GetSurface(4)->SetVertexIndex(1, 3);
	model->GetSurface(4)->SetVertexIndex(2, 7);
	model->GetSurface(4)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(4)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(4)->SetVertexTexCoords(0, 0.5f, 0.0f);
	model->GetSurface(4)->SetVertexTexCoords(1, 0.55f, 0.0f);
	model->GetSurface(4)->SetVertexTexCoords(2, 0.5f, 0.75f);
	model->GetSurface(5)->Initialize(3, true);
	model->GetSurface(5)->SetVertexIndex(0, 3);
	model->GetSurface(5)->SetVertexIndex(1, 2);
	model->GetSurface(5)->SetVertexIndex(2, 7);
	model->GetSurface(5)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(5)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(5)->SetVertexTexCoords(0, 0.55f, 0.0f);
	model->GetSurface(5)->SetVertexTexCoords(1, 0.6f, 0.0f);
	model->GetSurface(5)->SetVertexTexCoords(2, 0.5f, 0.75f);
	model->GetSurface(6)->Initialize(3, true);
	model->GetSurface(6)->SetVertexIndex(0, 2);
	model->GetSurface(6)->SetVertexIndex(1, 1);
	model->GetSurface(6)->SetVertexIndex(2, 7);
	model->GetSurface(6)->SetTexture0(GameContext::TextureRegistry.GetTexture("MetalTexture"));
	model->GetSurface(6)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("MetalSpecular"));
	model->GetSurface(6)->SetVertexTexCoords(0, 0.6f, 0.0f);
	model->GetSurface(6)->SetVertexTexCoords(1, 1.0f, 0.0f);
	model->GetSurface(6)->SetVertexTexCoords(2, 0.5f, 0.75f);
	model->CalculateNormals();
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].material.specularReflectivity.Set(1.0f, 1.0f, 1.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].material.ambientReflectivity.Set(1.0f, 1.0f, 1.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].material.diffuseReflectivity.Set(1.0f, 1.0f, 1.0f);
	dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].material.shininess = 512.0f;

	particleQueue = new GraphicsParticleQueue();

	GameBase::Initialize(); // call base initialize too.
}

void TestRandomDungeon::DestroyGameData()
{
	if (dungeon != nullptr)
	{
		delete dungeon;
		dungeon = nullptr;
	}
	if (randomDungeonGenerateIteration != nullptr)
	{
		delete randomDungeonGenerateIteration;
		randomDungeonGenerateIteration = nullptr;
	}
	if (randomDungeonMakePortalIteration != nullptr)
	{
		delete randomDungeonMakePortalIteration;
		randomDungeonMakePortalIteration = nullptr;
	}
	if (dungeonModelRegistry != nullptr)
	{
		delete[] dungeonModelRegistry;
		dungeonModelRegistry = nullptr;
	}
	if (dressings != nullptr)
	{
		delete dressings;
		dressings = nullptr;
	}
	if (creatures != nullptr)
	{
		delete creatures;
		creatures = nullptr;
	}
	// no need for this to be done before portal map
	if (nodeObjectLists != nullptr)
	{
		delete[] nodeObjectLists;
		nodeObjectLists = nullptr;
	}
	if (ambientColor != nullptr)
	{
		delete ambientColor;
		ambientColor = nullptr;
	}
	if (ambientColorStart != nullptr)
	{
		delete ambientColorStart;
		ambientColorStart = nullptr;
	}
	if (ambientColorEnd != nullptr)
	{
		delete ambientColorEnd;
		ambientColorEnd = nullptr;
	}
	if (ambientColorBase != nullptr)
	{
		delete ambientColorBase;
		ambientColorBase = nullptr;
	}
	if (portalMap != nullptr)
	{
		delete portalMap;
		portalMap = nullptr;
	}
	if (portalPartition != nullptr)
	{
		delete portalPartition;
		portalPartition = nullptr;
	}
	if (playerOrient != nullptr)
	{
		delete playerOrient;
		playerOrient = nullptr;
	}
	if (ball != nullptr)
	{
		delete ball;
		ball = nullptr;
	}
	if (ballNativeObject != nullptr)
	{
		delete ballNativeObject;
		ballNativeObject = nullptr;
	}
	if (balls != nullptr)
	{
		delete balls;
		balls = nullptr;
	}
	if (shadowMapRegistry != nullptr)
	{
		delete shadowMapRegistry;
		shadowMapRegistry = nullptr;
	}
	if (postProcessingFrameBuffer != nullptr)
	{
		delete postProcessingFrameBuffer;
		postProcessingFrameBuffer = nullptr;
	}
	if (postProcessingPingPongFrameBuffer != nullptr)
	{
		delete postProcessingPingPongFrameBuffer;
		postProcessingPingPongFrameBuffer = nullptr;
	}
	if (mapLights != nullptr)
	{
		delete mapLights;
		mapLights = nullptr;
	}
	if (timer != nullptr)
	{
		delete timer;
		timer = nullptr;
	}
	if (triguy != nullptr)
	{
		delete triguy;
		triguy = nullptr;
	}
	if (triguyRedEyes != nullptr)
	{
		delete triguyRedEyes;
		triguyRedEyes = nullptr;
	}
	if (triguyJointOrients != nullptr)
	{
		delete triguyJointOrients;
		triguyJointOrients = nullptr;
	}
	if (triguyAnimationTracker != nullptr)
	{
		delete triguyAnimationTracker;
		triguyAnimationTracker = nullptr;
	}
	if (triguyNativeObject != nullptr)
	{
		delete triguyNativeObject;
		triguyNativeObject = nullptr;
	}
	if (triguyRedEyesNativeObject != nullptr)
	{
		delete triguyRedEyesNativeObject;
		triguyRedEyesNativeObject = nullptr;
	}
	if (sarahModel != nullptr)
	{
		delete sarahModel;
		sarahModel = nullptr;
	}
	if (sarahOrient != nullptr)
	{
		delete sarahOrient;
		sarahOrient = nullptr;
	}
	if (particleQueue != nullptr)
	{
		delete particleQueue;
		particleQueue = nullptr;
	}
	if (shaderAppSettings != nullptr)
	{
		delete shaderAppSettings;
		shaderAppSettings = nullptr;
	}
}

void TestRandomDungeon::Destroy() 
{
	// correct way to destroy when API has registered resources to destroy

	GameBase::Destroy();
	// get rid of common game-level resources, leave app-level resources alone
	GameApplicationContext::Instance->DestroyGame();
	// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
	//  game instances)
	DestroyGameData();
	GameContext::Instance->DestroyGame();
}

void TestRandomDungeon::ViewportSizeChanged(GameViewport ^p_viewport) 
{
	// adjust rects on dungeon graphic cells
	int cellSize = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() / dungeon->cellHeight;
	if (cellSize == 0)
		cellSize = 1;
	int tempSize = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() / dungeon->cellWidth;
	if (tempSize == 0)
		tempSize = 1;
	if (tempSize < cellSize)
		cellSize = tempSize;
	dungeon->SetCellRects(
		float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() / 2 - cellSize * dungeon->cellWidth / 2),
		float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() / 2 - cellSize * dungeon->cellHeight / 2),
		float(cellSize));

	// get rid of postprocessing buffers - they need to be resized, which will happen when they are recreated in RenderDungeon
	if (postProcessingFrameBuffer != nullptr)
		GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->DestroyFrameBuffer(postProcessingFrameBuffer);
	if (postProcessingPingPongFrameBuffer != nullptr)
		GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->DestroyFrameBuffer(postProcessingPingPongFrameBuffer);
}

bool TestRandomDungeon::DoGameLoop() 
{
	if (keyboardKeys.GetKey(27)->IsPressed())
	{
		if (mouse.IsVisible() == false)
			mouse.Show();

		return false;
	}

	joystick->Poll();
	timer->Poll();

	// run iterations for prep
	// if iterations not done, keyboard events and animations will not fire
	if (randomDungeonGenerateIteration->phase != RandomDungeonGenerateIterationPhase::Done)
	{
		if (randomDungeonGenerateIteration->phase != RandomDungeonGenerateIterationPhase::Done)
		{
			if (keyboardKeys.GetKey('M')->IsClicked())
				useMirrors = !useMirrors;
			if (keyboardKeys.GetKey('C')->IsClicked())
				placeCreatures = !placeCreatures;
			if (keyboardKeys.GetKey('D')->IsClicked())
				placeDressings = !placeDressings;
			if (keyboardKeys.GetKey('F')->IsClicked())
				placeFlames = !placeFlames;
			if (keyboardKeys.GetKey('L')->IsClicked())
				placeWallLights = !placeWallLights;
			if (keyboardKeys.GetKey('A')->IsClicked())
			{
				if (useMirrors || placeCreatures || placeDressings || placeFlames || placeWallLights)
				{
					useMirrors = false;
					placeCreatures = false;
					placeDressings = false;
					placeFlames = false;
					placeWallLights = false;
				}
				else
				{
					useMirrors = true;
					placeCreatures = true;
					placeDressings = true;
					placeFlames = true;
					placeWallLights = true;
				}
			}

			keyboardKeys.ClearClicked();
		}

		int numberOfIterations = (dungeon->cellWidth * dungeon->cellHeight) / 500;
		if (numberOfIterations == 0)
			numberOfIterations = 1;
		RunRandomDungeonGenerateIterations(numberOfIterations);
		return true;
	}
	else if (randomDungeonMakePortalIteration->phase != RandomDungeonMakePortalIterationPhase::Done)
	{
		int numberOfIterations = (dungeon->cellWidth * dungeon->cellHeight) / 500;
		if (numberOfIterations == 0)
			numberOfIterations = 1;
		RunRandomDungeonMakePortalIterations(numberOfIterations);
		return true;
	}
	else
	{
		// if it just finished, set up dressings
		if (dressingsPlaced == false)
		{
			FastRandom fastRandom;

			// place a dressing in each room for simplicity for now
			int nextType = 0;
			DungeonPoint points[5];
			int roomsPerCreature = 5;
			int triguyNumber = 0;
			int arbiterNumber = 2;
			for (int i = 0; i < randomDungeonGenerateIteration->roomQty; i++)
			{
				int roomSize = randomDungeonGenerateIteration->rooms[i].width * randomDungeonGenerateIteration->rooms[i].height;
				int numberOfDressings = roomSize / 9;
				if (numberOfDressings < 0)
					numberOfDressings = 1;
				// 1-5
				for (int j = 0; j < numberOfDressings; j++) // one per room
				{
					int randomH, randomV;
					bool done = false;
					while (done == false)
					{
						randomH = fastRandom.GetRandomInteger(randomDungeonGenerateIteration->rooms[i].left, randomDungeonGenerateIteration->rooms[i].right - 1);
						randomV = fastRandom.GetRandomInteger(randomDungeonGenerateIteration->rooms[i].top, randomDungeonGenerateIteration->rooms[i].bottom - 1);

						// make sure nothing else takes up this space
						bool found = false;
						for (int k = 0; k < j; k++)
						{
							if (points[k].x == randomH && points[k].y == randomV)
							{
								found = true;
								break;
							}
						}

						if (found == false)
						{
							points[j].x = randomH;
							points[j].y = randomV;
							done = true;
						}
					}

					LinkedListNode<RandomDungeonDressing> *newDressing = dressings->GetNewNode();
					newDressing->data.Initialize();

					nextType++;
					if (nextType > 4)
						nextType = 0;
					//nextType = 0;
					// int nextType = fastRandom.GetRandomInteger(0, 4);
					switch (nextType)
					{
					case 0:
						newDressing->data.type = RandomDungeonObjectTypeEnum::TestCube;
						newDressing->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::TestCube]);
						newDressing->data.scale = 0.2f;
						newDressing->data.orient.p = Vector3d(float(randomH) + 0.5f, 0.2f, float(randomV) + 0.5f);
						newDressing->data.renderRadius = float(Math::Sqrt(newDressing->data.scale * newDressing->data.scale + newDressing->data.scale * newDressing->data.scale + newDressing->data.scale * newDressing->data.scale));
						break;
					case 1:
						newDressing->data.type = RandomDungeonObjectTypeEnum::HellraiserCube;
						newDressing->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::HellraiserCube]);
						newDressing->data.scale = 0.05f + float(fastRandom.GetRandomInteger(0, 10)) / 200.0f;
						newDressing->data.orient.p = Vector3d(float(randomH) + 0.5f, float(fastRandom.GetRandomInteger(0, 20)) / 50.0f + 0.3f, float(randomV) + 0.5f);
						newDressing->data.orient.Rotate(newDressing->data.orient.l, float(fastRandom.GetRandomInteger(0, 90)));
						newDressing->data.renderRadius = float(Math::Sqrt(newDressing->data.scale * newDressing->data.scale + newDressing->data.scale * newDressing->data.scale + newDressing->data.scale * newDressing->data.scale));
						// up to 1/2 revolution per second
						newDressing->data.rotationDegreesPerMS = (float(fastRandom.GetRandomInteger(0, 360)) - 180) / 1000.0f;
						break;
					case 2:
						newDressing->data.type = RandomDungeonObjectTypeEnum::BlackObelisk;
						newDressing->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::BlackObelisk]);
						newDressing->data.scale = float(fastRandom.GetRandomInteger(0, 10)) * 0.08f + 0.5f; // 1.0f;
						newDressing->data.orient.p = Vector3d(float(randomH) + 0.5f, 0.0f, float(randomV) + 0.5f);
						newDressing->data.orient.Rotate(newDressing->data.orient.u, float(fastRandom.GetRandomInteger(0, 90)));
						newDressing->data.renderRadius = newDressing->data.modelRef->model->GetVertex(0)->vertex.y;
						break;
					case 3:
						newDressing->data.type = RandomDungeonObjectTypeEnum::MarbleObelisk;
						newDressing->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::MarbleObelisk]);
						newDressing->data.scale = float(fastRandom.GetRandomInteger(0, 10)) * 0.08f + 0.5f; // 1.0f;
						newDressing->data.orient.p = Vector3d(float(randomH) + 0.5f, 0.0f, float(randomV) + 0.5f);
						newDressing->data.orient.Rotate(newDressing->data.orient.u, float(fastRandom.GetRandomInteger(0, 90)));
						newDressing->data.renderRadius = newDressing->data.modelRef->model->GetVertex(0)->vertex.y;
						break;
					case 4:
						newDressing->data.type = RandomDungeonObjectTypeEnum::StoneObelisk;
						newDressing->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::StoneObelisk]);
						newDressing->data.scale = float(fastRandom.GetRandomInteger(0, 10)) * 0.08f + 0.5f; // 1.0f;
						newDressing->data.orient.p = Vector3d(float(randomH) + 0.5f, 0.0f, float(randomV) + 0.5f);
						newDressing->data.orient.Rotate(newDressing->data.orient.u, float(fastRandom.GetRandomInteger(0, 90)));
						newDressing->data.renderRadius = newDressing->data.modelRef->model->GetVertex(0)->vertex.y;
						break;
					}
					dressings->AddNode(newDressing);

				} // each object in the room

				// should we place a creature?
				if (i % (roomsPerCreature + triguyNumber) == 0 && placeCreatures == true)
				{
					LinkedListNode<RandomDungeonCreature> *newCreature = creatures->GetNewNode();
					newCreature->data.Initialize();

					// triguy!
					newCreature->data.scale = float(fastRandom.GetRandomInteger(0, 11)) * 0.0125f + 0.0125f;
					newCreature->data.orient.p = Vector3d(
						randomDungeonGenerateIteration->rooms[i].left + randomDungeonGenerateIteration->rooms[i].width / 2.0f,
						2.8f * newCreature->data.scale,
						randomDungeonGenerateIteration->rooms[i].top + randomDungeonGenerateIteration->rooms[i].height / 2.0f);
					newCreature->data.type = RandomDungeonObjectTypeEnum::Triguy;
					newCreature->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy]);
					newCreature->data.speed = float(fastRandom.GetRandomInteger(0, 10)) * 0.1f + 0.5f;
					newCreature->data.renderRadius = 3.0f * newCreature->data.scale; // just a guess, barely matters - probably closer to 2.5f (2.0f is too small)
					// this will trigger finding a new portal upon AI animation
					newCreature->data.targetPosition = newCreature->data.orient.p;
					if (newCreature->data.jointOrients != nullptr)
					{
						if (newCreature->data.jointOrientQty < dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetTotalJointOrientQty())
						{
							delete[] newCreature->data.jointOrients;
							newCreature->data.jointOrients = new Orient3d[dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetTotalJointOrientQty()];
						}
					}
					else
					{
						newCreature->data.jointOrients = new Orient3d[dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetTotalJointOrientQty()];
					}
					newCreature->data.jointedModelAnimationTracker.SetAnimation(dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetAnimation(1)); // walking

					creatures->AddNode(newCreature);

					// maintain node lists
					MaintainCreatureNodeList(newCreature->data);
				}
				else if (i % (roomsPerCreature + arbiterNumber) == 0 && placeCreatures == true)
				{
					LinkedListNode<RandomDungeonCreature> *newCreature = creatures->GetNewNode();
					newCreature->data.Initialize();

					// arbiter
					newCreature->data.scale = 1.0f;
					newCreature->data.orient.p = Vector3d(
						randomDungeonGenerateIteration->rooms[i].left + randomDungeonGenerateIteration->rooms[i].width / 2.0f,
						0.7f,
						randomDungeonGenerateIteration->rooms[i].top + randomDungeonGenerateIteration->rooms[i].height / 2.0f);
					newCreature->data.type = RandomDungeonObjectTypeEnum::Arbiter;
					newCreature->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::Arbiter]);
					newCreature->data.speed = float(fastRandom.GetRandomInteger(5, 10) + fastRandom.GetRandomInteger(5, 10)) / 20.0f; // 0.5f - 1.0f, weight on 0.75
					newCreature->data.renderRadius = 0.05f;
					// this will trigger finding a new portal upon AI animation
					newCreature->data.targetPosition = newCreature->data.orient.p;
					// don't need joint orients
					/*
					if (newCreature->data.jointOrients != nullptr)
					{
						if (newCreature->data.jointOrientQty < dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetTotalJointOrientQty())
						{
							delete[] newCreature->data.jointOrients;
							newCreature->data.jointOrients = new Orient3d[dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetTotalJointOrientQty()];
						}
					}
					else
					{
						newCreature->data.jointOrients = new Orient3d[dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetTotalJointOrientQty()];
					}
					newCreature->data.jointedModelAnimationTracker.SetAnimation(dungeonModelRegistry[RandomDungeonObjectTypeEnum::Triguy].jointedModel->GetAnimation(1)); // walking
					*/

					// need a light though!
					Orient3d arbiterLightOrient = RandomDungeonArbiterLightData::RandomSpotlightOrient();
					arbiterLightOrient.p = newCreature->data.orient.p;
					newCreature->data.lightRef = &(MakeNewLight()->data);
					float brightness = 2.0f;
					Vector3d color = RandomDungeonLight::RandomColor(brightness);
					Vector3d modelColor = color.ScalarMult(1.0f / brightness);
					newCreature->data.lightRef->SetSpotlight(arbiterLightOrient.p, arbiterLightOrient.f, 30.0f, color, 0.25f, 0.125f);
					newCreature->data.lightRef->arbiterLightDataRef = &(newCreature->data.arbiterLightData);
					// match arbiter color to light color (a little dimmer)
					newCreature->data.useSingleColor = true;
					newCreature->data.singleColor.Set(
						unsigned char(modelColor.x * 192.0f),
						unsigned char(modelColor.y * 192.0f),
						unsigned char(modelColor.z * 192.0f)
						);

					// initiate interpolation
					newCreature->data.newSpotlightMS = 2000.0f;
					newCreature->data.arbiterLightData.SetNewOrientationInterpolation(arbiterLightOrient, arbiterLightOrient, 0.0f);

					creatures->AddNode(newCreature);

					// maintain node lists
					MaintainCreatureNodeList(newCreature->data);
				}

			} // each room

			dressingsPlaced = true; // just a tag to say we are done with a phase of the generation

			// maintain dressing node lists (includes light sconces)
			if (placeDressings == true)
			{
				LinkedListEnumerator<RandomDungeonDressing> dressingEnumerator = LinkedListEnumerator<RandomDungeonDressing>(*dressings);
				while (dressingEnumerator.MoveNext())
				{
					LinkedListNode<RandomDungeonDressing> *newDressing = dressingEnumerator.Current(); // code was noved down from above, done this way for simplicity

					// maintain node lists
					// todo: actually this should be a unit vector along 1,1,1 and -1,-1,-1 scalrmultiplied by renderRadius for more accuracy, but this isn't destructive
					Vector3d minPosition = newDressing->data.orient.p - Vector3d(newDressing->data.renderRadius, newDressing->data.renderRadius, newDressing->data.renderRadius);
					Vector3d maxPosition = newDressing->data.orient.p + Vector3d(newDressing->data.renderRadius, newDressing->data.renderRadius, newDressing->data.renderRadius);
					int xMinIndex, yMinIndex, zMinIndex;
					int xMaxIndex, yMaxIndex, zMaxIndex;
					portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
					portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
					for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
					{
						for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
						{
							for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
							{
								LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
								while (nodeIndexEnumerator.MoveNext())
								{
									// quick way to exclude
									if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
										continue;
									if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
										continue;
									if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
										continue;
									if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
										continue;
									if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
										continue;
									if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
										continue;

									// track node overlapped, don't store duplicate (although it isn't destructive, so might be faster to do so)
									LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(newDressing->data.nodesOverlapped);
									bool found = false;
									while (nodeEnumerator.MoveNext())
									{
										if (nodeEnumerator.Current()->data.index == nodeIndexEnumerator.Current()->data.index)
										{
											found = true;
											break;
										}
									}
									if (found == false)
									{
										newDressing->data.nodesOverlapped.Add(PortalNodeIndex(nodeIndexEnumerator.Current()->data.index));

										nodeObjectLists[nodeIndexEnumerator.Current()->data.index].dressings.Add(&(newDressing->data));
									}
								}
							} // zIndex
						} // yIndex
					} // zIndex
				} // place all objects within their nodes
			} // place dressings
		} // done placing dressings and creatures
	} // done making dungeon

	// dungeon exploration
	// handle controls
	Vector3d playerMoveVector = Vector3d(0, 0, 0);
	float walkSpeed = 0.00586f / 10.0f * 2.0f;  // brisk 4 miles per hour, double (8mph hustle)
	float runSpeed = 0.022f / 10.0f; // 15 miles per hour
	float moveSpeed = walkSpeed;
	if (mouse.IsVisible() == false)
	{
		if (joystickControl == false)
		{
			float mouseSensitivity = 0.25f;
			rotateAngleDegrees += (float(mouse.offsetX) * mouseSensitivity);
			while (rotateAngleDegrees >= 360.0f)
				rotateAngleDegrees -= 360.0f;
			while (rotateAngleDegrees < 0.0f)
				rotateAngleDegrees += 360.0f;
			pitchAngleDegrees -= (float(mouse.offsetY) * mouseSensitivity);
			if (pitchAngleDegrees > 90.0f)
				pitchAngleDegrees = 90.0f;
			if (pitchAngleDegrees < -90.0f)
				pitchAngleDegrees = -90.0f;
		}
		else
		{
			if (joystick->values.valid == true)
			{
				int dead = 150;
				float max = 1000.0f;
				float joystickSensitivity = 180.0f / 1000.0f;   // at max, rotate full in 2 seconds

				// roll
				if (abs(joystick->values.primaryX) >= dead)
				{
					float factor = (float(abs(joystick->values.primaryX) - dead)) / (max - float(dead));
					factor = factor * factor * factor;
					if (joystick->values.primaryX > 0)
						joystickRollAngleDegreesPerMS = -joystickSensitivity * factor;
					else
						joystickRollAngleDegreesPerMS = joystickSensitivity * factor;
				}
				else
					joystickRollAngleDegreesPerMS = 0;

				// pitch
				if (abs(joystick->values.primaryY) >= dead)
				{
					float factor = (float(abs(joystick->values.primaryY) - dead)) / (max - float(dead));
					factor = factor * factor * factor;
					if (joystick->values.primaryY > 0)
						joystickPitchAngleDegreesPerMS = joystickSensitivity * factor;
					else
						joystickPitchAngleDegreesPerMS = -joystickSensitivity * factor;
				}
				else
					joystickPitchAngleDegreesPerMS = 0;

				// yaw
				if (abs(joystick->values.twist) >= dead)
				{
					float factor = (float(abs(joystick->values.twist) - dead)) / (max - float(dead));
					factor = factor * factor * factor;
					if (joystick->values.twist > 0)
						joystickYawAngleDegreesPerMS = joystickSensitivity * factor;
					else
						joystickYawAngleDegreesPerMS = -joystickSensitivity * factor;
				}
				else
					joystickYawAngleDegreesPerMS = 0;

				fireBullets = joystick->values.button1Down;
			}
		}

		if (useExceptionTest == false)
		{
			if (joystickControl == false)
			{
				// apply mouse controls
				// create new orientation for player
				Vector3d oldP = playerOrient->p;
				playerOrient->LoadIdentity();
				playerOrient->Rotate(playerOrient->u, rotateAngleDegrees);
				playerOrient->Rotate(playerOrient->l, pitchAngleDegrees);
				playerOrient->p = oldP;
			}
		}

		Vector3d horizontalForward = playerOrient->f;
		Vector3d sideways = playerOrient->l;
		if (joystickControl == false)
			horizontalForward.y = 0.0f;
		if (horizontalForward.Normalize() == false)
		{
			// use u for forward
			horizontalForward = playerOrient->u.ScalarMult(1.0f);
			horizontalForward.Normalize();
		}
		sideways.Normalize(); // should always be good
		bool playerFeetOnGround = true; // for now
		if (keyboardKeys.GetKey(17)->IsPressed() == false && useExceptionTest == false) // not if ctrl is pressed
		{
			if (playerFeetOnGround == true)
			{
				float moveBuildup = 250.0f;
				bool slide = false;
				if (keyboardKeys.GetKey('A')->IsPressed() == true)
				{
					slide = true;
					joystickSlideFactor += timer->GetElapsedTimeMSFloat() / moveBuildup;
					if (joystickSlideFactor > 1.0f)
						joystickSlideFactor = 1.0f;
					if (joystickControl == false)
						joystickSlideFactor = 1.0f;
				}
				if (keyboardKeys.GetKey('D')->IsPressed() == true)
				{
					slide = true;
					joystickSlideFactor -= timer->GetElapsedTimeMSFloat() / moveBuildup;
					if (joystickSlideFactor < -1.0f)
						joystickSlideFactor = -1.0f;
					if (joystickControl == false)
						joystickSlideFactor = -1.0f;
				}
				if (slide == false)
				{
					if (joystickControl == true)
					{
						if (joystickSlideFactor > 0.0f)
						{
							joystickSlideFactor -= timer->GetElapsedTimeMSFloat() / moveBuildup;
							if (joystickSlideFactor < 0.0f)
								joystickSlideFactor = 0.0f;
						}
						else
						{
							joystickSlideFactor += timer->GetElapsedTimeMSFloat() / moveBuildup;
							if (joystickSlideFactor > 0.0f)
								joystickSlideFactor = 0.0f;
						}
					}
					else
						joystickSlideFactor = 0.0f;
				}
				playerMoveVector = playerMoveVector + sideways.ScalarMult(joystickSlideFactor);

				// moving
				bool move = false;
				if (keyboardKeys.GetKey('W')->IsPressed() == true)
				{
					move = true;
					joystickMoveFactor += timer->GetElapsedTimeMSFloat() / moveBuildup;
					if (joystickMoveFactor > 1.0f)
						joystickMoveFactor = 1.0f;
					if (joystickControl == false)
						joystickMoveFactor = 1.0f;
				}
				if (keyboardKeys.GetKey('S')->IsPressed() == true)
				{
					move = true;
					joystickMoveFactor -= timer->GetElapsedTimeMSFloat() / moveBuildup;
					if (joystickMoveFactor < -1.0f)
						joystickMoveFactor = -1.0f;
					if (joystickControl == false)
						joystickMoveFactor = -1.0f;
				}
				if (move == false)
				{
					if (joystickControl == true)
					{
						if (joystickMoveFactor > 0.0f)
						{
							joystickMoveFactor -= timer->GetElapsedTimeMSFloat() / moveBuildup;
							if (joystickMoveFactor < 0.0f)
								joystickMoveFactor = 0.0f;
						}
						else
						{
							joystickMoveFactor += timer->GetElapsedTimeMSFloat() / moveBuildup;
							if (joystickMoveFactor > 0.0f)
								joystickMoveFactor = 0.0f;
						}
					}
					else
						joystickMoveFactor = 0.0f;
				}
				playerMoveVector = playerMoveVector + horizontalForward.ScalarMult(joystickMoveFactor);
			}
		}
		if (joystickControl == false)
			playerMoveVector.Normalize(); // prevent diagonal speedup
		if (keyboardKeys.GetKey(16)->IsClicked() == true) // run
		{
			playerRun = !playerRun;
		}
		if (playerRun == true)
			moveSpeed = runSpeed;

		// handle throwing balls
		if (mouse.leftButton.down == false)
		{
			if (playerBallLaunchPower > 0.0f)
			{
				// launch a ball
				int maxPlayerBalls = 200; // for now, can change to 8 or whatever for testing
				RandomDungeonBall *playerBall = nullptr;
				// find currentPlayerBallId - if not found, make it
				LinkedListEnumerator<RandomDungeonBall> ballEnumerator = LinkedListEnumerator<RandomDungeonBall>(*balls);
				while (ballEnumerator.MoveNext())
				{
					if (ballEnumerator.Current()->data.playerControlBallId == currentPlayerControlBallId)
					{
						playerBall = &(ballEnumerator.Current()->data);
						break;
					}
				}
				FastRandom fastRandom;
				if (playerBall == nullptr)
				{
					// if not found, make it
					playerBall = &(MakeDungeonBallNode()->data);
					// make a light for the ball
					if (fastRandom.GetRandomInteger(1, 1) == 1) // always for now
						playerBall->lightRef = &(MakeNewLight()->data); // position will get set in Animate, which always runs after controls are handled
					playerBall->playerControlBallId = currentPlayerControlBallId;
				}
				// set the position and launch speed
				playerBall->orient.p = playerOrient->p + playerOrient->f.ScalarMult(playerBall->radius + 0.2f);
				playerBall->velocity = playerOrient->f.ScalarMult(playerBallLaunchPower);
				if (playerBall->lightRef != nullptr)
				{
					switch (fastRandom.GetRandomInteger(0, 0)) // 0-2 is too much when there are a lot of object types being rendered; 0-4 is too much with jsut a few object types, permutations got out of control and ate up a lot of memory
					{
					case 0:
						playerBall->lightRef->SetPoint(playerBall->orient.p, RandomDungeonLight::RandomColor(1.0f), 0.25f, 0.125f); // position will be updated again in Animate
						break;
					case 1:
						playerBall->lightRef->SetSpotlight(playerBall->orient.p, playerBall->orient.f, 40.0f, RandomDungeonLight::RandomColor(1.0f), 0.25f, 0.125f); // position will be updated again in Animate
						break;
					case 2:
						playerBall->lightRef->SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Flashlight"), playerBall->orient.p, playerBall->orient.f, playerBall->orient.l, playerBall->orient.u, 40.0f, RandomDungeonLight::RandomColor(1.0f), 0.25f, 0.125f); // position will be updated again in Animate
						break;
					case 3:
						playerBall->lightRef->SetSpotlight(playerBall->orient.p, playerBall->orient.f, 70.0f, RandomDungeonLight::RandomColor(1.0f), 0.25f, 0.125f); // position will be updated again in Animate
						break;
					case 4:
						playerBall->lightRef->SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Flashlight"), playerBall->orient.p, playerBall->orient.f, playerBall->orient.l, playerBall->orient.u, 70.0f, RandomDungeonLight::RandomColor(1.0f), 0.25f, 0.125f); // position will be updated again in Animate
						break;
					}
				}
				// preserve energy!
				// (note: if ever realistic physics is enabled and turned off again, all potential energies will need to be reset)
				//playerBall->SetPotentialEnergy(gravityPerMSMS, -100.0f);

				// prepare for next ball to launch
				currentPlayerControlBallId++;
				if (currentPlayerControlBallId >= maxPlayerBalls)
					currentPlayerControlBallId = 0;
			}

			// button not pressed or no longer pressed
			playerBallLaunchPower = 0.0f; // reset
		}
		else
		{
			// increase power!
			playerBallLaunchPower += playerBallLaunchPowerIncreasePerMSf * timer->GetElapsedTimeMSFloat();
			if (playerBallLaunchPower > playerBallMaxLaunchPower)
				playerBallLaunchPower = playerBallMaxLaunchPower;
		}
	}
	// no ctrl
	if (keyboardKeys.GetKey(17)->IsPressed() == false)
	{
		if (keyboardKeys.GetKey(186)->IsClicked() == true) // semicolon
		{
			if (mouse.IsVisible() == false)
				mouse.Show();
			else
				mouse.Hide();
		}
		if (keyboardKeys.GetKey('F')->IsClicked() == true)
		{
			fullFrustum = !fullFrustum;
		}
		if (keyboardKeys.GetKey('P')->IsClicked() == true)
		{
			usePartition = !usePartition;
		}
		if (keyboardKeys.GetKey('I')->IsClicked() == true)
		{
			showInformation = !showInformation;
		}
		if (keyboardKeys.GetKey('Z')->IsClicked() == true)
		{
			showInstructions = !showInstructions;
		}
		if (keyboardKeys.GetKey('N')->IsClicked() == true)
		{
			useLighting = !useLighting;
		}
		if (keyboardKeys.GetKey('M')->IsClicked() == true)
		{
			useShadowMaps = !useShadowMaps;
		}
		if (keyboardKeys.GetKey('B')->IsClicked() == true)
		{
			useBackSideOfNodesForShadows = !useBackSideOfNodesForShadows;
		}
		if (keyboardKeys.GetKey('L')->IsClicked() == true)
		{
			playerLightAttached = !playerLightAttached;
		}
		if (keyboardKeys.GetKey('X')->IsClicked() == true)
		{
			useWireframe = !useWireframe;
		}
		if (keyboardKeys.GetKey('Q')->IsClicked() == true)
		{
			showExploredMap = !showExploredMap;
		}
		if (keyboardKeys.GetKey('E')->IsClicked() == true)
		{
			freezeBalls = !freezeBalls;
		}
		if (keyboardKeys.GetKey('0')->IsClicked() == true)
		{
			maxLightQty = 0;
		}
		if (keyboardKeys.GetKey('1')->IsClicked() == true)
		{
			maxLightQty = 1;
		}
		if (keyboardKeys.GetKey('2')->IsClicked() == true)
		{
			maxLightQty = 2;
		}
		if (keyboardKeys.GetKey('3')->IsClicked() == true)
		{
			maxLightQty = 3;
		}
		if (keyboardKeys.GetKey('4')->IsClicked() == true)
		{
			maxLightQty = 4;
		}
		if (keyboardKeys.GetKey('5')->IsClicked() == true)
		{
			maxLightQty = 5;
		}
		if (keyboardKeys.GetKey('6')->IsClicked() == true)
		{
			maxLightQty = 6;
		}
		if (keyboardKeys.GetKey('7')->IsClicked() == true)
		{
			maxLightQty = 7;
		}
		if (keyboardKeys.GetKey('8')->IsClicked() == true)
		{
			maxLightQty = 8;
		}
		if (keyboardKeys.GetKey(192)->IsClicked() == true) // ~
		{
			if (slowMotionFactor == 1.0f)
				slowMotionFactor = 0.1f;
			else if (slowMotionFactor == 0.1f)
				slowMotionFactor = 0.05f;
			else
				slowMotionFactor = 1.0f;
		}
		if (keyboardKeys.GetKey(13)->IsClicked() == true)
		{
			stereoScopicMode++;
			if (stereoScopicMode > 2)
				stereoScopicMode = 0;

			switch (stereoScopicMode)
			{
			case 0:
			case 1:
				fov = 45.0f;
				break;
			case 2:
				fov = 77.8f;
				splitScreenEyeSeparationInches = 2.75f; // reset
				break;
			}
		}
		if (keyboardKeys.GetKey('H')->IsClicked() == true) // sarah!
		{
			// place sarah in front of the player, facing him, hovering a little, shimmering away and shaking
			//sarahOrient->Set(*playerOrient);
			//sarahOrient->p = sarahOrient->p + playerOrient->f.ScalarMult(2.5f);
			//sarahOrient->p = sarahOrient->p + sarahOrient->u.ScalarMult(0.0f);
			//sarahOrient->Rotate(sarahOrient->u, 180.0f);
			//sarahTimerMSf = 2000.0f; // set top alphas to 0.0-0.5

			//// move triguy off
			//triguyOrient->p = Vector3d(0, 0, 0);

			//// place a red eyes triguy behind the player
			//triguyRedEyesOrient->Set(*playerOrient);
			//triguyRedEyesOrient->p = playerOrient->p - playerOrient->f.ScalarMult(1.0f);
			//triguyRedEyesOrient->p.y = 0.28f; // whatever correct height is
			//// make him stand there
			//triguyAnimationTracker->SetAnimation(triguy->GetDefaultAnimation());

			// alter sconces
			switch (sconceMode)
			{
			case 0:
				{
					LinkedListEnumerator<RandomDungeonLight> lightEnumerator = LinkedListEnumerator<RandomDungeonLight>(*mapLights);
					while (lightEnumerator.MoveNext())
					{
						if (lightEnumerator.Current()->data.flicker == true)
							lightEnumerator.Current()->data.SelectFlameColor(6, true, 500.0f, gameTimeMSf);
					}
					sconceMode = 1;
					ambientColorStart->Set(*ambientColor);
					ambientColorEnd->Set(GameColor(82, 6, 6).ToVector3d().ScalarMult(1.0f));
					ambientColorBase->Set(*ambientColorEnd);
					ambientInterpolationMS = 500.0f;
					totalAmbientInterpolationMS = 500.0f;

					fovBegin = fov;
					fovEnd = 120.0f;
					fovInterpolationMS = 2000.0f;
					totalFovInterpolationMS = fovInterpolationMS;
				}
				break;
			case 1:
				{
					LinkedListEnumerator<RandomDungeonLight> lightEnumerator = LinkedListEnumerator<RandomDungeonLight>(*mapLights);
					while (lightEnumerator.MoveNext())
					{
						if (lightEnumerator.Current()->data.flicker == true)
							lightEnumerator.Current()->data.SelectFlameColor(7, true, 500.0f, gameTimeMSf);
					}
					sconceMode = 2;
					ambientColorStart->Set(*ambientColor);
					ambientColorEnd->Set(GameColor(102, 82, 40).ToVector3d().ScalarMult(1.0f));
					ambientColorBase->Set(*ambientColorEnd);
					ambientInterpolationMS = 500.0f;
					totalAmbientInterpolationMS = 500.0f;

					fovBegin = fov;
					fovEnd = 45.0f;
					float expectedDifference = 120.0f - 45.0f;
					fovInterpolationMS = (fov - 45.0f) / expectedDifference * 1000.0f; // based on interpolating from 80 to 45
					totalFovInterpolationMS = fovInterpolationMS;
				}
				break;
			case 2:
				{
					LinkedListEnumerator<RandomDungeonLight> lightEnumerator = LinkedListEnumerator<RandomDungeonLight>(*mapLights);
					while (lightEnumerator.MoveNext())
					{
						if (lightEnumerator.Current()->data.flicker == true)
							lightEnumerator.Current()->data.RestoreOriginalIllumination(1000.0f, gameTimeMSf);
					}
					sconceMode = 0;
					ambientColorStart->Set(*ambientColor);
					ambientColorEnd->Set(0,0,0);
					ambientColorBase->Set(*ambientColorEnd);
					ambientInterpolationMS = 1000.0f;
					totalAmbientInterpolationMS = 1000.0f;
			}
				break;
			}
		}
		if (keyboardKeys.GetKey('J')->IsClicked() == true)
		{
			// lower lights and trigger red eyes in-face waggle and go black for a few seconds
			jumpScareTimerMSf = 9125.0f; // start it up!
		}
		//newLight->data.SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Flashlight"), playerOrient->p, playerOrient->f, playerOrient->l, playerOrient->u, 65.0f, Vector3d(1, 1, 1), 0.25, 0.125); // light torch
		//newLight->data.SetSpotlight(playerOrient->p, playerOrient->f, 65.0f, Vector3d(1, 1, 1), 0.25, 0.125); // light torch
		if (keyboardKeys.GetKey('G')->IsClicked() == true)
		{
			if (playerLightRef != nullptr)
			{
				// cycle player light type for testing
				playerLightType++;
				if (playerLightType >= 5)
					playerLightType = 0;
				switch (playerLightType)
				{
				case 0:
					playerLightRef->SetPoint(playerLightRef->worldPosition, Vector3d(1, 1, 1), 0.25, 0.125);
					break;
				case 1:
					playerLightRef->SetSpotlight(playerLightRef->worldPosition, playerOrient->f, 25.0f, Vector3d(1, 1, 1), 0.25, 0.125); // narrow spotlight
					break;
				case 2:
					playerLightRef->SetSpotlight(playerLightRef->worldPosition, playerOrient->f, 65.0f, Vector3d(1, 1, 1), 0.25, 0.125); // wide spotlight
					break;
				case 3:
				{
					playerLightRef->SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Flashlight"), playerLightRef->worldPosition, playerOrient->f, playerOrient->l, playerOrient->u, 25.0f, Vector3d(1, 1, 1), 0.25, 0.125); // narrow flashlight
				}
				break;
				case 4:
				{
					playerLightRef->SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Flashlight"), playerLightRef->worldPosition, playerOrient->f, playerOrient->l, playerOrient->u, 65.0f, Vector3d(1, 1, 1), 0.25, 0.125); // wide flashlight
				}
				break;
				}
			}
		}
		if (keyboardKeys.GetKey('V')->IsClicked()) // portal depth
		{
			if (portalDepth == -1)
				portalDepth = 1;
			else
			{
				portalDepth++;
				if (portalDepth > 6)
					portalDepth = -1;
			}
		}
		if (keyboardKeys.GetKey('C')->IsClicked())
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->SetVSyncEnabled(!graphics->VSyncIsEnabled());
		}
		if (keyboardKeys.GetKey('U')->IsClicked())
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			shaderAppSettings->escalateLightAspectCheck = !(shaderAppSettings->escalateLightAspectCheck);
			graphics->SetShaderAppSettings(*shaderAppSettings);
		}
		if (keyboardKeys.GetKey('K')->IsClicked())
		{
			renderShadowNodes = !renderShadowNodes;
		}
		if (keyboardKeys.GetKey('Y')->IsClicked())
		{
			checkLightNodeBounds = !checkLightNodeBounds;
		}
		if (keyboardKeys.GetKey('T')->IsClicked()) // not if ctrl is pressed
		{
			checkLightNodeBoundsHeavy = !checkLightNodeBoundsHeavy;
		}
		if (keyboardKeys.GetKey(188)->IsClicked()) // ,
		{
			mirrorOrientAdjustment -= 0.00001f;
		}
		if (keyboardKeys.GetKey(190)->IsClicked()) // .
		{
			mirrorOrientAdjustment += 0.00001f;
		}
	}
	// ctrl
	if (keyboardKeys.GetKey(17)->IsPressed() == true) // ctrl
	{
		if (keyboardKeys.GetKey('D')->IsClicked()) // ctrl-D darkvision
		{
			useDarkvision = !useDarkvision;
		}
		if (keyboardKeys.GetKey('G')->IsClicked()) // ctrl-G grayscale
		{
			// cycle through values 0.0, 0.25, 0.5, 0.75, 1.0
			if (grayScale < 0.25f)
				grayScale = 0.25f;
			else if (grayScale < 0.5f)
				grayScale = 0.5f;
			else if (grayScale < 0.75f)
				grayScale = 0.75f;
			else if (grayScale < 1.0f)
				grayScale = 1.0f;
			else
				grayScale = 0.0f;
		}
		if (keyboardKeys.GetKey('B')->IsClicked()) // ctrl-B gamma
		{
			/*
			// cycle through values 1.0f, 2.0, 2.1, 2.2, 2.3, 2.4
			// NO! Too much!!!
			if (gamma == 1.0f)
				gamma = 2.0f;
			else if (gamma == 2.0f)
				gamma = 2.1f;
			else if (gamma == 2.1f)
				gamma = 2.2f;
			else if (gamma == 2.2f)
				gamma = 2.3f;
			else if (gamma == 2.3f)
				gamma = 2.4f;
			else
				gamma = 1.0f;
				*/
			// cycle through values 1.0f-1.9f
			if (gamma == 1.0f)
				gamma = 1.1f;
			else if (gamma == 1.1f)
				gamma = 1.2f;
			else if (gamma == 1.2f)
				gamma = 1.3f;
			else if (gamma == 1.3f)
				gamma = 1.4f;
			else if (gamma == 1.4f)
				gamma = 1.5f;
			else if (gamma == 1.5f)
				gamma = 1.6f;
			else if (gamma == 1.6f)
				gamma = 1.7f;
			else if (gamma == 1.7f)
				gamma = 1.8f;
			else if (gamma == 1.8f)
				gamma = 1.9f;
			else
				gamma = 1.0f;
		}
		if (keyboardKeys.GetKey('H')->IsClicked()) // ctrl-H render hidden creatures
		{
			renderHiddenCreatures = !renderHiddenCreatures;
		}
		if (keyboardKeys.GetKey('C')->IsClicked()) // ctrl-C toggle clip planes
		{
			useClipPlanes = !useClipPlanes;
		}
		if (keyboardKeys.GetKey('S')->IsClicked()) // ctrl-S toggle single clip plane (requires useClipPlanes == true)
		{
			useSingleClipPlane = !useSingleClipPlane;
		}
		if (keyboardKeys.GetKey('M')->IsClicked()) // ctrl-M toggle pre-rendering mirrors with depth to assist with depth culling while rendering world n-1 behind mirror n
		{
			renderMirrorsWithNodesForDepthCulling = !renderMirrorsWithNodesForDepthCulling;
		}
		if (keyboardKeys.GetKey('U')->IsClicked()) // ctrl-U allow updating of shadowmaps during additional passes of parsing light sources (anaglyph, mirrors)
		{
			//allowShadowMapUpdating = !allowShadowMapUpdating;
		}
		if (keyboardKeys.GetKey('V')->IsClicked()) // ctrl-V mirror depth
		{
			maxMirrorDepth++;
			if (maxMirrorDepth > 5)
				maxMirrorDepth = 0;
		}
		if (keyboardKeys.GetKey('T')->IsClicked()) // ctrl-T exception testing!
		{
			useExceptionTest = !useExceptionTest;
			if (useExceptionTest == true)
			{
				exceptionTestNodeTimerMS = 2000; // 2 seconds per room
				exceptionTestRoomSpinDegreesPerMS = 480.0f / float(exceptionTestNodeTimerMS); // spin 1.3 times per room
			}
		}
		if (keyboardKeys.GetKey('A')->IsClicked()) // ctrl-A toggle alpha on mirrors for depth clarity
		{
			useZeroMirrorAlpha = !useZeroMirrorAlpha;
		}
		if (keyboardKeys.GetKey(188)->IsClicked()) // ctrl-,
		{
			mirrorClipPlaneNormalAdjustment -= 0.00001f;
		}
		if (keyboardKeys.GetKey(190)->IsClicked()) // ctrl-.
		{
			mirrorClipPlaneNormalAdjustment += 0.00001f;
		}
		if (keyboardKeys.GetKey('F')->IsClicked()) // ctrl-F fade to color
		{
			fade += 0.1f;
			if (fade > 1.001f)
				fade = 0.0f;
		}
		if (keyboardKeys.GetKey('R')->IsClicked()) // ctrl-R to toggle render switches
		{
			if (allowShadowMapRender == true && allowScreenRender == true)
			{
				allowShadowMapRender = false;
				allowScreenRender = true;
			}
			else if (allowShadowMapRender == false && allowScreenRender == true)
			{
				allowShadowMapRender = true;
				allowScreenRender = false;
			}
			else if (allowShadowMapRender == true && allowScreenRender == false)
			{
				allowShadowMapRender = false;
				allowScreenRender = false;
			}
			else
			{
				allowShadowMapRender = true;
				allowScreenRender = true;
			}
		}
		if (keyboardKeys.GetKey('O')->IsClicked()) // ctrl-O to toggle obejct render switches
		{
			if (allowObjectsInShadowMaps == true && allowObjectsInRender == true)
			{
				allowObjectsInShadowMaps = false;
				allowObjectsInRender = true;
			}
			else if (allowObjectsInShadowMaps == false && allowObjectsInRender == true)
			{
				allowObjectsInShadowMaps = true;
				allowObjectsInRender = false;
			}
			else if (allowObjectsInShadowMaps == true && allowObjectsInRender == false)
			{
				allowObjectsInShadowMaps = false;
				allowObjectsInRender = false;
			}
			else
			{
				allowObjectsInShadowMaps = true;
				allowObjectsInRender = true;
			}
		}
		if (keyboardKeys.GetKey('L')->IsClicked()) // ctrl-L mirror lighting depth
		{
			minimumMirrorLightingDepth++;
			if (minimumMirrorLightingDepth > 6)
				minimumMirrorLightingDepth = 0;
		}
		// ctrl 1-0 for disabling renderinv sections to track down framerate drops
		if (keyboardKeys.GetKey('0')->IsClicked())
		{
			maximumRenderSectionAllowed = 100; // allow all of them
		}
		if (keyboardKeys.GetKey('1')->IsClicked())
		{
			maximumRenderSectionAllowed = 1;
		}
		if (keyboardKeys.GetKey('2')->IsClicked())
		{
			maximumRenderSectionAllowed = 2;
		}
		if (keyboardKeys.GetKey('3')->IsClicked())
		{
			maximumRenderSectionAllowed = 3;
		}
		if (keyboardKeys.GetKey('4')->IsClicked())
		{
			maximumRenderSectionAllowed = 4;
		}
		if (keyboardKeys.GetKey('5')->IsClicked())
		{
			maximumRenderSectionAllowed = 5;
		}
		if (keyboardKeys.GetKey('6')->IsClicked())
		{
			maximumRenderSectionAllowed = 6;
		}
		if (keyboardKeys.GetKey('7')->IsClicked())
		{
			maximumRenderSectionAllowed = 7;
		}
		if (keyboardKeys.GetKey('8')->IsClicked())
		{
			maximumRenderSectionAllowed = 8;
		}
		if (keyboardKeys.GetKey('9')->IsClicked())
		{
			maximumRenderSectionAllowed = 9;
		}
		if (keyboardKeys.GetKey('P')->IsClicked() == true) // ctrl-P
		{
			allowParticles = !allowParticles;
		}
		if (keyboardKeys.GetKey('N')->IsClicked() == true) // ctrl-N
		{
			// only for testing.  not destructive, but it will render more nodes than it should as increases accumulate, but can test for getting rid of more artifacting seen later
			portalMap->EnlargePortals(0.01f);
		}
		if (keyboardKeys.GetKey('K')->IsClicked() == true) // ctrl-K
		{
			fastPortalParse = !fastPortalParse;
		}
		if (keyboardKeys.GetKey('Z')->IsClicked() == true) // ctrl-Z
		{
			// toggle blur and focus by depth
			if (blurRadius == 0.0f && focusByDepthRadius == 0.0f)
			{
				blurRadius = 1.0f;
				focusByDepthRadius = 0.0f;
			}
			else if (focusByDepthRadius == 0.0f)
			{
				// light depth of field
				blurRadius = 0.0f;
				focusByDepthRadius = 1.0f; // light blur
				focusByDepthWorldZMin = 2.0f; // start blur at 20 feet
				focusByDepthWorldZMax = 4.0f; // maximize it at 40 feet
			}
			else if (focusByDepthRadius == 1.0f)
			{
				// intense depth of field
				blurRadius = 0.0f;
				focusByDepthRadius = 2.0f; // deep blur
				focusByDepthWorldZMin = 0.25f; // start blur at 2.5 feet
				focusByDepthWorldZMax = 0.5f; // maximize it at 5 feet
			}
			else
			{
				blurRadius = 0.0f;
				focusByDepthRadius = 0.0f;
			}
		}
		if (keyboardKeys.GetKey('X')->IsClicked() == true) // ctrl-X
		{
			if (lens == 1.0f)
				lens = 1.7f;
			else if (lens == 1.7f)
				lens = 0.6f;
			else
				lens = 1.0f;
		}
		if (keyboardKeys.GetKey('J')->IsClicked() == true) // ctrl-J
		{
			joystickControl = !joystickControl;
			if (joystickControl == false)
				playerOrient->p.y = 0.6f;
			else
			{
				joystickSlideFactor = 0.0f;
				joystickMoveFactor = 0.0f;
			}
		}
		if (keyboardKeys.GetKey('E')->IsClicked() == true) // ctrl-E
		{
			if (splitScreenEyeSeparationInches == 2.75f)
				splitScreenEyeSeparationInches = 0.275f;
			else
				splitScreenEyeSeparationInches = 2.75f;
		}
	}

	keyboardKeys.ClearClicked();
	if (mouse.IsVisible() == false && appActivated == true)
	{
		// move it to the middle of the viewport (should be screen position)
		GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
		mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
	}
	mouse.ZeroOffsets();

	colliderSetsExecuted = 0;

	// animate player
	float timeElapsedMSf = timer->GetElapsedTimeMSFloat();
	while (timeElapsedMSf > 0.0f)
	{
		if (timeElapsedMSf > 16.0f)
		{
			AnimatePlayer(16.0f, playerMoveVector, moveSpeed);
			timeElapsedMSf -= 16.0f;
		}
		else
		{
			AnimatePlayer(timeElapsedMSf, playerMoveVector, moveSpeed);
			timeElapsedMSf = 0;
		}
	}

	// animate everything else
	timeElapsedMSf = timer->GetElapsedTimeMSFloat();
	timeElapsedMSf *= slowMotionFactor;
	if (freezeBalls == true)
		timeElapsedMSf = 0.0f;
	if (timeElapsedMSf > 0.0f)
	{
		InterpolateAmbientColor(timeElapsedMSf);
		InterpolateFov(timeElapsedMSf);
	}
	while (timeElapsedMSf > 0.0f)
	{
		if (timeElapsedMSf > 16.0f)
		{
			Animate(16.0f);
			timeElapsedMSf -= 16.0f;
		}
		else
		{
			Animate(timeElapsedMSf);
			timeElapsedMSf = 0;
		}
	}

	// todo: shouldn't need to maintain lists if nothing moved (elapsedTimeMS == 0)
	// todo: maintain balls and lights as they move? (since objects make decisions according to the node they are in, maybe they shoudl be maintained inside animate with the others?)
	MaintainBallAndLightNodeLists();

	// do this at end of render instead - we need it for animating some objects during render
	//timer->ResetElapsedTime();

	return true;
}

void TestRandomDungeon::InterpolateAmbientColor(float p_elapsedTimeMSf)
{
	if (ambientInterpolationMS > 0.0f)
	{
		if (ambientInterpolationMS <= p_elapsedTimeMSf)
		{
			ambientColor->Set(*ambientColorEnd);

			if (ambientColorBase->Equals(Vector3d::ZeroVector()) == false)
			{
				// flicker it slowly!
				static FastRandom fastRandom;
				ambientInterpolationMS = float(fastRandom.GetRandomInteger(500, 1000));
				totalAmbientInterpolationMS = ambientInterpolationMS;
				ambientColorStart->Set(*ambientColorEnd);
				ambientColorEnd->Set(ambientColorBase->ScalarMult(float(fastRandom.GetRandomInteger(50, 100)) / 100.0f));
			}
			else
				ambientInterpolationMS = 0.0f; // no more interpolation of ambient color for base zero
		}
		else
		{
			ambientInterpolationMS -= p_elapsedTimeMSf;
			ambientColor->Set(Vector3d::Interpolate(*ambientColorStart, *ambientColorEnd, (totalAmbientInterpolationMS - ambientInterpolationMS) / totalAmbientInterpolationMS));
		}
	}
}

void TestRandomDungeon::InterpolateFov(float p_elapsedTimeMSf)
{
	if (fovInterpolationMS > 0.0f)
	{
		if (fovInterpolationMS <= p_elapsedTimeMSf)
		{
			fov = fovEnd;
			fovInterpolationMS = 0.0f;
			if (sconceMode == 1)
			{
				playerLightRef->brightness = 0.0f;
				focusByDepthRadius = 2.0f;
				focusByDepthWorldZMin = 0.25f;
				focusByDepthWorldZMax = 0.5f;
				lens = 1.3f;
			}
			else
			{
				playerLightRef->brightness = 1.0f;
				focusByDepthRadius = 0.0f;
				lens = 1.0f;
			}
		}
		else
		{
			fovInterpolationMS -= p_elapsedTimeMSf;
			// accelerates from 0.0, decelerates to 1.0
			float factor = (totalFovInterpolationMS - fovInterpolationMS) / totalFovInterpolationMS;
			if (sconceMode == 1)
			{
				playerLightRef->brightness = 1.0f - factor;
				focusByDepthRadius = 2.0f * factor;
				focusByDepthWorldZMin = 0.25f + (1.0f - factor) * 3.0f;
				focusByDepthWorldZMax = 0.5f + (1.0f - factor) * 5.0f;
				lens = 1.0f + (0.3f * factor);
			}
			else if (sconceMode == 2)
			{
				playerLightRef->brightness = factor;
				focusByDepthRadius = 2.0f * (1.0f - factor);
				focusByDepthWorldZMin = 0.25f + (factor) * 3.0f;
				focusByDepthWorldZMax = 0.5f + (factor) * 5.0f;
				lens = 1.0f + (0.3f * (1.0f - factor));
			}
			else
			{
				playerLightRef->brightness = 1.0f;
				focusByDepthRadius = 0.0f;
				lens = 1.0f;
			}
			factor = (1.0f - float(cos(MathUtilities::DegreesToRadians(factor * 180.0f)))) / 2.0f;
			fov = fovBegin + (fovEnd - fovBegin) * factor;
		}
	}
}

LinkedListNode<RandomDungeonBall> * TestRandomDungeon::MakeDungeonBallNode()
{
	LinkedListNode<RandomDungeonBall> *newBall = balls->GetNewNode();
	newBall->data.Initialize();
	balls->AddNode(newBall);
	return newBall;
}

void TestRandomDungeon::AnimatePlayer(float p_elapsedTimeMSf, Vector3d &p_playerMoveVector, float p_playerMoveSpeed)
{
	float bulletTimeToConsumef = p_elapsedTimeMSf;
	// ALWAYS consume bullet delay to zero if possible
	CycleBulletDelay(bulletTimeToConsumef);

	if (useExceptionTest == false)
	{
		if (joystickControl == true)
		{
			// apply joystick controls
			// create new orientation for player
			playerOrient->Rotate(playerOrient->f, joystickRollAngleDegreesPerMS * p_elapsedTimeMSf);
			playerOrient->Rotate(playerOrient->l, joystickPitchAngleDegreesPerMS * p_elapsedTimeMSf);
			playerOrient->Rotate(playerOrient->u, joystickYawAngleDegreesPerMS * p_elapsedTimeMSf);

			// fire bullets until time is consumed
			if (fireBullets == true && bulletDelayMS == 0)
			{
				bool done = false;
				while (done == false)
				{
					FireBullet(*playerOrient, bulletHardpointLeft, GameColor(255, 255, 192)); // kind of yellow
					bulletHardpointLeft = !bulletHardpointLeft;

					CycleBulletDelay(bulletTimeToConsumef);
					if (bulletDelayMS != 0)
						done = true;
				}
			}
		}

		playerOrient->p = playerOrient->p + p_playerMoveVector.ScalarMult(p_playerMoveSpeed * p_elapsedTimeMSf);
	}
	else
	{
		exceptionTestNodeTimerMS -= int(p_elapsedTimeMSf);
		if (exceptionTestNodeTimerMS <= 0)
		{
			exceptionTestNodeTimerMS = 2000;

			// put player in new room
			static FastRandom fastRandomPlayer;
			int nodeIndex = fastRandomPlayer.GetRandomInteger(0, portalMap->nodeQty - 1);
			playerOrient->p.x = portalMap->nodes[nodeIndex].center.x;
			playerOrient->p.z = portalMap->nodes[nodeIndex].center.z;
		}

		playerOrient->Rotate(Vector3d(0, 1, 0), exceptionTestRoomSpinDegreesPerMS * p_elapsedTimeMSf);
	}

	// use node collider set to confine player
	// note - this may not always work.  should really check indices at center-radius, center+radius and check ALL of those nodes, because
	//   center might have moved out of the node that it really needs to be contained by.  for now, I'll leave this the way it is for speed
	// todo: correct - there is a case where this fails - a 4 way node intersection has no vertical segments because it has no vertical surfaces.  So run containment on all
	//   nodes in the region it overlaps!
	//int nodeThatPlayerIsIn = portalMap->NodeThatPointIsInside(playerOrient->p, *portalPartition, x);
	//if (nodeThatPlayerIsIn != -1)
	//{
	// int x;
	//	portalMap->nodes[nodeThatPlayerIsIn].colliderSet.ContainSphere(playerOrient->p, 0.1f);
	//}
	// get all partition cells for start and end point of ball and run the colliders for all of them (collisionT will continually be reduced until a first colliding object is found)
	Vector3d minPosition, maxPosition;
	float radius = 0.1f;
	minPosition.x = playerOrient->p.x - radius;
	minPosition.y = playerOrient->p.y - radius;
	minPosition.z = playerOrient->p.z - radius;
	maxPosition.x = playerOrient->p.x + radius;
	maxPosition.y = playerOrient->p.y + radius;
	maxPosition.z = playerOrient->p.z + radius;

	// ignore nodes that ball overlaps, we need the limits of the movement for the animation loop
	int xMinIndex, yMinIndex, zMinIndex, xMaxIndex, yMaxIndex, zMaxIndex;
	portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
	portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
	for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
	{
		for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
		{
			for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
			{
				LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
				while (nodeIndexEnumerator.MoveNext())
				{
					// quick way to exclude
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
						continue;

					// this might repeat nodes, but not a big deal right now
					portalMap->nodes[nodeIndexEnumerator.Current()->data.index].colliderSet.ContainSphere(playerOrient->p, radius);
				}
			}
		}
	}
}

void TestRandomDungeon::CycleBulletDelay(float &p_bulletDelayMS)
{
	if (p_bulletDelayMS > 0)
	{
		if (bulletDelayMS <= p_bulletDelayMS)
		{
			p_bulletDelayMS -= bulletDelayMS;
			bulletDelayMS = 0;
		}
		else
		{
			bulletDelayMS -= p_bulletDelayMS;
			p_bulletDelayMS = 0;
		}
	}
}

void TestRandomDungeon::FireBullet(Orient3d &p_playerOrient, bool p_left, GameColor &p_color)
{
	// create bullet at left or right hardpoint
	LinkedListNode<RandomDungeonBullet> *newBullet = bullets->GetNewNode();
	newBullet->data.bounceQty = 0;
	newBullet->data.velocity = p_playerOrient.f.ScalarMult(bulletSpeedPerMS);
	newBullet->data.color = p_color;
	newBullet->data.lightRef = nullptr; // for now
	newBullet->data.collisionRadius = 0.025f;
	float bulletStartForwardOffset = 0.1f;
	float bulletStartLateralOffset = 0.1f;
	newBullet->data.position = p_playerOrient.p + p_playerOrient.f.ScalarMult(bulletStartForwardOffset) + p_playerOrient.l.ScalarMult(bulletStartLateralOffset * (p_left == true ? 1.0f : -1.0f));
	// ?? establish nodes they overlap (this is a little painful and should be cleaned up since I'm always copying code)

	// create light for it and associate them

	// increase delay for next shot
	bulletDelayMS += 125.0f;
}

void TestRandomDungeon::Animate(float p_elapsedTimeMSf)
{
	if (freezeBalls == false)
	{
		float timeToConsumeMSf = p_elapsedTimeMSf;

		// advance game timer for others uses
		gameTimeMSf += timeToConsumeMSf;

		AnimateBalls(timeToConsumeMSf);

		// careful - if frozen from the beginning no creatures will animated and they won't have original orientation values for the interpolation for the rendering.
		AnimateCreatures(timeToConsumeMSf);
	}

	// special triguy animation - not really used
	triguyAnimationTracker->Animate(p_elapsedTimeMSf, triguyJointOrients);

	if (sarahTimerMSf > 0.0f)
	{
		static FastRandom fastRandom;

		sarahTimerMSf -= p_elapsedTimeMSf;
		if (sarahTimerMSf < 0.0f)
			sarahTimerMSf = 0.0f;
		if (sarahTimerMSf > 0.0f)
		{
			if (sarahTimerMSf > 1000.0f)
				// fade in
				sarahModel->GetColor(0)->Set(255, 255, 255, int(128.0f * (2000.0f - sarahTimerMSf) / 1000.0f));
			else
				// fade out
				sarahModel->GetColor(0)->Set(255, 255, 255, int(128.0f * sarahTimerMSf / 1000.0f));

			int check = fastRandom.GetRandomInteger(1, 30);
			if (check == 1)
			{
				float x = float(fastRandom.GetRandomInteger(0, 16) - 8);
				float y = float(fastRandom.GetRandomInteger(0, 16) - 8);
				sarahOrient->p = sarahOrient->p + sarahOrient->l.ScalarMult(x / 300.0f) + sarahOrient->u.ScalarMult(y / 300.0f);
			}
		}
	}

	// jump scare
	if (jumpScareTimerMSf > 0.0f)
	{
		static Orient3d triguyOrient3dBackup;

		jumpScareTimerMSf -= p_elapsedTimeMSf;
		if (jumpScareTimerMSf < 0.0f)
			jumpScareTimerMSf = 0.0f;
		if (jumpScareTimerMSf > 0.0f)
		{
			if (jumpScareTimerMSf >= 8125.0f)
			{
				lightScale = (jumpScareTimerMSf - 8125.0f) / 1000.0f;
				// take a backup of orientation
				triguyOrient3dBackup.Set(*triguyRedEyesOrient);
			}
			else
			{
				lightScale = 0.0f;
				maxLightQty = 0;
				if (jumpScareTimerMSf < 8125.0f && jumpScareTimerMSf >= 8060.0f)
				{
					// move triguyredeyes at player face
					Vector3d target = playerOrient->p + playerOrient->f.ScalarMult(0.20f) - Vector3d(0, 0.065f, 0);
					triguyRedEyesOrient->p = target + (triguyOrient3dBackup.p - target).ScalarMult((jumpScareTimerMSf - 8060.0f) / 65.0f);
				}
				else if (jumpScareTimerMSf < 8060.0f && jumpScareTimerMSf >= 7000.0f)
				{
					// waggle triguy red eyes in player's face
					FastRandom fastRandom;
					triguyRedEyesOrient->Set(triguyOrient3dBackup);
					// start in player's face
					triguyRedEyesOrient->p = playerOrient->p + playerOrient->f.ScalarMult(0.20f) - Vector3d(0, 0.065f, 0);
					// waggle!
					float angle = float(fastRandom.GetRandomInteger(0, 60) - 30);
					triguyRedEyesOrient->Rotate(triguyRedEyesOrient->u, angle);
					float x = float(fastRandom.GetRandomInteger(0, 20) - 10) / 320.0f;
					float y = float(fastRandom.GetRandomInteger(0, 20) - 10) / 480.0f;
					triguyRedEyesOrient->p = triguyRedEyesOrient->p + playerOrient->l.ScalarMult(x) + Vector3d(0.0f, y, 0.0f);
				}
				else if (jumpScareTimerMSf < 7000.0f)
				{
					triguyRedEyesOrient->p = Vector3d(0, 0, 0);
				}
			}
		}
		else
		{
			lightScale = 1.0f;
			maxLightQty = 8;
		}
	}
}

void TestRandomDungeon::AnimateBalls(float p_elapsedTimeMSf)
{
	LinkedListEnumerator<RandomDungeonBall> ballEnumerator = LinkedListEnumerator<RandomDungeonBall>(*balls);
	while (ballEnumerator.MoveNext())
	{
		// this arrangement is ok because the balls don't collide with each other
		AnimateBall(&(ballEnumerator.Current()->data), p_elapsedTimeMSf);
	}
}

void TestRandomDungeon::AnimateBall(RandomDungeonBall *p_ball, float p_elapsedTimeMSf)
{
	Vector3d accelerationPerMSMS = Vector3d(0, -1, 0).ScalarMult(gravityPerMSMS);
	bool atLeastOneCollision = false;

	float timeToConsumeMSf = p_elapsedTimeMSf;
	p_ball->priorPosition = p_ball->orient.p;
	// don't increase velocity yet, but apply acceleration
	// velocity will be increased at end
	p_ball->orient.p = p_ball->orient.p + p_ball->velocity.ScalarMult(timeToConsumeMSf) + accelerationPerMSMS.ScalarMult(0.5f * timeToConsumeMSf * timeToConsumeMSf);

	// todo: affect it with gravity, make it collide with walls!
	// spin it!
	int bothPositionsSameNodeId = -1;
	int xMinIndex, yMinIndex, zMinIndex;
	int xMaxIndex, yMaxIndex, zMaxIndex;
	Vector3d minPosition;
	Vector3d maxPosition;
	while (timeToConsumeMSf > 0.0f)
	{
		Vector3d travelVector = p_ball->orient.p - p_ball->priorPosition;

		float collisionT = 10.0f;
		void *colliderObject = nullptr; // if set afterwards, there was a collision
		ColliderObjectType colliderObjectType;
		Vector3d collisionPoint;
		Vector3d collisionNormal;

		// get all partition cells for start and end point of ball and run the colliders for all of them (collisionT will continually be reduced until a first colliding object is found)
		minPosition.x = p_ball->priorPosition.x - p_ball->radius;
		if (minPosition.x > p_ball->orient.p.x - p_ball->radius)
			minPosition.x = p_ball->orient.p.x - p_ball->radius;
		minPosition.y = p_ball->priorPosition.y - p_ball->radius;
		if (minPosition.y > p_ball->orient.p.y - p_ball->radius)
			minPosition.y = p_ball->orient.p.y - p_ball->radius;
		minPosition.z = p_ball->priorPosition.z - p_ball->radius;
		if (minPosition.z > p_ball->orient.p.z - p_ball->radius)
			minPosition.z = p_ball->orient.p.z - p_ball->radius;
		maxPosition.x = p_ball->priorPosition.x + p_ball->radius;
		if (maxPosition.x < p_ball->orient.p.x + p_ball->radius)
			maxPosition.x = p_ball->orient.p.x + p_ball->radius;
		maxPosition.y = p_ball->priorPosition.y + p_ball->radius;
		if (maxPosition.y < p_ball->orient.p.y + p_ball->radius)
			maxPosition.y = p_ball->orient.p.y + p_ball->radius;
		maxPosition.z = p_ball->priorPosition.z + p_ball->radius;
		if (maxPosition.z < p_ball->orient.p.z + p_ball->radius)
			maxPosition.z = p_ball->orient.p.z + p_ball->radius;

		// ignore nodes that ball overlaps, we need the limits of the movement for the animation loop
		portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
		portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
		for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
		{
			for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
			{
				for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
				{
					LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
					while (nodeIndexEnumerator.MoveNext())
					{
						// quick way to exclude
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
							continue;

						// this might repeat nodes, but not a big deal right now
						colliderSetsExecuted++;
						portalMap->nodes[nodeIndexEnumerator.Current()->data.index].colliderSet.SphereCollision(p_ball->priorPosition, travelVector, p_ball->radius, collisionT, &colliderObject, colliderObjectType, collisionPoint, collisionNormal);
					}
				}
			}
		}

		if (colliderObject == nullptr)
		{
			// no collision
			// keep p intact except for containment adjustment below

			// apply full spin
			p_ball->orient.Rotate(p_ball->spinAxis, p_ball->spinDegreesPerMS * timeToConsumeMSf);

			// increase velocity
			p_ball->velocity = p_ball->velocity + accelerationPerMSMS.ScalarMult(timeToConsumeMSf);

			// and just in case, keep ball contained so that a perfect touch now isn't miscalcualted for collision next time
			timeToConsumeMSf = 0.0f;

			// done with loop
			break;
		} // no collision
		else
		{
			// we have a collision
			atLeastOneCollision = true; // flag to check potential energy at the end

			float timeConsumedUpToCollisionMSf = timeToConsumeMSf * collisionT;
			timeToConsumeMSf -= timeConsumedUpToCollisionMSf;

			// move ball up to the point of collision
			p_ball->orient.p = p_ball->priorPosition + travelVector.ScalarMult(collisionT);
			// apply increase to velocity now
			p_ball->velocity = p_ball->velocity + accelerationPerMSMS.ScalarMult(timeConsumedUpToCollisionMSf);
			// apply that amount of spin
			p_ball->orient.Rotate(p_ball->spinAxis, p_ball->spinDegreesPerMS * timeConsumedUpToCollisionMSf);

			// use spin at time of collision to affect bounce velocity (angular momentum for more realism - only do this with realism on otherwise ball may fail to jump back out of a pit)
			// ??

			// special piece of code to make balls bounce toward a portal
			if (collisionNormal.y > 0.999f)
			{
				int x;
				int currentNode = portalMap->NodeThatPointIsInside(p_ball->orient.p, *portalPartition, x);
				if (currentNode != p_ball->currentNode)
				{
					// new node - pick a new portal to jump towards!
					p_ball->currentNode = currentNode;
					// choose target point
					// if only one portal, bounce towards that
					if (portalMap->nodes[p_ball->currentNode].portalIndexQty == 1)
					{
						p_ball->targetPortalIndex = portalMap->nodes[p_ball->currentNode].portalIndices[0];
						p_ball->targetPoint = portalMap->portals[p_ball->targetPortalIndex].center;
					}
					else
					{
						// don't choose closest to exclude, exclude the one the ball was bouncing towards previously
						//int closestPortalIndex = -1;
						//float closestPortalDistanceSq = 0.0f;
						//for (int i = 0; i < portalMap->nodes[p_ball->currentNode].portalIndexQty; i++)
						//{
						//	float distanceSq = (portalMap->portals[portalMap->nodes[p_ball->currentNode].portalIndices[i]].center - p_ball->orient.p).MagnitudeSquared();
						//	if ((closestPortalIndex == -1) || (closestPortalDistanceSq > distanceSq))
						//	{
						//		closestPortalDistanceSq = distanceSq;
						//		closestPortalIndex = i;
						//	}
						//}

						FastRandom fastRandom;
						// get random portal, exclude the portal ball was previously bouncing through
						bool done = false;
						while (done == false)
						{
							int targetPortalIndex = fastRandom.GetRandomInteger(0, portalMap->nodes[p_ball->currentNode].portalIndexQty - 1);
							if (portalMap->nodes[p_ball->currentNode].portalIndices[targetPortalIndex] != p_ball->targetPortalIndex)
							{
								// got a good one
								p_ball->targetPortalIndex = portalMap->nodes[p_ball->currentNode].portalIndices[targetPortalIndex];
								done = true;
							}
						}

						p_ball->targetPoint = portalMap->portals[p_ball->targetPortalIndex].center;
						// done!
					}
				}
				Vector3d offset = p_ball->targetPoint - p_ball->orient.p;
				offset.y = 0.0f;
				if (offset.Normalize() == true) // just playing it safe
				{
					// ok to alter direction
					Vector3d horizontalVelocity = p_ball->velocity;
					horizontalVelocity.y = 0.0f;
					p_ball->velocity = p_ball->velocity - horizontalVelocity;
					float length = horizontalVelocity.Magnitude();
					p_ball->velocity = p_ball->velocity + offset.ScalarMult(length);
				}
			}

			// save for calculation of new spin later, since ball velocity is about to change from the reflection
			Vector3d collisionVelocity = p_ball->velocity;

			// reflect ball off surface
			// todo: trigger to bounce toward target point here
			// apply realistic physics if wanted (absorb some bounce)
			// if collision was so incredibly slight and collisionTime was very small, zero out the velocity in that direction and adjust acceleration below
			bool absorbBallPhysics = false; // todo: move to class variables and toggle (but beware, if realistic phsycis and ANY ball comes to rest, infinite loop in this routine)
			bool preventAcceleration = false;
			if (abs(p_ball->velocity * collisionNormal) > 0.00001f)
			{
				if (absorbBallPhysics == false)
					p_ball->velocity = p_ball->velocity - collisionNormal.ScalarMult(2.0f * (p_ball->velocity * collisionNormal));
				else
				{
					float bounceReduction = 0.90f;
					// absorb just a tiny bit in the direction of the collisionNormal
					p_ball->velocity = p_ball->velocity - collisionNormal.ScalarMult((1.0f + bounceReduction) * (p_ball->velocity * collisionNormal));
				}
			}
			else
			{
				// adjust for a slight slight bounce off a surface (ball might be 'rolling' we don't want to check that surface constantly)
				// ball is 'rolling' indicated by the very light impact
				preventAcceleration = true;
				// note: this is the same as velocity along wall... could just set it to that
				p_ball->velocity = p_ball->velocity - collisionNormal.ScalarMult(p_ball->velocity * collisionNormal);
				if (absorbBallPhysics == true)
				{
					// ball is treated as rolling along a surface, so absorb a little again, but less
					float rollReduction = 0.99f;
					float comeToStopReduction = 0.85f;
					float magnitudeSquared = p_ball->velocity.MagnitudeSquared();
					float magnitudeThreshold = 0.000000016f; // based on world value (this one is 4 foot per second, squared)
					if (magnitudeSquared > magnitudeThreshold || collisionNormal.y < 0.99f) // slightly reduce if on fairly non-horizontal surface or rolling decently (0.06 degree slope)
						p_ball->velocity = p_ball->velocity.ScalarMult(rollReduction);
					else
					{
						// bring to stop - rolling very slowly on horizontal surface (if slanted at all, gravity will be trying to accelerate it)
						float reduction = rollReduction - (magnitudeThreshold - magnitudeSquared) / magnitudeThreshold * (rollReduction - comeToStopReduction); // slow it down up to 0.75 the closer to zero it gets
						p_ball->velocity = p_ball->velocity.ScalarMult(reduction);
					}
				}
			}

			// calculate new spin off collision velocity
			Vector3d velocityAlongWall = collisionVelocity - collisionNormal.ScalarMult(collisionVelocity * collisionNormal);
			Vector3d proposedBallSpinAxis = velocityAlongWall.CrossProd(collisionNormal);
			if (proposedBallSpinAxis.Normalize() == true)
			{
				p_ball->spinAxis = proposedBallSpinAxis;
				p_ball->spinDegreesPerMS = MathUtilities::RadiansToDegrees(velocityAlongWall.Magnitude() / p_ball->radius);
			}
			else if (collisionVelocity.MagnitudeSquared() < 0.00001f)
				// just keep axis the same and just spin according to the velocity - ball is likely coming to rest
				p_ball->spinDegreesPerMS = MathUtilities::RadiansToDegrees(velocityAlongWall.Magnitude() / p_ball->radius);
			else
				// we hit the wall dead on, hard enough to stop spinning.
				p_ball->spinDegreesPerMS = 0;

			// calculate new p - move from p calculated up to point of collision to the position it will be in when the rest of the time is consumed
			// new prior, new updated position
			p_ball->priorPosition = p_ball->orient.p;
			Vector3d accelerationComponentOfNewPosition = accelerationPerMSMS.ScalarMult(0.5f * timeToConsumeMSf * timeToConsumeMSf);
			if (preventAcceleration == false)
			{
				// make sure we're ok
				Vector3d oldP = p_ball->orient.p;
				p_ball->orient.p = p_ball->orient.p + p_ball->velocity.ScalarMult(timeToConsumeMSf) + accelerationComponentOfNewPosition;
				if (collisionT == 0.0f && ((p_ball->orient.p - p_ball->priorPosition) * collisionNormal < 0.0f))
				{
					// nope, gravity is going to cause another collision at time 0, so fix!
					// this portion of code can happen when a ball bouncing for a long time without any reduction loses its energy because of rounding
					// todo: sadly, this didn't work.
					p_ball->orient.p = oldP;
					preventAcceleration = true;
				}
			}
			if (preventAcceleration == true)
			{
				// don't acceleration along the surface this time - collision was so slight we are pretty much rolling - this avoids accelerating in a way to collide with that surface again
				// this avoids infinite loops MUCH better than trying to zero out the move offset or skipping detection later
				accelerationComponentOfNewPosition = accelerationComponentOfNewPosition - collisionNormal.ScalarMult(accelerationComponentOfNewPosition * collisionNormal);
				p_ball->orient.p = p_ball->orient.p + p_ball->velocity.ScalarMult(timeToConsumeMSf) + accelerationComponentOfNewPosition;
			}
			// travel vector will be recalculated in beginning of loop

			// currentNode on ball is good from beginning of iteration, no need to retrieve it again

			// check potential energy only on upward slanted collisions
			// todo: if accurate physics is on, don't do this
			// forget this for a while
			//if (collisionNormal.y > 0.5f)
			//{
			//	//if (absorbBallPhysics == false)
			//	p_ball->CheckPotentialEnergy(); // make sure no energy is lost in velocity
			//}


		} // collision
	} // while there is time to consume

	// just in case, keep ball contained after all is done
	// don't use ball node lists for nodes to use for containment, since we haven't maintained those after movement yet - that happens elsewhere
	minPosition = p_ball->orient.p - Vector3d(p_ball->radius, p_ball->radius, p_ball->radius);
	maxPosition = p_ball->orient.p + Vector3d(p_ball->radius, p_ball->radius, p_ball->radius);
	portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
	portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
	for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
	{
		for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
		{
			for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
			{
				LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
				while (nodeIndexEnumerator.MoveNext())
				{
					// quick way to exclude
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
						continue;

					// this might repeat nodes, but not a big deal right now
					portalMap->nodes[nodeIndexEnumerator.Current()->data.index].colliderSet.ContainSphere(p_ball->orient.p, p_ball->radius + 0.00001f);
				}
			}
		}
	}
}

void TestRandomDungeon::MaintainBallAndLightNodeLists()
{
	parsesToMaintainNodeBallLists = 0;

	Vector3d minPosition;
	Vector3d maxPosition;
	int xMinIndex, yMinIndex, zMinIndex;
	int xMaxIndex, yMaxIndex, zMaxIndex;

	LinkedListEnumerator<RandomDungeonBall> ballEnumerator = LinkedListEnumerator<RandomDungeonBall>(*balls);
	while (ballEnumerator.MoveNext())
	{
		RandomDungeonBall *ball = &(ballEnumerator.Current()->data);

		// just in case, keep ball contained after all is done, and re-check nodes overlapped
		// get rid of references it currently is listed under (todo: might be faster to just wipe them all out and repopulate them after all animation is done, especially when 200 balls are in one node)
		LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(ball->nodesOverlapped);
		while (nodeEnumerator.MoveNext())
		{
			LinkedListEnumerator<RandomDungeonBallPtr> ballEnumerator = LinkedListEnumerator<RandomDungeonBallPtr>(nodeObjectLists[nodeEnumerator.Current()->data.index].balls);
			while (ballEnumerator.MoveNext())
			{
				parsesToMaintainNodeBallLists++;
				if (ballEnumerator.Current()->data == ball)
				{
					nodeObjectLists[nodeEnumerator.Current()->data.index].balls.DeleteNode(ballEnumerator.Current());
					break;
				}
			}
		}
		ball->nodesOverlapped.Clear();
		minPosition = ball->orient.p - Vector3d(ball->radius, ball->radius, ball->radius);
		maxPosition = ball->orient.p + Vector3d(ball->radius, ball->radius, ball->radius);
		portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
		portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
		for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
		{
			for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
			{
				for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
				{
					LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
					while (nodeIndexEnumerator.MoveNext())
					{
						// quick way to exclude
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
							continue;
						if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
							continue;

						// track node overlapped, don't store duplicate (although it isn't destructive, so might be faster to do so)
						LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(ball->nodesOverlapped);
						bool found = false;
						while (nodeEnumerator.MoveNext())
						{
							if (nodeEnumerator.Current()->data.index == nodeIndexEnumerator.Current()->data.index)
							{
								found = true;
								break;
							}
						}
						if (found == false)
						{
							ball->nodesOverlapped.Add(PortalNodeIndex(nodeIndexEnumerator.Current()->data.index));

							nodeObjectLists[nodeIndexEnumerator.Current()->data.index].balls.Add(ball);
						}
					}
				}
			}
		}

		// now move light with ball and maintain its current node and node light list
		if (ballEnumerator.Current()->data.lightRef != nullptr)
		{
			if (ballEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::Point)
				ballEnumerator.Current()->data.lightRef->SetPosition(ballEnumerator.Current()->data.orient.p);
			else if (ballEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::Spotlight)
				ballEnumerator.Current()->data.lightRef->SetPositionAndDirection(ballEnumerator.Current()->data.orient.p, ballEnumerator.Current()->data.orient.f);
			else if (ballEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::SpotlightTexture)
				ballEnumerator.Current()->data.lightRef->SetPositionAndAxes(ballEnumerator.Current()->data.orient.p, ballEnumerator.Current()->data.orient.f, ballEnumerator.Current()->data.orient.l, ballEnumerator.Current()->data.orient.u);

			MaintainLightNodeLists(ballEnumerator.Current()->data.lightRef);
		}
	} // for each ball
}

void TestRandomDungeon::MaintainLightNodeLists(RandomDungeonLight *p_light)
{
	int x;
	int tempNode = portalMap->NodeThatPointIsInside(p_light->worldPosition, *portalPartition, x);
	if (tempNode != p_light->currentNode)
	{
		// remove this light from that node list
		if (p_light->currentNode != -1)
		{
			LinkedListEnumerator<RandomDungeonLightPtr> lightEnumerator = LinkedListEnumerator<RandomDungeonLightPtr>(nodeObjectLists[p_light->currentNode].lights);
			while (lightEnumerator.MoveNext())
			{
				if (lightEnumerator.Current()->data == p_light)
				{
					nodeObjectLists[p_light->currentNode].lights.DeleteNode(lightEnumerator.Current());
					break;
				}
			}
		}
		// add this light to the other node list
		if (tempNode != -1)
			nodeObjectLists[tempNode].lights.Add(p_light);
		p_light->currentNode = tempNode;
	}
}

void TestRandomDungeon::AnimateCreatures(float p_elapsedTimeMSf)
{
	if (p_elapsedTimeMSf <= 0)
		return;
	if (allowObjectsInShadowMaps == false && allowObjectsInRender == false)
		return;

	LinkedListEnumerator<RandomDungeonCreature> enumerator = LinkedListEnumerator<RandomDungeonCreature>(*creatures);
	while (enumerator.MoveNext())
	{
		RandomDungeonCreature *creature = &(enumerator.Current()->data);

		// did the creature reach the target position?
		// this block handles both triguys and arbiters
		Vector3d offset = creature->targetPosition - creature->orient.p;
		offset.y = 0.0f;
		if (offset.MagnitudeSquared() < 0.01f) // < 0.1f
		{
			// choose new target position

			int nodesParsed;
			int nodeIndex = portalMap->NodeThatPointIsInside(creature->orient.p, nodesParsed);
			if (nodeIndex == -1)
				throw gcnew Exception("Creature is not in a node - -1 returned");
			bool putTargetPositionInFront = false;
			if (nodeIndex != creature->nodeIndex) // if creature moved into a new mode, choose a point in the node that is in front of a random portal
			{
				putTargetPositionInFront = true;
				creature->nodeIndex = nodeIndex;
				if (portalMap->nodes[nodeIndex].portalIndexQty == 1)
				{
					creature->targetPortalIndex = portalMap->nodes[nodeIndex].portalIndices[0];
				}
				else
				{
					// choose a random portal that isn't the current one
					FastRandom fastRandom;
					int portalCount;
					if (creature->targetPortalIndex < 0)
						creature->targetPortalIndex = portalMap->nodes[nodeIndex].portalIndices[fastRandom.GetRandomInteger(0, portalMap->nodes[nodeIndex].portalIndexQty - 1)];
					else
					{
						portalCount = fastRandom.GetRandomInteger(0, portalMap->nodes[nodeIndex].portalIndexQty - 2);
						for (int i = 0; i < portalMap->nodes[nodeIndex].portalIndexQty; i++)
						{
							if (portalMap->nodes[nodeIndex].portalIndices[i] != creature->targetPortalIndex)
							{
								if (portalCount == 0)
								{
									creature->targetPortalIndex = portalMap->nodes[nodeIndex].portalIndices[i];
									break;
								}
								else
									portalCount--;
							}
						}
					}
				}
			}

			// now that we have a target portal, determine target point
			if (portalMap->portals[creature->targetPortalIndex].PointInFront(creature->orient.p) == putTargetPositionInFront)
			{
				creature->targetPosition = portalMap->portals[creature->targetPortalIndex].center + portalMap->portals[creature->targetPortalIndex].normal.ScalarMult(0.5);
			}
			else
			{
				creature->targetPosition = portalMap->portals[creature->targetPortalIndex].center - portalMap->portals[creature->targetPortalIndex].normal.ScalarMult(0.5);
			}
		}

		// we have a good target position now

		// turn towards target
		switch (creature->type)
		{
		case RandomDungeonObjectTypeEnum::Triguy:
			{
				if (offset.MagnitudeSquared() > 0.01f) // skip if right on target with 1 foot
				{
					offset.Normalize(); // for angle check
					if (offset * creature->orient.f < 0.999f) // skip if pointing pretty much at target
					{
						float turnDegreesPerMS = 360.0f / 1000.0f; // one revolution per second
						bool facingTowards = true; // if not facing towards, don't worry about turning too much
						if (offset * creature->orient.f < 0.0f)
							facingTowards = false;
						float turnAmount = 0.0f;
						if (offset * creature->orient.l > 0.0f)
						{
							turnAmount = -turnDegreesPerMS * p_elapsedTimeMSf;
						}
						else
						{
							turnAmount = turnDegreesPerMS * p_elapsedTimeMSf;
						}
						creature->orient.Rotate(creature->orient.u, turnAmount);
						float testTurnTooMuch = offset * creature->orient.l;
						if (facingTowards == true && (testTurnTooMuch > 0.0f && turnAmount > 0.0f) || (testTurnTooMuch < 0.0f && turnAmount < 0.0f))
						{
							// turned too much - point it right at the target
							creature->orient.f = offset;
							//creature->orient.f.Normalize(); // offset already normalized
							creature->orient.l = creature->orient.u.CrossProd(creature->orient.f);
						}
					}
				}

				// move towards target
				// normal triguy travels 2.0f in 250ms.  or 8.0f in 1000ms;
				float baseSpeed = 8.0f / 1000.0f; // 80 feet per second
				creature->orient.p = creature->orient.p + creature->orient.f.ScalarMult(baseSpeed * (0.1f) * creature->speed * p_elapsedTimeMSf);

				// animate it!
				// only track keyframes - don't calculate final orients until render time - otherwise this hits the framerate too much animating every creature on the map
				creature->jointedModelAnimationTracker.Animate(p_elapsedTimeMSf * creature->speed * (0.1f / creature->scale), creature->jointOrients, false); // Adjust by speed and walk speed factor according to animation
			}
			break;
		case RandomDungeonObjectTypeEnum::Arbiter:
			{
				if (offset.MagnitudeSquared() > 0.01f) // skip if right on target with 1 foarot
				{
					offset.Normalize(); // for angle check
					// no turning
				}

				// move towards target
				float baseSpeed = 1.0f / 1000.0f; // 10 feet per second
				creature->orient.p = creature->orient.p + offset.ScalarMult(baseSpeed * creature->speed * p_elapsedTimeMSf);

				// prep for light tally during render
				if (creature->lightRef != nullptr)
				{
					creature->newSpotlightMS -= p_elapsedTimeMSf;

					// todo: initiate new interpolation
					float timeToInterpolate = p_elapsedTimeMSf;
					if (creature->newSpotlightMS <= 0.0f)
					{
						static FastRandom fastRandom;
						float newMS = float(fastRandom.GetRandomInteger(1500, 3000));
						creature->newSpotlightMS += newMS;
						timeToInterpolate = newMS - creature->newSpotlightMS;
						creature->arbiterLightData.SetNewOrientationInterpolation(creature->arbiterLightData.currentOrient, RandomDungeonArbiterLightData::RandomSpotlightOrient(), float(fastRandom.GetRandomInteger(250, 500)));
					}

					creature->lightRef->SetArbiterLightPosition(creature->orient.p);
					creature->lightRef->ArbiterApplyElapsedTimeMS(timeToInterpolate);
					MaintainLightNodeLists(creature->lightRef);
				}
			}
			break;
		}

		MaintainCreatureNodeList(*creature);
	}
}

void TestRandomDungeon::MaintainCreatureNodeList(RandomDungeonCreature &p_creature)
{
	// get rid of references it currently is listed under (todo: might be faster to just wipe them all out and repopulate them after all animation is done)
	LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(p_creature.nodesOverlapped);
	while (nodeEnumerator.MoveNext())
	{
		LinkedListEnumerator<RandomDungeonCreaturePtr> creatureEnumerator = LinkedListEnumerator<RandomDungeonCreaturePtr>(nodeObjectLists[nodeEnumerator.Current()->data.index].creatures);
		while (creatureEnumerator.MoveNext())
		{
			if (creatureEnumerator.Current()->data == &p_creature)
			{
				nodeObjectLists[nodeEnumerator.Current()->data.index].creatures.DeleteNode(creatureEnumerator.Current());
				break;
			}
		}
	}
	p_creature.nodesOverlapped.Clear();

	// todo: actually this should be a unit vector along 1,1,1 and -1,-1,-1 scalrmultiplied by renderRadius for more accuracy, but this isn't destructive
	Vector3d minPosition = p_creature.orient.p - Vector3d(p_creature.renderRadius, p_creature.renderRadius, p_creature.renderRadius);
	Vector3d maxPosition = p_creature.orient.p + Vector3d(p_creature.renderRadius, p_creature.renderRadius, p_creature.renderRadius);
	int xMinIndex, yMinIndex, zMinIndex;
	int xMaxIndex, yMaxIndex, zMaxIndex;
	portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
	portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
	for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
	{
		for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
		{
			for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
			{
				LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
				while (nodeIndexEnumerator.MoveNext())
				{
					// quick way to exclude
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
						continue;
					if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
						continue;

					// track node overlapped, don't store duplicate (although it isn't destructive, so might be faster to do so)
					LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(p_creature.nodesOverlapped);
					bool found = false;
					while (nodeEnumerator.MoveNext())
					{
						if (nodeEnumerator.Current()->data.index == nodeIndexEnumerator.Current()->data.index)
						{
							found = true;
							break;
						}
					}
					if (found == false)
					{
						p_creature.nodesOverlapped.Add(PortalNodeIndex(nodeIndexEnumerator.Current()->data.index));

						nodeObjectLists[nodeIndexEnumerator.Current()->data.index].creatures.Add(&(p_creature));
					}
				}
			} // zIndex
		} // yIndex
	} // zIndex
}

void TestRandomDungeon::RunRandomDungeonGenerateIterations(int p_steps)
{
	// show the fix per frame
	if (randomDungeonGenerateIteration->phase == RandomDungeonGenerateIterationPhase::ConnectRegions)
		p_steps = 1;

	for (int i = 0; i < p_steps; i++)
		DoRandomDungeonGenerateIteration();
}

void TestRandomDungeon::RunRandomDungeonMakePortalIterations(int p_steps)
{
	for (int i = 0; i < p_steps; i++)
		DoRandomDungeonMakePortalIteration();
}

void TestRandomDungeon::DoRandomDungeonGenerateIteration()
{
	static FastRandom fastRandom;
	static LecuyerRandom random; // to make room distribution less patterned

	switch (randomDungeonGenerateIteration->phase)
	{
	case RandomDungeonGenerateIterationPhase::RandomRooms:
	{
		bool done = false;
		while (done == false)
		{
			// by having rooms with 3,5,7,9 dimensions and starting at an odd coordinate, they are guaranteed to have 1 or 3 border between them, allowing a hallway
			// so leave hardcoded for now
			int roomWidth = 1 + 2 * fastRandom.GetRandomInteger(1, 3); // 3,5,7
			int roomHeight = 1 + 2 * fastRandom.GetRandomInteger(1, 3); // 3,5,7
			//int roomWidth = 7;
			//int roomHeight = 7;
			// leave a border at the edges always
			int roomStartX = 1 + 2 * random.GetRandomInteger(0, (dungeon->cellWidth - roomWidth - 2) / 2);
			int roomStartY = 1 + 2 * random.GetRandomInteger(0, (dungeon->cellHeight - roomHeight - 2) / 2);
			// if the room overlaps or is exactly adjacent to any other rooms, discard it and try again
			DungeonRoom room(roomStartX, roomStartY, roomWidth, roomHeight);
			//DungeonRoom testRoom(roomStartX-1, roomStartY-1, roomWidth+2, roomHeight+2); // force a border between rooms
			if (randomDungeonGenerateIteration->AnyRoomsOverlapped(room) == false)
			{
				randomDungeonGenerateIteration->roomRetries = 0;
				// room is good
				done = true;
				dungeon->ApplyRoom(room);
				room.doorQty = fastRandom.GetRandomInteger(1, 6); // final result 1-3 doors
				// weight the random more to 1, less to 3
				if (room.doorQty > 5)
					room.doorQty = 3;
				if (room.doorQty > 4)
					room.doorQty = 2;
				// save it for checking overlaps later
				randomDungeonGenerateIteration->rooms[randomDungeonGenerateIteration->roomQty] = room;
				randomDungeonGenerateIteration->roomQty++;
				if (randomDungeonGenerateIteration->roomQty == randomDungeonGenerateIteration->maxRoomQty)
					randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::RandomHalls;
			}
			else
			{
				randomDungeonGenerateIteration->roomRetries++;
				if (randomDungeonGenerateIteration->roomRetries >= 100)
				{
					// we aren't trying anymore, 100 failure is enough
					randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::RandomHalls;
					done = true;
				}
			}
		}
	}
	break;
	case RandomDungeonGenerateIterationPhase::RandomHalls:
	{
		if (randomDungeonGenerateIteration->hallwayPoints.IsEmpty() == true)
		{
			// find a new starting point - if one found, add to list.  If none, go to next phase
			// check odd numbered coordinates only.  Find an odd (both x and y) coordinate point that is rock that has at least one valid direction to go (2 over, another rock)
			for (int h = 1; h < dungeon->cellWidth - 1; h += 2)
			{
				bool breakOut = false;
				for (int v = 1; v < dungeon->cellHeight - 1; v += 2)
				{
					int count = 0;
					if (dungeon->GetCell(h, v)->rock == true)
					{
						DungeonPoint point = dungeon->GetValidDirections(h, v, count);
						if (count > 0)
						{
							randomDungeonGenerateIteration->hallwayPoints.Add(point);
							dungeon->GetCell(h, v)->rock = false;
							randomDungeonGenerateIteration->currentHallwayGroup++;
							dungeon->GetCell(h, v)->hallwayGroup = randomDungeonGenerateIteration->currentHallwayGroup;
							breakOut = true;
							break;
						}
					}
				}
				if (breakOut == true)
					break;
			}
		}

		if (randomDungeonGenerateIteration->hallwayPoints.IsEmpty() == true)
		{
			// still empty
			// move on to doors, no more hallway points to find or work on
			randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::RandomDoors;
		}
		else
		{
			// keep working on last point in list
			// find a valid direction to go.  (any direction that 2 over is a rock cell completely surrounded by rocks)
			// if either coordinate is even, continue in same direction
			DungeonPoint point = randomDungeonGenerateIteration->hallwayPoints.GetLastNode()->data;
			if (point.x % 2 == 0 || point.y % 2 == 0)
			{
				// only one of these should be set, see below from random direction selection
				if (point.left == true)
				{
					point.x--;
					point.currentDirection = 0;
				}
				else if (point.right == true)
				{
					point.x++;
					point.currentDirection = 1;
				}
				else if (point.up == true)
				{
					point.y--;
					point.currentDirection = 2;
				}
				else if (point.down == true)
				{
					point.y++;
					point.currentDirection = 3;
				}
				dungeon->GetCell(point.x, point.y)->rock = false;
				dungeon->GetCell(point.x, point.y)->hallwayGroup = randomDungeonGenerateIteration->currentHallwayGroup;
				// save it
				randomDungeonGenerateIteration->hallwayPoints.GetLastNode()->data = point;
			}
			else
			{
				// evaluate directions
				int count = 0;
				int currentDirection = point.currentDirection;
				point = dungeon->GetValidDirections(point.x, point.y, count);
				if (count == 0)
				{
					// if no valid direction to go, remove the point
					// remove point, continue - last node is now a new point to continue with
					randomDungeonGenerateIteration->hallwayPoints.DeleteNode(randomDungeonGenerateIteration->hallwayPoints.GetLastNode());
					// move the first node to the last slot so that earlier points are handled first
					// actually, leave this out - a long long main hallways with little branches is better than a lot of long long branches
					//if (randomDungeonIteration->hallwayPoints.IsEmpty() == false)
					//{
					//	LinkedListNode<DungeonPoint> *node = randomDungeonIteration->hallwayPoints.GetFirstNode();
					//	randomDungeonIteration->hallwayPoints.DetachNode(node);
					//	randomDungeonIteration->hallwayPoints.InsertNode(node, randomDungeonIteration->hallwayPoints.GetLastNode()); // if list is now empty, this will just put it back
					//}	
					randomDungeonGenerateIteration->currentHallwayGroup++;
				}
				else if (count == 1)
				{
					// If only one valid direction to go, go that way
					// go that way!
					if (point.left == true)
					{
						point.x--;
					}
					else if (point.right == true)
					{
						point.x++;
					}
					else if (point.up == true)
					{
						point.y--;
					}
					else if (point.down == true)
					{
						point.y++;
					}
					dungeon->GetCell(point.x, point.y)->rock = false;
					dungeon->GetCell(point.x, point.y)->hallwayGroup = randomDungeonGenerateIteration->currentHallwayGroup;
					// save it
					randomDungeonGenerateIteration->hallwayPoints.GetLastNode()->data = point;
				}
				else if (count > 1)
				{
					// If more than one direction can go, store this point again in the list so that we can come back to it, and pick a random direction to go of the ones found
					// save it again and pick a random direction to go
					// canel the other directions to track which way we stepped into the even coordinate
					int weight = 6; // higher = more chance of a straight hallway
					int direction = fastRandom.GetRandomInteger(1, count * weight);
					// use currentdirection to weight the result
					bool done = false;
					if (direction > count)
					{
						// go in weighted direction
						switch (currentDirection)
						{
						case 0: // left
							if (point.left == true)
							{
								point.left = true;
								point.right = false;
								point.up = false;
								point.down = false;
								done = true;
							}
							break;
						case 1: // right
							if (point.right == true)
							{
								point.left = false;
								point.right = true;
								point.up = false;
								point.down = false;
								done = true;
							}
							break;
						case 2: // up
							if (point.up == true)
							{
								point.left = false;
								point.right = false;
								point.up = true;
								point.down = false;
								done = true;
							}
							break;
						case 3: // down
							if (point.down == true)
							{
								point.left = false;
								point.right = false;
								point.up = false;
								point.down = true;
								done = true;
							}
							break;
						}
					}

					if (done == false) // if done = true we are continuing in the weighted direction
					{
						// get a usable direction
						int direction = fastRandom.GetRandomInteger(1, count);
						for (int i = 0; i < 4; i++)
						{
							switch (i)
							{
							case 0:
								if (point.left == true)
								{
									direction--;
									if (direction == 0)
									{
										point.right = false;
										point.up = false;
										point.down = false;
									}
								}
								break;
							case 1:
								if (point.right == true)
								{
									direction--;
									if (direction == 0)
									{
										point.left = false;
										point.up = false;
										point.down = false;
									}
								}
								break;
							case 2:
								if (point.up == true)
								{
									direction--;
									if (direction == 0)
									{
										point.right = false;
										point.left = false;
										point.down = false;
									}
								}
								break;
							case 3:
								if (point.down == true)
								{
									direction--;
									if (direction == 0)
									{
										point.right = false;
										point.up = false;
										point.left = false;
									}
								}
								break;
							} // switch
						} // for
					}

					// go that way!
					if (point.left == true)
					{
						point.x--;
					}
					else if (point.right == true)
					{
						point.x++;
					}
					else if (point.up == true)
					{
						point.y--;
					}
					else if (point.down == true)
					{
						point.y++;
					}
					dungeon->GetCell(point.x, point.y)->rock = false;
					dungeon->GetCell(point.x, point.y)->hallwayGroup = randomDungeonGenerateIteration->currentHallwayGroup;

					// add it!  we'll be coming back to the prior point after this one has no more options (earliest insertions are handled first)
					randomDungeonGenerateIteration->hallwayPoints.Add(point);
				}
			}
		}
	}
	break;
	// next case
	case RandomDungeonGenerateIterationPhase::RandomDoors:
	{
		// place one door on a room
		// IMPORTANT NOTE: To avoid confusion in algorithms regarding double wide doorways (since hallways or rooms cannot predict how they will be noded), do NOT place
		//   two doors right next to each other
		DungeonRoom *room = &(randomDungeonGenerateIteration->rooms[randomDungeonGenerateIteration->currentRoom]);
		int roomFace = fastRandom.GetRandomInteger(1, 4);
		// 1 left, 2 right, 3 up, 4 down
		bool done = false;
		// start along random place on face, looking for the first cell 2 over that is not rock
		// if no good place for a door found, drop out and retry to a max number of retries
		switch (roomFace)
		{
		case 1: // left
			if (room->left >= 3)
			{
				int currentFace = fastRandom.GetRandomInteger(0, room->height - 1);
				for (int i = 0; i < room->height; i++)
				{
					if (dungeon->GetCell(room->left - 1, room->top + currentFace + 1)->rock == true)
						if (dungeon->GetCell(room->left - 1, room->top + currentFace - 1)->rock == true)
							if (dungeon->GetCell(room->left - 2, room->top + currentFace)->rock == false)
							{
								dungeon->GetCell(room->left - 1, room->top + currentFace)->rock = false;
								done = true;
								break;
							}

					currentFace++;
					if (currentFace >= room->height)
						currentFace = 0;
				}
			}
			break;
		case 2: // right
			if (room->right < dungeon->cellWidth - 3)
			{
				int currentFace = fastRandom.GetRandomInteger(0, room->height - 1);
				for (int i = 0; i < room->height; i++)
				{
					// don't place doorways right next to each other
					if (dungeon->GetCell(room->right - 1 + 1, room->top + currentFace + 1)->rock == true)
						if (dungeon->GetCell(room->right - 1 + 1, room->top + currentFace - 1)->rock == true)
							if (dungeon->GetCell(room->right - 1 + 2, room->top + currentFace)->rock == false)
							{
								dungeon->GetCell(room->right - 1 + 1, room->top + currentFace)->rock = false;
								done = true;
								break;
							}

					currentFace++;
					if (currentFace >= room->height)
						currentFace = 0;
				}
			}
			break;
		case 3: // up
			if (room->top >= 3)
			{
				int currentFace = fastRandom.GetRandomInteger(0, room->width - 1);
				for (int i = 0; i < room->width; i++)
				{
					// don't place doorways right next to each other
					if (dungeon->GetCell(room->left + currentFace + 1, room->top - 1)->rock == true)
						if (dungeon->GetCell(room->left + currentFace - 1, room->top - 1)->rock == true)
							if (dungeon->GetCell(room->left + currentFace, room->top - 2)->rock == false)
							{
								dungeon->GetCell(room->left + currentFace, room->top - 1)->rock = false;
								done = true;
								break;
							}

					currentFace++;
					if (currentFace >= room->width)
						currentFace = 0;
				}
			}
			break;
		case 4: // down
			if (room->bottom < dungeon->cellHeight - 3)
			{
				int currentFace = fastRandom.GetRandomInteger(0, room->width - 1);
				for (int i = 0; i < room->width; i++)
				{
					// don't place doorways right next to each other
					if (dungeon->GetCell(room->left + currentFace - 1, room->bottom - 1 + 1)->rock == true)
						if (dungeon->GetCell(room->left + currentFace + 1, room->bottom - 1 + 1)->rock == true)
							if (dungeon->GetCell(room->left + currentFace, room->bottom - 1 + 2)->rock == false)
							{
								dungeon->GetCell(room->left + currentFace, room->bottom - 1 + 1)->rock = false;
								done = true;
								break;
							}

					currentFace++;
					if (currentFace >= room->width)
						currentFace = 0;
				}

			}
			break;
		}

		if (done == false)
		{
			// increment retries
			// if tried too many times just forget this room
			randomDungeonGenerateIteration->roomDoorRetries++;
			if (randomDungeonGenerateIteration->roomDoorRetries > 30)
			{
				done = true;
				room->doorQty = 1;
			}
		}
		if (done == true)
		{
			randomDungeonGenerateIteration->roomDoorRetries = 0;
			room->doorQty--;

			if (room->doorQty == 0)
			{
				randomDungeonGenerateIteration->currentRoom++;
				if (randomDungeonGenerateIteration->currentRoom == randomDungeonGenerateIteration->roomQty)
					randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::PaintRegions;
			}
		}
	}
	break;
	case RandomDungeonGenerateIterationPhase::PaintRegions:
	{
		if (randomDungeonGenerateIteration->hallwayPoints.IsEmpty() == true)
		{
			// find a new starting point - if one found, add to list.  If none, go to next phase
			// check odd numbered coordinates only.  Find an odd (both x and y) coordinate point that is rock that has at least one valid direction to go (2 over, another rock)
			for (int h = 1; h < dungeon->cellWidth - 1; h++)
			{
				bool breakOut = false;
				for (int v = 1; v < dungeon->cellHeight - 1; v++)
				{
					if (dungeon->GetCell(h, v)->rock == false && dungeon->GetCell(h, v)->hallwayRegion == -1)
					{
						DungeonPoint point;
						point.x = h;
						point.y = v;
						randomDungeonGenerateIteration->currentRegion++;
						// paint it
						dungeon->GetCell(point.x, point.y)->hallwayRegion = randomDungeonGenerateIteration->currentRegion;
						// save it so we can work on it later
						randomDungeonGenerateIteration->hallwayPoints.Add(point);
						breakOut = true;
						break;
					}
				}
				if (breakOut == true)
					break;
			}

			if (randomDungeonGenerateIteration->hallwayPoints.IsEmpty() == true)
			{
				// still empty
				// move on to dead ends, no more hallway regions to paint
				randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::ConnectRegions;
			}
		}
		else
		{
			// get last hallway point and progress
			DungeonPoint point = randomDungeonGenerateIteration->hallwayPoints.GetLastNode()->data;
			point.left = false;
			point.right = false;
			point.up = false;
			point.down = false;
			// find a direction to go - if only one direction then update last node.  If more than one direction then go that way, paint region, and store the point
			int count = 0;
			if (dungeon->GetCell(point.x - 1, point.y)->rock == false && dungeon->GetCell(point.x - 1, point.y)->hallwayRegion == -1)
			{
				point.left = true;
				count++;
			}
			if (dungeon->GetCell(point.x + 1, point.y)->rock == false && dungeon->GetCell(point.x + 1, point.y)->hallwayRegion == -1)
			{
				point.right = true;
				count++;
			}
			if (dungeon->GetCell(point.x, point.y - 1)->rock == false && dungeon->GetCell(point.x, point.y - 1)->hallwayRegion == -1)
			{
				point.up = true;
				count++;
			}
			if (dungeon->GetCell(point.x, point.y + 1)->rock == false && dungeon->GetCell(point.x, point.y + 1)->hallwayRegion == -1)
			{
				point.down = true;
				count++;
			}
			if (count == 0)
			{
				// remove that point - we are done with that one
				randomDungeonGenerateIteration->hallwayPoints.DeleteNode(randomDungeonGenerateIteration->hallwayPoints.GetLastNode());
			}
			else if (count == 1)
			{
				// paint the point and update the last node
				if (point.left == true)
				{
					point.x--;
				}
				else if (point.right == true)
				{
					point.x++;
				}
				else if (point.up == true)
				{
					point.y--;
				}
				else if (point.down == true)
				{
					point.y++;
				}
				dungeon->GetCell(point.x, point.y)->hallwayRegion = randomDungeonGenerateIteration->currentRegion;
				randomDungeonGenerateIteration->hallwayPoints.GetLastNode()->data = point;
			}
			else if (count > 1)
			{
				// just pick a way to go, paint it and add a new point
				if (point.left == true)
				{
					point.x--;
				}
				else if (point.right == true)
				{
					point.x++;
				}
				else if (point.up == true)
				{
					point.y--;
				}
				else if (point.down == true)
				{
					point.y++;
				}
				// paint the point
				dungeon->GetCell(point.x, point.y)->hallwayRegion = randomDungeonGenerateIteration->currentRegion;
				// and add it so we leave a trail of where to continue when this point has no more options
				randomDungeonGenerateIteration->hallwayPoints.Add(point);
			}
		}
	}
	break;
	case RandomDungeonGenerateIterationPhase::ConnectRegions:
	{
		bool found = false;
		int h = fastRandom.GetRandomInteger(1, dungeon->cellWidth - 2);
		int v = fastRandom.GetRandomInteger(1, dungeon->cellHeight - 2);
		// find a point to connect with another region
		int fixH, fixV, fixRegion, fixedRegion;
		for (int i = 0; i < (dungeon->cellWidth - 2) * (dungeon->cellHeight - 2); i++)
		{
			// check left
			if (h >= 2
				&& dungeon->GetCell(h - 2, v)->rock == false
				&& dungeon->GetCell(h, v)->rock == false
				&& (dungeon->GetCell(h - 2, v)->hallwayRegion != dungeon->GetCell(h, v)->hallwayRegion)
				&& dungeon->GetCell(h - 1, v)->rock == true
				&& dungeon->GetCell(h - 1, v - 1)->rock == true
				&& dungeon->GetCell(h - 1, v + 1)->rock == true)
			{
				fixH = h - 1;
				fixV = v;
				fixRegion = dungeon->GetCell(h - 2, v)->hallwayRegion;
				fixedRegion = dungeon->GetCell(h, v)->hallwayRegion;
				if (fixRegion > dungeon->GetCell(h, v)->hallwayRegion)
				{
					fixRegion = dungeon->GetCell(h, v)->hallwayRegion;
					fixedRegion = dungeon->GetCell(h - 2, v)->hallwayRegion;
				}
				found = true;
			}

			// check right
			if (h <= dungeon->cellWidth - 3
				&& found == false
				&& dungeon->GetCell(h + 2, v)->rock == false
				&& dungeon->GetCell(h, v)->rock == false
				&& (dungeon->GetCell(h + 2, v)->hallwayRegion != dungeon->GetCell(h, v)->hallwayRegion)
				&& dungeon->GetCell(h + 1, v)->rock == true
				&& dungeon->GetCell(h + 1, v - 1)->rock == true
				&& dungeon->GetCell(h + 1, v + 1)->rock == true)
			{
				fixH = h + 1;
				fixV = v;
				fixRegion = dungeon->GetCell(h + 2, v)->hallwayRegion;
				fixedRegion = dungeon->GetCell(h, v)->hallwayRegion;
				if (fixRegion > dungeon->GetCell(h, v)->hallwayRegion)
				{
					fixRegion = dungeon->GetCell(h, v)->hallwayRegion;
					fixedRegion = dungeon->GetCell(h + 2, v)->hallwayRegion;
				}
				found = true;
			}

			// check up
			if (v >= 2
				&& found == false
				&& dungeon->GetCell(h, v - 2)->rock == false
				&& dungeon->GetCell(h, v)->rock == false
				&& (dungeon->GetCell(h, v - 2)->hallwayRegion != dungeon->GetCell(h, v)->hallwayRegion)
				&& dungeon->GetCell(h, v - 1)->rock == true
				&& dungeon->GetCell(h - 1, v - 1)->rock == true
				&& dungeon->GetCell(h + 1, v - 1)->rock == true)
			{
				fixH = h;
				fixV = v - 1;
				fixRegion = dungeon->GetCell(h, v - 2)->hallwayRegion;
				fixedRegion = dungeon->GetCell(h, v)->hallwayRegion;
				if (fixRegion > dungeon->GetCell(h, v)->hallwayRegion)
				{
					fixRegion = dungeon->GetCell(h, v)->hallwayRegion;
					fixedRegion = dungeon->GetCell(h, v - 2)->hallwayRegion;
				}
				found = true;
			}

			// check down
			if (v <= dungeon->cellHeight - 3
				&& found == false
				&& dungeon->GetCell(h, v + 2)->rock == false
				&& dungeon->GetCell(h, v)->rock == false
				&& (dungeon->GetCell(h, v + 2)->hallwayRegion != dungeon->GetCell(h, v)->hallwayRegion)
				&& dungeon->GetCell(h, v + 1)->rock == true
				&& dungeon->GetCell(h - 1, v + 1)->rock == true
				&& dungeon->GetCell(h + 1, v + 1)->rock == true)
			{
				fixH = h;
				fixV = v + 1;
				fixRegion = dungeon->GetCell(h, v + 2)->hallwayRegion;
				fixedRegion = dungeon->GetCell(h, v)->hallwayRegion;
				if (fixRegion > dungeon->GetCell(h, v)->hallwayRegion)
				{
					fixRegion = dungeon->GetCell(h, v)->hallwayRegion;
					fixedRegion = dungeon->GetCell(h, v + 2)->hallwayRegion;
				}
				found = true;
			}

			// if one connected, fix the higher region to equal the lower region
			if (found == true)
			{
				// fix region and paint over all of the 
				dungeon->GetCell(fixH, fixV)->rock = false;
				dungeon->GetCell(fixH, fixV)->hallwayRegion = fixRegion;
				for (int h = 1; h < dungeon->cellWidth - 1; h++)
				{
					for (int v = 1; v < dungeon->cellHeight - 1; v++)
						if (dungeon->GetCell(h, v)->hallwayRegion == fixedRegion)
							dungeon->GetCell(h, v)->hallwayRegion = fixRegion;
				}

				break; // break out of main for
			}
			else
			{
				// continue i loop
				h++;
				if (h >= dungeon->cellWidth - 1)
				{
					h = 1;
					v++;
					if (v >= dungeon->cellHeight - 1)
						v = 1;
				}
			}
		} // for i - loop through all valid h's and v's

		// if none found, we're done
		if (found == false)
		{
			// reset regions for rendering, we are done fixing
			for (int h = 1; h < dungeon->cellWidth - 1; h++)
			{
				for (int v = 1; v < dungeon->cellHeight - 1; v++)
				{
					if (dungeon->GetCell(h, v)->rock == false)
					{
						if (dungeon->GetCell(h, v)->hallwayRegion != 0)
							throw gcnew Exception("Failed to connect all regions");
						dungeon->GetCell(h, v)->hallwayRegion = -1;
					}
				}
			}

			randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::ClearDeadEnds;
		}
	}
	break;
	case RandomDungeonGenerateIterationPhase::ClearDeadEnds:
	{
		bool done = false;
		while (done == false)
		{
			int h = randomDungeonGenerateIteration->currentRemoveDeadEndX;
			int v = randomDungeonGenerateIteration->currentRemoveDeadEndY;

			DungeonCell *cell = dungeon->GetCell(h, v);
			int count = 0;
			if (cell->rock == false)
			{
				if (dungeon->GetCell(h - 1, v)->rock == true)
					count++;
				if (dungeon->GetCell(h + 1, v)->rock == true)
					count++;
				if (dungeon->GetCell(h, v - 1)->rock == true)
					count++;
				if (dungeon->GetCell(h, v + 1)->rock == true)
					count++;
			}
			if (count >= 3)
			{
				cell->rock = true;
				done = true;
			}

			randomDungeonGenerateIteration->currentRemoveDeadEndY++;
			if (randomDungeonGenerateIteration->currentRemoveDeadEndY == dungeon->cellHeight - 1)
			{
				randomDungeonGenerateIteration->currentRemoveDeadEndY = 1;
				randomDungeonGenerateIteration->currentRemoveDeadEndX++;
				if (randomDungeonGenerateIteration->currentRemoveDeadEndX == dungeon->cellWidth - 1)
				{
					randomDungeonGenerateIteration->currentRemoveDeadEndX = 1;

					// reached end of map
					// see if there are any left to take care of at all

					bool breakOut = false;
					bool found = false;
					for (int h = 1; h < dungeon->cellWidth - 1; h++)
					{
						for (int v = 1; v < dungeon->cellHeight - 1; v++)
						{
							DungeonCell *cell = dungeon->GetCell(h, v);
							int count = 0;
							if (cell->rock == false)
							{
								if (dungeon->GetCell(h - 1, v)->rock == true)
									count++;
								if (dungeon->GetCell(h + 1, v)->rock == true)
									count++;
								if (dungeon->GetCell(h, v - 1)->rock == true)
									count++;
								if (dungeon->GetCell(h, v + 1)->rock == true)
									count++;
							}
							if (count >= 3)
							{
								found = true;
								// establish new starting point and fix cell if we haven't fixed one already
								randomDungeonGenerateIteration->currentRemoveDeadEndX = h;
								randomDungeonGenerateIteration->currentRemoveDeadEndY = v;
								breakOut = true;
								break;
							}
						}

						if (breakOut == true)
							break;
					}

					if (found == false)
					{
						randomDungeonGenerateIteration->phase = RandomDungeonGenerateIterationPhase::Done;
						done = true;
					}
				}
			} // increment Y and X
		} // while not done
	}
	break;
	} // switch
}

void TestRandomDungeon::DoRandomDungeonMakePortalIteration()
{
	switch (randomDungeonMakePortalIteration->phase)
	{
	case RandomDungeonMakePortalIterationPhase::PrepRoomNodes:
	{
		DungeonPortal *portal = nullptr;

		// populate a room's cells as node prepped for now
		// todo: split into nodes based on size max
		int startH = randomDungeonGenerateIteration->rooms[randomDungeonMakePortalIteration->currentRoomIndex].left;
		int stopH = randomDungeonGenerateIteration->rooms[randomDungeonMakePortalIteration->currentRoomIndex].right - 1;
		int startV = randomDungeonGenerateIteration->rooms[randomDungeonMakePortalIteration->currentRoomIndex].top;
		int stopV = randomDungeonGenerateIteration->rooms[randomDungeonMakePortalIteration->currentRoomIndex].bottom - 1;
		int hIncrement = stopH - startH + 1;
		int vIncrement = stopV - startV + 1;
		// split into nodes and add each into node list
		// if a room is > than max allowed size, split room in half so that light distribution is better
		if (hIncrement > randomDungeonMakePortalIteration->maxNodeSize)
			hIncrement = hIncrement / 2 + 1; // fine for odd sized
		if (vIncrement > randomDungeonMakePortalIteration->maxNodeSize)
			vIncrement = vIncrement / 2 + 1; // fine for odd sized
		for (int subStartH = startH; subStartH <= stopH; subStartH += hIncrement)
		{
			int subStopH = subStartH + hIncrement - 1;
			if (subStopH > stopH)
				subStopH = stopH;
			for (int subStartV = startV; subStartV <= stopV; subStartV += vIncrement)
			{
				int subStopV = subStartV + vIncrement - 1;
				if (subStopV > stopV)
					subStopV = stopV;

				int nodeId = randomDungeonMakePortalIteration->nodeRegistry.nodeQty;
				DungeonNode *node = randomDungeonMakePortalIteration->nodeRegistry.AddNode(nodeId, subStartH, subStopH, subStartV, subStopV);

				// mark cells as noded
				for (int h = subStartH; h <= subStopH; h++)
				{
					for (int v = subStartV; v <= subStopV; v++)
					{
						dungeon->GetCell(h, v)->nodeId = nodeId;
					}
				}

				// add internal portals
				if (subStartH != startH)
				{
					// left portal
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(subStartH - 1, subStartH - 1, subStartV, subStopV, true, false, nodeId);
					node->AddPortalIndex(portal->index);
				}
				if (subStopH != stopH)
				{
					// right portal
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(subStopH, subStopH, subStartV, subStopV, true, true, nodeId);
					node->AddPortalIndex(portal->index);
				}
				if (subStartV != startV)
				{
					// up portal
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(subStartH, subStopH, subStartV - 1, subStartV - 1, false, false, nodeId);
					node->AddPortalIndex(portal->index);
				}
				if (subStopV != stopV)
				{
					// down portal
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(subStartH, subStopH, subStopV, subStopV, false, true, nodeId);
					node->AddPortalIndex(portal->index);
				}

				// evaluate other portals ONLY along edges (single cell portals supported only)
				for (int h = subStartH; h <= subStopH; h++)
				{
					for (int v = subStartV; v <= subStopV; v++)
					{
						if (h == startH)
						{
							// check left
							if (dungeon->GetCell(h - 1, v)->rock == false)
							{
								portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(h - 1, h - 1, v, v, true, false, nodeId);
								node->AddPortalIndex(portal->index);
							}
						}
						if (h == stopH)
						{
							// check right
							if (dungeon->GetCell(h + 1, v)->rock == false)
							{
								portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(h, h, v, v, true, true, nodeId);
								node->AddPortalIndex(portal->index);
							}
						}
						if (v == startV)
						{
							// check up
							if (dungeon->GetCell(h, v - 1)->rock == false)
							{
								portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(h, h, v - 1, v - 1, false, false, nodeId);
								node->AddPortalIndex(portal->index);
							}
						}
						if (v == stopV)
						{
							// check down
							if (dungeon->GetCell(h, v + 1)->rock == false)
							{
								portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(h, h, v, v, false, true, nodeId);
								node->AddPortalIndex(portal->index);
							}
						}
					}
				}
			}
		}

		randomDungeonMakePortalIteration->currentRoomIndex++;
		if (randomDungeonMakePortalIteration->currentRoomIndex == randomDungeonGenerateIteration->roomQty)
			randomDungeonMakePortalIteration->phase = RandomDungeonMakePortalIterationPhase::PrepHallwayNodes;
	}
	break;
	case RandomDungeonMakePortalIterationPhase::PrepHallwayNodes:
	{
		// find a non-noded non-rock cell
		// if none found we are done
		// todo: pick up where we stopped last on the first cell we checked, increment start numbers
		bool found = false;
		int startH, startV;
		bool done = false;
		while (done == false) // per row
		{
			if (randomDungeonMakePortalIteration->nextHallwayV < dungeon->cellHeight)
			{
				for (int h = randomDungeonMakePortalIteration->nextHallwayH; h < dungeon->cellWidth; h++)
				{
					DungeonCell *cell = dungeon->GetCell(h, randomDungeonMakePortalIteration->nextHallwayV);
					if (cell->rock == false && cell->nodeId == -1)
					{
						found = true;
						startH = h;
						startV = randomDungeonMakePortalIteration->nextHallwayV;
						done = true;

						// prep start variables for next iteration
						randomDungeonMakePortalIteration->nextHallwayH = h + 1;
						if (randomDungeonMakePortalIteration->nextHallwayH == dungeon->cellWidth)
						{
							randomDungeonMakePortalIteration->nextHallwayV++;
							randomDungeonMakePortalIteration->nextHallwayH = 0;
							// note: this may put us pass the bottom of the dungeon.  that's ok.  next iteration will realize we are done
						}
						break;
					}
				}
			}
			if (found == false)
			{
				randomDungeonMakePortalIteration->nextHallwayV++;
				if (randomDungeonMakePortalIteration->nextHallwayV == dungeon->cellHeight)
					break; // or done = true
				else
					randomDungeonMakePortalIteration->nextHallwayH = 0;
			}
		}

		if (found == false)
		{
			// all done
			randomDungeonMakePortalIteration->phase = RandomDungeonMakePortalIterationPhase::MakePortalData;

			// validate portals
			randomDungeonMakePortalIteration->portalRegistry.Validate();
		}
		else
		{
			bool horizontal = false;
			bool vertical = false;

			int stopH, stopV;
			stopH = startH;
			stopV = startV;

			DungeonPortal *portal = nullptr;

			// we aren't in a room, handled those in a prior phase, so, this is either a vertical line or a horizontal line stretching down or right
			if (startH < dungeon->cellWidth - 1)
			{
				if (dungeon->GetCell(startH + 1, startV)->rock == false && dungeon->GetCell(startH + 1, startV)->nodeId == -1)
				{
					// itsa horizontal
					horizontal = true;
					bool done = false;
					int size = 1;
					// keep going to the right until we hit rock or a noded cell or hit max size or map border
					while (size < randomDungeonMakePortalIteration->maxNodeSize && stopH < dungeon->cellWidth - 1 && dungeon->GetCell(stopH + 1, startV)->rock == false && dungeon->GetCell(stopH + 1, startV)->nodeId == -1)
					{
						stopH++;
						size++;
					}
					int nodeId = randomDungeonMakePortalIteration->nodeRegistry.nodeQty;
					// mark all the cells noded
					for (int h = startH; h <= stopH; h++)
						dungeon->GetCell(h, startV)->nodeId = nodeId;

					// save node
					DungeonNode *node = randomDungeonMakePortalIteration->nodeRegistry.AddNode(nodeId, startH, stopH, startV, stopV);

					// check portals on ends and both sides
					// todo: does not handle portals taking up more than one cell
					// left
					if (dungeon->GetCell(startH - 1, startV)->rock == false)
					{
						portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH - 1, startH - 1, startV, startV, true, false, nodeId);
						node->AddPortalIndex(portal->index);
					}
					// right
					if (dungeon->GetCell(stopH + 1, startV)->rock == false)
					{
						portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(stopH, stopH, startV, startV, true, true, nodeId);
						node->AddPortalIndex(portal->index);
					}
					for (int h = startH; h <= stopH; h++)
					{
						// up
						if (dungeon->GetCell(h, startV - 1)->rock == false)
						{
							portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(h, h, startV - 1, startV - 1, false, false, nodeId);
							node->AddPortalIndex(portal->index);
						}
						// down
						if (dungeon->GetCell(h, startV + 1)->rock == false)
						{
							portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(h, h, startV, startV, false, true, nodeId);
							node->AddPortalIndex(portal->index);
						}
					}
				}
			}
			if (horizontal == false && startV < dungeon->cellHeight - 1)
			{
				if (dungeon->GetCell(startH, startV + 1)->rock == false && dungeon->GetCell(startH, startV + 1)->nodeId == -1)
				{
					// itsa vertical
					vertical = true;
					bool done = false;
					// keep going down until we hit rock or a noded cell or hit max size or map border
					int size = 1;
					while (size < randomDungeonMakePortalIteration->maxNodeSize && stopV < dungeon->cellHeight - 1 && dungeon->GetCell(startH, stopV + 1)->rock == false && dungeon->GetCell(startH, stopV + 1)->nodeId == -1)
					{
						stopV++;
						size++;
					}
					int nodeId = randomDungeonMakePortalIteration->nodeRegistry.nodeQty;
					// mark all the cells noded
					for (int v = startV; v <= stopV; v++)
						dungeon->GetCell(startH, v)->nodeId = nodeId;

					// save node
					DungeonNode *node = randomDungeonMakePortalIteration->nodeRegistry.AddNode(nodeId, startH, stopH, startV, stopV);

					// check portals on ends and both sides
					// todo: does not handle portals taking up more than one cell
					// up
					if (dungeon->GetCell(startH, startV - 1)->rock == false)
					{
						portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH, startH, startV - 1, startV - 1, false, false, nodeId);
						node->AddPortalIndex(portal->index);
					}
					// down
					if (dungeon->GetCell(startH, stopV + 1)->rock == false)
					{
						portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH, startH, stopV, stopV, false, true, nodeId);
						node->AddPortalIndex(portal->index);
					}

					for (int v = startV; v <= stopV; v++)
					{
						// right
						if (dungeon->GetCell(startH + 1, v)->rock == false)
						{
							portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH, startH, v, v, true, true, nodeId);
							node->AddPortalIndex(portal->index);
						}
						// left
						if (dungeon->GetCell(startH - 1, v)->rock == false)
						{
							portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH - 1, startH - 1, v, v, true, false, nodeId);
							node->AddPortalIndex(portal->index);
						}
					}
				}
			}
			if (horizontal == false && vertical == false)
			{
				// we're dealing with a 1x1 cell.  node it up
				int nodeId = randomDungeonMakePortalIteration->nodeRegistry.nodeQty;
				dungeon->GetCell(startH, startV)->nodeId = nodeId;

				// save node
				DungeonNode *node = randomDungeonMakePortalIteration->nodeRegistry.AddNode(nodeId, startH, stopH, startV, stopV);

				// check portals on all sides
				// right
				if (dungeon->GetCell(startH + 1, startV)->rock == false)
				{
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH, startH, startV, startV, true, true, nodeId);
					node->AddPortalIndex(portal->index);
				}
				// left
				if (dungeon->GetCell(startH - 1, startV)->rock == false)
				{
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH - 1, startH - 1, startV, startV, true, false, nodeId);
					node->AddPortalIndex(portal->index);
				}
				// up
				if (dungeon->GetCell(startH, startV - 1)->rock == false)
				{
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH, startH, startV - 1, startV - 1, false, false, nodeId);
					node->AddPortalIndex(portal->index);
				}
				// down
				if (dungeon->GetCell(startH, startV + 1)->rock == false)
				{
					portal = randomDungeonMakePortalIteration->portalRegistry.AddPortal(startH, startH, startV, startV, false, true, nodeId);
					node->AddPortalIndex(portal->index);
				}
			}
		}
	}
	break;
	case RandomDungeonMakePortalIterationPhase::MakePortalData:
	{
		if (randomDungeonMakePortalIteration->currentNode == nullptr)
		{
			// just starting

			// don't initialize vertices in portalmap yet - we don't know how many there are yet
			portalMap->Initialize(randomDungeonMakePortalIteration->nodeRegistry.nodeQty, randomDungeonMakePortalIteration->portalRegistry.portalQty);
			randomDungeonMakePortalIteration->currentNode = randomDungeonMakePortalIteration->nodeRegistry.nodes.GetFirstNode();

			// make all the portals now, so that progress on the nodes can be followed
			LinkedList<DungeonPortal> *portalList = randomDungeonMakePortalIteration->portalRegistry.portalLists;
			for (int i = 0; i < randomDungeonMakePortalIteration->portalRegistry.listsPerRow * randomDungeonMakePortalIteration->portalRegistry.rowQty; i++)
			{
				LinkedListEnumerator<DungeonPortal> enumerator = LinkedListEnumerator<DungeonPortal>(*portalList);
				while (enumerator.MoveNext())
				{
					// always 4
					portalMap->portals[enumerator.Current()->data.index].Initialize(4);
					portalMap->portals[enumerator.Current()->data.index].frontNodeIndex = enumerator.Current()->data.frontNodeIndex;
					portalMap->portals[enumerator.Current()->data.index].backNodeIndex = enumerator.Current()->data.backNodeIndex;
					if (enumerator.Current()->data.right == false)
					{
						// if portal is horizontal, clockwise facing up - southern tip of startV/stopV, left tip of startH, right tip of stopH
						portalMap->portals[enumerator.Current()->data.index].vertices[0] = Vector3d(float(enumerator.Current()->data.stopH + 1), 0.0f, float(enumerator.Current()->data.startV + 1));
						portalMap->portals[enumerator.Current()->data.index].vertices[1] = Vector3d(float(enumerator.Current()->data.stopH + 1), 1.0f, float(enumerator.Current()->data.startV + 1));
						portalMap->portals[enumerator.Current()->data.index].vertices[2] = Vector3d(float(enumerator.Current()->data.startH), 1.0f, float(enumerator.Current()->data.startV + 1));
						portalMap->portals[enumerator.Current()->data.index].vertices[3] = Vector3d(float(enumerator.Current()->data.startH), 0.0f, float(enumerator.Current()->data.startV + 1));
					}
					else
					{
						// if portal is vertical, clockwise facing left - right tip of startH/stopH, top tip of startV, bottom tip of stopV
						portalMap->portals[enumerator.Current()->data.index].vertices[0] = Vector3d(float(enumerator.Current()->data.startH + 1), 0.0f, float(enumerator.Current()->data.startV));
						portalMap->portals[enumerator.Current()->data.index].vertices[1] = Vector3d(float(enumerator.Current()->data.startH + 1), 1.0f, float(enumerator.Current()->data.startV));
						portalMap->portals[enumerator.Current()->data.index].vertices[2] = Vector3d(float(enumerator.Current()->data.startH + 1), 1.0f, float(enumerator.Current()->data.stopV + 1));
						portalMap->portals[enumerator.Current()->data.index].vertices[3] = Vector3d(float(enumerator.Current()->data.startH + 1), 0.0f, float(enumerator.Current()->data.stopV + 1));
					}
				}

				// next list
				portalList++;
			}
		}

		////////////////////////////
		// process the current node

		// make the node geometry for the currentNode
		DungeonNode *currentNodeData = &(randomDungeonMakePortalIteration->currentNode->data);
		int pass = 1; // 1 = count surfaces needed, 2 = make surfaces and create vertices
		int surfaceQty = 0; // for pass 1
		int surfaceIndex = 0; // for pass 2
		ModelSurface *surface = nullptr; // surface to create geometry for (could be a node surface or a mirror)
		// note: for simplicity, some surfaces may be allocated but have no polygons added to them because the vertices were placed on a mirror instead - these will be skipped in the rendering
		Vector2d perimeterVertices[24]; // max 24 with 6-square nodes, exception if more than that, 50 just in case but still exception if > 24
		// these perimeter vertices are for creating perfect stitching between the quad floor and ceiling with the staggered geometry of the walls.  Otherwise, artifacting can occur during rendering
		// the basic algorithm is:
		// - form the first triangle in the lower corner
		// - keep making triangles by continuing parsing in one direction and stop just short of the opposite corner
		// - continue with the rest of the triangles in the other direction including the opposite corner
		// - done
		// - number of triangles is always number of vertices - 2
		// note: these triangles can also be used for collider data, but it is faster to use the full quad for the collider
		int maxVertexQty = 24; // equal array definition
		int perimeterVertexQty = 0;
		int upperLeftVertexIndex = 0; // stopping point for loop 1 when build floor and ceiling geometry

		int floorCeilingSurfaceQty = 0; // how many surfaces are we putting on the floro and ceiling (each)?  Helps with creating surface storage for mirrors if mirror is floor or ceiling
		int logicalSurfaceQty = 0; // how many logical surfaces are there?  (individual walls, and floor and ceiling)
		int logicalSurfaceIndex = 0; // current logical surface in pass 2

		int mirrorLogicalSurfaceIndex = -1; // which logical surface are we making a mirror for? (todo: support multiple mirrors)
		int mirrorQty = 0; // how many mirrors in this node? set after first pass
		int mirrorIndex = 0; // current mirror
		static FastRandom fastRandom;
		GameColor mirrorColor(255, 128, 255, 96); // purple for clarity, some sheen, not too much, to show up in a generally dark room
		switch (fastRandom.GetRandomInteger(0, 0)) // leave as purple for now - multicolored give you too much to look at
		{
		case 0:
			mirrorColor = GameColor(255, 128, 255, 96); // purple
			//mirrorColor = GameColor(0, 0, 0, 96); // black - no, this makes the surface uniform with no visible attributes - an rgba texture or just alpha using any color for the polygon would be necessary for that
			break;
		case 1:
			mirrorColor = GameColor(255, 255, 128, 96); // yellow
			break;
		case 2:
			mirrorColor = GameColor(128, 255, 255, 96); // cyan
			break;
		case 3:
			mirrorColor = GameColor(255, 128, 128, 96); // red
			break;
		case 4:
			mirrorColor = GameColor(128, 255, 128, 96); // green
			break;
		case 5:
			mirrorColor = GameColor(128, 128, 255, 96); // blue
			break;
		}

		GameTexture ^diffuseTexture = nullptr;
		GameTexture ^bumpMapTexture = nullptr;
		GameTexture ^specularTexture = nullptr;

		while (pass <= 2)
		{
			if (pass == 2)
			{
				if (useMirrors == true)
				{
					mirrorLogicalSurfaceIndex = fastRandom.GetRandomInteger(0, logicalSurfaceQty - 1); // anywhere (ceiling, floor, any wall)
					//mirrorLogicalSurfaceIndex = fastRandom.GetRandomInteger(0, 1); // ceiling or floor only
					//mirrorLogicalSurfaceIndex = 0; // always ceiling
					//mirrorLogicalSurfaceIndex = 1; // always floor
				}
			}

			if (pass == 1)
			{
				// collect information about vertices that will be used to assemble floor and ceiling geometry to connect perfectly with any wall sections prepared
				// right wall up, include corners
				bool currentRock = true;
				for (int v = currentNodeData->cellRange.stopV; v >= currentNodeData->cellRange.startV; v--)
				{
					if (v == currentNodeData->cellRange.stopV)
					{
						// always save lwoer right corner vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(currentNodeData->cellRange.stopH + 1), float(v + 1));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(currentNodeData->cellRange.stopH + 1, v)->rock;
					}
					else if (currentRock != dungeon->GetCell(currentNodeData->cellRange.stopH + 1, v)->rock)
					{
						// store vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(currentNodeData->cellRange.stopH + 1), float(v + 1));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(currentNodeData->cellRange.stopH + 1, v)->rock;
					}
					if (v == currentNodeData->cellRange.startV)
					{
						// always save corner upper right corner vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(currentNodeData->cellRange.stopH + 1), float(v));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(currentNodeData->cellRange.stopH, v - 1)->rock;
					}
				}
				// top wall left, skip corners
				for (int h = currentNodeData->cellRange.stopH - 1; h >= currentNodeData->cellRange.startH; h--)
				{
					if (currentRock != dungeon->GetCell(h, currentNodeData->cellRange.startV - 1)->rock)
					{
						// store vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(h + 1), float(currentNodeData->cellRange.startV));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(h, currentNodeData->cellRange.startV - 1)->rock;
					}
				}
				// left wall down, include corners
				for (int v = currentNodeData->cellRange.startV; v <= currentNodeData->cellRange.stopV; v++)
				{
					if (v == currentNodeData->cellRange.startV)
					{
						// always save upper left corner vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(currentNodeData->cellRange.startH), float(v));
						// and record this one as the stopper for loop 1 in the surface build
						upperLeftVertexIndex = perimeterVertexQty;
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(currentNodeData->cellRange.startH - 1, v)->rock;
					}
					else if (currentRock != dungeon->GetCell(currentNodeData->cellRange.startH - 1, v)->rock)
					{
						// store vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(currentNodeData->cellRange.startH), float(v));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(currentNodeData->cellRange.startH - 1, v)->rock;
					}
					if (v == currentNodeData->cellRange.stopV)
					{
						// always save lower left corner vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(currentNodeData->cellRange.startH), float(v + 1));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(currentNodeData->cellRange.startH, v + 1)->rock;
					}
				}
				// bottom wall right, skip corners
				for (int h = currentNodeData->cellRange.startH + 1; h <= currentNodeData->cellRange.stopH; h++)
				{
					if (currentRock != dungeon->GetCell(h, currentNodeData->cellRange.stopV + 1)->rock)
					{
						// store vertex
						if (perimeterVertexQty >= maxVertexQty)
							throw gcnew System::Exception("Too many vertices - did you increase the node size and allow more to occur?");
						perimeterVertices[perimeterVertexQty] = Vector2d(float(h), float(currentNodeData->cellRange.stopV + 1));
						perimeterVertexQty++;
						currentRock = dungeon->GetCell(h, currentNodeData->cellRange.stopV + 1)->rock;
					}
				}

				// count surfaces (triangles)
				surfaceQty = 2 * (perimeterVertexQty - 2); // ceiling and floor are ALWAYS drawn, this counts triangles in each, doubled
				floorCeilingSurfaceQty = perimeterVertexQty - 2;
				//surfaceQty = 2;
				logicalSurfaceQty += 2; // always a single logical floor and ceiling (for selecting a surface to make a mirror)
			}
			else
			{
				// todo: make the ceiling and floor surfaces
				int vertexIndex;

				// need something better than this to join floor and ceiling geometry with wall openings
				//// ceiling
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->Initialize(4, true);
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetTexture0(randomDungeonMakePortalIteration->ceilingTextureRef);
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetBumpMapTexture(randomDungeonMakePortalIteration->ceilingBumpMapTextureRef);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->startH), 1.0f, float(currentNodeData->startV)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(0, float(currentNodeData->startH), float(currentNodeData->startV));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(0, vertexIndex);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->startH), 1.0f, float(currentNodeData->stopV + 1)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(1, float(currentNodeData->startH), float(currentNodeData->stopV + 1));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(1, vertexIndex);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->stopH + 1), 1.0f, float(currentNodeData->stopV + 1)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(2, float(currentNodeData->stopH + 1), float(currentNodeData->stopV + 1));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(2, vertexIndex);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->stopH + 1), 1.0f, float(currentNodeData->startV)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(3, float(currentNodeData->stopH + 1), float(currentNodeData->startV));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(3, vertexIndex);
				//surfaceIndex++;

				//// floor
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->Initialize(4, true);
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetTexture0(randomDungeonMakePortalIteration->floorTextureRef);
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetBumpMapTexture(randomDungeonMakePortalIteration->floorBumpMapTextureRef);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->startH), 0.0f, float(currentNodeData->startV)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(0, float(currentNodeData->startH), float(currentNodeData->startV));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(0, vertexIndex);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->stopH + 1), 0.0f, float(currentNodeData->startV)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(1, float(currentNodeData->stopH + 1), float(currentNodeData->startV));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(1, vertexIndex);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->stopH + 1), 0.0f, float(currentNodeData->stopV + 1)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(2, float(currentNodeData->stopH + 1), float(currentNodeData->stopV + 1));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(2, vertexIndex);
				//vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->startH), 0.0f, float(currentNodeData->stopV + 1)))->index;
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexTexCoords(3, float(currentNodeData->startH), float(currentNodeData->stopV + 1));
				//portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex)->SetVertexIndex(3, vertexIndex);
				//surfaceIndex++;

				// ceiling

				if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
				{
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(floorCeilingSurfaceQty, mirrorColor);
					surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
					diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

					// create ceiling portal at height 1.0f
					// startH,startV;startH,stopV+1;stopH+1,stopV+1;stopH+1,startV
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(currentNodeData->cellRange.startV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.startV));
					mirrorIndex++;
				}
				else
				{
					surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
					diffuseTexture = randomDungeonMakePortalIteration->ceilingTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->ceilingBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->ceilingSpecularTextureRef;
				}
				// triangle 0 (perimeterVertexQty-1, corner, 1), set upper right point
				surface->Initialize(3, true);
				surface->SetTexture0(diffuseTexture);
				surface->SetBumpMapTexture(bumpMapTexture);
				surface->SetSpecularMapTexture0(specularTexture);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[perimeterVertexQty - 1].x, 1.0f, perimeterVertices[perimeterVertexQty - 1].y))->index;
				surface->SetVertexTexCoords(0, perimeterVertices[perimeterVertexQty - 1].x, perimeterVertices[perimeterVertexQty - 1].y);
				surface->SetVertexIndex(0, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[0].x, 1.0f, perimeterVertices[0].y))->index;
				surface->SetVertexTexCoords(1, perimeterVertices[0].x, perimeterVertices[0].y);
				surface->SetVertexIndex(1, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[1].x, 1.0f, perimeterVertices[1].y))->index;
				surface->SetVertexTexCoords(2, perimeterVertices[1].x, perimeterVertices[1].y);
				surface->SetVertexIndex(2, vertexIndex);
				surfaceIndex++; // advance so that next logical surface starts with the correct surface
				surface++; // advance the surface being used
				Vector2d upperRightPoint = perimeterVertices[1];
				// loop 1 along bottom and left
				for (int i = perimeterVertexQty - 1; i > upperLeftVertexIndex + 1; i--)
				{
					// next point + current point + upper right point
					surface->Initialize(3, true);
					surface->SetTexture0(diffuseTexture);
					surface->SetBumpMapTexture(bumpMapTexture);
					surface->SetSpecularMapTexture0(specularTexture);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i - 1].x, 1.0f, perimeterVertices[i - 1].y))->index;
					surface->SetVertexTexCoords(0, perimeterVertices[i - 1].x, perimeterVertices[i - 1].y);
					surface->SetVertexIndex(0, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i].x, 1.0f, perimeterVertices[i].y))->index;
					surface->SetVertexTexCoords(1, perimeterVertices[i].x, perimeterVertices[i].y);
					surface->SetVertexIndex(1, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(upperRightPoint.x, 1.0f, upperRightPoint.y))->index;
					surface->SetVertexTexCoords(2, upperRightPoint.x, upperRightPoint.y);
					surface->SetVertexIndex(2, vertexIndex);
					surfaceIndex++; // advance so that next logical surface starts with the correct surface
					surface++; // advance the surface being used
				}
				Vector2d lowerLeftPoint = perimeterVertices[upperLeftVertexIndex + 1];
				// loop 2 along right and top
				for (int i = 1; i < upperLeftVertexIndex; i++)
				{
					// next point + lower left point + current point
					surface->Initialize(3, true);
					surface->SetTexture0(diffuseTexture);
					surface->SetBumpMapTexture(bumpMapTexture);
					surface->SetSpecularMapTexture0(specularTexture);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i + 1].x, 1.0f, perimeterVertices[i + 1].y))->index;
					surface->SetVertexTexCoords(0, perimeterVertices[i + 1].x, perimeterVertices[i + 1].y);
					surface->SetVertexIndex(0, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(lowerLeftPoint.x, 1.0f, lowerLeftPoint.y))->index;
					surface->SetVertexTexCoords(1, lowerLeftPoint.x, lowerLeftPoint.y);
					surface->SetVertexIndex(1, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i].x, 1.0f, perimeterVertices[i].y))->index;
					surface->SetVertexTexCoords(2, perimeterVertices[i].x, perimeterVertices[i].y);
					surface->SetVertexIndex(2, vertexIndex);
					surfaceIndex++; // advance so that next logical surface starts with the correct surface
					surface++; // advance the surface being used
				}
				logicalSurfaceIndex++;

				// floor
				if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
				{
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(floorCeilingSurfaceQty, mirrorColor);
					surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
					diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

					// create floor portal at height 0.0f
					// startH,startV;stopH+1,stopV;stopH+1,stopV+1;startH,stopV+1
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(currentNodeData->cellRange.startV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.startV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(currentNodeData->cellRange.stopV + 1));
					mirrorIndex++;
				}
				else
				{
					surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
					diffuseTexture = randomDungeonMakePortalIteration->floorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->floorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->floorSpecularTextureRef;
				}
				// triangle 0 (perimeterVertexQty-1, 1, corner), set upper right point
				surface->Initialize(3, true);
				surface->SetTexture0(diffuseTexture);
				surface->SetBumpMapTexture(bumpMapTexture);
				surface->SetSpecularMapTexture0(specularTexture);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[perimeterVertexQty - 1].x, 0.0f, perimeterVertices[perimeterVertexQty - 1].y))->index;
				surface->SetVertexTexCoords(0, perimeterVertices[perimeterVertexQty - 1].x, perimeterVertices[perimeterVertexQty - 1].y);
				surface->SetVertexIndex(0, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[1].x, 0.0f, perimeterVertices[1].y))->index;
				surface->SetVertexTexCoords(1, perimeterVertices[1].x, perimeterVertices[1].y);
				surface->SetVertexIndex(1, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[0].x, 0.0f, perimeterVertices[0].y))->index;
				surface->SetVertexTexCoords(2, perimeterVertices[0].x, perimeterVertices[0].y);
				surface->SetVertexIndex(2, vertexIndex);
				surfaceIndex++; // advance so that next logical surface starts with the correct surface
				surface++; // advance the surface being used
				upperRightPoint = perimeterVertices[1];
				// loop 1 along bottom and left
				for (int i = perimeterVertexQty - 1; i > upperLeftVertexIndex + 1; i--)
				{
					// current point + next point + upper right point
					surface->Initialize(3, true);
					surface->SetTexture0(diffuseTexture);
					surface->SetBumpMapTexture(bumpMapTexture);
					surface->SetSpecularMapTexture0(specularTexture);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i].x, 0.0f, perimeterVertices[i].y))->index;
					surface->SetVertexTexCoords(0, perimeterVertices[i].x, perimeterVertices[i].y);
					surface->SetVertexIndex(0, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i - 1].x, 0.0f, perimeterVertices[i - 1].y))->index;
					surface->SetVertexTexCoords(1, perimeterVertices[i - 1].x, perimeterVertices[i - 1].y);
					surface->SetVertexIndex(1, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(upperRightPoint.x, 0.0f, upperRightPoint.y))->index;
					surface->SetVertexTexCoords(2, upperRightPoint.x, upperRightPoint.y);
					surface->SetVertexIndex(2, vertexIndex);
					surfaceIndex++; // advance so that next logical surface starts with the correct surface
					surface++; // advance the surface being used
				}
				lowerLeftPoint = perimeterVertices[upperLeftVertexIndex + 1];
				// loop 2 along right and top
				for (int i = 1; i < upperLeftVertexIndex; i++)
				{
					// next point + current point + lower left point
					surface->Initialize(3, true);
					surface->SetTexture0(diffuseTexture);
					surface->SetBumpMapTexture(bumpMapTexture);
					surface->SetSpecularMapTexture0(specularTexture);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i + 1].x, 0.0f, perimeterVertices[i + 1].y))->index;
					surface->SetVertexTexCoords(0, perimeterVertices[i + 1].x, perimeterVertices[i + 1].y);
					surface->SetVertexIndex(0, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(perimeterVertices[i].x, 0.0f, perimeterVertices[i].y))->index;
					surface->SetVertexTexCoords(1, perimeterVertices[i].x, perimeterVertices[i].y);
					surface->SetVertexIndex(1, vertexIndex);
					vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(lowerLeftPoint.x, 0.0f, lowerLeftPoint.y))->index;
					surface->SetVertexTexCoords(2, lowerLeftPoint.x, lowerLeftPoint.y);
					surface->SetVertexIndex(2, vertexIndex);
					surfaceIndex++; // advance so that next logical surface starts with the correct surface
					surface++; // advance the surface being used
				}
				logicalSurfaceIndex++;
			} // ceiling and floor

			int subStartH, subStartV;

			int count = 0;
			// go along top and count contiguous rock cells one cell up
			count = 0;
			for (int h = currentNodeData->cellRange.startH; h <= currentNodeData->cellRange.stopH; h++)
			{
				if (dungeon->GetCell(h, currentNodeData->cellRange.startV - 1)->rock == true)
				{
					count++;
					if (pass == 2 && count == 1)
						subStartH = h;
				}
				else
				{
					if (pass == 1)
					{
						if (count > 0)
						{
							count = 0;
							surfaceQty++;
							logicalSurfaceQty++; // count logical surfaces
						}
					}
					else
					{
						if (count > 0)
						{
							count = 0;

							if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
							{
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(1, mirrorColor);
								surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
								diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

								// make a wall section portal
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.startV));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(h - 1 + 1), 1.0f, float(currentNodeData->cellRange.startV));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(h - 1 + 1), 0.0f, float(currentNodeData->cellRange.startV));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.startV));
								mirrorIndex++;
							}
							else
							{
								surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
								diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
							}

							// make a surface!
							// wall on top facing down
							surface->Initialize(4, true);
							surface->SetTexture0(diffuseTexture);
							surface->SetBumpMapTexture(bumpMapTexture);
							surface->SetSpecularMapTexture0(specularTexture);
							int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.startV)))->index;
							surface->SetVertexTexCoords(0, float(subStartH), 1.0f);
							surface->SetVertexIndex(0, vertexIndex);
							// use prior cell
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(h - 1 + 1), 1.0f, float(currentNodeData->cellRange.startV)))->index;
							surface->SetVertexTexCoords(1, float(h - 1 + 1), 1.0f);
							surface->SetVertexIndex(1, vertexIndex);
							// use prior cell
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(h - 1 + 1), 0.0f, float(currentNodeData->cellRange.startV)))->index;
							surface->SetVertexTexCoords(2, float(h - 1 + 1), 0.0f);
							surface->SetVertexIndex(2, vertexIndex);
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.startV)))->index;
							surface->SetVertexTexCoords(3, float(subStartH), 0.0f);
							surface->SetVertexIndex(3, vertexIndex);
							surfaceIndex++;
							logicalSurfaceIndex++;
						}
					}
				}
			}
			if (pass == 1 && count > 0)
			{
				surfaceQty++;
				logicalSurfaceQty++; // count logical surfaces
			}
			else if (pass == 2 && count > 0)
			{
				if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
				{
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(1, mirrorColor);
					surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
					diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

					// make a wall section portal
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.startV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.startV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.startV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.startV));
					mirrorIndex++;
				}
				else
				{
					surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
					diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
				}

				// make final surface
				// wall on top facing down
				surface->Initialize(4, true);
				surface->SetTexture0(diffuseTexture);
				surface->SetBumpMapTexture(bumpMapTexture);
				surface->SetSpecularMapTexture0(specularTexture);
				int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.startV)))->index;
				surface->SetVertexTexCoords(0, float(subStartH), 1.0f);
				surface->SetVertexIndex(0, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.startV)))->index;
				surface->SetVertexTexCoords(1, float(currentNodeData->cellRange.stopH + 1), 1.0f);
				surface->SetVertexIndex(1, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.startV)))->index;
				surface->SetVertexTexCoords(2, float(currentNodeData->cellRange.stopH + 1), 0.0f);
				surface->SetVertexIndex(2, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.startV)))->index;
				surface->SetVertexTexCoords(3, float(subStartH), 0.0f);
				surface->SetVertexIndex(3, vertexIndex);
				surfaceIndex++;
				logicalSurfaceIndex++;
			}
			// go along right and count contiguous rock cells one cell right
			count = 0;
			for (int v = currentNodeData->cellRange.startV; v <= currentNodeData->cellRange.stopV; v++)
			{
				if (dungeon->GetCell(currentNodeData->cellRange.stopH + 1, v)->rock == true)
				{
					count++;
					if (pass == 2 && count == 1)
						subStartV = v;
				}
				else
				{
					if (pass == 1)
					{
						if (count > 0)
						{
							count = 0;
							surfaceQty++;
							logicalSurfaceQty++; // count logical surfaces
						}
					}
					else
					{
						if (count > 0)
						{
							count = 0;

							if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
							{
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(1, mirrorColor);
								surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
								diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

								// make a wall section portal
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(subStartV));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(v - 1 + 1));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(v - 1 + 1));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(subStartV));
								mirrorIndex++;
							}
							else
							{
								surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
								diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
							}

							// make a surface!
							// wall on right facing left
							surface->Initialize(4, true);
							surface->SetTexture0(diffuseTexture);
							surface->SetBumpMapTexture(bumpMapTexture);
							surface->SetSpecularMapTexture0(specularTexture);
							int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(subStartV)))->index;
							surface->SetVertexTexCoords(0, float(subStartV), 1.0f);
							surface->SetVertexIndex(0, vertexIndex);
							// use prior cell
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(v - 1 + 1)))->index;
							surface->SetVertexTexCoords(1, float(v - 1 + 1), 1.0f);
							surface->SetVertexIndex(1, vertexIndex);
							// use prior cell
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(v - 1 + 1)))->index;
							surface->SetVertexTexCoords(2, float(v - 1 + 1), 0.0f);
							surface->SetVertexIndex(2, vertexIndex);
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(subStartV)))->index;
							surface->SetVertexTexCoords(3, float(subStartV), 0.0f);
							surface->SetVertexIndex(3, vertexIndex);
							surfaceIndex++;
							logicalSurfaceIndex++;
						}
					}
				}
			}
			if (pass == 1 && count > 0)
			{
				surfaceQty++;
				logicalSurfaceQty++; // count logical surfaces
			}
			else if (pass == 2 && count > 0)
			{
				count = 0;

				if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
				{
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(1, mirrorColor);
					surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
					diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

					// make a wall section portal
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(subStartV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(subStartV));
					mirrorIndex++;
				}
				else
				{
					surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
					diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
				}

				// make a surface!
				// wall on right facing left
				surface->Initialize(4, true);
				surface->SetTexture0(diffuseTexture);
				surface->SetBumpMapTexture(bumpMapTexture);
				surface->SetSpecularMapTexture0(specularTexture);
				int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(subStartV)))->index;
				surface->SetVertexTexCoords(0, float(subStartV), 1.0f);
				surface->SetVertexIndex(0, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(1, float(currentNodeData->cellRange.stopV + 1), 1.0f);
				surface->SetVertexIndex(1, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(2, float(currentNodeData->cellRange.stopV + 1), 0.0f);
				surface->SetVertexIndex(2, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(subStartV)))->index;
				surface->SetVertexTexCoords(3, float(subStartV), 0.0f);
				surface->SetVertexIndex(3, vertexIndex);
				surfaceIndex++;
				logicalSurfaceIndex++;
			}
			// go along left and count contiguous rock cells one cell left
			count = 0;
			for (int v = currentNodeData->cellRange.startV; v <= currentNodeData->cellRange.stopV; v++)
			{
				if (dungeon->GetCell(currentNodeData->cellRange.startH - 1, v)->rock == true)
				{
					count++;
					if (pass == 2 && count == 1)
						subStartV = v;
				}
				else
				{
					if (pass == 1)
					{
						if (count > 0)
						{
							count = 0;
							surfaceQty++;
							logicalSurfaceQty++; // count logical surfaces
						}
					}
					else
					{
						if (count > 0)
						{
							count = 0;

							if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
							{
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].Initialize(1, mirrorColor);
								surface = portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].GetSurface(0);
								diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

								// make a wall section portal
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(v - 1 + 1));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(subStartV));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(subStartV));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(v - 1 + 1));
								mirrorIndex++;
							}
							else
							{
								surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
								diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
							}

							// make a surface!
							// wall on left facing right
							surface->Initialize(4, true);
							surface->SetTexture0(diffuseTexture);
							surface->SetBumpMapTexture(bumpMapTexture);
							surface->SetSpecularMapTexture0(specularTexture);
							// use prior cell
							int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(v - 1 + 1)))->index;
							surface->SetVertexTexCoords(0, float(subStartV), 1.0f);
							surface->SetVertexIndex(0, vertexIndex);
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(subStartV)))->index;
							surface->SetVertexTexCoords(1, float(v - 1 + 1), 1.0f);
							surface->SetVertexIndex(1, vertexIndex);
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(subStartV)))->index;
							surface->SetVertexTexCoords(2, float(v - 1 + 1), 0.0f);
							surface->SetVertexIndex(2, vertexIndex);
							// use prior cell
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(v - 1 + 1)))->index;
							surface->SetVertexTexCoords(3, float(subStartV), 0.0f);
							surface->SetVertexIndex(3, vertexIndex);
							surfaceIndex++;
							logicalSurfaceIndex++;
						}
					}
				}
			}
			if (pass == 1 && count > 0)
			{
				surfaceQty++;
				logicalSurfaceQty++; // count logical surfaces
			}
			else if (pass == 2 && count > 0)
			{
				if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
				{
					portalMap->nodes[currentNodeData->index].mirrors[0].Initialize(1, mirrorColor);
					surface = portalMap->nodes[currentNodeData->index].mirrors[0].GetSurface(0);
					diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

					// make a wall section portal
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(subStartV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(subStartV));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(currentNodeData->cellRange.stopV + 1));
					mirrorIndex++;
				}
				else
				{
					surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
					diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
				}

				// make final surface!
				// wall on left facing right
				surface->Initialize(4, true);
				surface->SetTexture0(diffuseTexture);
				surface->SetBumpMapTexture(bumpMapTexture);
				surface->SetSpecularMapTexture0(specularTexture);
				int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(0, float(subStartV), 1.0f);
				surface->SetVertexIndex(0, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 1.0f, float(subStartV)))->index;
				surface->SetVertexTexCoords(1, float(currentNodeData->cellRange.stopV + 1), 1.0f);
				surface->SetVertexIndex(1, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(subStartV)))->index;
				surface->SetVertexTexCoords(2, float(currentNodeData->cellRange.stopV + 1), 0.0f);
				surface->SetVertexIndex(2, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.startH), 0.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(3, float(subStartV), 0.0f);
				surface->SetVertexIndex(3, vertexIndex);
				surfaceIndex++;
				logicalSurfaceIndex++;
			}
			// go along bottom and count contiguous rock cells one cell down
			count = 0;
			for (int h = currentNodeData->cellRange.startH; h <= currentNodeData->cellRange.stopH; h++)
			{
				if (dungeon->GetCell(h, currentNodeData->cellRange.stopV + 1)->rock == true)
				{
					count++;
					if (pass == 2 && count == 1)
						subStartH = h;
				}
				else
				{
					if (pass == 1)
					{
						if (count > 0)
						{
							count = 0;
							surfaceQty++;
							logicalSurfaceQty++; // count logical surfaces
						}
					}
					else
					{
						if (count > 0)
						{
							count = 0;

							if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
							{
								portalMap->nodes[currentNodeData->index].mirrors[0].Initialize(1, mirrorColor);
								surface = portalMap->nodes[currentNodeData->index].mirrors[0].GetSurface(0);
								diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

								// make a wall section portal
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(h - 1 + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.stopV + 1));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.stopV + 1));
								portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(h - 1 + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1));
								mirrorIndex++;
							}
							else
							{
								surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
								diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
								bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
								specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
							}

							// make a surface!
							// wall on bottom facing up
							surface->Initialize(4, true);
							surface->SetTexture0(diffuseTexture);
							surface->SetBumpMapTexture(bumpMapTexture);
							surface->SetSpecularMapTexture0(specularTexture);
							// use prior cell
							int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(h - 1 + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
							surface->SetVertexTexCoords(0, float(subStartH), 1.0f);
							surface->SetVertexIndex(0, vertexIndex);
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
							surface->SetVertexTexCoords(1, float(h - 1 + 1), 1.0f);
							surface->SetVertexIndex(1, vertexIndex);
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
							surface->SetVertexTexCoords(2, float(h - 1 + 1), 0.0f);
							surface->SetVertexIndex(2, vertexIndex);
							// use prior cell
							vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(h - 1 + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
							surface->SetVertexTexCoords(3, float(subStartH), 0.0f);
							surface->SetVertexIndex(3, vertexIndex);
							surfaceIndex++;
							logicalSurfaceIndex++;
						}
					}
				}
			}
			if (pass == 1 && count > 0)
			{
				surfaceQty++;
				logicalSurfaceQty++; // count logical surfaces
			}
			else if (pass == 2 && count > 0)
			{
				if (mirrorLogicalSurfaceIndex == logicalSurfaceIndex)
				{
					portalMap->nodes[currentNodeData->index].mirrors[0].Initialize(1, mirrorColor);
					surface = portalMap->nodes[currentNodeData->index].mirrors[0].GetSurface(0);
					diffuseTexture = randomDungeonMakePortalIteration->mirrorTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->mirrorBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->mirrorSpecularTextureRef;

					// make a wall section portal
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.Initialize(4);
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[0] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[1] = Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[2] = Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.stopV + 1));
					portalMap->nodes[currentNodeData->index].mirrors[mirrorIndex].mirrorPortal.vertices[3] = Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1));
					mirrorIndex++;
				}
				else
				{
					surface = portalMap->nodes[currentNodeData->index].GetSurface(surfaceIndex);
					diffuseTexture = randomDungeonMakePortalIteration->wallTextureRef;
					bumpMapTexture = randomDungeonMakePortalIteration->wallBumpMapTextureRef;
					specularTexture = randomDungeonMakePortalIteration->wallSpecularTextureRef;
				}

				// make final surface!
				// wall on bottom facing up
				surface->Initialize(4, true);
				surface->SetTexture0(diffuseTexture);
				surface->SetBumpMapTexture(bumpMapTexture);
				surface->SetSpecularMapTexture0(specularTexture);
				int vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(0, float(subStartH), 1.0f);
				surface->SetVertexIndex(0, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 1.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(1, float(currentNodeData->cellRange.stopH + 1), 1.0f);
				surface->SetVertexIndex(1, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(subStartH), 0.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(2, float(currentNodeData->cellRange.stopH + 1), 0.0f);
				surface->SetVertexIndex(2, vertexIndex);
				vertexIndex = randomDungeonMakePortalIteration->vertexRegistry.AddVertex(Vector3d(float(currentNodeData->cellRange.stopH + 1), 0.0f, float(currentNodeData->cellRange.stopV + 1)))->index;
				surface->SetVertexTexCoords(3, float(subStartH), 0.0f);
				surface->SetVertexIndex(3, vertexIndex);
				surfaceIndex++;
				logicalSurfaceIndex++;
			}

			if (pass == 1)
			{
				// initialize surfaces
				if (useMirrors == true)
					mirrorQty = 1;
				portalMap->nodes[currentNodeData->index].Initialize(surfaceQty, currentNodeData->portalIndexQty, 6, mirrorQty);

				randomDungeonMakePortalIteration->surfaceQty += surfaceQty;

				// store the portal indices
				LinkedListNode<PortalNodeIndex> *portalIndexNode = currentNodeData->portalIndices.GetFirstNode();
				for (int p = 0; p < currentNodeData->portalIndexQty; p++)
				{
					portalMap->nodes[currentNodeData->index].portalIndices[p] = portalIndexNode->data.index;
					portalIndexNode = portalIndexNode->next;
				}
			}
			else if (pass == 2)
			{
				// set up containment planes
				portalMap->nodes[currentNodeData->index].GetNodePlane(0)->Set(Vector3d(float(currentNodeData->cellRange.startH), 0, float(currentNodeData->cellRange.startV)), Vector3d(1, 0, 0));
				portalMap->nodes[currentNodeData->index].GetNodePlane(1)->Set(Vector3d(float(currentNodeData->cellRange.startH), 0, float(currentNodeData->cellRange.startV)), Vector3d(0, 1, 0));
				portalMap->nodes[currentNodeData->index].GetNodePlane(2)->Set(Vector3d(float(currentNodeData->cellRange.startH), 0, float(currentNodeData->cellRange.startV)), Vector3d(0, 0, 1));
				portalMap->nodes[currentNodeData->index].GetNodePlane(3)->Set(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1, float(currentNodeData->cellRange.stopV + 1)), Vector3d(-1, 0, 0));
				portalMap->nodes[currentNodeData->index].GetNodePlane(4)->Set(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1, float(currentNodeData->cellRange.stopV + 1)), Vector3d(0, -1, 0));
				portalMap->nodes[currentNodeData->index].GetNodePlane(5)->Set(Vector3d(float(currentNodeData->cellRange.stopH + 1), 1, float(currentNodeData->cellRange.stopV + 1)), Vector3d(0, 0, -1));
			}

			pass++;
			// pass 2
			// then make the surfaces

			if (pass > 2)
			{
				// about to leave
				if (surfaceIndex != surfaceQty)
					throw gcnew System::Exception(String::Format("Surface Index != surface Qty: {0}, {1}", surfaceIndex, surfaceQty));
				if (logicalSurfaceIndex != logicalSurfaceQty)
					throw gcnew System::Exception(String::Format("Logical Surface Index != logical surface Qty: {0}, {1}", logicalSurfaceIndex, logicalSurfaceQty));
				if (useMirrors == true && mirrorIndex != mirrorQty)
					throw gcnew System::Exception(String::Format("Mirror Index != mirror Qty: {0}, {1}", mirrorIndex, mirrorQty));
			}
		}

		// mark all the cells of the node fully noded
		for (int h = currentNodeData->cellRange.startH; h <= currentNodeData->cellRange.stopH; h++)
		{
			for (int v = currentNodeData->cellRange.startV; v <= currentNodeData->cellRange.stopV; v++)
			{
				dungeon->GetCell(h, v)->noded = true;
			}
		}

		////////////////////////////
		// advance the current node
		if (randomDungeonMakePortalIteration->currentNode == randomDungeonMakePortalIteration->nodeRegistry.nodes.GetLastNode())
		{
			randomDungeonMakePortalIteration->phase = RandomDungeonMakePortalIterationPhase::Done;

			// make all the vertices
			portalMap->InitializeVertices(randomDungeonMakePortalIteration->vertexRegistry.vertexQty);
			LinkedList<DungeonVertex> *vertexList = &(randomDungeonMakePortalIteration->vertexRegistry.vertexLists[0]);
			for (int v = 0; v < randomDungeonMakePortalIteration->vertexRegistry.listsPerRow * randomDungeonMakePortalIteration->vertexRegistry.rowQty; v++)
			{
				LinkedListEnumerator<DungeonVertex> enumerator = LinkedListEnumerator<DungeonVertex>(*vertexList);
				while (enumerator.MoveNext())
				{
					portalMap->vertices[enumerator.Current()->data.index].vertex = enumerator.Current()->data.vertex;
					portalMap->vertices[enumerator.Current()->data.index].colorIndex = 0;
				}
				vertexList++;
			}

			// commit the portal map!
			portalMap->Commit();
			// enlarge all of the portals so that mid-mirror corner-corner artifacting is reduced
			portalMap->EnlargePortals(0.01f);

			// create partition
			BoundingVolume3d boundingVolume = portalMap->GetBoundingVolume();
			// set up parition with 5.0 size x and z cells and 1 main y cell
			portalPartition = new VolumePartition<LinkedList<PortalNodeIndex>>(boundingVolume.minX, boundingVolume.minY - 1.0f, boundingVolume.minZ, boundingVolume.maxX, boundingVolume.maxY + 1.0f, boundingVolume.maxZ, 5.0f, 10.0f, 5.0f);
			portalMap->PopulatePartition(*portalPartition);

			// make collider sets at node level, we'll use partitioning to quickly determine which node we need to use
			//portalMap->MakeNodeColliderSets(); // make colliders off rendering geometry
			// tailor it to make the ceiling and floor simple quads (this will have to change if there are pits, vaulted ceilings, etc.)
			// didn't even need this - I saw a frame rate drop because I was running a debug build and didn't realize it, but we'll keep it since it does speed things up and works, for now
			MakeNodeColliderSets(); // tailored collider geometry to reduce calculations against floor and ceiling

			// prep node lists
			nodeObjectLists = new RandomDungeonNodeObjectLists[portalMap->nodeQty];

			// record cell ranges for faster marking of explored
			LinkedListEnumerator<DungeonNode> nodeEnumerator = LinkedListEnumerator<DungeonNode>(randomDungeonMakePortalIteration->nodeRegistry.nodes);
			while (nodeEnumerator.MoveNext())
			{
				nodeObjectLists[nodeEnumerator.Current()->data.index].cellRange = nodeEnumerator.Current()->data.cellRange;
			}

			// lights!
			// create lights
			if (mapLights == nullptr)
			{
				mapLights = new LinkedList<RandomDungeonLight>();

				// give the player a light
				LinkedListNode<RandomDungeonLight> *newLight = MakeNewLight();
				newLight->data.SetPoint(playerOrient->p, Vector3d(1, 1, 1), 0.25, 0.125); // light torch
				//newLight->data.SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Flashlight"), playerOrient->p, playerOrient->f, playerOrient->l, playerOrient->u, 65.0f, Vector3d(1, 1, 1), 0.25, 0.125); // light torch
				//newLight->data.SetSpotlight(playerOrient->p, playerOrient->f, 65.0f, Vector3d(1, 1, 1), 0.25, 0.125); // light torch
				playerLightRef = &(newLight->data); // position will be set repeatedly in render routine

				// make a lot and place them randomly around the map, and tag them to partition cells so that we aren't parsing all of them for closeness
				bool addMapLights = placeWallLights;
				if (addMapLights == true)
				{
					FastRandom fastRandom;
					for (int n = 0; n < portalMap->nodeQty; n++)
					{
						if (fastRandom.GetRandomInteger(1, 5) > 1)
							continue;

						DungeonNode *node = randomDungeonMakePortalIteration->nodeRegistry.FindNode(n);
						// place a light
						// find a cell with a wall next to it and place the light there, start with a random face
						int face = fastRandom.GetRandomInteger(0, 3);
						float x, z;
						int h, v;
						float rotation;
						bool done = false;
						// try once on each face to find a good place to put the light, as if it's up on a wall
						float distanceFromWall = -dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce].model->GetVertex(0)->vertex.z; // matches wall sconce model definition
						for (int i = 0; i < 4; i++)
						{
							switch (face)
							{
							case 0: // left
								h = node->cellRange.startH - 1;
								v = fastRandom.GetRandomInteger(node->cellRange.startV, node->cellRange.stopV);
								x = portalMap->nodes[n].boundingVolume.minX + distanceFromWall;
								z = float(v) + 0.5f;
								rotation = -90.0f;
								break;
							case 1: // top
								h = fastRandom.GetRandomInteger(node->cellRange.startH, node->cellRange.stopH);
								v = node->cellRange.startV - 1;
								x = float(h) + 0.5f;
								z = portalMap->nodes[n].boundingVolume.minZ + distanceFromWall;
								rotation = 0.0f;
								break;
							case 2: // right
								h = node->cellRange.stopH + 1;
								v = fastRandom.GetRandomInteger(node->cellRange.startV, node->cellRange.stopV);
								x = portalMap->nodes[n].boundingVolume.maxX - distanceFromWall;
								z = float(v) + 0.5f;
								rotation = 90.0f;
								break;
							case 3: // bottom
								h = fastRandom.GetRandomInteger(node->cellRange.startH, node->cellRange.stopH);
								v = node->cellRange.stopV + 1;
								x = float(h) + 0.5f;
								z = portalMap->nodes[n].boundingVolume.maxZ - distanceFromWall;
								rotation = 180.0f;
								break;
							}
							// is the cell we want to place the torch next to rock?
							if (dungeon->GetCell(h, v)->rock == true)
								done = true;

							if (done == true)
								break;

							// cycle face
							face++;
							if (face == 4)
								face = 0;
						}
						if (done == true)
						{
							LinkedListNode<RandomDungeonLight> *newLight = MakeNewLight();
							newLight->data.flicker = placeFlames; // these flicker
							newLight->data.SetPoint(Vector3d(x, 0.8f, z), Vector3d(1.0, 1.0, 1.0), 0.25, 0.125); // light torch
							MaintainLightNodeLists(&(newLight->data));
							// prep particle usage!
							newLight->data.particleTextureRef = GameContext::TextureRegistry.GetTexture("FireParticle");
							if (placeFlames == true)
								newLight->data.SelectFlameColor();

							// make some test particles
							//newLight->data.AddParticle(Vector3d(x, 0.8f - 0.025f, z), GameColor(168, 49, 17));

							if (placeFlames == true)
							{
								// make a wall sconce!
								// node lists will be maintained later
								LinkedListNode<RandomDungeonDressing> *newDressing = dressings->GetNewNode();
								newDressing->data.type = RandomDungeonObjectTypeEnum::WallSconce;
								newDressing->data.modelRef = &(dungeonModelRegistry[RandomDungeonObjectTypeEnum::WallSconce]);
								newDressing->data.scale = 1.0f;
								newDressing->data.orient.LoadIdentity();
								newDressing->data.orient.p = Vector3d(x, 0.8f - 0.05f, z); // slightly below light
								newDressing->data.orient.Rotate(newDressing->data.orient.u, rotation);
								newDressing->data.renderRadius = 0.1f;
								dressings->AddNode(newDressing);
							}
						}
					}
				}
			}
		}
		else
		{
			randomDungeonMakePortalIteration->currentNode = randomDungeonMakePortalIteration->currentNode->next;
		}
	}
	break;
	}
}

LinkedListNode<RandomDungeonLight> * TestRandomDungeon::MakeNewLight()
{
	LinkedListNode<RandomDungeonLight> *newLight = mapLights->GetNewNode();
	newLight->data.Initialize();
	mapLights->AddNode(newLight);

	return newLight;
}

void TestRandomDungeon::MakeNodeColliderSets()
{
	// didn't even need this - I saw a frame rate drop because I was running a debug build and didn't realize it, but we'll keep it since it does speed things up and works, for now
	// tailored collider sets for the random dungeon to speed up floor and ceiling collisions
	// this will NOT work if the floors and ceilings ever take on complex geometry!!!
	LinkedList<PortalNodeIndex> vertexIndices;
	for (int n = 0; n < portalMap->nodeQty; n++)
	{
		int segmentQty = 0;
		int segmentIndex = 0;
		int surfaceQty = 0; // not all rendered surfaces will become colliders - only the vertical ones with 4 vertices since they are full walls

		// count unique vertices
		// renderable geometry
		for (int s = 0; s < portalMap->nodes[n].surfaceQty; s++)
		{
			// skip surfaces that have no vertices
			if (portalMap->nodes[n].surfaces[s].GetVertexQty() == 0)
				continue;

			// skip surfaces that aren't vertical
			if (abs(portalMap->nodes[n].surfaces[s].GetNormal().y) >= 0.0001f)
				continue;

			surfaceQty++;
			// count segments while we're here
			// and surfaces with 4 vertices with normals that are near horizontal - those will be made into colliders, along with 1 each for the floor and ceiling (determined by bounding box)
			segmentQty += portalMap->nodes[n].surfaces[s].GetVertexQty();
			for (int v = 0; v < portalMap->nodes[n].surfaces[s].GetVertexQty(); v++)
			{
				bool found = false;
				LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(vertexIndices);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.index == portalMap->nodes[n].surfaces[s].GetSurfaceVertex(v)->vertexIndex)
					{
						found = true;
						break;
					}
				}
				if (found == false)
					vertexIndices.Add(PortalNodeIndex(portalMap->nodes[n].surfaces[s].GetSurfaceVertex(v)->vertexIndex));
			}
		} // renderable surfaces
		// mirrors
		for (int m = 0; m < portalMap->nodes[n].mirrorQty; m++)
		{
			for (int s = 0; s < portalMap->nodes[n].mirrors[m].surfaceQty; s++)
			{
				// skip surfaces that have no vertices
				if (portalMap->nodes[n].mirrors[m].surfaces[s].GetVertexQty() == 0)
					continue;

				// skip surfaces that aren't vertical
				if (abs(portalMap->nodes[n].mirrors[m].surfaces[s].GetNormal().y) >= 0.0001f)
					continue;

				surfaceQty++;
				// count segments while we're here
				// and surfaces with 4 vertices with normals that are near horizontal - those will be made into colliders, along with 1 each for the floor and ceiling (determined by bounding box)
				segmentQty += portalMap->nodes[n].mirrors[m].surfaces[s].GetVertexQty();
				for (int v = 0; v < portalMap->nodes[n].mirrors[m].surfaces[s].GetVertexQty(); v++)
				{
					bool found = false;
					LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(vertexIndices);
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.index == portalMap->nodes[n].mirrors[m].surfaces[s].GetSurfaceVertex(v)->vertexIndex)
						{
							found = true;
							break;
						}
					}
					if (found == false)
						vertexIndices.Add(PortalNodeIndex(portalMap->nodes[n].mirrors[m].surfaces[s].GetSurfaceVertex(v)->vertexIndex));
				}
			}
		} // mirrors
		// set up points
		portalMap->nodes[n].colliderSet.InitializePoints(vertexIndices.Count());
		LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(vertexIndices);
		int p = 0;
		while (enumerator.MoveNext())
		{
			portalMap->nodes[n].colliderSet.points[p].position = portalMap->vertices[enumerator.Current()->data.index].vertex;
			p++;
		}

		// segments and surfaces
		surfaceQty += 2;
		segmentQty += 8; // and their segments
		portalMap->nodes[n].colliderSet.InitializeSegments(segmentQty);
		portalMap->nodes[n].colliderSet.InitializeSurfaces(surfaceQty); // 1 for each vertical quad and 1 for floor and ceiling
		int surfaceIndex = 0;
		// vertices for renderable geometry
		for (int s = 0; s < portalMap->nodes[n].surfaceQty; s++)
		{
			// skip surfaces with no vertices
			if (portalMap->nodes[n].surfaces[s].GetVertexQty() == 0)
				continue;

			// only making vertical rendered surfaces into colliders
			if (abs(portalMap->nodes[n].surfaces[s].GetNormal().y) >= 0.0001f)
				continue;

			portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetPrimaryData(portalMap->vertices[portalMap->nodes[n].GetSurface(s)->GetSurfaceVertex(0)->vertexIndex].vertex, portalMap->vertices[portalMap->nodes[n].GetSurface(s)->GetSurfaceVertex(1)->vertexIndex].vertex, portalMap->nodes[n].GetSurface(s)->GetNormal());
			portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].Initialize(portalMap->nodes[n].GetSurface(s)->GetVertexQty());

			for (int p = 0; p < portalMap->nodes[n].surfaces[s].GetVertexQty(); p++)
			{
				portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetSurfacePoint(p, portalMap->vertices[portalMap->nodes[n].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex);
				// debug
				Vector2d point = portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].surfacePoints[p];

				int nextP = p + 1;
				if (nextP == portalMap->nodes[n].surfaces[s].GetVertexQty())
					nextP = 0;
				portalMap->nodes[n].colliderSet.segments[segmentIndex].SetData(portalMap->vertices[portalMap->nodes[n].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex, portalMap->vertices[portalMap->nodes[n].GetSurface(s)->GetSurfaceVertex(nextP)->vertexIndex].vertex);
				segmentIndex++;
			}
			surfaceIndex++;
		}  // surfaces
		// vertices for mirrors
		for (int m = 0; m < portalMap->nodes[n].mirrorQty; m++)
		{
			for (int s = 0; s < portalMap->nodes[n].mirrors[m].surfaceQty; s++)
			{
				// skip surfaces with no vertices
				if (portalMap->nodes[n].mirrors[m].surfaces[s].GetVertexQty() == 0)
					continue;

				// only making vertical rendered surfaces into colliders
				if (abs(portalMap->nodes[n].mirrors[m].surfaces[s].GetNormal().y) >= 0.0001f)
					continue;

				portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetPrimaryData(portalMap->vertices[portalMap->nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(0)->vertexIndex].vertex, portalMap->vertices[portalMap->nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(1)->vertexIndex].vertex, portalMap->nodes[n].mirrors[m].GetSurface(s)->GetNormal());
				portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].Initialize(portalMap->nodes[n].mirrors[m].GetSurface(s)->GetVertexQty());

				for (int p = 0; p < portalMap->nodes[n].mirrors[m].surfaces[s].GetVertexQty(); p++)
				{
					portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetSurfacePoint(p, portalMap->vertices[portalMap->nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex);
					// debug
					Vector2d point = portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].surfacePoints[p];

					int nextP = p + 1;
					if (nextP == portalMap->nodes[n].mirrors[m].surfaces[s].GetVertexQty())
						nextP = 0;
					portalMap->nodes[n].colliderSet.segments[segmentIndex].SetData(portalMap->vertices[portalMap->nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex, portalMap->vertices[portalMap->nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(nextP)->vertexIndex].vertex);
					segmentIndex++;
				}
				surfaceIndex++;
			}  // surfaces
		} // mirrors

		// now do floor and ceiling
		Vector3d points[4];
		// floor - faster than all the triangles and segments used to perfect the artifacting
		points[0] = Vector3d(portalMap->nodes[n].boundingVolume.minX, 0.0, portalMap->nodes[n].boundingVolume.minZ);
		points[1] = Vector3d(portalMap->nodes[n].boundingVolume.maxX, 0.0, portalMap->nodes[n].boundingVolume.minZ);
		points[2] = Vector3d(portalMap->nodes[n].boundingVolume.maxX, 0.0, portalMap->nodes[n].boundingVolume.maxZ);
		points[3] = Vector3d(portalMap->nodes[n].boundingVolume.minX, 0.0, portalMap->nodes[n].boundingVolume.maxZ);
		portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetPrimaryData(points[0], points[1], Vector3d(0, 1, 0));
		portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].Initialize(4);
		for (int p = 0; p < 4; p++)
		{
			portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetSurfacePoint(p, points[p]);
			// debug
			Vector2d point = portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].surfacePoints[p];

			int nextP = p + 1;
			if (nextP == 4)
				nextP = 0;
			portalMap->nodes[n].colliderSet.segments[segmentIndex].SetData(points[p], points[nextP]);
			segmentIndex++;
		}
		surfaceIndex++;
		// ceiling - faster than all the triangles and segments used to perfect the artifacting
		points[0] = Vector3d(portalMap->nodes[n].boundingVolume.minX, 1.0, portalMap->nodes[n].boundingVolume.maxZ);
		points[1] = Vector3d(portalMap->nodes[n].boundingVolume.maxX, 1.0, portalMap->nodes[n].boundingVolume.maxZ);
		points[2] = Vector3d(portalMap->nodes[n].boundingVolume.maxX, 1.0, portalMap->nodes[n].boundingVolume.minZ);
		points[3] = Vector3d(portalMap->nodes[n].boundingVolume.minX, 1.0, portalMap->nodes[n].boundingVolume.minZ);
		portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetPrimaryData(points[0], points[1], Vector3d(0, -1, 0));
		portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].Initialize(4);
		for (int p = 0; p < 4; p++)
		{
			portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].SetSurfacePoint(p, points[p]);
			// debug
			Vector2d point = portalMap->nodes[n].colliderSet.surfaces[surfaceIndex].surfacePoints[p];

			int nextP = p + 1;
			if (nextP == 4)
				nextP = 0;
			portalMap->nodes[n].colliderSet.segments[segmentIndex].SetData(points[p], points[nextP]);
			segmentIndex++;
		}
		surfaceIndex++;

		if (segmentIndex != segmentQty)
			throw gcnew Exception(String::Format("Segment Index != segment Qty: {0}, {1}", segmentIndex, segmentQty));
		if (surfaceIndex != surfaceQty)
			throw gcnew Exception(String::Format("surface Index != surface Qty: {0}, {1}", surfaceIndex, surfaceQty));

		vertexIndices.Clear();
	}

}

////////////////////////////
// Rendering

// Theory design
//
// Gameloop refers to one occurrence of updating the gamestate and performing all rendering for that occurrence.  Once gamestate update and rendering is complete for that occurrence, a
//    new gameloop begins.
// A gameloop can be skipped with no gamestate update if the time passed is 0ms, although a render will still occur (since other elements of the application may still advance and need
//    to be reflected in the render)
// Gamestate refers to the result of a single game tick occurring before render.  All game obejcts are advanced and ready for rendering.  Not all aspects of animation are applied for
//   objects whose animations do not impact other aspects of the gamestate (such as placing the joints of a multi-jointed model in a walking animation, but the aniamtion track is updated).
//   This is because applying those additional aspects are costly for so many objects that will not even be rendered on this gametick.  But when rendering does occur, the code is written
//   to catch that the object's additional aspects need to be caught up to the gamestate and made final for the render.  So objects can move, have a world orientation, decide AI behaviors, etc.
//   but anything costly to the framerate that does not impact any other part of the gamestate is held off until the object is rendered.
// After gamestate is finalized, rendering can occur.
// Even though the gamestate update occurs once per game loop, an object can be rendered many times (shadow maps, anaglyph rendering (once for each eye), and mirror reflections).  
//   - Effects meant to appear for only one game loop should not be removed until ALL rendering for a gamestate is complete.
//   - Objects whose additional aspects need to be caught up to the current gamestate for rendering should should be caught up before the first render - this is not be repeated for additional 
//       renders of that gameloop for that object (these renders include to shadowmaps, mirror reflections, each anaglyph eye, etc.)
// The routine that renders objects viewed by a viewpoint can be called many times (once for each anaglyph eye, and mirror reflections).  The term 'render' can refer to the current occurrence
//    to one of those calls.  A 'gamestate render' is the entire collection of all render calls necessary to complete the entire scene for a gamestate.  There is one 'gamestate render' for each
//    game loop.  They are 1 to 1.
//
// Portal node rendering
// A portal engine is well suited for rendering internal environments.  It accomplishes this by separating individual nodes with 'portals' - convex polygons compared against the view frustum
//    to determine visibility, with no regard to any other node geometry.  If a portal can be seen, then the room on the other side of it can also be seen.  The portal is then intersected with
//    the view frustum, and the process continues in the next room.  If nodes occur more than once, the nodes that come before them are inserted before the duplicate node's occurrence in the
//    final list.  Mirrors work similiarly except they already reflect back into the same node they are a part of, and after the frustum is intersected with the mirror's polygon, 
//    it is reflected through the mirror, and the parse continues as normal.  Mirrors in this implementation are NOT parsed more deeply - they are simply listed as visible with their
//    reflected frustums so that they can be processed by portal parse later to render the reflections.
// Node geometry and the objects in them are rendered first, then all mirrors seen and the results of their visibility are rendered, along with the mirror's surface after the reflection is complete.
// IMPORTANT NOTE! The entirety of a node is rendered even if it is only partially visible.  The slightest sliver of a node is enough to render the entire node and all of its objects.  Further
//    optimization can be used to determine if an object or its shadows should also be rendered with the node based on the frustum seeing the node, but this can lead to complications with
//    multiple frustum splices striking the node, discussed next as a bug that can happen with mirrors.
// Mirror spliced frustum challenge: In this implementation, large rooms can be made up of multiple nodes with portals splicing the room apart.  Nodes are kept small so that lights can be selected to illuminate the room in chunks, 
//     allowing rooms to have many lights but still be lit by all participating lights (although if any lights are skipped, there will be visible anomalies).  That aside, large rooms pose a problem
//     for mirrors.  When we are rendering normal nodes, we are rendering the entire node even when it is only slightly visible.  When we render mirrors, we want to render only the amount of the mirror reflection that is
//     visible, rather than the entire mirror.  When a frustum is spliced across a large room by all the portals, one of these spliced frustums can encounter part of a mirror. Later, another
//     spliced frustum from the same main frustum can encounter another part of the same mirror.  Since it's important to parse the entire mirror with a frustum to render its reflection, we need
//     to make sure we are rendering enough of it.  So, when parsing mirrors, if we strike the same mirror a second time with a frustum splice, we must either merge the two frustums together to be
//     used to render the mirror's reflection (which can be hard because we want a convex frustum and the merge might cause concavity - for one case, imagine a mirror viewed behind a thin post surrounded by
//     portals that split the room without being connected - the two resulting frustums don't even touch each other), or just take the frustum intersection between the mirror and 
//     the main view frustum (which may still render more than we want, but it's a lot simpler than attempting a frustum merge.  It render more than desired, but is a fair compromise rather
//     than developing a frustum merge for now.  If we only use the first frustum intersection when a splice strikes a mirror, some nodes within the reflection may not render.  This causes
//     a visual bug.  Using the full frustum from the original parse intersected with the mirror solves this issue, and is only necessary if the mirror is encountered more than once during
//     a visibility parse.  If a mirror is only encountered once, the intersected frustum is good for the render.
//     Note: A frustum merge is possible by removing planes from each that would could out planes from the other, then add all the rest to a single frustum.  This also works, but the resulting
//       frustum should be intersected with the mirror just to make sure the result doesn't include to large of a view.
//     The lesson: NEVER assume a frustum will be the only one to strike a mirror during a parse!  Handle the case!  this only matters because we are using the frustum intersection later
//       to render the entire mirror space and don't want it to be too large or too small, as opposed to rendering an entire node because of a small sliver being visible in other parts of the algorithm.

// Lighting
// Supports up to 8 lights of different types (point, spotlight, spotlight with texture - directional lights will be added later) with shadowing
// When a given element is rendered, 8 lights are selected to light it.  Currently, the 8 lights closest to the center of a given portal node and can 'see' it are used to render that node 
//    and every object that overlaps it.  When a new node is selected for rendering, a new set of lights is tallied for it.  If more than 8 lights can see the node, anything farther than the 8th
//    light is skipped, which can lead to some visible artifacts like a coloration border on the floor.  But under usual circumstances, this is rare, although designing rooms with
//    a lot of lights is discouraged with this design.  Or at least make sure the lights are far enough apart and the nodes are small enough to keep the selected lights spread out and 
//    reduce the visual artifacts.
// Each light is paired with a shadowmap (until a future upgrade when lights shine through mirrors, in which case a single light can contribute in multiple ways, and
//    each contribution of a given light source will have its own shadow map
// Because lights can move during a gamestate update, and other objects can move, impacting the shadows, all shadowmaps are wiped as rendering begins for a gamestate, for simplicity.
// Shadowmaps have a single correct state for each game loop (they coincide with the updated gamestate), since they reflect how all objects are casting shadows in that gamestate.  That is,
//    they will be no different no matter where they are rendered (the real world, each anaglyph eye, or any mirror relfection). Because of this, Once a shadowmap is generated for 
//    that gamestate, it is preserved as long as possible for that entire render.  If a shadowmap is selected for a light source, and isn't locked because the light source it is bound to 
//    isn't required for the current render element, the shadowmap is reassigned to the other light source and wiped.  in this case, if the original light source is required for another render,
//    a new shadow map will have to be prepared again from scratch.  To alleviate this, allocate enough shadowmaps in the registry for lights to select from.  This increases the chance
//    that a shadowmap won't require another preparation in the same render
// Note: Currently shadowmaps can be updated later for another render within the gamestate, because that render might involve nodes not included in the original preparation (which can
//    happen when rendering the other anaglyph eye or a mirror reflection).  Later, a full parse can be done involving both anaglyph eyes and all mirror reflections to arrive at a basis
//    from which to prepare shadowmaps completely correctly on the first light pass, preventing the need to go back to update them (although if a shadowmap is re-used, it will still
//    need to be prepared again from scratch).
// The nodes and items that will be used to prepare shadowmaps are determined based on lights that can see them, objects that overlap them, and whether or not the resulting shadow of those 
//    items is determined to impact the rendered scene.  Nodes and objects outside that range are not rendered to shadowmaps in order to keep framerate up.  Nodes are the primary determiner 
//    for this prediction, since objects are drawn based on which nodes they overlap.
//
// Object rendering
// Each object is rendered only once during a single given render (shadowmap, anaglyph, mirror reflection), even though it can be encountered multiple times (objects can overlap multiple nodes, 
//    and each of those nodes might be involved in the render)
// 
// Mirrors
// Artifacting short list: Edges have artifacts when geometry is expected to exactly stop there, so move reflected viewpoitn slightly towards the mirror and put the clip plane just out from it.
//    This isn't guaranteed to stop all artifacting, but pre-rendering the mirror surface witha  color that won't show up well as an artifact dot may suffice.
//    However, this exacerbates the other artifacting problem which is mentioned below (corner-corner node artifacting, or projected view coincident portal segments).  Combat by making portals
//    slightly larger than the geometry being rendered.
// On a given scene render call, at depth 0 there is no stencil (unless it is being used for some other purpose).  if mirror depth > 0, 
//    everything in the scene will be rendered only to that stencil value
// Render mirror surface first as a simple depth polygon while all other geometry in the world is being rendered, front to back when possible, to help foster depth culling
// When using stencil, stencil must be cleared for each main scene render (each anaglyph eye) that starts with rendering mirror depth 0, but do NOT do this for mirror depth > 0, as that would destroy needed data
// Note about artifacting: Strageies below to prevent artifacting are discussed, but edge artifacting will not be a problem if the mirror does not coincide with any world geometry that requires
//   a perfect render to join up with the mirror edge in the reflection.  Mirrors floating in the middle of a room are a good example.  However, despite the edge artifacting not being a problem
//   with mirrors that float, it's still possible for mid-mirror artifacting occurring because of the viewpoint not quite being in sync with what the view frustum is calculated to see.  Portals
//   larger than the surrounding geometry will combat this.  Also, viewed polygons that happen to end exactly at the edge of the mirror at a distance also have the potential to have artifacts, 
//   but can be combatted by widening the frustum just a little to make sure all geometry within the mirror is covered.  Each case has to be looked at.  But where artifacting is not a problem,
//   no adjustment of viewpoint is necessary, although the clip plane should still probably be adjusted out from the mirror just tad to prevent overzealous clipping in the mirror, preventing a
//   render of close or intersecting geometry.
// Save mirrors for after world geometry is rendered:
// - a) Render the solid scene geometry (including the mirror surfaces with depth rendered simply)
// - when prepping shadow maps, make sure the geometry is rendered with NORMAL polygon culling (it can flip, see below), since the 'viewpoints' for the shadowmap renders are the lights, 
//      which aren't reflected (that is, flip it when mirror depth is odd, and flip it back afterwards)
// - For each mirror involved in the scene:
// - Stencil the mirror surface with current mirror depth + 1 by writing to the current stencil, obeying depth <= (mirror depth 0 looks for stencil 0, which works) and increment it
// - Clear its area to max depth (obey stencil) so that the mirror scene can be rendered
// - Set a single clip plane (we only need one for this, ever) to prevent geometry 'behind' the mirror from appearing in the reflection.  
//      Note: Even if you have no geometry that intersects a mirror directly, objects around the corner from a mirror could still show up in its reflection without a clip plane.  So a clip plane IS required.
//      Adjust position slightly along the normal for potential artifacting  (i.e. mirror reflection scene geometry stops exactly at mirror's edge)
//     This may not be necessary if all your mirrors are perfectly along an orthogonal axis (the reflection only affects one coordinate) (not a guarantee, artifacts can still happen), 
//     but may likely be needed if any are at any sort of angle and perfectly intersect world geometry.  Unfortunately, whatever adjustment you provide
//     may help the mirrors at an angle but harm the ones that are perfectly along an orthogonal axis.  Code accordingly where possible and test for artifacting.  
//     Extra geometry that hides mirror edges makes this a non issue.  Code in a way that keeps artifacting to a minimum, including rendering an initial mirror color  that is less visible so that
//     artifacting is less noticable depending on the scene.
// - Flip polygon direction culling since polygons will now be drawn in reverse
// - Set to obey the stencil value with no writing to it
// - Reflect the viewpoint through the mirror plane.  Adjust position slightly along the forward vector for potentional artifacting (i.e. mirror reflection scene geometry stops exactly at mirror's edge).
//     This may not be necessary if all your mirrors are perfectly along an orthogonal axis (the reflection only affects one coordinate) (not a guarantee, artifacts can still happen), 
//     but may likely be needed if any are at any sort of angle and perfectly intersect world geometry.  Unfortunately, whatever adjustment you provide
//     may help the mirrors at an angle but harm the ones that are perfectly along an orthogonal axis.  Code accordingly where possible and test for artifacting.  
//     Extra geometry that hides mirror edges makes this a non issue. Code in a way that keeps artifacting to a minimum, including rendering an initial mirror color  that is less visible so that
//     artifacting is less noticable depending on the scene.
// - Prepare any additional data that will help guide the reflection render (such as a reflected view frustum for portal parsing, etc.)
// - >>> Recursively call the scene render with current mirror depth + 1, the reflected viewpoint, the clip plane values, and any other needed data. (starts at a) with incremenet current mirror depth)
// - Restore polygon direction culling
// - If mirror depth > 0, restore the clip plane to what it was when this render call was made, otherwise disable it
// - Render the mirror surface (you will likely need to choose light sources and pre shadows for it again, since the shadowmaps will be processed for the recursive render), 
//     decrementing the stencil value back down (do this matching the expected stencil value and decrementing it back down whether depth test passes or not, in case any geometry is poking
//     out of the mirror because of clip plane artifacts)
// - Note: Avoid going too deep with mirrors (obey a maximum).  You may need to render something solid on the mirror surface at max depth if the mirror's surface isn't opaque enough to occlude
//     the farthest mirror for composition
// - Note: This methodology does not detail portal parse strategy for handling mirrors - this discussion is just a base theory for handling them.  For portal parsing, the view frustum must see a mirror
//     for it to be rendered.  The view frustum's intersection with the mirror polygon is then reflected and provided along with the reflected viewpoint into the recursive call, so that
//     only the portion of the reflected scene that is visible is rendered.
// - Note: If the mirror surfaces have already been depth culled, the order in which mirrors at a given level are processed matters little, since depth culling can no longer contribute to assisting
//     the mirror surface itself.  However, the order in which elements of the reflection are drawn within the mirror do matter, so those elements should be drawn front to back wherever possible (which
//     is already done via how the portal parse stores seen nodes, front to back, and likewise only lists the mirror surfaces it has seen in the same order of the nodes it has seen, which is good only for
//     the initial depth culling aspect, as mentioned)
// - Note: One example where the attempt to adjust the rendering viewpoint to prevent artificating actually causes a failure: consider being backed into a corner such that you are at an exact 45 angle towards a mirror's corner.
//     Within that mirror, geometry in the distance is rendered exactly to the mirror edge on the screen, but geometry jsut past the corner is not because of a portal that is also exactly occurs
//     on the mirror's edge in the distance, but is nto seen by the frustum.  Becuase the viewpoint is now closer (and it must be in some capacity, along the mirror's normal or towards its center) 
//     for the primary artifacting problem of geometry that occurs right up to the mirror's edge), the viewpoint can 'see' the geometry in the portal, but because the frustum does not, 
//     the geometry doesn't get rendered, leaving an artifact. In this case, it's beneficial
//     to move the frustum slightly away from the mirror's center to widen its overall view so that its visibility parse can catch what the viewpoint now sees because it's closer.  We could also recalculate
//     a new frustum because of the closer viewpoint, but for now we are keeping the plane test from the original parse that saw the mirror's surface, and we are not adjusting origins in that test.
//     This is a case where artifacting can appear in the center of a mirror, because the viewpoint is 'peeking around a corner', which the frustum can't, which could be anywhere in the reflection.
//     Bear in mind all this trouble is only necessary when dealing with mirrors whose edges aren't further occluded by other geometry, like a picture frame.
//     Another very simple fix for this is to just define your portals to be a little larger than the surrounding geometry.  Nothing says the portals have to coincide with the surrounding geometry 
//        - but they must be at least the same size or larger, NOT smaller!!!  In addition, portals overlapping each other is also not a problem as long as the nodes they are defined
//        as their front and back spaces remain as they were.
//     note: moving the viewpoint towards the center of the mirror can cause the reflection to go visibly out of alignment with the real world (ie a brick pattern's grout doesn't line up), so maybe factor
//        the distance and reduce the adjustment accordingly, or only move towards the center when the entire mirror is at an extreme angle?
//     Illustration:
//           -------
//           |  a  |
//           |     |
//           |..----
//         ---..|
//
//        fv
// f = frustum position, v = viewpoint position.  .. are portals. frustum f can't see into room a because of the two corners.  v can, causing a gap in the rendering because node a isn't rendered
// mirror not displayed but isn't necessary for the clarity.

// Rendering order
// - For a given mirror depth (rendering starts at mirror depth 0 = the 'real' world):
// - Render all solids - walls and objects, lit with shadows
// - Then render each mirror individually.  Each mirror renders its entire reflection world first, then renders the mirror's surface, lit and shadowed.  This is fully recursive, calling this entire list with mirror depth + 1
//     Rendering the surface as an alpha is fine here since the mirror was already depthed and stenciled out - the only objects behidn the surfaces to be occluded are their reflections.  With the algorithm above,
//     you CANNOT save the mirror surfaces for last with the intent to render them all at the same time.  Their renders are meant to decrement the stencil, and one mirror's stencil MUST be cleared
//     before another mirror renders its reflections, otherwise their reflections could appear in each other if the clip plane allows it.  (evolving this algorithm would require using different stencil numbers
//     or unstenciling the mirror with a simple polygon and still saving the render of all the surfaces in that mirror depth for last.  rendering them all together will at least prevent program switching, which might be a very minor
//     gain.  But note that you still have to prep lights and shadows for each of mirrors' nodes before rendering the surface.)
// - Then render particles considering depth but not writing to it.  If they are occlusive particles they will need to be sorted back to front, and will need to be rendered opposite the order of all nodes rendered.  If they are additive,
//     NO order matters.  Intermixed types of particles will need to be handled appropriately.  Note that particles in reflections should be rendered flipped appropriately.  Particle sorting
//     must occur back to front according to the viewpoint's f vector as it exists int he real world for mirror depth 0 or as it was reflected in the mirror for depth >= 1! (in an application
//     where there is only one mirror, like a lake, it's possibel to have two particle lists and sort each accordingly to keep them mostly sorted from frame to frame, but that isn't possible
//     with so many mirrors here, and the particles that appear in a particular mirror could be anywhere, especially in other nodes).  To further help, the reflected frustum can be backed up a little
//     to increase its view inside the mirror so that enough nodes are rendered to fill in gaps.  Moving the frustum must be looked at more closely however:if the frustum fans out in all directions,
//     then es it sees more.  But if it has been cut to only view off to one side of forward (that is, any of its planes face more towards the direction of adjustment, then moving it backwards decreases its view.  And we need to make sure adjustments don't accumualte for each mirror depth - the
//     adjusted frustum (as long as it helps) can be used to check for visibility, but the unaltered one should be the one reflected.  A frustum should only be adjusted along a vector taht is between all
//     of the planes (will a sum then average work?)

// Portal map deep parse
// A deep parse not only returns a resulting list of nodes and 1-depth mirrors to render for the main world, but also returns lists for each mirror encountered, including those mirrors inside
//    the reflections of other mirrors.  The resulting data also holds a list of unique node indices encountered, since it is common for hundreds or thousands of nodes to be in the final scene,
//    but a vast number are repeats since the actual unique list of node indices is usually only around 30 or so.
// The unique node list is good for determining which nodes need to be rendered for light source shadowmaps.  Since the list is compelte even for mirror reflections, shadowmaps can be properly
//    prepared for the entire scene with one pass.  This removes the need to return to shadow maps to update them with more data.
// However, this methodology convolutes the data structure a bit.  Each node in the parse result list has a list of nodes to render along with mirrors encountered.  The first node always represents
//    the primary world render with 1-depth mirrors.  All nodes following that are the result of a mirror and have a reference to the mirror causing the parsed data.
// The deep parse also prevents recursive DrawElements calls from needing to call the portal parse additional times to determine node lists to render - the corresponding parse data is simply 
//    forwarded to the next DrawElements call instead.
// No matter how many times DrawElements is called recursively with parse data nodes, the same uniqueNode list is used to prep lights.
// This deep parse occurs once for each anaglyph eye to collect all primary world nodes, and mirrors their resulting nodes.
// The deep parse is only called for determining nodes and mirrors to render for the final scene.  Lights call a simpler parse that stays at the top level (until lights reflect off mirrors) and doesn't track unique nodes.

// Other
// Shadow render methdology (flat maps with a projection mvp passed to the shader, cube maps with a world location)
// Render methodology for fragments (each fragment has a world location when necessary so that lighting and shadowing calculations are easier without having to transform in the fragment shader or 
//    convert a renderspace coordinate to worldspace)

void TestRandomDungeon::PerformRender()
{
	GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

	if (particleQueue->IsInitialized() == false)
	{
		graphics->CreateParticleQueue(particleQueue, 1000);
	}

	if (useShadowMaps == true)
	{
		// since lights can move durign a game tick, might as well wipe out all the shadow maps to force re-rendering, because those lights' shadowmaps would now be incorrect
		// todo: ideally, this should only happens with the shadows of lights that moved, but the price here is usually low
		if (shadowMapRegistry->ShadowMapsCreated() == false)
			shadowMapRegistry->CreateShadowMaps(graphics);
		shadowMapRegistry->ClearAssignments();
#ifdef _DEBUG
		// no lights should have a texture now
		if (mapLights != nullptr)
		{
			LinkedListEnumerator<RandomDungeonLight> lightEnumerator = LinkedListEnumerator<RandomDungeonLight>(*mapLights);
			while (lightEnumerator.MoveNext())
			{
				if (lightEnumerator.Current()->data.shadowMapFrameBufferRef != nullptr)
					throw gcnew Exception("Light shadow map not cleared!");
			}
		}
#endif _DEBUG
	}

	if (ballNativeObject == nullptr)
		ballNativeObject = new GraphicsNativeObjectContainer();
	if (ballNativeObject->nativeObjectRef == nullptr)
		ball->CreateNativeObject(graphics, ballNativeObject, true);

	if (triguyNativeObject == nullptr)
		triguyNativeObject = new GraphicsNativeObjectContainer();
	if (triguyNativeObject->nativeObjectRef == nullptr)
		triguy->CreateNativeObject(graphics, triguyNativeObject, true);
	if (triguyRedEyesNativeObject == nullptr)
		triguyRedEyesNativeObject = new GraphicsNativeObjectContainer();
	if (triguyRedEyesNativeObject->nativeObjectRef == nullptr)
		triguyRedEyes->CreateNativeObject(graphics, triguyRedEyesNativeObject, true);

	graphics->MakeCurrent();
	graphics->ClearScreen(GameColor(0, 128, 128));
	if (renderHiddenCreatures == true || useMirrors == true) // useMirrors here for clarity
		graphics->ClearStencil();

	int nodesParsedForFirstNode = 0;
	int nodesRenderedQty = 0;
	int lightNodesRenderedQty = 0;
	int lightNodesRerenderedQty = 0;
	int frameBufferChangesQty = 0;
	int totalLightsRenderedQty = 0;
	int lightsSkipped = 0;
	int lightNodesRejected = 0;
	// todo: render map with player indicator later
	if (randomDungeonMakePortalIteration->phase != RandomDungeonMakePortalIterationPhase::Done)
		RenderRandomDungeon(graphics, GameColor(64, 64, 64), GameColor(192, 192, 192), GameColor(64, 64, 64), false);
	else
	{
		RenderDungeon(graphics, nodesParsedForFirstNode, nodesRenderedQty, lightNodesRenderedQty, lightNodesRerenderedQty, frameBufferChangesQty, totalLightsRenderedQty, lightsSkipped, lightNodesRejected);
		if (showExploredMap == true)
			RenderRandomDungeon(graphics, GameColor(64, 64, 64), GameColor(192, 192, 192), GameColor(64, 64, 64), true);
	}

	if (showInformation == true)
		RenderInfo(graphics, nodesParsedForFirstNode, nodesRenderedQty, lightNodesRenderedQty, lightNodesRerenderedQty, frameBufferChangesQty, totalLightsRenderedQty, lightsSkipped, lightNodesRejected);
	if (showInstructions == true && randomDungeonMakePortalIteration->phase == RandomDungeonMakePortalIterationPhase::Done)
		ShowInstructions(graphics);

	graphics->FinishRender();
	graphics->SwapBuffers();

	// reset timer now for new poll
	timer->ResetElapsedTime();
}

void TestRandomDungeon::RenderRandomDungeon(GraphicsBase *p_graphics, GameColor &p_rockColor, GameColor &p_clearColor, GameColor &p_borderRoom, bool p_showObjectsAndPlayer)
{
	p_graphics->Set2dWindowProjection();
	p_graphics->SetDepthTestEnabled(false);
	p_graphics->SetDepthWriteEnabled(false);

	// draw the full gray box for the rocks and skip them during the render (speeds up the render)
	System::Drawing::RectangleF rect(dungeon->GetCell(0, 0)->rect.Left, dungeon->GetCell(0, 0)->rect.Top, dungeon->GetCell(dungeon->cellWidth - 1, dungeon->cellHeight - 1)->rect.Right - dungeon->GetCell(0, 0)->rect.Left, dungeon->GetCell(dungeon->cellWidth - 1, dungeon->cellHeight - 1)->rect.Bottom - dungeon->GetCell(0, 0)->rect.Top);
	p_graphics->RenderFilledRectangle(rect, p_rockColor);

	for (int v = 0; v < dungeon->cellHeight; v++)
	{
		DungeonCell *cell = dungeon->GetCell(0, v);
		for (int h = 0; h < dungeon->cellWidth; h++)
		{
			if (cell->rock == true)
			{
				cell++;
				continue;
			}

			System::Drawing::RectangleF rect = cell->rect;
			if (cell->rock == true)
			{
				// old code, not used
				if (cell->bordersRoom == false)
					p_graphics->RenderFilledRectangle(rect, p_rockColor);
				else
					p_graphics->RenderFilledRectangle(rect, p_borderRoom);
			}
			else if (cell->explored == true)
			{
				p_graphics->RenderFilledRectangle(rect, GameColor(128, 128, 128));
			}
			else
			{
				if (cell->hallwayGroup == -1 && cell->hallwayRegion == -1 && cell->nodeId == -1)
				{
					// unnoded unpainted room
					p_graphics->RenderFilledRectangle(rect, GameColor(0, 128, 128));
				}
				else
					if (cell->hallwayRegion != -1)
					{
						if (cell->hallwayRegion == 0) // the master
						{
							p_graphics->RenderFilledRectangle(rect, GameColor(255, 255, 255));
						}
						else
							switch (cell->hallwayRegion % 8)
						{
							case 0:
								p_graphics->RenderFilledRectangle(rect, p_clearColor);
								break;
							case 1:
								p_graphics->RenderFilledRectangle(rect, GameColor(255, 128, 128));
								break;
							case 2:
								p_graphics->RenderFilledRectangle(rect, GameColor(128, 255, 128));
								break;
							case 3:
								p_graphics->RenderFilledRectangle(rect, GameColor(128, 128, 255));
								break;
							case 4:
								p_graphics->RenderFilledRectangle(rect, GameColor(255, 255, 128));
								break;
							case 5:
								p_graphics->RenderFilledRectangle(rect, GameColor(255, 128, 255));
								break;
							case 6:
								p_graphics->RenderFilledRectangle(rect, GameColor(128, 255, 255));
								break;
							case 7:
								p_graphics->RenderFilledRectangle(rect, GameColor(128, 128, 128));
								break;
						}

					}
					else if (cell->nodeId == -1)
					{
						switch (cell->hallwayGroup % 8)
						{
						case 0:
							p_graphics->RenderFilledRectangle(rect, p_clearColor);
							break;
						case 1:
							p_graphics->RenderFilledRectangle(rect, GameColor(255, 128, 128));
							break;
						case 2:
							p_graphics->RenderFilledRectangle(rect, GameColor(128, 255, 128));
							break;
						case 3:
							p_graphics->RenderFilledRectangle(rect, GameColor(128, 128, 255));
							break;
						case 4:
							p_graphics->RenderFilledRectangle(rect, GameColor(255, 255, 128));
							break;
						case 5:
							p_graphics->RenderFilledRectangle(rect, GameColor(255, 128, 255));
							break;
						case 6:
							p_graphics->RenderFilledRectangle(rect, GameColor(128, 255, 255));
							break;
						case 7:
							p_graphics->RenderFilledRectangle(rect, GameColor(128, 128, 128));
							break;

						}
					}
					else if (cell->noded == false)
					{
						// node prepped
						p_graphics->RenderFilledRectangle(rect, GameColor(0, 0, 128));
					}
					else
					{
						// noded
						p_graphics->RenderFilledRectangle(rect, GameColor(0, 128, 0));
					}
			}

			cell++;
		} // h
	} // v

	if (p_showObjectsAndPlayer == true)
	{
		Vector2d origin(dungeon->GetCell(0, 0)->rect.Left, dungeon->GetCell(0, 0)->rect.Top);
		float cellSize = dungeon->GetCell(0, 0)->rect.Width;

		// now take the x,z coord, multiply by cellSize and add to origin to get the location to render the object
		// use cellSize as a way to scale the render (cellSize represents 10')
		//GameTexture ^object = GameContext::TextureRegistry.GetTexture("Reticle");
		Vector2d center;

		float sizeScale = 0.5f;
		LinkedListEnumerator<RandomDungeonLight> lightEnumerator = LinkedListEnumerator<RandomDungeonLight>(*mapLights);
		while (lightEnumerator.MoveNext())
		{
			center = Vector2d(lightEnumerator.Current()->data.worldPosition.x * cellSize + origin.x, lightEnumerator.Current()->data.worldPosition.z * cellSize + origin.y);
			rect = System::Drawing::RectangleF(center.x - cellSize * sizeScale / 2.0f, center.y - cellSize * sizeScale / 2.0f, cellSize * sizeScale, cellSize * sizeScale);
			p_graphics->RenderFilledRectangle(rect, GameColor(255, 255, 0));
		}

		sizeScale = 1.0f;
		LinkedListEnumerator<RandomDungeonBall> ballEnumerator = LinkedListEnumerator<RandomDungeonBall>(*balls);
		while (ballEnumerator.MoveNext())
		{
			center = Vector2d(ballEnumerator.Current()->data.orient.p.x * cellSize + origin.x, ballEnumerator.Current()->data.orient.p.z * cellSize + origin.y);
			rect = System::Drawing::RectangleF(center.x - cellSize * sizeScale / 2.0f, center.y - cellSize * sizeScale / 2.0f, cellSize * sizeScale, cellSize * sizeScale);
			p_graphics->RenderFilledRectangle(rect, GameColor(0, 192, 255));
		}

		LinkedListEnumerator<RandomDungeonCreature> creatureEnumerator = LinkedListEnumerator<RandomDungeonCreature>(*creatures);
		while (creatureEnumerator.MoveNext())
		{
			switch (creatureEnumerator.Current()->data.type)
			{
			case RandomDungeonObjectTypeEnum::Triguy:
				sizeScale = 1.0f;
				center = Vector2d(creatureEnumerator.Current()->data.orient.p.x * cellSize + origin.x, creatureEnumerator.Current()->data.orient.p.z * cellSize + origin.y);
				rect = System::Drawing::RectangleF(center.x - cellSize * sizeScale / 2.0f, center.y - cellSize * sizeScale / 2.0f, cellSize * sizeScale, cellSize * sizeScale);
				p_graphics->RenderFilledRectangle(rect, GameColor(255, 0, 0));
				break;
			case RandomDungeonObjectTypeEnum::Arbiter:
				sizeScale = 0.5f;
				center = Vector2d(creatureEnumerator.Current()->data.orient.p.x * cellSize + origin.x, creatureEnumerator.Current()->data.orient.p.z * cellSize + origin.y);
				rect = System::Drawing::RectangleF(center.x - cellSize * sizeScale / 2.0f, center.y - cellSize * sizeScale / 2.0f, cellSize * sizeScale, cellSize * sizeScale);
				p_graphics->RenderFilledRectangle(rect, GameColor(255, 255, 255));
				break;
			}
		}

		// draw player LAST!
		sizeScale = 2.5f;
		center = Vector2d(playerOrient->p.x * cellSize + origin.x, playerOrient->p.z * cellSize + origin.y);
		System::Drawing::RectangleF rect;
		rect = System::Drawing::RectangleF(center.x - cellSize * sizeScale / 2.0f, center.y - cellSize * sizeScale / 2.0f, cellSize * sizeScale, cellSize * sizeScale);
		p_graphics->RenderFilledRectangle(rect, GameColor(0, 255, 0));

	}

	p_graphics->SetDepthTestEnabled(true);
	p_graphics->SetDepthWriteEnabled(true);
}

void TestRandomDungeon::RenderInfo(GraphicsBase *p_graphics, int p_nodesParsedForFirstNode, int p_nodesRenderedQty, int p_lightNodesRenderedQty, int p_lightNodesRerenderedQty, int p_frameBufferChangesQty, int p_totalLightsRenderedQty, int p_lightsSkipped, int p_lightNodesRejected)
{
	p_graphics->Set2dWindowProjection();
	if (showInstructions == false)
	{
		p_graphics->SetDepthTestEnabled(false);
		if (randomDungeonGenerateIteration->phase != RandomDungeonGenerateIterationPhase::Done)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("Info");
			String ^message = String::Format(
				"Mirrors (M): {0}\r\nCreatures (C): {1}\r\nDressings (D): {2}\r\nFlames (F): {3}\r\nWall lights (L):{4}\r\nToggle All (A)",
				((useMirrors == true) ? "On" : "Off"),
				((placeCreatures == true) ? "On" : "Off"),
				((placeDressings == true) ? "On" : "Off"),
				((placeFlames == true) ? "On" : "Off"),
				((placeWallLights == true) ? "On" : "Off")
				);
			p_graphics->RenderTextBlock(message, font,
				10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - 10 - font->GetTextBlockSize(message).Y,
				GameColor(255, 255, 0));
		}
		else
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("Info");
			String ^message = String::Format("Rooms: {0}\r\nNodes: {1}\r\nPortals: {2}\r\nSurfaces: {3}\r\nVertices: {4}\r\nNodes Parsed To Determine First Node: {5}\r\nNodes Rendered: {6}\r\nLight Nodes Rendered for Shadows: {7}\r\nLight Nodes Re-Rendered for Shadows: {8}\r\nFrame Buffer Changes: {9}\r\nTotal Lights Rendered: {10}\r\nMax Lights: {11}\r\nLights Skipped: {12}\r\nLight Nodes Rejected: {13}{14}\r\nCollider Sets Executed: {15}\r\nBalls Rendered: {16}\r\nObject Parses To Render: {17}\r\nParses to Maintain Node Ball Lists: {18}\r\nShader count: {19}\r\nLight Aspect Check Escalated: {20}\r\nDarkvision: {21}\r\nClip planes: {22} ({23})\r\nMirror clip plane normal adjustment: {24:F5}\r\nMirror viewpoint adjustment: {25:F5}\r\nAllow Shadow maps: {26} Allow Screen rendering: {27}\r\nAllow Objects in shadows: {28} Allow Objects in rendering: {29}\r\nNodes rendered ({30}): {31}",
				randomDungeonGenerateIteration->roomQty,
				randomDungeonMakePortalIteration->nodeRegistry.nodeQty,
				randomDungeonMakePortalIteration->portalRegistry.portalQty,
				randomDungeonMakePortalIteration->surfaceQty,
				randomDungeonMakePortalIteration->vertexRegistry.vertexQty,
				p_nodesParsedForFirstNode,
				p_nodesRenderedQty,
				p_lightNodesRenderedQty,
				p_lightNodesRerenderedQty,
				p_frameBufferChangesQty,
				p_totalLightsRenderedQty,
				maxLightQty,
				p_lightsSkipped,
				p_lightNodesRejected,
				(checkLightNodeBounds == false ? " (Off)" : (checkLightNodeBoundsHeavy == true ? " (Heavy)" : " (Basic)")),
				colliderSetsExecuted,
				ballsRendered,
				objectParsesToRender,
				parsesToMaintainNodeBallLists,
				p_graphics->GetCompositionShaderQty(),
				(shaderAppSettings->escalateLightAspectCheck == true ? "On" : "Off"),
				(useDarkvision == true ? "On" : "Off"),
				(useClipPlanes == true ? "On" : "Off"),
				(useSingleClipPlane == true ? "Single" : "Multiple"),
				mirrorClipPlaneNormalAdjustment, 
				mirrorOrientAdjustment,
				(allowShadowMapRender == true ? "On " : "Off"), // space to prevent shifting
				(allowScreenRender == true ? "On " : "Off"), // space to prevent shifting
				(allowObjectsInShadowMaps == true ? "On " : "Off"), // space to prevent shifting
				(allowObjectsInRender == true ? "On " : "Off"), // space to prevent shifting
				uniqueNodeQty,
				uniqueNodeList
				);
			p_graphics->RenderTextBlock(message, font,
				10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - 10 - font->GetTextBlockSize(message).Y,
				GameColor(255, 255, 0));

#ifdef _DEBUG
			message = "DEBUG BUILD";
			p_graphics->RenderTextBlock(message, font,
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() - font->GetTextBlockSize(message).X,
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - font->GetTextBlockSize(message).Y,
				GameColor(255, 255, 0));
#endif
		}
	}
	p_graphics->SetDepthTestEnabled(true);
}

void TestRandomDungeon::ShowInstructions(GraphicsBase *p_graphics)
{
	p_graphics->Set2dWindowProjection();
	p_graphics->SetDepthTestEnabled(false);
	p_graphics->SetDepthWriteEnabled(false);

	GameFont ^font = GameContext::FontRegistry.GetFont("Info");

	String ^instructions = R"(; - toggle player mouse and move controls (hides mouse)
					W,A,S,D - move
					mouse - look
					SHIFT - toggle run
					left mouse button - launch ball (up to 200)

					L - toggle light attached to player
					Q - toggle explored map

					N - toggle lighting
					M - toggle shadowmaps
					G - cycle player light for testing (point, spotlight, spotlight texture)
					B - toggle using frontsides for nodes to generate wall shadows (front sides give more correct shadows but cause shadow acne)
					X - toggle wireframe for walls and floors
					E - toggle freeze balls
					~ - toggle slow motion
					0-8 - set maximum light quantity
					V - portal depth of final render (all, 1-6)
					C - toggle VSync on/off
					U - toggle escalation of light aspect check (faster shaders when lights are behind surfaces - when on, ignores any spotlight and shadow checking when lights are behind)
					K - toggle rendering of shadow maps (does all other processing except actually render to shadow maps)
					Y - toggle checking of light node bounds to reject nodes for shadow maps and speed up rendering
					T - toggle checking of light nodes more specifically testing against every final mode rather than the whole volume (more rejections but more parsing)
					ctrl-D - Darkvision
					ctrl-G - cycle grayscale (0, 25%, 50%, 75%, 100%)

					F - toggle full frustum
					P - toggle node partitioning
					ENTER - toggle red/blue anaglyph

					I - toggle information
					Z - toggle these instructions)";

	p_graphics->RenderTextBlock(instructions, font, 10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - font->GetTextBlockSize(instructions).Y - 10, GameColor(255, 255, 128));

	p_graphics->SetDepthTestEnabled(true);
	p_graphics->SetDepthWriteEnabled(true);
}

void TestRandomDungeon::RenderDungeon(GraphicsBase *p_graphics, int &p_nodesParsedForFirstNode, int &p_nodesRenderedQty, int &p_lightNodesRenderedQty, int &p_lightNodeRerendersQty, int &p_frameBufferChangesQty, int &p_totalLightsRendered, int &p_lightsSkipped, int &p_lightNodesRejected)
{
	// will be counted ~twice in anaglyph
	ballsRendered = 0;
	objectParsesToRender = 0;

	// if player not placed yet, do it now
	if (playerOrient->p.Equals(Vector3d(0, 0, 0)) == true)
	{
		for (int h = dungeon->cellWidth / 2; h >= 0; h--)
		{
			bool breakOut = false;
			for (int v = dungeon->cellHeight / 2; v >= 0; v--)
			{
				if (dungeon->GetCell(h, v)->rock == false)
				{
					playerOrient->p = Vector3d(float(h) + 0.5f, 0.6f, float(v) + 0.5f);
					breakOut = true;
					break;
				}
			}
			if (breakOut == true)
				break;
		}
	}

	// set up light position
	if (playerLightRef != nullptr)
	{
		if (playerLightAttached == true)
		{
			if (playerLightRef->type == GraphicsShaderCompositionLightType::Spotlight)
			{
				playerLightRef->SetPositionAndDirection(playerOrient->p, playerOrient->f);
			}
			else if (playerLightRef->type == GraphicsShaderCompositionLightType::SpotlightTexture)
			{
				playerLightRef->SetPositionAndAxes(playerOrient->p, playerOrient->f, playerOrient->l, playerOrient->u);
			}
			else if (playerLightRef->type == GraphicsShaderCompositionLightType::Point)
			{
				playerLightRef->SetPosition(playerOrient->p);
			}
			MaintainLightNodeLists(playerLightRef);
		}

		// todo: should ahve been cleared already from prior render - remove this after that is in place
		playerLightRef->nodesToRender.Clear(); // it moved, so clear its nodes
		playerLightRef->shadowMapFrameBufferRef = nullptr;
		playerLightRef->shadowMapTextureRef = nullptr;
	}

	Orient3d cameraOrient;
	cameraOrient.Set(*playerOrient);

	///////////////////////
	// set up the transform
	//float fov = 45.0f; // now a class variable
	float nearPlane = 0.01f;
	float farPlane = 1000.0f;

	// note: the nodes that lights can see and their shadow maps will NOT change for left and right eye in anaglyph, so prep a given light only once during anaglyph
	// also, only interpolate jointed models that aren't caught up ONCE
	// for clarity:
	// mainRenderId is effectively a gameStateId, and covers both eyes of anaglyph.  shadows should only be prepared once for a gameStateId when possible, since they do not change
	//   no matter which eye sees them. (although if a shadow is wiped and used for another purpose, it will need to be prepped again for a gameStateId if needed)
	//   with mirrors and anaglyph, however, shadowmaps will need to be rechecked for the extra scene renders because lights intelligently decide which nodes to prep shadows for based on the
	//   viewpoint of the current scene - anaglyph and mirror renders may require shadow nodes that weren't added in the original render.
	//   Same goes for any render side animating, like joint orients or spinning objects that aren't already handled in the game loop.  Animate an object ONLY ONCE per main render!
	// renderId is a per render scene number, so it increments twice for anaglyph (see currentRenderId in DrawElements), and once for each mirror.  It ensures no item is rendered more than once in the given render.
	// lightRenderId is a per shadow prep render and makes sure no item is rendered more than once while prepping a shadow (see PrepareLightsAndShadowsForNode).  If a shadow map is
	//   updated due to an anaglyph or mirror render, all the objects for nodes that are added will be rendered again if they have been already on that shadowmap, but each only once on that iteration.
	static int mainRenderId = 0;
	mainRenderId++;
	if (mainRenderId == -1)
		mainRenderId++;

	// todo depth of field:
	// create framebuffer with depth texture and stencil attachment
	// create pingpong framebuffer with just color buffer for postprocessing interim
	// determine if we need post processing.  If we do, establish current frame buffer, or leave nullptr for main
	// DrawElements needs to know what main draw buffer is so that it can restore things after done with lights
	// anywhere SelectCurrentBuffer() is called, call with the determined main frame buffer (or nullptr)
	// at end of drawelements, perform any necessary post processing if main buffer is not the draw buffer (including pingponging), and set current buffer back to target draw buffer
	// note: anaglyph won't need to change, although the shaders could be coded to only work with r and gb for speed increases.  not a big deal right now though
	// switch back to man view buffer at the end of this routine so that map and info/instructions can be rendered
	// if ANY postprocessing options are chosen, use postProcessing buffer
	if (fade != 0.0f || gamma != 1.0f || grayScale != 0.0f || blurRadius != 0.0f || focusByDepthRadius != 0.0f || lens != 1.0f)
	{
		// main postporocessing buffer has texture depth and stencil
		if (postProcessingFrameBuffer == nullptr)
			postProcessingFrameBuffer = new GraphicsFrameBufferContainer();
		if (postProcessingFrameBuffer->frameBuffer == nullptr)
			p_graphics->CreateFrameBuffer(postProcessingFrameBuffer, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::Texture,
			GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
			GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight(),
			1, true);
		// ping pong buffer is simple render buffer with color texture and no depth buffer
		if (postProcessingPingPongFrameBuffer == nullptr)
			postProcessingPingPongFrameBuffer = new GraphicsFrameBufferContainer();
		if (postProcessingPingPongFrameBuffer->frameBuffer == nullptr)
			p_graphics->CreateFrameBuffer(postProcessingPingPongFrameBuffer, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::None,
			GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
			GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());

		// use post processing!!!
		currentMainFramebuffer = postProcessingFrameBuffer;
	}
	else
	{
		currentMainFramebuffer = nullptr;
	}
	p_graphics->SetCurrentFrameBuffer(currentMainFramebuffer);
	if (currentMainFramebuffer != nullptr)
	{
		// we already cleared the main view - we need to clear the post processing render buffer now if we are using it
		p_graphics->ClearScreen(GameColor(0, 192, 0)); // green
		if (renderHiddenCreatures == true || useMirrors == true) // useMirrors here for clarity
			p_graphics->ClearStencil();
	}

	if (stereoScopicMode == 0)
	{
		DrawElements(p_graphics, &cameraOrient, nullptr, fov, nearPlane, farPlane, p_nodesParsedForFirstNode, p_nodesRenderedQty, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChangesQty, p_totalLightsRendered, p_lightsSkipped, p_lightNodesRejected, nullptr, false, mainRenderId, -1, 0, Vector3d(0, 0, 0), Vector3d(0, 0, 0), nullptr, nullptr, nullptr);
	}
	else if (stereoScopicMode == 1)
	{
		StereoscopicCamera stereoCamera(0.2f, 0.031f);  // 0.33 is a little too uncomfortable (22" monitor)

		// left eye
		p_graphics->ColorMask(true, false, false, true); // red
		DrawElements(p_graphics, &cameraOrient, nullptr, fov, nearPlane, farPlane, p_nodesParsedForFirstNode, p_nodesRenderedQty, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChangesQty, p_totalLightsRendered, p_lightsSkipped, p_lightNodesRejected, &stereoCamera, true, mainRenderId, -1, 0, Vector3d(0, 0, 0), Vector3d(0, 0, 0), nullptr, nullptr, nullptr);

		// DrawElements will be pointing at main view, so force it back to the postProcessing buffer again
		if (currentMainFramebuffer != nullptr)
			p_graphics->SetCurrentFrameBuffer(currentMainFramebuffer);

		// right eye
		p_graphics->ColorMask(false, true, true, true); // cyan
		p_graphics->ClearDepth();
		if (renderHiddenCreatures == true || useMirrors == true) // useMirrors here for clarity
			p_graphics->ClearStencil();
		DrawElements(p_graphics, &cameraOrient, nullptr, fov, nearPlane, farPlane, p_nodesParsedForFirstNode, p_nodesRenderedQty, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChangesQty, p_totalLightsRendered, p_lightsSkipped, p_lightNodesRejected, &stereoCamera, false, mainRenderId, -1, 0, Vector3d(0, 0, 0), Vector3d(0, 0, 0), nullptr, nullptr, nullptr);

		// restore color mask
		p_graphics->ColorMask(true, true, true, true);
	}
	else
	{
		// split screen
		StereoscopicCamera stereoCamera(4.0f / 1334.0f, 
			//-0.25f, // hard to resolve when eyes are tired (40)
			//-0.24375f, // (45)
			//-0.22875f, // (57)
			-0.225f, // (60)
			0.0f, 2.75f / 12.0f / 10.0f); // 4" iphone google cardboard
		stereoCamera.eyeSeparationLength = splitScreenEyeSeparationInches / 12.0f / 10.0f;
		stereoCamera.leftVanishingPointX = (((2.8f + splitScreenCalibrationValue / 100.0f) / 8.0f) - 0.5f) * 2.0f;

		// left eye
		DrawElements(p_graphics, &cameraOrient, nullptr, fov, nearPlane, farPlane, p_nodesParsedForFirstNode, p_nodesRenderedQty, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChangesQty, p_totalLightsRendered, p_lightsSkipped, p_lightNodesRejected, &stereoCamera, true, mainRenderId, -1, 0, Vector3d(0, 0, 0), Vector3d(0, 0, 0), nullptr, nullptr, nullptr);

		// DrawElements will be pointing at main view, so force it back to the postProcessing buffer again
		if (currentMainFramebuffer != nullptr)
			p_graphics->SetCurrentFrameBuffer(currentMainFramebuffer);

		// right eye
		DrawElements(p_graphics, &cameraOrient, nullptr, fov, nearPlane, farPlane, p_nodesParsedForFirstNode, p_nodesRenderedQty, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChangesQty, p_totalLightsRendered, p_lightsSkipped, p_lightNodesRejected, &stereoCamera, false, mainRenderId, -1, 0, Vector3d(0, 0, 0), Vector3d(0, 0, 0), nullptr, nullptr, nullptr);

		p_graphics->SetViewportSize(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
			GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());

		// Render division
		p_graphics->Set2dWindowProjection();
		ModelVertex quad[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
		GameColor white(255, 255, 255);
		float width = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth());
		float height = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());
		float centerX = width / 2.0f;
		float centerY = width / 2.0f;
		quad[0].vertex.Set(centerX - width * stereoCamera.divisionWidth / 2.0f, 0, 0);
		quad[1].vertex.Set(centerX + width * stereoCamera.divisionWidth / 2.0f, 0, 0);
		quad[2].vertex.Set(centerX + width * stereoCamera.divisionWidth / 2.0f, height, 0);
		quad[3].vertex.Set(centerX - width * stereoCamera.divisionWidth / 2.0f, height, 0);
		p_graphics->RenderFilledQuad(&white, 1, quad, 4);
	}

	// wipe out light preparations so that they are refreshed for next render (node lists, shadowmaps) - note that node lists don't necessarily have to be cleared, but a lights node list should be 
	//   cleared if a light moves, changes its type, angle limitations, or nearby portals activate or deactive, etc.  So it's simpler to just clear them all.
	// todo:

	// point back to main view for everything else if not already (map, instructions, etc.)
	// todo: This might be redundant since DrawElements needs to render the final result of postprocessing to the main render view anyway
	if (currentMainFramebuffer != nullptr)
		p_graphics->SetCurrentFrameBuffer(nullptr);
}

void TestRandomDungeon::SetMainProjection(GraphicsBase *p_graphics, Orient3d *p_viewpointOrient, float p_fov, float p_nearPlane, float p_farPlane, StereoscopicCamera *p_camera, bool p_left)
{
	if (p_camera == nullptr)
	{
		p_graphics->SetPerspectiveProjection(p_fov, p_nearPlane, p_farPlane);
		p_graphics->DefaultTransform();
	}
	else
	{
		if (p_left == true)
		{
			p_graphics->SetPerspectiveProjectionStereoscopicLeft(p_fov, p_nearPlane, p_farPlane, *p_camera);
			p_graphics->DefaultTransformStereoscopicLeft(*p_camera);
		}
		else
		{
			p_graphics->SetPerspectiveProjectionStereoscopicRight(p_fov, p_nearPlane, p_farPlane, *p_camera);
			p_graphics->DefaultTransformStereoscopicRight(*p_camera);
		}
	}
	p_graphics->ReverseTransform(*p_viewpointOrient);
}

void TestRandomDungeon::DrawElements(GraphicsBase *p_graphics, Orient3d *p_viewpointOrient, Frustum *p_defaultFrustum, float p_fov, float p_nearPlane, float p_farPlane, int &p_nodesParsedForFirstNode, int &p_nodesRenderedQty, int &p_lightNodesRenderedQty, int &p_lightNodeRerendersQty, int &p_frameBufferChanges, int &p_totalLightsRendered, int &p_lightsSkipped, int &p_lightNodesRejected, StereoscopicCamera *p_camera, bool p_left, int p_mainRenderId, int p_firstPortalNodeIndex, int p_mirrorDepth, Vector3d &p_clipPlanePosition, Vector3d &p_clipPlaneNormal, PortalParseResult *p_parseResultData, PortalParseResultList *p_resultList, BoundingVolume3d *p_finalNodeBoundingVolume)
{
	// todo:
	// ?? accept a resultsNode to use as the nodes to render

	// render a single full scene of the geometry elements (called once for each eye of anaglyph, or each mirror for which there is a reflection)

	// p_firstPortalNodeIndex is where to start the parsing of the portal map with the viewpoint frustum
	// p_mirrorDepth is how far into the mirror universe we have rendered (0 is the game world)

	// set up slow motion time elapsed
	float elapsedTimeMSf = timer->GetElapsedTimeMSFloat();
	elapsedTimeMSf = elapsedTimeMSf * slowMotionFactor;
	if (freezeBalls == true)
		elapsedTimeMSf = 0;

	GraphicsShaderOptions shaderOptions; // this call to DrawElements and all of its calls to PrepLights, SelectShadowBuffer etc. will use this instance of this structure
	Matrix4d mvp;
	shaderOptions.eyeMVPMatrixRef = &mvp;
	Orient3d worldOrient;
	worldOrient.LoadIdentity();
	//shaderOptions.modelWorldOrientRef = &worldOrient; // do this later as a matter of consistency since it changes per the object we are rendering
	GraphicsNativeObjectRenderOptionsTransformData jointTransformData; // for joitend models
	shaderOptions.transformDataRef = &jointTransformData;

	shaderOptions.lighting = useLighting;
	shaderOptions.shadowMaps = useShadowMaps;
	//GraphicsShaderLight lights[8]; // don't need this anymore - all lights are implementation side and are assigned to lightRefs in PrepareLights
	GraphicsShaderLightPtr lightRefs[8];
	for (int i = 0; i < 8; i++)
		lightRefs[i] = nullptr;
	shaderOptions.lightRefs = &(lightRefs[0]);
	//Vector3d ambientColor = Vector3d(0, 0, 0);
	shaderOptions.ambientLightRef = ambientColor; // use class variable now
	GraphicsShaderMaterial material;
	material.ambientReflectivity = Vector3d(1, 1, 1);
	material.diffuseReflectivity = Vector3d(1, 1, 1);
	shaderOptions.lightingMaterialRef = &material;
	Vector3d lightCameraPosition;
	shaderOptions.cameraPositionRef = &lightCameraPosition;
	Matrix4d lightMVPs[6]; // for point lights
	// in case lighting is being used
	// camera position
	if (p_camera == nullptr)
		lightCameraPosition = p_viewpointOrient->p;
	else
	{
		if (p_left == true)
			lightCameraPosition = p_camera->CorrectedEyePositionLeft(*p_viewpointOrient);
		else
			lightCameraPosition = p_camera->CorrectedEyePositionRight(*p_viewpointOrient);
	}

	if (p_mirrorDepth == maxMirrorDepth && maximumRenderSectionAllowed < 2)
		return;
	// end of section 1

	//////////////////////

	// get initial projection and its mvp so we can get a good view frustum and be ready for the node render after prepping shadowmaps if they are used
	SetMainProjection(p_graphics, p_viewpointOrient, p_fov, p_nearPlane, p_farPlane, p_camera, p_left);
	mvp = p_graphics->GetMVPMatrix();

	Frustum frustumMain;
	if (p_defaultFrustum == nullptr)
	{
		if (fullFrustum == true)
			p_graphics->BuildViewFrustum(*p_viewpointOrient, &frustumMain);
		else
			p_graphics->BuildViewFrustum(*p_viewpointOrient, &frustumMain, 0.5f);
		// for anaglyph, fix frustum origin
		if (stereoScopicMode != 0)
		{
			if (p_left == true)
			{
				frustumMain.origin = p_camera->CorrectedEyePositionLeft(*p_viewpointOrient);
			}
			else
			{
				frustumMain.origin = p_camera->CorrectedEyePositionRight(*p_viewpointOrient);
			}
		}
	}
	else
	{
		p_defaultFrustum->CopyTo(&frustumMain);
	}

	if (p_mirrorDepth == maxMirrorDepth && maximumRenderSectionAllowed < 3)
		return;
	// end of section 2

	int startNodeIndex = p_firstPortalNodeIndex;
	if (startNodeIndex == -1)
	{
		if (usePartition == true)
			startNodeIndex = portalMap->NodeThatPointIsInside(frustumMain.origin, *portalPartition, p_nodesParsedForFirstNode);
	}

	// if -1, nothing to render because nowhere to start
	if (startNodeIndex != -1 || usePartition == false)
	{
		// mark node explored
		static int lastStartNode = -1;
		if (lastStartNode != startNodeIndex && p_mirrorDepth == 0) // only at mirror depth 0 to prevent a lot of large map parsing (it will be fast anyway since we have a specific cell range for a node)
		{
			dungeon->MarkNodeExplored(nodeObjectLists[startNodeIndex].cellRange);
			lastStartNode = startNodeIndex;
		}

		PortalParseResultList nodesToRender;
		PortalParseResultList *resultList = p_resultList;

		// reality check
		if (p_mirrorDepth == 0)
		{
			if (p_resultList != nullptr)
				throw gcnew Exception("p_resultList should be null!");
			if (p_parseResultData != nullptr)
				throw gcnew Exception("p_parseResultData should be null!");
		}
		else
		{
			if (p_resultList == nullptr)
				throw gcnew Exception("p_resultList should not be null!");
			if (p_parseResultData == nullptr)
				throw gcnew Exception("p_parseResultData should not be null!");
		}

		if (resultList == nullptr)
		{
			resultList = &nodesToRender;
		}

		BoundingVolume3d finalNodeBoundingVolume; // prepped at mirror depth 0 passed to deeper mirror depths
		//LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(resultList->GetFirstNode()->data.nodes);
		if (p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 3)
		{
			// don't call this when we have the nodes from the deep parse already
			// also, call for deep parse with mirror depth
			if (p_parseResultData == nullptr)
			{
				if (p_mirrorDepth != 0)
					throw gcnew Exception("Portal parse should only be called at depth 0 when deep parse is being used!");

				portalMap->PopulateNodesToRender(*resultList, &frustumMain, p_nodesParsedForFirstNode, startNodeIndex, true, true, !fastPortalParse, maxMirrorDepth, 0);
				// result list gets its first node here at depth 0
				p_parseResultData = &(resultList->GetFirstNode()->data);
				uniqueNodeList = resultList->DebugNodeList(resultList->uniqueNodes);
				uniqueNodeQty = resultList->uniqueNodeQty;

				// determine full bounding volume of nodes to be rendered so that we can reject nodes for rendering to shadow maps (and make sure that what is prepped in a shadow map is prepared enough for all nodes 
				//   that will be rendered in the case a shadow map is prepped for one node with lesser requirements and reused later for another node)
				if (checkLightNodeBounds == true && checkLightNodeBoundsHeavy == false)
				{
					if (p_finalNodeBoundingVolume == nullptr)
					{
#ifdef _DEBUG
						int firstNodeIndex = resultList->GetFirstNode()->data.nodes.GetFirstNode()->data.index;
#endif
						finalNodeBoundingVolume = resultList->GetFullBoundingVolume(portalMap->nodes);
#ifdef _DEBUG
						if (firstNodeIndex != resultList->GetFirstNode()->data.nodes.GetFirstNode()->data.index)
						{
							throw gcnew Exception("GetFullBoundingVolume changed node list!!");
						}
#endif
						p_finalNodeBoundingVolume = &finalNodeBoundingVolume;
					}
				}
			}
		}
		else
		{
			// make sure p_parseResultData is meaningful even though it might be empty
			if (p_parseResultData == nullptr)
			{
				if (resultList->IsEmpty())
					resultList->GetNewNode();
				p_parseResultData = &(resultList->GetFirstNode()->data);
			}
		}
		// end of section 3

		// render Id for this render pass (increments once for each eye in anaglyph - NOT to be confused for the mainRenderId which is the gameStateRenderId and prevents shadowmaps from being prepared twice if they have been already)
		static int currentRenderId = 0;
		currentRenderId++;
		if (currentRenderId == -1)
			currentRenderId++;

		bool originalLightingEnabled = shaderOptions.lighting;
		if (p_mirrorDepth < minimumMirrorLightingDepth)
			shaderOptions.lighting = false;

		// todo: when we start working with gateways or mirrors, the final bounding volume must properly include those nodes as well so that needed nodes aren't rejected by lighting -
		//   we only want to ever prepare a correct a sufficient shadow map for each light on a render
		// reset for render
		LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(p_parseResultData->nodes);
		int currentPortalDepth = 0;
		int mirrorStencilMask = 0x7;
		int hiddenCreatureStencilValue = 8; // mirrors use stencil 0-4, so this is safe.  if maxMirrorDepth becomes 7 (or 8?), this will need to become 16, and the mirrorStencilMask will need to become 0xf
		int hiddenCreatureStencilMask = 8;
		GameColor fadeColor(138, 7, 7); // blood red
		while (enumerator.MoveNext())
		{
			// NOTE: lights have to be prepped separately for each eye in anaglyph because each eye can see a different list of nodes
			// determine lights that are candidates for this node, closest first, farthest last
			// clear node lists for any lights we have tagged to be used but are clearing now (try to reuse a light as often as possible - need an id tag to identify it)
			// once a light's nodes are prepped and rendered to shadowmaps, they don't need to be prepped again for this tick.  but to be safe, they should always be prepped from scratch
			//   for a new render since objects with shadows can move or animate during a game tick (wipe them out (nodes lists and shadowmap buffers) after done rendering, track prepped lights with a linked list)
			// todo:

			bool restoreMainProjection = false;

			if (originalLightingEnabled == true)
			{
				if (p_mirrorDepth % 2 == 1)
					// restore normal face culling since we are in a flipped presentation
					p_graphics->FlipCullFace();
				PrepareLightsAndShadowsForNode(p_graphics, resultList->uniqueNodes, &worldOrient, enumerator.Current()->data.index, p_finalNodeBoundingVolume, shaderOptions, p_lightsSkipped, p_lightNodesRejected, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChanges, p_mainRenderId, currentRenderId, restoreMainProjection, &lightMVPs[0], p_nearPlane, p_farPlane, nodeObjectLists, elapsedTimeMSf);
				if (p_mirrorDepth % 2 == 1)
					// and bring it back (although restoreMainProjection below flips it again, but this is a more logical presentation)
					p_graphics->FlipCullFace();
			}

			// render it, finally!
			// todo: restore projection, transform (including considering anaglyph)
			if (restoreMainProjection == true)
			{
				// this is all we need to do, really, since we are just using shaders
				// but if we need the old pipeline, we'll need to put the projection back
				shaderOptions.eyeMVPMatrixRef = &mvp;
				p_graphics->FlipCullFace();
				p_graphics->SetCurrentFrameBuffer(currentMainFramebuffer);
				p_frameBufferChanges++;

				// MUST restore projection values in the API graphics class so that later operations work! (like rendering the view frustum)
				SetMainProjection(p_graphics, p_viewpointOrient, p_fov, p_nearPlane, p_farPlane, p_camera, p_left);
			}

			// use darkvision
			shaderOptions.darkvision = useDarkvision;
			shaderOptions.darkvisionWorldRange = 6.0f; // 60 feet
			shaderOptions.darkvisionSourcePositionRef = &(p_viewpointOrient->p);

			// use postprocessing instead!!!
			//shaderOptions.grayScale = grayScale;
			//shaderOptions.gamma = gamma;
			//shaderOptions.fadeColorRef = &fadeColor;
			//shaderOptions.fade = fade;

			// if this is a mirror world, stencil will already be enabled
			if (renderHiddenCreatures == true && p_mirrorDepth == 0) // if not using mirrors, need to enable stencil here
			{
				p_graphics->SetStencilEnabled(true);
				p_graphics->StencilMask(hiddenCreatureStencilMask);
				// 0 for balls
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Always, 0, hiddenCreatureStencilMask);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Replace);
			}

			if (allowObjectsInRender == true)
			{
				// render the objects associated with this node BEFORE the walls - might save on depth culling
				// balls
				// todo: parse a smaller list!
				// todo: problem which this methodology is that an object with a radius suddenly appears with it passes in from a not-rendered node, so should really
				//   incorporate its radius into the decision making, and NOT render the same object twice here!
				material.specularReflectivity = Vector3d(1.0f, 1.0f, 1.0f); // good reflection
				material.shininess = 50.0f; // dispersed reflection off water
				if (p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 4)
				{
					LinkedListEnumerator<RandomDungeonBallPtr> ballEnumerator = LinkedListEnumerator<RandomDungeonBallPtr>(nodeObjectLists[enumerator.Current()->data.index].balls);
					while (ballEnumerator.MoveNext())
					{
						objectParsesToRender++;

						if (ballEnumerator.Current()->data->renderId != currentRenderId)
						{
							shaderOptions.vertexScale = ballEnumerator.Current()->data->radius;
							shaderOptions.modelWorldOrientRef = &(ballEnumerator.Current()->data->orient);
							if (allowScreenRender == true)
							{
								ballsRendered++;
								p_graphics->RenderNativeObject(ballNativeObject, shaderOptions);
							}
							ballEnumerator.Current()->data->renderId = currentRenderId; // prevent double renders
						}
					}
				}
				//end of section 4

				if (renderHiddenCreatures == true && p_mirrorDepth == 0)
				{
					// stencil value for dressings
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Always, hiddenCreatureStencilValue, hiddenCreatureStencilMask);
				}

				// render dressings
				if (p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 5)
				{
					LinkedListEnumerator<RandomDungeonDressingPtr> dressingEnumerator = LinkedListEnumerator<RandomDungeonDressingPtr>(nodeObjectLists[enumerator.Current()->data.index].dressings);
					while (dressingEnumerator.MoveNext())
					{
						objectParsesToRender++;

						// spin the Hellraiser cubes
						if (elapsedTimeMSf > 0.0f)
						{
							if (dressingEnumerator.Current()->data->animationId != p_mainRenderId && dressingEnumerator.Current()->data->type == RandomDungeonObjectTypeEnum::HellraiserCube)
							{
								dressingEnumerator.Current()->data->orient.Rotate(Vector3d(0, 1, 0), dressingEnumerator.Current()->data->rotationDegreesPerMS * elapsedTimeMSf);
								dressingEnumerator.Current()->data->animationId = p_mainRenderId;
							}
						}

						if (dressingEnumerator.Current()->data->renderId != currentRenderId)
						{
							if (allowScreenRender == true)
								dressingEnumerator.Current()->data->Render(p_graphics, shaderOptions);
							dressingEnumerator.Current()->data->renderId = currentRenderId; // prevent double renders
						}
					}
				}
				// end of section 5

				if (renderHiddenCreatures == true && p_mirrorDepth == 0)
				{
					// 0 for creatures
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Always, 0, hiddenCreatureStencilMask);
				}

				// render creatures
				//if (useBackSideOfNodesForShadows == false)
				//	p_graphics->FlipCullFace();
				if (p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 6)
				{
					LinkedListEnumerator<RandomDungeonCreaturePtr> creatureEnumerator = LinkedListEnumerator<RandomDungeonCreaturePtr>(nodeObjectLists[enumerator.Current()->data.index].creatures);
					while (creatureEnumerator.MoveNext())
					{
						objectParsesToRender++;

						if (creatureEnumerator.Current()->data->animationId != p_mainRenderId && creatureEnumerator.Current()->data->modelRef->jointedModel != nullptr)
						{
							// prep jointed model orients according to its animation!
							creatureEnumerator.Current()->data->jointedModelAnimationTracker.InterpolateOrients(creatureEnumerator.Current()->data->jointOrients);

							creatureEnumerator.Current()->data->animationId = p_mainRenderId;
						}

						if (creatureEnumerator.Current()->data->renderId != currentRenderId)
						{
							if (allowScreenRender == true)
							{
								float oldFade;
								GameColor *oldFadeColor;
								GameColor fadeColor;

								if (creatureEnumerator.Current()->data->type == RandomDungeonObjectTypeEnum::Arbiter && shaderOptions.fade != 1.0f)
								{
									float arbiterGlowFactor = 0.66f;
									oldFade = shaderOptions.fade;
									oldFadeColor = shaderOptions.fadeColorRef;
									fadeColor = creatureEnumerator.Current()->data->singleColor;
									if (oldFade == 0.0f)
										shaderOptions.fade = arbiterGlowFactor;
									else
									{
										shaderOptions.fade = arbiterGlowFactor + oldFade * (1.0f - arbiterGlowFactor);
										fadeColor = GameColor::Interpolate(fadeColor, *oldFadeColor, oldFade);
									}
									shaderOptions.fadeColorRef = &fadeColor;
								}

								creatureEnumerator.Current()->data->Render(p_graphics, shaderOptions);

								if (creatureEnumerator.Current()->data->type == RandomDungeonObjectTypeEnum::Arbiter && shaderOptions.fade != 1.0f)
								{
									shaderOptions.fade = oldFade;
									shaderOptions.fadeColorRef = oldFadeColor;
								}
							}
							creatureEnumerator.Current()->data->renderId = currentRenderId; // prevent double renders
						}
					}
				}
				// end of section 6

				// set material reference back - rendering dressings and creatures alters it
				shaderOptions.lightingMaterialRef = &material;

				// draw the triguys, don't care about double renders right now
				float triguyScale = 0.1f;
				shaderOptions.vertexScale = triguyScale;
				shaderOptions.modelWorldOrientRef = triguyOrient;
				material.specularReflectivity = Vector3d(0, 0, 0);
				material.diffuseReflectivity = Vector3d(1, 1, 1);
				material.ambientReflectivity = Vector3d(1, 1, 1);
				material.shininess = 50.0f;
				triguy->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), triguyJointOrients, *triguyOrient, triguyScale);
				//p_graphics->RenderNativeObject(triguyNativeObject, shaderOptions);

				shaderOptions.modelWorldOrientRef = triguyRedEyesOrient;
				triguy->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), triguyJointOrients, *triguyRedEyesOrient, triguyScale);
				//p_graphics->RenderNativeObject(triguyRedEyesNativeObject, shaderOptions);
			} // allow objects in final render

			// now render walls
			if (p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 7)
			{
				shaderOptions.modelWorldOrientRef = &worldOrient; // we are rendering walls right now
				shaderOptions.useHighShadowBias = 1; // since front faces were used to make their shadows, use high bias
				material.specularReflectivity = Vector3d(0.15f, 0.15f, 0.15f); // slight sheen (0.1 is almost dry, 0.2 almost glossy)
				material.shininess = 50.0f;
				shaderOptions.vertexScale = 1.0f;
				shaderOptions.singleColorRef = nullptr;
				if (useWireframe == true)
					p_graphics->SetPolygonFill(false);
				if (renderHiddenCreatures == true && p_mirrorDepth == 0)
				{
					// stencil value for walls
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Always, hiddenCreatureStencilValue, hiddenCreatureStencilMask);
				}
				if (allowScreenRender == true)
					portalMap->RenderNode(p_graphics, enumerator.Current()->data.index, shaderOptions);
				// mirrors too!  render as a silhouette just to establish depth - the mirror render later for the mirror will fill in the gaps
				shaderOptions.useHighShadowBias = 0;
				if (renderMirrorsWithNodesForDepthCulling == true)
				{
					shaderOptions.silhouetteType = GraphicsShaderSilhouetteEnumType::SolidColor;
					GameColor initialMirrorColor(255, 255, 255);
					shaderOptions.silhouetteColorRef = &initialMirrorColor;
					for (int m = 0; m < portalMap->nodes[enumerator.Current()->data.index].mirrorQty; m++)
					{
						if (allowScreenRender == true)
							portalMap->RenderMirror(p_graphics, enumerator.Current()->data.index, m, shaderOptions);
					}
					shaderOptions.silhouetteType = GraphicsShaderSilhouetteEnumType::Normal;
				}
				if (useWireframe == true)
					p_graphics->SetPolygonFill(true);
				p_nodesRenderedQty++;
				if (shaderOptions.lighting == true)
					p_totalLightsRendered += shaderOptions.lightQty;
			}
			// end of section 7

			// since this node was rendered, its particles will be rendered too.  So find those emitters and handle them
			// particles will be rendered later after all solid surfaces since they are blended, but they need to be animated here so that they are ready to be rendered in mirror reflections
			if (allowParticles == true)
			{
				LinkedListEnumerator<RandomDungeonLightPtr> nodeLightEnumerator = LinkedListEnumerator<RandomDungeonLightPtr>(nodeObjectLists[enumerator.Current()->data.index].lights);
				while (nodeLightEnumerator.MoveNext())
				{
					// flicker here just means it's a flame, also triggers random variation of the light source
					if (nodeLightEnumerator.Current()->data->flicker == true && nodeLightEnumerator.Current()->data->particlesGamestateId != p_mainRenderId)
					{
						// zDepth will be calculated later when particles are rendered.
						// this section only runs on those particles that will be rendered but haven't been caught up to the current gameStateId yet
						nodeLightEnumerator.Current()->data->AnimateParticles(elapsedTimeMSf);

						nodeLightEnumerator.Current()->data->particlesGamestateId = p_mainRenderId;
					}
				}
			}

			// break on max rendered portal depth
			currentPortalDepth++;
			if (portalDepth != -1 && currentPortalDepth >= portalDepth)
				break;

		} // main render node loop

#pragma region Process Mirrors
		if (p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 8) // mirror depth should match with deep parse (todo: exception test?)
		{
			// Mirrors!
			// todo: if we have hit max depth, just render every mirror surface as solid to prevent null rendering artifacts at the deepest mirror level
			// mirror surface is shiny
			GraphicsShaderMaterial reallyShiny;
			reallyShiny.specularReflectivity.Set(0.8f, 0.8f, 0.8f);
			reallyShiny.diffuseReflectivity.Set(1, 1, 1);
			reallyShiny.ambientReflectivity.Set(1, 1, 1);
			reallyShiny.shininess = 1000.0f;

			// render mirrors that were evaluated as visible during the portal parse!
			// if not rendering hidden creatures, stencil is still disabled here in mirrorDepth 0
			// also disable after mirrors done
			if (renderHiddenCreatures == false && p_mirrorDepth == 0)
			{
				p_graphics->SetStencilEnabled(true);

				// set the simple state for rendering to allow mirrors at depth 0 when maxMirrorDepth == 0 to render without modifying the stencil
				// (or we could have just skipped this whole step if maxMirrorDepth == 0)
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth, mirrorStencilMask); // mirrorDepth doesn't really matter here since we are incrementing what's in the stencil buffer
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->StencilMask(0x0);
			}

			GameColor white(255, 255, 255); // for simple silhouette rendering for speed
			LinkedListEnumerator<PortalMirrorAndDistance> mirrorEnumerator = LinkedListEnumerator<PortalMirrorAndDistance>(p_parseResultData->mirrors);
			while (mirrorEnumerator.MoveNext())
			{
				// reality check
				if (mirrorEnumerator.Current()->data.depth != p_mirrorDepth)
					throw gcnew Exception("Mirror depth does not equal current render depth!");
				if (mirrorEnumerator.Current()->data.parseResultRef == nullptr && p_mirrorDepth < maxMirrorDepth)
					throw gcnew Exception("Mirrors at less than max depth must have a parse result!");
				if (mirrorEnumerator.Current()->data.parseResultRef != nullptr && ((PortalParseResult *)mirrorEnumerator.Current()->data.parseResultRef)->mirror != &(mirrorEnumerator.Current()->data))
					throw gcnew Exception("Mirror's parse result doesn't reference the mirror!");

				if (p_mirrorDepth < maxMirrorDepth)
				{
					// put values back so we can render the mirror
					shaderOptions.modelWorldOrientRef = &worldOrient;
					worldOrient.LoadIdentity(); // to render the mirror
					shaderOptions.vertexScale = 1.0f;
					shaderOptions.singleColorRef = nullptr;

					// stencil the mirror's geometry (increment)
					shaderOptions.silhouetteType = GraphicsShaderSilhouetteEnumType::SolidColor; // use a simple fast render method
					shaderOptions.silhouetteColorRef = &white;
					// note: mirrors were rendered as white during the main solid object render - so they are not white because of what's here!
					p_graphics->ColorMask(false, false, false, false);
					p_graphics->StencilMask(mirrorStencilMask);
					// look for Equal, not Always, because we might be stenciling within a mirror world
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth, mirrorStencilMask); // mirrorDepth doesn't really matter here since we are incrementing what's in the stencil buffer
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Increment);
					// need <= because mirror was already rendered as a silhouette with the node to occupy the depth buffer to help with depth culling
					p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThanEqual);
					if (allowScreenRender == true)
						portalMap->RenderMirror(p_graphics, mirrorEnumerator.Current()->data.nodeIndex, mirrorEnumerator.Current()->data.mirrorIndex, shaderOptions);

					// clear the depth buffer within the mirror
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, mirrorStencilMask);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
					p_graphics->StencilMask(0x0);
					p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::GreaterThan);
					p_graphics->SetDepthRange(0.9999f, 1.0f);
					if (allowScreenRender == true)
						portalMap->RenderMirror(p_graphics, mirrorEnumerator.Current()->data.nodeIndex, mirrorEnumerator.Current()->data.mirrorIndex, shaderOptions);
					p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThan);
					p_graphics->SetDepthRange(0.0f, 1.0f);

					// set the clip plane on the mirror
					// since nothing currently intersects surfaces, we don't need clip planes on the mirrors currently.
					// (besides, it appears clip planes are implemented GLSL side and are not set up on the GL side)
					// (NO! We need it to prevent object 'behind' the mirror from showing up in the reflection!)
					Vector3d clipPlanePosition;
					Vector3d clipPlaneNormal;
					int clipPlaneId = p_mirrorDepth;
					if (useClipPlanes == true)
					{
						clipPlanePosition = portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.vertices[0] -
							portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.normal.ScalarMult(mirrorClipPlaneNormalAdjustment);
						clipPlaneNormal = portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.normal;
						if (useSingleClipPlane == true)
							clipPlaneId = 0;
						p_graphics->SetClipPlane(clipPlaneId,
							clipPlanePosition,
							clipPlaneNormal);
					}

					// reflect the viewpoint
					Orient3d mirrorWorldViewpoint = p_viewpointOrient->ReflectThroughPlane(portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.vertices[0], portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.normal);
					Vector3d mirrorNormal = portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.normal;
					// only fix viewpoint if the mirror normal isn't along an orthogonal axis (helps prevent other possible artificating along horizontal or vertical mirror edges inside reflections)
					// no. there were artifacts!  always do it!
					//if (mirrorNormal.x != 1.0f && mirrorNormal.y != 1.0f && mirrorNormal.z != 1.0f)
					// We must adjsut the viewpoint to prevent artifacts along the mirror's edge but movign the viewpoint closer.  However, this might cause additional artifacts by 
					Vector3d offsetToCenter = portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].mirrorPortal.center - mirrorWorldViewpoint.p;
					offsetToCenter.Normalize(); // don't care if it's zero length, no exception - that would just mean we are point blank with a mirror which should never be the case
					Vector3d viewpointAdjustment;
					bool allowMoveTowardsCenter = false;
					if (offsetToCenter * mirrorNormal < 0.1f || allowMoveTowardsCenter == false) // this tolerance should increase if mirrors viewed at an extrame angle exhibit artifacts
						// at extreme viewing angle, moving along normal is better although artifacts may still happen with geometry distance within the mirror
						// this strategy best handles geometry that exists right up to the mirror's actual edge to prevent artifacts from floating point inaccuracies
						// todo: don't do this yet, it offsets the image in the mirror to be misaligned against the reflection in the real world, noticably, when up clsoe to a mirror.  Possibly
						//   reduce the ammount depending on how clsoe you are?
						viewpointAdjustment = mirrorNormal.ScalarMult(mirrorOrientAdjustment);
					else
						// instead of moving the viewpoint along the normal, move it towards the mirror's center so that even at an angle, geometry isn't missed
						// moving towards center instead halps avoid additional artifacting problems that the new viewpoint might see but the frustum does not exactly at the mirror's edge
						// it won't fix a distance portal in the mirror that coincides with the mirror's edge whose intersection hides more distance geometry that the adjsuted viewpoint can now
						//    see, but the artifacting effect will be less than simply moving along the normal.
						viewpointAdjustment = offsetToCenter.ScalarMult(mirrorOrientAdjustment);
					mirrorWorldViewpoint.p = mirrorWorldViewpoint.p + viewpointAdjustment;
					// adjust the frustum backwards to widen its view and make sure slightly more is rendered.  helps with more artifacting
					Frustum newFrustum;
					mirrorEnumerator.Current()->data.reflectedFrustum.CopyTo(&newFrustum);
					// don't do this yet - the adjustments will cascade to each mirror depth because the adjusted frustum will be reflected.  the portal parse should use the adjustment but the reflected
					//   frustum should use the original.  Baking on it,a nd only if it seems necessary.  If artifacting is not enough of a problem then don't bother.
					//newFrustum.origin = newFrustum.origin - offsetToCenter.ScalarMult(mirrorOrientAdjustment);

					// ?? todo: might need to fix frustum since its origin != mirrorWorldViewpoint.p now.

					// flip the cullface
					p_graphics->FlipCullFace();

					// render everything with the flipped viewpoint and the starting node for the mirror
					shaderOptions.silhouetteType = GraphicsShaderSilhouetteEnumType::Normal;
					// restore color - anaglyph compliant
					if (p_camera != nullptr && stereoScopicMode == 1)
					{
						if (p_left == true)
							p_graphics->ColorMask(true, false, false, true); // red
						else
							p_graphics->ColorMask(false, true, true, true); // cyan
					}
					else
						p_graphics->ColorMask(true, true, true, true); // normal

					///////////////////////
					// render it!
#ifdef _DEBUG
					Matrix4d mvp1 = p_graphics->GetMVPMatrix();
#endif

					p_graphics->PushMatrix();
					DrawElements(p_graphics, &mirrorWorldViewpoint, &(newFrustum), p_fov, p_nearPlane, p_farPlane, p_nodesParsedForFirstNode, p_nodesRenderedQty, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChanges, p_totalLightsRendered, p_lightsSkipped, p_lightNodesRejected, p_camera, p_left, p_mainRenderId, mirrorEnumerator.Current()->data.nodeIndex, p_mirrorDepth + 1, clipPlanePosition, clipPlaneNormal, ((PortalParseResult *)mirrorEnumerator.Current()->data.parseResultRef), resultList, p_finalNodeBoundingVolume);
					p_graphics->PopMatrix();
					// done rendering mirror world
					///////////////////////

					// restore to this world
					p_graphics->FlipCullFace();

					// disable clip plane
					if (useClipPlanes == true)
					{
						if (useSingleClipPlane == false || p_mirrorDepth == 0)
							p_graphics->DisableClipPlane(p_mirrorDepth);
						else
						{
							// restore clip plane to what it was when DrawElements was started
							p_graphics->SetClipPlane(clipPlaneId,
								p_clipPlanePosition,
								p_clipPlaneNormal);
						}
					}

					// duplicated in else below
					// note: this involves flipping the cull face, but it should be fine since it is compliant with how the viewpoint is currently situated from reflection
					// re-prep all the lights and shadows for the current node
					if (originalLightingEnabled == true && useZeroMirrorAlpha == false) // don't bother if mirror surfaces won't be rendered on top of their reflections
					{
						bool restoreMainProjection = false;

						if (p_mirrorDepth % 2 == 1)
							// restore normal face culling since we are in a flipped presentation
							p_graphics->FlipCullFace();
						PrepareLightsAndShadowsForNode(p_graphics, resultList->uniqueNodes, &worldOrient, mirrorEnumerator.Current()->data.nodeIndex, p_finalNodeBoundingVolume, shaderOptions, p_lightsSkipped, p_lightNodesRejected, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChanges, p_mainRenderId, currentRenderId, restoreMainProjection, &lightMVPs[0], p_nearPlane, p_farPlane, nodeObjectLists, elapsedTimeMSf);
						if (p_mirrorDepth % 2 == 1)
							// and bring it back (although restoreMainProjection below flips it again, but this is a more logical presentation)
							p_graphics->FlipCullFace();

						if (restoreMainProjection == true)
						{
							// this is all we need to do, really, since we are just using shaders
							// but if we need the old pipeline, we'll need to put the projection back

							shaderOptions.eyeMVPMatrixRef = &mvp;
							p_graphics->FlipCullFace();
							p_graphics->SetCurrentFrameBuffer(currentMainFramebuffer);
							p_frameBufferChanges++;

							// MUST restore projection values in the API graphics class so that later operations work! (like rendering the view frustum)
							SetMainProjection(p_graphics, p_viewpointOrient, p_fov, p_nearPlane, p_farPlane, p_camera, p_left);
						}
					}

					// put values back so we can render the mirror
					shaderOptions.modelWorldOrientRef = &worldOrient;
					worldOrient.LoadIdentity();
					//mvp = p_graphics->GetMVPMatrix();
					shaderOptions.vertexScale = 1.0f;
					shaderOptions.singleColorRef = nullptr;

					// render the mirror's surface, decrementing the stencil surface as it is rendered (eventually restoring everything to 0), using the same lights and shadow maps tallied for this node
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, mirrorStencilMask); // need this here because the mirror world render likely altered this setting
					p_graphics->StencilMask(mirrorStencilMask);
					// decrement on depth fail and success to make absolutely sure the stencil for the area gets cleared to prevent artifacts from the clip plane allowing fragments with a lower depth
					//   value than the mirror's surface preventing the mirror from clearing the stencil
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Decrement, GraphicsStencilOperationEnum::Decrement);
					if (originalLightingEnabled == true)
					{
						shaderOptions.lightingMaterialRef = &reallyShiny;
					}

#ifdef _DEBUG
					Matrix4d mvp2 = p_graphics->GetMVPMatrix();
					if (mvp2.Equals(mvp1) == false)
						throw gcnew Exception("Push and pop has different results!");
					if (mvp2.Equals(*(shaderOptions.eyeMVPMatrixRef)) == false)
						throw gcnew Exception("shader MVP has changed!");
#endif

					GameColor overrideMirrorColor(255, 0, 0, 255);
					GameColor *colorOverride = nullptr;
					if (useZeroMirrorAlpha == true)
					{
						overrideMirrorColor = portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].color;
						overrideMirrorColor.alpha = 0;
						colorOverride = &overrideMirrorColor;// and keep specular off so that they dont' interere with visibility
						reallyShiny.specularReflectivity = Vector3d(0, 0, 0);
						shaderOptions.lightQty = 0; // for a speedup
					}

					shaderOptions.useHighShadowBias = 1; // use high bias since front face was used to make shadow
					if (allowScreenRender == true)
						portalMap->RenderMirror(p_graphics, mirrorEnumerator.Current()->data.nodeIndex, mirrorEnumerator.Current()->data.mirrorIndex, shaderOptions, colorOverride);
					shaderOptions.useHighShadowBias = 0;
				} // mirror depth < max
				else
				{
					// max mirrors already
					// render mirror as a solid object - don't render its scene

					// duplicated from above
					// note: this involves flipping the cull face, but it should be fine since it is compliant with how the viewpoint is currently situated from reflection
					// re-prep all the lights and shadows for the current node
					if (originalLightingEnabled == true)
					{
						bool restoreMainProjection = false;

						if (p_mirrorDepth % 2 == 1)
							// restore normal face culling since we are in a flipped presentation
							p_graphics->FlipCullFace();
						PrepareLightsAndShadowsForNode(p_graphics, resultList->uniqueNodes, &worldOrient, mirrorEnumerator.Current()->data.nodeIndex, p_finalNodeBoundingVolume, shaderOptions, p_lightsSkipped, p_lightNodesRejected, p_lightNodesRenderedQty, p_lightNodeRerendersQty, p_frameBufferChanges, p_mainRenderId, currentRenderId, restoreMainProjection, &lightMVPs[0], p_nearPlane, p_farPlane, nodeObjectLists, elapsedTimeMSf);
						if (p_mirrorDepth % 2 == 1)
							// and bring it back (although restoreMainProjection below flips it again, but this is a more logical presentation)
							p_graphics->FlipCullFace();

						if (restoreMainProjection == true)
						{
							// this is all we need to do, really, since we are just using shaders
							// but if we need the old pipeline, we'll need to put the projection back

							shaderOptions.eyeMVPMatrixRef = &mvp;
							p_graphics->FlipCullFace();
							p_graphics->SetCurrentFrameBuffer(currentMainFramebuffer);
							p_frameBufferChanges++;

							// MUST restore projection values in the API graphics class so that later operations work! (like rendering the view frustum)
							SetMainProjection(p_graphics, p_viewpointOrient, p_fov, p_nearPlane, p_farPlane, p_camera, p_left);
						}
					}

					// put values back so we can render the mirror
					shaderOptions.modelWorldOrientRef = &worldOrient;
					worldOrient.LoadIdentity(); // to render the mirror
					shaderOptions.vertexScale = 1.0f;
					shaderOptions.singleColorRef = nullptr;

					if (originalLightingEnabled == true)
					{
						shaderOptions.lightingMaterialRef = &reallyShiny;
					}

					// need to match depth because the mirror was already rendered solid before
					p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThanEqual);
					GameColor colorOverride = portalMap->nodes[mirrorEnumerator.Current()->data.nodeIndex].mirrors[mirrorEnumerator.Current()->data.mirrorIndex].color;
					colorOverride.alpha = 255;
					shaderOptions.useHighShadowBias = 1; // use high bias since front face was used to make shadow
					if (allowScreenRender == true)
						portalMap->RenderMirror(p_graphics, mirrorEnumerator.Current()->data.nodeIndex, mirrorEnumerator.Current()->data.mirrorIndex, shaderOptions, &colorOverride);
					shaderOptions.useHighShadowBias = 0;
					p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThan);
				} // mirror depth max
			}

			if (renderHiddenCreatures == false && p_mirrorDepth == 0)
			{
				// all done with stencil
				p_graphics->SetStencilEnabled(false);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->StencilMask(0x0);
			}
			else if (p_mirrorDepth > 0)
			{
				// in case anything after the mirror processing needs to be rendered (like fire particles), return the stencil test condition to this mirror level
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth, mirrorStencilMask);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->StencilMask(0x0);
			}
		}
		// end of section 8
#pragma endregion Process Mirrors

		// render triguys hidden by walls, only in non-mirror world
		if (renderHiddenCreatures == true && p_mirrorDepth == 0)
		{
			shaderOptions.silhouetteType = GraphicsShaderSilhouetteEnumType::SolidColor;
			//GameColor silhouetteColor(255, 255, 255, 64);
			GameColor silhouetteColor(128, 128, 128, 255);
			shaderOptions.silhouetteColorRef = &silhouetteColor;
			p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::GreaterThan);
			p_graphics->SetDepthWriteEnabled(false);

			// 200' volume around player, for now
			Vector3d minPosition = p_viewpointOrient->p - Vector3d(10.0f, 10.0f, 10.0f);
			Vector3d maxPosition = p_viewpointOrient->p + Vector3d(10.0f, 10.0f, 10.0f);
			int xMinIndex, yMinIndex, zMinIndex;
			int xMaxIndex, yMaxIndex, zMaxIndex;
			portalPartition->GetPartitionSectionIndices(minPosition.x, minPosition.y, minPosition.z, xMinIndex, yMinIndex, zMinIndex);
			portalPartition->GetPartitionSectionIndices(maxPosition.x, maxPosition.y, maxPosition.z, xMaxIndex, yMaxIndex, zMaxIndex);
			// clear render Ids
			for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
			{
				for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
				{
					for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
					{
						LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
						while (nodeIndexEnumerator.MoveNext())
						{
							// quick way to exclude
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
								continue;

							LinkedListEnumerator<RandomDungeonCreaturePtr> creatureEnumerator = LinkedListEnumerator<RandomDungeonCreaturePtr>(nodeObjectLists[nodeIndexEnumerator.Current()->data.index].creatures);
							while (creatureEnumerator.MoveNext())
							{
								if (creatureEnumerator.Current()->data->animationId != p_mainRenderId && creatureEnumerator.Current()->data->modelRef->jointedModel != nullptr)
								{
									// prep jointed model orients according to its animation!
									creatureEnumerator.Current()->data->jointedModelAnimationTracker.InterpolateOrients(creatureEnumerator.Current()->data->jointOrients);

									creatureEnumerator.Current()->data->animationId = p_mainRenderId;
								}

								creatureEnumerator.Current()->data->renderId = 0;
							}
							LinkedListEnumerator<RandomDungeonBallPtr> ballEnumerator = LinkedListEnumerator<RandomDungeonBallPtr>(nodeObjectLists[nodeIndexEnumerator.Current()->data.index].balls);
							while (ballEnumerator.MoveNext())
							{
								ballEnumerator.Current()->data->renderId = 0;
							}
						} // nodes in partition
					} // zIndex
				} // yIndex
			} // xIndex

			// now render them! (render Ids were cleared so we could tell if we rendered them in this section already)
			// only show if rendering on fragment with stencil = 1 (and is beyond wall in depth test)
			p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, hiddenCreatureStencilValue, 0xff);
			// don't write to stencil at all (also accomplished by setting mask to 0)
			p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);

			for (int xIndex = xMinIndex; xIndex <= xMaxIndex; xIndex++)
			{
				for (int yIndex = yMinIndex; yIndex <= yMaxIndex; yIndex++)
				{
					for (int zIndex = zMinIndex; zIndex <= zMaxIndex; zIndex++)
					{
						LinkedListEnumerator<PortalNodeIndex> nodeIndexEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
						while (nodeIndexEnumerator.MoveNext())
						{
							// quick way to exclude
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minX > maxPosition.x)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minY > maxPosition.y)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.minZ > maxPosition.z)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxX < minPosition.x)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxY < minPosition.y)
								continue;
							if (portalMap->nodes[nodeIndexEnumerator.Current()->data.index].boundingVolume.maxZ < minPosition.z)
								continue;

							LinkedListEnumerator<RandomDungeonCreaturePtr> creatureEnumerator = LinkedListEnumerator<RandomDungeonCreaturePtr>(nodeObjectLists[nodeIndexEnumerator.Current()->data.index].creatures);
							while (creatureEnumerator.MoveNext())
							{
								if (creatureEnumerator.Current()->data->animationId != p_mainRenderId && creatureEnumerator.Current()->data->modelRef->jointedModel != nullptr)
								{
									// prep jointed model orients according to its animation!
									creatureEnumerator.Current()->data->jointedModelAnimationTracker.InterpolateOrients(creatureEnumerator.Current()->data->jointOrients);

									creatureEnumerator.Current()->data->animationId = p_mainRenderId;
								}

								if (creatureEnumerator.Current()->data->renderId != currentRenderId)
								{
									creatureEnumerator.Current()->data->Render(p_graphics, shaderOptions);
									creatureEnumerator.Current()->data->renderId = currentRenderId; // prevent double renders
								}
							}

							LinkedListEnumerator<RandomDungeonBallPtr> ballEnumerator = LinkedListEnumerator<RandomDungeonBallPtr>(nodeObjectLists[nodeIndexEnumerator.Current()->data.index].balls);
							while (ballEnumerator.MoveNext())
							{
								if (ballEnumerator.Current()->data->renderId != currentRenderId)
								{
									shaderOptions.vertexScale = ballEnumerator.Current()->data->radius;
									shaderOptions.modelWorldOrientRef = &(ballEnumerator.Current()->data->orient);
									ballsRendered++;
									p_graphics->RenderNativeObject(ballNativeObject, shaderOptions);
									ballEnumerator.Current()->data->renderId = currentRenderId; // prevent double renders
								}
							}

						} // nodes in partition
					} // zIndex
				} // yIndex
			} // xIndex

			p_graphics->SetDepthWriteEnabled(true);
			p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThan);
			shaderOptions.silhouetteType = GraphicsShaderSilhouetteEnumType::Normal;

			// disable stencil writing in main world render (all done with hidden creatures)
			if (p_mirrorDepth == 0)
			{
				p_graphics->SetStencilEnabled(false);
				p_graphics->StencilMask(0x0);
			}
		}

		if ((p_mirrorDepth < maxMirrorDepth || maximumRenderSectionAllowed >= 9) && (allowParticles == true))
		{
			////////////
			// Fire particles!
			// Loop through all nodes we rendered, get their light sources, submit all particles for them to graphics
			p_graphics->SetDepthWriteEnabled(false);
			p_graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One);
			LinkedListEnumerator<PortalNodeIndex> nodeParticleEnumerator = LinkedListEnumerator<PortalNodeIndex>(p_parseResultData->nodes);
			GraphicsShaderParticlesOptions particleOptions;
			particleOptions.mvpMatrixRef = &mvp;
			mvp = p_graphics->GetMVPMatrix();
			Vector3d leftAxis = p_viewpointOrient->l;
			if (p_mirrorDepth % 2 == 1)
				leftAxis = leftAxis.ScalarMult(-1.0f); // so that the particles are proper, so that the flipped cull actually succeeds in rendering them
			Vector3d upAxis = p_viewpointOrient->u;
			particleOptions.leftVPAxisRef = &leftAxis;
			particleOptions.upVPAxisRef = &upAxis;
			particleOptions.minimumZ = p_nearPlane;
			particleOptions.textures[0] = GameContext::TextureRegistry.GetTexture("FireParticle");
			// don't use these here!  save for post processing!
			//particleOptions.grayScale = grayScale;
			//particleOptions.gamma = gamma;
			//particleOptions.fadeColorRef = &fadeColor;
			//particleOptions.fade = fade;
			while (nodeParticleEnumerator.MoveNext())
			{
				LinkedListEnumerator<RandomDungeonLightPtr> nodeLightEnumerator = LinkedListEnumerator<RandomDungeonLightPtr>(nodeObjectLists[nodeParticleEnumerator.Current()->data.index].lights);
				while (nodeLightEnumerator.MoveNext())
				{
					if (nodeLightEnumerator.Current()->data->flicker == true && nodeLightEnumerator.Current()->data->particles.IsEmpty() == false)
					{
						// calculate zdepth for this render (not a gamestate thing - must calculate this for every single render, include each anaglyph eye)
						LinkedListEnumerator<Particle> particleEnumerator = LinkedListEnumerator<Particle>(nodeLightEnumerator.Current()->data->particles);
						while (particleEnumerator.MoveNext())
						{
							Particle *particle = &(particleEnumerator.Current()->data);
							particle->PrepareZDepth(p_viewpointOrient->p, p_viewpointOrient->f);
						}

						// Render particles!
						p_graphics->SubmitParticlesToQueue(particleQueue, nodeLightEnumerator.Current()->data->particles, particleOptions);
					}
				}
			}
			p_graphics->CommitParticleQueue(particleQueue, particleOptions);
			p_graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One_Minus_Source_Alpha);
			p_graphics->SetDepthWriteEnabled(true);
			// particles!
			//////////////////
		}

		// render sarah
		if (sarahTimerMSf > 0.0f)
		{
			//float sarahScale = 0.2f / 978.0f;
			float sarahScale = 0.2f / 978.0f;
			p_graphics->PushMatrix();
			p_graphics->Transform(*sarahOrient);
			p_graphics->Scale(sarahScale, sarahScale, 1.0f);
			sarahModel->Render(*p_graphics);
			p_graphics->PopMatrix();
		}

	} // startNodeIndex != -1

	if (p_mirrorDepth == 0 && fullFrustum == false)
	{
		RenderFrustum(p_graphics, frustumMain, GameColor(255, 255, 255, 32));
	}

	// post processing!!!
	if (p_mirrorDepth == 0 && currentMainFramebuffer != nullptr)
	{
		// Dungeon was rendered to the postprocessing buffer
		// render result with postprocessing effects to main view
		GraphicsPostProcessShaderOptions postProcessingOptions;
		Matrix4d currentMvp = p_graphics->GetMVPMatrix();
		float testZeroDepth = currentMvp.GetDepthBufferValue(p_viewpointOrient->p + p_viewpointOrient->f.ScalarMult(p_nearPlane));  // should be zero or very close
		float maxFocusedDepth = 0.0f;
		float minTotalBlurDepth = 0.0f;
		if (focusByDepthRadius != 0.0f)
		{
			maxFocusedDepth = currentMvp.GetDepthBufferValue(p_viewpointOrient->p + p_viewpointOrient->f.ScalarMult(focusByDepthWorldZMin));
			minTotalBlurDepth = currentMvp.GetDepthBufferValue(p_viewpointOrient->p + p_viewpointOrient->f.ScalarMult(focusByDepthWorldZMax));
		}
		p_graphics->SetDepthTestEnabled(false);
		p_graphics->SetDepthWriteEnabled(false);

		// fulls creen quad
		// no color required
		ModelVertex fullScreenQuadVertices[4] = { ModelVertex(Vector3d(400, 300, 1), 0), ModelVertex(Vector3d(-400, 300, 1), 0), ModelVertex(Vector3d(-400, -300, 1), 0), ModelVertex(Vector3d(400, -300, 1), 0) };
		fullScreenQuadVertices[0].vertex.x = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
		fullScreenQuadVertices[0].vertex.y = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
		fullScreenQuadVertices[1].vertex.x = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
		fullScreenQuadVertices[1].vertex.y = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
		fullScreenQuadVertices[2].vertex.x = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
		fullScreenQuadVertices[2].vertex.y = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
		fullScreenQuadVertices[3].vertex.x = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
		fullScreenQuadVertices[3].vertex.y = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
		ModelVertexTextureCoords fullScreenQuadTexCoords[4] = { ModelVertexTextureCoords(0.0f, 1.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(0.0f, 0.0f) };

		// no need to preserve the current matrix
		p_graphics->SetOrthoProjection(0.1f, 100.0f);
		p_graphics->DefaultTransform();
		p_graphics->Scale(2.0f / float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()), 2.0f / float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()), 1.0f);
		Matrix4d postProcessMvp = p_graphics->GetMVPMatrix();
		postProcessingOptions.mvpMatrixRef = &postProcessMvp;

		float blurSizeFactor = float(currentMainFramebuffer->colorBufferTexture->GetHeight()) / 518.0f * 4.0f / float(blurKernelElementQty); // base on a 4 element kernel
		if (blurRadius != 0.0f || focusByDepthRadius != 0.0f)
		{
			// prep the ping pong frame buffer before rendering to main with the vertical blur and the other post processing effects

			// just a number I haggled together that works

			// depth of field
			if (blurRadius != 0.0f)
			{
				postProcessingOptions.blur = true;
				postProcessingOptions.blurScaleS = 2.0f * blurRadius * 1.0f / float(currentMainFramebuffer->colorBufferTexture->GetWidth()) * blurSizeFactor;
			}
			else if (focusByDepthRadius != 0.0f)
			{
				postProcessingOptions.focusByDepth = true;
				postProcessingOptions.blurScaleS = 2.0f * focusByDepthRadius * 1.0f / float(currentMainFramebuffer->colorBufferTexture->GetWidth()) * blurSizeFactor;
				postProcessingOptions.focusLowDepthRangeMin = 0.004f;
				postProcessingOptions.focusLowDepthRangeMax = 0.005f;
				postProcessingOptions.focusHighDepthRangeMin = maxFocusedDepth;
				postProcessingOptions.focusHighDepthRangeMax = minTotalBlurDepth;
				postProcessingOptions.depthTextureRef = currentMainFramebuffer->depthBufferTexture;
			}
			postProcessingOptions.blurKernelRef = &blurKernel[0];
			postProcessingOptions.kernelElementQty = blurKernelElementQty;

			// render to ping pong buffer
			p_graphics->FinishRender(); // make sure render to post processing buffer is flushed
			p_graphics->SetCurrentFrameBuffer(postProcessingPingPongFrameBuffer);

			postProcessingOptions.srcTextureRef = postProcessingFrameBuffer->colorBufferTexture;

			p_graphics->RenderPostProcessingShaderQuad(fullScreenQuadVertices, fullScreenQuadTexCoords, postProcessingOptions);
			postProcessingOptions.blurScaleS = 0.0f;
		}

		postProcessingOptions.fadeFactor = fade;
		GameColor fadeColor(138, 7, 7); // blood red
		postProcessingOptions.fadeColorRef = &fadeColor;
		postProcessingOptions.gamma = gamma;
		postProcessingOptions.grayScale = grayScale;
		postProcessingOptions.lens  = lens;
		//postProcessingOptions.lens = 0.75f; // just testing.  weird.  And edges of screen are wrong!
		//postProcessingOptions.lens = 1.5f; // just testing.  weird.  And edges of screen are wrong!
		if (blurRadius != 0.0f || focusByDepthRadius != 0.0f)
		{
			// just a number I haggled together that works

			// depth of field
			if (blurRadius != 0.0f)
			{
				postProcessingOptions.blur = true;
				postProcessingOptions.blurScaleT = 2.0f * blurRadius * 1.0f / float(currentMainFramebuffer->colorBufferTexture->GetHeight()) * blurSizeFactor;
			}
			else if (focusByDepthRadius != 0.0f)
			{
				postProcessingOptions.focusByDepth = true;
				// need adjustment factor - vertical is exaggerated for some reason
				// todo: don't know why the 5/8 needs to be here
				postProcessingOptions.blurScaleT = (5.0f / 8.0f) * 2.0f * focusByDepthRadius * 1.0f / float(currentMainFramebuffer->colorBufferTexture->GetHeight()) * blurSizeFactor;
				postProcessingOptions.focusLowDepthRangeMin = 0.004f;
				postProcessingOptions.focusLowDepthRangeMax = 0.005f;
				postProcessingOptions.focusHighDepthRangeMin = maxFocusedDepth;
				postProcessingOptions.focusHighDepthRangeMax = minTotalBlurDepth;
				postProcessingOptions.depthTextureRef = currentMainFramebuffer->depthBufferTexture;
			}
			postProcessingOptions.blurKernelRef = &blurKernel[0];
			postProcessingOptions.kernelElementQty = blurKernelElementQty;

			postProcessingOptions.srcTextureRef = postProcessingPingPongFrameBuffer->colorBufferTexture;
		}
		else
		{
			postProcessingOptions.srcTextureRef = postProcessingFrameBuffer->colorBufferTexture;
		}

		// render to main now
		p_graphics->FinishRender(); // make sure render to post processing or pingpong buffer is flushed
		p_graphics->SetCurrentFrameBuffer(nullptr);

		p_graphics->RenderPostProcessingShaderQuad(fullScreenQuadVertices, fullScreenQuadTexCoords, postProcessingOptions);

		p_graphics->SetDepthWriteEnabled(true);
		p_graphics->SetDepthTestEnabled(true);
	}
}

void TestRandomDungeon::PrepareLightsAndShadowsForNode(GraphicsBase *p_graphics, LinkedList<PortalNodeIndex> &p_nodesToRender, Orient3d *p_worldOrientRef, int p_nodeIndex, BoundingVolume3d *p_finalNodeBoundingVolume, GraphicsShaderOptions %p_shaderOptions, int &p_lightsSkipped, int &p_lightNodesRejected, int &p_lightNodesRenderedQty, int &p_lightNodeRerendersQty, int &p_frameBufferChanges, int p_gameStateRenderId, int p_currentRenderId, bool &p_restoreMainProjection, Matrix4d *p_lightMVPs, float p_nearPlane, float p_farPlane, RandomDungeonNodeObjectLists *p_nodeObjectLists, float p_elapsedTimeMSf)
{
#pragma region Lighting

#ifdef _DEBUG
	Matrix4d originalMVP = p_graphics->GetMVPMatrix();
#endif
	// each node gets a separate tally of lights to use

	GraphicsShaderLightTally *lightTally = &(p_nodeObjectLists[p_nodeIndex].lightTally);
	if (p_nodeObjectLists[p_nodeIndex].lightsGameStateId != p_gameStateRenderId)
	{
		lightTally->Clear();
		lightTally->SetMaxLights(maxLightQty);

		// tally up the light.  Get max lights from surrounding regions
		// get region range
		int currentXIndex, currentYIndex, currentZIndex;
		Vector3d startPoint = portalMap->nodes[p_nodeIndex].center;
		portalPartition->GetPartitionSectionIndices(startPoint.x, startPoint.y, startPoint.z, currentXIndex, currentYIndex, currentZIndex);
		int regionRange = 3; // good enough for a intensity 2.0 specular 0.125 attentuation light
		int startXIndex = currentXIndex - regionRange;
		int startZIndex = currentZIndex - regionRange;
		int stopXIndex = currentXIndex + regionRange;
		int stopZIndex = currentZIndex + regionRange;
		if (startXIndex < 0)
			startXIndex = 0;
		if (startZIndex < 0)
			startZIndex = 0;
		if (stopXIndex >= portalPartition->xSectionQty)
			stopXIndex = portalPartition->xSectionQty - 1;
		if (stopZIndex >= portalPartition->zSectionQty)
			stopZIndex = portalPartition->zSectionQty - 1;

		// tally them up
		static int lightTallyId = 0; // tally id to prevent duplicate light inspection
		lightTallyId++;
		if (lightTallyId == -1)
			lightTallyId++;
		for (int xIndex = startXIndex; xIndex <= stopXIndex; xIndex++)
		{
			for (int zIndex = startZIndex; zIndex <= stopZIndex; zIndex++)
			{
				// assuming y only has one region depth
				LinkedListEnumerator<PortalNodeIndex> regionNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(portalPartition->GetPartitionSectionByIndex(xIndex, currentYIndex, zIndex)->data);
				while (regionNodeEnumerator.MoveNext())
				{
					int nodeId = regionNodeEnumerator.Current()->data.index;
					LinkedListEnumerator<RandomDungeonLightPtr> tallyLightEnumerator = LinkedListEnumerator<RandomDungeonLightPtr>(nodeObjectLists[nodeId].lights);
					while (tallyLightEnumerator.MoveNext())
					{
						// note: this assumes lights will NOT move during the render.  if a light has already been tallied then that node has been tallied
						if (tallyLightEnumerator.Current()->data->tallyId == lightTallyId)
						{
							// skip this node
							break;
						}
						else
						{
							// inspect it for inclusion
							tallyLightEnumerator.Current()->data->tallyId = lightTallyId; // prevent double inspection

							// can this light see the node we are rendering?  If not, DO NOT TALLY IT
							// if necessary, get nodes to render for each, and if this node is part of the light's node list, allow including it
							// nodes visible to render for each light are saved so that they never have to be processed again
							// todo: doors will affect this list if they deactivate portals
							// this list shoudl be cleared whenever lights move or portals are affected that are seen by the light, which can change the node list
							if (tallyLightEnumerator.Current()->data->nodesToRender.IsEmpty())
							{
								// interpolate light if not updated yet to gamestateid
								if (tallyLightEnumerator.Current()->data->IsArbiterLight() == true)
								{
									tallyLightEnumerator.Current()->data->SetArbiterLightOrientation(p_gameStateRenderId);
								}

								Frustum lightFrustum;
								// use nodePosition for node visibility, NOT light position, since it can change due to waggle
								tallyLightEnumerator.Current()->data->MakeFrustum(lightFrustum, &(tallyLightEnumerator.Current()->data->nodePosition));
								int startLightNodeIndex = -1;
								int x;
								if (usePartition == true)
									startLightNodeIndex = portalMap->NodeThatPointIsInside(lightFrustum.origin, *portalPartition, x);
								if (startLightNodeIndex != -1 || usePartition == false)
								{
									portalMap->PopulateNodesToRender(tallyLightEnumerator.Current()->data->nodesToRender, &lightFrustum, x, startLightNodeIndex, false, !fastPortalParse);
								}
							}

							// see if light is visible to same node as we are rendering
							// note: this will look more natural when shadows are enabled, otherwise lights will no longer light the floor on the other side of walls, causing visual dropout and popin
							LinkedListEnumerator<PortalNodeIndex> lightNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(tallyLightEnumerator.Current()->data->nodesToRender.GetFirstNode()->data.nodes);
							bool found = false;
							while (lightNodeEnumerator.MoveNext())
							{
								if (lightNodeEnumerator.Current()->data.index == p_nodeIndex)
								{
									// got a node match, use it
									found = true;
									break;
								}
							}
							if (found == false)
								// light effects won't be visible to node.  skip this light
								continue;

							// DO NOT IGNORE SHADOW!!!   While it's true that a light CANNOT cast shadow of the walls in a node on to that node, there is no guarantee the shadowmap
							//   does not also have shadows of objects rendered in that node that must be cast into that node.  So we can't ignore the shadow.
							// Ignoring shadow is far too circumstantial to really be useful
							//if (tallyLightEnumerator.Current()->data->currentNode == enumerator.Current()->data.index)
							//	tallyLightEnumerator.Current()->data->ignoreShadow = true;
							//else
							//	tallyLightEnumerator.Current()->data->ignoreShadow = false;

							///////////////////////////////////////////////
							// evaluate precedence and attempt to tally it
							// tally entirely on distance from light to center of node being rendered - good enough for now, can be further weighted by lights closer to
							//   bordering portals/lighting more node surface or more brightly
							int lightQty = lightTally->lightQty;
							lightTally->TallyLight(tallyLightEnumerator.Current()->data, (tallyLightEnumerator.Current()->data->worldPosition - portalMap->nodes[p_nodeIndex].center).MagnitudeSquared());
							if (lightTally->lightQty == lightQty)
								p_lightsSkipped++;
						}
					} // lights
				} // nodes
			} // zIndex
		} // xIndex

		p_nodeObjectLists[p_nodeIndex].lightsGameStateId = p_gameStateRenderId;
	}

	// now the tally list has the up to 8 lights we will be using to render this node.
	// time to prep shadow maps for the lights, if any

	// lock the shadowmap assignments that are good
	if (useShadowMaps == true)
	{
		// clear all locks and lock the ones we already have assignments for
		shadowMapRegistry->ClearLocks();
		LinkedListEnumerator<GraphicsShaderLightTallyNode> lightEnumerator = lightTally->GetEnumerator();
		while (lightEnumerator.MoveNext())
		{
			// if shadow map already assigned, lock it!
			if (static_cast<GameTexture ^>(lightEnumerator.Current()->data.lightRef->shadowMapTextureRef) != nullptr)
			{
				shadowMapRegistry->LockShadowMap(lightEnumerator.Current()->data.lightRef);
			}
		}
	}
	LinkedListEnumerator<GraphicsShaderLightTallyNode> lightEnumerator = lightTally->GetEnumerator();
	while (lightEnumerator.MoveNext())
	{
		// and add it to the shaderOptions - main render gets access to light data and shadow map result
		// do this later
		if (useShadowMaps == true)
		{
#pragma region ShadowMaps
			// if shadow map needs prepping, do it now on the implementation light
			// needs prep if no shadow map for this light currently (if mainRenderId is ==, that means a node render used this shadow map but another node wiped it out so we need it again)
			// to reiterate, a shadow map is prepped once for a single game tick, but an upgrade allows a shadowmap to be updated with extra missing nodes if lights are parsed extra times due to anaglyph or mirrors
			if (static_cast<GameTexture ^>(lightEnumerator.Current()->data.lightRef->shadowMapTextureRef) == nullptr || ((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->shadowMapMainRenderId != p_gameStateRenderId)// || (static_cast<GameTexture ^>(lightEnumerator.Current()->data.lightRef->shadowMapTextureRef) != nullptr && ((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->renderId != p_currentRenderId && allowShadowMapUpdating == true))
			{
				bool frameBufferActive = false; // don't select the frame buffer until we know we need it

				bool updating = false;
				if (allowShadowMapUpdating == true)
				{
					if (static_cast<GameTexture ^>(lightEnumerator.Current()->data.lightRef->shadowMapTextureRef) != nullptr && ((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->renderId != p_currentRenderId)
						updating = true; // making another pass at the light because of another call to DrawElements (analgyph or mirror render), so check the nodes to make sure they weren't already prepped in the shadow map
				}
				((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->renderId = p_currentRenderId; // track for updating check later

				bool reRender = false;
				if (static_cast<GameTexture ^>(lightEnumerator.Current()->data.lightRef->shadowMapTextureRef) == nullptr && ((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->shadowMapMainRenderId == p_gameStateRenderId) // && updating == false)
				{
					// this is a re-render because we ran out of shadow maps and had to use a rendered one for another light previously, so this one is being rerendered from scratch
					p_lightNodeRerendersQty++;
					reRender = true;
				}

				// rendering this shadow map
				((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->shadowMapMainRenderId = p_gameStateRenderId; // prevents duplicate shadow map renders

				// get a texture to render to if we don't have one
				// do this on the implementation light, NOT the shader light copy!!!
				// note: both texture and framebuffer are set and null together
				bool freshShadowMap = false;
				if (static_cast<GameTexture ^>(lightEnumerator.Current()->data.lightRef->shadowMapTextureRef) == nullptr)
				{
					shadowMapRegistry->AssignShadowMap(lightEnumerator.Current()->data.lightRef);
					freshShadowMap = true;
				}

				// use mvp specific to lights for spotlights and directional flatmaps (lightMVPs array above will be used for cubemaps)
				// main buffer will be made active and eyeMVPRef will be put back before render
				Matrix4d shadowMapEyeMVP;

				// if light has a flicker/waggle, apply it now
				// check again before copying lights over to shader
				RandomDungeonLightPtr light = (RandomDungeonLightPtr)lightEnumerator.Current()->data.lightRef;
				if (light->flicker == true && light->positionWaggleGamestateId != p_gameStateRenderId)
				{
					light->AnimatePositionWaggle(p_elapsedTimeMSf);
					light->positionWaggleGamestateId = p_gameStateRenderId;
				}

				// select and clear the framebuffer now if this is a fresh assignment, so that if no nodes are rendered, it has no shadows and is good data
				if (freshShadowMap == true)
				{
					p_shaderOptions.eyeMVPMatrixRef = &shadowMapEyeMVP;

					SelectShadowFrameBuffer(p_graphics, p_shaderOptions, lightEnumerator.Current()->data.lightRef, freshShadowMap, p_restoreMainProjection, p_lightMVPs, p_nearPlane, p_farPlane);
					p_frameBufferChanges++;

					frameBufferActive = true;
				}

				// render the shadow map
				///////////////////////////////////////////
				// render EVERYTHING (walls, objects, etc.)
				static int currentLightRenderId = 0;
				currentLightRenderId++;
				LinkedListEnumerator<PortalNodeIndex> lightNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(((RandomDungeonLight *)(lightEnumerator.Current()->data.lightRef))->nodesToRender.GetFirstNode()->data.nodes);
				BoundingVolume3d lightFinalBoundingVolume;
				if (checkLightNodeBounds == true && checkLightNodeBoundsHeavy == false)
				{
					lightFinalBoundingVolume = *p_finalNodeBoundingVolume;
					// get bounding volume of light combined with final node volume to use as rejection partition
					lightFinalBoundingVolume.ProcessPoint(lightEnumerator.Current()->data.lightRef->worldPosition);
				}
				while (lightNodeEnumerator.MoveNext())
				{
					bool includeLightNode = false;
					if (checkLightNodeBounds == false || renderShadowNodes == false)
					{
						// don't count skipping it if not rendering shadow nodes
						includeLightNode = true;
					}
					else
					{
						bool alreadyPrepped = false; // was this node already prepped for this gamestate? (if set to true, the node was already prepped and will be skipped below)

						if (checkLightNodeBoundsHeavy == false)
						{
							// figure out if node should even be rendered (if it's entirely outside the final node bounding volume including the light point, there is no reason to render it)
							if (portalMap->nodes[lightNodeEnumerator.Current()->data.index].boundingVolume.Intersects(lightFinalBoundingVolume) == true)
							{
								includeLightNode = true;
								if (updating == true)
								{
									// make sure we haven't rendered this node already to this shadow map
									LinkedListEnumerator<PortalNodeIndex> renderedNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(lightEnumerator.Current()->data.lightRef->shadowNodesPrepared);
									while (renderedNodeEnumerator.MoveNext())
									{
										if (renderedNodeEnumerator.Current()->data.index == lightNodeEnumerator.Current()->data.index)
										{
											includeLightNode = false; // cancel this node
											alreadyPrepped = true;
											break;
										}
									}
								}
							}
						}
						else
						{
							// check ALL nodes one at a time - on first success, skip out - we need the node
							// We need to check ALL nodes we plan to render to handle the case of shadowmap reuse (a shadowmap reused for rendering a later node will NOT be prepped again, so render ALL necessary
							//   nodes to the shadowmap)
							BoundingVolume3d nodeBoundingVolume;
							LinkedListEnumerator<PortalNodeIndex> finalNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(p_nodesToRender);
							while (finalNodeEnumerator.MoveNext())
							{
								nodeBoundingVolume = portalMap->nodes[finalNodeEnumerator.Current()->data.index].boundingVolume;
								nodeBoundingVolume.ProcessPoint(lightEnumerator.Current()->data.lightRef->worldPosition);
								if (nodeBoundingVolume.Intersects(portalMap->nodes[lightNodeEnumerator.Current()->data.index].boundingVolume) == true)
								{
									includeLightNode = true;
									if (updating == true)
									{
										// make sure we haven't rendered this node already to this shadow map
										LinkedListEnumerator<PortalNodeIndex> renderedNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(lightEnumerator.Current()->data.lightRef->shadowNodesPrepared);
										while (renderedNodeEnumerator.MoveNext())
										{
											if (renderedNodeEnumerator.Current()->data.index == lightNodeEnumerator.Current()->data.index)
											{
												includeLightNode = false; // cancel this node
												alreadyPrepped = true;
												break;
											}
										}
									}

									// we got a final node that requires the light node - skip out
									if (includeLightNode == true)
										break;
								}
							}
						}

						if (includeLightNode == false && alreadyPrepped == false)
							p_lightNodesRejected++;
					} // is node good?

					if (renderShadowNodes == true && includeLightNode == true)
					{
						// select frame buffer for rendering now if it isn't ready yet
						// this call only happens here if update == true on the first good node found on an existing shadowmap that is still intact on this iteration, so don't clear it
						if (frameBufferActive == false)
						{
							p_shaderOptions.eyeMVPMatrixRef = &shadowMapEyeMVP;

							SelectShadowFrameBuffer(p_graphics, p_shaderOptions, lightEnumerator.Current()->data.lightRef, false, p_restoreMainProjection, p_lightMVPs, p_nearPlane, p_farPlane);
							p_frameBufferChanges++;
							frameBufferActive = true;
						}

						// draw the balls that are in the node first - saves on depth culling
						// todo: parse a smaller list!
						// todo: problem which this methodology is that an object with a radius suddenly appears with it passes in from a not-rendered node, so should really
						//   incorporate its radius into the decision making, and NOT render the same object twice here!
						// todo: if updating (updating == true), we shouldn't render objects that were already rendered for this light before, but we have no real way of checking that
						//   unless objects record which mainRenderId for a given light they were rendered for, which is too much information to track.  So, objects will be rendered
						//   more than once if they were already rendered before and are in nodes that are being added.
						if (allowObjectsInShadowMaps == true)
						{
							LinkedListEnumerator<RandomDungeonBallPtr> ballEnumerator = LinkedListEnumerator<RandomDungeonBallPtr>(nodeObjectLists[lightNodeEnumerator.Current()->data.index].balls);
							while (ballEnumerator.MoveNext())
							{
								objectParsesToRender++;

								// don't double render, and don't render a ball for the shadowmap of the light that the ball has attached
								// ??: why was the light showing up at all when we weren't checking that!?
								if (ballEnumerator.Current()->data->lightRenderId != currentLightRenderId && ballEnumerator.Current()->data->lightRef != lightEnumerator.Current()->data.lightRef)
								{
									p_shaderOptions.vertexScale = ballEnumerator.Current()->data->radius;
									p_shaderOptions.modelWorldOrientRef = &(ballEnumerator.Current()->data->orient);
									if (allowShadowMapRender == true)
									{
										if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
											p_graphics->RenderNativeObjectToShadowMap(ballNativeObject, p_shaderOptions);
										else
											p_graphics->RenderNativeObjectToCubeShadowMap(ballNativeObject, p_shaderOptions);
									}
									ballEnumerator.Current()->data->lightRenderId = currentLightRenderId; // prevent rendering twice for this light
								}
							}

							// render dressings
							// keep backsides, otherwise we get acne
							//if (useBackSideOfNodesForShadows == false)
							//	p_graphics->FlipCullFace();
							LinkedListEnumerator<RandomDungeonDressingPtr> dressingEnumerator = LinkedListEnumerator<RandomDungeonDressingPtr>(nodeObjectLists[lightNodeEnumerator.Current()->data.index].dressings);
							while (dressingEnumerator.MoveNext())
							{
								objectParsesToRender++;

								if (dressingEnumerator.Current()->data->shadowRenderId != currentLightRenderId)
								{
									// spin the Hellraiser cubes
									if (p_elapsedTimeMSf > 0.0f)
									{
										if (dressingEnumerator.Current()->data->animationId != p_gameStateRenderId && dressingEnumerator.Current()->data->type == RandomDungeonObjectTypeEnum::HellraiserCube)
										{
											dressingEnumerator.Current()->data->orient.Rotate(Vector3d(0, 1, 0), dressingEnumerator.Current()->data->rotationDegreesPerMS * p_elapsedTimeMSf);
											dressingEnumerator.Current()->data->animationId = p_gameStateRenderId;
										}
									}

									if (allowShadowMapRender == true)
									{
										if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
											dressingEnumerator.Current()->data->RenderToFlatShadowMap(p_graphics, p_shaderOptions);
										else
											dressingEnumerator.Current()->data->RenderToCubeShadowMap(p_graphics, p_shaderOptions);
									}
									dressingEnumerator.Current()->data->shadowRenderId = currentLightRenderId; // prevent double renders
								}
							}
							//if (useBackSideOfNodesForShadows == false)
							//	p_graphics->FlipCullFace();

							// render creatures
							// keep backsides, otherwise we get acne
							//if (useBackSideOfNodesForShadows == false)
							//	p_graphics->FlipCullFace();
							LinkedListEnumerator<RandomDungeonCreaturePtr> creatureEnumerator = LinkedListEnumerator<RandomDungeonCreaturePtr>(nodeObjectLists[lightNodeEnumerator.Current()->data.index].creatures);
							while (creatureEnumerator.MoveNext())
							{
								objectParsesToRender++;

								// don't render an object for its own light!!
								if (creatureEnumerator.Current()->data->shadowRenderId != currentLightRenderId && creatureEnumerator.Current()->data->lightRef != lightEnumerator.Current()->data.lightRef)
								{
									// prep animation orients for jointed models (shader orients will be prepped inside the render call)
									if (creatureEnumerator.Current()->data->animationId != p_gameStateRenderId && creatureEnumerator.Current()->data->modelRef->jointedModel != nullptr)
									{
										// prep jointed model orients according to its animation!
										creatureEnumerator.Current()->data->jointedModelAnimationTracker.InterpolateOrients(creatureEnumerator.Current()->data->jointOrients);

										creatureEnumerator.Current()->data->animationId = p_gameStateRenderId;
									}

									if (allowShadowMapRender == true)
									{
										if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
											creatureEnumerator.Current()->data->RenderToFlatShadowMap(p_graphics, p_shaderOptions);
										else
											creatureEnumerator.Current()->data->RenderToCubeShadowMap(p_graphics, p_shaderOptions);
									}
									creatureEnumerator.Current()->data->shadowRenderId = currentLightRenderId; // prevent double renders
								}
							}
							//if (useBackSideOfNodesForShadows == false)
							//	p_graphics->FlipCullFace();

							// draw the triguys, don't care about duplicate renders right now
							float triguyScale = 0.1f;
							p_shaderOptions.vertexScale = 0.1f;
							p_shaderOptions.modelWorldOrientRef = triguyOrient;
							triguy->PrepareNativeObjectJointOrients(p_shaderOptions.transformDataRef->GetOrients(), triguyJointOrients, *triguyOrient, triguyScale);
							if (allowShadowMapRender == true)
							{
								if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
									p_graphics->RenderNativeObjectToCubeShadowMap(triguyNativeObject, p_shaderOptions);
								else
									p_graphics->RenderNativeObjectToShadowMap(triguyNativeObject, p_shaderOptions);
							}

							p_shaderOptions.modelWorldOrientRef = triguyRedEyesOrient;
							triguy->PrepareNativeObjectJointOrients(p_shaderOptions.transformDataRef->GetOrients(), triguyJointOrients, *triguyRedEyesOrient, triguyScale);
							if (allowShadowMapRender == true)
							{
								if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
									p_graphics->RenderNativeObjectToCubeShadowMap(triguyRedEyesNativeObject, p_shaderOptions);
								else
									p_graphics->RenderNativeObjectToShadowMap(triguyRedEyesNativeObject, p_shaderOptions);
							}
						} // allow objects in shadow maps

						// objects might have changed these, put them back!
						p_shaderOptions.modelWorldOrientRef = p_worldOrientRef;
						p_shaderOptions.vertexScale = 1.0f;

						// but render front side of portal nodes to get the complete shadow we need (otherwise nodes that light can't see aren't rendered to the shadow map and leave gaps in the shadow
						//   that can be seen on more distant large walls)
						if (useBackSideOfNodesForShadows == false)
							p_graphics->FlipCullFace();
						// this render only uses the parts of the shaderoptions necessary for rendering the shadow map (lights are ignored, lightmvp is used for flat map, mvp array used for cubemap)
						if (allowShadowMapRender == true)
						{
							p_lightNodesRenderedQty++;
							if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
								portalMap->RenderNodeToFlatMap(p_graphics, lightNodeEnumerator.Current()->data.index, p_shaderOptions);
							else
								portalMap->RenderNodeToCubeMap(p_graphics, lightNodeEnumerator.Current()->data.index, p_shaderOptions);
						}
						// mirrors too!
						for (int m = 0; m < portalMap->nodes[lightNodeEnumerator.Current()->data.index].mirrorQty; m++)
						{
							if (allowShadowMapRender == true)
							{
								if (lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
									portalMap->RenderMirrorToFlatMap(p_graphics, lightNodeEnumerator.Current()->data.index, m, p_shaderOptions);
								else
									portalMap->RenderMirrorToCubeMap(p_graphics, lightNodeEnumerator.Current()->data.index, m, p_shaderOptions);
							}
						}
						// backside rendering again for the rest of the objects to draw
						if (useBackSideOfNodesForShadows == false)
							p_graphics->FlipCullFace();

						// record node as being prepared in this light's shadow map for update checking later
						lightEnumerator.Current()->data.lightRef->shadowNodesPrepared.Add(lightNodeEnumerator.Current()->data.index);
					} // good node to render
				} // each node a light can see
			} // shadow map not prepped yet
#pragma endregion ShadowMaps
		} // use shadow maps
	} // loop through tallied lights - todo: only doing anything if shadow maps are enabled, so these two blocks can be switched

	// animate lights if necessary
	LinkedListEnumerator<GraphicsShaderLightTallyNode> lightTallyEnumerator = lightTally->GetEnumerator();
	while (lightTallyEnumerator.MoveNext())
	{
		RandomDungeonLight *dungeonLight = (RandomDungeonLight *)(lightTallyEnumerator.Current()->data.lightRef);
		if (dungeonLight->flicker == true && dungeonLight->animationGamestateId != p_gameStateRenderId)
		{
			dungeonLight->PerformFlicker(p_elapsedTimeMSf, gameTimeMSf);
			dungeonLight->animationGamestateId = p_gameStateRenderId;
		}
		// if light has a waggle, apply it now
		// we check here again in case shadows were skipped
		if (dungeonLight->flicker == true && dungeonLight->positionWaggleGamestateId != p_gameStateRenderId)
		{
			dungeonLight->AnimatePositionWaggle(p_elapsedTimeMSf);
			dungeonLight->positionWaggleGamestateId = p_gameStateRenderId;
		}
	}
	// copy tallied lights into shader, sorted
	lightTally->SetLightsInShaderOptions(p_shaderOptions);
	// if light scale is other than 1.0, change colors as they were copied into shaderoptions (next iteration will replace them)
	if (lightScale != 1.0f)
	{
		// todo: intensity will need to be reset after all is done, but don't always reset it, only after this loop is done, because flickering lights need their intensity preserved after
		//  this loop is done
		// preferably, RandomDungeonLight will have an intensity modulator that preserves the original intensity and puts it back
		for (int i = 0; i < p_shaderOptions.lightQty; i++)
		{
			p_shaderOptions.lightRefs[i]->intensity = lightScale;
		}
	}
#ifdef _DEBUG
	if (useShadowMaps == true)
	{
		for (int i = 0; i < p_shaderOptions.lightQty; i++)
		{
			if (p_shaderOptions.lightRefs[i]->shadowMapFrameBufferRef == nullptr)
			{
				throw gcnew Exception(String::Format("Light qty {0}, index {1} has no shadow map frame buffer", p_shaderOptions.lightQty, i));
			}
			if (static_cast<GameTexture ^>(p_shaderOptions.lightRefs[i]->shadowMapTextureRef) == nullptr)
			{
				throw gcnew Exception(String::Format("Light qty {0}, index {1} has no shadow map depth texture", p_shaderOptions.lightQty, i));
			}
		}
	}
#endif _DEBUG

#ifdef _DEBUG
	Matrix4d currentMVP = p_graphics->GetMVPMatrix();
	if (p_restoreMainProjection == false && currentMVP.Equals(originalMVP) == false)
		throw gcnew Exception("MVPs don't match!");
#endif
}

void TestRandomDungeon::SelectShadowFrameBuffer(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, GraphicsShaderLightPtr p_lightRef, bool p_clear, bool &p_restoreMainProjection, Matrix4d *p_lightMVPs, float p_nearPlane, float p_farPlane)
{
	// set shadowmap texture as current render target
	// must do this before prep so that viewport values are correct!!!
	p_graphics->SetCurrentFrameBuffer(p_lightRef->shadowMapFrameBufferRef);

	// the mvp prepping can occur on the shader light instead of the implementation
	if (p_lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
	{
		if (p_lightRef->type == GraphicsShaderCompositionLightType::Directional)
		{
			//GraphicsUtilities::PrepareDirectionalShadowFlatMapMVP(p_graphics, shaderOptions, shaderOptions.lightQty, 0.01f, 1000.0f, *sceneWorldCenter, sceneWorldRadius);
		}
		else
			GraphicsUtilities::PrepareSpotlightShadowFlatMapMVP(p_graphics, p_shaderOptions, p_lightRef, p_nearPlane, p_farPlane);
	}
	else if (p_lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
	{
		GraphicsUtilities::PreparePointLightShadowCubeMapMVPs(p_graphics, p_shaderOptions, p_lightRef, p_lightMVPs, p_nearPlane, p_farPlane);
	}

	// don't clear it if we are updating
	if (p_clear == true)
		p_graphics->ClearDepth();
	// don't do this if we haven't rendered main since we flipped the cullface
	if (p_restoreMainProjection == false)
	{
		p_restoreMainProjection = true; // will need to restore main projection before rendering the final node
		// default render backside of objects to get shadows
		// calling routine will have to flip things back if p_restoreMainProjection is true
		p_graphics->FlipCullFace();
	}
#pragma endregion Lighting
}

void TestRandomDungeon::RenderFrustum(GraphicsBase *p_graphics, Frustum &p_frustum, GameColor &p_color)
{
	// assumes 3d render space reverse transformed to frustum origin

	ModelVertex vertices[16]; // up to 16

	if (p_frustum.IsEmpty() == true)
		return;

	// just build a polygon out of the frustum segments and render it
	LinkedListEnumerator<FrustumPlane> frustumEnumerator = p_frustum.GetPlaneEnumerator();
	int vertexIndex = 0;
	while (frustumEnumerator.MoveNext())
	{
		vertices[vertexIndex].colorIndex = 0;
		vertices[vertexIndex].vertex = p_frustum.origin + frustumEnumerator.Current()->data.intersectSegmentLeft.ScalarMult(100.0f); // works best for anaglyph

		vertexIndex++;
		if (vertexIndex >= 16)
			throw gcnew System::Exception("Too many planes - max 16");
	}
	ModelSurface surface;
	surface.Initialize(vertexIndex, true);
	for (int i = 0; i < vertexIndex; i++)
		surface.SetVertexIndex(i, i);

	p_graphics->SetDepthTestEnabled(false);
	p_graphics->SetDepthWriteEnabled(false);
	p_graphics->RenderSurfaces(&p_color, 1, &surface, 1, vertices, vertexIndex);
	p_graphics->SetDepthWriteEnabled(true);
	p_graphics->SetDepthTestEnabled(true);
}

// todo: this really should be its own class, but this uses hardcded sigma 10
void TestRandomDungeon::SetBlurKernel(int p_elementQty)
{
	if (p_elementQty < 2 || p_elementQty > MAX_BLUR_KERNEL_ELEMENT_QTY)
		throw gcnew Exception(String::Format("Blur kernel element quantity must be 2-{0}", MAX_BLUR_KERNEL_ELEMENT_QTY));

	// hurray!  http://dev.theomader.com/gaussian-kernel-calculator/
	blurKernelElementQty = p_elementQty;
	// sigma 10 used
	switch (blurKernelElementQty)
	{
	case 2:
		// 0.110741 0.111296 0.110741
		// 0.111296 0.111853 0.111296
		// 0.110741 0.111296 0.110741
		blurKernel[0] = 0.334444f;
		blurKernel[1] = 0.332778f;
		//blurKernelElementTotal = blurKernel[1] + blurKernel[0] + blurKernel[1];
		break;
	case 3:
		// 0.039206 0.039798 0.039997 0.039798 0.039206
		// 0.039798 0.040399 0.040601 0.040399 0.039798
		// 0.039997 0.040601 0.040804 0.040601 0.039997
		// 0.039798 0.040399 0.040601 0.040399 0.039798
		// 0.039206 0.039798 0.039997 0.039798 0.039206
		blurKernel[0] = 0.202001f;
		blurKernel[1] = 0.200995f;
		blurKernel[2] = 0.198005f;
		//blurKernelElementTotal = blurKernel[2] + blurKernel[1] + blurKernel[0] + blurKernel[1] + blurKernel[2];
		break;
	case 4:
		// 0.019408 0.019899 0.020199 0.0203   0.020199  0.019899  0.019408
		// 0.019899 0.020402 0.02071  0.020814 0.02071  0.020402 0.019899
		// 0.020199 0.02071  0.021023 0.021128 0.021023 0.02071  0.020199
		// 0.020300 0.020814 0.021128 0.021234 0.021128 0.020814 0.0203
		// 0.020199 0.02071  0.021023 0.021128 0.021023 0.02071  0.020199
		// 0.019899 0.020402 0.02071  0.020814 0.02071  0.020402 0.019899
		// 0.019408 0.019899 0.020199 0.0203   0.020199 0.019899 0.019408
		blurKernel[0] = 0.145719f;
		blurKernel[1] = 0.144993f;
		blurKernel[2] = 0.142836f;
		blurKernel[3] = 0.139312f;
		break;
	case 5:
		// 0.011237 0.011637 0.011931 0.012111 0.012172 0.012111 0.011931 0.011637 0.011237
		// 0.011637 0.012051 0.012356 0.012542 0.012605 0.012542 0.012356 0.012051 0.011637
		// 0.011931 0.012356 0.012668 0.01286  0.012924 0.01286  0.012668 0.012356 0.011931
		// 0.012111 0.012542 0.01286  0.013054 0.013119 0.013054 0.01286  0.012542 0.012111
		// 0.012172 0.012605 0.012924 0.013119 0.013185 0.013119 0.012924 0.012605 0.012172
		// 0.012111 0.012542 0.01286  0.013054 0.013119 0.013054 0.01286  0.012542 0.012111
		// 0.011931 0.012356 0.012668 0.01286  0.012924 0.01286  0.012668 0.012356 0.011931
		// 0.011637 0.012051 0.012356 0.012542 0.012605 0.012542 0.012356 0.012051 0.011637
		// 0.011237 0.011637 0.011931 0.012111 0.012172 0.012111 0.011931 0.011637 0.011237
		blurKernel[0] = 0.114825f;
		blurKernel[1] = 0.114253f;
		blurKernel[2] = 0.112553f;
		blurKernel[3] = 0.109777f;
		blurKernel[4] = 0.106004f;
		break;
	case 6:
		// 0.0071   0.007427 0.007691 0.007886 0.008005 0.008045 0.008005 0.007886 0.007691 0.007427 0.0071 
		// 0.007427 0.007768 0.008045 0.008248 0.008373 0.008415 0.008373 0.008248 0.008045 0.007768 0.007427
		// 0.007691 0.008045 0.008331 0.008542 0.008671 0.008714 0.008671 0.008542 0.008331 0.008045 0.007691
		// 0.007886 0.008248 0.008542 0.008758 0.00889  0.008935 0.00889  0.008758 0.008542 0.008248 0.007886
		// 0.008005 0.008373 0.008671 0.00889  0.009025 0.00907  0.009025 0.00889  0.008671 0.008373 0.008005
		// 0.008045 0.008415 0.008714 0.008935 0.00907  0.009115 0.00907  0.008935 0.008714 0.008415 0.008045
		// 0.008005 0.008373 0.008671 0.00889  0.009025 0.00907  0.009025 0.00889  0.008671 0.008373 0.008005
		// 0.007886 0.008248 0.008542 0.008758 0.00889  0.008935 0.00889  0.008758 0.008542 0.008248 0.007886
		// 0.007691 0.008045 0.008331 0.008542 0.008671 0.008714 0.008671 0.008542 0.008331 0.008045 0.007691
		// 0.007427 0.007768 0.008045 0.008248 0.008373 0.008415 0.008373 0.008248 0.008045 0.007768 0.007427
		// 0.0071   0.007427 0.007691 0.007886 0.008005 0.008045 0.008005 0.007886 0.007691 0.007427 0.0071
		blurKernel[0] = 0.095474f;
		blurKernel[1] = 0.094998f;
		blurKernel[2] = 0.093585f;
		blurKernel[3] = 0.091276f;
		blurKernel[4] = 0.088139f;
		blurKernel[5] = 0.084264f;
		break;
	}
}


#pragma endregion TestRandomDungeon

