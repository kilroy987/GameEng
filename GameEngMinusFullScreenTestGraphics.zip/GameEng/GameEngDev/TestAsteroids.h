#pragma once

#define ASTEROIDS_VERSIONSTRING "0.99.011" // app version for display
// guid format .............. "12345678-1234-1234-1234-123456789012"
#define ASTEROIDS_VERSIONGUID "37d549yr-fl1e-1jf7-rsak-a0a1g1x7fja8" // verification for network login
#define ASTEROIDS_HOSTINGPORT_TCP 26010
#define ASTEROIDS_HOSTINGPORT_UDP 26011

// 0.99.004 9/30/2017
// first release

// 0.99.005 10/1/2017
// Improved bullet reporting accuracy so that other machines don't believe bullet was created on a gametime earlier than it actually was (at very close range, bullet was missing locally but hitting remotely)
// Added rules comments to Animate() and CheckForCollision() routines for clarity

// 0.99.006 10/1/2017
// Slower ships for easier dogfighting
// Can no longer hold ctrl or space to rapid fire
// Fixed exception from minimizing app

// 0.99.007 10/1/2017
// Fewer asteroids
// cancel maneuvering flames on other ship when shot and goes into death throes

// 0.99.008 10/1/2017
// cleaned up code for clearing flames on dying client ship
// ship will not control at all when dying (safer code)
// ship flashes out of cloak when dying or damaged
// report final drift of dying ship to other machines for accuracy

// 0.99.009 10/2/2017
// mistyped tags in chat text were not showing the <> symbols in chat
// moved debug values to central class to make it easier to create debugging situations
// improper tags did not parse properly (ex. '<<<color=ffffff>test' previously showed uncolored 'test', now correctly shows << and white 'test')
// window caption now says 'Multiplayer Asteroids'
// ship flames flicker more visibly
// pulsating powerups
// dev only - asteroid saturation adjustment added to app settings

// 0.99.010 10/6/2017
// connect routine no longer locks screen waiting for response (unless a host name is typed instead of a web address)
// user may cancel connection attempt if the connecting message is taking a while to show a result
// discovered bug that caused game times to fail to sync properly after host is up for around 10 minutes or more
// other player's cloaked ships only become partially visible for a short time instead of fully visible
// quick ship updates and secondary pings now sent by UDP - every 250ms a guaranteed ship update is still sent by TCP
// server now forwards bullets reported by clients to the other players - oops

// 0.99.011 10/13/2017
// in death throes, ships shake and slow to a standstill before exploding
// bandwidth reporting in player list now includes UDP sends and receives
// ship now fires with mouse button again, oops

// Primary todos:
// Very occasionally, a client will fail to destroy an asteroid or pick up a powerup even though a bullet registers a hit and the ship clearly passes through the powerup on the client
//    It could be if an asteroid has been drifting on its own for a long time that there are minute truncations in the operations and hence small variations between the host and player's 
//    calculated position of the asteroid from frame to frame.  Perhaps an occasional correction from the server on each powerup and asteroid would help this.
// Support ship collisions in multiplayer (reject ship positon updates from clients until they sent the correct game time version but accept controls, retcon host's report of ship's 
//    new position after a collision, applying controls to calculate new position, and sending that position back to the host, to account for client retconning and ships that slip into each other, 
//    handle ships that overlap (shove them away from each other with a burst of velocity), etc.)
// Support rare future object reporting (occurs when a machine pausing on a frame for any reason receives data for a gametime that hasn't occurred yet) - I think this is already supported
//    for powerups, bullets and asteroids (bullets clamp their collisions to minimumGameTimeMS), but ship position/controls would have to be saved until that time passes and animate appopriately inside
//    the ship animate loop.
// Handle ships drifting into asteroids because of updates that get them past the collision barrier (so rare, I haven't seen this yet)
// Rock-shaped asteroids, spinning
// Specific shaped powerups
// Replace graphics with 3d models, lighting, shadows, textures for powerups

#include "..\Headers\GameBase.h"
#include "..\Headers\Tools.h"
#include "..\Headers\GameContext.h"
#include "..\Headers\GameApplicationContext.h"
#include "..\Headers\GameUI.h"
#include "..\Headers\GameNetwork.h"

namespace GameEngDev {

	using namespace GameEng::Game;
	using namespace GameEng::Tools::Timer;
	using namespace GameEng::Tools::Random;
	using namespace GameEng::UI;
	using namespace GameEng::Network;
	using namespace GameEng::Math;
	using namespace GameEng::Graphics;
	using namespace System::Drawing; // RectangleF

	// values that interruption operations for basic debugging and testing needs
	public class AsteroidsDebugSettings
	{
	public:
		static const int maxAsteroidQty = -1;  // -1 means allow normal amount to be created
		static const int clientLagSimulationAmount = -1; // < -1 means random between 50 and 500, -1 means do not simulate lag, >= 0 means constant amount of lag to simulate (up to 2000)
		static const bool echoFutureRejectionPacket = false; // echo rejection of future gamestate activity (would occur on ship packets from machines reporting to the local machine which has a low frame rate)
	};

	// offical app settings
	public class AsteroidsAppSettings
	{
	public:
		static const float asteroidsSaturationLevel;  // 1.0f is normal, recommended max 20.0f - initialized in .cpp since float initializers are not allowed here
	};

	public class AsteroidsPlayfield
	{
	public:
		RectangleF bounds;

		Vector3d NormalizePositionWithPlayfield(Vector3d &p_position)
		{
			// make sure x,y is between [0,0 and playfield bounds)
			Vector3d newPosition = p_position;

			while (newPosition.x < bounds.X)
				newPosition.x += bounds.X;
			while (newPosition.x >= bounds.X)
				newPosition.x -= bounds.X;

			while (newPosition.y < bounds.Y)
				newPosition.y += bounds.Y;
			while (newPosition.y >= bounds.Y)
				newPosition.y -= bounds.Y;

			return newPosition;
		}

		Vector3d NormalizeOffsetWithPlayfield(Vector3d &p_offset)
		{
			// make sure vector is shortest distance that can be used to reach the position
			Vector3d newOffset = p_offset;

			while (newOffset.x > bounds.X / 2.0f)
				newOffset.x -= bounds.X;
			while (newOffset.x < -bounds.X / 2.0f)
				newOffset.x += bounds.X;

			while (newOffset.y > bounds.Y / 2.0f)
				newOffset.y -= bounds.Y;
			while (newOffset.y < -bounds.Y / 2.0f)
				newOffset.y += bounds.Y;

			return newOffset;
		}
	};

	public class AsteroidsStar
	{
	public:
		Vector2d position;
		GameColor color;
		float size;
		float moveScale;
	};

	public class AsteroidsPowerupType
	{
	public:
		static const int Health = 1;
		static const int Shield = 2;
		static const int Weapon = 3;
		static const int Cloak = 4;
	};

	class AsteroidsShipColor
	{
		friend class AsteroidsShipColorRegistry;

	public:
		AsteroidsShipColor()
		{
			used = false;
		}

		GameColor color;
		bool used;

		void Untag()
		{
			used = false;
		}

		void Tag()
		{
			used = true;
		}

		bool IsAvailable()
		{
			return (used == false);
		}

	private:
		void Set(GameColor &p_color)
		{
			color = p_color;
		}
	};

	public class AsteroidsShipColorRegistry
	{
	private:
		AsteroidsShipColor *colors;
		int colorQty;

		AsteroidsShipColor * FindShipColor(GameColor &p_color)
		{
			for (int i = 0; i < colorQty; i++)
				if (colors[i].color.CompareWithoutAlpha(p_color) == true)
					return &colors[i];

			return nullptr;
		}

	public:
		AsteroidsShipColorRegistry()
		{
			colors = new AsteroidsShipColor[16];
			colorQty = 16;

			// these must be unique or FreeColor doesn't work right!!!
			colors[0].Set(GameColor(255, 64, 64)); // red
			colors[1].Set(GameColor(255, 192, 64)); // orange
			colors[2].Set(GameColor(64, 255, 64)); // green
			colors[3].Set(GameColor(96, 96, 255)); // blue
			colors[4].Set(GameColor(255, 64, 255)); // purple
			colors[5].Set(GameColor(255, 255, 64)); // yellow
			colors[6].Set(GameColor(64, 255, 255)); // cyan
			colors[7].Set(GameColor(160, 160, 160)); // light gray

			colors[8].Set(GameColor(255, 160, 160)); // bright red
			colors[9].Set(GameColor(255, 240, 160)); // bright orange
			colors[10].Set(GameColor(160, 255, 160)); // bright green
			colors[11].Set(GameColor(160, 160, 255)); // bright blue
			colors[12].Set(GameColor(255, 160, 255)); // bright purple
			colors[13].Set(GameColor(255, 255, 160)); // bright yellow
			colors[14].Set(GameColor(160, 255, 255)); // bright cyan
			colors[15].Set(GameColor(192, 192, 192)); // lighter gray

			Verify();
		}

		~AsteroidsShipColorRegistry()
		{
			if (colors != nullptr)
			{
				delete [] colors;
				colors = nullptr;
				colorQty = 0;
			}
		}

		GameColor GetAvailableColor()
		{
			for (int i = 0; i < colorQty; i++)
			{
				if (colors[i].IsAvailable() == true)
				{
					colors[i].Tag();
					return colors[i].color;
				}
			}

			throw gcnew Exception(String::Format("No colors available! - need more than {0} colors!!!", colorQty));
		}

		void FreeColor(GameColor &p_color)
		{
			AsteroidsShipColor *color = FindShipColor(p_color);
			if (color != nullptr)
				color->Untag();
		}

		int GetColorQty()
		{
			return colorQty;
		}

		int GetAvailableColorQty()
		{
			int count = 0;
			for (int i = 0; i < colorQty; i++)
			{
				if (colors[i].IsAvailable() == true)
					count++;
			}

			return count;
		}

	private:
		void Verify()
		{
			for (int i = 0; i < colorQty - 1; i++)
			{
				for (int j = i + 1; j < colorQty; j++)
				{
					if (colors[i].color.CompareWithoutAlpha(colors[j].color) == true)
						throw gcnew Exception(String::Format("Colors are not unique!  Index {0} machs index {1}", i, j));
				}
			}
		}
	};

	public class AsteroidsShip
	{
	public:
		int Id; // for updating by server

		Vector3d position;
		Vector3d velocity;
		float rotationAngle; // where is the ship facing?
		float radius; // determines collision model, and render size
		int shotsFired; // max 4, increments as shots go away, server might reject if ship has 4 shots up already - tally still kept even after ship destroyed
		GameColor color;

		float health; // if 0, ship cannot be controlled
		float shield;
		float boostFuel;
		int superWeaponShots;
		float cloakMS;
		bool destroyed; // if true, ship is invisible and camera no longer follows it (ship is not deleted, it is simply reset and restored somewhere else)

		// controls
		bool thrust; // normal forward acceleration
		bool boost; // super acceleration
		bool backwards; // backwards acceleration
		// sliding
		bool left;
		bool right;
		int spinDirection; // 0 none, 1 to the right, -1 to the left
		bool shoot; // shooting on next Animate? (one shot only)

		float rotationAnglePerMS; // how fast is the spin?  (positive only, spinDirection determines direction of spin)

		// flame flickering
		// if both are off, go ahead and render flame if rendering flame is relevant
		float onFlameTimerMS;
		float offFlameTimerMS;

		bool appliedBoost; // did we apply boost on the final iteration of animation?  Set in Animate();

		Vector3d moveOffset; // for collision detection (position = priorPosition + moveOffset)

		int lastGameTimeUpdatedByServerMS; // for version control on updates (server will reject a position and velocity update on a ship with version that isn't caught up to its version)
		int lastGameTimeUpdatedByPacketMS; // puts a general lock on a ship being updated by packet, since UDP packets can arrive out of order, faster than TCP, twice, etc.

		float elapsedTimeMSRemainder; // how much of a decimal is left from last time?  Adds to next time elapsed.
		float respawnTimerMS; // time to respawn
		float deathThroesMS; // if > 0.0 ship is spinning out of control abotu to explode
		float deathThroeRotationAnglePerMS;

		float deathThroesColorCycleMS; // timer that advances during deaththroes to determine color to render
		float damageFlashMS; // counts down to zero, fades white to color
		float damageMeterMS; // should the ship's health be displayed above it?

		float maxHealth;
		float maxShield;
		float maxBoostFuel;
		int maxSuperWeaponShots;
		float maxCloakMS;

		int playerId; // which player controls it?

		static int nextShipId;

		bool priorThrust;
		bool priorBackwards;
		bool priorBoost;
		bool priorLeft;
		bool priorRight;
		int priorSpinDirection;

		int timeSinceSentToPlayersMS;

		AsteroidsShip()
		{
			// initialization values to be set when object firest created, not touched when structure reinitialized when ship restored

			maxHealth = 100.0f;
			maxBoostFuel = 1500.0f;
			maxShield = 50.0f;
			maxSuperWeaponShots = 20;
			maxCloakMS = 10000.0f;
		}

		static int GetNextShipId()
		{
			nextShipId++;
			if (nextShipId == 0)
				nextShipId++;
			return nextShipId;
		}

		void Initialize(bool p_getId = true, bool p_requireRespawn = true) // call when ship created or recreated as a node
		{
			if (p_getId == true)
				Id = GetNextShipId();

			shotsFired = 0; // assume no shots on playfield from this ship yet
			rotationAnglePerMS = 5.0f * 360.0f / 5.0f / 1000.0f; // spin 5 times in 5 seconds
			radius = 18.0f; // a little larger than small asteroid for now

			color.Set(255, 255, 255);

			elapsedTimeMSRemainder = 0.0f;

			position = Vector3d::ZeroVector();
			Restore();

			if (p_requireRespawn == true)
			{
				// don't let it render or control just yet, it hasn't been spawned
				health = 0.0f;
				destroyed = true;
			}

			playerId = -1;

			lastGameTimeUpdatedByPacketMS = 0;
			lastGameTimeUpdatedByServerMS = 0;
		}

	private:
		void Restore() // call when ship placed back on field after destroyed
		{
			destroyed = false;
			health = maxHealth;
			shield = 0.0f;
			boostFuel = maxBoostFuel;
			superWeaponShots = 0;
			cloakMS = 0.0f;

			CancelControls();

			static FastRandom fastRandom; // prevents many ships created in immediate succession from having the same rotation
			rotationAngle = float(fastRandom.GetRandomInteger(0, 359));

			velocity = Vector3d::ZeroVector();
			moveOffset = Vector3d::ZeroVector();

			respawnTimerMS = 0.0f;
			deathThroesMS = 0.0f;
			deathThroeRotationAnglePerMS = 0.0f;
			damageFlashMS = 0.0f;
			damageMeterMS = 0.0f;

			timeSinceSentToPlayersMS = 0;

			onFlameTimerMS = 0;
			offFlameTimerMS = 0;
		}

		void ResetDamageFlash()
		{
			damageFlashMS = 250.0f;
		}

		void StartDamageMeter()
		{
			damageMeterMS = 2000.0f;
		}

		void StartDeathThroes()
		{
			// explode in 4 seconds unless more damage comes in or an asteroid collides
			deathThroesMS = 4000.0f;
			deathThroesColorCycleMS = 0.0f;
			damageFlashMS = 0.0f;
			damageMeterMS = 0.0f;

			CancelControls();
		}

	public:
		void CancelControls()
		{
			thrust = false;
			backwards = false;
			boost = false;
			left = false;
			right = false;
			spinDirection = 0;

			shoot = false;
		}

		void RecordPriorControls()
		{
			priorThrust = thrust;
			priorBackwards = backwards;
			priorBoost = boost;
			priorLeft = left;
			priorRight = right;
			priorSpinDirection = spinDirection;
		}

		bool ControlsChanged()
		{
			return (
				priorThrust != thrust ||
				priorBackwards != backwards ||
				priorBoost != boost ||
				priorLeft != left ||
				priorRight != right ||
				priorSpinDirection != spinDirection);
		}

		void DestroyShip() // game event, not object maintenenace
		{
			health = 0.0f;
			destroyed = true;
			velocity = Vector3d(0, 0, 0);
			moveOffset = Vector3d::ZeroVector();
			respawnTimerMS = 2000.0f;
			deathThroesMS = 0.0f;
			damageFlashMS = 0.0f;
			damageMeterMS = 0.0f;

			CancelControls();
		}

		bool IsTimeToExplode()
		{
			return (health == 0.0f && deathThroesMS == 0.0f && destroyed == false);
		}

		bool IsDestroyed()
		{
			return destroyed;
		}

		bool IsAlive()
		{
			return (health > 0.0f);
		}

		bool IsReadyToRespawn()
		{
			return (respawnTimerMS == 0.0 && destroyed == true);
		}

		bool IsCloaked()
		{
			return (cloakMS > 0.0f);
		}

		float GetCloakedAlpha(bool p_shipHasFocus)
		{
			// return 0.0-1.0
			if (cloakMS <= 0.0f)
				return 1.0f;

			float minimumAlpha = 0.0f;
			float maximumAlpha = 0.5f;
			if (p_shipHasFocus == true) // spectator or controller can see his own ship better
			{
				minimumAlpha = 0.40f;
				maximumAlpha = 0.80f;
			}

			// every 2000.0ms, the cloak cycles.
			// 250.0ms before the 2000.0f multiple, the ship fades in (at 0.0, max alpha)
			// 250.0ms after the 2000.0f multiple, the ship fades out (at 0.0, max alpha)
			int multiple = int(cloakMS / 2000.0f + 0.5f);
			float value = cloakMS - float(multiple) * 2000.0f;
			if (value < 0.0f)
			{
				if (value >= -250.0f)
				{
					return minimumAlpha + (maximumAlpha - minimumAlpha) * (-250.0f - value) / -250.0f;
				}
			}
			else if (value < 250.0f)
			{
				return minimumAlpha + (maximumAlpha - minimumAlpha) * (250.0f - value) / 250.0f;
			}

			return minimumAlpha;
		}

		void SnapToPosition(PointF &p_position)
		{
			position = Vector3d(p_position.X, p_position.Y, 0.0f);
			moveOffset = Vector3d::ZeroVector();
			velocity = Vector3d::ZeroVector();
		}

		void ApplyDamage(float p_damage, bool p_damageMeterTimer)
		{
			if (shield > 0.0f)
			{
				if (shield < p_damage)
				{
					p_damage -= shield;
					shield = 0.0f;
				}
				else
				{
					shield -= p_damage;
					ResetDamageFlash();
					if (p_damageMeterTimer == true)
						StartDamageMeter();
					return; // damage didn't get through
				}
			}
			if (health > 0.0f)
			{
				if (health <= p_damage)
				{
					p_damage -= health; // overflow to deaththroe timer below
					StartDeathThroes();
					health = 0.0f;
				}
				else
				{
					health -= p_damage;
					ResetDamageFlash();
					if (p_damageMeterTimer == true)
						StartDamageMeter();
				}
			}

			if (health == 0.0f)
			{
				float deathThroeDamage = p_damage * 35.0f;
				if (deathThroesMS <= deathThroeDamage)
				{
					// time to explode!
					deathThroesMS = 0.0f;
				}
				else
				{
					deathThroesMS -= deathThroeDamage;
					FastRandom fastRandom;
					// spin really fast at first, will slow down later for the explosion
					if (fastRandom.GetRandomInteger(1,2) == 1)
						deathThroeRotationAnglePerMS = float(fastRandom.GetRandomInteger(10, 40)) / 20.0f * 720.0f / 1000.0f;
					else
						deathThroeRotationAnglePerMS = float(fastRandom.GetRandomInteger(-10, -40)) / 20.0f * 720.0f / 1000.0f;
				}
			}
		}

		bool InDeathThroes()
		{
			return (deathThroesMS > 0.0f);
		}

		bool DisplayHealthMeter()
		{
			return (damageMeterMS > 0.0);
		}

		GameColor GetHealthMeterColor()
		{
			if (health >= 50.0f)
				return GameColor(32, 255, 32);
			else if (health >= 25.0f)
				return GameColor(255, 255, 32);
			else
				return GameColor(255, 32, 32);
		}

		float GetHealthMeterFillPercentage()
		{
			return health / maxHealth;
		}

		float GetShieldMeterFillPercentage()
		{
			return shield / maxShield;
		}

		float GetBoostMeterFillPercentage()
		{
			return boostFuel / maxBoostFuel;
		}

		void Animate(float p_elapsedTimeMS, AsteroidsPlayfield &p_playfield, bool p_ignoreRenderTimers = false)
		{
			if (respawnTimerMS > 0.0f)
			{
				respawnTimerMS -= p_elapsedTimeMS;
				if (respawnTimerMS < 0.0f)
					respawnTimerMS = 0.0f;
			}

			if (p_ignoreRenderTimers == false)
			{
				if (damageMeterMS > 0.0f)
				{
					damageMeterMS -= p_elapsedTimeMS;
					if (damageMeterMS < 0.0f)
						damageMeterMS = 0.0f;
				}

				if (damageFlashMS > 0.0f)
				{
					damageFlashMS -= p_elapsedTimeMS;
					if (damageFlashMS < 0.0f)
						damageFlashMS = 0.0f;
				}
			}

			if (cloakMS > 0.0f)
			{
				cloakMS -= p_elapsedTimeMS;
				if (cloakMS < 0.0f)
					cloakMS = 0.0f;
			}

			//if (boostFuel < maxBoostFuel)
			//{
			//	boostFuel += p_elapsedTimeMS * 0.5f;
			//	if (boostFuel > maxBoostFuel)
			//		boostFuel = maxBoostFuel;
			//}

			appliedBoost = false; // affects rendering - did we have enough boost to apply it?

			if (InDeathThroes())
			{
				if (p_ignoreRenderTimers == false)
					deathThroesColorCycleMS += p_elapsedTimeMS;

				if (deathThroesMS <= p_elapsedTimeMS)
				{
					// time to explode.
					deathThroesMS = 0.0f;
					return;
				}
				else
				{
					deathThroesMS -= p_elapsedTimeMS;

					// spin the ship, slow it down when it's about to explode
					rotationAngle += deathThroeRotationAnglePerMS * p_elapsedTimeMS * GetDeathThroeAnimationFactor();
					while (rotationAngle >= 360.0f)
						rotationAngle -= 360.0f;
					while (rotationAngle < 0.0f)
						rotationAngle += 360.0f;
				}
			}

			if (IsDestroyed() == true)
				return;

			// incorporate remainder from last time
			// this works for the benefit of slowMotion but should not be necessary for normal gameplay
			int timeToConsumeMS = int(p_elapsedTimeMS + elapsedTimeMSRemainder + 0.0001f); // just being safe
			elapsedTimeMSRemainder = p_elapsedTimeMS + elapsedTimeMSRemainder - float(timeToConsumeMS);

			// these represent fair maximum travel speeds
			// now I just need to come up with a true acceleration every 10ms and calculate new velocities accordingly (need a good acceleration and resistance value)
			float power = 0.0f;
			float slide = 0.0f;

			Vector3d priorPosition = position;
			float powerFactor = 0.001f;
			float resistanceFactor = 0.999f;
			while (timeToConsumeMS > 0)
			{
				timeToConsumeMS -= 1;

				if (InDeathThroes() == false)
				{
					// ship can operate under its controls

					// rotate ship
					if (spinDirection > 0)
					{
						rotationAngle += rotationAnglePerMS;
						while (rotationAngle >= 360.0f)
							rotationAngle -= 360.0f;
					}
					else if (spinDirection < 0)
					{
						rotationAngle -= rotationAnglePerMS;
						while (rotationAngle < 0.0f)
							rotationAngle += 360.0f;
					}

					float radians = MathUtilities::DegreesToRadians(rotationAngle);
					Vector3d powerUnitVector = Vector3d(sin(radians), -cos(radians), 0.0f);
					Vector3d slideUnitVector = Vector3d(-cos(radians), -sin(radians), 0.0f);

					// move ship
					if (boost == true && boostFuel >= 1.0f)
					{
						boostFuel -= 1.0f;

						if (thrust == true)
						{
							power = 1.5f;
						}
						else if (backwards == true)
						{
							power = -1.2f;
						}
						else
							power = 0.0f;

						if (left == true)
						{
							slide = 1.2f;
						}
						else if (right == true)
						{
							slide = -1.2f;
						}
						else
							slide = 0.0f;

						appliedBoost = true; // affects rendering - did we have enough boost to apply it?
					}
					else
					{
						if (thrust == true)
						{
							power = 0.75f;
						}
						else if (backwards == true)
						{
							power = -0.6f;
						}
						else
							power = 0.0f;

						if (left == true)
						{
							slide = 0.6f;
						}
						else if (right == true)
						{
							slide = -0.6f;
						}
						else
							slide = 0.0f;

						appliedBoost = false; // affects rendering - did we have enough boost to apply it?
					}

					// powerFactor is fine here for both slide and power, it's just a scaling to apply the amount per MS
					Vector3d powerVector = powerUnitVector.ScalarMult(power * powerFactor);
					Vector3d slideVector = slideUnitVector.ScalarMult(slide * powerFactor);

					// apply 1ms worth of acceleration
					velocity = velocity + powerVector; // affect velocity
					velocity = velocity + slideVector;

					boostFuel += 0.5f; // regen boost fuel
					if (boostFuel > maxBoostFuel)
						boostFuel = maxBoostFuel;
				} // not in death throes

				// 1ms worth of movement
				position = position + velocity.ScalarMult(1.0f);
				// apply 1ms worth of resistance
				velocity = velocity.ScalarMult(resistanceFactor); // slow down
			}
			position = p_playfield.NormalizePositionWithPlayfield(position);
			moveOffset = p_playfield.NormalizeOffsetWithPlayfield(position - priorPosition);
		}

		float GetDeathThroeAnimationFactor()
		{
			float adjustAmountMS = 250.0f;
			float amount = deathThroesMS - adjustAmountMS;
			if (amount < 0.0f)
				amount = 0.0f;
			return float(pow((amount / (4000.0f - adjustAmountMS)), 0.75f));  // animation full until close to explode then suddenly stop
		}

		GameColor GetRenderColor(bool p_isRenderFocusShip)
		{
			// if dying or struck, cloak fails while the flash effect occurs
			if (InDeathThroes())
			{
				float cycleValue = 1000.0f;
				if (deathThroesMS < 1000.0f)
					cycleValue = 125.0f;
				else if (deathThroesMS < 2000.0f)
					cycleValue = 500.0f;

				// every 1000.0f, cycle from white to the color
				while (deathThroesColorCycleMS >= cycleValue)
				{
					deathThroesColorCycleMS -= cycleValue;
				}

				return GameColor::Interpolate(GameColor(255, 255, 255), color, deathThroesColorCycleMS / cycleValue);
			}
			else if (damageFlashMS > 0.0f)
			{
				// let ship go back to any cloak as flash wears off
				return GameColor::Interpolate(GameColor(color.red, color.green, color.blue, int(255.0f * GetCloakedAlpha(p_isRenderFocusShip))), GameColor(255, 255, 255), damageFlashMS / 250.0f);
			}

			// not dying or struck, so include cloak
			GameColor returnColor = color;
			returnColor.alpha = int(255.0f * GetCloakedAlpha(p_isRenderFocusShip));
			return returnColor;
		}

		Vector3d GetForwardVector()
		{
			// 0.0 is straight up
			float frontRadians = MathUtilities::DegreesToRadians(rotationAngle);
			Vector3d shipFrontVector = Vector3d(sin(frontRadians), -cos(frontRadians), 0.0f);
			return shipFrontVector;
		}

		Vector3d GetBulletStartPosition(AsteroidsPlayfield &p_playfield)
		{
			float bulletStartRadius = 1.4f;
			return p_playfield.NormalizePositionWithPlayfield(position + GetForwardVector().ScalarMult(bulletStartRadius * radius));  // just beyond tip of ship
		}

		bool CanBeControlled()
		{
			return (health > 0);
		}

		void Respawn(PointF &p_position)
		{
			SnapToPosition(p_position);
			Restore();
		}

		bool AddHealth(float p_health, bool p_testOnly = false)
		{
			if (health < maxHealth)
			{
				if (p_testOnly == false)
				{
					health += p_health;
					if (health > maxHealth)
						health = maxHealth;
				}

				return true;
			}
			else
				return false;
		}

		bool AddShield(float p_shield, bool p_testOnly = false)
		{
			if (shield < maxShield)
			{
				if (p_testOnly == false)
				{
					shield += p_shield;
					if (shield > maxShield)
						shield = maxShield;
				}

				return true;
			}
			else
				return false;
		}

		bool AddSuperWeaponShots(int p_weaponShots, bool p_testOnly = false)
		{
			if (superWeaponShots < maxSuperWeaponShots)
			{
				if (p_testOnly == false)
				{
					superWeaponShots += p_weaponShots;
					if (superWeaponShots > maxSuperWeaponShots)
						superWeaponShots = maxSuperWeaponShots;
				}

				return true;
			}
			else
				return false;
		}

		bool AddCloak(float p_cloakMS, bool p_testOnly = false)
		{
			if (cloakMS < maxCloakMS)
			{
				if (p_testOnly == false)
				{
					cloakMS += p_cloakMS;
					if (cloakMS > maxCloakMS)
						cloakMS = maxCloakMS;
				}

				return true;
			}
			else
				return false;
		}
	};

	public class AsteroidsPowerup
	{
	public:
		int Id;
		int type;

		float renderRadius;
		float captureRadius;

		Vector3d position;
		Vector3d velocity;
		Vector3d moveOffset;

		static int nextPowerupId;

		int minimumGameTimeMS; // when was it created? (affects rendering and allowed collisions)

		float lifeMS; // advancing timer used for rendering (pulsating radius, etc.)

		void Initialize(bool p_getId = true)
		{
			Id = GetNextPowerupId();
			renderRadius = 10.0f; // smaller than smallest asteroid to stand out
			captureRadius = 5.0f; // have to fly into it to pick it up
			lifeMS = 0;
		}

		int GetNextPowerupId()
		{
			nextPowerupId++;
			if (nextPowerupId == 0)
				nextPowerupId++;

			return nextPowerupId;
		}

		GameColor GetRenderColor()
		{
			switch (type)
			{
			case AsteroidsPowerupType::Health:
				return GameColor(32, 255, 32);
				break;
			case AsteroidsPowerupType::Shield:
				return GameColor(32, 255, 255);
				break;
			case AsteroidsPowerupType::Weapon:
				return GameColor(240, 32, 32);
				break;
			case AsteroidsPowerupType::Cloak:
				return GameColor(255, 32, 255);
				break;
			default:
				throw gcnew Exception(String::Format("Unsupported Powerup type '{0}'", type));
			}
		}

		static int GetRandomPowerupType()
		{
			static FastRandom fastRandom;
			int value = fastRandom.GetRandomInteger(1, 100);
			if (value <= 25)
				return AsteroidsPowerupType::Health;
			if (value <= 50)
				return AsteroidsPowerupType::Shield;
			if (value <= 75)
				return AsteroidsPowerupType::Weapon;
			return AsteroidsPowerupType::Cloak;
		}

		void Animate(float p_elapsedTimeMS, AsteroidsPlayfield &p_playfield)
		{
			moveOffset = velocity.ScalarMult(p_elapsedTimeMS);
			position = p_playfield.NormalizePositionWithPlayfield(position + moveOffset);

			lifeMS += p_elapsedTimeMS;
		}

		static bool ApplyToShip(int p_type, AsteroidsShip *p_ship, bool p_testOnly = false)
		{
			switch (p_type)
			{
			case AsteroidsPowerupType::Health:
				return p_ship->AddHealth(50.0f, p_testOnly);
				break;
			case AsteroidsPowerupType::Shield:
				return p_ship->AddShield(50.0f, p_testOnly);
				break;
			case AsteroidsPowerupType::Weapon:
				return p_ship->AddSuperWeaponShots(20, p_testOnly);
				break;
			case AsteroidsPowerupType::Cloak:
				return p_ship->AddCloak(10000.0f, p_testOnly);
				break;
			default:
				throw gcnew Exception(String::Format("Unsupported Powerup type '{0}'", p_type));
			}
		}
	};

	// todo: if bullet hits something on screen but not on server, server should reject bullet.   If bullet hits something on server but not on screen, server should tell client to remove it.
	public class AsteroidsBullet
	{
	public:
		int Id; // only for server to tell clients to remove it - id is selected by client/owner combo, since clients decide their own id, so it's only unique within the ship owner id
		AsteroidsShip *ownerRef; // which ship fired it?  (for this reason, NEVER delete a ship - leave it destroyed and existing until it is restored - that is, until the entire storage is wiped)

		static int nextBulletId;

		bool newBullet; // was it just made this tick?

		Vector3d position;
		Vector3d velocity;
		float radius; // most are tiny, some might be large
		float lifeMS; // how much life is left before it disappears

		Vector3d moveOffset; // for collision detection (position = priorPosition + moveOffset)

		bool removeAfterAnimate;  // bullet has reached the end of its life.  Last chance to collide with anything before it is removed.
		float factorTravelled; // will be <= 1.0 when removeAfterAnimate = true, otherwise always true - multiply this by moveOffsets of other objects testing against and consider when comparing for first collision
							   // this bullet's moveOffset represetns its full movement.  For objects checking collision against, go back their full moveOffset then forward by this factor to get collision check values.

		bool justFired; // not animated, just sitting there for overlap collision check only (check current positions)
		bool super; // is it a super shot? (more damage)

		int minimumGameTimeMS; // bullet might be in the future from another box, so don't let any collisions happen before then

		AsteroidsBullet()
		{
		}

	private:
		int GetNextBulletId()
		{
			nextBulletId++;
			if (nextBulletId == 0)
				nextBulletId++;
			return nextBulletId;
		}

	public:
		void Initialize(bool p_getId = true)
		{
			if (p_getId == true)
				Id = GetNextBulletId();

			newBullet = true;

			moveOffset = Vector3d::ZeroVector();
			velocity = Vector3d::ZeroVector();
			removeAfterAnimate = false;
			factorTravelled = 1.0f;
			lifeMS = 0;
			justFired = true;
			super = false;

			minimumGameTimeMS = 0;
		}

		void SetPositionVelocityLifeRadius(AsteroidsShip *p_ownerRef, Vector3d &p_position, Vector3d &p_velocity, float p_lifeMS, float p_radius, bool p_super = false)
		{
			ownerRef = p_ownerRef;
			position = p_position;
			velocity = p_velocity;
			lifeMS = p_lifeMS;
			radius = p_radius;
			super = p_super;
		}

		void SetRemoveAfterAnimate(float p_factorTravelled)
		{
			removeAfterAnimate = true;
			factorTravelled = p_factorTravelled;
		}

		void Animate(float p_elapsedTimeMS, AsteroidsPlayfield &p_playfield)
		{
			justFired = false;

			if (lifeMS == 0.0f)
				throw gcnew Exception("This bullet should have been removed by now!  LifeMS = 0");

			float timeToConsumeMSf = p_elapsedTimeMS;
			if (lifeMS <= p_elapsedTimeMS)
			{
				timeToConsumeMSf = lifeMS;
				SetRemoveAfterAnimate(lifeMS / p_elapsedTimeMS); // factor of how far along the full gametick the bull moved (everyone else moved from 0.0-1.0, this bullet moved from 0.0-factor)
				lifeMS = 0.0f;
			}
			else
				lifeMS -= p_elapsedTimeMS;

			Vector3d priorPosition = position;
			moveOffset = velocity.ScalarMult(timeToConsumeMSf); // since moveOffset represents priorPosition to current backwards, we can't extend it to 1.0 for consistency in the collision routine
			position = p_playfield.NormalizePositionWithPlayfield(position + moveOffset);
		}
	};

	// these are ints instead of enums so that network packets can send their values
	public class AsteroidType
	{
	public:
		static const int Large = 1;
		static const int Medium = 2;
		static const int Small = 3;
	};

	public class AsteroidsAsteroid
	{
		static int nextAsteroidId;
		int NextAsteroidId()
		{
			nextAsteroidId++; // doesn't matter if it loops, as long as it's unique
			return nextAsteroidId;
		}

	public:
		int Id; // for updating by server

		Vector3d position;
		Vector3d velocity;
		int type; // large, medium, small
		float radius;
		int minimumGameTimeMS; // versioning for server

		Vector3d moveOffset; // for collision detection (position = priorPosition + moveOffset)

		void Initialize(bool p_getId = true)
		{
			if (p_getId == true)
				Id = NextAsteroidId();
			minimumGameTimeMS = 0; // clients will always have 0 here
		}

		void SetPositionVelocityAndRadius(PointF &p_position, PointF &p_velocity, float p_radius)
		{
			position = Vector3d(p_position.X, p_position.Y, 0.0f);
			velocity = Vector3d(p_velocity.X, p_velocity.Y, 0.0f);
			radius = p_radius;

			moveOffset = Vector3d::ZeroVector();
		}

		void SetPositionMoveOffsetVelocityAndRadius(PointF &p_position, PointF &p_priorPosition, PointF &p_velocity, float p_radius)
		{
			position = Vector3d(p_position.X, p_position.Y, 0.0f);
			moveOffset = position - Vector3d(p_priorPosition.X, p_priorPosition.Y, 0.0f);
			velocity = Vector3d(p_velocity.X, p_velocity.Y, 0.0f);
			radius = p_radius;
		}

		void Animate(float p_elapsedTimeMS, AsteroidsPlayfield &p_playfield)
		{
			moveOffset = velocity.ScalarMult(p_elapsedTimeMS);
			position = p_playfield.NormalizePositionWithPlayfield(position + moveOffset);
		}
	};

	public class AsteroidsExplosion
	{
	public:
		Vector3d position;
		float radius;
		GameColor color;
		float radiusIncreasePerMS;
		float lifeMS; // life left
		float maxLifeMS; // what life did it start with?

		bool animate;
		bool deleteIt;

		void Initialize()
		{
			animate = false; // don't animate an explosion the first frame it is created.  set this to true when the explosion is rendered so that later frames animate it.
			deleteIt = false;
		}

		void SetValues(Vector3d &p_position, GameColor &p_color, float p_startingRadius, float p_expansionRatePerMS, float p_lifeMS)
		{
			position = p_position;
			color = p_color;
			radius = p_startingRadius;
			radiusIncreasePerMS = p_expansionRatePerMS;
			lifeMS = p_lifeMS;
			maxLifeMS = p_lifeMS;
		}

		void Animate(float p_elapsedTimeMS)
		{
			if (animate == false)
				return;
			if (deleteIt == true)
				return;

			if (lifeMS <= p_elapsedTimeMS)
				deleteIt = true;
			else
			{
				radius += radiusIncreasePerMS * p_elapsedTimeMS;
				lifeMS -= p_elapsedTimeMS;
			}
		}
	};

	enum class AsteroidsGameType
	{
		None,
		SinglePlayer,
		Multiplayer
	};

	class AsteroidsCamera
	{
	private:
		Vector3d currentPosition;

	public:
		AsteroidsCamera()
		{
			currentPosition = Vector3d::ZeroVector();
		}

		void SnapToPosition(Vector3d &p_position)
		{
			currentPosition = p_position;
		}

		Vector3d GetCameraCenter(Vector3d &p_newTargetCenter, float p_elapsedTimeMS, AsteroidsPlayfield &p_playfield)
		{
			// todo: I still want to get a more stable position based on target velocity, rather than use time elapsed, because it gets jittery with unable frame rates
			// But time seems to need to be involved because I want the camera to catch up with the ship consistently on each machine.  not sure how to do this yet.
			currentPosition = (p_playfield.NormalizeOffsetWithPlayfield(p_newTargetCenter - currentPosition)).ScalarMult(1.0f - pow(0.993f, p_elapsedTimeMS)) + currentPosition;
			currentPosition = p_playfield.NormalizePositionWithPlayfield(currentPosition);
			return currentPosition;
		}
	};

	public class AsteroidsBulletList : public LinkedList<AsteroidsBullet>
	{
	public:
		void AddBullet(LinkedListNode<AsteroidsBullet> *bulletNode)
		{
			if (GameContext::Instance->GetNetwork()->IsActive() == false || bulletNode->data.ownerRef->Id == GameContext::Instance->GetNetwork()->GetLocalUserId())
				bulletNode->data.ownerRef->shotsFired++;

			LinkedList<AsteroidsBullet>::AddNode(bulletNode);
		}

		void RemoveBullet(LinkedListNode<AsteroidsBullet> *bulletNode)
		{
			if (GameContext::Instance->GetNetwork()->IsActive() == false || bulletNode->data.ownerRef->Id == GameContext::Instance->GetNetwork()->GetLocalUserId())
			{
				bulletNode->data.ownerRef->shotsFired--;
				if (bulletNode->data.ownerRef->shotsFired < 0)
					throw gcnew Exception("Shots fired now < 0!");
			}

			LinkedList<AsteroidsBullet>::DeleteNode(bulletNode);
		}
	};

	public class AsteroidsAsteroidList : public LinkedList<AsteroidsAsteroid>
	{
	public:
		void AddAsteroid(LinkedListNode<AsteroidsAsteroid> *p_asteroidNode)
		{
			LinkedList<AsteroidsAsteroid>::AddNode(p_asteroidNode);
		}

		void RemoveAsteroid(LinkedListNode<AsteroidsAsteroid> *p_asteroidNode)
		{
			LinkedList<AsteroidsAsteroid>::DeleteNode(p_asteroidNode);
		}
	};

	public class AsteroidsExplosionList : public LinkedList<AsteroidsExplosion>
	{
	public:
		void AddExplosion(Vector3d &p_position, GameColor &p_color, float p_startingRadius, float p_expansionRatePerMS, float p_lifeMS)
		{
			LinkedListNode<AsteroidsExplosion> *newExplosion = GetNewNode();
			newExplosion->data.Initialize();
			newExplosion->data.SetValues(p_position, p_color, p_startingRadius, p_expansionRatePerMS, p_lifeMS);
			LinkedList<AsteroidsExplosion>::AddNode(newExplosion);
		}

		void RemoveExplosion(LinkedListNode<AsteroidsExplosion> *p_explosionNode)
		{
			LinkedList<AsteroidsExplosion>::DeleteNode(p_explosionNode);
		}
	};


	// used by AsteroidsMessageList to render its contents
	public class AsteroidsGameRenderMessage
	{
	public:
		// not rendered
		int line; // which message is this a part of? (line = 0, 1, 2 are messages 0, 1, 2 from the original list - not really lines 0, 1, 2)
		int feed; // which line feed within a message is this? (helps with location evaluation on the post parse
		float textHeight; // used to determine where to render a line (tall fonts shift the whole line down - nothing is centered vertically on a line)

		// rendered
		gcroot<String ^> message; // format string <color=ffddee> </color> <b></b> <font=Info></font> - note: font overrides font used by <b>
		gcroot<GameFont ^> fontRef;
		PointF location; // screen location to render
		GameColor color; // base color - alpha is determined during rendering - that way restore colors are less complicated
		float lifeMS; // helps with determination of alpha at render time (color is modulated by it)
		Point textSize; // might as well track this since we need to do multiple parses on the data
	};

	public class AsteroidsGameMessage
	{
	public:
		gcroot<String ^> message; // format string <color=ffddee> </color> <b></b> <font=Info></font> - note: font overrides font used by <b>
		float lifeMS; // counts down to zero, last 500ms fades out
		bool persistAfterFade; // don't destroy after it fades out, so it can be rendered in a different mode

		void Initialize()
		{
			message = "";
			lifeMS = 0.0f;
			persistAfterFade = false;
		}

		void SetMessageAndLife(String ^p_message, float p_lifeMS = 4000.0f, bool p_persistAfterFade = false)
		{
			message = p_message;
			lifeMS = p_lifeMS;
			persistAfterFade = p_persistAfterFade;
		}

	};

	public class AsteroidsGameMessageTag
	{
	public:
		gcroot<String ^> tag;

		// values to restore
		GameColor restoreColor;
		gcroot<GameFont ^> restoreFont;
	};

	// rules:  tags must be nested properly.  does NOT support straddled tags.  
	// Ex:  "<b><color=ff45223>Hello I am the smart</color></b>" is valid. 
	// "<color=ff><font=Big>Derp derp</b></color>derp" is not,
	// and will be rendered as "Derp derp</b></color>derp" entirely as blue and bold because the tags weren't properly terminated
	public class AsteroidsGameMessageList
	{
	private:
		GameColor defaultColor;
		gcroot<GameFont^> defaultNormalFontRef;
		gcroot<GameFont^> defaultBoldFontRef;

		LinkedList<AsteroidsGameMessage> messages;
		RectangleF outputRectangle; // coordinates of where output gooes (1st message is on bottom, message beyond top don't get displayed, sentences wrap)

		float messageLifeMS;
		float messageBeginFadeMS;

	public:
		AsteroidsGameMessageList(GameColor &p_defaultColor, GameFont ^p_defaultNormalFont, GameFont ^p_defaultBoldFont, float p_messageLifeMS = 4000.0f, float p_messageBeginFadeMS = 500.0f)
		{
			defaultColor = p_defaultColor;
			defaultNormalFontRef = p_defaultNormalFont;
			defaultBoldFontRef = p_defaultBoldFont;

			messageLifeMS = p_messageLifeMS;
			messageBeginFadeMS = p_messageBeginFadeMS;
		}

		void SetFonts(GameFont ^p_defaultNormalFont, GameFont ^p_defaultBoldFont)
		{
			defaultNormalFontRef = p_defaultNormalFont;
			defaultBoldFontRef = p_defaultBoldFont;
		}

		~AsteroidsGameMessageList()
		{
			// nothing needs destroying
		}

		void Clear()
		{
			messages.Clear();
		}

		// note: message is a tagged message (colors, bold, etc.), which might wrap when it's rendered
		// later messages are earlier in the list, so the first nodes render the lowest on the screen
		// Each insertion here represents a single message.  The render list built in Render() is arranged so that the parsing properly coarses through text to position the elements properly
		void AddMessage(String ^p_message, bool p_persistAfterFade = false)
		{
			LinkedListNode<AsteroidsGameMessage> *newNode = messages.GetNewNode();
			newNode->data.Initialize();
			newNode->data.SetMessageAndLife(p_message, messageLifeMS, p_persistAfterFade);
			messages.InsertNode(newNode);
		}

		// elapsed time in this case is not dependent on game time as updated by the server - this is an independent game time.
		void Animate(float p_elapsedTimeMS)
		{
			LinkedListNode<AsteroidsGameMessage> *messageNode = messages.GetFirstNode();
			if (messageNode != nullptr)
			{
				while (messageNode != &(messages.footer))
				{
					LinkedListNode<AsteroidsGameMessage> *nextNode = messageNode->next;
					if (messageNode->data.lifeMS <= p_elapsedTimeMS)
					{
						if (messageNode->data.persistAfterFade == false)
							messages.DeleteNode(messageNode);
						else
							messageNode->data.lifeMS = 0.0f;
					}
					else
						messageNode->data.lifeMS -= p_elapsedTimeMS;

					messageNode = nextNode;
				}
			}
		}

		void Render(GraphicsBase *p_graphics, RectangleF &p_outputRectangle, int p_backgroundOffset, bool p_showPersistedMessages = false)
		{
			// todo:
			// if there are no new lines, none have been removed, and the shape of the outputRectangle (mroe notably its Width) has not changed, there is no reason to re-evaluate the
			//   render lines except to calculate their alpha again.
			// So for an upgrade, respond to appropriate changes and only re-evaluate or calculate what is necessary to accommodate the change.

			// assemble a render list of messages based on the output rectangle, lines are noted by the line number on each render node - line numbers will be together
			// a single line can be made up of different fonts, so the textheight for the line will be the tallest font, which then determines the y coordinate to render at for the whole line.

			// split by tags to determine attributes for each, start a new line of text when the current text wraps past the outputbox, stop when the bottom of the next line to render is
			// above the output box.
			// build a line with fonts and tagless text until a space or full word clips the end of the box, then start a new line, removing the space if the space caused the wrap.
			// spaces, dashes, periods and commas divide words.  dashes, periods and commas remain part of the word and wrap with the word if it clips the end of the box.
			// tags that don't evaluate validly are rendered exactly as they are, including a terminating tag (with no <b>, a </b> tag renders as is)
			// use stencil to clip upper vertical contents?  Is there a point to it?

			// how to render messages (will be discarded afterwards)
			LinkedList<AsteroidsGameRenderMessage> renderMessages; // text here 

			// parse data, building the render data
			LinkedListEnumerator<AsteroidsGameMessage> messageEnumerator = LinkedListEnumerator<AsteroidsGameMessage>(messages);
			LinkedList<AsteroidsGameMessageTag> tags;
			int currentLine = 1; // message, actually, not line, since a line is cut into feeds later
			float currentX = p_outputRectangle.Left; // never changes
			float currentY = p_outputRectangle.Bottom; // Y is always at the BOTTOM of the current line being worked, and will be changed when EvaluateLine is called.  Messages work their way up
			GameRichTextList richText;
			float lifeMS;
			bool skipped = false;
			while (messageEnumerator.MoveNext())
			{
				if (currentLine > 1 && skipped == false)
				{
					// Handle line feeds due of clipping right side, handle y coordinate placement, determine next Y to start at for future lines
					EvaluateLine(richText, renderMessages, currentLine - 1, p_outputRectangle.Width, currentX, currentY, lifeMS);
					richText.Clear();
				}
				skipped = false;

				AsteroidsGameMessage *gameMessage = &(messageEnumerator.Current()->data);
				lifeMS = gameMessage->lifeMS;
				if (p_showPersistedMessages == true && gameMessage->persistAfterFade == true)
					lifeMS = messageBeginFadeMS + 1.0f; // render as solid
				if (lifeMS == 0.0f)
				{
					// don't work on a faded message (might be persisted)
					skipped = true;
					continue;
				}
				int startIndex = 0;

				// reset tags for each gameMessage
				GameFont ^currentFont = defaultNormalFontRef;
				GameColor currentColor = defaultColor;

				bool done = false;
				while (done == false)
				{
					// split up this line.
					// each iteration, startIndex advances.
					int nextTagStart = gameMessage->message->IndexOf("<", startIndex);
					if (nextTagStart >= startIndex)
					{
						// collect as much as we can before we investigate an actual tage
						// watch for another tag (we dont' support nesting, so if we find more before a > just add it
						bool done = false;
						while (done == false)
						{
							// if find false tags (not supporting nesting), continue advancing until we find a suspected true tag strength between <>
							// ex. <<<color> ignore the first two << and prepare to collect the <color> string
							int tagStart = gameMessage->message->IndexOf("<", nextTagStart + 1);
							int tagEnd = gameMessage->message->IndexOf(">", nextTagStart + 1);
							if (tagStart >= 0 && tagEnd > tagStart)
							{
								nextTagStart = tagStart;
							}
							else
								break;
						}
					}
					if (nextTagStart >= startIndex)
					{
						if (nextTagStart > startIndex) // not an empty string before the <
							richText.AddText(gameMessage->message->Substring(startIndex, nextTagStart - startIndex), currentFont, currentColor);

						int nextTagEnd = gameMessage->message->IndexOf(">", nextTagStart);
						if (nextTagEnd < 0)
						{
							// tag not terminated, just add the remaining text
							richText.AddText(gameMessage->message->Substring(nextTagStart), currentFont, currentColor);

							currentLine++;
							break;;
						}
						else
						{
							startIndex = nextTagEnd + 1;

							// get tag
							bool valid = false; // if remains false, skip the tag and add it as text
							String ^tagText = gameMessage->message->Substring(nextTagStart + 1, nextTagEnd - nextTagStart - 1); // strip off < and >
							String ^trimmedTag = tagText->Trim()->ToLower();
							if (trimmedTag->Substring(0, 1) == "/")
							{
								// it's a terminating tag - see if it matches the last tag
								String ^tag = trimmedTag->Substring(1);
								if (tags.GetLastNode() != nullptr)
								{
									if (tags.GetLastNode()->data.tag == tag) // if it matchs it's one of the three below or something went very wrong
									{
										if (tag == "b" || tag == "font")
										{
											currentFont = tags.GetLastNode()->data.restoreFont;
										}
										else if (tag == "color")
										{
											currentColor = tags.GetLastNode()->data.restoreColor;
										}

										valid = true;

										// remove last node
										RemoveLastTag(tags);
									}
								}
							}
							else
							{
								// it's a starting tag - see if it's valid
								String ^token = "b";
								if (valid == false)
								{
									if (trimmedTag == token)
									{
										AddTag(tags, trimmedTag, currentColor, currentFont);
										currentFont = defaultBoldFontRef;
										valid = true;
									}
								}
								if (valid == false)
								{
									token = "font=";
									if (trimmedTag->StartsWith(token))
									{
										AddTag(tags, "font", currentColor, currentFont);
										String ^fontName = trimmedTag->Substring(token->Length)->Trim();
										if (GameContext::Instance->FontRegistry.FontExists(fontName) == true)
											currentFont = GameContext::Instance->FontRegistry.GetFont(fontName);
										valid = true;
									}
								}
								if (valid == false)
								{
									token = "color=";
									if (trimmedTag->StartsWith(token))
									{
										AddTag(tags, "color", currentColor, currentFont);
										String ^color = trimmedTag->Substring(token->Length)->Trim();
										if (GameColor::FromHexStringIsValid(color) == true)
											currentColor = GameColor::FromHexString(color);
										valid = true;
									}
								}
							}

							if (valid == false)
							{
								// no valid result, just add the tag as text
								richText.AddText("<" + tagText + ">", currentFont, currentColor);
							}
						} // there is a full tag (not verified as valid yet)
					}
					else
					{
						// no tag, just add text
						richText.AddText(gameMessage->message->Substring(startIndex), currentFont, currentColor);

						currentLine++;
						break;
					}

					// we hit this if the string ends with a tag terminator.
					if (startIndex >= gameMessage->message->Length)
					{
						// no more string left
						currentLine++;
						break;
					}
				} // parsing line with tags

				tags.Clear();
			}
			// evaluate final line
			if (currentLine > 1 && skipped == false)
				EvaluateLine(richText, renderMessages, currentLine - 1, p_outputRectangle.Width, currentX, currentY, lifeMS);

			// render it all
			// background
			LinkedListEnumerator<AsteroidsGameRenderMessage> renderMessageEnumerator = LinkedListEnumerator<AsteroidsGameRenderMessage>(renderMessages);
			while (renderMessageEnumerator.MoveNext())
			{
				AsteroidsGameRenderMessage *renderMessage = &(renderMessageEnumerator.Current()->data);

				GameColor renderColor = GameColor::Interpolate(renderMessage->color, GameColor(0, 0, 0), 0.75f);
				//GameColor renderColor = GameColor::Interpolate(renderMessage->color, GameColor(255, 255, 255), 0.50f);
				if (renderMessage->lifeMS < messageBeginFadeMS)
				{
					renderColor.alpha = int(float(renderColor.alpha) * renderMessage->lifeMS / messageBeginFadeMS);
				}
				p_graphics->RenderFont(renderMessage->message, renderMessage->fontRef, float(int(renderMessage->location.X + float(p_backgroundOffset) + 0.01f)), float(int(renderMessage->location.Y + float(p_backgroundOffset) + 0.01f)), renderColor);
			}
			// foreground
			renderMessageEnumerator = LinkedListEnumerator<AsteroidsGameRenderMessage>(renderMessages);
			while (renderMessageEnumerator.MoveNext())
			{
				AsteroidsGameRenderMessage *renderMessage = &(renderMessageEnumerator.Current()->data);

				GameColor renderColor = renderMessage->color;
				if (renderMessage->lifeMS < messageBeginFadeMS)
				{
					renderColor.alpha = int(float(renderColor.alpha) * renderMessage->lifeMS / messageBeginFadeMS);
				}
				// float(int()) cleans up a float to a whole number, otherwise characters under the character in the texture could show
				p_graphics->RenderFont(renderMessage->message, renderMessage->fontRef, float(int(renderMessage->location.X)), float(int(renderMessage->location.Y)), renderColor);
			}
		}

	private:
		void AddTag(LinkedList<AsteroidsGameMessageTag> &p_tagList, String ^p_tag, GameColor &p_restoreColor, GameFont ^p_restoreFont)
		{
			// tag has qualifers stripped off (color=xxxxxx becomes color)
			LinkedListNode<AsteroidsGameMessageTag> *newNode = p_tagList.GetNewNode();
			newNode->data.tag = p_tag;
			newNode->data.restoreColor = p_restoreColor;
			newNode->data.restoreFont = p_restoreFont;
			p_tagList.AddNode(newNode);
		}

		void RemoveLastTag(LinkedList<AsteroidsGameMessageTag> &p_tagList)
		{
			if (p_tagList.GetLastNode() != nullptr)
				p_tagList.DeleteNode(p_tagList.GetLastNode());
		}

		// test:
		// try a simple line with no tags
		// try a long word that cuts-
		// try a line with a lot of spaces
		// try a line with many tags, etc.
		void EvaluateLine(GameRichTextList &p_richText, LinkedList<AsteroidsGameRenderMessage> &p_renderMessages, int p_line, float p_maxWidth, float p_startX, float &p_renderY, float p_lifeMS)
		{
			// for clarity, a line represents a single long Asteroids message.  a feed is each line for that message split up because of the output rectangle
			// all line nodes are together, as are each feed, with the lower screen lines appearing after the upper ones, and the first node for each feed being the left most on the screen.

			// renderY represents the BOTTOM of the line currently
			// go through entire line, forcing new lines and raising text, and making sure the bottom Y of all text on a single line are equal
			// and return the Y for the bottom of the next line up (or top of the tallest font of the upper most line evaluated here) for new text.
			// New nodes can be put anywhere in the list since everything is rendered by coordinate, so ordering doesn't matter

			// find first node with that line number (this can be sped up by keeping it determined in the main loop) - there will be multiple nodes for a line depending on how tags affected colors, fonts, etc.
			// parse forward through nodes (earliest nodes are earliest text).  On each node, set feed = currentFeed
			// when a line feed is required, split the text in the current node and insert the duplicate node with the latter part of the text after the current node, currentFeed++ -
			//    can't lift the y's from the prior line until we know the tallest text in the new feed.  So evaluate all the y's backwards after all the feeds are done
			// Splitting the text is the hard part.  Track current word.  Words are split on . , - and space.  Spaces are consumed by the line feed, at the end of the prior line and the beginning of the new one.
			// parsing backwards, start with bottomY = Y of farthest feed forward.  when evaluating a finished feed, for each bit of text, set render y = bottomY - textHeight, collect tallestTextHeight, and when encoutner the next feed up,
			//    set bottomY for next line up = bottomY - tallestTextHeight and keep going
			// splitting is now done by Graphics->WrapText()
			if (p_richText.IsEmpty())
				return; // nothing to do

			LinkedList<GameLinedRichText> linedRichText;
			GameFontHelper::WrapText(p_richText, linedRichText, int(p_maxWidth));

			// move lined rich text nodes over to the render list, working up (later nodes are higher on the screen)
			LinkedListEnumerator<GameLinedRichText> linedEnumerator = LinkedListEnumerator<GameLinedRichText>(linedRichText);
			LinkedListNode<AsteroidsGameRenderMessage> *firstLineNode = nullptr;
			LinkedListNode<AsteroidsGameRenderMessage> *lastLineNode = nullptr;
			LinkedListNode<AsteroidsGameRenderMessage> *insertAfter = nullptr;
			while (linedEnumerator.MoveNext())
			{
				LinkedListNode<AsteroidsGameRenderMessage> *newNode = p_renderMessages.GetNewNode();
				newNode->data.color = linedEnumerator.Current()->data.foreColor;
				newNode->data.line = p_line;
				newNode->data.feed = linedEnumerator.Current()->data.line;
				newNode->data.fontRef = linedEnumerator.Current()->data.fontRef;
				newNode->data.lifeMS = p_lifeMS;
				newNode->data.message = linedEnumerator.Current()->data.text;
				newNode->data.textHeight = float(linedEnumerator.Current()->data.textSize.Y);
				newNode->data.textSize = linedEnumerator.Current()->data.textSize;
				p_renderMessages.InsertNode(newNode, insertAfter);
				if (firstLineNode == nullptr)
					firstLineNode = newNode;
				insertAfter = newNode;
				lastLineNode = newNode;
			}

			//////////////////////////////////////
			// now calculate X and Y renders for the nodes.  First node of a given feed always starts at startX.  Each feed has a bottomY.  The last feed starts at p_renderY - tallestText for the feed, 
			//    the prior feed adjust Y upward by tallestText for the current feed, and repeat until all feeds' Y's are set
			// first, set up text sizes

			// now, start with last node, establish render positions
			LinkedListNode<AsteroidsGameRenderMessage> *node = lastLineNode;
			bool done = false;
			float bottomY = p_renderY;
			while (done == false)
			{
				LinkedListNode<AsteroidsGameRenderMessage> *lastFeedNode = node;
				int currentFeed = node->data.feed;

				// find first node of feed
				LinkedListNode<AsteroidsGameRenderMessage> *firstFeedNode = nullptr;
				while (node->data.feed == currentFeed)
				{
					firstFeedNode = node;
					if (node == firstLineNode) // if hit first node for line, break out
						break;
					node = node->prev;
				}
				// node is now last feed node of next feed up, for next loop iteration

				// set X's and establish tallest Text height
				// center the text
				LinkedListNode<AsteroidsGameRenderMessage> *parseNode = firstFeedNode;
				int totalTextWidth = 0;
				while (parseNode->data.feed == currentFeed) // redundant, but we are sticking within the feed
				{
					totalTextWidth += parseNode->data.textSize.X;

					if (parseNode == lastFeedNode)
						break;

					parseNode = parseNode->next;
				}
				// start so that text is centered in area
				float x = p_startX + float(int((p_maxWidth - float(totalTextWidth))/2.0f)); // no half pixels, so int it - otherwise just start at p_startX
				int tallestTextHeight = 0;
				parseNode = firstFeedNode;
				while (parseNode->data.feed == currentFeed) // redundant, but we are sticking within the feed
				{
					parseNode->data.location.X = x;
					x += float(parseNode->data.textSize.X);
					// force text to be flush with bottom
					parseNode->data.location.Y = float(bottomY) - float(parseNode->data.textSize.Y);
					if (parseNode->data.textSize.Y > tallestTextHeight)
						tallestTextHeight = parseNode->data.textSize.Y;

					if (parseNode == lastFeedNode)
						break;

					parseNode = parseNode->next;
				}
				bottomY -= float(tallestTextHeight);

				if (firstFeedNode == firstLineNode) // if hit first node for line, break out, we are all done
				{
					p_renderY = bottomY; // tell main loop Y moved up
					break;
				}
			}
		}
	};

	/////////////
	// network packets
	class AsteroidsNetworkPacketType
	{
	public:
		static const int Chat = 1;
		static const int RequestPingServer = 2; // clients receive this
		static const int RequestPingClient = 3; // server receives this
		static const int AnswerPing = 4; // clients receive this
		static const int RequestPingCycle = 5; // if server sends, is telling client to request ping cycles.  If client sends, is requesting a ping and telling server which iteration it is on

		static const int AddAsteroid = 6;
		static const int UpdateAsteroid = 7;
		static const int RemoveAsteroid = 8;
		static const int AddPowerup = 9;
		static const int ApplyShipPowerup = 10;
		static const int RemovePowerup = 11;
		static const int AddBullet = 12;
		static const int RemoveBullet = 13;

		static const int AddShip = 14;
		static const int SpawnShip = 15;
		static const int UpdateShipSimple = 16;
		static const int UpdateShipFull = 17;
		static const int UpdateShipFromClient = 18;
		static const int UpdateShipFromClientUDP = 19;
		static const int DamageShip = 20;
		static const int DyingShipPosition = 21; // ship just went into death throes, reporting position and velocity for accuracy
		static const int DestroyShip = 22;

		static const int AddExplosion = 23;

		// taunts
		static const int TauntAsteroidShipDestroyed = 24;
		static const int TauntBulletShipDestroyed = 25;
		static const int TauntShipCollideDeathThroe = 26;
		static const int TauntShipCollideDestroyed = 27;
		static const int EchoPlayerDestroyedPlayer = 28;

		// udp stuff
		static const int RequestPingServerUDP = 100; // clients receive this
		static const int RequestPingClientUDP = 101; // server receives this
		static const int AnswerPingUDP = 102; // clients receive this
	};

	struct AsteroidsNetworkAddPlayerPacket : NetworkAddPlayerPacketBase
	{
		int color; // color of player's name, matches the ship assigned
	};

	struct AsteroidsNetworkAddAsteroidPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkAddAsteroidPacket
		int id;
		float positionX;
		float positionY;
		float velocityX;
		float velocityY;
		int asteroidType;
		float radius;
		int minimumGameTimeMS; // lower bound for collisions (bullets, ships)
		int gameTimeMS; // this is the time on the server - NOT the gametime version (only ship has version because that is the only item clients can update on server)
	};

	struct AsteroidsNetworkUpdateAsteroidPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkUpdateAsteroidPacket
		int id;
		float positionX;
		float positionY;
		float velocityX;
		float velocityY;
		int asteroidType;
		float radius;
		int minimumGameTimeMS; // lower bound for collisions (bullets, ships)
		int gameTimeMS; // this is the time on the server - NOT the gametime version (only ship has version because that is the only item clients can update on server)
	};

	struct AsteroidsNetworkRemoveAsteroidPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkRemoveAsteroidPacket
		int id;
	};

	struct AsteroidsNetworkAddPowerupPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkAddPowerupPacket
		int id;
		float positionX;
		float positionY;
		float velocityX;
		float velocityY;
		int powerupType;
		int minimumGameTimeMS;
		int gameTimeMS; // position time when powerup was added
	};

	struct AsteroidsNetworkRemovePowerupPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkRemovePowerupPacket
		int id;
	};

	struct AsteroidsNetworkApplyPowerupPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkApplyPowerupPacket
		int powerupType;
		int shipId;
	};

	struct AsteroidsNetworkAddBulletPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkAddBulletPacket
		int id;
		int parentShipId;
		float positionX;
		float positionY;
		float velocityX;
		float velocityY;
		bool super;
		float radius;
		float lifeMS;
		int minimumGameTimeMS; // time bullet was created (NOT the same as where bullet is at end of its first move)
		int gameTimeMS; // this is the time on the creating machine after the bullet's first move - NOT the gametime version (only ship has version because that is the only item clients can update on server)
	};

	struct AsteroidsNetworkRemoveBulletPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkRemovePowerupPacket
		int id;
		int parentShipId;
	};

	struct AsteroidsNetworkChatPacket : NetworkPacketBase
	{
		// length = 17 + strlen(message)
		int fromPlayerId;
		int toPlayerId; // if -1, send to everyone, otherwise send specifically to that player as a tell
		char message[2000];
	};

	struct AsteroidsNetworkAddShipPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkAddShipPacket
		int playerId; // id of player that it belongs to
		int shipId;

		// controls
		int spinDirection;
		bool thrust;
		bool backwards;
		bool left;
		bool right;
		bool boost;

		int color; // GameColor's Int representation
		Vector3d position;
		Vector3d velocity;
		float rotationAngle;
		bool destroyed;
		float health;
		float shield;
		float boostFuel;
		float cloakMS;
		float deathThroesMS;
		float deathThroeRotationAnglePerMS;
		int gameTimeVersion; // version on server, required to accept updates on ship from client
		int gameTimeMS;
	};

	struct AsteroidsNetworkUpdateShipPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkUpdateShipPacket
		int shipId;

		// controls
		int spinDirection;
		bool thrust;
		bool backwards;
		bool left;
		bool right;
		bool boost;

		int color; // GameColor's Int representation
		Vector3d position;
		Vector3d velocity;
		float rotationAngle;
		bool destroyed;
		float health;
		float shield;
		float boostFuel;
		float cloakMS;
		float deathThroesMS;
		float deathThroeRotationAnglePerMS;
		int gameTimeVersion; // version on server, required to accept updates on ship from client
		int gameTimeMS;
	};

	struct AsteroidsNetworkUpdateShipFromClientPacket : NetworkPacketBase
	{
		// length = struct AsteroidsNetworkUpdateShipFromClientPacket : NetworkPacketBase
		int shipId;

		// controls
		int spinDirection;
		int controls; // bits for thrust, backwards, left, right, boost

		Vector2d position;
		Vector2d velocity;
		float rotationAngle;
		float boostFuel;
		float cloakMS;
		int gameTimeVersion; // version on server, required to accept updates on ship from client
		int gameTimeMS;
	};

	struct AsteroidsNetworkRespawnShipPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkRespawnShipPacket
		int id;
		float x;
		float y;
		float rotationAngle;
		int gameTimeVersion;
	};

	struct AsteroidsNetworkDamageShipPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkDamageShipPacket
		int id;
		float damage;
		int damagingPlayerId;
	};

	struct AsteroidsNetworkDyingShipPositionPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkDyingShipPositionPacket
		int id;
		Vector2d position;
		Vector2d velocity;
		int gameTimeMS;
	};

	struct AsteroidsNetworkDestroyShipPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkDestroyShipPacket
		int id;
		float x; // where did ship explode?
		float y;
	};

	struct AsteroidsNetworkAddExplosionPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkAddExplosionPacket
		float x; // explosioncenter
		float y;
		int color; // GameColor::ToInt()
		float radius;
		float expansionRatePerMS;
		float lifeMS;
	};

	struct AsteroidsNetworkTauntPacket : NetworkPacketBase // tell the client to display a prompt to itself
	{
		// length = NetworkPacketBase
	};

	struct AsteroidsNetworkEchoPlayerDestroyedPlayerPacket : NetworkPacketBase
	{
		// length = AsteroidsNetworkEchoPlayerDestroyedPlayerPacket
		int destroyingPlayerId;
		int destroyedPlayerId;
	};

	////

	struct AsteroidsNetworkRequestPingServerPacket : NetworkPacketBase
	{
		int serverPureTimeMS;
	};

	struct AsteroidsNetworkRequestPingClientPacket : NetworkPacketBase
	{
		int serverPureTimeMS; // echoed back to server
		int clientPureTimeMS; // sent from client for AsteroidsNetworkAnswerPingPacket reply
	};

	struct AsteroidsNetworkAnswerPingPacket : NetworkPacketBase
	{
		int clientPureTimeMS; // echoed back
		int serverGameTimeMS; // sent from server
		bool set; // should game time be set instead of adjusted? (set should only be used before first gamestate is sent down to client)
	};

	struct AsteroidsNetworkRequestPingCyclePacket : NetworkPacketBase
	{
		// length 16
		int clientPureTimeMS;
		int cycleNumber; // if maxCycleNbr, server sends down gamestate, finally
	};

	////////

	class AsteroidsNetworkPacketHelper
	{
	public:
		static void PopulateAddPlayerPacket(AsteroidsNetworkAddPlayerPacket &p_packet, GameNetworkPlayerBase *p_player, bool p_echo, GameColor &p_color)
		{
			p_packet.type = NetworkPacketTypes::AddPlayer;
			p_packet.id = p_player->id;
			strcpy_s(p_packet.name, 33, p_player->name);
			p_packet.server = p_player->server;
			p_packet.host = p_player->host;
			p_packet.echo = p_echo;
			p_packet.color = p_color.ToInt();
			p_packet.length = sizeof(AsteroidsNetworkAddPlayerPacket);
		}

		static void PopulateChatPacket(AsteroidsNetworkChatPacket &chatPacket, String ^p_message, int p_fromPlayerId, int p_toPlayerId = -1)
		{
			chatPacket.type = AsteroidsNetworkPacketType::Chat;
			chatPacket.fromPlayerId = p_fromPlayerId;
			chatPacket.toPlayerId = p_toPlayerId;
			GameNetworkPacketHelper::CopyStringToCharArray(chatPacket.message, 1999, p_message);
			chatPacket.length = 17 + strlen(chatPacket.message);
		}

		static void PopulateRequestPingServerPacket(AsteroidsNetworkRequestPingServerPacket &pingPacket, int p_pureTimeMS)
		{
			pingPacket.type = AsteroidsNetworkPacketType::RequestPingServer;
			pingPacket.length = sizeof(AsteroidsNetworkRequestPingServerPacket);
			pingPacket.serverPureTimeMS = p_pureTimeMS;
		}

		static void PopulateRequestPingClientPacket(AsteroidsNetworkRequestPingClientPacket &pingPacket, int p_serverPureTimeMS, int p_clientPureTimeMS)
		{
			pingPacket.type = AsteroidsNetworkPacketType::RequestPingClient;
			pingPacket.length = sizeof(AsteroidsNetworkRequestPingClientPacket);
			pingPacket.serverPureTimeMS = p_serverPureTimeMS;
			pingPacket.clientPureTimeMS = p_clientPureTimeMS;
		}

		static void PopulateAnswerPingPacket(AsteroidsNetworkAnswerPingPacket &pingPacket, int p_clientPureTimeMS, int p_serverGameTimeMS, bool p_set)
		{
			pingPacket.type = AsteroidsNetworkPacketType::AnswerPing;
			pingPacket.length = sizeof(AsteroidsNetworkAnswerPingPacket);
			pingPacket.clientPureTimeMS = p_clientPureTimeMS;
			pingPacket.serverGameTimeMS = p_serverGameTimeMS;
			pingPacket.set = p_set;
		}

		static void PopulateRequestPingServerUDPPacket(AsteroidsNetworkRequestPingServerPacket &pingPacket, int p_pureTimeMS)
		{
			pingPacket.type = AsteroidsNetworkPacketType::RequestPingServerUDP;
			pingPacket.length = sizeof(AsteroidsNetworkRequestPingServerPacket);
			pingPacket.serverPureTimeMS = p_pureTimeMS;
		}

		static void PopulateRequestPingClientUDPPacket(AsteroidsNetworkRequestPingClientPacket &pingPacket, int p_serverPureTimeMS, int p_clientPureTimeMS)
		{
			pingPacket.type = AsteroidsNetworkPacketType::RequestPingClientUDP;
			pingPacket.length = sizeof(AsteroidsNetworkRequestPingClientPacket);
			pingPacket.serverPureTimeMS = p_serverPureTimeMS;
			pingPacket.clientPureTimeMS = p_clientPureTimeMS;
		}

		static void PopulateAnswerPingUDPPacket(AsteroidsNetworkAnswerPingPacket &pingPacket, int p_clientPureTimeMS, int p_serverGameTimeMS, bool p_set)
		{
			pingPacket.type = AsteroidsNetworkPacketType::AnswerPingUDP;
			pingPacket.length = sizeof(AsteroidsNetworkAnswerPingPacket);
			pingPacket.clientPureTimeMS = p_clientPureTimeMS;
			pingPacket.serverGameTimeMS = p_serverGameTimeMS;
			pingPacket.set = p_set;
		}

		static void PopulateRequestPingCyclePacket(AsteroidsNetworkRequestPingCyclePacket &cyclePacket, int p_clientPureTimeMS, int p_cycleNumber)
		{
			cyclePacket.type = AsteroidsNetworkPacketType::RequestPingCycle;
			cyclePacket.length = sizeof(AsteroidsNetworkRequestPingCyclePacket);
			cyclePacket.clientPureTimeMS = p_clientPureTimeMS;
			cyclePacket.cycleNumber = p_cycleNumber;
		}

		static void PopulateAddAsteroidPacket(AsteroidsNetworkAddAsteroidPacket &asteroidPacket, int p_id, Vector3d &p_position, Vector3d &p_velocity, int p_asteroidType, float p_radius, int p_minimumGameTimeMS, int p_gameTimeMS)
		{
			asteroidPacket.length = sizeof(AsteroidsNetworkAddAsteroidPacket);
			asteroidPacket.type = AsteroidsNetworkPacketType::AddAsteroid;
			asteroidPacket.id = p_id;
			asteroidPacket.positionX = p_position.x;
			asteroidPacket.positionY = p_position.y;
			asteroidPacket.velocityX = p_velocity.x;
			asteroidPacket.velocityY = p_velocity.y;
			asteroidPacket.asteroidType = p_asteroidType;
			asteroidPacket.radius = p_radius;
			asteroidPacket.minimumGameTimeMS = p_minimumGameTimeMS;
			asteroidPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateUpdateAsteroidPacket(AsteroidsNetworkUpdateAsteroidPacket &asteroidPacket, int p_id, Vector3d &p_position, Vector3d &p_velocity, int p_asteroidType, float p_radius, int p_minimumGameTimeMS, int p_gameTimeMS)
		{
			asteroidPacket.length = sizeof(AsteroidsNetworkUpdateAsteroidPacket);
			asteroidPacket.type = AsteroidsNetworkPacketType::UpdateAsteroid;
			asteroidPacket.id = p_id;
			asteroidPacket.positionX = p_position.x;
			asteroidPacket.positionY = p_position.y;
			asteroidPacket.velocityX = p_velocity.x;
			asteroidPacket.velocityY = p_velocity.y;
			asteroidPacket.asteroidType = p_asteroidType;
			asteroidPacket.radius = p_radius;
			asteroidPacket.minimumGameTimeMS = p_minimumGameTimeMS;
			asteroidPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateRemoveAsteroidPacket(AsteroidsNetworkRemoveAsteroidPacket &asteroidPacket, int p_id)
		{
			asteroidPacket.length = sizeof(AsteroidsNetworkRemoveAsteroidPacket);
			asteroidPacket.type = AsteroidsNetworkPacketType::RemoveAsteroid;
			asteroidPacket.id = p_id;
		}

		static void PopulateAddPowerupPacket(AsteroidsNetworkAddPowerupPacket &powerupPacket, int p_id, Vector3d &p_position, Vector3d &p_velocity, int p_powerupType, int p_minimumGameTimeMS, int p_gameTimeMS)
		{
			powerupPacket.length = sizeof(AsteroidsNetworkAddPowerupPacket);
			powerupPacket.type = AsteroidsNetworkPacketType::AddPowerup;
			powerupPacket.id = p_id;
			powerupPacket.positionX = p_position.x;
			powerupPacket.positionY = p_position.y;
			powerupPacket.velocityX = p_velocity.x;
			powerupPacket.velocityY = p_velocity.y;
			powerupPacket.powerupType = p_powerupType;
			powerupPacket.minimumGameTimeMS = p_minimumGameTimeMS;
			powerupPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateRemovePowerupPacket(AsteroidsNetworkRemovePowerupPacket &powerupPacket, int p_id)
		{
			powerupPacket.length = sizeof(AsteroidsNetworkRemovePowerupPacket);
			powerupPacket.type = AsteroidsNetworkPacketType::RemovePowerup;
			powerupPacket.id = p_id;
		}

		static void PopulateApplyPowerupPacket(AsteroidsNetworkApplyPowerupPacket &powerupPacket, int p_powerupType, int p_shipId)
		{
			powerupPacket.length = sizeof(AsteroidsNetworkApplyPowerupPacket);
			powerupPacket.type = AsteroidsNetworkPacketType::ApplyShipPowerup;
			powerupPacket.powerupType = p_powerupType;
			powerupPacket.shipId = p_shipId;
		}

		static void PopulateAddBulletPacket(AsteroidsNetworkAddBulletPacket &bulletPacket, int p_id, int p_parentShipId, Vector3d &p_position, Vector3d &p_velocity, bool p_super, float p_radius, float p_lifeMS, int p_minimumGameTimeMS, int p_gameTimeMS)
		{
			bulletPacket.length = sizeof(AsteroidsNetworkAddBulletPacket);
			bulletPacket.type = AsteroidsNetworkPacketType::AddBullet;
			bulletPacket.id = p_id;
			bulletPacket.parentShipId = p_parentShipId;
			bulletPacket.positionX = p_position.x;
			bulletPacket.positionY = p_position.y;
			bulletPacket.velocityX = p_velocity.x;
			bulletPacket.velocityY = p_velocity.y;
			bulletPacket.super = p_super;
			bulletPacket.radius = p_radius;
			bulletPacket.lifeMS = p_lifeMS;
			bulletPacket.minimumGameTimeMS = p_minimumGameTimeMS;
			bulletPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateRemoveBulletPacket(AsteroidsNetworkRemoveBulletPacket &bulletPacket, int p_id, int p_parentShipId)
		{
			bulletPacket.length = sizeof(AsteroidsNetworkRemoveBulletPacket);
			bulletPacket.type = AsteroidsNetworkPacketType::RemoveBullet;
			bulletPacket.id = p_id;
			bulletPacket.parentShipId = p_parentShipId;
		}

		static void PopulateAddShipPacket(AsteroidsNetworkAddShipPacket &shipPacket, int p_playerId, int p_id, 
			int p_spinDirection, bool p_thrust, bool p_backwards, bool p_left, bool p_right, bool p_boost, 
			Vector3d &p_position, Vector3d &p_velocity, float p_rotationAngle,
			GameColor p_color, bool p_destroyed, float p_health, float p_shield, float p_boostFuel, float p_cloakMS, float p_deathThroesMS, float p_deathThroeRotationAnglePerMS,
			int p_gameTimeVersion, int p_gameTimeMS)
		{
			shipPacket.length = sizeof(AsteroidsNetworkAddShipPacket);
			shipPacket.type = AsteroidsNetworkPacketType::AddShip;
			shipPacket.playerId = p_playerId;
			shipPacket.shipId = p_id;

			// controls
			shipPacket.spinDirection = p_spinDirection;
			shipPacket.thrust = p_thrust;
			shipPacket.backwards = p_backwards;
			shipPacket.left = p_left;
			shipPacket.right = p_right;
			shipPacket.boost = p_boost;

			shipPacket.position = p_position;
			shipPacket.velocity = p_velocity;
			shipPacket.rotationAngle = p_rotationAngle;
			shipPacket.color = p_color.ToInt();
			shipPacket.destroyed = p_destroyed;
			shipPacket.health = p_health;
			shipPacket.shield = p_shield;
			shipPacket.boostFuel = p_boostFuel;
			shipPacket.cloakMS = p_cloakMS;
			shipPacket.deathThroesMS = p_deathThroesMS;
			shipPacket.deathThroeRotationAnglePerMS = p_deathThroeRotationAnglePerMS;
			shipPacket.gameTimeVersion = p_gameTimeVersion;
			shipPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateUpdateShipPacket(AsteroidsNetworkUpdateShipPacket &shipPacket, int p_id,
			int p_spinDirection, bool p_thrust, bool p_backwards, bool p_left, bool p_right, bool p_boost,
			Vector3d &p_position, Vector3d &p_velocity, float p_rotationAngle,
			GameColor p_color, bool p_destroyed, float p_health, float p_shield, float p_boostFuel, float p_cloakMS, float p_deathThroesMS, float p_deathThroeRotationAnglePerMS,
			int p_gameTimeVersion, int p_gameTimeMS)
		{
			shipPacket.length = sizeof(AsteroidsNetworkUpdateShipPacket);
			shipPacket.type = AsteroidsNetworkPacketType::UpdateShipFull;
			shipPacket.shipId = p_id;

			// controls
			shipPacket.spinDirection = p_spinDirection;
			shipPacket.thrust = p_thrust;
			shipPacket.backwards = p_backwards;
			shipPacket.left = p_left;
			shipPacket.right = p_right;
			shipPacket.boost = p_boost;

			shipPacket.position = p_position;
			shipPacket.velocity = p_velocity;
			shipPacket.rotationAngle = p_rotationAngle;
			shipPacket.color = p_color.ToInt();
			shipPacket.destroyed = p_destroyed;
			shipPacket.health = p_health;
			shipPacket.shield = p_shield;
			shipPacket.boostFuel = p_boostFuel;
			shipPacket.cloakMS = p_cloakMS;
			shipPacket.deathThroesMS = p_deathThroesMS;
			shipPacket.deathThroeRotationAnglePerMS = p_deathThroeRotationAnglePerMS;
			shipPacket.gameTimeVersion = p_gameTimeVersion;
			shipPacket.gameTimeMS = p_gameTimeMS;
		}

#define ASTEROIDS_CONTROLS_THRUST_BIT 1
#define ASTEROIDS_CONTROLS_BACKWARDS_BIT 2
#define ASTEROIDS_CONTROLS_LEFT_BIT 4
#define ASTEROIDS_CONTROLS_RIGHT_BIT 8
#define ASTEROIDS_CONTROLS_BOOST_BIT 16

		static void PopulateUpdateShipFromClientPacket(AsteroidsNetworkUpdateShipFromClientPacket &shipPacket, int p_id,
			int p_spinDirection, bool p_thrust, bool p_backwards, bool p_left, bool p_right, bool p_boost,
			Vector3d &p_position, Vector3d &p_velocity, float p_rotationAngle,
			float p_boostFuel, float p_cloakMS,
			int p_gameTimeVersion, int p_gameTimeMS)
		{
			shipPacket.length = sizeof(AsteroidsNetworkUpdateShipFromClientPacket);
			shipPacket.type = AsteroidsNetworkPacketType::UpdateShipFromClient;
			shipPacket.shipId = p_id;

			// controls
			shipPacket.spinDirection = p_spinDirection;
			shipPacket.controls = 0;
			if (p_thrust == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_THRUST_BIT;
			if (p_backwards == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_BACKWARDS_BIT;
			if (p_left == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_LEFT_BIT;
			if (p_right == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_RIGHT_BIT;
			if (p_boost == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_BOOST_BIT;

			shipPacket.position = Vector2d(p_position.x, p_position.y);
			shipPacket.velocity = Vector2d(p_velocity.x, p_velocity.y);
			shipPacket.rotationAngle = p_rotationAngle;
			shipPacket.boostFuel = p_boostFuel;
			shipPacket.cloakMS = p_cloakMS;
			shipPacket.gameTimeVersion = p_gameTimeVersion;
			shipPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateUpdateShipFromClientUDPPacket(AsteroidsNetworkUpdateShipFromClientPacket &shipPacket, int p_id,
			int p_spinDirection, bool p_thrust, bool p_backwards, bool p_left, bool p_right, bool p_boost,
			Vector3d &p_position, Vector3d &p_velocity, float p_rotationAngle,
			float p_boostFuel, float p_cloakMS,
			int p_gameTimeVersion, int p_gameTimeMS)
		{
			shipPacket.length = sizeof(AsteroidsNetworkUpdateShipFromClientPacket);
			shipPacket.type = AsteroidsNetworkPacketType::UpdateShipFromClientUDP;
			shipPacket.shipId = p_id;

			// controls
			shipPacket.spinDirection = p_spinDirection;
			shipPacket.controls = 0;
			if (p_thrust == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_THRUST_BIT;
			if (p_backwards == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_BACKWARDS_BIT;
			if (p_left == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_LEFT_BIT;
			if (p_right == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_RIGHT_BIT;
			if (p_boost == true)
				shipPacket.controls = shipPacket.controls | ASTEROIDS_CONTROLS_BOOST_BIT;

			shipPacket.position = Vector2d(p_position.x, p_position.y);
			shipPacket.velocity = Vector2d(p_velocity.x, p_velocity.y);
			shipPacket.rotationAngle = p_rotationAngle;
			shipPacket.boostFuel = p_boostFuel;
			shipPacket.cloakMS = p_cloakMS;
			shipPacket.gameTimeVersion = p_gameTimeVersion;
			shipPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateRespawnShipPacket(AsteroidsNetworkRespawnShipPacket &shipPacket, int p_shipId, float p_x, float p_y, float p_rotationAngle, int p_gameTimeVersion)
		{
			shipPacket.length = sizeof(AsteroidsNetworkRespawnShipPacket);
			shipPacket.type = AsteroidsNetworkPacketType::SpawnShip;
			shipPacket.id = p_shipId;
			shipPacket.x = p_x;
			shipPacket.y = p_y;
			shipPacket.rotationAngle = p_rotationAngle;
			shipPacket.gameTimeVersion = p_gameTimeVersion;
		}

		static void PopulateDamageShipPacket(AsteroidsNetworkDamageShipPacket &shipPacket, int p_shipId, float p_damage, int p_damagingPlayerId)
		{
			shipPacket.length = sizeof(AsteroidsNetworkDamageShipPacket);
			shipPacket.type = AsteroidsNetworkPacketType::DamageShip;
			shipPacket.id = p_shipId;
			shipPacket.damage = p_damage;
			shipPacket.damagingPlayerId = p_damagingPlayerId;
		}

		static void PopulateDyingShipPositionPacket(AsteroidsNetworkDyingShipPositionPacket &shipPacket, int p_shipId, Vector3d &p_position, Vector3d &p_velocity, int p_gameTimeMS)
		{
			shipPacket.length = sizeof(AsteroidsNetworkDyingShipPositionPacket);
			shipPacket.type = AsteroidsNetworkPacketType::DyingShipPosition;
			shipPacket.id = p_shipId;
			shipPacket.position.Set(p_position.x, p_position.y);
			shipPacket.velocity.Set(p_velocity.x, p_velocity.y);
			shipPacket.gameTimeMS = p_gameTimeMS;
		}

		static void PopulateDestroyShipPacket(AsteroidsNetworkDestroyShipPacket &shipPacket, int p_shipId, Vector3d &p_destructionPosition)
		{
			shipPacket.length = sizeof(AsteroidsNetworkDestroyShipPacket);
			shipPacket.type = AsteroidsNetworkPacketType::DestroyShip;
			shipPacket.id = p_shipId;
			shipPacket.x = p_destructionPosition.x;
			shipPacket.y = p_destructionPosition.y;
		}

		static void PopulateAddExplosionPacket(AsteroidsNetworkAddExplosionPacket &explosionPacket, Vector3d &p_position, GameColor &p_color, float p_radius, float p_expansionRatePerMS, float p_lifeMS)
		{
			explosionPacket.length = sizeof(AsteroidsNetworkAddExplosionPacket);
			explosionPacket.type = AsteroidsNetworkPacketType::AddExplosion;
			explosionPacket.x = p_position.x;
			explosionPacket.y = p_position.y;
			explosionPacket.color = p_color.ToInt();
			explosionPacket.radius = p_radius;
			explosionPacket.expansionRatePerMS = p_expansionRatePerMS;
			explosionPacket.lifeMS = p_lifeMS;
		}

		static void PopulateTauntPacket(AsteroidsNetworkTauntPacket &tauntPacket, int p_type)
		{
			tauntPacket.length = sizeof(AsteroidsNetworkTauntPacket);
			tauntPacket.type = p_type;
		}

		static void PopulateEchoPlayerDestroyedPlayerPacket(AsteroidsNetworkEchoPlayerDestroyedPlayerPacket &echoPacket, int p_destroyingPlayerId, int p_destroyedPlayerId)
		{
			echoPacket.length = sizeof(AsteroidsNetworkEchoPlayerDestroyedPlayerPacket);
			echoPacket.type = AsteroidsNetworkPacketType::EchoPlayerDestroyedPlayer;
			echoPacket.destroyingPlayerId = p_destroyingPlayerId;
			echoPacket.destroyedPlayerId = p_destroyedPlayerId;			
		}
	};

	/////////

	public class AsteroidsGameData
	{
	public:
		gcroot<GameViewport^> viewportRef;
		AsteroidsGameType gameType;
		GameTimer *gameTimerRef;
		int gameStateGameTimeMS; // time that the gamestate after Animate() represents, used to catch obejcts sent by the server up to a client's gamestate
		// timer's GameStateMS() cannot be used for that purpose since the timer's GameStateMS() might have been adjusted by a ping, which throws it off
		//   from the gamestate's gameTimeMS.  Things will be fixed on the next Animate() in which the elapsedTimeMS > 0
		// this value should only be read in a game tick after Animate() is finished - most usually ONLY by routines called by the network when packets arrive, or the render routine.
		// once animate is done, this value represents the gameTimeMS being rendered, and every object in the gamestate, including those that arrived or were udpated by network packets,
		//    should reflect that in their position at render time

		ModelVertex *circleVertices; // for rendering a circle
		int circleVertexQty;

		ModelVertex *simpleCircleVertices; // lower detail for smaller circles
		int simpleCircleVertexQty;

		AsteroidsStar *stars;
		int starQty;
		float maxStarSize;

		AsteroidsPlayfield playfield;

		LinkedList<AsteroidsShip> ships;
		AsteroidsBulletList bullets;
		AsteroidsAsteroidList asteroids;
		AsteroidsExplosionList explosions;
		LinkedList<AsteroidsPowerup> powerups;

		AsteroidsShip *renderFocusShipRef;
		AsteroidsShip *localPlayerShipRef; // which ship does the local player control?

		Vector3d priorNormalizedRenderCenter;

		Vector3d floatingCamera;

		AsteroidsCamera camera; // for getting rendering center

		AsteroidsShipColorRegistry asteroidsShipColorRegistry;

		float largeAsteroidRadius;
		float mediumAsteroidRadius;
		float smallAsteroidRadius;

		bool exitGame; // when GameLoop sees this = true, stops

		// for rendering stars
		GraphicsPolygonQueue polygonQueue;

		// game messages
		AsteroidsGameMessageList *messageList;

		AsteroidsGameData(GameViewport ^p_viewportRef, GameTimer *p_gameTimerRef)
		{
			floatingCamera.Set(0, 0, 0);
			priorNormalizedRenderCenter.Set(0, 0, 0); // set to something meaningful for simplicity

			viewportRef = p_viewportRef;
			gameTimerRef = p_gameTimerRef;
			gameStateGameTimeMS = gameTimerRef->GetGameTimeMS();
			gameType = AsteroidsGameType::None;

			InitializeCircleVertices();
			InitializeSimpleCircleVertices();

			stars = nullptr;
			starQty = 0;

			renderFocusShipRef = nullptr;
			localPlayerShipRef = nullptr;

			largeAsteroidRadius = 60.0f;
			mediumAsteroidRadius = 30.0f;
			smallAsteroidRadius = 15.0f;

			exitGame = false;

			messageList = new AsteroidsGameMessageList(GameColor(255, 255, 32), GameContext::Instance->FontRegistry.GetFont("Messages720"), GameContext::Instance->FontRegistry.GetFont("MessagesBold720"), 6000.0f, 1000.0f);
		}

		~AsteroidsGameData()
		{
			ClearStars();

			if (circleVertices != nullptr)
			{
				delete[] circleVertices;
				circleVertices = nullptr;
				circleVertexQty = 0;;
			}
			if (simpleCircleVertices != nullptr)
			{
				delete[] simpleCircleVertices;
				simpleCircleVertices = nullptr;
				simpleCircleVertexQty = 0;;
			}
			if (messageList != nullptr)
			{
				delete messageList;
				messageList = nullptr;
			}
		}

		void ResetAllData()
		{
			LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnumerator.MoveNext())
			{
				asteroidsShipColorRegistry.FreeColor(shipEnumerator.Current()->data.color);
			}
			int availableColorQty = asteroidsShipColorRegistry.GetAvailableColorQty();
			if (availableColorQty != asteroidsShipColorRegistry.GetColorQty())
				throw gcnew Exception("Clearing color registry failed!  Are all of the colors in the registry unique?");

			ships.Clear();
			bullets.Clear();
			asteroids.Clear();
			explosions.Clear();
			powerups.Clear();

			renderFocusShipRef = nullptr;
			localPlayerShipRef = nullptr;

			// keep messagelist intact

			gameType = AsteroidsGameType::None;
		}

		void ClearStars()
		{
			if (stars != nullptr)
			{
				delete[] stars;
				stars = nullptr;
				starQty = 0;
			}
		}

		void MoveStars(Vector2d &p_offset)
		{
			float scale = GetRenderScale();

			if (stars != nullptr)
			{
				int viewportWidth = viewportRef->GetWidth();
				int viewportHeight = viewportRef->GetHeight();

				for (int i = 0; i < starQty; i++)
				{
					stars[i].position.x += (p_offset.x) * stars[i].moveScale * scale;
					stars[i].position.y += (p_offset.y) * stars[i].moveScale * scale;

					while (stars[i].position.x > viewportWidth)
						stars[i].position.x -= viewportWidth;
					while (stars[i].position.x < 0)
						stars[i].position.x += viewportWidth;
					while (stars[i].position.y > viewportHeight)
						stars[i].position.y -= viewportHeight;
					while (stars[i].position.y < 0)
						stars[i].position.y += viewportHeight;
				}
			}
		}

	private:
		void CreateStarfield()
		{
			// todo: The depth effect is kind of weak.  Each star should progressively get deeper by an incremental value and adjust its size accordingly

			// make a starfield with quantity based on the surface area of the viewport to maintain star density
			int viewportWidth = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth();
			int viewportHeight = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight();
			int viewportSurfaceArea = viewportWidth * viewportHeight;

			maxStarSize = float(viewportHeight) / 120.0f;  // matches up with star texture - if star texture is made larger, reduce this size
			//float minSize = maxStarSize / 1000.0f; // determines depth of field
			//float minSize = maxStarSize  / 80.0f; // determines depth of field
			float minDepth = 50;
			float maxDepth = 500;

			starQty = viewportSurfaceArea / 1000;
			stars = new AsteroidsStar[starQty];
			FastRandom random;
			// build back to front because that is how they will be rendered
			for (int i = 0; i < starQty; i++)
			{
				stars[i].position.Set(float(random.GetRandomInteger(0, viewportWidth)), float(random.GetRandomInteger(0, viewportHeight)));
				int threshold = 64;
				// make all stars mostly bright
				stars[i].color = GameColor(255 - random.GetRandomInteger(0, threshold), 255 - random.GetRandomInteger(0, threshold), 255 - random.GetRandomInteger(0, threshold));
				// small to large
				float depth = maxDepth + (minDepth - maxDepth) * (float(i)) / float(starQty);
				stars[i].size = maxStarSize * minDepth / depth; // star's size determines its speed
				stars[i].moveScale = stars[i].size / maxStarSize;
				// make size a bit more random
				stars[i].size *= float(random.GetRandomInteger(-20, 20) + 100) / 100.0f;
			}
		}

		void CheckStarfield()
		{
			if (stars == nullptr)
			{
				CreateStarfield();
			}
		}

	public:
		void RenderStarfield(GraphicsBase *p_graphics)
		{
			if (polygonQueue.IsCreated() == false)
				p_graphics->CreatePolygonQueue(&polygonQueue, 8000);

			CheckStarfield();

			// render it!  back to front
			GameColor colors[1];
			ModelVertex vertices[4];
			vertices[0].colorIndex = 0;
			vertices[1].colorIndex = 0;
			vertices[2].colorIndex = 0;
			vertices[3].colorIndex = 0;
			ModelVertexTextureCoords texCoords[4];
			texCoords[0].s = 0.0f;
			texCoords[0].t = 0.0f;
			texCoords[1].s = 1.0f;
			texCoords[1].t = 0.0f;
			texCoords[2].s = 1.0f;
			texCoords[2].t = 1.0f;
			texCoords[3].s = 0.0f;
			texCoords[3].t = 1.0f;

			GameTexture ^star = GameContext::Instance->TextureRegistry.GetTexture("Star");
			GraphicsShaderPolygonOptions polygonQueueOptions;
			Matrix4d matrix = p_graphics->GetMVPMatrix();
			polygonQueueOptions.mvpMatrixRef = &matrix;
			for (int i = 0; i < starQty; i++)
			{
				colors[0] = stars[i].color;
				// render opposite to perspective volume since this is ortho
				vertices[0].vertex.Set(stars[i].position.x - stars[i].size, stars[i].position.y - stars[i].size, 0);
				vertices[1].vertex.Set(stars[i].position.x + stars[i].size, stars[i].position.y - stars[i].size, 0);
				vertices[2].vertex.Set(stars[i].position.x + stars[i].size, stars[i].position.y + stars[i].size, 0);
				vertices[3].vertex.Set(stars[i].position.x - stars[i].size, stars[i].position.y + stars[i].size, 0);
				//vertices[0].vertex.Set(0, 0, 0);
				//vertices[1].vertex.Set(200, 0, 0);
				//vertices[2].vertex.Set(200, 200, 0);
				//vertices[3].vertex.Set(0, 200, 0);

				// much faster than RenderFilledQuad
				p_graphics->SubmitPolygonToQueue(&polygonQueue, polygonQueueOptions, colors, 1, vertices, 4, true, star, texCoords, 4);
				//p_graphics->RenderFilledQuad(colors, 1, vertices, 4, true, star, texCoords, 4);
			}
			p_graphics->CommitPolygonQueue(&polygonQueue, polygonQueueOptions);
		}

		void RenderShips(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			float scale = GetRenderScale();
			Vector3d viewportCenter = Vector3d(float(viewportRef->GetWidth()) / 2.0f, float(viewportRef->GetHeight()) / 2.0f, 0.0f);

			// center is playfield coordinate representing where center of viewport lies
			// don't render a ship outside the viewport

			float frontShipRadiusFactor = 1.4f;
			float backCornerShipRadiusFactor = 1.0f;
			float backCornerShipAngle = 137.5f; // degrees from front to a back corner (135 too little, 140 too much)

			ModelVertex shapeVertices[4];
			shapeVertices[0].colorIndex = 0;
			shapeVertices[1].colorIndex = 0;
			shapeVertices[2].colorIndex = 0;
			shapeVertices[3].colorIndex = 0;

			LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnumerator.MoveNext())
			{
				AsteroidsShip *ship = &(shipEnumerator.Current()->data);
				if (ship->IsDestroyed() == true)
					continue;

				Vector3d renderCenter = playfield.NormalizeOffsetWithPlayfield(ship->position - p_center).ScalarMult(scale) + viewportCenter;

				// find radius needed to determine if ship should be rendered
				float frontShipRadius = frontShipRadiusFactor * ship->radius;
				float thrustTipRadius = 0.0f;
				float thrustTipRadiusNormalFactor = 2.0f;
				float thrustTipRadiusBoostFactor = 3.0f;
				if (ship->offFlameTimerMS == 0)
				{
					if (ship->thrust == true)
					{
						if (ship->appliedBoost == true)
							thrustTipRadius = thrustTipRadiusBoostFactor * ship->radius;
						else
							thrustTipRadius = thrustTipRadiusNormalFactor * ship->radius;
					}
				}
				float maxRadius = frontShipRadius;
				if (thrustTipRadius > maxRadius)
					maxRadius = thrustTipRadius;

				// todo: if boosting or reversing, a flame might constitute the largest radius

				// see if ship is outside bounds of screen (check against largest radius)
				if (renderCenter.x + maxRadius * scale < 0.0f)
					continue;
				if (renderCenter.y + maxRadius * scale < 0.0f)
					continue;
				if (renderCenter.x - maxRadius * scale > float(viewportRef->GetWidth()))
					continue;
				if (renderCenter.y - maxRadius * scale > float(viewportRef->GetHeight()))
					continue;

				// Draw it!

				// The flame
				float flameFlickerMS = 25.0f;
				if (ship->offFlameTimerMS == 0) // if off flame timer is 0, allow flame
				{
					if (ship->thrust == true)
					{
						if (ship->onFlameTimerMS == 0)
							// keep flame on for a while
							ship->onFlameTimerMS = flameFlickerMS;

						// backwards flame
						float flameCornerAngle = 145.0f; // degrees from front
						float flameCornerRadiusFactor = 0.9f; // to touch where 145.0f is

						// note: rotation Angle of zero faces straight up on screen
						float backRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + 180.0f);
						Vector3d shipBackVector = Vector3d(sin(backRadians), -cos(backRadians), 0.0f);
						float backRightRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerAngle);
						Vector3d shipBackRightVector = Vector3d(sin(backRightRadians), -cos(backRightRadians), 0.0f);
						float backLeftRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerAngle);
						Vector3d shipBackLeftVector = Vector3d(sin(backLeftRadians), -cos(backLeftRadians), 0.0f);

						float flameCornerRadius = flameCornerRadiusFactor * ship->radius;
						shapeVertices[0].vertex.Set(renderCenter + shipBackRightVector.ScalarMult(flameCornerRadius * scale));
						shapeVertices[1].vertex.Set(renderCenter + shipBackVector.ScalarMult(thrustTipRadius * scale));
						shapeVertices[2].vertex.Set(renderCenter + shipBackLeftVector.ScalarMult(flameCornerRadius * scale));

						GameColor flameColor(255, 96, 64);
						flameColor.alpha = int(255.0f * ship->GetCloakedAlpha(renderFocusShipRef == ship));
						p_graphics->RenderLineStrip(4.5f * scale, &flameColor, 1, shapeVertices, 3, true);
					}
					else if (ship->backwards == true)
					{
						if (ship->onFlameTimerMS == 0)
							// keep flame on for a while
							ship->onFlameTimerMS = flameFlickerMS;
						// two backwards flames

						// right side
						float flameCornerLeftAngle = 100.0f; // degrees from front
						float flameCornerMiddleAngle = 80.0f; // degrees from front
						float flameCornerRightAngle = backCornerShipAngle;
						float flameCornerLeftRadiusFactor = 0.6f;
						float flameCornerMiddleRadiusFactor = 1.1f;
						float flameCornerRightRadiusFactor = backCornerShipRadiusFactor;

						if (ship->appliedBoost == true)
						{
							flameCornerMiddleAngle = 50.0f;
							flameCornerMiddleRadiusFactor = 1.7f;
						}

						// note: rotation Angle of zero faces straight up on screen
						float leftRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerLeftAngle);
						Vector3d leftVector = Vector3d(sin(leftRadians), -cos(leftRadians), 0.0f);
						float middleRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerMiddleAngle);
						Vector3d middleVector = Vector3d(sin(middleRadians), -cos(middleRadians), 0.0f);
						float rightRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerRightAngle);
						Vector3d rightVector = Vector3d(sin(rightRadians), -cos(rightRadians), 0.0f);

						float flameLeftRadius = flameCornerLeftRadiusFactor * ship->radius;
						float flameMiddleRadius = flameCornerMiddleRadiusFactor * ship->radius;
						float flameRightRadius = flameCornerRightRadiusFactor * ship->radius;
						shapeVertices[0].vertex.Set(renderCenter + leftVector.ScalarMult(flameLeftRadius * scale));
						shapeVertices[1].vertex.Set(renderCenter + middleVector.ScalarMult(flameMiddleRadius * scale));
						shapeVertices[2].vertex.Set(renderCenter + rightVector.ScalarMult(flameRightRadius * scale));

						GameColor flameColor(255, 96, 64);
						flameColor.alpha = int(255.0f * ship->GetCloakedAlpha(renderFocusShipRef == ship));
						p_graphics->RenderLineStrip(4.5f * scale, &flameColor, 1, shapeVertices, 3, true);

						// left side - flip left and right angles and factors to get meaningful values
						leftRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerRightAngle);
						leftVector = Vector3d(sin(leftRadians), -cos(leftRadians), 0.0f);
						middleRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerMiddleAngle);
						middleVector = Vector3d(sin(middleRadians), -cos(middleRadians), 0.0f);
						rightRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerLeftAngle);
						rightVector = Vector3d(sin(rightRadians), -cos(rightRadians), 0.0f);

						flameLeftRadius = flameCornerRightRadiusFactor * ship->radius;
						flameMiddleRadius = flameCornerMiddleRadiusFactor * ship->radius;
						flameRightRadius = flameCornerLeftRadiusFactor * ship->radius;
						shapeVertices[0].vertex.Set(renderCenter + leftVector.ScalarMult(flameLeftRadius * scale));
						shapeVertices[1].vertex.Set(renderCenter + middleVector.ScalarMult(flameMiddleRadius * scale));
						shapeVertices[2].vertex.Set(renderCenter + rightVector.ScalarMult(flameRightRadius * scale));

						p_graphics->RenderLineStrip(4.5f * scale, &flameColor, 1, shapeVertices, 3, true);
					}
					if (ship->left == true)
					{
						if (ship->onFlameTimerMS == 0)
							// keep flame on for a while
							ship->onFlameTimerMS = flameFlickerMS;
						// sideways flame

						// right side
						float flameCornerLeftAngle = 100.0f; // degrees from front
						float flameCornerMiddleAngle = 105.0f; // degrees from front
						float flameCornerRightAngle = backCornerShipAngle;
						float flameCornerLeftRadiusFactor = 0.6f;
						float flameCornerMiddleRadiusFactor = 1.7f;
						float flameCornerRightRadiusFactor = backCornerShipRadiusFactor;

						if (ship->appliedBoost == true)
						{
							flameCornerMiddleAngle = 100.0f;
							flameCornerMiddleRadiusFactor = 2.4f;
						}

						// note: rotation Angle of zero faces straight up on screen
						float leftRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerLeftAngle);
						Vector3d leftVector = Vector3d(sin(leftRadians), -cos(leftRadians), 0.0f);
						float middleRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerMiddleAngle);
						Vector3d middleVector = Vector3d(sin(middleRadians), -cos(middleRadians), 0.0f);
						float rightRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + flameCornerRightAngle);
						Vector3d rightVector = Vector3d(sin(rightRadians), -cos(rightRadians), 0.0f);

						float flameLeftRadius = flameCornerLeftRadiusFactor * ship->radius;
						float flameMiddleRadius = flameCornerMiddleRadiusFactor * ship->radius;
						float flameRightRadius = flameCornerRightRadiusFactor * ship->radius;
						shapeVertices[0].vertex.Set(renderCenter + leftVector.ScalarMult(flameLeftRadius * scale));
						shapeVertices[1].vertex.Set(renderCenter + middleVector.ScalarMult(flameMiddleRadius * scale));
						shapeVertices[2].vertex.Set(renderCenter + rightVector.ScalarMult(flameRightRadius * scale));

						GameColor flameColor(255, 96, 64);
						flameColor.alpha = int(255.0f * ship->GetCloakedAlpha(renderFocusShipRef == ship));
						p_graphics->RenderLineStrip(4.5f * scale, &flameColor, 1, shapeVertices, 3, true);
					}
					else if (ship->right == true)
					{
						if (ship->onFlameTimerMS == 0)
							// keep flame on for a while
							ship->onFlameTimerMS = flameFlickerMS;
						// sideways flame

						// left side (left and right are 'switched', we'll just draw them backwards)
						float flameCornerLeftAngle = 100.0f; // degrees from front
						float flameCornerMiddleAngle = 105.0f; // degrees from front
						float flameCornerRightAngle = backCornerShipAngle;
						float flameCornerLeftRadiusFactor = 0.6f;
						float flameCornerMiddleRadiusFactor = 1.7f;
						float flameCornerRightRadiusFactor = backCornerShipRadiusFactor;

						if (ship->appliedBoost == true)
						{
							flameCornerMiddleAngle = 100.0f;
							flameCornerMiddleRadiusFactor = 2.4f;
						}

						// note: rotation Angle of zero faces straight up on screen
						float leftRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerLeftAngle);
						Vector3d leftVector = Vector3d(sin(leftRadians), -cos(leftRadians), 0.0f);
						float middleRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerMiddleAngle);
						Vector3d middleVector = Vector3d(sin(middleRadians), -cos(middleRadians), 0.0f);
						float rightRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - flameCornerRightAngle);
						Vector3d rightVector = Vector3d(sin(rightRadians), -cos(rightRadians), 0.0f);

						float flameLeftRadius = flameCornerLeftRadiusFactor * ship->radius;
						float flameMiddleRadius = flameCornerMiddleRadiusFactor * ship->radius;
						float flameRightRadius = flameCornerRightRadiusFactor * ship->radius;
						// draw backwards
						shapeVertices[2].vertex.Set(renderCenter + leftVector.ScalarMult(flameLeftRadius * scale));
						shapeVertices[1].vertex.Set(renderCenter + middleVector.ScalarMult(flameMiddleRadius * scale));
						shapeVertices[0].vertex.Set(renderCenter + rightVector.ScalarMult(flameRightRadius * scale));

						GameColor flameColor(255, 96, 64);
						flameColor.alpha = int(255.0f * ship->GetCloakedAlpha(renderFocusShipRef == ship));
						p_graphics->RenderLineStrip(4.5f * scale, &flameColor, 1, shapeVertices, 3, true);
					}
				}

				// flicker the flame for next time!
				if (ship->onFlameTimerMS > 0)
				{
					ship->onFlameTimerMS -= gameTimerRef->GetElapsedTimeMSFloat(); // flicker it!
					if (ship->onFlameTimerMS <= 0.0f)
					{
						// keep flame off for a while
						ship->offFlameTimerMS = flameFlickerMS;
						ship->onFlameTimerMS = 0;
					}
				}
				else if (ship->offFlameTimerMS > 0)
				{
					ship->offFlameTimerMS -= gameTimerRef->GetElapsedTimeMSFloat(); // flicker it!
					if (ship->offFlameTimerMS < 0)
						ship->offFlameTimerMS = 0;
				}

				// The ship
				// note: rotation Angle of zero faces straight up on screen
				float frontRadians = MathUtilities::DegreesToRadians(ship->rotationAngle);
				Vector3d shipFrontVector = Vector3d(sin(frontRadians), -cos(frontRadians), 0.0f);
				float backRightRadians = MathUtilities::DegreesToRadians(ship->rotationAngle + backCornerShipAngle);
				Vector3d shipBackRightVector = Vector3d(sin(backRightRadians), -cos(backRightRadians), 0.0f);
				float backLeftRadians = MathUtilities::DegreesToRadians(ship->rotationAngle - backCornerShipAngle);
				Vector3d shipBackLeftVector = Vector3d(sin(backLeftRadians), -cos(backLeftRadians), 0.0f);

				float backCornerShipRadius = backCornerShipRadiusFactor * ship->radius;
				float deathThroeScale = 1.0f;
				Vector3d shipPositionOffset = Vector3d::ZeroVector();
				if (ship->InDeathThroes())
				{
					// violent at first then calm down as approach explosion time
					//float factor = float(ship->deathThroesMS * ship->deathThroesMS) / 16000000.0f;
					float factor = ship->GetDeathThroeAnimationFactor();
					static FastRandom fastRandom;
					deathThroeScale = float(fastRandom.GetRandomInteger(80, 120)) / 100.0f;
					deathThroeScale = 1.0f + (deathThroeScale - 1.0f) * factor;
					// shake ship around violently at first then less until it explodes
					shipPositionOffset = Vector3d(float(fastRandom.GetRandomInteger(-20, 20)) / 4.0f, float(fastRandom.GetRandomInteger(-20, 20)) / 4.0f, 0.0f).ScalarMult(factor);
				}
				shapeVertices[0].vertex.Set(renderCenter + shipPositionOffset.ScalarMult(scale) + shipFrontVector.ScalarMult(frontShipRadius * scale * deathThroeScale));
				shapeVertices[1].vertex.Set(renderCenter + shipPositionOffset.ScalarMult(scale) + shipBackRightVector.ScalarMult(backCornerShipRadius * scale * deathThroeScale));
				shapeVertices[2].vertex.Set(renderCenter + shipPositionOffset.ScalarMult(scale) + shipBackLeftVector.ScalarMult(backCornerShipRadius * scale * deathThroeScale));
				shapeVertices[3].vertex = shapeVertices[0].vertex;

				GameColor shipColor = ship->GetRenderColor(renderFocusShipRef == ship); // flash ship in deaththroes and when take damage, force out of cloak when damaged, etc.
				p_graphics->RenderLineStrip(4.5f * scale, &shipColor, 1, shapeVertices, 4, true);
			}
		}

		void RenderBullets(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			// center is playfield coordinate representing where center of viewport lies
			// don't render a bullet outside the viewport

			float scale = GetRenderScale();
			Vector3d viewportCenter = Vector3d(float(viewportRef->GetWidth()) / 2.0f, float(viewportRef->GetHeight()) / 2.0f, 0.0f);

			LinkedListEnumerator<AsteroidsBullet> bulletEnumerator = LinkedListEnumerator<AsteroidsBullet>(bullets);
			while (bulletEnumerator.MoveNext())
			{
				AsteroidsBullet *bullet = &(bulletEnumerator.Current()->data);
				Vector3d renderCenter = playfield.NormalizeOffsetWithPlayfield(bullet->position - p_center).ScalarMult(scale) + viewportCenter;

				// don't render bullet before it exists
				if (bullet->minimumGameTimeMS > gameStateGameTimeMS) // GameTimeMS might have been adjusted
					continue;

				// see if asteroid is outside bounds of screen
				if (renderCenter.x + bullet->radius * scale < 0.0f)
					continue;
				if (renderCenter.y + bullet->radius * scale < 0.0f)
					continue;
				if (renderCenter.x - bullet->radius * scale > float(viewportRef->GetWidth()))
					continue;
				if (renderCenter.y - bullet->radius * scale > float(viewportRef->GetHeight()))
					continue;

				// Draw it!
				RenderSimpleCircle(p_graphics, renderCenter, bullet->radius * scale, bullet->ownerRef->color, 4.5f * scale);
			}
		}

		float GetRenderScale()
		{
			//if (GameContext::Instance->GetNetwork()->IsClient() == false)
			return float(viewportRef->GetHeight()) / 1080.0f;
			//else
			//return 2.0f * float(viewportRef->GetHeight()) / float(playfield.bounds.Y); 
		}

		float GetMessageListRenderScale()
		{
			// in case RenderScale gets a serious modification, message list should be scaled according to normal text size
			return float(viewportRef->GetHeight()) / 1080.0f;
		}

		void RenderAsteroids(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			float scale = GetRenderScale();
			Vector3d viewportCenter = Vector3d(float(viewportRef->GetWidth()) / 2.0f, float(viewportRef->GetHeight()) / 2.0f, 0.0f);

			// center is playfield coordinate representing where center of viewport lies
			// don't render an asteroid outside the viewport
			LinkedListEnumerator<AsteroidsAsteroid> asteroidEnumerator = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
			while (asteroidEnumerator.MoveNext())
			{
				AsteroidsAsteroid *asteroid = &(asteroidEnumerator.Current()->data);
				Vector3d renderCenter = playfield.NormalizeOffsetWithPlayfield(asteroid->position - p_center).ScalarMult(scale) + viewportCenter;

				// don't render asteroid before it exists
				if (asteroid->minimumGameTimeMS > gameStateGameTimeMS) // GameTimeMS might have been adjusted
					continue;

				// see if asteroid is outside bounds of screen
				if (renderCenter.x + asteroid->radius * scale < 0.0f)
					continue;
				if (renderCenter.y + asteroid->radius * scale < 0.0f)
					continue;
				if (renderCenter.x - asteroid->radius * scale > float(viewportRef->GetWidth()))
					continue;
				if (renderCenter.y - asteroid->radius * scale > float(viewportRef->GetHeight()))
					continue;

				// Draw it!
				RenderCircle(p_graphics, renderCenter, asteroid->radius * scale, GameColor(255, 128, 0), 4.5f * scale);
			}
		}

		void RenderExplosions(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			// center is playfield coordinate representing where center of viewport lies
			// don't render an explosion outside the viewport

			float scale = GetRenderScale();
			Vector3d viewportCenter = Vector3d(float(viewportRef->GetWidth()) / 2.0f, float(viewportRef->GetHeight()) / 2.0f, 0.0f);

			LinkedListEnumerator<AsteroidsExplosion> explosionEnumerator = LinkedListEnumerator<AsteroidsExplosion>(explosions);
			while (explosionEnumerator.MoveNext())
			{
				AsteroidsExplosion *explosion = &(explosionEnumerator.Current()->data);

				// make sure explosion is expanded next turn
				explosion->animate = true;

				if (explosion->radius <= 0.0f)
					continue;

				Vector3d renderCenter = playfield.NormalizeOffsetWithPlayfield(explosion->position - p_center).ScalarMult(scale) + viewportCenter;

				// see if asteroid is outside bounds of screen
				if (renderCenter.x + explosion->radius * scale < 0.0f)
					continue;
				if (renderCenter.y + explosion->radius * scale < 0.0f)
					continue;
				if (renderCenter.x - explosion->radius * scale > float(viewportRef->GetWidth()))
					continue;
				if (renderCenter.y - explosion->radius * scale > float(viewportRef->GetHeight()))
					continue;

				// Draw it!
				GameColor explosionColor = explosion->color;
				explosionColor.alpha = int(255.0f * pow(explosion->lifeMS / explosion->maxLifeMS, 0.3f)); // make it fade out
				RenderCircle(p_graphics, renderCenter, explosion->radius * scale, explosionColor, 4.5f * scale);
			}
		}

		void RenderPowerups(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			float scale = GetRenderScale();
			Vector3d viewportCenter = Vector3d(float(viewportRef->GetWidth()) / 2.0f, float(viewportRef->GetHeight()) / 2.0f, 0.0f);

			// center is playfield coordinate representing where center of viewport lies
			// don't render an asteroid outside the viewport
			LinkedListEnumerator<AsteroidsPowerup> powerupEnumerator = LinkedListEnumerator<AsteroidsPowerup>(powerups);
			while (powerupEnumerator.MoveNext())
			{
				AsteroidsPowerup *powerup = &(powerupEnumerator.Current()->data);
				Vector3d renderCenter = playfield.NormalizeOffsetWithPlayfield(powerup->position - p_center).ScalarMult(scale) + viewportCenter;

				// if it's a future object, don't render it
				if (powerupEnumerator.Current()->data.minimumGameTimeMS > gameStateGameTimeMS) // GameTimeMS might have been adjusted
					continue;

				float renderRadius = powerup->renderRadius;
				int lifeMSRemainder = int(powerupEnumerator.Current()->data.lifeMS) % 500;
				// pulsate every 500ms
				float radiusScale = 1.0f;
				// increase renderRadius to max half again
				radiusScale += radiusScale * 0.5f * float(lifeMSRemainder) / 500.0f;
				// fade away halfway through cycle
				int alpha = 255;
				if (lifeMSRemainder >= 250)
					alpha = int(255.0f * (500.0f - float(lifeMSRemainder)) / 250.0f);

				// see if asteroid is outside bounds of screen
				if (renderCenter.x + renderRadius * radiusScale * scale < 0.0f)
					continue;
				if (renderCenter.y + renderRadius * radiusScale * scale < 0.0f)
					continue;
				if (renderCenter.x - renderRadius * radiusScale * scale > float(viewportRef->GetWidth()))
					continue;
				if (renderCenter.y - renderRadius * radiusScale * scale > float(viewportRef->GetHeight()))
					continue;

				// Draw it!
				GameColor renderColor = powerup->GetRenderColor();
				renderColor.alpha = alpha;
				RenderCircle(p_graphics, renderCenter, renderRadius * radiusScale * scale, renderColor, 6.0f * radiusScale * scale);
			}
		}

		void RenderHealthBar(GraphicsBase *p_graphics, GameViewport ^p_viewport, float &p_topRenderY)
		{
			// doing screen position calculations even if ship is destroyed so that calling routine has a meaningful number to work with
			// if ship is destroyed, nothing is rendered

			float healthBarWidth = float(p_viewport->GetHeight()) * 0.7f;
			float healthBarHeight = healthBarWidth / 24.0f;
			float healthBarMargin = 10.0f * GetRenderScale();
			float healthBarX = float(p_viewport->GetWidth()) / 2.0f - healthBarWidth / 2.0f;
			float healthBarY = float(p_viewport->GetHeight()) - healthBarMargin - healthBarHeight;
			if (renderFocusShipRef != nullptr && renderFocusShipRef->IsDestroyed() == false)
				p_graphics->RenderFilledRectangle(RectangleF(healthBarX, healthBarY, healthBarWidth * renderFocusShipRef->GetHealthMeterFillPercentage(), healthBarHeight), renderFocusShipRef->GetHealthMeterColor());

			float shieldBarWidth = healthBarWidth;
			float shieldBarHeight = healthBarHeight / 2.0f;
			float shieldBarX = float(p_viewport->GetWidth()) / 2.0f - healthBarWidth / 2.0f;
			float shieldBarY = float(p_viewport->GetHeight()) - healthBarMargin - healthBarHeight - shieldBarHeight;
			if (renderFocusShipRef != nullptr && renderFocusShipRef->IsDestroyed() == false)
				p_graphics->RenderFilledRectangle(RectangleF(shieldBarX, shieldBarY, shieldBarWidth * renderFocusShipRef->GetShieldMeterFillPercentage(), shieldBarHeight), GameColor(32, 255, 255));

			float boostBarWidth = float(p_viewport->GetHeight()) * 0.2f;
			float boostBarHeight = healthBarHeight;
			float boostBarX = healthBarX + healthBarWidth + 60.0f;
			float boostBarY = healthBarY;
			if (renderFocusShipRef != nullptr && renderFocusShipRef->IsDestroyed() == false)
				p_graphics->RenderFilledRectangle(RectangleF(boostBarX, boostBarY, boostBarWidth * renderFocusShipRef->GetBoostMeterFillPercentage(), boostBarHeight), GameColor(255, 32, 32));

			p_topRenderY = shieldBarY; // main routine needs to know where shield bar was rendered
		}

		void RenderShipHealthBars(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			float scale = GetRenderScale();
			Vector3d viewportCenter = Vector3d(float(viewportRef->GetWidth()) / 2.0f, float(viewportRef->GetHeight()) / 2.0f, 0.0f);

			// center is playfield coordinate representing where center of viewport lies
			// don't render a ship outside the viewport

			float healthBarWorldMarginAboveShip = 40.0f;
			float healthBarHalfWidth = 30.0f;
			float healthBarHalfHeight = 5.0f; // full height 10
			float healthBarVerticalPortionShield = 4.0f; // how much from top is taken up by shield?

			ModelVertex shapeVertices[5];
			shapeVertices[0].colorIndex = 0;
			shapeVertices[1].colorIndex = 0;
			shapeVertices[2].colorIndex = 0;
			shapeVertices[3].colorIndex = 0;
			shapeVertices[4].colorIndex = 0;

			LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnumerator.MoveNext())
			{
				AsteroidsShip *ship = &(shipEnumerator.Current()->data);
				if (ship->DisplayHealthMeter() == false)
					continue;

				Vector3d renderCenter = playfield.NormalizeOffsetWithPlayfield(ship->position - p_center - Vector3d(0.0, healthBarWorldMarginAboveShip, 0.0)).ScalarMult(scale) + viewportCenter;

				// see if healthbar is outside bounds of screen (check against largest radius)
				if (renderCenter.x + healthBarHalfWidth * scale < 0.0f)
					continue;
				if (renderCenter.y + healthBarHalfHeight * scale < 0.0f)
					continue;
				if (renderCenter.x - healthBarHalfWidth * scale > float(viewportRef->GetWidth()))
					continue;
				if (renderCenter.y - healthBarHalfHeight * scale > float(viewportRef->GetHeight()))
					continue;

				// Draw it!

				// shield bar
				if (ship->GetShieldMeterFillPercentage() > 0.0f)
				{
					shapeVertices[0].vertex.Set(renderCenter + Vector3d(-healthBarHalfWidth, -healthBarHalfHeight, 0.0).ScalarMult(scale));
					shapeVertices[1].vertex.Set(renderCenter + Vector3d(healthBarHalfWidth, -healthBarHalfHeight, 0.0).ScalarMult(scale));
					shapeVertices[2].vertex.Set(renderCenter + Vector3d(healthBarHalfWidth, -healthBarHalfHeight + healthBarVerticalPortionShield, 0.0).ScalarMult(scale));
					shapeVertices[3].vertex.Set(renderCenter + Vector3d(-healthBarHalfWidth, -healthBarHalfHeight + healthBarVerticalPortionShield, 0.0).ScalarMult(scale));
					shapeVertices[4].vertex = shapeVertices[0].vertex;

					p_graphics->RenderFilledRectangle(
						RectangleF(
						shapeVertices[0].vertex.x,
						shapeVertices[0].vertex.y,
						(shapeVertices[2].vertex.x - shapeVertices[0].vertex.x) * (ship->GetShieldMeterFillPercentage()),
						shapeVertices[2].vertex.y - shapeVertices[0].vertex.y),
						GameColor(32, 255, 255));
				}
				else
				{
					// just render health part, keep lower line of meter in same position
					healthBarHalfHeight -= (healthBarVerticalPortionShield / 2.0f);
					renderCenter.y += (healthBarVerticalPortionShield / 2.0f);
					healthBarVerticalPortionShield = 0.0f;
				}


				// health bar
				shapeVertices[0].vertex.Set(renderCenter + Vector3d(-healthBarHalfWidth, -healthBarHalfHeight + healthBarVerticalPortionShield, 0.0).ScalarMult(scale));
				shapeVertices[1].vertex.Set(renderCenter + Vector3d(healthBarHalfWidth, -healthBarHalfHeight + healthBarVerticalPortionShield, 0.0).ScalarMult(scale));
				shapeVertices[2].vertex.Set(renderCenter + Vector3d(healthBarHalfWidth, healthBarHalfHeight, 0.0).ScalarMult(scale));
				shapeVertices[3].vertex.Set(renderCenter + Vector3d(-healthBarHalfWidth, healthBarHalfHeight, 0.0).ScalarMult(scale));
				shapeVertices[4].vertex = shapeVertices[0].vertex;

				p_graphics->RenderFilledRectangle(
					RectangleF(
					shapeVertices[0].vertex.x,
					shapeVertices[0].vertex.y,
					(shapeVertices[2].vertex.x - shapeVertices[0].vertex.x) * (ship->GetHealthMeterFillPercentage()),
					shapeVertices[2].vertex.y - shapeVertices[0].vertex.y),
					ship->GetHealthMeterColor());

				// boundary
				shapeVertices[0].vertex.Set(renderCenter + Vector3d(-healthBarHalfWidth, -healthBarHalfHeight, 0.0).ScalarMult(scale));
				shapeVertices[1].vertex.Set(renderCenter + Vector3d(healthBarHalfWidth, -healthBarHalfHeight, 0.0).ScalarMult(scale));
				shapeVertices[2].vertex.Set(renderCenter + Vector3d(healthBarHalfWidth, healthBarHalfHeight, 0.0).ScalarMult(scale));
				shapeVertices[3].vertex.Set(renderCenter + Vector3d(-healthBarHalfWidth, healthBarHalfHeight, 0.0).ScalarMult(scale));
				shapeVertices[4].vertex = shapeVertices[0].vertex;

				p_graphics->RenderLineStrip(2.0f, &(GameColor(32, 128, 32)), 1, shapeVertices, 5, true);
			}
		}

		void RenderRadar(GraphicsBase *p_graphics, GameViewport ^p_viewport, Vector3d &p_center)
		{
			if (renderFocusShipRef != nullptr)
			{
				if (renderFocusShipRef->IsDestroyed())
					return;
			}
			else
				return;

			float scale = GetRenderScale();

			float radarHeight = float(p_viewport->GetHeight()) / 5.0f;
			float radarWidth = radarHeight;
			float radarInternalEdgeMargin = 5.0f * scale;
			float radarMargin = 10.0f * scale;
			// upper right for now
			float radarLeft = float(p_viewport->GetWidth()) - radarWidth - radarMargin;
			float radarTop = radarMargin;
			float radarCenterX = radarLeft + radarWidth / 2.0f;
			float radarCenterY = radarTop + radarHeight / 2.0f;

			// background
			p_graphics->RenderFilledRectangle(RectangleF(radarLeft, radarTop, radarWidth, radarHeight), GameColor(0, 0, 0));

			float dimension = 3.0f * scale;
			LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnumerator.MoveNext())
			{
				AsteroidsShip *ship = &(shipEnumerator.Current()->data);
				if (ship->IsDestroyed() == true)
					continue;
				// save rendering focus ship for last
				if (ship == renderFocusShipRef)
					continue;
				// cloaked ships don't show up on radar
				if (ship->IsCloaked() == true && ship != renderFocusShipRef) // second comparison is redundant
					continue;

				Vector3d dotCenter = Vector3d(radarCenterX, radarCenterY, 0.0f) + playfield.NormalizeOffsetWithPlayfield(ship->position - p_center).ScalarMult((radarWidth - radarInternalEdgeMargin) / playfield.bounds.X);
				p_graphics->RenderFilledRectangle(RectangleF(dotCenter.x - dimension, dotCenter.y - dimension, dimension * 2.0f, dimension * 2.0f), ship->color);
			}
			if (renderFocusShipRef != nullptr)
			{
				// now render focus ship last, on top
				AsteroidsShip *ship = renderFocusShipRef;
				if (ship->IsDestroyed() == false)
				{
					Vector3d dotCenter = Vector3d(radarCenterX, radarCenterY, 0.0f) + playfield.NormalizeOffsetWithPlayfield(ship->position - p_center).ScalarMult((radarWidth - radarInternalEdgeMargin) / playfield.bounds.X);
					p_graphics->RenderFilledRectangle(RectangleF(dotCenter.x - dimension, dotCenter.y - dimension, dimension * 2.0f, dimension * 2.0f), ship->color);
				}
			}

			// border
			ModelVertex shapeVertices[5];
			shapeVertices[0].colorIndex = 0;
			shapeVertices[1].colorIndex = 0;
			shapeVertices[2].colorIndex = 0;
			shapeVertices[3].colorIndex = 0;
			shapeVertices[4].colorIndex = 0;
			shapeVertices[0].vertex.Set(radarLeft, radarTop, 0.0f);
			shapeVertices[1].vertex.Set(radarLeft + radarWidth, radarTop, 0.0f);
			shapeVertices[2].vertex.Set(radarLeft + radarWidth, radarTop + radarHeight, 0.0f);
			shapeVertices[3].vertex.Set(radarLeft, radarTop + radarHeight, 0.0f);
			shapeVertices[4].vertex = shapeVertices[0].vertex;
			GameColor borderColor(255, 255, 255);
			p_graphics->RenderLineStrip(1.0f, &borderColor, 1, shapeVertices, 5);
		}

		AsteroidsShip * CreateShip(GameColor &p_color)
		{
			LinkedListNode<AsteroidsShip> *newShip = ships.GetNewNode();
			newShip->data.Initialize();
			newShip->data.color = p_color;
			ships.AddNode(newShip);

			return &(newShip->data);
		}

		void RemoveShip(int p_playerId)
		{
			LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnum.MoveNext())
			{
				if (shipEnum.Current()->data.playerId == p_playerId)
				{
					asteroidsShipColorRegistry.FreeColor(shipEnum.Current()->data.color);

					ships.DeleteNode(shipEnum.Current());
					return;
				}
			}
		}

		void StartSinglePlayer()
		{
			CreateNewPlayfield();
			gameType = AsteroidsGameType::SinglePlayer;

			// place ship
			localPlayerShipRef = CreateShip(asteroidsShipColorRegistry.GetAvailableColor());
			renderFocusShipRef = localPlayerShipRef;

			// 15 more ships!!!
			bool makePracticeShips = true;
			if (makePracticeShips == true)
			{
				for (int i = 0; i < 15; i++)
				{
					CreateShip(asteroidsShipColorRegistry.GetAvailableColor());
				}
			}

			messageList->AddMessage("Single Player Started");

			// tests
			//messageList->AddMessage("Single <color=ff6566>player</color> <b>star</b>ted");
			//messageList->AddMessage("Here's another with some really long words, because I want to test if it will properly <b>advance to the next line so that</b> things look gewwwwwd");
			//messageList->AddMessage("<b>WATCH OUT</b> - aw.....");
			//messageList->AddMessage("Here's another test with some words with no spaces at all, just separated by commas,dashes-and periods.and a lot              of spaces.I'm hoping things properly render");
		}

		AsteroidsShip * HostStartMultiplayer()
		{
			// ship created for server
			CreateNewPlayfield();
			gameType = AsteroidsGameType::Multiplayer;

			// place ship
			localPlayerShipRef = CreateShip(asteroidsShipColorRegistry.GetAvailableColor());
			renderFocusShipRef = localPlayerShipRef;
			localPlayerShipRef->playerId = GameContext::Instance->GetNetwork()->GetLocalUserId();

			return localPlayerShipRef;
		}

		void ClientStartMultiplayer()
		{
			// ship created for server
			ResetAllData();
			gameType = AsteroidsGameType::Multiplayer;

			// no ship or asteroids yet... waiting for gamestate from server
		}

		void CreateNewPlayfield()
		{
			ResetAllData();

			FastRandom fastRandom;

			// place asteroids
			float singleAsteroidSpawnArea = largeAsteroidRadius * largeAsteroidRadius * 360; // smaller area = more asteroids (was 240)
			int asteroidQty = int(playfield.bounds.X * playfield.bounds.Y / singleAsteroidSpawnArea * AsteroidsAppSettings::asteroidsSaturationLevel);
			if (AsteroidsDebugSettings::maxAsteroidQty != -1 && asteroidQty > AsteroidsDebugSettings::maxAsteroidQty)
				asteroidQty = AsteroidsDebugSettings::maxAsteroidQty;
			for (int i = 0; i < asteroidQty; i++)
			{
				LinkedListNode<AsteroidsAsteroid> *newAsteroid = asteroids.GetNewNode();
				newAsteroid->data.Initialize();
				float randomAngle = MathUtilities::DegreesToRadians(float(fastRandom.GetRandomInteger(0, 359)));
				float maxSpeedPerMS = 200.0f / 1000.0f;
				float randomSpeedPerMS = float(fastRandom.GetRandomInteger(5, 10)) / 10.0f * maxSpeedPerMS;
				PointF randomVelocity = PointF(cos(randomAngle) * randomSpeedPerMS, sin(randomAngle) * randomSpeedPerMS);
				newAsteroid->data.SetPositionVelocityAndRadius(
					PointF(float(fastRandom.GetRandomInteger(0, 99)) / 100.0f * playfield.bounds.X, float(fastRandom.GetRandomInteger(0, 99)) / 100.0f * playfield.bounds.Y),
					randomVelocity,
					largeAsteroidRadius);
				newAsteroid->data.type = AsteroidType::Large;
				newAsteroid->data.minimumGameTimeMS = gameTimerRef->GetGameTimeMS();
				asteroids.AddAsteroid(newAsteroid);
			}
		}

		// from server
		void AddAsteroid(int p_id, Vector3d &p_position, Vector3d &p_velocity, int p_type, float p_radius, int p_minimumGameTimeMS)
		{
			LinkedListNode<AsteroidsAsteroid> *newAsteroid = asteroids.GetNewNode();
			newAsteroid->data.Initialize(false);
			newAsteroid->data.Id = p_id;
			newAsteroid->data.SetPositionVelocityAndRadius(
				PointF(p_position.x, p_position.y),
				PointF(p_velocity.x, p_velocity.y),
				p_radius);
			newAsteroid->data.type = p_type;
			newAsteroid->data.minimumGameTimeMS = p_minimumGameTimeMS;
			asteroids.AddAsteroid(newAsteroid);
		}

		void UpdateAsteroid(int p_id, Vector3d &p_position, Vector3d &p_velocity, int p_type, float p_radius, int p_minimumGameTimeMS)
		{
			LinkedListEnumerator<AsteroidsAsteroid> asteroidEnum = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
			while (asteroidEnum.MoveNext())
			{
				if (asteroidEnum.Current()->data.Id == p_id)
				{
					asteroidEnum.Current()->data.SetPositionVelocityAndRadius(
						PointF(p_position.x, p_position.y),
						PointF(p_velocity.x, p_velocity.y),
						p_radius);
					asteroidEnum.Current()->data.type = p_type;
					asteroidEnum.Current()->data.minimumGameTimeMS = p_minimumGameTimeMS;

					break;
				}
			}
		}

		void RemoveAsteroid(int p_id)
		{
			LinkedListEnumerator<AsteroidsAsteroid> asteroidEnum = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
			while (asteroidEnum.MoveNext())
			{
				if (asteroidEnum.Current()->data.Id == p_id)
				{
					asteroids.RemoveAsteroid(asteroidEnum.Current());
					break;
				}
			}
		}

		void AddPowerup(int p_id, Vector3d &p_position, Vector3d &p_velocity, int p_type, int p_minimumGameTimeMS)
		{
			LinkedListNode<AsteroidsPowerup> *newPowerup = powerups.GetNewNode();
			newPowerup->data.Initialize(false);
			newPowerup->data.Id = p_id;
			newPowerup->data.position = p_position;
			newPowerup->data.velocity = p_velocity;
			newPowerup->data.type = p_type;
			newPowerup->data.minimumGameTimeMS = p_minimumGameTimeMS;
			powerups.AddNode(newPowerup);
		}

		void RemovePowerup(int p_id)
		{
			LinkedListEnumerator<AsteroidsPowerup> powerupEnum = LinkedListEnumerator<AsteroidsPowerup>(powerups);
			while (powerupEnum.MoveNext())
			{
				if (powerupEnum.Current()->data.Id == p_id)
				{
					powerups.DeleteNode(powerupEnum.Current());
					break;
				}
			}
		}

		void ApplyPowerup(int p_powerupType, AsteroidsShip *p_ship)
		{
			AsteroidsPowerup::ApplyToShip(p_powerupType, p_ship);

			if (p_ship == localPlayerShipRef)
				ShowPowerupPickupMessage(p_powerupType);
		}

		void ShowPowerupPickupMessage(int p_powerupType)
		{
			switch (p_powerupType)
			{
			case AsteroidsPowerupType::Cloak:
				messageList->AddMessage("Picked up <b><color=ff20ff>Cloak</color></b>");
				break;
			case AsteroidsPowerupType::Health:
				messageList->AddMessage("Picked up <b><color=20ff20>Health</color></b>");
				break;
			case AsteroidsPowerupType::Shield:
				messageList->AddMessage("Picked up <b><color=20ffff>Shield</color></b>");
				break;
			case AsteroidsPowerupType::Weapon:
				messageList->AddMessage("Picked up <b><color=ff2020>Super Shot</color></b>");
				break;
			}
		}

		LinkedListNode<AsteroidsBullet> * AddBullet(int p_id, int p_parentShipId, Vector3d &p_position, Vector3d &p_velocity, bool p_super, float p_radius, float p_lifeMS, int p_minimumGameTimeMS)
		{
			AsteroidsShip *ownerShip = nullptr;
			LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnum.MoveNext())
			{
				if (shipEnum.Current()->data.Id == p_parentShipId)
				{
					ownerShip = &(shipEnum.Current()->data);
					break;
				}
			}
			if (ownerShip != nullptr)
			{
				LinkedListNode<AsteroidsBullet> *newBullet = bullets.GetNewNode();
				newBullet->data.Initialize(false);
				newBullet->data.Id = p_id;
				newBullet->data.SetPositionVelocityLifeRadius(
					ownerShip,
					p_position,
					p_velocity,
					p_lifeMS,
					p_radius,
					p_super);
				newBullet->data.super = p_super;
				newBullet->data.radius = p_radius;
				newBullet->data.minimumGameTimeMS = p_minimumGameTimeMS;
				bullets.AddNode(newBullet);

				return newBullet;
			}

			return nullptr;
		}

		void BulletRetconCollisions(LinkedListNode<AsteroidsBullet> *p_bulletNode)
		{
			// game state is currently adnvaced to gameStateGameTimeMS.  Bullet has time p_bulletGameTimeMS
			// check collisions back from p_bulletGameTimeMS to gameStateGameTimeMS.

			// bullet is exactly current or in the future.  Do nothing.  And in next iteration, make sure no collisions occur beore this time
			// bullet path is from its time of creation to the advanced gameState time of the current game state.
			if (p_bulletNode->data.minimumGameTimeMS >= gameStateGameTimeMS)
				return;

			float elapsedTimeMSf = float(gameStateGameTimeMS - p_bulletNode->data.minimumGameTimeMS);
			float noCollision = 10.0f;
			float firstCollisionT = noCollision;

			LinkedListNode<AsteroidsAsteroid> *collisionAsteroid = nullptr;
			AsteroidsShip *collisionShip = nullptr;
			Vector3d collisionPoint;

			// prevent collisions that occur before the asteroid existed (asteroid.minimumGameTimeMS)
			Vector3d bulletMove = p_bulletNode->data.velocity.ScalarMult(elapsedTimeMSf);
			Vector3d bulletOriginalPosition = p_bulletNode->data.position - bulletMove;
			LinkedListEnumerator<AsteroidsAsteroid> asteroidEnum = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
			while (asteroidEnum.MoveNext())
			{
				AsteroidsAsteroid *asteroid = &(asteroidEnum.Current()->data);
				Vector3d asteroidMove = asteroid->velocity.ScalarMult(elapsedTimeMSf);
				Vector3d asteroidOriginalPosition = playfield.NormalizeOffsetWithPlayfield(asteroid->position - asteroidMove - bulletOriginalPosition) + bulletOriginalPosition;

				float collisionT = 1.0f;
				if (MathUtilities::SphereSphereCollision(bulletOriginalPosition, bulletMove - asteroidMove, p_bulletNode->data.radius, asteroidOriginalPosition, asteroid->radius, collisionT) == true)
				{
					if (collisionT < firstCollisionT)
					{
						int collisionGameTimeMS = int(p_bulletNode->data.minimumGameTimeMS + elapsedTimeMSf * collisionT);
						if (collisionGameTimeMS >= asteroid->minimumGameTimeMS)
						{
							firstCollisionT = collisionT;
							collisionAsteroid = asteroidEnum.Current();
							collisionShip = nullptr;
							collisionPoint = playfield.NormalizePositionWithPlayfield(bulletOriginalPosition + bulletMove.ScalarMult(firstCollisionT));
						}
					}
				}
			}

			LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnum.MoveNext())
			{
				AsteroidsShip *ship = &(shipEnum.Current()->data);
				Vector3d shipMove = ship->velocity.ScalarMult(elapsedTimeMSf);
				Vector3d shipOriginalPosition = playfield.NormalizeOffsetWithPlayfield(ship->position - shipMove - bulletOriginalPosition) + bulletOriginalPosition;

				float collisionT = 1.0f;
				if (MathUtilities::SphereSphereCollision(bulletOriginalPosition, bulletMove - shipMove, p_bulletNode->data.radius, shipOriginalPosition, ship->radius, collisionT) == true)
				{
					if (collisionT < firstCollisionT)
					{
						int collisionGameTimeMS = int(p_bulletNode->data.minimumGameTimeMS + elapsedTimeMSf * collisionT);

						// todo: watch for ship minimum collision time, if appropriate

						firstCollisionT = collisionT;
						collisionShip = &(shipEnum.Current()->data);
						collisionAsteroid = nullptr;
						collisionPoint = playfield.NormalizePositionWithPlayfield(bulletOriginalPosition + bulletMove.ScalarMult(firstCollisionT));
					}
				}
			}

			if (firstCollisionT != noCollision)
			{
				if (collisionAsteroid != nullptr)
					BulletHitsAsteroid(p_bulletNode, collisionAsteroid, collisionAsteroid->data.velocity.ScalarMult(elapsedTimeMSf), collisionPoint, firstCollisionT, elapsedTimeMSf, gameStateGameTimeMS);
				else if (collisionShip != nullptr)
					BulletHitsShip(p_bulletNode, collisionShip, collisionPoint, firstCollisionT, elapsedTimeMSf, gameStateGameTimeMS);
			}
		}

		void RemoveBullet(int p_id, int p_parentShipId)
		{
			AsteroidsShip *ownerShip = nullptr;
			LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(ships);
			while (shipEnum.MoveNext())
			{
				if (shipEnum.Current()->data.Id == p_parentShipId)
				{
					ownerShip = &(shipEnum.Current()->data);
					break;
				}
			}
			if (ownerShip != nullptr)
			{
				LinkedListEnumerator<AsteroidsBullet> bulletEnum = LinkedListEnumerator<AsteroidsBullet>(bullets);
				while (bulletEnum.MoveNext())
				{
					if (bulletEnum.Current()->data.Id == p_id)
					{
						bullets.RemoveBullet(bulletEnum.Current());
						break;
					}
				}
			}
		}

		// player, packet->shipId, position, packet->velocity, GameColor(packet->color), packet->destroyed, packet->gameTimeVersion
		AsteroidsShip * AddShip(GameNetworkPlayerBase *p_player, int p_id, 
			int p_spinDirection, bool p_thrust, bool p_backwards, bool p_left, bool p_right, bool p_boost,
			Vector3d &p_position, Vector3d &p_velocity, float p_rotationAngle, GameColor &p_color, bool p_destroyed,
			float p_health, float p_shield, float p_boostFuel, float p_cloakMS, float p_deathThroesMS, float p_deathThroeRotationAnglePerMS, 
			int p_gameTimeVersion);

		void RetconAnimateShip(AsteroidsShip *p_ship, float p_elapsedTimeMS, bool p_checkCollisions)
		{
			float timeStep = 50.0f;
			float timeToConsumeMSf = p_elapsedTimeMS;
			while (timeToConsumeMSf > 0.0f)
			{
				if (timeToConsumeMSf > timeStep)
				{
					p_ship->Animate(timeStep, playfield, true);
					timeToConsumeMSf -= timeStep;
				}
				else
				{
					p_ship->Animate(timeToConsumeMSf, playfield, true);
					timeToConsumeMSf = 0.0f;
				}

				if (p_checkCollisions == true)
				{
					// oh gawd!
					// ??
				}
			}
		}

		void Disconnect()
		{
			GameContext::Instance->GetNetwork()->Disconnect();

			ResetAllData();
		}

		void SendChatMessage(String ^p_message, int p_toPlayerId = -1)
		{
			AsteroidsNetworkChatPacket chatPacket;
			AsteroidsNetworkPacketHelper::PopulateChatPacket(chatPacket, p_message, GameContext::Instance->GetNetwork()->GetLocalUserId(), p_toPlayerId);
			if (GameContext::Instance->GetNetwork()->IsServer())
			{
				// echo to screen, as a tell or as a public
				EchoChatMessage(p_message, GameContext::Instance->GetNetwork()->GetLocalUserId());

				// send to all clients or just one
				if (p_toPlayerId == -1)
				{
					GameContext::Instance->GetNetwork()->SendToAllClientsNow((char *)&chatPacket, chatPacket.length, 0);
				}
				else
				{
					GameNetworkClient *client = GameContext::Instance->GetNetwork()->GetClientByClientId(p_toPlayerId);
					if (client != nullptr && client->GetStatus() == NetworkClientStatus::Validated)
						GameContext::Instance->GetNetwork()->SendToClientNow(GameContext::Instance->GetNetwork()->GetClientByClientId(p_toPlayerId), (char *)&chatPacket, chatPacket.length, 0);
				}
			}
			else if (GameContext::Instance->GetNetwork()->IsClient())
			{
				// don't echo, need to wait for echo back from server

				// send to server
				GameContext::Instance->GetNetwork()->SendToServerNow((char *)&chatPacket, chatPacket.length, 0);
			}
		}

		void EchoChatMessage(String ^p_message, int p_fromPlayerId, bool p_tell = false);

	private:

		void InitializeCircleVertices()
		{
			circleVertexQty = 33;
			circleVertices = new ModelVertex[circleVertexQty];
			for (int i = 0; i < circleVertexQty - 1; i++)
			{
				float angle = MathUtilities::DegreesToRadians(float(i) / float(circleVertexQty - 1) * 360.0f);
				circleVertices[i].colorIndex = 0;
				// winds clockwise
				circleVertices[i].vertex.Set(cos(angle), sin(angle), 0.0f);
			}
			circleVertices[circleVertexQty - 1].colorIndex = 0;
			circleVertices[circleVertexQty - 1].vertex.Set(circleVertices[0].vertex);
		}

		void InitializeSimpleCircleVertices()
		{
			simpleCircleVertexQty = 8;
			simpleCircleVertices = new ModelVertex[simpleCircleVertexQty];
			for (int i = 0; i < simpleCircleVertexQty - 1; i++)
			{
				float angle = MathUtilities::DegreesToRadians(float(i) / float(simpleCircleVertexQty - 1) * 360.0f);
				simpleCircleVertices[i].colorIndex = 0;
				// winds clockwise
				simpleCircleVertices[i].vertex.Set(cos(angle), sin(angle), 0.0f);
			}
			simpleCircleVertices[simpleCircleVertexQty - 1].colorIndex = 0;
			simpleCircleVertices[simpleCircleVertexQty - 1].vertex.Set(simpleCircleVertices[0].vertex);
		}

		void RenderCircle(GraphicsBase *p_graphics, Vector3d &p_center, float p_radius, GameColor &p_color, float p_width = 1.0f)
		{
			p_graphics->PushMatrix();
			p_graphics->Translate(p_center.x, p_center.y, p_center.z);
			p_graphics->Scale(p_radius, p_radius, 1.0f);
			p_graphics->RenderLineStrip(p_width, &p_color, 1, circleVertices, circleVertexQty, true);
			p_graphics->PopMatrix();
		}

		void RenderSimpleCircle(GraphicsBase *p_graphics, Vector3d &p_center, float p_radius, GameColor &p_color, float p_width = 1.0f)
		{
			p_graphics->PushMatrix();
			p_graphics->Translate(p_center.x, p_center.y, p_center.z);
			p_graphics->Scale(p_radius, p_radius, 1.0f);
			p_graphics->RenderLineStrip(p_width, &p_color, 1, simpleCircleVertices, simpleCircleVertexQty, true);
			p_graphics->PopMatrix();
		}

	public:
		void SetPlayfieldBounds(float p_width, float p_height)
		{
			playfield.bounds.X = p_width;
			playfield.bounds.Y = p_height;
		}

		void Animate(float p_elapsedTimeMS, int p_gameTimeMS);

		void CheckForCollisions(float p_animationTimeMS, int p_gameTimeMS)
		{
			// animation time is the full time slice of the iteration (a segment of the full elapsedTimeMS for the gametick, and is equal to what was called for Animate)
			// p_gameTimeMS represents the game time at the END of p_animationTimeMS

			// It's understood that every object has a current position with a moveOffset that represents where they came from.  moveOffset is NOT normalized in the playfield for simplicity here.
			//    If you want the true prior position in the playfield, you must normalize(position - moveOffset)
			// current position is the render position and represents the END of the movement for the object for this segment of animation
			// To get objects in the same domain of coordinates for comparison, get a normalized offset between them, and use one object's position as the other object's position plus that offset
			// Bullets may be stationary and just checking for overlap, or at the end of their travel having not gone for the entire period of elapsed time (data on the bullet signifies this)
			// Ships may bounce off each other and require a re-evaluation of their collisions with bullets and ships again, like billiards. (in online situations they may also end up inside each other)

			// find earliest collision, handle it, then come back and find the next collision, handle that, etc.
			// this allows billard-style ship collision and lets first bullets win against later ones on asteroids and ships

			// since every object is in the exact same time domain both at their end positions and their moveOffsets, collisions can be handled by a 0.0-1.0 factor basis
			// any altered objects (created, velocities changed, etc.) MUST be placed back in their lists obeying how they would have looked had they had that velocity already - that is,
			//   their moveOffsets and final position must reflect the same 0.0-1.0 time slice, so that they comply with what this routine requires for continued collision checking to continue

			// note that retcon collisions are handled with completely different routines when object creation/update packets are received and treat obejcts according to their velocities 
			//   stretched back to the time the obejct needs to be processed all the way up to current gameTimeMS - moveOffsets are ignored there - more appropriate move vectors are created
			//   locally for the purposes of those routines, then discarded.  Since those routines are called after all Animate() and CheckForCollisons() are called for the entire game tick,
			//   there is no need to create moveOffsets for those objects - that will be handled when the new DoGameLoop() is called after the render

			float startMove = 0.0f;
			float endMove = 1.0f;
			float firstCollisionT = 0.0f; // to enter
			while (firstCollisionT < 1.0f)
			{
				float noCollision = 10.0f;
				firstCollisionT = noCollision; // will be 0.0 - 1.0 if a collison occurs
				LinkedListNode<AsteroidsShip> *collisionShip = nullptr;
				LinkedListNode<AsteroidsShip> *collisionShip2 = nullptr; /// used in ship-ship collision only
				LinkedListNode<AsteroidsPowerup> *collisionPowerup = nullptr;
				LinkedListNode<AsteroidsAsteroid> *collisionAsteroid = nullptr;
				LinkedListNode<AsteroidsBullet> *collisionBullet = nullptr;
				Vector3d collisionPoint;

				// Bullets and asteroids/ships - use moveFactor of bullet since it might not have travelled all the way to 1.0, if its life has run out
				// todo: should we just detail a full move to 1.0f for the bullet to make the calcualtions below more consistent, and use moveFactor < 1.0f that way?  check bullet->animate()
				LinkedListEnumerator<AsteroidsBullet> bulletEnumerator = LinkedListEnumerator<AsteroidsBullet>(bullets);
				while (bulletEnumerator.MoveNext())
				{
					Vector3d bulletPosition = bulletEnumerator.Current()->data.position;
					Vector3d bulletMove = bulletEnumerator.Current()->data.moveOffset;
					Vector3d bulletPriorPosition = playfield.NormalizePositionWithPlayfield(bulletPosition - bulletMove);
					float bulletRadius = bulletEnumerator.Current()->data.radius;
					float moveFactor = 1.0f;
					if (bulletEnumerator.Current()->data.removeAfterAnimate == true)
					{
						// adjust bullet so that it looks like it moved full but still starts in the same place - limit collisions to a t < moveFactor
						moveFactor = bulletEnumerator.Current()->data.factorTravelled;
						bulletMove = bulletMove.ScalarMult(1.0f / moveFactor);  // convert bulletMove to a full movement to t=1.0f
						bulletPosition = playfield.NormalizePositionWithPlayfield(bulletPriorPosition + bulletMove);
					}
					// if check is starting after point where bullet is done, skip
					if (startMove > moveFactor)
						continue;

					LinkedListEnumerator<AsteroidsAsteroid> asteroidEnumerator = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
					while (asteroidEnumerator.MoveNext())
					{
						// get same domain coordinate of asteroid
						Vector3d asteroidPosition = asteroidEnumerator.Current()->data.position;
						Vector3d asteroidMove = asteroidEnumerator.Current()->data.moveOffset;
						Vector3d asteroidPriorPosition = playfield.NormalizeOffsetWithPlayfield(asteroidPosition - asteroidMove - bulletPriorPosition) + bulletPriorPosition;
						float collisionT;
						if (MathUtilities::SphereSphereCollision(bulletPriorPosition,
							(bulletMove - asteroidEnumerator.Current()->data.moveOffset),
							bulletRadius,
							asteroidPriorPosition, 
							asteroidEnumerator.Current()->data.radius, collisionT) == true)
						{
							if (collisionT < firstCollisionT && collisionT >= startMove && collisionT < moveFactor) // limit collisions to startMove or after (covers reiterations)
							{
								int collisionGameTime = p_gameTimeMS - int(p_animationTimeMS * (1.0f - collisionT));
								if (collisionGameTime >= bulletEnumerator.Current()->data.minimumGameTimeMS && collisionGameTime >= asteroidEnumerator.Current()->data.minimumGameTimeMS) // don't allow collisions in gametime before bullet was created
								{
									firstCollisionT = collisionT;
									collisionAsteroid = asteroidEnumerator.Current();
									collisionBullet = bulletEnumerator.Current();
									collisionPowerup = nullptr;
									collisionShip = nullptr;
									collisionShip2 = nullptr;
									collisionPoint = playfield.NormalizePositionWithPlayfield(bulletPriorPosition + bulletMove.ScalarMult(collisionT)); // plus small adjustment for radius, not here yet
								}
							}
						}
					}

					// and ships
					LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
					while (shipEnumerator.MoveNext())
					{
						if (shipEnumerator.Current()->data.IsDestroyed() == true)
							continue;
						// bullet can't hit its parent ship, for now (NOTE: Done this way, if someone leaves game and someone else joins with same ship record while bullet is in flight, it won't hit them either)
						if (bulletEnumerator.Current()->data.ownerRef == &(shipEnumerator.Current()->data))
							continue;

						// get same domain coordinate of ship
						Vector3d shipPosition = shipEnumerator.Current()->data.position;
						Vector3d shipMove = shipEnumerator.Current()->data.moveOffset;
						Vector3d shipPriorPosition = playfield.NormalizeOffsetWithPlayfield(shipPosition - shipMove - bulletPriorPosition) + bulletPriorPosition;
						float collisionT;
						if (MathUtilities::SphereSphereCollision(bulletPriorPosition,
							(bulletMove - shipEnumerator.Current()->data.moveOffset),
							bulletRadius,
							shipPriorPosition,
							shipEnumerator.Current()->data.radius, collisionT) == true)
						{
							if (collisionT < firstCollisionT && collisionT >= startMove && collisionT < moveFactor) // limit collisions to startMove or after (covers reiterations)
							{
								int collisionGameTime = p_gameTimeMS - int(p_animationTimeMS * (1.0f - collisionT));
								if (collisionGameTime >= bulletEnumerator.Current()->data.minimumGameTimeMS) // don't allow collisions in gametime before bullet was created
								{
									firstCollisionT = collisionT;
									collisionShip = shipEnumerator.Current();
									collisionBullet = bulletEnumerator.Current();
									collisionShip2 = nullptr;
									collisionPowerup = nullptr;
									collisionAsteroid = nullptr;
									collisionPoint = playfield.NormalizePositionWithPlayfield(bulletPriorPosition + bulletMove.ScalarMult(collisionT)); // plus small adjustment for radius, not here yet
								}
							}
						}
					}
				}

				// Ships and asteroids/powerups/ships
				if (GameContext::Instance->GetNetwork()->IsClient() == false)
				{
					LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
					while (shipEnumerator.MoveNext())
					{
						if (shipEnumerator.Current()->data.IsDestroyed() == true)
							continue;

						Vector3d shipPosition = shipEnumerator.Current()->data.position;
						Vector3d shipMove = shipEnumerator.Current()->data.moveOffset;
						Vector3d shipPriorPosition = playfield.NormalizePositionWithPlayfield(shipPosition - shipMove);
						float shipRadius = shipEnumerator.Current()->data.radius;

						// asteroids
						LinkedListEnumerator<AsteroidsAsteroid> asteroidEnumerator = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
						while (asteroidEnumerator.MoveNext())
						{
							// get same domain coordinate of asteroid
							Vector3d asteroidPosition = asteroidEnumerator.Current()->data.position;
							Vector3d asteroidMove = asteroidEnumerator.Current()->data.moveOffset;
							Vector3d asteroidPriorPosition = playfield.NormalizeOffsetWithPlayfield(asteroidPosition - asteroidMove - shipPriorPosition) + shipPriorPosition;
							float collisionT = firstCollisionT;
							if (MathUtilities::SphereSphereCollision(shipPriorPosition,
								(shipMove - asteroidEnumerator.Current()->data.moveOffset),
								shipRadius,
								asteroidPriorPosition,
								asteroidEnumerator.Current()->data.radius, collisionT) == true)
							{
								if (collisionT < firstCollisionT && collisionT >= startMove) // limit collisions to startMove or after (covers reiterations)
								{
									firstCollisionT = collisionT;
									collisionAsteroid = asteroidEnumerator.Current();
									collisionShip = shipEnumerator.Current();
									collisionShip2 = nullptr;
									collisionPowerup = nullptr;
									collisionBullet = nullptr;
									collisionPoint = playfield.NormalizePositionWithPlayfield(shipPriorPosition + shipMove.ScalarMult(collisionT)) +
										playfield.NormalizeOffsetWithPlayfield(asteroidPriorPosition + asteroidMove.ScalarMult(collisionT) - (shipPriorPosition + shipMove.ScalarMult(collisionT))).ScalarMult(shipRadius / (shipRadius + asteroidEnumerator.Current()->data.radius));
								}
							}
						}

						// powerups
						if (shipEnumerator.Current()->data.InDeathThroes() == false) // dying ships can't pick up powerups
						{
							LinkedListEnumerator<AsteroidsPowerup> powerupEnumerator = LinkedListEnumerator<AsteroidsPowerup>(powerups);
							while (powerupEnumerator.MoveNext())
							{
								// get same domain coordinate of asteroid
								Vector3d powerupPosition = powerupEnumerator.Current()->data.position;
								Vector3d powerupMove = powerupEnumerator.Current()->data.moveOffset;
								Vector3d powerupPriorPosition = playfield.NormalizeOffsetWithPlayfield(powerupPosition - powerupMove - shipPriorPosition) + shipPriorPosition;
								float collisionT = firstCollisionT;
								if (MathUtilities::SphereSphereCollision(shipPriorPosition,
									(shipMove - powerupEnumerator.Current()->data.moveOffset),
									shipRadius,
									powerupPriorPosition,
									powerupEnumerator.Current()->data.captureRadius, collisionT) == true)
								{
									// don't collide if powerup wouldn't affect the ship (allowing a collison but later not removing the powerup would cause an infinite loop)
									if (collisionT < firstCollisionT && collisionT >= startMove && AsteroidsPowerup::ApplyToShip(powerupEnumerator.Current()->data.type, &(shipEnumerator.Current()->data), true)) // limit collisions to startMove or after (covers reiterations)
									{
										int collisionGameTime = p_gameTimeMS - int(p_animationTimeMS * (1.0f - collisionT));
										if (collisionGameTime >= powerupEnumerator.Current()->data.minimumGameTimeMS) // don't allow collisions in gametime before powerup was created
										{
											firstCollisionT = collisionT;
											collisionPowerup = powerupEnumerator.Current();
											collisionShip = shipEnumerator.Current();
											collisionAsteroid = nullptr;
											collisionShip2 = nullptr;
											collisionBullet = nullptr;
										}
										// don't need collision point
									}
								}
							}
						}

						// ships - only check ships after the main ship in the list
						if (shipEnumerator.Current()->next != &(ships.footer) && GameContext::Instance->GetNetwork()->IsActive() == false) // or gameType != multiplayer
						{
							LinkedListEnumerator<AsteroidsShip> shipEnumerator2 = LinkedListEnumerator<AsteroidsShip>(ships, shipEnumerator.Current()); // current() will NOT be included in the parse
							while (shipEnumerator2.MoveNext())
							{
								if (shipEnumerator2.Current()->data.IsDestroyed() == true)
									continue;

								// get same domain coordinate of ship
								Vector3d shipPosition2 = shipEnumerator2.Current()->data.position;
								Vector3d shipMove2 = shipEnumerator2.Current()->data.moveOffset;
								Vector3d shipPriorPosition2 = playfield.NormalizeOffsetWithPlayfield(shipPosition2 - shipMove2 - shipPriorPosition) + shipPriorPosition;
								float collisionT;
								if (MathUtilities::SphereSphereCollision(shipPriorPosition,
									(shipMove - shipEnumerator2.Current()->data.moveOffset),
									shipRadius,
									shipPriorPosition2,
									shipEnumerator2.Current()->data.radius, collisionT) == true)
								{
									if (collisionT < firstCollisionT && collisionT >= startMove) // limit collisions to startMove or after (covers reiterations)
									{
										firstCollisionT = collisionT;
										collisionShip = shipEnumerator.Current();
										collisionShip2 = shipEnumerator2.Current();
										collisionBullet = nullptr;
										collisionPowerup = nullptr;
										collisionAsteroid = nullptr;
										// no need for collision point when it's ship to ship
									}
								}
							}
						}
					}
				} // not a network client

				if (firstCollisionT != noCollision)
				{
					// handle collision
					if (collisionBullet != nullptr && collisionAsteroid != nullptr)
					{
						BulletHitsAsteroid(collisionBullet, collisionAsteroid, collisionAsteroid->data.moveOffset, collisionPoint, firstCollisionT, p_animationTimeMS, p_gameTimeMS);
					}
					else if (collisionShip != nullptr && collisionAsteroid != nullptr)
					{
						ShipHitsAsteroid(&(collisionShip->data), collisionAsteroid, collisionAsteroid->data.moveOffset, collisionPoint, firstCollisionT, p_animationTimeMS, p_gameTimeMS);
					}
					else if (collisionShip != nullptr && collisionBullet != nullptr)
					{
						BulletHitsShip(collisionBullet, &(collisionShip->data), collisionPoint, firstCollisionT, p_animationTimeMS, p_gameTimeMS);
					}
					else if (collisionShip != nullptr && collisionShip2 != nullptr)
					{
						ShipHitsShip(&(collisionShip->data), &(collisionShip2->data), firstCollisionT, p_animationTimeMS, p_gameTimeMS);
					}
					else if (collisionShip != nullptr && collisionPowerup != nullptr)
					{
						ShipHitsPowerup(&(collisionShip->data), collisionPowerup, firstCollisionT, p_animationTimeMS);
					}
					else
						throw gcnew Exception("Unhandled collision type!");
				}

				// set up for next iteration
				startMove = firstCollisionT;
			}
		}

		void BulletHitsAsteroid(LinkedListNode<AsteroidsBullet> *p_bulletNode, LinkedListNode<AsteroidsAsteroid> *p_asteroidNode, Vector3d &p_asteroidMoveOffset, Vector3d &p_collisionPoint, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS)
		{
			// iterationFActor is 0.0-1.0 representing the time point within the current slot of time being evaluated (whatever Animate() was called with, representing the time that moveOffset covers)
			// animation time is the full time slice of the iteration

			// split the asteroid - create new aseroids as if they were moving the full turn if created mid turn so that collision routine doesn't require extra data on the asteroid
			//    to compensate (ex.  if an asteroid is created at time index 0.4 in the collision iteration, its move from its start position to end position will only be 0.6 normally.  Instead,
			//    calculate its end position using the 0.6, and calcualte its moveOffset as if it had moved an entire 1.0.  since no other collision happened before 0.4, this should not cause
			//    a problem.
			if (GameContext::Instance->GetNetwork()->IsClient() == false)
			{
				GameColor explosionColor = GameColor::Interpolate(p_bulletNode->data.ownerRef->color, GameColor(255, 255, 255), 0.50f);
				DestroyAsteroid(p_asteroidNode, p_asteroidMoveOffset, p_collisionPoint, p_iterationFactor, p_animationTimeMS, p_gameTimeMS, explosionColor);
			}

			// don't really need to send remove bullet to clients. but we can for save keeping
			if (GameContext::Instance->GetNetwork()->IsServer())
			{
				SendRemoveBulletToClients(&(p_bulletNode->data));
			}
		
			// place an explosion for the bullet hit, do NOT advance its animation!  Give the player the best chance to see it.
			explosions.AddExplosion(p_collisionPoint, GameColor::Interpolate(p_bulletNode->data.ownerRef->color, GameColor(255,255,255), 0.25f), 5.0f, 0.25f, 125.0f);

			bullets.RemoveBullet(p_bulletNode);
		}

		void SendAddBulletToServer(AsteroidsBullet *p_bullet, int p_gameTimeMS)
		{
			AsteroidsNetworkAddBulletPacket bulletPacket;
			AsteroidsNetworkPacketHelper::PopulateAddBulletPacket(bulletPacket, p_bullet->Id, p_bullet->ownerRef->Id, p_bullet->position, p_bullet->velocity, p_bullet->super, p_bullet->radius, p_bullet->lifeMS, p_bullet->minimumGameTimeMS, p_gameTimeMS);
			GameContext::Instance->GetNetwork()->SendToServer((char *)&bulletPacket, bulletPacket.length, 0);
		}

		void SendAddBulletToClients(AsteroidsBullet *p_ship, int p_gameTimeMS);

		void SendRemoveBulletToClients(AsteroidsBullet *p_bullet)
		{
			AsteroidsNetworkRemoveBulletPacket bulletPacket;
			AsteroidsNetworkPacketHelper::PopulateRemoveBulletPacket(bulletPacket, p_bullet->Id, p_bullet->ownerRef->Id);
			GameContext::Instance->GetNetwork()->SendToAllClients((char *)&bulletPacket, bulletPacket.length, 0);
		}

		void ShipHitsAsteroid(AsteroidsShip *p_asteroidShip, LinkedListNode<AsteroidsAsteroid> *p_asteroidNode, Vector3d &p_asteroidMoveOffset, Vector3d &p_collisionPoint, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS)
		{
			// iterationFActor is 0.0-1.0 representing the time point within the current slot of time being evaluated (whatever Animate() was called with, representing the time that moveOffset covers)
			// animation time is the full time slice of the iteration

			DestroyShip(p_asteroidShip, p_iterationFactor, p_animationTimeMS, p_gameTimeMS);

			if (p_asteroidShip == localPlayerShipRef)
			{
				TauntAsteroidShipDestroyed();
			}
			else if (GameContext::Instance->GetNetwork()->IsServer())
			{
				SendTauntToClient(p_asteroidShip->playerId, AsteroidsNetworkPacketType::TauntAsteroidShipDestroyed);
			}

			// split the asteroid - create new aseroids as if they were moving the full turn if created mid turn so that collision routine doesn't require extra data on the asteroid
			//    to compensate (ex.  if an asteroid is created at time index 0.4 in the collision iteration, its move from its start position to end position will only be 0.6 normally.  Instead,
			//    calculate its end position using the 0.6, and calculate its moveOffset as if it had moved an entire 1.0.  since no other collision happened before 0.4, this should not cause
			//    a problem.
			GameColor explosionColor = GameColor::Interpolate(p_asteroidShip->color, GameColor(255, 255, 255), 0.37f);
			DestroyAsteroid(p_asteroidNode, p_asteroidMoveOffset, p_collisionPoint, p_iterationFactor, p_animationTimeMS, p_gameTimeMS, explosionColor);

			// place an explosion, do NOT advance its animation!  Give the player the best chance to see it.
			// we are already placing this in DestroyAsteroid()
			//AddExplosion(p_collisionPoint, GameColor(255, 192, 0), 5.0f, 0.25f, 125.0f);
		}

		void ShipHitsPowerup(AsteroidsShip *p_asteroidShip, LinkedListNode<AsteroidsPowerup> *p_powerupNode, float p_iterationFactor, float p_animationTimeMS)
		{
			// apply to ship
			if (AsteroidsPowerup::ApplyToShip(p_powerupNode->data.type, p_asteroidShip) == true)
			{
				if (p_asteroidShip == localPlayerShipRef)
				{
					ShowPowerupPickupMessage(p_powerupNode->data.type);
				}

				if (GameContext::Instance->GetNetwork()->IsServer())
				{
					SendApplyPowerupToClients(&(p_powerupNode->data), p_asteroidShip);
					SendRemovePowerupToClients(&(p_powerupNode->data));
				}

				powerups.DeleteNode(p_powerupNode);
			}
		}

		void ShipHitsShip(AsteroidsShip *p_asteroidShip, AsteroidsShip *p_asteroidShip2, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS)
		{
			// iterationFActor is 0.0-1.0 representing the time point within the current slot of time being evaluated (whatever Animate() was called with, representing the time that moveOffset covers)
			// animation time is the full time slice of the iteration

			bool ship1DeathThroesBefore = false;
			bool ship2DeathThroesBefore = false;
			if (p_asteroidShip == localPlayerShipRef)
			{
				if (p_asteroidShip->InDeathThroes() == true)
					ship1DeathThroesBefore = true;
			}
			if (p_asteroidShip2 == localPlayerShipRef)
			{
				if (p_asteroidShip2->InDeathThroes() == true)
					ship2DeathThroesBefore = true;
			}

			// Damage each ship based on the severity of the velocities they will be trading ((velocity1 - velocity2) magnitude)
			float magnitudeOfCollision = (p_asteroidShip->velocity - p_asteroidShip2->velocity).Magnitude();
			float damageFactor = 10.0f; // enough to cause around 80 damage if two ships at full speed collide, max velocity around 2.0f (two head on full speed = 4.0f)
			float damageCaused = pow(magnitudeOfCollision, 1.5f) * damageFactor;
			p_asteroidShip->ApplyDamage(damageCaused, renderFocusShipRef == p_asteroidShip2);
			p_asteroidShip2->ApplyDamage(damageCaused, renderFocusShipRef == p_asteroidShip);

			bool ship1Destroyed = false;
			bool ship1DeathThroesNow = false;
			bool ship2Destroyed = false;
			bool ship2DeathThroesNow = false;
			if (GameContext::Instance->GetNetwork()->IsServer())
			{
				// destroy them or let them continue (server: send packets!)
				if (p_asteroidShip->IsTimeToExplode() == true)
				{
					DestroyShip(p_asteroidShip, p_iterationFactor, p_animationTimeMS, p_gameTimeMS); // position calculated for destruction ends up being the same before as how we calculated the position and moveOffset
					ship1Destroyed = true;
				}
				else
				{
					if (p_asteroidShip->InDeathThroes())
					{
						if (ship1DeathThroesBefore == false)
							ship1DeathThroesNow = true;
						// reject further updates by controlling machine
						// todo: somehow the client machine was still communicating its controls and a dying ship showed its flames, I made changes but not sure actually why they worked
						p_asteroidShip->lastGameTimeUpdatedByServerMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));
					}
					SendDamageShipToClients(p_asteroidShip, damageCaused, p_asteroidShip2->playerId);
					if (ship1DeathThroesNow == true && p_asteroidShip == localPlayerShipRef)
						// tell clients final position and velocity for accuracy
						SendDyingShipPositionToClients(p_asteroidShip, p_gameTimeMS);
				}
				if (p_asteroidShip2->IsTimeToExplode() == true)
				{
					DestroyShip(p_asteroidShip2, p_iterationFactor, p_animationTimeMS, p_gameTimeMS);
					ship2Destroyed = true;
				}
				else
				{
					if (p_asteroidShip2->InDeathThroes())
					{
						if (ship2DeathThroesBefore == false)
							ship2DeathThroesNow = true;
						// reject further updates by controlling machine
						// todo: somehow the client machine was still communicating its controls and a dying ship showed its flames, I made changes but not sure actually why they worked
						p_asteroidShip2->lastGameTimeUpdatedByServerMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));
					}
					SendDamageShipToClients(p_asteroidShip2, damageCaused, p_asteroidShip->playerId);
					if (ship2DeathThroesNow == true && p_asteroidShip2 == localPlayerShipRef)
						// tell clients final position and velocity for accuracy
						SendDyingShipPositionToClients(p_asteroidShip2, p_gameTimeMS);
				}
			}

			// move each to the point of contact
			p_asteroidShip->position = p_asteroidShip->position + p_asteroidShip->moveOffset.ScalarMult(p_iterationFactor);
			p_asteroidShip2->position = p_asteroidShip2->position + p_asteroidShip2->moveOffset.ScalarMult(p_iterationFactor);
			// trade their velocities
			Vector3d tempVelocity = p_asteroidShip->velocity;
			p_asteroidShip->velocity = p_asteroidShip2->velocity;
			p_asteroidShip2->velocity = tempVelocity;
			// clever moment: add just a little bit more to move them away from each other and keep them from sliding through each other because their edges touch too closely
			// this doesn't prevent all of it, but prevents a lot
			Vector3d offset = playfield.NormalizeOffsetWithPlayfield(p_asteroidShip->position - p_asteroidShip2->position);
			offset.Normalize();
			p_asteroidShip->velocity = p_asteroidShip->velocity + offset.ScalarMult(0.01f);
			p_asteroidShip2->velocity = p_asteroidShip2->velocity - offset.ScalarMult(0.01f);
			// calculate new final position based on iteration factor and animation time
			p_asteroidShip->position = playfield.NormalizePositionWithPlayfield(p_asteroidShip->position + p_asteroidShip->velocity.ScalarMult((1.0f - p_iterationFactor) * p_animationTimeMS));
			p_asteroidShip2->position = playfield.NormalizePositionWithPlayfield(p_asteroidShip2->position + p_asteroidShip2->velocity.ScalarMult((1.0f - p_iterationFactor) * p_animationTimeMS));
			// calculate new moveoffset that represents a full 0.0-1.0 of movement off animation time
			p_asteroidShip->moveOffset = p_asteroidShip->velocity.ScalarMult(p_animationTimeMS);
			p_asteroidShip2->moveOffset = p_asteroidShip2->velocity.ScalarMult(p_animationTimeMS);

			if (ship1Destroyed == true)
			{
				if (p_asteroidShip == localPlayerShipRef)
					TauntShipCollideDestroyed();
				else if (GameContext::Instance->GetNetwork()->IsServer())
				{
					SendTauntToClient(p_asteroidShip->playerId, AsteroidsNetworkPacketType::TauntShipCollideDestroyed);
				}
			}
			else if (ship1DeathThroesNow == true)
			{
				if (p_asteroidShip == localPlayerShipRef)
					TauntShipCollideDeathThroe();
				else if (GameContext::Instance->GetNetwork()->IsServer())
				{
					SendTauntToClient(p_asteroidShip->playerId, AsteroidsNetworkPacketType::TauntShipCollideDeathThroe);
				}
			}
			if (ship2Destroyed == true)
			{
				if (p_asteroidShip2 == localPlayerShipRef)
					TauntShipCollideDestroyed();
				else if (GameContext::Instance->GetNetwork()->IsServer())
				{
					SendTauntToClient(p_asteroidShip2->playerId, AsteroidsNetworkPacketType::TauntShipCollideDestroyed);
				}
			}
			else if (ship2DeathThroesNow == true)
			{
				if (p_asteroidShip2 == localPlayerShipRef)
					TauntShipCollideDeathThroe();
				else if (GameContext::Instance->GetNetwork()->IsServer())
				{
					SendTauntToClient(p_asteroidShip2->playerId, AsteroidsNetworkPacketType::TauntShipCollideDeathThroe);
				}
			}
		}

		void BulletHitsShip(LinkedListNode<AsteroidsBullet> *p_bulletNode, AsteroidsShip *p_asteroidShip, Vector3d &p_collisionPoint, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS)
		{
			// iterationFActor is 0.0-1.0 representing the time point within the current slot of time being evaluated (whatever Animate() was called with, representing the time that moveOffset covers)
			// animation time is the full time slice of the iteration

			// DamageShip
			if (GameContext::Instance->GetNetwork()->IsClient() == false)
			{
				float damage = 10.01f; // 0.01f just in case of rounding and leaving ship with 0.00001 health or something
				if (p_bulletNode->data.super == true)
					damage = damage * 1.5f;
				bool shipWasAlive = p_asteroidShip->IsAlive();
				p_asteroidShip->ApplyDamage(damage, p_bulletNode->data.ownerRef == renderFocusShipRef);
				if (GameContext::Instance->GetNetwork()->IsServer())
				{
					if (shipWasAlive == true && p_asteroidShip->IsAlive() == false)
						// reject further updates on ship from client for this ship
						p_asteroidShip->lastGameTimeUpdatedByServerMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));

					SendDamageShipToClients(p_asteroidShip, damage, p_bulletNode->data.ownerRef->playerId);
				}
				if (p_asteroidShip->IsTimeToExplode() == true)
					DestroyShip(p_asteroidShip, p_iterationFactor, p_animationTimeMS, p_gameTimeMS);
				if (shipWasAlive == true && p_asteroidShip->IsAlive() == false)
				{
					if (GameContext::Instance->GetNetwork()->IsActive())
					{
						EchoPlayerDestroyedPlayerMessage(p_bulletNode->data.ownerRef->playerId, p_asteroidShip->playerId);

						if (GameContext::Instance->GetNetwork()->IsServer())
						{
							SendEchoPlayerDestroyedPlayerMessage(p_bulletNode->data.ownerRef->playerId, p_asteroidShip->playerId);
						}

						//if (p_bulletNode->data.ownerRef == localPlayerShipRef) // for now until I get players playing
						if (p_asteroidShip == localPlayerShipRef)
						{
							TauntBulletShipDestroyed();
						}
						else
						{
							SendTauntToClient(p_asteroidShip->playerId, AsteroidsNetworkPacketType::TauntBulletShipDestroyed);
						}
					}
				}
			}

			// place an explosion, do NOT advance its animation!  Give the player the best chance to see it.
			explosions.AddExplosion(p_collisionPoint, GameColor::Interpolate(p_bulletNode->data.ownerRef->color, GameColor(255, 255, 255), 0.25f), 5.0f, 0.25f, 125.0f);

			// don't really need to send remove bullet to clients. but we can for save keeping
			if (GameContext::Instance->GetNetwork()->IsServer())
			{
				SendRemoveBulletToClients(&(p_bulletNode->data));
			}

			bullets.RemoveBullet(p_bulletNode);
		}
	
		void EchoPlayerDestroyedPlayerMessage(int p_destroyingPlayerId, int p_destroyedPlayerId);
		void SendEchoPlayerDestroyedPlayerMessage(int p_destroyingPlayerId, int p_destroyedPlayerId);
		void SendTauntToClient(int p_playerId, int p_tauntType);

		void DestroyAsteroid(LinkedListNode<AsteroidsAsteroid> *p_asteroidNode, Vector3d &p_asteroidMoveOffset, Vector3d &p_collisionPoint, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS, GameColor &p_explosionColor)
		{
			// asteroid Move Offset is sent separately from teh asteroid node because the node has the moveOffset from the gameTick, and this routine can be called from a retcon routine
			//   that uses alonger offset (but still ends at position on the node, just stretches back to a different original position)

			// iterationFActor is 0.0-1.0 representing the time point within the current slot of time being evaluated (whatever Animate() was called with, representing the time that moveOffset covers)
			// animation time is the full time slice of the iteration
			// gameTimeMS is at iteration 1.0, gameTimeMS-p_animationTimeMS is at iteration 0.0

			// todo: provide game time here so that server can meaningfully communicate data to clients and use the split as a buffer against shots that arrive later
			// todo: need factor for collision so that new asteroids can get a new calculation about where their new position is, and calculate a proper moveOffset that agrees with the continuing
			//    collision loop

			float originalAsteroidRadius = p_asteroidNode->data.radius;
			Vector3d asteroidDestructionPosition = p_asteroidNode->data.position - p_asteroidMoveOffset.ScalarMult(1.0f - p_iterationFactor);
			// back asteroid up to collision point
			p_asteroidNode->data.position = p_asteroidNode->data.position - p_asteroidMoveOffset + p_asteroidMoveOffset.ScalarMult(p_iterationFactor);
			if (p_asteroidNode->data.type != AsteroidType::Small)
			{
				Vector3d originalAsteroidVelocity = p_asteroidNode->data.velocity;
				Vector3d originalAsteroidPosition = p_asteroidNode->data.position;

				// calculate split along how collision point cuts the asteroid and generates an added amount of movement based on the collision point vector to the centers of the new asteroids
				float newAsteroidRadius;
				int newType;
				switch (p_asteroidNode->data.type)
				{
				case AsteroidType::Large:
					newAsteroidRadius = mediumAsteroidRadius;
					newType = AsteroidType::Medium;
					break;
				case AsteroidType::Medium:
					newAsteroidRadius = smallAsteroidRadius;
					newType = AsteroidType::Small;
					break;
				default:
					throw gcnew Exception("Asteroid type not Large or Medium here!");
					break;
				}

				// we will be replacing the asteroid with 1, making a new one with 2
				Vector3d newAsteroidPosition1, newAsteroidPosition2;
				Vector3d newAsteroidVelocity1, newAsteroidVelocity2;
				float splitVelocityAddition = 0.2f;
				Vector3d offsetToCollision = p_collisionPoint - p_asteroidNode->data.position;
				if (offsetToCollision.Normalize() == false)
					offsetToCollision = Vector3d(0.707f, 0.5f, 0.0f); // this isn't expected to happen, just in case
				Vector3d baseOffsetToAsteroidStartPosition = Vector3d(offsetToCollision.y, -offsetToCollision.x, 0.0f).ScalarMult(originalAsteroidRadius / 2.0f); // used for both asteroids, + and -
				// use base start position as position at iteration factor.  calculate a moveOffset that covers 0.0-1.0 off the new velocity using animationTime, and calculate a new position for 1.0
				Vector3d baseOffsetToAsteroidStartPositionUnit = baseOffsetToAsteroidStartPosition; // for adding velocity from explosion
				if (baseOffsetToAsteroidStartPositionUnit.Normalize() == false)
					baseOffsetToAsteroidStartPositionUnit = Vector3d(1.0f, 0.0f, 0.0f);

				static FastRandom fastRandom;

				bool bigExplosion = false;
				// asteroid 1
				newAsteroidPosition1 = originalAsteroidPosition + baseOffsetToAsteroidStartPosition;
				// need new velocity = (original velocity + (normalized offset from collision point to new asteroid center) * some amount
				//Vector3d offsetToCollisionPoint = newAsteroidPosition1 - p_collisionPoint;
				//if (offsetToCollisionPoint.Normalize() == false)
				//	offsetToCollisionPoint = Vector3d(1.0f, 0.0f, 0.0f); // not expected to happen
				float randomAddition = float(fastRandom.GetRandomInteger(0, 10)) / 100.0f;
				float randomRadians = MathUtilities::DegreesToRadians(float(fastRandom.GetRandomInteger(0, 359)));
				Vector3d randomDirection = Vector3d(sin(randomRadians), -cos(randomRadians), 0.0f).ScalarMult(randomAddition);
				newAsteroidVelocity1 = originalAsteroidVelocity + baseOffsetToAsteroidStartPositionUnit.ScalarMult(splitVelocityAddition) + randomDirection;
				if (fastRandom.GetRandomInteger(1, 10) == 1)
				{
					bigExplosion = true;
					if (newType == AsteroidType::Medium)
						newAsteroidVelocity1 = newAsteroidVelocity1.ScalarMult(3.0f);
					else
						newAsteroidVelocity1 = newAsteroidVelocity1.ScalarMult(4.0f);
				}
				// calculate moveOffset off new velocity * animationTimeMS
				p_asteroidNode->data.moveOffset = newAsteroidVelocity1.ScalarMult(p_animationTimeMS); // if set from BulletRetcon, doesn't matter, CheckForCollisions doesn't need it anymore this tick
				// calculate new position off baseOffsetToAsteroidStartPosition - moveOffset.(iterationFactor) + moveOffset;
				p_asteroidNode->data.position = playfield.NormalizePositionWithPlayfield(newAsteroidPosition1 - p_asteroidNode->data.moveOffset.ScalarMult(p_iterationFactor) + p_asteroidNode->data.moveOffset);
				p_asteroidNode->data.velocity = newAsteroidVelocity1;
				p_asteroidNode->data.type = newType;
				p_asteroidNode->data.radius = newAsteroidRadius;
				p_asteroidNode->data.minimumGameTimeMS = int(p_gameTimeMS - p_animationTimeMS * (1.0f - p_iterationFactor)); // lower bound for collisions, NOT version

				// asteroid 2
				LinkedListNode<AsteroidsAsteroid> *newAsteroid = asteroids.GetNewNode();
				newAsteroid->data.Initialize();
				newAsteroidPosition2 = originalAsteroidPosition - baseOffsetToAsteroidStartPosition;
				// need new velocity = (original velocity + (normalized offset from collision point to new asteroid center) * some amount
				//offsetToCollisionPoint = newAsteroidPosition2 - p_collisionPoint;
				//if (offsetToCollisionPoint.Normalize() == false)
				//	offsetToCollisionPoint = Vector3d(1.0f, 0.0f, 0.0f); // not expected to happen
				randomAddition = float(fastRandom.GetRandomInteger(0, 10)) / 100.0f;
				randomRadians = MathUtilities::DegreesToRadians(float(fastRandom.GetRandomInteger(0, 359)));
				randomDirection = Vector3d(sin(randomRadians), -cos(randomRadians), 0.0f).ScalarMult(randomAddition);
				newAsteroidVelocity2 = originalAsteroidVelocity - baseOffsetToAsteroidStartPositionUnit.ScalarMult(splitVelocityAddition) + randomDirection;
				if (fastRandom.GetRandomInteger(1, 10) == 1)
				{
					bigExplosion = true;
					if (newType == AsteroidType::Medium)
						newAsteroidVelocity2 = newAsteroidVelocity2.ScalarMult(3.0f);
					else
						newAsteroidVelocity2 = newAsteroidVelocity2.ScalarMult(4.0f);
				}
				// calculate moveOffset off new velocity * animationTimeMS
				newAsteroid->data.moveOffset = newAsteroidVelocity2.ScalarMult(p_animationTimeMS); // if set from BulletRetcon, doesn't matter, CheckForCollisions doesn't need it anymore this tick
				// calculate new position off baseOffsetToAsteroidStartPosition - moveOffset.(iterationFactor) + moveOffset;
				newAsteroid->data.position = playfield.NormalizePositionWithPlayfield(newAsteroidPosition2 - newAsteroid->data.moveOffset.ScalarMult(p_iterationFactor) + newAsteroid->data.moveOffset);
				newAsteroid->data.velocity = newAsteroidVelocity2;
				newAsteroid->data.type = newType;
				newAsteroid->data.radius = newAsteroidRadius;
				newAsteroid->data.minimumGameTimeMS = int(p_gameTimeMS - p_animationTimeMS * (1.0f - p_iterationFactor)); // lower bound for collisions, NOT version
				asteroids.AddAsteroid(newAsteroid);

				if (GameContext::Instance->GetNetwork()->IsServer())
				{
					// send update for existing asteroid and add new asteroid to clients
					// remember p_gameTimeMS is the game time representing the postion of the asteroids, which we set here effectively to gameTimeMS for consistency to continue CheckForCollisions
					// it is NOT the VERSION of the asteroid.  Ships will need a version gameTimeMS AND a position gameTimeMS sent to clients.
					SendAsteroidToClients(&(p_asteroidNode->data), p_iterationFactor, p_animationTimeMS, p_gameTimeMS, false);
					SendAsteroidToClients(&(newAsteroid->data), p_iterationFactor, p_animationTimeMS, p_gameTimeMS, true);
				}

				// add explosion
				// todo: send to clients
				if (bigExplosion == false)
				{
					AddExplosion(asteroidDestructionPosition, p_explosionColor, originalAsteroidRadius * 0.25f, 0.20f, 250.0f);
				}
				else
				{
					AddExplosion(asteroidDestructionPosition, p_explosionColor, originalAsteroidRadius * 0.25f, 0.30f, 350.0f);
					AddExplosion(asteroidDestructionPosition, p_explosionColor, originalAsteroidRadius * 0.25f - 4.0f, 0.35f, 350.0f);
					AddExplosion(asteroidDestructionPosition, p_explosionColor, originalAsteroidRadius * 0.25f - 8.0f, 0.40f, 350.0f);
				}
			}
			else
			{
				if (GameContext::Instance->GetNetwork()->IsServer())
				{
					// send remove for existing asteroid and add new asteroid to clients
					SendRemoveAsteroidToClients(&(p_asteroidNode->data));
				}				
				
				// just get rid of it, with an explosion
				AddExplosion(asteroidDestructionPosition, p_explosionColor, originalAsteroidRadius * 0.25f, 0.20f, 250.0f);
				asteroids.RemoveAsteroid(p_asteroidNode);

				static FastRandom fastRandom;
				if (fastRandom.GetRandomInteger(1, 100) <= 33)
				{
					// make a powerup!
					LinkedListNode<AsteroidsPowerup> *newPowerup = powerups.GetNewNode();
					// set it up for travelling the rest of the iteration, but as if it existed the whole iteration (collision will prevent a collision < a certain time from occurring)
					// set it up so its position at iterationFfactor is = the source asteroid
					newPowerup->data.Initialize();
					// random direction
					int randomAngle = fastRandom.GetRandomInteger(0, 359);
					float radians = MathUtilities::DegreesToRadians(float(randomAngle));
					// half the speed of the original asteroid, for now
					newPowerup->data.velocity = Vector3d(sin(radians), -cos(radians), 0.0f).ScalarMult(p_asteroidNode->data.velocity.Magnitude() / 2.0f);
					newPowerup->data.moveOffset = newPowerup->data.velocity.ScalarMult(p_animationTimeMS);
					newPowerup->data.position = playfield.NormalizePositionWithPlayfield(p_asteroidNode->data.position - newPowerup->data.moveOffset.ScalarMult(p_iterationFactor) + newPowerup->data.moveOffset);
					newPowerup->data.type = AsteroidsPowerup::GetRandomPowerupType();
					newPowerup->data.minimumGameTimeMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));

					powerups.AddNode(newPowerup);

					if (GameContext::Instance->GetNetwork()->IsServer())
					{
						SendAddPowerupToClients(&(newPowerup->data), p_iterationFactor, p_animationTimeMS, p_gameTimeMS);
					}
				}
			}
		}

		void AddExplosion(Vector3d &p_position, GameColor &p_color, float p_radius, float p_expansionRatePerMS, float p_lifeMS)
		{
			explosions.AddExplosion(p_position, p_color, p_radius, p_expansionRatePerMS, p_lifeMS);
			if (GameContext::Instance->GetNetwork()->IsServer())
				SendAddExplosionToClients(p_position, p_color, p_radius, p_expansionRatePerMS, p_lifeMS);
		}

		void SendAddExplosionToClients(Vector3d &p_position, GameColor &p_color, float p_radius, float p_expansionRatePerMS, float p_lifeMS);

		void SendAsteroidToClients(AsteroidsAsteroid *p_asteroid, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS, bool p_add = true);

		void SendRemoveAsteroidToClients(AsteroidsAsteroid *p_asteroid)
		{
			AsteroidsNetworkRemoveAsteroidPacket removeAsteroid;
			AsteroidsNetworkPacketHelper::PopulateRemoveAsteroidPacket(removeAsteroid, p_asteroid->Id);
			GameContext::Instance->GetNetwork()->SendToAllClients((char *)&removeAsteroid, removeAsteroid.length, 0);
		}

		void SendAddPowerupToClients(AsteroidsPowerup *p_powerup, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS);

		void SendRemovePowerupToClients(AsteroidsPowerup *p_powerup)
		{
			AsteroidsNetworkRemovePowerupPacket removePowerup;
			AsteroidsNetworkPacketHelper::PopulateRemovePowerupPacket(removePowerup, p_powerup->Id);
			GameContext::Instance->GetNetwork()->SendToAllClients((char *)&removePowerup, removePowerup.length, 0);
		}

		void DestroyShip(AsteroidsShip *p_asteroidShip, float p_iterationFactor, float p_animationTimeMS, int p_gameTimeMS)
		{
			Vector3d destructionPosition = playfield.NormalizePositionWithPlayfield(p_asteroidShip->position - p_asteroidShip->moveOffset.ScalarMult(1.0f - p_iterationFactor));

			if (GameContext::Instance->GetNetwork()->IsServer())
			{
				// reject further updates by controlling machine
				p_asteroidShip->lastGameTimeUpdatedByServerMS = p_gameTimeMS - int(p_animationTimeMS * (1.0f - p_iterationFactor));
				SendDestroyShipToClients(p_asteroidShip, destructionPosition);
			}

			DestroyShip(p_asteroidShip, destructionPosition);
		}

		void DamageShip(AsteroidsShip *p_ship, float p_damage, int p_damagingPlayerId)
		{
			p_ship->ApplyDamage(p_damage, GameContext::Instance->GetNetwork()->IsClient() && p_damagingPlayerId == GameContext::Instance->GetNetwork()->GetLocalUserId());
		}

		void DestroyShip(AsteroidsShip *p_asteroidShip, Vector3d &p_destructionPosition)
		{
			// place a few explosions around its center
			FastRandom fastRandom;
			int explosionQty = 6;
			float maxDistanceFromCenter = 30.0f;
			float startRadius = 15.0f;
			for (int i = 0; i < explosionQty; i++)
			{
				float distance = float(fastRandom.GetRandomInteger(50, 100)) / 100.0f * maxDistanceFromCenter;
				if (i == 0)
					distance = 0.0f; // put first explosion right on the ship
				float angle = float(fastRandom.GetRandomInteger(0, 359));
				float radians = MathUtilities::DegreesToRadians(angle);
				Vector3d offsetUnit = Vector3d(sin(radians), -cos(radians), 0.0f); // 0 is straight up, although it doesn't matter here
				Vector3d explosionPosition = playfield.NormalizePositionWithPlayfield(p_destructionPosition + offsetUnit.ScalarMult(distance));

				// some start with a negative radius to delay them
				GameColor explosionColor = GameColor::Interpolate(p_asteroidShip->color, GameColor(255, 255, 255), 0.25f);
				if (i == 1 && p_asteroidShip->GetShieldMeterFillPercentage() > 0.0f)
					explosionColor = GameColor(32, 255, 255); // shield giving off energy
				if (i == 2 && p_asteroidShip->cloakMS > 0.0f)
					explosionColor = GameColor(255, 32, 255); // cloak giving off energy
				if (i == 4 && p_asteroidShip->GetShieldMeterFillPercentage() > 0.5f)
					explosionColor = GameColor(32, 255, 255); // shield giving off energy
				if (i == 5 && p_asteroidShip->cloakMS > 0.0f)
					explosionColor = GameColor(255, 32, 255); // cloak giving off energy
				explosions.AddExplosion(explosionPosition, explosionColor, float(1 - i) * startRadius, 0.30f, float(fastRandom.GetRandomInteger(750, 1200)));
			}

			p_asteroidShip->position = p_destructionPosition; // clients need this to move the camera to the explosions
			p_asteroidShip->DestroyShip();
		}

		void RespawnShip(AsteroidsShip *p_asteroidShip)
		{
			// no guarantee this will succeed

			float respawnAreaDimension = 500.0f;
			int respawnHorizontalQty = int(playfield.bounds.X / respawnAreaDimension);
			int respawnVerticalQty = int(playfield.bounds.Y / respawnAreaDimension);
			float respawnHorizontalSize = playfield.bounds.X / float(respawnHorizontalQty);
			float respawnVerticalSize = playfield.bounds.Y / float(respawnVerticalQty);
			float respawnHorizontalStart = respawnHorizontalSize / 2.0f; // center of square
			float respawnVerticalStart = respawnVerticalSize / 2.0f;

			static FastRandom fastRandom; // to prevent multiple immediate ships from always randomly starting in the same place
			int startH = fastRandom.GetRandomInteger(0, respawnHorizontalQty);
			int startV = fastRandom.GetRandomInteger(0, respawnVerticalQty);
			int currentH = startH;
			int currentV = startV;
			for (int h = 0; h < respawnHorizontalQty; h++)
			{
				for (int v = 0; v < respawnVerticalQty; v++)
				{
					Vector3d respawnPosition = Vector3d(respawnHorizontalStart + float(currentH) * respawnHorizontalSize, respawnVerticalStart + float(currentV) * respawnVerticalSize, 0.0f);

					// now see if from that position, anything is currently crossing or will cross
					if (WillAnythingCollide(respawnPosition, 100.0f, 500.0f, 2000.0f) == false)
					{
						// spawn it and leave!
						PlaceRespawnedShip(p_asteroidShip, respawnPosition.x, respawnPosition.y);

						if (GameContext::Instance->GetNetwork()->IsServer())
							SendRespawnShipToClients(p_asteroidShip, p_asteroidShip->position.x, p_asteroidShip->position.y, p_asteroidShip->rotationAngle, p_asteroidShip->lastGameTimeUpdatedByServerMS);

						return;
					}

					currentV++;
					if (currentV >= respawnVerticalQty)
						currentV = 0;
				}

				currentH++;
				if (currentH >= respawnHorizontalQty)
					currentH = 0;
			}

			// if get here, we didn't spawn the ship, so reset its timer for another second
			p_asteroidShip->respawnTimerMS = 1000.0f;
		}

		void SendAddShipToClients(AsteroidsShip *p_ship, int p_gameTimeMS);

		// controlling machine sends these:
		// client to host
		void SendUpdateShipToServer(AsteroidsShip *p_ship, int p_gameTimeMS);
		void SendUpdateShipToServerUDP(AsteroidsShip *p_ship, int p_gameTimeMS);
		// host to clients
		void SendUpdateShipToClients(AsteroidsShip *p_ship, int p_gameTimeMS);
		void SendUpdateShipToClientsUDP(AsteroidsShip *p_ship, int p_gameTimeMS);

		// server forwards this to other clients from controlling machine
		void SendUpdateShipPacketToOtherClients(AsteroidsNetworkUpdateShipFromClientPacket *p_packet, int p_excludeClientId = -1);
		void SendUpdateShipPacketToOtherClientsUDP(AsteroidsNetworkUpdateShipFromClientPacket *p_packet, int p_excludeClientId = -1);
		void SendDyingShipPositionPacketToClients(AsteroidsNetworkDyingShipPositionPacket *p_packet, int p_excludeClientId = -1);

		// all machines receive this except controlling machine, starting from controlling machine
		void UpdateShipFromClient(AsteroidsShip *p_ship,
			int p_spinDirection, int p_controls, // bit flags for thrust, backwards, left, right, boost
			Vector2d &p_position, Vector2d &p_velocity, float p_rotationAngle,
			float p_boostFuel, float p_cloakMS,
			int p_gameTimeVersion);

		// received from server when it evaluates a collision with another ship
		void UpdateShipPositionAndVelocity(AsteroidsShip *p_ship, int p_gameTimeMS);

		void UpdateDyingShipPosition(AsteroidsShip *p_ship, Vector2d &p_position, Vector2d &p_velocity, float p_deathThroesMS);

		void SendRespawnShipToClients(AsteroidsShip *p_ship, float p_x, float p_y, float p_rotationAngle, int p_gameTimeVersion);

		void SendDamageShipToClients(AsteroidsShip *p_ship, float p_damage, int p_damagingPlayerId);

		void SendDyingShipPositionToClients(AsteroidsShip *p_ship, int p_gameTimeMS);

		void SendDyingShipPositionToServer(AsteroidsShip *p_ship, int p_gameTimeMS);

		void SendDestroyShipToClients(AsteroidsShip *p_ship, Vector3d &p_destructionPosition);

		void SendApplyPowerupToClients(AsteroidsPowerup *p_powerup, AsteroidsShip *p_ship);

		void PlaceRespawnedShip(AsteroidsShip *p_asteroidShip, float p_x, float p_y)
		{
			p_asteroidShip->Respawn(PointF(p_x, p_y));
			if (renderFocusShipRef == p_asteroidShip)
				camera.SnapToPosition(p_asteroidShip->position);
		}

		void TauntBulletShipDestroyed()
		{
			static FastRandom fastRandom;
			switch (fastRandom.GetRandomInteger(1, 11))
			{
			case 1:
				messageList->AddMessage("\"Rookie One, I've got a bogey on my ass, over.\"");
				break;
			case 2:
				messageList->AddMessage("I just waxed this paint job!");
				break;
			case 3:
				messageList->AddMessage("Go go Gadget Ejector Seat!");
				break;
			case 4:
				messageList->AddMessage("...with any luck, the network will pick me up...");
				break;
			case 5:
				messageList->AddMessage("In the arms of the angel...");
				break;
			case 6:
				messageList->AddMessage("<GOAT SCREAM>");
				break;
			case 7:
				messageList->AddMessage("Oh stop you bad bad man.");
				break;
			case 8:
				messageList->AddMessage("DUN DUN DUN!");
				break;
			case 9:
				messageList->AddMessage("<Violin screech> <Violin screech> <Violin screech>");
				break;
			case 10:
				messageList->AddMessage("\"I'll get you for this!\"");
				break;
			case 11:
				messageList->AddMessage("No fair, there was lag.");
				break;
			}
		}

		void TauntAsteroidShipDestroyed()
		{
			static FastRandom fastRandom;
			switch (fastRandom.GetRandomInteger(1, 11))
			{
			case 1:
				messageList->AddMessage("You asploded.");
				break;
			case 2:
				messageList->AddMessage("<b>WATCH OUT</b> - awww...");
				break;
			case 3:
				messageList->AddMessage("Oh, there's rocks floating around, be careful.");
				break;
			case 4:
				messageList->AddMessage("Those floating rock things kill you if you touch them.");
				break;
			case 5:
				messageList->AddMessage("Some people somewhere get out of the way, sometimes.");
				break;
			case 6:
				messageList->AddMessage("There is this spinny thrusty thing on your ship, you know.");
				break;
			case 7:
				messageList->AddMessage("All around me are familiar faces...");
				break;
			case 8:
				messageList->AddMessage("The endless void of space, and you chose to be there.");
				break;
			case 9:
				messageList->AddMessage("Just making sure you knew, this is Asteroids, not Pac-Man.");
				break;
			case 10:
				messageList->AddMessage("Yes, in fact, there is collision detection.");
				break;
			case 11:
				messageList->AddMessage("The best way to avoid asteroids is to, you know, not touch them.");
				break;
			}
		}

		void TauntShipCollideDeathThroe()
		{
			static FastRandom fastRandom;
			switch (fastRandom.GetRandomInteger(1, 4))
			{
			case 1:
				messageList->AddMessage("Bumped that one a little too hard.");
				break;
			case 2:
				messageList->AddMessage("Wuh oh - that left a mark.");
				break;
			case 3:
				messageList->AddMessage("Not an even offer for dinner?");
				break;
			case 4:
				messageList->AddMessage("Oh that's just demeaning.");
				break;
			}
		}

		void TauntShipCollideDestroyed()
		{
			static FastRandom fastRandom;
			switch (fastRandom.GetRandomInteger(1, 4))
			{
			case 1:
				messageList->AddMessage("Does this look like a demolition derby to you!?");
				break;
			case 2:
				messageList->AddMessage("There went that paint job");
				break;
			case 3:
				messageList->AddMessage("You can save 15% on your auto insurance by switching to Geico");
				break;
			case 4:
				messageList->AddMessage("Get a little closer, with Arrid Extra Dry");
				break;
			}
		}

		bool WillAnythingCollide(Vector3d p_position, float p_radius, float p_backTimeMS, float p_forwardTimeMS)
		{
			// look for asteroids, shots, powerups, ships
			// if anything currently overlaps now, return true
			// if anything will overlap along the defined travel times, return true
			Vector3d testPosition, testStartPosition, testTravelVector, testRadius;
			float collisionT;
			LinkedListEnumerator<AsteroidsAsteroid> asteroidEnumerator = LinkedListEnumerator<AsteroidsAsteroid>(asteroids);
			{
				while (asteroidEnumerator.MoveNext())
				{
					Vector3d testPosition = playfield.NormalizeOffsetWithPlayfield(asteroidEnumerator.Current()->data.position - p_position) + p_position;
					float testRadius = asteroidEnumerator.Current()->data.radius;
					if ((p_position - testPosition).MagnitudeSquared() <= ((p_radius + testRadius)*(p_radius + testRadius)))
						// overlap!
						return true;
					// no need to normalize since testPosition is already in the domain of p_position
					Vector3d testStartPosition = testPosition - asteroidEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS);
					Vector3d testTravelVector = asteroidEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS + p_forwardTimeMS);
					if (MathUtilities::SphereSphereCollision(testPosition, testTravelVector, testRadius, p_position, p_radius, collisionT) == true)
						return true;
				}
			}
			LinkedListEnumerator<AsteroidsBullet> bulletEnumerator = LinkedListEnumerator<AsteroidsBullet>(bullets);
			{
				while (bulletEnumerator.MoveNext())
				{
					Vector3d testPosition = playfield.NormalizeOffsetWithPlayfield(bulletEnumerator.Current()->data.position - p_position) + p_position;
					float testRadius = bulletEnumerator.Current()->data.radius;
					if ((p_position - testPosition).MagnitudeSquared() <= ((p_radius + testRadius)*(p_radius + testRadius)))
						// overlap!
						return true;
					// no need to normalize since testPosition is already in the domain of p_position
					Vector3d testStartPosition = testPosition - bulletEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS);
					Vector3d testTravelVector = bulletEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS + p_forwardTimeMS);
					if (MathUtilities::SphereSphereCollision(testPosition, testTravelVector, testRadius, p_position, p_radius, collisionT) == true)
						return true;
				}
			}
			LinkedListEnumerator<AsteroidsShip> shipEnumerator = LinkedListEnumerator<AsteroidsShip>(ships);
			{
				while (shipEnumerator.MoveNext())
				{
					if (shipEnumerator.Current()->data.IsDestroyed() == true)
						continue;

					Vector3d testPosition = playfield.NormalizeOffsetWithPlayfield(shipEnumerator.Current()->data.position - p_position) + p_position;
					float testRadius = shipEnumerator.Current()->data.radius;
					if ((p_position - testPosition).MagnitudeSquared() <= ((p_radius + testRadius)*(p_radius + testRadius)))
						// overlap!
						return true;
					// no need to normalize since testPosition is already in the domain of p_position
					Vector3d testStartPosition = testPosition - shipEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS);
					Vector3d testTravelVector = shipEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS + p_forwardTimeMS);
					if (MathUtilities::SphereSphereCollision(testPosition, testTravelVector, testRadius, p_position, p_radius, collisionT) == true)
						return true;
				}
			}
			// note: powerups are not skipped when they would have no effect on the ship here.  We could, but it might be jarring to have the ship appear on top of a health powerup, and it's
			//    rare enough to not bother
			LinkedListEnumerator<AsteroidsPowerup> powerupEnumerator = LinkedListEnumerator<AsteroidsPowerup>(powerups);
			{
				while (powerupEnumerator.MoveNext())
				{
					Vector3d testPosition = playfield.NormalizeOffsetWithPlayfield(powerupEnumerator.Current()->data.position - p_position) + p_position;
					float testRadius = powerupEnumerator.Current()->data.captureRadius;
					if ((p_position - testPosition).MagnitudeSquared() <= ((p_radius + testRadius)*(p_radius + testRadius)))
						// overlap!
						return true;
					// no need to normalize since testPosition is already in the domain of p_position
					Vector3d testStartPosition = testPosition - powerupEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS);
					Vector3d testTravelVector = powerupEnumerator.Current()->data.velocity.ScalarMult(p_backTimeMS + p_forwardTimeMS);
					if (MathUtilities::SphereSphereCollision(testPosition, testTravelVector, testRadius, p_position, p_radius, collisionT) == true)
						return true;
				}
			}

			// nothing collided!
			return false;
		}

		void RemoveExpiredBullets()
		{
			LinkedListNode<AsteroidsBullet> *bulletNode = bullets.GetFirstNode();
			if (bulletNode != nullptr)
			{
				while (bulletNode != &(bullets.footer))
				{
					LinkedListNode<AsteroidsBullet> *nextNode = bulletNode->next;

					if (bulletNode->data.removeAfterAnimate == true)
						bullets.RemoveBullet(bulletNode);

					bulletNode = nextNode;
				}
			}
		}

		void ApplyNewRenderCenter(Vector3d &p_normalizedCenter)
		{
			// p_normalizedCenter MUST be normalized with playfield!
			// todo: in the event that the center is flung very VERY far away (more than a full playfield), if the stars are to be accurately placed, the full offset must be
			//  correct.  In that case, the prior p_center should have been normalized from before, and p_center should be the pre-normalized value, and we shouldn't normalize the offset here.   
			//  Then afterwards, normalize the new position.  But this is a rare situation and is only for placing the stars accurately to express the flinging (still, if the fling places you
			//  in the same place in the playfield after normalization, should it look like you moved?).

			Vector3d centerOffset = priorNormalizedRenderCenter - p_normalizedCenter;
			centerOffset = playfield.NormalizeOffsetWithPlayfield(centerOffset);
			MoveStars(Vector2d(centerOffset.x, centerOffset.y));
			priorNormalizedRenderCenter = p_normalizedCenter;
		}
	};

	public class AsteroidsNetworkPlayer : public GameNetworkPlayerBase
	{

	public:
		AsteroidsShip *shipRef;
		int score;
		float uploadRate;
		float downloadRate;
		GameColor color;
		int ping; // in MS
		int pingUDP; // from UDP
		int smallestPing; // in MS
		bool gameStateInitialized;

		AsteroidsNetworkPlayer()
		{
			score = 0;
			uploadRate = 0;
			downloadRate = 0;
			ping = -1; // < 0 means hasn't been recorded yet
			pingUDP = -1;
			smallestPing = -1;
			color.Set(255,255,255,255);
			gameStateInitialized = false;
		}
	};

	// The network model for Asteroids is based on synced game times between the clients and server.  The reason for this is that a client that fires at a distant drifting asteroid
	//   should be able to strike it accurately both on the server machine and the client machine.  Reporting the gametime of the bullet shot allows this, ensuring the result of the shot
	//   is accurate.  Otherwise, allowing a simple report that a bullet was fired might come too late on the server, being applied it as is at the server's gametime and missing.
	// The other compelling reason for this model is that the server is responsible for determining the primary events that occur - bullets striking asteroids and ships, ships colliding ith asteroids, 
	//   ships picking up powerups, and their resulting velocities from colliding with each other.
	// It does present a few problems however:
	// - Events from clients that are reported on objects that were just updated by the server - the server may have updated the position and velocity of a ship, but a client is reporting
	//     a new position and velocity for the ship without having yet received the update.  This is blocked by reporting a gametime version on the ships whenever the server sends data
	//     down to a client.  When the client reports an update to a ship, the gametime version of that ship is sent, and if it doesn't match what is on the server, the update is blocked (although
	//     controls are still accepted, while the client later accepts the new position and velocity whenever it arrives).  This version gameTime is usually the creation or update time of the
	//     object (which can be between the start and end time of a full game tick) and can also serve as the lower bound for valid collisions.  Collisions detected on the object before that time are rejected
	// - Events can arrive on the server or client with a gametime that has not yet occurred on the receiver. This would mostly happen if the machine is spending so much time on the animate loop that
	//     the gametime hasn't had a chance to advance to a time equal to or greater than the arriving event.  In this case, the arriving event is held until the proper time it can be applied.
	// - Events might arrive so late (with a gametime significantly less than the receiver's current game time) that a certain amount of retconning might be necessary.  For example, a bullet arrives that
	//     strikes an asteroid in the past when it has long since drifted past that point.  More extremely, a bullet that would have struck an asteroid before another reported bullet would have, but
	//     the other bullet has already split the asteroid.  In situations like this, the server needs to decide if it will backtrack and apply the event or skip it because it is affecting an object
	//     that already received an update at a certain gametime, and new events that impact the object before that gametime will then be ignored.  So some retconning simply will not occur, but others 
	//     will be allowed if nothing has happened on that object for a while.  A simpler example is a bullet that arrives that drifts just behind an asteroid that was just created from a larger
	//     asteroid split.  If gametime is applied verbatim, the bullet would have struck the asteroid behind its creation point - but the gametime of the asteroid's creation, if it is used as a 
	//     lower bound for collision detection, will ignore any collisions occurring before that time.
	// Packet patterns:
	// - Clients are allowed to control their ships real time and fire bullets real time, reporting changes to the server who then reports those changes to everyone else.  Occasionally the server will
	//     correct a ship's position and velocity in the event that a collision with anotehr ship occurred.
	// - Clients can show bullet shots striking objects, but those obejcts are unaffected until the server decides that the bullet hit something.  The impacts will then be reported to every client.
	// - Clients will perform NO impacts of collision detection outside of showing bullets strike an object for effect.  The server is responsible for all impacts of collision (bullets striking objects,
	//      ships colliding with powerups, asteroids or other ships). Ships will drift through asteroidsm, ship and powerups until the server provides an update.
	// - Clients track their own bullet availability by handling bullet strikes for effect locally.  Occasionally this might allow more bullets than usual on the server because a ship bullet might
	//      miss an object affected by another bullet beforehand, but this should not be too common.
	// - Server will report asteroid destruction, explosion locations for split asteorids, damage on ships, rotation of deaththroes, final destruction, powerup updates, 
	//      and udpates to ship position and velocity when collisions with other ships occur
	// - Clients will locally animate their own bullet strikes and ship movement and rotation, and handle their own ship damage flashes, cloak fading, death throw rotation and ship destruction from event reports
	// Rules:
	// - New clients are told to collect a number of pings over time from the server to establish an initial accurate game time synced with the server.
	// - After that, the gamestate is sent down to the client, where the client will correct for the difference in gametime to provide an accurate representation of the gamestate on their box
	// - Clients will, after calling Animate(), track the current gameTime of their gamestate and use that to correct incoming object updates.   This is because while those events arrive, ping
	//     events can also arrive that adjust the gametime and make it different from the gametime of the gamestate, which will throw the object states out of time sync with each other, which
	//     interferes with collision detection (until a better method is found)
	// - After the gamestate is sent down, it is still possible to adjust the client's gametime such that the next elapsedTime < 0, in which case animation should be skipped until the elaspedTime 
	//     catches up, animate is called again, and the new gametime is tracked there again.  However, network processing and message times will always advance normally.
	// Complexities:
	// - when an object is updated with a new form and/ or position and velocity (that is, split asteroids and colliding ships), the new versions get gametimes from the server for the gametime that
	//     the update took place.  This serves as the lower bound for collisions and as version checking when client attempts to send an update for the object.  However, since it might be possible for
	//	   a bullet to arrive late, the gamestate could conceivably hold two versions of the object - before the update and after, where the old version uses the updated gametime of the new version
	//     as te upper bound for collisions - and get rid of the old version after a period of time.  The extra complexity here is that a single object can have multiple updates in a span of time, 
	//     so this strategy may be more bother than it is worth, and just reject anything trying to affect the object before its update gametime.
	// - To avoid confusion, for clarity, when Animate() is finished, the entire gamestate is moved up to a specific gameTimeMS with objects positioned there for rendering and a moveOffset that
	//     takes them back to the beginning of where they moved from.  When objects like asteroids and bullets arrive, they have minimumGameTimes and a current gameTime.  minimumGameTimeMS is the beginning
	//     of their creation, and gameTimeMS is where they are now.  These are used to guide collisions and prevent collisions that would occur before the object was actually created, in the event
	//     that a client machine's tick has a period of time that starts before their minumum game time.  In short, miniomumGameTimeMS should be less than the object's gameTimeMS and defines where
	//     the object started and where it moved to along its velocity when it arrived.  The client machine then uses that to place the object according to its own gameTimeMS and checks for collisions
	//     (retconned when the object arrives and in normal Animate() loops later) using the minimumGameTimeMS as a limit.  These limits matter on the clients for bullet collisions, and on the server
	//     for asteroid-ship, asteroid-bullet (both asteroid and bullet), and could matter for ship-powerup if desired (not currently implemented)
	// - Keeping the gamestate moved up to current gametime before very render, placing new objects received according to the same game time, and using minimumgametimeMS on obejcts to invalidate collisions
	//     and rendering prevents a great deal of chaotic number play and prevents depending on the next tick to 'clean' things or mold objects into their proper placement.  understanding that future
	//     or past objects can arrive after Aniamte() and after other collisions have been detected so that the arriving obejcts need to be retconned, with results still resulting in objects
	//     placed according to current game time keeps rules consistent and the methodologies clearer.
	// - If timer->Poll() has been called but an object is created at the beginning of that tick and will move the full tick to arrive at current gametime, then its creation time, and its
	//     minimum game time, is gametime - elapsedTime.  The game time of an object created as the result of a splitting or an event in the middle of a game tick will have a creation/minimumgametime of
	//     begnning of tick (that is, gametime - elapsedTime) + elaspedTime * (0.0-1.0 factor of the occurrence of the event along the duration of the gametick, or linear movement of all the objects)
	public class AsteroidsNetwork : public GameNetworkBase
	{
	private:
		AsteroidsGameData *gameDataRef; // reference, don't destroy
		GameUIFormBase *connectingMessageBox;

		int timeSinceLastPingRequestMS;

		// player requesting ping cycles from server at login
		int timeRequestPingCycleMS;
		int timeUntilNextPingCycleMS;
		int pingCyclesRemaining;

	public:
		AsteroidsNetwork(AsteroidsGameData *p_gameDataRef, int p_clientQty, String ^p_versionString, String ^p_versionGuid) : GameNetworkBase(p_clientQty, p_versionString, p_versionGuid)
		{
			gameDataRef = p_gameDataRef;
			ResetCustomSessionVariables();
		}

	private:
		void ResetCustomSessionVariables()
		{
			timeSinceLastPingRequestMS = 0;
			timeRequestPingCycleMS = 0;
			timeUntilNextPingCycleMS = 0;
			pingCyclesRemaining = 0;
		}

	public:
		virtual ~AsteroidsNetwork()
		{

		}

		void NetworkMessage(GameNetworkMessageType p_type, String ^p_message) override
		{
			if (IsActive() == false && p_type != GameNetworkMessageType::Disconnect)
			{
				GameContext::Instance->GetUI()->MessageBox(p_message);
			}
			else
				gameDataRef->messageList->AddMessage(p_message);
		}

	protected:
		void CustomProcess(int p_elapsedTimeMS) override
		{
			if (IsServer() == true)
			{
				timeSinceLastPingRequestMS += p_elapsedTimeMS;
				if (timeSinceLastPingRequestMS > 1000.0f)
				{
					timeSinceLastPingRequestMS = 0;
					SendPingRequestsToClients();
				}
			}

			if (IsClient() == true)
			{
				if (pingCyclesRemaining > 0)
				{
					if (timeUntilNextPingCycleMS <= p_elapsedTimeMS)
					{
						timeUntilNextPingCycleMS = timeRequestPingCycleMS;
						pingCyclesRemaining--;

						AsteroidsNetworkRequestPingCyclePacket pingCyclePacket;
						AsteroidsNetworkPacketHelper::PopulateRequestPingCyclePacket(pingCyclePacket, gameDataRef->gameTimerRef->GetPureTimeMS(), pingCyclesRemaining);
						SendToServerNow((char *)&pingCyclePacket, pingCyclePacket.length, 0);
					}
					else
						timeUntilNextPingCycleMS -= p_elapsedTimeMS;
				}
			}
		}

		void SendPingRequestsToClients()
		{
			AsteroidsNetworkRequestPingServerPacket pingRequestServerPacket;
			AsteroidsNetworkPacketHelper::PopulateRequestPingServerPacket(pingRequestServerPacket, gameDataRef->gameTimerRef->GetPureTimeMS());

			SendToAllClientsNow((char *)&pingRequestServerPacket, pingRequestServerPacket.length, 0);

			if (UsesUDP() == true)
			{
				AsteroidsNetworkPacketHelper::PopulateRequestPingServerUDPPacket(pingRequestServerPacket, gameDataRef->gameTimerRef->GetPureTimeMS());
				SendToAllClientsUDP((char *)&pingRequestServerPacket, pingRequestServerPacket.length, 0);
			}
		}

		bool CustomValidatePacket(char *p_packet, int p_type) override
		{
			switch (p_type)
			{
			case AsteroidsNetworkPacketType::Chat:
				{
					AsteroidsNetworkChatPacket *packet = (AsteroidsNetworkChatPacket *)p_packet;
					if (packet->fromPlayerId < 0)
						return false;
					if (packet->toPlayerId < -1)
						return false;
					if (packet->length != 17 + GameNetworkPacketHelper::StringLength(packet->message, 1999))
						return false;
					if (GameNetworkPacketHelper::StringLength(packet->message, 1999) > 1999)
						return false;
				}
					break;
			case AsteroidsNetworkPacketType::RequestPingServer:
				{
					AsteroidsNetworkRequestPingServerPacket *packet = (AsteroidsNetworkRequestPingServerPacket *)p_packet;
					if (packet->length != sizeof(AsteroidsNetworkRequestPingServerPacket))
						return false;
				}
					break;
			case AsteroidsNetworkPacketType::RequestPingClient:
				{
					AsteroidsNetworkRequestPingClientPacket *packet = (AsteroidsNetworkRequestPingClientPacket *)p_packet;
					if (packet->length != sizeof(AsteroidsNetworkRequestPingClientPacket))
						return false;
				}
					break;
			case AsteroidsNetworkPacketType::AnswerPing:
				{
					AsteroidsNetworkAnswerPingPacket *packet = (AsteroidsNetworkAnswerPingPacket *)p_packet;
					if (packet->length != sizeof(AsteroidsNetworkAnswerPingPacket))
						return false;
				}
					break;
			case AsteroidsNetworkPacketType::RequestPingServerUDP:
			{
				AsteroidsNetworkRequestPingServerPacket *packet = (AsteroidsNetworkRequestPingServerPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRequestPingServerPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::RequestPingClientUDP:
			{
				AsteroidsNetworkRequestPingClientPacket *packet = (AsteroidsNetworkRequestPingClientPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRequestPingClientPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::AnswerPingUDP:
			{
				AsteroidsNetworkAnswerPingPacket *packet = (AsteroidsNetworkAnswerPingPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkAnswerPingPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::RequestPingCycle:
			{
				AsteroidsNetworkRequestPingCyclePacket *packet = (AsteroidsNetworkRequestPingCyclePacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRequestPingCyclePacket))
					return false;
				if (packet->cycleNumber < 0)
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::AddAsteroid:
			{
				AsteroidsNetworkAddAsteroidPacket *packet = (AsteroidsNetworkAddAsteroidPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkAddAsteroidPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::UpdateAsteroid:
			{
				AsteroidsNetworkUpdateAsteroidPacket *packet = (AsteroidsNetworkUpdateAsteroidPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkUpdateAsteroidPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::RemoveAsteroid:
			{
				AsteroidsNetworkRemoveAsteroidPacket *packet = (AsteroidsNetworkRemoveAsteroidPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRemoveAsteroidPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::AddPowerup:
			{
				AsteroidsNetworkAddPowerupPacket *packet = (AsteroidsNetworkAddPowerupPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkAddPowerupPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::RemovePowerup:
			{
				AsteroidsNetworkRemovePowerupPacket *packet = (AsteroidsNetworkRemovePowerupPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRemovePowerupPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::ApplyShipPowerup:
			{
				AsteroidsNetworkApplyPowerupPacket *packet = (AsteroidsNetworkApplyPowerupPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkApplyPowerupPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::AddBullet:
			{
				AsteroidsNetworkAddBulletPacket *packet = (AsteroidsNetworkAddBulletPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkAddBulletPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::RemoveBullet:
			{
				AsteroidsNetworkRemoveBulletPacket *packet = (AsteroidsNetworkRemoveBulletPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRemoveBulletPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::AddShip:
			{
				AsteroidsNetworkAddShipPacket *packet = (AsteroidsNetworkAddShipPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkAddShipPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::UpdateShipFromClient:
			{
				AsteroidsNetworkUpdateShipFromClientPacket *packet = (AsteroidsNetworkUpdateShipFromClientPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkUpdateShipFromClientPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::UpdateShipFromClientUDP:
			{
				AsteroidsNetworkUpdateShipFromClientPacket *packet = (AsteroidsNetworkUpdateShipFromClientPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkUpdateShipFromClientPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::SpawnShip:
			{
				AsteroidsNetworkRespawnShipPacket *packet = (AsteroidsNetworkRespawnShipPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkRespawnShipPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::DamageShip:
			{
				AsteroidsNetworkDamageShipPacket *packet = (AsteroidsNetworkDamageShipPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkDamageShipPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::DyingShipPosition:
			{
				AsteroidsNetworkDyingShipPositionPacket *packet = (AsteroidsNetworkDyingShipPositionPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkDyingShipPositionPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::DestroyShip:
			{
				AsteroidsNetworkDestroyShipPacket *packet = (AsteroidsNetworkDestroyShipPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkDestroyShipPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::AddExplosion:
			{
				AsteroidsNetworkAddExplosionPacket *packet = (AsteroidsNetworkAddExplosionPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkAddExplosionPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::TauntAsteroidShipDestroyed:
			case AsteroidsNetworkPacketType::TauntBulletShipDestroyed:
			case AsteroidsNetworkPacketType::TauntShipCollideDeathThroe:
			case AsteroidsNetworkPacketType::TauntShipCollideDestroyed:
			{
				AsteroidsNetworkTauntPacket *packet = (AsteroidsNetworkTauntPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkTauntPacket))
					return false;
			}
			break;
			case AsteroidsNetworkPacketType::EchoPlayerDestroyedPlayer:
			{
				AsteroidsNetworkEchoPlayerDestroyedPlayerPacket *packet = (AsteroidsNetworkEchoPlayerDestroyedPlayerPacket *)p_packet;
				if (packet->length != sizeof(AsteroidsNetworkEchoPlayerDestroyedPlayerPacket))
					return false;
			}
			break;
			default:
				return false; // unrecognized packet type!
			}

			return true;
		}

		void CustomProcessPacketHost(GameNetworkClient *p_client, char *p_packet, int p_type) override
		{
			// process packet on host machine
			switch (p_type)
			{
			case AsteroidsNetworkPacketType::Chat:
			{
				AsteroidsNetworkChatPacket *packet = (AsteroidsNetworkChatPacket *)p_packet;
				AsteroidsNetworkPlayer *fromPlayer = (AsteroidsNetworkPlayer *)players.GetPlayer(packet->fromPlayerId);
				if (fromPlayer != nullptr)
				{
					if (packet->toPlayerId == -1)
					{
						// echo as a public message and send to everyone else, including the sender
						gameDataRef->EchoChatMessage(GameNetworkPacketHelper::CharArrayToString(packet->message), packet->fromPlayerId);

						// Send to everyone, including echoing back to client that sent it
						SendToAllClientsNow(p_packet, packet->length, 0);
					}
					else if (packet->toPlayerId == localUser.GetId())
					{
						// echo to screen as a tell, it's a tell to the host
						gameDataRef->EchoChatMessage(GameNetworkPacketHelper::CharArrayToString(packet->message), packet->fromPlayerId, true);
					}
					else
					{
						// forward it on to the receiver
						GameNetworkClient *client = GetClientByClientId(packet->toPlayerId);
						if (client != nullptr && client->GetStatus() == NetworkClientStatus::Validated)
						{
							SendToClientNow(client, p_packet, packet->length, 0);
						}
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::RequestPingClient: // received by a client that has been sent its gamestate, so client should AdjustGameTimeMS on return if ping is low enough
			{
				AsteroidsNetworkRequestPingClientPacket *packet = (AsteroidsNetworkRequestPingClientPacket *)p_packet;
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetPlayer(p_client->GetId());
				if (player != nullptr)
				{
					player->ping = gameDataRef->gameTimerRef->GetPureTimeMS() - packet->serverPureTimeMS;

					// no real need for smallest ping here except metrics.  Host does not adjust its gametime based on a ping from a client
					if (player->smallestPing == -1 || player->ping < player->smallestPing)
						player->smallestPing = player->ping;

					// send a response
					AsteroidsNetworkAnswerPingPacket answerPacket;
					AsteroidsNetworkPacketHelper::PopulateAnswerPingPacket(answerPacket, packet->clientPureTimeMS, gameDataRef->gameTimerRef->GetGameTimeMS(), false);
					SendToClientNow(p_client, (char *)&answerPacket, answerPacket.length, 0);
				}
			}
			break;
			case AsteroidsNetworkPacketType::RequestPingClientUDP: // received from a client to establish server ping to client only, send back answer so client can adjust gamestate
			{
				AsteroidsNetworkRequestPingClientPacket *packet = (AsteroidsNetworkRequestPingClientPacket *)p_packet;
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetPlayer(p_client->GetId());
				if (player != nullptr)
				{
					player->pingUDP = gameDataRef->gameTimerRef->GetPureTimeMS() - packet->serverPureTimeMS;

					// no real need for smallest ping here except metrics.  Host does not adjust its gametime based on a ping from a client
					if (player->smallestPing == -1 || player->pingUDP < player->smallestPing)
						player->smallestPing = player->pingUDP;

					// send a response
					AsteroidsNetworkAnswerPingPacket answerPacket;
					AsteroidsNetworkPacketHelper::PopulateAnswerPingUDPPacket(answerPacket, packet->clientPureTimeMS, gameDataRef->gameTimerRef->GetGameTimeMS(), false);
					SendToClientUDP(p_client, (char *)&answerPacket, answerPacket.length, 0);
				}
			}
			break;
			case AsteroidsNetworkPacketType::RequestPingCycle: // received by a client that hasn't been sent its gamestate yet, so client should SetGameTimeMS on return if ping is low enough
			{
				AsteroidsNetworkRequestPingCyclePacket *packet = (AsteroidsNetworkRequestPingCyclePacket *)p_packet;

				AsteroidsNetworkAnswerPingPacket answerPing;
				AsteroidsNetworkPacketHelper::PopulateAnswerPingPacket(answerPing, packet->clientPureTimeMS, gameDataRef->gameTimerRef->GetGameTimeMS(), true);
				SendToClientNow(p_client, (char *)&answerPing, answerPing.length, 0);
				if (packet->cycleNumber == 0)
				{
					AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetPlayer(p_client->GetId());
					if (player != nullptr)
					{
						player->gameStateInitialized = true;

						// send gamestate down to client according to current GameTime!
						GameNetworkPacketQueue packetQueue;
						packetQueue.Start(GameNetworkPacketSendType::Send, 0, 0, p_client->GetId());
						LinkedListEnumerator<AsteroidsAsteroid> asteroidEnum = LinkedListEnumerator<AsteroidsAsteroid>(gameDataRef->asteroids);
						while (asteroidEnum.MoveNext())
						{
							AsteroidsAsteroid *asteroid = &(asteroidEnum.Current()->data);
							AsteroidsNetworkAddAsteroidPacket asteroidPacket;
							AsteroidsNetworkPacketHelper::PopulateAddAsteroidPacket(asteroidPacket, asteroid->Id, asteroid->position, asteroid->velocity, asteroid->type, asteroid->radius, asteroid->minimumGameTimeMS, gameDataRef->gameTimerRef->GetGameTimeMS());
							packetQueue.SubmitPacket((char *)&asteroidPacket, asteroidPacket.length);
						}
						LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
						while (shipEnum.MoveNext())
						{
							AsteroidsShip *ship = &(shipEnum.Current()->data);
							AsteroidsNetworkAddShipPacket shipPacket;
							AsteroidsNetworkPacketHelper::PopulateAddShipPacket(shipPacket, ship->playerId, ship->Id, 
								ship->spinDirection, ship->thrust, ship->backwards, ship->left, ship->right, ship->boost,
								ship->position, ship->velocity, ship->rotationAngle, ship->color, ship->destroyed,
								ship->health, ship->shield, ship->boostFuel, ship->cloakMS, ship->deathThroesMS, ship->deathThroeRotationAnglePerMS,
								ship->lastGameTimeUpdatedByServerMS, gameDataRef->gameTimerRef->GetGameTimeMS());
							packetQueue.SubmitPacket((char *)&shipPacket, shipPacket.length);
						}
						LinkedListEnumerator<AsteroidsPowerup> powerupEnum = LinkedListEnumerator<AsteroidsPowerup>(gameDataRef->powerups);
						while (powerupEnum.MoveNext())
						{
							AsteroidsPowerup *powerup = &(powerupEnum.Current()->data);
							AsteroidsNetworkAddPowerupPacket powerupPacket;
							AsteroidsNetworkPacketHelper::PopulateAddPowerupPacket(powerupPacket, powerup->Id, powerup->position, powerup->velocity, powerup->type, powerup->minimumGameTimeMS, gameDataRef->gameTimerRef->GetGameTimeMS());
							packetQueue.SubmitPacket((char *)&powerupPacket, powerupPacket.length);
						}
						LinkedListEnumerator<AsteroidsBullet> bulletEnum = LinkedListEnumerator<AsteroidsBullet>(gameDataRef->bullets);
						while (bulletEnum.MoveNext())
						{
							AsteroidsBullet *bullet = &(bulletEnum.Current()->data);
							AsteroidsNetworkAddBulletPacket bulletPacket;
							AsteroidsNetworkPacketHelper::PopulateAddBulletPacket(bulletPacket, bullet->Id, bullet->ownerRef->Id, bullet->position, bullet->velocity, bullet->super, bullet->radius, bullet->lifeMS, bullet->minimumGameTimeMS, gameDataRef->gameTimerRef->GetGameTimeMS());
							packetQueue.SubmitPacket((char *)&bulletPacket, bulletPacket.length);
						}
						packetQueue.Finish();
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::UpdateShipFromClient:
			case AsteroidsNetworkPacketType::UpdateShipFromClientUDP:
			{
				AsteroidsNetworkUpdateShipFromClientPacket *packet = (AsteroidsNetworkUpdateShipFromClientPacket *)p_packet;

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				// todo: handle future gametime - collisions shouldn't happen before the bullet came into existence
				//Vector3d position = packet->position + packet->velocity.ScalarMult(gameTimeAdjustMS);
				//gameDataRef->playfield.NormalizePositionWithPlayfield(position);

				bool echoDebug = false; // debug to see how often client sends an update to the server
				if (echoDebug == true)
				{
					static int count = 0;
					count++;
					gameDataRef->messageList->AddMessage(String::Format("Update Ship {0}, adjust {1}", count, int(gameTimeAdjustMS)));
				}

				if (gameTimeAdjustMS >= 0.0f) // only if not future! (todo: handle future)
				{
					// get ship
					LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
					while (shipEnum.MoveNext())
					{
						if (shipEnum.Current()->data.Id == packet->shipId)
						{
							if (shipEnum.Current()->data.lastGameTimeUpdatedByPacketMS < packet->gameTimeMS)
							{
								shipEnum.Current()->data.lastGameTimeUpdatedByPacketMS = packet->gameTimeMS;

								AsteroidsShip *ship = &(shipEnum.Current()->data);
								// if version doesn't match, reject!  ship might also be in death throes, so dont' accept if ship can't be controlled
								if (ship->lastGameTimeUpdatedByServerMS == packet->gameTimeVersion && ship->CanBeControlled())
								{
									gameDataRef->UpdateShipFromClient(ship,
										packet->spinDirection, packet->controls,
										packet->position, packet->velocity, packet->rotationAngle,
										packet->boostFuel, packet->cloakMS,
										packet->gameTimeVersion);

									// also, forward this on to everyone else, not the controlling ship
									if (p_type == AsteroidsNetworkPacketType::UpdateShipFromClientUDP)
										gameDataRef->SendUpdateShipPacketToOtherClientsUDP(packet, p_client->GetId());
									else
										gameDataRef->SendUpdateShipPacketToOtherClients(packet, p_client->GetId());

									// this is the host, so collision checking!
									if (gameTimeAdjustMS > 0.0f)
										gameDataRef->RetconAnimateShip(ship, gameTimeAdjustMS, true);
								}
							}

							break;
						}
					}
				}
				else
				{
					if (AsteroidsDebugSettings::echoFutureRejectionPacket == true)
					{
						static int msgCount = 0;
						msgCount++;
						gameDataRef->messageList->AddMessage(String::Format("Future message - rejected {0}", msgCount));
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::DyingShipPosition:
			{
				// no need to validate gametime version since this is a specific update
				AsteroidsNetworkDyingShipPositionPacket *packet = (AsteroidsNetworkDyingShipPositionPacket *)p_packet;
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.Id == packet->id)
					{
						float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);

						// advance its position

						if (gameTimeAdjustMS >= 0.0f) // only if not future! (todo: handle future)
						{
							AsteroidsShip *ship = &(shipEnum.Current()->data);

							gameDataRef->UpdateDyingShipPosition(ship,
								packet->position, packet->velocity, ship->deathThroesMS + gameTimeAdjustMS);

							// also, forward this on to everyone else, not the controlling ship
							gameDataRef->SendDyingShipPositionPacketToClients(packet, p_client->GetId());

							// this is the host, so collision checking!
							if (gameTimeAdjustMS > 0.0f)
								gameDataRef->RetconAnimateShip(ship, gameTimeAdjustMS, true);
						}
						else
						{
							if (AsteroidsDebugSettings::echoFutureRejectionPacket == true)
							{
								static int msgCount = 0;
								msgCount++;
								gameDataRef->messageList->AddMessage(String::Format("Future message - rejected {0}", msgCount));
							}
						}

						break;
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::AddBullet:
			{
				AsteroidsNetworkAddBulletPacket *packet = (AsteroidsNetworkAddBulletPacket *)p_packet;

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position to gameTimeMS
				// retcon any bullet strikes, prevent collision prior to minimumGameTimeMS
				Vector3d position = Vector3d(packet->positionX, packet->positionY, 0.0f) + Vector3d(packet->velocityX, packet->velocityY, 0.0f).ScalarMult(gameTimeAdjustMS);
				position = gameDataRef->playfield.NormalizePositionWithPlayfield(position);

				float adjustedLifeMS = packet->lifeMS - float(gameTimeAdjustMS);
				if (adjustedLifeMS > 0)
				{
					// todo: even if life <= 0, it had a small life when it arrived and should still have collisions checked (VERY corner case)
					LinkedListNode<AsteroidsBullet> *bulletNode = gameDataRef->AddBullet(packet->id, packet->parentShipId, position, Vector3d(packet->velocityX, packet->velocityY, 0.0f), packet->super, packet->radius, packet->lifeMS - float(gameTimeAdjustMS), packet->minimumGameTimeMS);

					if (bulletNode != nullptr)
					{
						if (bulletNode->data.super == true)
						{
							// remove a super shot so ship can pick up the powerup again if it hits one
							// let client continue to decide which bullets sent are super by the packet
							bulletNode->data.ownerRef->superWeaponShots--;
							if (bulletNode->data.ownerRef->superWeaponShots < 0)
								bulletNode->data.ownerRef->superWeaponShots = 0;
						}

						// check retcon collisions against current gamestate
						gameDataRef->BulletRetconCollisions(bulletNode);

						// forward it on to the other players
						SendToAllClients((char *)packet, packet->length, 0, 0, p_client->GetId());
					}
				}
			}
			break;
			}
		}

		void CustomProcessPacketPlayer(char *p_packet, int p_type) override
		{
			// process packet on player machine
			switch (p_type)
			{
			case AsteroidsNetworkPacketType::Chat:
			{
				AsteroidsNetworkChatPacket *packet = (AsteroidsNetworkChatPacket *)p_packet;

				// echo to screen as public or a tell
				if (packet->toPlayerId == -1)
					gameDataRef->EchoChatMessage(GameNetworkPacketHelper::CharArrayToString(packet->message), packet->fromPlayerId);
				else
					// echo to screen as a tell, it's a tell to the client
					gameDataRef->EchoChatMessage(GameNetworkPacketHelper::CharArrayToString(packet->message), packet->fromPlayerId, true);

			}
			break;
			case AsteroidsNetworkPacketType::RequestPingServer:
			{
				AsteroidsNetworkRequestPingServerPacket *packet = (AsteroidsNetworkRequestPingServerPacket *)p_packet;
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetHostPlayer();
				if (player != nullptr)
				{
					// send a request for ping and answer server's ping
					AsteroidsNetworkRequestPingClientPacket requestPingPacket;
					AsteroidsNetworkPacketHelper::PopulateRequestPingClientPacket(requestPingPacket, packet->serverPureTimeMS, gameDataRef->gameTimerRef->GetPureTimeMS());
					SendToServerNow((char *)&requestPingPacket, requestPingPacket.length, 0);
				}

			}
			break;
			case AsteroidsNetworkPacketType::AnswerPing:
			{
				AsteroidsNetworkAnswerPingPacket *packet = (AsteroidsNetworkAnswerPingPacket *)p_packet;
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetHostPlayer();
				if (player != nullptr)
				{
					player->ping = gameDataRef->gameTimerRef->GetPureTimeMS() - packet->clientPureTimeMS;

					// adjust gametime if ping is low enough
					if (player->smallestPing == -1 || player->ping < player->smallestPing)
					{
						bool setGameTime = (player->smallestPing == -1); // always set game time if this is the first ping
						player->smallestPing = player->ping;

						int newGameTimeMS = packet->serverGameTimeMS + player->smallestPing / 2;
						if (packet->set == true)
						{
							if (gameDataRef->gameTimerRef->GetGameTimeMS() != newGameTimeMS || setGameTime == true)
							{
								int differenceMS = newGameTimeMS - gameDataRef->gameTimerRef->GetGameTimeMS();
								gameDataRef->gameTimerRef->SetGameTime(newGameTimeMS);
								// establsh current gametime of gamestate (haven't received gamestate yet)
								gameDataRef->gameStateGameTimeMS = gameDataRef->gameTimerRef->GetGameTimeMS();

								if (setGameTime == true)
									NetworkMessage(GameNetworkMessageType::Info, String::Format("Syncing game time - Ping: {0}ms - Game Time now {1}", player->smallestPing, gameDataRef->gameTimerRef->GetGameTimeMS()));
								else if (differenceMS > 0)
									NetworkMessage(GameNetworkMessageType::Info, String::Format("Syncing game time - Ping: {0}ms - Game Time now {1} (+{2})", player->smallestPing, gameDataRef->gameTimerRef->GetGameTimeMS(), differenceMS));
								else
									NetworkMessage(GameNetworkMessageType::Info, String::Format("Syncing game time - Ping: {0}ms - Game Time now {1} ({2})", player->smallestPing, gameDataRef->gameTimerRef->GetGameTimeMS(), differenceMS));
							}
						}
						else
							gameDataRef->gameTimerRef->AdjustGameTime(packet->serverGameTimeMS + player->smallestPing / 2);
					}
				}

			}
			break;
			case AsteroidsNetworkPacketType::RequestPingServerUDP:
			{
				AsteroidsNetworkRequestPingServerPacket *packet = (AsteroidsNetworkRequestPingServerPacket *)p_packet;
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetHostPlayer();
				if (player != nullptr)
				{
					// send a request for ping and answer server's ping
					AsteroidsNetworkRequestPingClientPacket requestPingPacket;
					AsteroidsNetworkPacketHelper::PopulateRequestPingClientUDPPacket(requestPingPacket, packet->serverPureTimeMS, gameDataRef->gameTimerRef->GetPureTimeMS());
					SendToServerUDP((char *)&requestPingPacket, requestPingPacket.length, 0);
				}
			}
			break;
			case AsteroidsNetworkPacketType::AnswerPingUDP:
			{
				AsteroidsNetworkAnswerPingPacket *packet = (AsteroidsNetworkAnswerPingPacket *)p_packet;
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)players.GetHostPlayer();
				if (player != nullptr)
				{
					player->pingUDP = gameDataRef->gameTimerRef->GetPureTimeMS() - packet->clientPureTimeMS;

					// adjust gametime if ping is low enough
					if (player->smallestPing == -1 || player->pingUDP < player->smallestPing)
					{
						bool setGameTime = (player->smallestPing == -1); // always set game time if this is the first ping
						player->smallestPing = player->pingUDP;

						int newGameTimeMS = packet->serverGameTimeMS + player->smallestPing / 2;
						if (packet->set == true)
						{
							if (gameDataRef->gameTimerRef->GetGameTimeMS() != newGameTimeMS || setGameTime == true)
							{
								int differenceMS = newGameTimeMS - gameDataRef->gameTimerRef->GetGameTimeMS();
								gameDataRef->gameTimerRef->SetGameTime(newGameTimeMS);
								// establsh current gametime of gamestate (haven't received gamestate yet)
								gameDataRef->gameStateGameTimeMS = gameDataRef->gameTimerRef->GetGameTimeMS();

								if (setGameTime == true)
									NetworkMessage(GameNetworkMessageType::Info, String::Format("Syncing game time - Ping: {0}ms - Game Time now {1}", player->smallestPing, gameDataRef->gameTimerRef->GetGameTimeMS()));
								else if (differenceMS > 0)
									NetworkMessage(GameNetworkMessageType::Info, String::Format("Syncing game time - Ping: {0}ms - Game Time now {1} (+{2})", player->smallestPing, gameDataRef->gameTimerRef->GetGameTimeMS(), differenceMS));
								else
									NetworkMessage(GameNetworkMessageType::Info, String::Format("Syncing game time - Ping: {0}ms - Game Time now {1} ({2})", player->smallestPing, gameDataRef->gameTimerRef->GetGameTimeMS(), differenceMS));
							}
						}
						else
							gameDataRef->gameTimerRef->AdjustGameTime(packet->serverGameTimeMS + player->smallestPing / 2);
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::RequestPingCycle:
			{
				AsteroidsNetworkRequestPingCyclePacket *packet = (AsteroidsNetworkRequestPingCyclePacket *)p_packet;

				// set up for ping request cycle
				timeRequestPingCycleMS = 100;
				timeUntilNextPingCycleMS = 0;
				pingCyclesRemaining = packet->cycleNumber;
			}
			break;
			case AsteroidsNetworkPacketType::AddAsteroid:
			{
				AsteroidsNetworkAddAsteroidPacket *packet = (AsteroidsNetworkAddAsteroidPacket *)p_packet;

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				Vector3d position = Vector3d(packet->positionX, packet->positionY, 0.0f) + Vector3d(packet->velocityX, packet->velocityY, 0.0f).ScalarMult(gameTimeAdjustMS);
				gameDataRef->playfield.NormalizePositionWithPlayfield(position);
				gameDataRef->AddAsteroid(packet->id, position, Vector3d(packet->velocityX, packet->velocityY, 0.0f), packet->asteroidType, packet->radius, packet->minimumGameTimeMS);
			}
			break;
			case AsteroidsNetworkPacketType::UpdateAsteroid:
			{
				AsteroidsNetworkUpdateAsteroidPacket *packet = (AsteroidsNetworkUpdateAsteroidPacket *)p_packet;

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				Vector3d position = Vector3d(packet->positionX, packet->positionY, 0.0f) + Vector3d(packet->velocityX, packet->velocityY, 0.0f).ScalarMult(gameTimeAdjustMS);
				gameDataRef->playfield.NormalizePositionWithPlayfield(position);

				gameDataRef->UpdateAsteroid(packet->id, position, Vector3d(packet->velocityX, packet->velocityY, 0.0f), packet->asteroidType, packet->radius, packet->minimumGameTimeMS);
			}
			break;
			case AsteroidsNetworkPacketType::RemoveAsteroid:
			{
				AsteroidsNetworkRemoveAsteroidPacket *packet = (AsteroidsNetworkRemoveAsteroidPacket *)p_packet;

				gameDataRef->RemoveAsteroid(packet->id);
			}
			break;
			case AsteroidsNetworkPacketType::AddPowerup:
			{
				AsteroidsNetworkAddPowerupPacket *packet = (AsteroidsNetworkAddPowerupPacket *)p_packet;

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				Vector3d position = Vector3d(packet->positionX, packet->positionY, 0.0f) + Vector3d(packet->velocityX, packet->velocityY, 0.0f).ScalarMult(gameTimeAdjustMS);
				gameDataRef->playfield.NormalizePositionWithPlayfield(position);

				gameDataRef->AddPowerup(packet->id, position, Vector3d(packet->velocityX, packet->velocityY, 0.0f), packet->powerupType, packet->minimumGameTimeMS);
			}
			break;
			case AsteroidsNetworkPacketType::RemovePowerup:
			{
				AsteroidsNetworkRemovePowerupPacket *packet = (AsteroidsNetworkRemovePowerupPacket *)p_packet;

				gameDataRef->RemovePowerup(packet->id);
			}
			break;
			case AsteroidsNetworkPacketType::ApplyShipPowerup:
			{
				AsteroidsNetworkApplyPowerupPacket *packet = (AsteroidsNetworkApplyPowerupPacket *)p_packet;
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.Id == packet->shipId)
					{
						gameDataRef->ApplyPowerup(packet->powerupType, &(shipEnum.Current()->data));
						break;
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::AddBullet:
			{
				AsteroidsNetworkAddBulletPacket *packet = (AsteroidsNetworkAddBulletPacket *)p_packet;
				
				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				// todo: handle future gametime - collisions shouldn't happen before the bullet came into existence
				Vector3d position = Vector3d(packet->positionX, packet->positionY, 0.0f) + Vector3d(packet->velocityX, packet->velocityY, 0.0f).ScalarMult(gameTimeAdjustMS);
				gameDataRef->playfield.NormalizePositionWithPlayfield(position);

				float adjustedLifeMS = packet->lifeMS - float(gameTimeAdjustMS);
				if (adjustedLifeMS > 0)
				{
					// todo: even if life <= 0, it had a small life when it arrived and should still have collisions checked (VERY corner case)
					LinkedListNode<AsteroidsBullet> *bulletNode = gameDataRef->AddBullet(packet->id, packet->parentShipId, position, Vector3d(packet->velocityX, packet->velocityY, 0.0f), packet->super, packet->radius, packet->lifeMS - float(gameTimeAdjustMS), packet->minimumGameTimeMS);

					// check retcon collisions against current gamestate
					if (bulletNode != nullptr)
						gameDataRef->BulletRetconCollisions(bulletNode);
				}
			}
			break;
			case AsteroidsNetworkPacketType::RemoveBullet:
			{
				AsteroidsNetworkRemoveBulletPacket *packet = (AsteroidsNetworkRemoveBulletPacket *)p_packet;

				gameDataRef->RemoveBullet(packet->id, packet->parentShipId);
			}
			break;
			case AsteroidsNetworkPacketType::AddShip:
			{
				AsteroidsNetworkAddShipPacket *packet = (AsteroidsNetworkAddShipPacket *)p_packet;

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				// todo: handle future gametime - collisions shouldn't happen before the bullet came into existence
				//Vector3d position = packet->position + packet->velocity.ScalarMult(gameTimeAdjustMS);
				//gameDataRef->playfield.NormalizePositionWithPlayfield(position);
				AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GetPlayer(packet->playerId);
				if (player != nullptr)
				{
					AsteroidsShip *ship = gameDataRef->AddShip(player, packet->shipId,
						packet->spinDirection, packet->thrust, packet->backwards, packet->left, packet->right, packet->boost,
						packet->position, packet->velocity, packet->rotationAngle, GameColor(packet->color), packet->destroyed,
						packet->health, packet->shield, packet->boostFuel, packet->cloakMS, packet->deathThroesMS, packet->deathThroeRotationAnglePerMS,
						packet->gameTimeVersion);

					if (ship != nullptr)
					{
						// this is a client, so no collision checking
						gameDataRef->RetconAnimateShip(ship, float(gameTimeAdjustMS), false);
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::UpdateShipFromClient:
			case AsteroidsNetworkPacketType::UpdateShipFromClientUDP:
			{
				AsteroidsNetworkUpdateShipFromClientPacket *packet = (AsteroidsNetworkUpdateShipFromClientPacket *)p_packet;

				// this is from host, so trust it as far as gametimeversion goes, but still lock on lastGameTimeUpdatedByPacketMS because
				//   packet could be TCP and arrive out of order or twice

				// calculate new position of asteroid based on local gameTimeMS
				// this happens at end of GameLoop, so next Aniamte will calculate a new MoveOffset.
				float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);
				// advance its position
				// todo: retcon any bullet strikes
				// todo: handle future gametime - collisions shouldn't happen before the bullet came into existence
				//Vector3d position = packet->position + packet->velocity.ScalarMult(gameTimeAdjustMS);
				//gameDataRef->playfield.NormalizePositionWithPlayfield(position);

				// get ship, trust update since it's from server
				if (gameTimeAdjustMS >= 0.0f) // only if not future! (todo: handle future)
				{
					LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
					while (shipEnum.MoveNext())
					{
						if (shipEnum.Current()->data.Id == packet->shipId)
						{
							if (shipEnum.Current()->data.lastGameTimeUpdatedByPacketMS < packet->gameTimeMS)
							{
								shipEnum.Current()->data.lastGameTimeUpdatedByPacketMS = packet->gameTimeMS;

								AsteroidsShip *ship = &(shipEnum.Current()->data);
								gameDataRef->UpdateShipFromClient(ship,
									packet->spinDirection, packet->controls,
									packet->position, packet->velocity, packet->rotationAngle,
									packet->boostFuel, packet->cloakMS,
									packet->gameTimeVersion);

								// this is a client, so no collision checking!
								if (gameTimeAdjustMS > 0.0)
									gameDataRef->RetconAnimateShip(ship, gameTimeAdjustMS, false);
							}

							break;
						}
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::SpawnShip:
			{
				AsteroidsNetworkRespawnShipPacket *packet = (AsteroidsNetworkRespawnShipPacket *)p_packet;
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.Id == packet->id)
					{
						gameDataRef->PlaceRespawnedShip(&(shipEnum.Current()->data), packet->x, packet->y);
						shipEnum.Current()->data.rotationAngle = packet->rotationAngle;
						// restore valid version so controlling machine can send updates for its ship
						shipEnum.Current()->data.lastGameTimeUpdatedByServerMS = packet->gameTimeVersion;
						break;
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::DamageShip:
			{
				AsteroidsNetworkDamageShipPacket *packet = (AsteroidsNetworkDamageShipPacket *)p_packet;
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.Id == packet->id)
					{
						bool shipWasAlive = shipEnum.Current()->data.IsAlive();

						gameDataRef->DamageShip(&(shipEnum.Current()->data), packet->damage, packet->damagingPlayerId);

						if (shipWasAlive == true && &(shipEnum.Current()->data) == gameDataRef->localPlayerShipRef && shipEnum.Current()->data.InDeathThroes() == true)
						{
							// report final position, velocity and gametime to server
							gameDataRef->SendDyingShipPositionToServer(&(shipEnum.Current()->data), gameDataRef->gameStateGameTimeMS);
						}

						break;
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::DyingShipPosition:
			{
				// no need to validate gametime version since this is a specific update
				AsteroidsNetworkDyingShipPositionPacket *packet = (AsteroidsNetworkDyingShipPositionPacket *)p_packet;
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.Id == packet->id)
					{
						float gameTimeAdjustMS = float(gameDataRef->gameStateGameTimeMS - packet->gameTimeMS);

						// advance its position

						if (gameTimeAdjustMS >= 0.0f) // only if not future! (todo: handle future)
						{
							AsteroidsShip *ship = &(shipEnum.Current()->data);

							gameDataRef->UpdateDyingShipPosition(ship,
								packet->position, packet->velocity, ship->deathThroesMS + gameTimeAdjustMS);

							// this is a player, so no collision checking!
							if (gameTimeAdjustMS > 0.0f)
								gameDataRef->RetconAnimateShip(ship, gameTimeAdjustMS, false);
						}
						else
						{
							bool echoFutureDebug = false;
							if (echoFutureDebug == true)
							{
								static int msgCount = 0;
								msgCount++;
								gameDataRef->messageList->AddMessage(String::Format("Future message - rejected {0}", msgCount));
							}
						}

						break;
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::DestroyShip:
			{
				AsteroidsNetworkDestroyShipPacket *packet = (AsteroidsNetworkDestroyShipPacket *)p_packet;
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.Id == packet->id)
					{
						gameDataRef->DestroyShip(&(shipEnum.Current()->data), Vector3d(packet->x, packet->y, 0.0f));
						break;
					}
				}
			}
			break;
			case AsteroidsNetworkPacketType::AddExplosion:
			{
				AsteroidsNetworkAddExplosionPacket *packet = (AsteroidsNetworkAddExplosionPacket *)p_packet;

				gameDataRef->AddExplosion(Vector3d(packet->x, packet->y, 0.0f), GameColor(packet->color), packet->radius, packet->expansionRatePerMS, packet->lifeMS);
			}
			break;
			case AsteroidsNetworkPacketType::TauntAsteroidShipDestroyed:
			{
				gameDataRef->TauntAsteroidShipDestroyed();
			}
			break;
			case AsteroidsNetworkPacketType::TauntBulletShipDestroyed:
			{
				gameDataRef->TauntBulletShipDestroyed();
			}
			break;
			case AsteroidsNetworkPacketType::TauntShipCollideDeathThroe:
			{
				gameDataRef->TauntShipCollideDeathThroe();
			}
			break;
			case AsteroidsNetworkPacketType::TauntShipCollideDestroyed:
			{
				gameDataRef->TauntShipCollideDestroyed();
			}
			break;
			case AsteroidsNetworkPacketType::EchoPlayerDestroyedPlayer:
			{
				AsteroidsNetworkEchoPlayerDestroyedPlayerPacket *packet = (AsteroidsNetworkEchoPlayerDestroyedPlayerPacket *)p_packet;
				gameDataRef->EchoPlayerDestroyedPlayerMessage(packet->destroyingPlayerId, packet->destroyedPlayerId);
			}
			break;
			}
		}

		void OnConnectingPreProcess(String ^p_message) override
		{
			// show message box
			connectingMessageBox = GameContext::Instance->GetUI()->MessageBox(p_message, true, true); // esc only to close

			// do a block render at least to show information for gethostbyname(), even if connection is not blocking
			GameContext::Instance->GetGame()->BlockRender();
		}

		bool OnConnectingContinue() override
		{
			// did user close the message box with Esc?
			return (connectingMessageBox->IsClosed() == false);
		}

		void OnConnectingCanceled() override
		{
			NetworkMessage(GameNetworkMessageType::Error, "Connection canceled"); // to force a message box
		}

		void OnConnectingPostProcess() override
		{
			// close the message box
			connectingMessageBox->Close();
		}

		void OnHostSuccess() override
		{
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Host Success, supporting {0} clients", GetClientQty()));
		}

		void OnConnectSuccess() override
		{
			// close connection dialogs (because connect() is not blocking, the connection dialogs are still up, and should be closed now)
			GameContext::Instance->GetUI()->CloseAllForms();

			NetworkMessage(GameNetworkMessageType::Info, "Connected");
			gameDataRef->ClientStartMultiplayer();

			bool simulateLagDebug = false;
			if (AsteroidsDebugSettings::clientLagSimulationAmount != -1)
			{
				if (AsteroidsDebugSettings::clientLagSimulationAmount >= 0)
					SimulateLag(AsteroidsDebugSettings::clientLagSimulationAmount);
				else
				{
					static FastRandom fastRandom;
					SimulateLag(fastRandom.GetRandomInteger(50, 500));
				}
			}
		}

		void OnConnectFailure(String ^p_reason) override
		{
			NetworkMessage(GameNetworkMessageType::Error, p_reason);
		}

		void OnJoined() override
		{
			// there is a player record for the local player.  Welcome message!
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)GetPlayer(GetLocalUserId());
			if (player == nullptr)
				throw gcnew Exception("No player!");
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Welcome, <b><color={0}>{1}</color></b>", player->color.ToString(), player->GetName()));
		}

		void OnDisconnect(String ^p_reason) override
		{
			// called on any disconnect (manual or forced)
			NetworkMessage(GameNetworkMessageType::Disconnect, "Disconnected - " + p_reason);
			gameDataRef->gameType = AsteroidsGameType::None;
			gameDataRef->ResetAllData();

			ResetCustomSessionVariables();
		}

		// player stuff
		GameNetworkPlayerBase * CreatePlayer() override
		{
			return new AsteroidsNetworkPlayer();
		}

		GameNetworkPlayerBase * ServerAddPlayer(GameNetworkClient &p_client, bool p_server, bool p_host) override
		{
			// client can be the localUser structure, which would be the host data.
			// implementation should perform extra maintenance and add extra information to the player in preparation for sending its information to the other clients
			AsteroidsShip *ship;
			if (p_client.GetId() == GetHostUserId())
			{
				ship = gameDataRef->HostStartMultiplayer();  // host is starting a game, reset playfield and give him a ship
				ship->playerId = GetHostUserId();
				ship->lastGameTimeUpdatedByServerMS = gameDataRef->gameTimerRef->GetGameTimeMS();
			}
			else
			{
				ship = gameDataRef->CreateShip(gameDataRef->asteroidsShipColorRegistry.GetAvailableColor()); // just make a ship for the joining client
				ship->playerId = p_client.GetId();
				ship->lastGameTimeUpdatedByServerMS = gameDataRef->gameTimerRef->GetGameTimeMS();

				// don't send ship to players yet, they don't have the player in their lists yet - wait for onplayerjoined
				//if (GameContext::Instance->GetNetwork()->IsServer())
					//gameDataRef->SendAddShipToClients(ship, gameDataRef->gameTimerRef->GetGameTimeMS());
			}

			// Do NOT destroy this pointer!  list will handle it.
			AsteroidsNetworkPlayer *newPlayer = (AsteroidsNetworkPlayer *)CreatePlayer();
			newPlayer->id = p_client.GetId();
			strcpy_s(newPlayer->name, 33, p_client.GetCharName());
			newPlayer->server = p_server;
			newPlayer->host = p_host;

			newPlayer->color = ship->color;
			newPlayer->shipRef = ship;

			players.AddPlayer(newPlayer);

			return newPlayer;
		}

		void SendAddPlayerPacket(GameNetworkPlayerBase *p_player, GameNetworkClient *p_destinationClient)  override // when player joins
		{
			AsteroidsNetworkAddPlayerPacket addPlayerPacket;
			if (p_destinationClient == nullptr)
			{
				// send to existing clients with echo
				AsteroidsNetworkPlayer *asteroidsPlayer = (AsteroidsNetworkPlayer *)p_player;
				AsteroidsNetworkPacketHelper::PopulateAddPlayerPacket(addPlayerPacket, asteroidsPlayer, true, asteroidsPlayer->color);

				// send to all except the joiner
				SendToAllClients((char *)&addPlayerPacket, addPlayerPacket.length, 0, 0, asteroidsPlayer->id);
			}
			else
			{
				// loop through all players and send their information to the new player
				LinkedListEnumerator<GameNetworkPlayerNode> playerEnum = players.GetEnumerator();
				while (playerEnum.MoveNext())
				{
					AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)playerEnum.Current()->data.player;
					AsteroidsNetworkPacketHelper::PopulateAddPlayerPacket(addPlayerPacket, player, false, player->color);
					SendToClient(p_destinationClient, (char *)&addPlayerPacket, addPlayerPacket.length, 0);
				}
			}
		}

		bool ValidateAddPlayerPacket(NetworkAddPlayerPacketBase *p_packet) override
		{
			// not using this, yet
			AsteroidsNetworkAddPlayerPacket *packet = (AsteroidsNetworkAddPlayerPacket *)p_packet;

			if (p_packet->id < 0)
				return false;
			int nameLength = GameNetworkPacketHelper::StringLength(p_packet->name, 32);
			if (nameLength > 32)
				return false;
			if (p_packet->length != sizeof(AsteroidsNetworkAddPlayerPacket))
				return false;

			return true;
		}

		void ClientAddPlayer(NetworkAddPlayerPacketBase *p_packet) override // client adding player
		{
			// implementation is expected to handle all of this and everything else in its version of NetworkAddPlayerPacketBase
			AsteroidsNetworkAddPlayerPacket *packet = (AsteroidsNetworkAddPlayerPacket *)p_packet;

			// do NOT deallocate this point!  list will take care of it!
			AsteroidsNetworkPlayer *newPlayer = (AsteroidsNetworkPlayer *)CreatePlayer();
			newPlayer->id = packet->id;
			strcpy_s(newPlayer->name, 33, packet->name);
			newPlayer->server = packet->server;
			newPlayer->host = packet->host;
			newPlayer->color = packet->color;
			newPlayer->shipRef = nullptr;
			players.AddPlayer(newPlayer);
		}

		void OnPlayerJoined(int p_id) override
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer* )players.GetPlayer(p_id);
			if (player == nullptr)
				throw gcnew Exception("player not found!");
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Player <b><color={0}>{1}</color></b> Joined", player->color.ToString(), player->GetName()));

			if (IsServer() == true)
			{
				// send player's ship to everyone
				LinkedListEnumerator<AsteroidsShip> shipEnum = LinkedListEnumerator<AsteroidsShip>(gameDataRef->ships);
				while (shipEnum.MoveNext())
				{
					if (shipEnum.Current()->data.playerId == p_id)
					{
						gameDataRef->SendAddShipToClients(&(shipEnum.Current()->data), gameDataRef->gameTimerRef->GetGameTimeMS());
					}
				}

				// tell joining player to request gametime pings from the server.  after all the pings are received, the server will send the game state down to the player and let their ship respawn
				AsteroidsNetworkRequestPingCyclePacket requestPingCycle;
				AsteroidsNetworkPacketHelper::PopulateRequestPingCyclePacket(requestPingCycle, 0, 10 ); // tell client to request 10 cycles
				// don't send Now, just in case something vital in Send() is delayed
				SendToClient(GetClientByClientId(p_id), (char *)&requestPingCycle, requestPingCycle.length, 0);
			}
		}

		void OnPlayerLeft(int p_id, bool p_echo) override
		{ 
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer*)players.GetPlayer(p_id);
			if (player != nullptr)
			{
				if (p_echo == true)
					NetworkMessage(GameNetworkMessageType::Info, String::Format("Player <b><color={0}>{1}</color></b> Left", player->color.ToString(), player->GetName()));

				// remove the player's ship
				gameDataRef->RemoveShip(player->id);
			}
		}

		void OnPlayerTimingOut(int p_id, int p_timeOutQty, int p_maxTimeouts) override
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer*)players.GetPlayer(p_id);
			if (player == nullptr)
				throw gcnew Exception("player not found!");
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Player <b><color={0}>{1}</color></b> Timing Out ({2}/{3})", player->color.ToString(), player->GetName(), p_timeOutQty, p_maxTimeouts));
		}

		void OnPlayerTimedOut(int p_id) override
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer*)players.GetPlayer(p_id);
			if (player == nullptr)
				throw gcnew Exception("player not found!");
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Player <b><color={0}>{1}</color></b> Timed Out", player->color.ToString(), player->GetName()));

			// remove the player's ship
			gameDataRef->RemoveShip(player->id);
		}

		void OnPlayerNoLongerTimingOut(int p_id) override
		{
			AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer*)players.GetPlayer(p_id);
			if (player == nullptr)
				throw gcnew Exception("player not found!");
			NetworkMessage(GameNetworkMessageType::Info, String::Format("Player <color={0}>{1}</color></b> No Longer Timing Out", player->color.ToString(), player->GetName()));
		}

	};

	class AsteroidsChatDlg : public GameUIForm
	{
		GameUILabel *label;
		GameUITextBox *chatEntry;

		gcroot<GameViewport^> viewportRef;
		AsteroidsGameData *gameDataRef;

	public:
		AsteroidsChatDlg(AsteroidsGameData *p_gameDataRef, GameViewport ^p_viewport)
		{
			gameDataRef = p_gameDataRef;
			viewportRef = p_viewport;

			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmallBold");
			int textHeight = font->GetHeight();

			SetPosition(RectangleF(80, 80, 700, float(font->GetHeight() + 6)));
			SetBackColor(GameColor(32, 32, 32, 240));

			label = (GameUILabel *)AddControl(new GameUILabel(RectangleF(3, 3, GetRect().Width, float(GetRect().Height - 6))));
			label->SetFont(font);
			label->SetForeColor(GameColor(255, 255, 255));
			label->SetBackColor(GameColor(0, 0, 0, 0));
			label->SetText("Chat:");
			label->SetSize(PointF(font->GetTextSize(label->GetText()).X + 4.0f, label->GetRect().Height));

			font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			chatEntry = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(label->GetRect().Width, 1, GetRect().Width - label->GetRect().Width - 2, GetRect().Height - 2)));
			chatEntry->SetFont(font);
			chatEntry->SetForeColor(GameColor(255, 255, 255));
			chatEntry->SetBackColor(GameColor(0, 0, 0, 0));
			chatEntry->SetBorderColor(GameColor(0, 0, 0, 0));
			chatEntry->SetMaxLength(400);
			chatEntry->SetText("");
			chatEntry->SetKeyDown((GameUIKeyDown)&AsteroidsChatDlg::chatEntry_KeyDown);
		}

		void chatEntry_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Enter)
			{
				String ^text = chatEntry->GetText()->Trim();
				if (text != "")
				{
					// send chat!
					gameDataRef->SendChatMessage(text);
				}
				Close();
			}
			else if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
			{
				// do nothing
				Close();
			}
		}

		// call before calling ShowModal (optional, some text of certain color may be hard to see)
		void SetTextColor(GameColor &p_color)
		{
			chatEntry->SetForeColor(p_color);
		}

		void ShowModal() override
		{
			chatEntry->SetText("");
			chatEntry->SelectAll(); // cheat to get caret in a non-bad position, until I fix SetText()

			// center on viewport lower part of screen
			SetLocation(PointF(viewportRef->GetWidth() / 2.0f - GetRect().Width / 2.0f, viewportRef->GetHeight() * 0.85f - GetRect().Height / 2.0f));

			GameUIForm::ShowModal();

			chatEntry->Focus();
		}
	};

	class AsteroidsHostDlg : public GameUIForm
	{
	private:
		GameUILabel *instructionsLabel;
		GameUILabel *instructionsLabel2;

		GameUILabel *hostNameLabel;
		GameUITextBox *hostNameTextBox;
		GameUILabel *hostNameErrorLabel;

		GameUIForm *mainMenuRef;
		GameUIForm *networkMenuRef;

	public:
		AsteroidsHostDlg()
		{
			mainMenuRef = nullptr;
			networkMenuRef = nullptr;

			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("InfoBold");
			int textHeight = font->GetHeight();

			SetPosition(RectangleF(80, 80, 250, float(textHeight + 40)));
			SetBackColor(GameColor(64, 64, 64, 128));

			instructionsLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, 10, 230, float(textHeight))));
			instructionsLabel->SetFont(font);
			instructionsLabel->SetForeColor(GameColor(255, 255, 255));
			if (ASTEROIDS_HOSTINGPORT_UDP != -1)
				instructionsLabel->SetText(String::Format("Route port {0} and {1} to", ASTEROIDS_HOSTINGPORT_TCP, ASTEROIDS_HOSTINGPORT_UDP));
			else
				instructionsLabel->SetText(String::Format("Route port {0} to", ASTEROIDS_HOSTINGPORT_TCP));
			instructionsLabel->SetBackColor(GameColor(64, 64, 64, 0));

			instructionsLabel2 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, instructionsLabel->GetRect().Bottom + 2.0f, 230, float(textHeight))));
			instructionsLabel2->SetFont(font);
			instructionsLabel2->SetForeColor(GameColor(255, 255, 255));
			instructionsLabel2->SetText("");
			instructionsLabel2->SetBackColor(GameColor(64, 64, 64, 0));

			hostNameLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, instructionsLabel2->GetRect().Bottom + 10.0f, 230, float(textHeight))));
			hostNameLabel->SetFont(font);
			hostNameLabel->SetForeColor(GameColor(255, 255, 0));
			hostNameLabel->SetText("Host Player Name");
			hostNameLabel->SetBackColor(GameColor(64, 64, 64, 0));

			hostNameTextBox = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(10, hostNameLabel->GetRect().Top + hostNameLabel->GetRect().Height + 2, 230, float(textHeight + 4)))); // allow margins
			hostNameTextBox->SetFont(font);
			hostNameTextBox->SetBackColor(GameColor(64, 64, 64, 64));
			hostNameTextBox->SetMaxLength(32);
			hostNameTextBox->SetKeyDown((GameUIKeyDown)&AsteroidsHostDlg::hostName_KeyDown);
			hostNameTextBox->SetText("Host Player");

			hostNameErrorLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, hostNameTextBox->GetRect().Top + hostNameTextBox->GetRect().Height + 2, 230, 16)));
			hostNameErrorLabel->SetFont(font);
			hostNameErrorLabel->SetForeColor(GameColor(255, 128, 64));
			hostNameErrorLabel->SetBackColor(GameColor(64, 64, 64, 0));

			SetSize(PointF(GetRect().Width, hostNameErrorLabel->GetRect().Top + hostNameErrorLabel->GetRect().Height + 10.0f));
		}

		~AsteroidsHostDlg()
		{
			// controls are destroyed automatically as long as they are added to the control
		}

		void hostName_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Enter)
			{
				bool error = false;
				// Validate and show error if needed
				// work up the form backwards so that last error encountered is highest

				hostNameErrorLabel->SetText("");
				String^ hostName = hostNameTextBox->GetText()->Trim();
				hostNameTextBox->SetText(hostName); // put cleaned version back
				if (hostName == "")
				{
					hostNameErrorLabel->SetText("Host Player Name is Required");
					hostNameTextBox->SelectAll();
					hostNameTextBox->Focus();
					error = true;
				}

				if (error == false)
				{
					// Host!
					// todo: any chance to render screen while hosting?  That would be in Host(), or a virtual that renders the connect message before the attempt.
					if (GameContext::Instance->GetNetwork()->Host(ASTEROIDS_HOSTINGPORT_TCP, hostName, "", true, ASTEROIDS_HOSTINGPORT_UDP) == true)
					{
						// close it
						Close();

						// close the multiplayer and main menues too
						networkMenuRef->Close();
						mainMenuRef->Close();
					}
				}
			}

			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
			{
				// close without effect
				Close();
			}
		}

	public:
		void Show()
		{
			throw gcnew Exception("No! HostDlg is meant to be a modal form!");
		}

		void ShowModal()
		{
			// clear error
			hostNameErrorLabel->SetText("");

			// show it!
			GameUIForm::ShowModal();

			hostNameTextBox->SelectAll();
			hostNameTextBox->Focus();

			String ^localIP = GameContext::Instance->GetNetwork()->GetLocalIP();
			instructionsLabel2->SetText(localIP);
		}

		void SetHostName(String ^p_clientName)
		{
			hostNameTextBox->SetText(p_clientName);
		}

		String ^ GetHostName()
		{
			return hostNameTextBox->GetText();
		}

		void SetParentForms(GameUIForm *p_mainMenuRef, GameUIForm *p_networkMenuRef)
		{
			mainMenuRef = p_mainMenuRef;
			networkMenuRef = p_networkMenuRef;
		}
	};

	class AsteroidsConnectDlg : public GameUIForm
	{
	private:
		GameUILabel *clientNameLabel;
		GameUITextBox *clientNameTextBox;
		GameUILabel *clientNameErrorLabel;

		GameUILabel *ipEntryLabel;
		GameUITextBox *ipEntryTextBox;
		GameUILabel *ipEntryErrorLabel;

		GameUIForm *mainMenuRef;
		GameUIForm *networkMenuRef;

	public:
		AsteroidsConnectDlg()
		{
			mainMenuRef = nullptr;
			networkMenuRef = nullptr;

			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("InfoBold");
			int textHeight = font->GetHeight();

			SetPosition(RectangleF(80, 80, 250, float(textHeight + 40)));
			SetBackColor(GameColor(64, 64, 64, 128));

			clientNameLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, 10, 230, float(textHeight))));
			clientNameLabel->SetFont(font);
			clientNameLabel->SetForeColor(GameColor(255, 255, 0));
			clientNameLabel->SetText("Player Name");
			clientNameLabel->SetBackColor(GameColor(64, 64, 64, 0));

			clientNameTextBox = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(10, clientNameLabel->GetRect().Top + clientNameLabel->GetRect().Height + 2, 230, float(textHeight + 4)))); // allow margins
			clientNameTextBox->SetFont(font);
			clientNameTextBox->SetBackColor(GameColor(64, 64, 64, 64));
			clientNameTextBox->SetMaxLength(32);
			clientNameTextBox->SetKeyDown((GameUIKeyDown)&AsteroidsConnectDlg::ipEntry_KeyDown);
			clientNameTextBox->SetText("Player");

			clientNameErrorLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, clientNameTextBox->GetRect().Top + clientNameTextBox->GetRect().Height + 2, 230, 16)));
			clientNameErrorLabel->SetFont(font);
			clientNameErrorLabel->SetForeColor(GameColor(255, 128, 64));
			clientNameErrorLabel->SetBackColor(GameColor(64, 64, 64, 0));

			ipEntryLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, clientNameErrorLabel->GetRect().Top + clientNameErrorLabel->GetRect().Height + 5, 230, float(textHeight))));
			ipEntryLabel->SetFont(font);
			ipEntryLabel->SetForeColor(GameColor(255, 255, 0));
			ipEntryLabel->SetText("IP Address or Host Name");
			ipEntryLabel->SetBackColor(GameColor(64, 64, 64, 0));

			ipEntryTextBox = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(10, ipEntryLabel->GetRect().Top + ipEntryLabel->GetRect().Height + 2, 230, float(textHeight + 4)))); // allow margins
			ipEntryTextBox->SetFont(font);
			ipEntryTextBox->SetBackColor(GameColor(64, 64, 64, 64));
			ipEntryTextBox->SetMaxLength(64);
			ipEntryTextBox->SetKeyDown((GameUIKeyDown)&AsteroidsConnectDlg::ipEntry_KeyDown);
			ipEntryTextBox->SetText("192.168.1.112");

			ipEntryErrorLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, ipEntryTextBox->GetRect().Top + ipEntryTextBox->GetRect().Height + 2, 230, 16)));
			ipEntryErrorLabel->SetFont(font);
			ipEntryErrorLabel->SetForeColor(GameColor(255, 128, 64));
			ipEntryErrorLabel->SetBackColor(GameColor(64, 64, 64, 0));

			SetSize(PointF(GetRect().Width, ipEntryErrorLabel->GetRect().Top + ipEntryErrorLabel->GetRect().Height + 10.0f));
		}

		~AsteroidsConnectDlg()
		{
			// controls are destroyed automatically as long as they are added to the control
		}

		void ipEntry_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Enter)
			{
				bool error = false;
				// Validate and show error if needed
				// work up the form backwards so that last error encountered is highest
				ipEntryErrorLabel->SetText("");
				String^ hostAddress = ipEntryTextBox->GetText()->Trim();
				while (hostAddress->IndexOf(" ") >= 0)
				{
					hostAddress = hostAddress->Remove(hostAddress->IndexOf(" "), 1);
				}
				ipEntryTextBox->SetText(hostAddress); // put cleaned version back
				if (hostAddress == "")
				{
					ipEntryErrorLabel->SetText("IP Address Is Required");
					ipEntryTextBox->SelectAll();
					ipEntryTextBox->Focus();
					error = true;
				}

				clientNameErrorLabel->SetText("");
				String^ clientName = clientNameTextBox->GetText()->Trim();
				clientNameTextBox->SetText(clientName); // put cleaned version back
				if (clientName == "")
				{
					clientNameErrorLabel->SetText("Player Name is Required");
					clientNameTextBox->SelectAll();
					clientNameTextBox->Focus();
					error = true;
				}

				if (error == false)
				{
					// Connect!
					bool blockingConnect = false;
					if (GameContext::Instance->GetNetwork()->Connect(hostAddress, ASTEROIDS_HOSTINGPORT_TCP, clientName, true, (blockingConnect==false), ASTEROIDS_HOSTINGPORT_UDP) == true && blockingConnect == true)
					{
						// if not a blockingConnect then leave them open - close when connection is successful when network determines connection success
						// if a blocking connect, then we have our connection result, and if we get here the connection was successful

						// close it
						Close();

						// close the multiplayer and main menues too
						networkMenuRef->Close();
						mainMenuRef->Close();
					}
				}
			}

			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
			{
				// close without effect
				Close();
			}
		}

	public:
		void Show()
		{
			throw gcnew Exception("No! ConnectDlg is meant to be a modal form!");
		}

		void ShowModal()
		{
			// clear error
			clientNameErrorLabel->SetText("");
			ipEntryErrorLabel->SetText("");

			// show it!
			GameUIForm::ShowModal();

			clientNameTextBox->SelectAll();
			ipEntryTextBox->SelectAll();
			clientNameTextBox->Focus();
		}

		void SetIPAddress(String ^p_address)
		{
			ipEntryTextBox->SetText(p_address);
		}

		void SetClientName(String ^p_clientName)
		{
			clientNameTextBox->SetText(p_clientName);
		}

		String ^ GetClientName()
		{
			return clientNameTextBox->GetText();
		}

		void SetParentForms(GameUIForm *p_mainMenuRef, GameUIForm *p_networkMenuRef)
		{
			mainMenuRef = p_mainMenuRef;
			networkMenuRef = p_networkMenuRef;
		}
	};

	public class AsteroidsNetworkMenu : public GameUIForm
	{
	private:
		AsteroidsGameData *gameDataRef;
		GameUILabel *labelControls1;
		GameUILabel *labelHost;
		GameUILabel *labelConnect;
		gcroot<GameViewport ^> viewportRef;

		GameUIForm *mainMenu;
		GameUIForm *connectDlgRef;
		GameUIForm *hostDlgRef;

	public:
		AsteroidsNetworkMenu(AsteroidsGameData *p_gameData, GameViewport ^p_viewport, GameUIForm *p_mainMenu, GameUIForm *p_hostDlgRef, GameUIForm *p_connectDlgRef)
		{
			gameDataRef = p_gameData;
			viewportRef = p_viewport;

			mainMenu = p_mainMenu;
			hostDlgRef = p_hostDlgRef;
			connectDlgRef = p_connectDlgRef;

			SetPosition(RectangleF(0, 0, 300, 400)); // 0,0 will be replaced before showing
			SetKeyDown((GameUIKeyDown)&AsteroidsNetworkMenu::MainMenu_KeyDown);
			SetBorderColor(GameColor(0, 0, 0, 0));
			SetBackColor(GameColor(64, 64, 64, 192));

			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			GameFont ^fontLarge = GameContext::Instance->FontRegistry.GetFont("MenuLarge");

			float horizontalMargin = 10.0f;
			float verticalMargin = 40.0f;
			float textControlVerticalMargin = 10.0f;
			float currentY = verticalMargin;

			labelControls1 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls1->SetFont(font);
			labelControls1->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls1->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls1->SetText("MULTIPLAYER");
			labelControls1->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls1->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			currentY += labelControls1->GetRect().Height + verticalMargin;

			labelHost = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(fontLarge->GetHeight() + textControlVerticalMargin * 2.0f))));
			labelHost->SetFont(font);
			labelHost->SetBackColor(GameColor(0, 0, 0, 0));
			labelHost->SetForeColor(GameColor(255, 255, 255, 128));
			labelHost->SetText("Host Game");
			labelHost->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelHost->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			labelHost->SetMouseMove((GameUIMouseMove)&AsteroidsNetworkMenu::labelHost_MouseMove);
			labelHost->SetMouseEntered((GameUIMouseEntered)&AsteroidsNetworkMenu::labelHost_MouseEntered);
			labelHost->SetMouseLeft((GameUIMouseLeft)&AsteroidsNetworkMenu::labelHost_MouseLeft);
			labelHost->SetMouseUp((GameUIMouseUp)&AsteroidsNetworkMenu::labelHost_MouseUp);
			currentY += labelHost->GetRect().Height + verticalMargin;

			labelConnect = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(fontLarge->GetHeight() + textControlVerticalMargin * 2.0f))));
			labelConnect->SetFont(font);
			labelConnect->SetBackColor(GameColor(0, 0, 0, 0));
			labelConnect->SetForeColor(GameColor(255, 255, 255, 128));
			labelConnect->SetText("Connect to Game");
			labelConnect->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelConnect->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			labelConnect->SetMouseMove((GameUIMouseMove)&AsteroidsNetworkMenu::labelConnect_MouseMove);
			labelConnect->SetMouseEntered((GameUIMouseEntered)&AsteroidsNetworkMenu::labelConnect_MouseEntered);
			labelConnect->SetMouseLeft((GameUIMouseLeft)&AsteroidsNetworkMenu::labelConnect_MouseLeft);
			labelConnect->SetMouseUp((GameUIMouseUp)&AsteroidsNetworkMenu::labelConnect_MouseUp);
			currentY += labelHost->GetRect().Height + verticalMargin;

			SetSize(PointF(GetRect().Width, currentY));
		}

		void MainMenu_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
				Close();
		}

		void labelHost_MouseMove(MouseMoveArgs &p_args)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelHost->SetFont(font);
			labelHost->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelHost_MouseEntered()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelHost->SetFont(font);
			labelHost->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelHost_MouseLeft()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelHost->SetFont(font);
			labelHost->SetForeColor(GameColor(255, 255, 255, 128));
		}

		void labelHost_MouseUp(GameEng::Input::MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				// show hosting dialog with instructions
				hostDlgRef->ShowModal();
			}
		}

		void labelConnect_MouseMove(MouseMoveArgs &p_args)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelConnect->SetFont(font);
			labelConnect->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelConnect_MouseEntered()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelConnect->SetFont(font);
			labelConnect->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelConnect_MouseLeft()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelConnect->SetFont(font);
			labelConnect->SetForeColor(GameColor(255, 255, 255, 128));
		}

		void labelConnect_MouseUp(GameEng::Input::MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				// show connect dialog
				connectDlgRef->ShowModal();
			}
		}

		void ShowModal() override
		{
			// reset font sizes and colors
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelHost->SetFont(font);
			labelHost->SetForeColor(GameColor(255, 255, 255, 128));
			labelConnect->SetFont(font);
			labelConnect->SetForeColor(GameColor(255, 255, 255, 128));

			// center on viewport
			SetLocation(PointF(viewportRef->GetWidth() / 2.0f - GetRect().Width / 2.0f + 20.0f, viewportRef->GetHeight() / 2.0f - GetRect().Height / 2.0f + 20.0f));

			GameUIForm::ShowModal();
		}
	};

	public class AsteroidsNetworkedMenu : public GameUIForm
	{
	private:
		AsteroidsGameData *gameDataRef;
		GameUILabel *labelControls1;
		GameUILabel *labelControls2;
		GameUILabel *labelControls2a;
		GameUILabel *labelControls3;
		GameUILabel *labelControls4;
		GameUILabel *labelControls5;
		GameUILabel *labelControls6;
		GameUILabel *labelControls7;
		GameUILabel *labelDisconnect;
		gcroot<GameViewport ^> viewportRef;

		GameUIForm *mainMenuRef;

	public:
		AsteroidsNetworkedMenu(AsteroidsGameData *p_gameData, GameViewport ^p_viewport, GameUIForm *p_mainMenu)
		{
			gameDataRef = p_gameData;
			viewportRef = p_viewport;
			mainMenuRef = p_mainMenu;

			SetPosition(RectangleF(0, 0, 300, 400)); // 0,0 will be replaced before showing
			SetKeyDown((GameUIKeyDown)&AsteroidsNetworkedMenu::MainMenu_KeyDown);
			SetBorderColor(GameColor(0, 0, 0, 0));
			SetBackColor(GameColor(64, 64, 64, 192));

			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			GameFont ^fontLarge = GameContext::Instance->FontRegistry.GetFont("MenuLarge");

			float horizontalMargin = 10.0f;
			float verticalMargin = 40.0f;
			float textControlVerticalMargin = 10.0f;
			float currentY = verticalMargin;

			labelControls1 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls1->SetFont(font);
			labelControls1->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls1->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls1->SetText("CONTROLS:");
			labelControls1->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls1->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls1->GetRect().Height;

			labelControls2 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls2->SetFont(font);
			labelControls2->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls2->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls2->SetText("Movement - WASD or arrow keys");
			labelControls2->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls2->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls2->GetRect().Height;

			labelControls2a = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls2a->SetFont(font);
			labelControls2a->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls2a->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls2a->SetText("Slide - Q, E");
			labelControls2a->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls2a->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls2a->GetRect().Height;

			labelControls3 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls3->SetFont(font);
			labelControls3->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls3->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls3->SetText("Boost - SHIFT");
			labelControls3->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls3->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls3->GetRect().Height;

			labelControls4 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls4->SetFont(font);
			labelControls4->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls4->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls4->SetText("Fire - Ctrl, SPACE or mouse button");
			labelControls4->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls4->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls4->GetRect().Height;

			labelControls5 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls5->SetFont(font);
			labelControls5->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls5->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls5->SetText("Chat - C or ENTER");
			labelControls5->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls5->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls5->GetRect().Height;

			labelControls6 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls6->SetFont(font);
			labelControls6->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls6->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls6->SetText("Player List - TAB");
			labelControls6->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls6->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls6->GetRect().Height;

			labelControls7 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls7->SetFont(font);
			labelControls7->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls7->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls7->SetText("Toggle VSync - V");
			labelControls7->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls7->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls7->GetRect().Height + verticalMargin;

			labelDisconnect = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(fontLarge->GetHeight() + textControlVerticalMargin * 2.0f))));
			labelDisconnect->SetFont(font);
			labelDisconnect->SetBackColor(GameColor(0, 0, 0, 0));
			labelDisconnect->SetForeColor(GameColor(255, 255, 255, 128));
			labelDisconnect->SetText("Disconnect");
			labelDisconnect->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelDisconnect->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			labelDisconnect->SetMouseMove((GameUIMouseMove)&AsteroidsNetworkedMenu::labelDisconnect_MouseMove);
			labelDisconnect->SetMouseEntered((GameUIMouseEntered)&AsteroidsNetworkedMenu::labelDisconnect_MouseEntered);
			labelDisconnect->SetMouseLeft((GameUIMouseLeft)&AsteroidsNetworkedMenu::labelDisconnect_MouseLeft);
			labelDisconnect->SetMouseUp((GameUIMouseUp)&AsteroidsNetworkedMenu::labelDisconnect_MouseUp);
			currentY += labelDisconnect->GetRect().Height + verticalMargin;

			SetSize(PointF(GetRect().Width, currentY));
		}

		void MainMenu_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
				Close();
		}

		void labelDisconnect_MouseMove(MouseMoveArgs &p_args)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelDisconnect->SetFont(font);
			labelDisconnect->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelDisconnect_MouseEntered()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelDisconnect->SetFont(font);
			labelDisconnect->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelDisconnect_MouseLeft()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelDisconnect->SetFont(font);
			labelDisconnect->SetForeColor(GameColor(255, 255, 255, 128));
		}

		void labelDisconnect_MouseUp(GameEng::Input::MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				gameDataRef->Disconnect();
				Close();

				mainMenuRef->ShowModal();
			}
		}

		void ShowModal() override
		{
			// reset font sizes and colors
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelDisconnect->SetFont(font);
			labelDisconnect->SetForeColor(GameColor(255, 255, 255, 128));

			// center on viewport
			SetLocation(PointF(viewportRef->GetWidth() / 2.0f - GetRect().Width / 2.0f, viewportRef->GetHeight() / 2.0f - GetRect().Height / 2.0f));

			GameUIForm::ShowModal();
		}
	};

	public class AsteroidsMainMenu : public GameUIForm
	{
	private:
		AsteroidsGameData *gameDataRef;
		GameUILabel *labelControls1;
		GameUILabel *labelControls2;
		GameUILabel *labelControls2a;
		GameUILabel *labelControls3;
		GameUILabel *labelControls4;
		GameUILabel *labelControls5;
		GameUILabel *labelSinglePlayer;
		GameUILabel *labelMultiplayer;
		GameUILabel *labelQuit;
		gcroot<GameViewport ^> viewportRef;

		GameUIForm *networkMenuRef;

	public:
		AsteroidsMainMenu(AsteroidsGameData *p_gameData, GameViewport ^p_viewport, GameUIForm *p_networkMenuRef)
		{
			gameDataRef = p_gameData;
			viewportRef = p_viewport;
			networkMenuRef = p_networkMenuRef;

			SetPosition(RectangleF(0, 0, 300, 400)); // 0,0 will be replaced before showing
			SetKeyDown((GameUIKeyDown)&AsteroidsMainMenu::MainMenu_KeyDown);
			SetBorderColor(GameColor(0,0,0,0));
			SetBackColor(GameColor(64, 64, 64, 192));

			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			GameFont ^fontLarge = GameContext::Instance->FontRegistry.GetFont("MenuLarge");

			float horizontalMargin = 10.0f;
			float verticalMargin = 40.0f;
			float textControlVerticalMargin = 10.0f;
			float currentY = verticalMargin;

			labelControls1 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls1->SetFont(font);
			labelControls1->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls1->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls1->SetText("CONTROLS:");
			labelControls1->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls1->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls1->GetRect().Height;

			labelControls2 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls2->SetFont(font);
			labelControls2->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls2->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls2->SetText("Movement - WASD or arrow keys");
			labelControls2->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls2->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls2->GetRect().Height;

			labelControls2a = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls2a->SetFont(font);
			labelControls2a->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls2a->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls2a->SetText("Slide - Q, E");
			labelControls2a->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls2a->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls2a->GetRect().Height;

			labelControls3 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls3->SetFont(font);
			labelControls3->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls3->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls3->SetText("Boost - SHIFT");
			labelControls3->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls3->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls3->GetRect().Height;

			labelControls4 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls4->SetFont(font);
			labelControls4->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls4->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls4->SetText("Fire - Ctrl, SPACE or mouse button");
			labelControls4->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls4->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls4->GetRect().Height;

			labelControls5 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(font->GetHeight()))));
			labelControls5->SetFont(font);
			labelControls5->SetBackColor(GameColor(0, 0, 0, 0));
			labelControls5->SetForeColor(GameColor(255, 255, 255, 255));
			labelControls5->SetText("Toggle VSync - V");
			labelControls5->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelControls5->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Left);
			currentY += labelControls5->GetRect().Height + verticalMargin;

			labelSinglePlayer = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(fontLarge->GetHeight() + textControlVerticalMargin * 2.0f))));
			labelSinglePlayer->SetFont(font);
			labelSinglePlayer->SetBackColor(GameColor(0, 0, 0, 0));
			labelSinglePlayer->SetForeColor(GameColor(255, 255, 255, 128));
			labelSinglePlayer->SetText("Single Player");
			labelSinglePlayer->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelSinglePlayer->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			labelSinglePlayer->SetMouseMove((GameUIMouseMove)&AsteroidsMainMenu::labelSinglePlayer_MouseMove);
			labelSinglePlayer->SetMouseEntered((GameUIMouseEntered)&AsteroidsMainMenu::labelSinglePlayer_MouseEntered);
			labelSinglePlayer->SetMouseLeft((GameUIMouseLeft)&AsteroidsMainMenu::labelSinglePlayer_MouseLeft);
			labelSinglePlayer->SetMouseUp((GameUIMouseUp)&AsteroidsMainMenu::labelSinglePlayer_MouseUp);
			currentY += labelSinglePlayer->GetRect().Height + verticalMargin;

			labelMultiplayer = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(fontLarge->GetHeight() + textControlVerticalMargin * 2.0f))));
			labelMultiplayer->SetFont(font);
			labelMultiplayer->SetBackColor(GameColor(0, 0, 0, 0));
			labelMultiplayer->SetForeColor(GameColor(255, 255, 255, 128));
			labelMultiplayer->SetText("Multiplayer");
			labelMultiplayer->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelMultiplayer->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			labelMultiplayer->SetMouseMove((GameUIMouseMove)&AsteroidsMainMenu::labelMultiplayer_MouseMove);
			labelMultiplayer->SetMouseEntered((GameUIMouseEntered)&AsteroidsMainMenu::labelMultiplayer_MouseEntered);
			labelMultiplayer->SetMouseLeft((GameUIMouseLeft)&AsteroidsMainMenu::labelMultiplayer_MouseLeft);
			labelMultiplayer->SetMouseUp((GameUIMouseUp)&AsteroidsMainMenu::labelMultiplayer_MouseUp);
			currentY += labelMultiplayer->GetRect().Height + verticalMargin;

			labelQuit = (GameUILabel *)AddControl(new GameUILabel(RectangleF(horizontalMargin, currentY, GetRect().Width - horizontalMargin * 2.0f, float(fontLarge->GetHeight() + textControlVerticalMargin * 2.0f))));
			labelQuit->SetFont(font);
			labelQuit->SetBackColor(GameColor(0, 0, 0, 0));
			labelQuit->SetForeColor(GameColor(255, 255, 255, 128));
			labelQuit->SetText("Quit");
			labelQuit->SetTextVerticalAlignment(GameUITextVerticalAlignment::Center);
			labelQuit->SetTextHorizontalAlignment(GameUITextHorizontalAlignment::Center);
			labelQuit->SetMouseMove((GameUIMouseMove)&AsteroidsMainMenu::labelQuit_MouseMove);
			labelQuit->SetMouseEntered((GameUIMouseEntered)&AsteroidsMainMenu::labelQuit_MouseEntered);
			labelQuit->SetMouseLeft((GameUIMouseLeft)&AsteroidsMainMenu::labelQuit_MouseLeft);
			labelQuit->SetMouseUp((GameUIMouseUp)&AsteroidsMainMenu::labelQuit_MouseUp);
			currentY += labelQuit->GetRect().Height + verticalMargin;

			SetSize(PointF(GetRect().Width, currentY));
		}

		void MainMenu_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
				Close();
		}

		void labelSinglePlayer_MouseMove(MouseMoveArgs &p_args)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelSinglePlayer->SetFont(font);
			labelSinglePlayer->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelSinglePlayer_MouseEntered()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelSinglePlayer->SetFont(font);
			labelSinglePlayer->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelSinglePlayer_MouseLeft()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelSinglePlayer->SetFont(font);
			labelSinglePlayer->SetForeColor(GameColor(255, 255, 255, 128));
		}

		void labelMultiplayer_MouseMove(MouseMoveArgs &p_args)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelMultiplayer->SetFont(font);
			labelMultiplayer->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelMultiplayer_MouseEntered()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelMultiplayer->SetFont(font);
			labelMultiplayer->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelMultiplayer_MouseLeft()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelMultiplayer->SetFont(font);
			labelMultiplayer->SetForeColor(GameColor(255, 255, 255, 128));
		}

		void labelMultiplayer_MouseUp(GameEng::Input::MouseButton p_button)
		{
			// host or connect menu!
			networkMenuRef->ShowModal();
		}

		void labelQuit_MouseMove(MouseMoveArgs &p_args)
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelQuit->SetFont(font);
			labelQuit->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelQuit_MouseEntered()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuLarge");
			labelQuit->SetFont(font);
			labelQuit->SetForeColor(GameColor(255, 255, 255, 255));
		}

		void labelQuit_MouseLeft()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelQuit->SetFont(font);
			labelQuit->SetForeColor(GameColor(255, 255, 255, 128));
		}

		void labelSinglePlayer_MouseUp(GameEng::Input::MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				gameDataRef->StartSinglePlayer();
				Close();
			}
		}

		void labelQuit_MouseUp(GameEng::Input::MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				gameDataRef->exitGame = true;
				Close();
			}
		}

		void ShowModal() override
		{
			// reset font sizes and colors
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MenuSmall");
			labelSinglePlayer->SetFont(font);
			labelSinglePlayer->SetForeColor(GameColor(255, 255, 255, 128));
			labelMultiplayer->SetFont(font);
			labelMultiplayer->SetForeColor(GameColor(255, 255, 255, 128));
			labelQuit->SetFont(font);
			labelQuit->SetForeColor(GameColor(255, 255, 255, 128));

			// center on viewport
			SetLocation(PointF(viewportRef->GetWidth() / 2.0f - GetRect().Width / 2.0f, viewportRef->GetHeight() / 2.0f - GetRect().Height / 2.0f));

			GameUIForm::ShowModal();
		}
	};

	// no real need to override this just yet, but just in case
	public class AsteroidsUI : public GameUI
	{
		AsteroidsGameData *gameDataRef; // reference, don't destroy

	public:
		AsteroidsUI(AsteroidsGameData *p_gameDataRef, GameViewport ^p_viewport, GameFont ^p_defaultFont, GameColor p_defaultForeColor) : GameUI(p_viewport, p_defaultFont, p_defaultForeColor)
		{
			gameDataRef = p_gameDataRef;
		}

		virtual ~AsteroidsUI()
		{

		}
	};

	public ref class AsteroidsGame : public GameBase
	{
	public:

		AsteroidsGameData *gameData;
		GameTimer *timer;
		GameTimer *steadyTimer;
		float slowMotionFactor;
		AsteroidsUI *asteroidsUI;
		AsteroidsNetwork *asteroidsNetwork;

		AsteroidsNetworkMenu *networkMenu;
		AsteroidsMainMenu *mainMenu;
		AsteroidsNetworkedMenu *networkedMenu;
		AsteroidsConnectDlg *connectDlg;
		AsteroidsHostDlg *hostDlg;
		AsteroidsChatDlg *chatDlg;

		bool showPlayerList;

		AsteroidsGame(HWND p_hWnd) : GameBase(p_hWnd)
		{
			gameData = nullptr;
			timer = nullptr;
			steadyTimer = nullptr;
			asteroidsUI = nullptr;
			asteroidsNetwork = nullptr;
			slowMotionFactor = 1.0f;

			networkMenu = nullptr;
			mainMenu = nullptr;
			networkedMenu = nullptr;
			connectDlg = nullptr;
			hostDlg = nullptr;

			showPlayerList = false;
		}

		virtual ~AsteroidsGame()
		{
			Destroy();
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		void Initialize() override
		{
			GameContext::Instance->SetGame(this);

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Messages720", gcnew System::Drawing::Font("Verdana", 14));
			GameContext::Instance->FontRegistry.RegisterFont("MessagesBold720", gcnew System::Drawing::Font("Verdana", 14, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("Messages1080", gcnew System::Drawing::Font("Verdana", 18));
			GameContext::Instance->FontRegistry.RegisterFont("MessagesBold1080", gcnew System::Drawing::Font("Verdana", 18, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("Messages500", gcnew System::Drawing::Font("Verdana", 10));
			GameContext::Instance->FontRegistry.RegisterFont("MessagesBold500", gcnew System::Drawing::Font("Verdana", 10, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("MenuSmall", gcnew System::Drawing::Font("Verdana", 12));
			GameContext::Instance->FontRegistry.RegisterFont("MenuSmallBold", gcnew System::Drawing::Font("Verdana", 12, FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("MenuLarge", gcnew System::Drawing::Font("Verdana", 16));
			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 10));
			GameContext::Instance->FontRegistry.RegisterFont("InfoBold", gcnew System::Drawing::Font("Verdana", 10, FontStyle::Bold));

			// set up file resources and textures
			GameContext::Instance->FileRegistry.RegisterFileResource("star.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Star", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("star.jpg"));

			timer = new GameTimer();
			steadyTimer = new GameTimer();

			gameData = new AsteroidsGameData(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), timer);
			gameData->SetPlayfieldBounds(8000.0f, 8000.0f);

			asteroidsUI = new AsteroidsUI(gameData, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), GameContext::Instance->FontRegistry.GetFont("MenuSmall"), GameColor(255,255,255));
			GameContext::Instance->SetUI(asteroidsUI);
			connectDlg = new AsteroidsConnectDlg();
			hostDlg = new AsteroidsHostDlg();
			networkMenu = new AsteroidsNetworkMenu(gameData, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), mainMenu, hostDlg, connectDlg);
			mainMenu = new AsteroidsMainMenu(gameData, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), networkMenu);
			networkedMenu = new AsteroidsNetworkedMenu(gameData, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), mainMenu);
			connectDlg->SetParentForms(mainMenu, networkMenu);
			hostDlg->SetParentForms(mainMenu, networkMenu);
			chatDlg = new AsteroidsChatDlg(gameData, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"));

			asteroidsNetwork = new AsteroidsNetwork(gameData, 8, ASTEROIDS_VERSIONSTRING, ASTEROIDS_VERSIONGUID);
			GameContext::Instance->SetNetwork(asteroidsNetwork);
			asteroidsNetwork->Startup("1.0.2");

#ifdef _DEBUG
			TestShipAnimation();
#endif
		}

		void TestShipAnimation()
		{
			// test that two ships while thrusting normally end up in same place over 100 seconds
			AsteroidsShip ship1;
			AsteroidsShip ship2;
			ship1.Initialize(false, false);
			ship2.Initialize(false, false);
			ship1.rotationAngle = 0;
			ship2.rotationAngle = 0;

			ship1.thrust = true;
			ship2.thrust = true;

			FastRandom fastrandom;

			float testTime = 100000.0f;

			float timeToConsume = testTime;
			while (timeToConsume > 0.0f)
			{
				float timeStep = 1.0f + float(fastrandom.GetRandomInteger(0, 1));

				if (timeToConsume > timeStep)
				{
					ship1.Animate(timeStep, gameData->playfield);
					timeToConsume -= timeStep;
				}
				else
				{
					ship1.Animate(timeToConsume, gameData->playfield);
					timeToConsume = 0;
				}
			}

			timeToConsume = testTime;
			while (timeToConsume > 0.0f)
			{
				float timeStep = 5.0f + float(fastrandom.GetRandomInteger(0, 2));

				if (timeToConsume > timeStep)
				{
					ship2.Animate(timeStep, gameData->playfield);
					timeToConsume -= timeStep;
				}
				else
				{
					ship2.Animate(timeToConsume, gameData->playfield);
					timeToConsume = 0;
				}
			}

			Vector3d position1 = ship1.position;
			Vector3d position2 = ship2.position;

			Vector3d velocity1 = ship1.velocity;
			Vector3d velocity2 = ship2.velocity;

			// test that two ships moving on their own, then one updated by ther other, end up in same place after X time
			// ship3 aniamted, then updated by ship4.  ship4 continues throughout its full animation, ship3 animates to the same amount of time in steps.
			// At end, both positions and velocities should be identical
			AsteroidsShip ship3;
			AsteroidsShip ship4;
			ship3.Initialize(false, false);
			ship4.Initialize(false, false);

			ship3.backwards = true;
			ship3.spinDirection = -1;
			ship3.boost = true;
			ship3.Animate(123.0f, gameData->playfield);

			ship4.thrust = true;
			ship4.spinDirection = 1;
			ship4.boost = true;
			ship4.Animate(245.0f, gameData->playfield);

			AsteroidsNetworkUpdateShipFromClientPacket packet;
			AsteroidsNetworkPacketHelper::PopulateUpdateShipFromClientPacket(packet, ship4.Id, ship4.spinDirection, ship4.thrust, ship4.backwards, ship4.left, ship4.right, ship4.boost,
				ship4.position, ship4.velocity, ship4.rotationAngle, ship4.boostFuel, ship4.cloakMS, 0, 0);
			gameData->UpdateShipFromClient(&ship3, packet.spinDirection, packet.controls, packet.position, packet.velocity, packet.rotationAngle, packet.boostFuel, packet.cloakMS, packet.gameTimeVersion);

			float testTimeMS = 885.0f;
			float testStep = 16.0f;
			ship4.Animate(885.0f, gameData->playfield);
			while (testTimeMS > 0)
			{
				if (testTimeMS > testStep)
				{
					ship3.Animate(testStep, gameData->playfield);
					testTimeMS -= testStep;
				}
				else
				{
					ship3.Animate(testTimeMS, gameData->playfield);
					testTimeMS = 0;
				}
			}

			Vector3d position3 = ship3.position;
			Vector3d position4 = ship4.position;

			Vector3d velocity3 = ship3.velocity;
			Vector3d velocity4 = ship4.velocity;
		}

		void ViewportSizeChanged(GameViewport ^p_viewport) override
		{
			// force a redo on the stars when they are rendered
			if (gameData != nullptr)
			{
				gameData->ClearStars();
			}
		}

		void DestroyGameData()
		{
			if (gameData != nullptr)
			{
				delete gameData;
				gameData = nullptr;
			}
			if (asteroidsUI != nullptr)
			{
				delete asteroidsUI;
				asteroidsUI = nullptr;
			}
			if (networkMenu != nullptr)
			{
				delete networkMenu;
				networkMenu = nullptr;
			}
			if (mainMenu != nullptr)
			{
				delete mainMenu;
				mainMenu = nullptr;
			}
			if (networkedMenu != nullptr)
			{
				delete networkedMenu;
				networkedMenu = nullptr;
			}
			if (connectDlg != nullptr)
			{
				delete connectDlg;
				connectDlg = nullptr;
			}
			if (chatDlg != nullptr)
			{
				delete chatDlg;
				chatDlg = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (steadyTimer != nullptr)
			{
				delete steadyTimer;
				steadyTimer = nullptr;
			}
			if (asteroidsNetwork != nullptr)
			{
				delete asteroidsNetwork;
				asteroidsNetwork = nullptr;
			}
		}

		String ^ ApplicationName() override
		{
			return "Multiplayer Asteroids";
		}

		bool DoGameLoop() override
		{
			bool uiActive = (asteroidsUI->GetTopForm() != nullptr);

			if (uiActive == true)
				keyboardKeys.ClearClicked(); // prevent keys from affecting game (events are still good and will be consumed by the UI)

			// route controls to UI
			// if controls call for closing the last form, uiActive will be re-evaluated again
			// UI style: hit escape to bring up menu.  Click something to make the form close or hit Escape to close the menu and continue with game
			LinkedListEnumerator<GameInputEvent> inputEnumerator = inputEvents->GetEnumerator();
			while (inputEnumerator.MoveNext())
			{
				switch (inputEnumerator.Current()->data.type)
				{
				case GameInputEventType::MouseDown:
				case GameInputEventType::MouseUp:
				case GameInputEventType::MouseMove:
					// route mouse events so that ui can track mouse state even with no forms open, so that mouse is detected as up after something is clicked and form closes and ui deactivates
					asteroidsUI->ApplyInputEvent(inputEnumerator.Current()->data);
					break;
				case GameInputEventType::MouseWheel:
				case GameInputEventType::KeyDown:
				case GameInputEventType::KeyUp:
				//case GameInputEventType::KeyPress:
					if (uiActive == true)
						asteroidsUI->ApplyInputEvent(inputEnumerator.Current()->data); // only apply keys on UI when it is active
					break;
				}

				uiActive = (asteroidsUI->GetTopForm() != nullptr);
			}

			if (uiActive == false)
			{
				// all done, end game
				if (gameData->exitGame == true)
				{
					if (mouse.IsVisible() == false)
						mouse.Show();
					return false;
				}

				if (mouse.IsVisible() == true)
					mouse.Hide();

				if (gameData->gameType == AsteroidsGameType::SinglePlayer)
					timer->Unpause();

				if (keyboardKeys.GetKey(27)->IsClicked())
				{
					// up to the ui to give control back to us
					if (gameData->gameType == AsteroidsGameType::SinglePlayer)
						timer->Pause();

					// show appropriate form in UI
					if (asteroidsNetwork->IsActive())
						networkedMenu->ShowModal();
					else
						mainMenu->ShowModal();
					mouse.Show();
				}
			}

			// gets stars moving again when single player game is ended, just in case
			if (timer->IsPaused() == true && gameData->gameType != AsteroidsGameType::SinglePlayer)
				timer->Unpause();

			joystick->Poll();
			timer->Poll();
			steadyTimer->Poll();

			if (gameData->gameType != AsteroidsGameType::SinglePlayer)
				slowMotionFactor = 1.0f;
			float elapsedTimeMS = timer->GetElapsedTimeMSFloat() * slowMotionFactor;
			float messageListElapsedTimeMS = steadyTimer->GetElapsedTimeMSFloat();

			// reset spin on player ship, let keys determine its state
			if (gameData->localPlayerShipRef != nullptr)
			{
				if (gameData->localPlayerShipRef->CanBeControlled() == true)
				{
					// if can't be controlled, controls wont' be used below anyway
					gameData->localPlayerShipRef->RecordPriorControls();
				}

				// but still good to cancel all controls so that flames aren't rendered, etc.
				gameData->localPlayerShipRef->CancelControls();
			}

			// handle mouse
			if (uiActive == false)
			{
				if (mouse.leftButton.IsClicked() == true)
				{
					// firing weapon.  do it!
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->shoot = true;
					}
				}
				if (mouse.IsVisible() == false && appActivated == true)
				{
					// move it to the middle of the viewport (should be screen position)
					// just to keep mouse within a form render window - this isn't really necessary in fullscreen
					GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
					mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
				}
			}
			mouse.ZeroOffsets();
			mouse.ClearClicked();

			// handle keyboard
			if (uiActive == false)
			{
				static bool okToShoot = true;

				if (keyboardKeys.GetKey('V')->IsClicked())
				{
					GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->SetVSyncEnabled(
						!(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->VSyncIsEnabled()));

					if (GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->VSyncIsEnabled() == true)
						gameData->messageList->AddMessage("VSync On");
					else
						gameData->messageList->AddMessage("VSync Off");
				}
				if (keyboardKeys.GetKey('A')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Left))->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->spinDirection--;
					}
				}
				if (keyboardKeys.GetKey('D')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Right))->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->spinDirection++;
					}
				}
				if (keyboardKeys.GetKey('W')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Up))->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->thrust = true;
					}
				}
				if (keyboardKeys.GetKey('S')->IsPressed() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Down))->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->backwards = true;
					}
				}
				if (keyboardKeys.GetKey('Q')->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->left = true;
					}
				}
				if (keyboardKeys.GetKey('E')->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->right = true;
					}
				}
				if (keyboardKeys.GetKey(int(System::Windows::Forms::Keys::ShiftKey))->IsPressed())
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->boost = true;
					}
				}
				if (keyboardKeys.GetKey(32)->IsPressed() == false && keyboardKeys.GetKey(int(System::Windows::Forms::Keys::ControlKey))->IsPressed() == false)
				{
					okToShoot = true;
				}
				if (okToShoot == true && (keyboardKeys.GetKey(32)->IsClicked() || keyboardKeys.GetKey(int(System::Windows::Forms::Keys::ControlKey))->IsClicked()))
				{
					if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
					{
						gameData->localPlayerShipRef->shoot = true;
						okToShoot = false;
					}
				}
				if (keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Tab))->IsClicked())
				{
					if (asteroidsNetwork->IsActive())
						showPlayerList = !showPlayerList;
				}
				// resolve control conflicts
				if (gameData->localPlayerShipRef != nullptr && gameData->localPlayerShipRef->CanBeControlled() == true)
				{
					if (gameData->localPlayerShipRef->thrust == true && gameData->localPlayerShipRef->backwards == true)
					{
						// cancel thrust movement
						gameData->localPlayerShipRef->thrust = false;
						gameData->localPlayerShipRef->backwards = false;
					}
					if (gameData->localPlayerShipRef->left == true && gameData->localPlayerShipRef->right == true)
					{
						// cancel thrust movement
						gameData->localPlayerShipRef->left = false;
						gameData->localPlayerShipRef->right = false;
					}
					if (gameData->localPlayerShipRef->thrust == false && gameData->localPlayerShipRef->backwards == false && 
							gameData->localPlayerShipRef->left == false && gameData->localPlayerShipRef->right == false)
						gameData->localPlayerShipRef->boost = false;
				}

				if (keyboardKeys.GetKey(int(System::Windows::Forms::Keys::Oemtilde))->IsClicked() && gameData->gameType == AsteroidsGameType::SinglePlayer)
				{
					if (slowMotionFactor == 1.0f)
						slowMotionFactor = 0.1f;
					else
						slowMotionFactor = 1.0f;
				}

				if ((keyboardKeys.GetKey('C')->IsClicked() || keyboardKeys.GetKey(13)->IsClicked()) && gameData->gameType == AsteroidsGameType::Multiplayer)
				{
					// send a chat message
					chatDlg->ShowModal();
					//gameData->SendChatMessage("Test <b><color=ff0000>chat</color></b> message");
				}
			}
			keyboardKeys.ClearClicked();

			////////////////
			// Animate
			switch (gameData->gameType)
			{
			case AsteroidsGameType::None:
				if (timer->IsPaused() == false)
				{
					gameData->floatingCamera = gameData->floatingCamera + Vector3d(0.3f, -0.15f, 0.0f).ScalarMult(elapsedTimeMS);
					gameData->floatingCamera = gameData->playfield.NormalizePositionWithPlayfield(gameData->floatingCamera);

					gameData->messageList->Animate(messageListElapsedTimeMS);
				}
				break;
			case AsteroidsGameType::SinglePlayer:
				if (timer->IsPaused() == false)
				{
					float timeToConsumeMSf = elapsedTimeMS; // can't be negative in single player
					int timeToConsumeMS = int(timeToConsumeMSf + 0.01f); // to be safe

					if (elapsedTimeMS > 0)
						gameData->floatingCamera = gameData->floatingCamera + Vector3d(0.3f, -0.15f, 0.0f).ScalarMult(elapsedTimeMS);
					gameData->floatingCamera = gameData->playfield.NormalizePositionWithPlayfield(gameData->floatingCamera);

					// note: when slow motion is in effect, gameTimeMS is NOT accurate, sine slowMotion factor is applied to elapsedTime after it is retrieved, not within timer 
					//   - doesn't matter for single player game
					int gameTimeMS = timer->GetGameTimeMS() - int(elapsedTimeMS); // and if slowmotion, this will be badly off anyway because we are now truncating decimals

					float timeStepMSf = 10.0f;
					int timeStepMS = 10;
					// note: don't need to worry about elapsedTimeMS being negative in single player, just here to be consistent
					bool animated = false;
					while (timeToConsumeMSf > 0) // automatically avoids any animation until elapsedTimeMS > 0 (adjusting timer->GameTimeMS from server can cause even cause this to be negative)
					{
						animated = true;
						if (timeToConsumeMSf > timeStepMSf)
						{
							gameTimeMS += timeStepMS;
							gameData->Animate(timeStepMSf, gameTimeMS); // and check collisions
							timeToConsumeMSf -= timeStepMSf;
							timeToConsumeMS -= timeStepMS;
						}
						else
						{
							gameTimeMS += timeToConsumeMS;
							gameData->Animate(timeToConsumeMSf, gameTimeMS); // and check collisions
							timeToConsumeMSf = 0.0f;
						}

						// remove expired bullets that didn't collide with anything
						gameData->RemoveExpiredBullets();
					}
					if (animated == true)
					{
						if (gameTimeMS != timer->GetGameTimeMS())
							throw gcnew Exception("gameTimeMS didn't advance properly!");

						// track gametimeMS of gamestate so that new objects from server can be caught up to current gamestate properly in the event that GameTimeMS() is adjusted from server before
						//   objects are received and before Poll() can be called here to catch the time up to positive again
						// vital that Process() only be called AFTER this, AFTER Animate() is finished, for the current method of how all obejcts now have the same gameTimeMS for their state
						gameData->gameStateGameTimeMS = timer->GetGameTimeMS();
					}

					gameData->messageList->Animate(messageListElapsedTimeMS);
				}
				break;
			case AsteroidsGameType::Multiplayer: // until this needs a more specific section
				asteroidsNetwork->AllocateBandwidth();
				float timeToConsumeMSf = elapsedTimeMS; // negative time is possible if AdjustGameTimeMS() was called in Process().  If so, wait until elaspedTimeMS > 0
				int timeToConsumeMS = int(timeToConsumeMSf + 0.01f); // to be safe

				if (elapsedTimeMS > 0 && asteroidsNetwork->IsClient() == false)
					gameData->floatingCamera = gameData->floatingCamera + Vector3d(0.3f, -0.15f, 0.0f).ScalarMult(elapsedTimeMS);
				gameData->floatingCamera = gameData->playfield.NormalizePositionWithPlayfield(gameData->floatingCamera);

				int gameTimeMS = timer->GetGameTimeMS() - int(elapsedTimeMS); // and if slowmotion, this will be badly off anyway because we are now truncating decimals

				// send local ship updates to server prior to animation to reduce possibility of future gametime requiring holding of data
				if (gameData->localPlayerShipRef != nullptr)
				{
					gameData->localPlayerShipRef->timeSinceSentToPlayersMS += int(elapsedTimeMS);
					if (gameData->localPlayerShipRef->CanBeControlled())
					{
						if (gameData->localPlayerShipRef->ControlsChanged())
						{
							// send to server
							if (asteroidsNetwork->IsClient())
								gameData->SendUpdateShipToServerUDP(gameData->localPlayerShipRef, gameTimeMS); // controls and fuel and timers accurate to gameTimeMS variable (beginning of tick)
							else
								gameData->SendUpdateShipToClientsUDP(gameData->localPlayerShipRef, gameTimeMS); // controls and fuel and timers accurate to gameTimeMS variable (beginning of tick)
						}
						if (gameData->localPlayerShipRef->timeSinceSentToPlayersMS >= 250)
						{
							// send to server
							if (asteroidsNetwork->IsClient())
								gameData->SendUpdateShipToServer(gameData->localPlayerShipRef, gameTimeMS); // controls and fuel and timers accurate to gameTimeMS variable (beginning of tick)
							else
								gameData->SendUpdateShipToClients(gameData->localPlayerShipRef, gameTimeMS); // controls and fuel and timers accurate to gameTimeMS variable (beginning of tick)

							gameData->localPlayerShipRef->timeSinceSentToPlayersMS = 0;
						}
					}
				}

				float timeStepMSf = 10.0f;
				int timeStepMS = 10;
				bool animated = false;
				while (timeToConsumeMSf > 0) // automatically avoids any animation until elapsedTimeMS > 0 (adjusting timer->GameTimeMS from server can even cause this to be negative)
				{
					animated = true;
					if (timeToConsumeMSf > timeStepMSf)
					{
						gameTimeMS += timeStepMS;
						gameData->Animate(timeStepMSf, gameTimeMS); // and check collisions
						timeToConsumeMSf -= timeStepMSf;
						timeToConsumeMS -= timeStepMS;
					}
					else
					{
						gameTimeMS += timeToConsumeMS;
						gameData->Animate(timeToConsumeMSf, gameTimeMS); // and check collisions
						timeToConsumeMSf = 0.0f;
					}

					// remove expired bullets that didn't collide with anything
					gameData->RemoveExpiredBullets();
				}
				if (animated == true)
				{
					if (timer->GetGameTimeMS() != gameTimeMS)
						throw gcnew Exception("game time out of sync with timer!");

					// record gameTimeMS of gamestate so that server objects sent in network->Process() can be properly caught up to the game state using this time (ping adjustments will
					//   alter timer->GameTimeMS() and throw it out of sync until the next Poll() above where elaspedTimeMS > 0 and Animate is called)
					// vital that Process() only be called AFTER this, AFTER Animate() is finished, for the current method of how all obejcts now have the same gameTimeMS for their state
					gameData->gameStateGameTimeMS = timer->GetGameTimeMS();
				}

				gameData->messageList->Animate(messageListElapsedTimeMS);

				// gamestate object updates from server are received here, along with possible game time adjustments from pings, so gamestate from Animate must be caught up to the current GameTimeMS() and its value recorded there
				// always call this AFTER getting elapsedTimeMS, after Animating and after setting gamestate's gameTime so that sent objects are properly caught up to gamestate if inside Process()
				//   an adjustment to the timer's GameTimeMS occurs (it's not longer good to catch objects up with in this tick because it doesn't match the game state anymore until elapsedTimeMS > 0
				//   and Animate() on a future tick)
				break;
			}

			// could be in a connected game, or just waiting for connection to occur on non-blocking socket.  Must call this regardless of game type so that connection can be detected as successful
			asteroidsNetwork->Process();

			return true;
		}

		void PerformRender() override
		{
			DoAsteroidsRender();

			// don't reset if it's negative, let it catch up!
			if (timer->GetElapsedTimeMS() >= 0)
				timer->ResetElapsedTime();

			steadyTimer->ResetElapsedTime();
		}

		void BlockRender() override
		{
			DoAsteroidsRender();
		}

		void DoAsteroidsRender()
		{
			GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");

			// minimized?  Prevents errors
			if (viewport->GetWidth() == 0)
				return;

			GraphicsBase *graphics = viewport->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 0, 0));

			graphics->Set2dWindowProjection();

			// painter's algorithm, bottom to top
			graphics->SetDepthTestEnabled(false);
			graphics->SetDepthWriteEnabled(false);

			// Do NOT do this on an Ortho projection!
			//graphics->DefaultTransform();

			////////////////
			// render it!

			// Get center of render field (point behind the moving ship at center, or floating camera)
			// renderFocusShipRef handles the game states (spectating, controlling a ship, otherwise use floating camera)
			Vector3d center;
			if (gameData->renderFocusShipRef != nullptr)
			{
				// put center behind moving ship, 150ms back
				center = gameData->camera.GetCameraCenter(gameData->renderFocusShipRef->position, timer->GetElapsedTimeMSFloat() * slowMotionFactor, gameData->playfield);

				//float velocityMagnitude = gameData->renderFocusShipRef->velocity.Magnitude();
				//Vector3d velocity = gameData->renderFocusShipRef->velocity;
				//Vector3d newCenter;
				//if (velocity.Magnitude() > 0.0001f)
				//{
				//	velocity.Normalize();
				//	newCenter = gameData->renderFocusShipRef->position - velocity.ScalarMult(pow(velocityMagnitude, 1.5f) * 120.0f);
				//}
				//else
				//	newCenter = gameData->renderFocusShipRef->position; // not enough velocity to matter
				//newCenter = gameData->playfield.NormalizePositionWithPlayfield(newCenter);
				gameData->ApplyNewRenderCenter(center);
				//center = newCenter; // already normalized by animate, but no matter
			}
			else
			{
				center = gameData->floatingCamera;
				gameData->ApplyNewRenderCenter(center);
			}

			gameData->RenderStarfield(graphics);
			gameData->RenderAsteroids(graphics, viewport, center);
			gameData->RenderBullets(graphics, viewport, center);
			gameData->RenderShips(graphics, viewport, center);
			gameData->RenderExplosions(graphics, viewport, center);
			gameData->RenderPowerups(graphics, viewport, center);

			float messageListBottomLimit; // bottom limit shifts when health bar is rendered
			gameData->RenderHealthBar(graphics, viewport, messageListBottomLimit);
			gameData->RenderRadar(graphics, viewport, center);
			gameData->RenderShipHealthBars(graphics, viewport, center);

			// render messages
			float messageListMargin = 200.0f * gameData->GetRenderScale();
			// set fonts depending on size of viewport
			int backgroundOffset = 0;
			if (viewport->GetHeight() < 650)
			{
				gameData->messageList->SetFonts(GameContext::Instance->FontRegistry.GetFont("Messages500"), GameContext::Instance->FontRegistry.GetFont("MessagesBold500"));
				backgroundOffset = 1;
			}
			else if (viewport->GetHeight() > 850)
			{
				gameData->messageList->SetFonts(GameContext::Instance->FontRegistry.GetFont("Messages1080"), GameContext::Instance->FontRegistry.GetFont("MessagesBold1080"));
				backgroundOffset = 2;
			}
			else
			{
				gameData->messageList->SetFonts(GameContext::Instance->FontRegistry.GetFont("Messages720"), GameContext::Instance->FontRegistry.GetFont("MessagesBold720"));
				backgroundOffset = 2;
			}
			gameData->messageList->Render(graphics, RectangleF(float(viewport->GetWidth() / 4.0f), 0.0f, float(viewport->GetWidth() / 2.0f), messageListBottomLimit - messageListMargin), backgroundOffset, chatDlg->IsClosed() == false);

			//graphics->RenderFont("A test", GameContext::Instance->FontRegistry.GetFont("Info"), 20, 20, GameColor(255, 255, 255));

			if (asteroidsNetwork->IsActive() && showPlayerList == true)
			{
				// render players

				// show names
				float x = float(viewport->GetWidth() - 350);
				float y = float(viewport->GetHeight() / 2);
				GameFont ^font = GameContext::Instance->FontRegistry.GetFont("MessagesBold500");
				int textHeight = font->GetHeight(); // assuming this is the greatest height - if not, use the height from the other font
				int widestTextWidth = 0;
				LinkedListEnumerator<GameNetworkPlayerNode> playerEnum = asteroidsNetwork->GetPlayerEnumerator();
				while (playerEnum.MoveNext())
				{
					AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)playerEnum.Current()->data.player;
					GameColor renderColor = player->color;
					String ^message = player->GetName();
					
					Point textSize = font->GetTextSize(player->GetName() + " ");
					if (textSize.X > widestTextWidth)
						widestTextWidth = textSize.X;

					graphics->RenderFont(message, font, x, y, renderColor);

					y += font->GetHeight();
				}

				// show ping and data rate
				x += float(widestTextWidth);
				y = float(viewport->GetHeight() / 2);
				font = GameContext::Instance->FontRegistry.GetFont("Messages500");
				playerEnum = asteroidsNetwork->GetPlayerEnumerator();
				while (playerEnum.MoveNext())
				{
					AsteroidsNetworkPlayer *player = (AsteroidsNetworkPlayer *)playerEnum.Current()->data.player;
					GameColor renderColor = player->color;
					String ^message = "";
					if (asteroidsNetwork->IsServer())
					{
						if (player->host == true)
							message = message + " (" + Convert::ToString(int(asteroidsNetwork->GetSustainedUploadDataRate() / 1024.0f * 8.0f)) + "Kb/sec)";
						if (player->host != true)
						{
							if (player->ping >= 0)
								message = message + " " + Convert::ToString(player->ping) + "ms";
							if (player->pingUDP >= 0)
								message = message + " UDP:" + Convert::ToString(player->pingUDP) + "ms";
							message = message + " (" + Convert::ToString(int(asteroidsNetwork->GetClientByClientId(player->id)->GetSustainedUploadDataRate() / 1024.0f * 8.0f)) + "Kb/sec)";
						}
					}
					else if (asteroidsNetwork->IsClient())
					{
						if (player->host == true)
						{
							if (player->ping >= 0)
								message = message + " " + Convert::ToString(player->ping) + "ms";
							if (player->pingUDP >= 0)
								message = message + " UDP:" + Convert::ToString(player->pingUDP) + "ms";
							message = message + " (" + Convert::ToString(int(asteroidsNetwork->GetSustainedDownloadDataRate() / 1024.0f * 8.0f)) + "Kb/sec)";
						}
					}

					graphics->RenderFont(message, font, x, y, renderColor);

					y += font->GetHeight();
				}

				// render a clock to check game time calibration
				float scale = gameData->GetRenderScale();
				float radius = 1080.f / 12.0f * scale;

				ModelVertex handVertices[2];
				handVertices[0].colorIndex = 0;
				handVertices[1].colorIndex = 0;
				handVertices[0].vertex.Set(radius, radius, 0);

				// hour hand
				float dayDecimals = float((timer->GetGameTimeMS() / 1000) % 86400) / 86400.0f; // makes hour hand move slightly with second hand
				float dayAngle = 720.0f * dayDecimals; // two trips around for a day
				GameColor dayColor(255, 32, 32);
				float radians = MathUtilities::DegreesToRadians(dayAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 0.6f * sin(radians), -radius * 0.6f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &dayColor, 1, handVertices, 2);

				// minute hand
				float hourDecimals = float((timer->GetGameTimeMS() / 1000) % 3600) / 3600.0f; // makes minute hand move slightly with second hand
				float hourAngle = 360.0f * hourDecimals;
				GameColor hourColor(255, 128, 32);
				radians = MathUtilities::DegreesToRadians(hourAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 0.7f * sin(radians), -radius * 0.7f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &hourColor, 1, handVertices, 2);

				// second hand
				float minuteDecimals = float((timer->GetGameTimeMS() / 1000) % 60) / 60.0f;
				float minuteAngle = 360.0f * minuteDecimals;
				GameColor minuteColor(255, 255, 32);
				radians = MathUtilities::DegreesToRadians(minuteAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 0.85f * sin(radians), -radius * 0.85f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &minuteColor, 1, handVertices, 2);

				// ms hand
				float secondDecimals = float(timer->GetGameTimeMS() % 1000) / 1000.0f;
				float secondAngle = 360.0f * secondDecimals;
				GameColor secondColor(255, 255, 255);
				radians = MathUtilities::DegreesToRadians(secondAngle);
				handVertices[1].vertex = handVertices[0].vertex + Vector3d(radius * 1.0f * sin(radians), -radius * 1.0f * cos(radians), 0.0f);
				graphics->RenderLineStrip(2.0f, &secondColor, 1, handVertices, 2);

				// time underneath
				GameColor clockColor(255, 255, 255);
				font = GameContext::Instance->FontRegistry.GetFont("MessagesBold500");
				String ^message = String::Format("{0}:{1}:{2}.{3}", int(dayDecimals*24.0f + 0.01f).ToString("D2"), int(hourDecimals*60.0f + 0.01f).ToString("D2"), int(minuteDecimals*60.0f + 0.01f).ToString("D2"), int(secondDecimals*1000.0f + 0.01f).ToString("D3"));
				int textSizeX = font->GetTextSize(message).X;
				x = radius - float(textSizeX) / 2.0f;
				y = radius * 2.0f + 5.0f;
				graphics->RenderFont(message, font, x, y, clockColor);
			}

			asteroidsUI->Render(graphics, true);
			if (asteroidsUI->GetTopForm() != nullptr)
			{
				// ui is up, render version
				GameFont ^font = GameContext::Instance->FontRegistry.GetFont("Info");
				String ^message = "Multiplayer Asteroids Version: " + ASTEROIDS_VERSIONSTRING;
				Point textSize = font->GetTextSize(message);
				int x = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() - textSize.X;
				int y = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - textSize.Y;
				graphics->RenderFont(message, font, float(x), float(y), GameColor(255, 255, 255));
			}

			// done rendering
			/////////////////

			graphics->SwapBuffers();
		}

	};
}

