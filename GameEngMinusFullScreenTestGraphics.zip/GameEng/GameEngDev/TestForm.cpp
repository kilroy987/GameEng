#include "TestForm.h"

using namespace System;
using namespace System::Windows::Forms;

ref class App
{
public:
	static void OnUnhandled(Object^ sender, System::Threading::ThreadExceptionEventArgs^ e)
	{
		System::IO::File::AppendAllText("error.txt", "EXCEPTION occurred at " + DateTime::Now.ToString("yyyy/MM/dd HH:mm:ss") + "\r\n" + e->Exception->ToString() + "\r\nLog:\r\n");
		for each (System::String ^log in GameEng::Game::GameContext::Instance->Log)
			System::IO::File::AppendAllText("error.txt", log + "\r\n");
		System::IO::File::AppendAllText("error.txt", "\r\n");

		MessageBox::Show(e->Exception->ToString(), "Global Exception");
		Application::ExitThread();
	}
};

[STAThread] // single thread apartment model
void Main(array<String^>^ args)
{
	Application::ThreadException += gcnew
		System::Threading::ThreadExceptionEventHandler(App::OnUnhandled);

	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	GameEngDev::TestForm form;
	Application::Run(%form);
}