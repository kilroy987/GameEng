#include "TestNetwork.h"

using namespace GameEngDev;
using namespace GameEng::Network;
using namespace GameEng::Storage;

LinkedList<MessageString> LinkedList<MessageString>::DeletedList("Deleted list for MessageString");
