#include "TestFPS.h"

using namespace GameEngDev;
using namespace GameEng::Storage;

LinkedList<FPSGameMessage> LinkedList<FPSGameMessage>::DeletedList("Deleted List for FPSGameMessage");
LinkedList<FPSGameRenderMessage> LinkedList<FPSGameRenderMessage>::DeletedList("Deleted List for FPSGameRenderMessage");

LinkedList<TestFPSAvatar> LinkedList<TestFPSAvatar>::DeletedList("Deleted List for TestFPSAvatar");