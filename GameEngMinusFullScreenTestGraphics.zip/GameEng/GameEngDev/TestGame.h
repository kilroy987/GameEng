#pragma once

#include "..\Headers\GameBase.h"
#include "..\Headers\LinkedListTemplate.h"
#include "..\Headers\GameObjectBase.h"
#include "..\Headers\Vector.h"
#include "..\Headers\Orient.h"
#include "..\Headers\GameApplicationContext.h"
#include "..\Headers\GameContext.h"
#include "..\Headers\Orient.h"
#include "..\Headers\Model.h"
#include "..\Headers\JointedModel.h"
#include "..\Headers\TerrainMesh.h"
#include "..\Headers\Skybox.h"
#include "..\Headers\MathConstants.h"
#include "..\Headers\GameWidgets.h"
#include "..\Headers\Collider.h"
#include "..\Headers\Frustum.h"
#include "..\Headers\PortalEngine.h"
#include "..\Headers\GraphicsUtilities.h"
#include "..\Headers\GameUI.h"

// GLShader only
#include <gl\gl.h>
#include <gl\glu.h>
// from user SDK directory - access to constants and method pointer types for OpenGL 1.2 and up
#include <gl\glext.h>
#include <gl\wglext.h> // wglARB routine (core version for shader)

namespace GameEngDev {
	using namespace GameEng::Game;
	using namespace GameEng::GameObject;
	using namespace GameEng::Storage;
	using namespace GameEng::Math;
	using namespace GameEng::Tools::Timer;
	using namespace GameEng::Widgets;
	using namespace GameEng::Collider;
	using namespace GameEng::PortalEngine;
	using namespace GameEng::UI;
	using namespace System::Diagnostics;

	public ref class TestListItem
	{
	public:
		String ^text;

		TestListItem(String ^p_itemText)
		{
			text = p_itemText;
		}
		String ^ ToString() override
		{
			return text;
		}
	};

	public class TestGameObject : public GameObjectBase
	{

	};

	/*
	public ref class TestStub : public GameBase
	{
	public:

		Orient3d *cubeOrient;
		Model3d *cube;
		Orient3d *cameraOrient;

		TestStub(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cubeOrient = nullptr;
			cube = nullptr;
			cameraOrient = nullptr;
		}

		virtual ~TestStub()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			cubeOrient = new Orient3d();
			cubeOrient->LoadIdentity();
			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);
			// move the jet forward and over
			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(7.0f) + cubeOrient->l.ScalarMult(2.5f) + cubeOrient->u.ScalarMult(2.0f);

			cubeOrient->Rotate(cubeOrient->u, 180.0f);

			cube = new Model3d();
			cube->MakeCube();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				cubeOrient->Rotate(cubeOrient->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = cubeOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(*cubeOrient);
			// render the cube
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	*/
	public ref class TestGame : public GameBase
	{
		LinkedList<TestGameObject> *linkedList; // also part of System::Collections

	public:
		TestGame(HWND p_hWnd) : GameBase(p_hWnd)
		{
		}

		~TestGame() override
		{
			Destroy();
		}

		void Initialize() override;

		void InitializeTests();
		void PerformTests();
		void TestColor();
		void TestLinkedList();
		void TestVectors();
		void TestOrients();
		void TestAlgebra();
		void TestMatrix();
		void TestFrustum();
		void TestModelSurface();
		void TestHexConversion();

		void Destroy() override
		{
			DestroyTests();

			// todo: get rid of anything app specific in GameInstance for this game

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}

		void DestroyTests()
		{
			if (linkedList != nullptr)
			{
				delete linkedList;
				linkedList = nullptr;
			}
		}

		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			InitializeTests();
			PerformTests();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			int major, minor, release;
			System::String ^version = graphics->GetAPIVersion(major, minor, release);

			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();
			graphics->Translate(0, 0, 100.0f);
			graphics->RenderTestTriangle();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}
	};

	public ref class TestTexture : public GameBase
	{
		LinkedList<TestGameObject> *linkedList; // also part of System::Collections

	public:
		TestTexture(HWND p_hWnd) : GameBase(p_hWnd)
		{
		}

		~TestTexture() override
		{
			Destroy();
		}

		void Initialize() override
		{
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));
			GameFileResource ^fileResource = nullptr;
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("DeathStarTransp-SWE_512_512.png"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar1", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar3", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar4", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar5", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Green, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar6", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Blue, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar7", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Alpha, fileResource);
		}

		void Destroy() override
		{
			// todo: get rid of anything app specific in GameInstance for this game

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();
			graphics->Translate(0, 0, 100.0f);

			GameColor colors[1] = { GameColor(255, 255, 255) };
			ModelVertex vertices[4] = { ModelVertex(Vector3d(10.0f, 10.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, 10.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, -10.0f, 0.0f), 0), ModelVertex(Vector3d(10.0f, -10.0f, 0.0f), 0) };
			graphics->Translate(37.0f, 12.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar2"));
			graphics->Translate(-25.0f, 0.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar3"));
			graphics->Translate(-25.0f, 0.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar1"));
			graphics->Translate(50.0f, -25.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar4"));
			graphics->Translate(-25.0f, 0.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar5"));
			graphics->Translate(-25.0f, 0.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar6"));
			graphics->Translate(-25.0f, 0.0f, 0.0f);
			graphics->RenderFilledQuad(colors, 1, vertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("DeathStar7"));

			graphics->FinishRender();
			graphics->SwapBuffers();
		}
	};

	public ref class AlphaClipPlane : public GameBase
	{
		LinkedList<TestGameObject> *linkedList; // also part of System::Collections

	public:
		AlphaClipPlane(HWND p_hWnd) : GameBase(p_hWnd)
		{
		}

		~AlphaClipPlane() override
		{
			Destroy();
		}

		void Initialize() override
		{
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));
			GameFileResource ^fileResource = nullptr;
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("DeathStarTransp-SWE_512_512.png"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar1", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
		}

		void Destroy() override
		{
			// todo: get rid of anything app specific in GameInstance for this game

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);


			Orient3d camera;
			camera.LoadIdentity();
			camera.Rotate(camera.u, 45.0f);
			camera.Rotate(camera.l, -45.0f);
			camera.p = camera.p - camera.f.ScalarMult(100.0f);
			camera.p = camera.p - camera.l.ScalarMult(37.0f); // start left
			camera.p = camera.p - camera.u.ScalarMult(12.0f); // start up a little

			Orient3d orient1;
			orient1.LoadIdentity();
			Orient3d orient2;
			orient2.LoadIdentity();
			orient2.Rotate(orient2.u, 90.0f);
			Orient3d orient3;
			orient3.LoadIdentity();
			orient3.Rotate(orient3.u, 45.0f);
			orient3.p = orient3.p + orient3.f.ScalarMult(2.5);

			GameColor colorsWhite[1] = { GameColor(255, 255, 255, 128) };
			GameColor colorsBlue[1] = { GameColor(0, 0, 255, 64) };
			GameColor colorsGreen[1] = { GameColor(0, 255, 0, 64) };
			GameColor colorsRed[1] = { GameColor(255, 0, 0, 64) };
			// A quad facing backwards, so use orients that face away from the viewpoint
			ModelVertex vertices[4] = { ModelVertex(Vector3d(10.0f, 10.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, 10.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, -10.0f, 0.0f), 0), ModelVertex(Vector3d(10.0f, -10.0f, 0.0f), 0) };

			GameTexture ^texture = GameContext::Instance->TextureRegistry.GetTexture("TestTexture");
			//GameTexture ^texture = GameContext::Instance->TextureRegistry.GetTexture("DeathStar1");

			// no attempt to blend alphas
			graphics->DefaultTransform();
			graphics->ReverseTransform(camera);
			graphics->PushMatrix();
			graphics->Transform(orient1);
			graphics->RenderFilledQuad(colorsWhite, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			graphics->PushMatrix();
			graphics->Transform(orient2);
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			graphics->PopMatrix();

			// no depth writing
			graphics->DefaultTransform();
			camera.p = camera.p + camera.l.ScalarMult(25.0f);
			graphics->SetDepthWriteEnabled(false);
			graphics->ReverseTransform(camera);
			graphics->PushMatrix();
			graphics->Transform(orient1);
			graphics->RenderFilledQuad(colorsWhite, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			graphics->PushMatrix();
			graphics->Transform(orient2);
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			graphics->SetDepthWriteEnabled(true);

			// using clip plane to properly blend them
			graphics->SetDepthWriteEnabled(false);

			graphics->DefaultTransform();
			camera.p = camera.p + camera.l.ScalarMult(25.0f);
			graphics->ReverseTransform(camera);
			// 1 - draw what is behind the partitioning alpha
			// set clip plane behind orient1 - AFTER reversetransforming camera BEFORE transforming to object to render
			graphics->SetClipPlane(0, orient1.p, orient1.f);
			graphics->PushMatrix();
			graphics->Transform(orient2);
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			// disable clip plane
			// 2 - draw the partitioning alpha
			graphics->PopMatrix();
			graphics->DisableClipPlane(0);
			graphics->PushMatrix();
			graphics->Transform(orient1);
			graphics->RenderFilledQuad(colorsWhite, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// 3 - draw the same objects in front of the partitioning alpha
			// set clip plane in front of orient1 - AFTER reversetransforming camera BEFORE transforming to object to render
			graphics->SetClipPlane(0, orient1.p, orient1.f.ScalarMult(-1.0f));
			graphics->PushMatrix();
			graphics->Transform(orient2);
			// disable clip plane
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			graphics->DisableClipPlane(0);

			graphics->DefaultTransform();
			camera.p = camera.p + camera.u.ScalarMult(25.0f);
			graphics->ReverseTransform(camera);
			// 1 - draw what is behind the partitioning alpha
			// set clip plane behind orient1 - AFTER reversetransforming camera BEFORE transforming to object to render
			graphics->SetClipPlane(0, orient2.p, orient2.f);
			graphics->PushMatrix();
			graphics->Transform(orient1);
			graphics->RenderFilledQuad(colorsWhite, 1, vertices, 4, true, texture);
			// disable clip plane
			// 2 - draw the partitioning alpha
			graphics->PopMatrix();
			graphics->DisableClipPlane(0);
			graphics->PushMatrix();
			graphics->Transform(orient2);
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// 3 - draw the same objects in front of the partitioning alpha
			// set clip plane in front of orient1 - AFTER reversetransforming camera BEFORE transforming to object to render
			graphics->SetClipPlane(0, orient2.p, orient2.f.ScalarMult(-1.0f));
			graphics->PushMatrix();
			graphics->Transform(orient1);
			// disable clip plane
			graphics->RenderFilledQuad(colorsWhite, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			graphics->DisableClipPlane(0);

			// the behind/partition/front logic works for multiple levels as well - think 3 quads intersecting:
			// note: partition and object #s are the same quad plane
			// object 1 is the main partition, object 2 is the sub partition, object 3 is a standalone (what's left)
			// set behind clip of partition 1
			// set behind clip of partition 2
			// draw object 3
			// disable clip 2
			// draw object 2
			// set front clip of partition 2
			// draw object 3
			// disable clip 2
			// disable clip 1
			// draw object 1
			// set front clip of partition 1
			// set behind clip of partition 2
			// draw object 3
			// disable clip 2
			// draw object 2
			// set front clip of partition 2
			// draw object 3
			// disable clip 2
			// disable clip 1
			graphics->DefaultTransform();
			camera.p = camera.p - camera.l.ScalarMult(25.0f);
			graphics->ReverseTransform(camera);
			// set behind clip of partition 1
			graphics->SetClipPlane(0, orient1.p, orient1.f);
			// set behind clip of partition 2
			graphics->SetClipPlane(1, orient2.p, orient2.f);
			// draw object 3
			graphics->PushMatrix();
			graphics->Transform(orient3);
			graphics->RenderFilledQuad(colorsRed, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// disable clip 2
			graphics->DisableClipPlane(1);
			// draw object 2
			graphics->PushMatrix();
			graphics->Transform(orient2);
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// set front clip of partition 2
			graphics->SetClipPlane(1, orient2.p, orient2.f.ScalarMult(-1.0f));
			// draw object 3
			graphics->PushMatrix();
			graphics->Transform(orient3);
			graphics->RenderFilledQuad(colorsRed, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// disable clip 2
			graphics->DisableClipPlane(1);
			// disable clip 1
			graphics->DisableClipPlane(0);
			// draw object 1
			graphics->PushMatrix();
			graphics->Transform(orient1);
			graphics->RenderFilledQuad(colorsWhite, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// set front clip of partition 1
			graphics->SetClipPlane(0, orient1.p, orient1.f.ScalarMult(-1.0f));
			// set behind clip of partition 2
			graphics->SetClipPlane(1, orient2.p, orient2.f);
			// draw object 3
			graphics->PushMatrix();
			graphics->Transform(orient3);
			graphics->RenderFilledQuad(colorsRed, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// disable clip 2
			graphics->DisableClipPlane(1);
			// draw object 2
			graphics->PushMatrix();
			graphics->Transform(orient2);
			graphics->RenderFilledQuad(colorsBlue, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// set front clip of partition 2
			graphics->SetClipPlane(1, orient2.p, orient2.f.ScalarMult(-1.0f));
			// draw object 3 (this part isn't necessary for this case since all rendering is done, but it's a generic pattern and it works)
			graphics->PushMatrix();
			graphics->Transform(orient3);
			graphics->RenderFilledQuad(colorsRed, 1, vertices, 4, true, texture);
			graphics->PopMatrix();
			// disable clip 2
			graphics->DisableClipPlane(1);
			// disable clip 1
			graphics->DisableClipPlane(0);
			// note: the same can be accomplished with spliced polygons with converted texture coordinates rendered in the proper order without clip planes.  
			//  It depends on how expensive the redundant calls to re-render unneeded polygons are.

			graphics->SetDepthWriteEnabled(true);

			graphics->FinishRender();
			graphics->SwapBuffers();

		}
	};

	// When rendering a trapezoidal polygon or rendering a trapezoidal portion of a texture, adjustments must be made so that interpolation while texture rendering doesn't split it into
	//   visible triangles.
	// To combat this, take the trapezoid segment length of the polygon divided by the texture trapezoid shape texture usage and use that as the q for the texture coordinate.  Also,
	//   multiply this q by the s and t that you use for the texture.
	// This causes a perspective effect on the texture, but it also avoids the visible triangle separation.
	// I have not yet solved the correction without having a perspective effect.

	// Lessons:
	// Assuming perspective textures are fine on a trapezoid:
	// When rendering a trapezoidal polygon, and a trapezoidal texture on the same non-equal segments, 
	//    use q = long side polygon length / long side texture usage length for the vertices on the long side, and
	//    use q = short side polygon length / short side texture usage length for the vertices on the short side.
	// note: these work by ratios, so if long side = 2 * short side, using a length of 2 and 1 is fine, or you can use 100 and 50, it doesn't matter.
	// same for the trapezoidal texture usage
	public ref class TrapezoidTexture : public GameBase
	{
	public:
		TrapezoidTexture(HWND p_hWnd) : GameBase(p_hWnd)
		{
		}

		~TrapezoidTexture() override
		{
			Destroy();
		}

		void Initialize() override
		{
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Checkerboard", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg"));
		}

		void Destroy() override
		{
			// todo: get rid of anything app specific in GameInstance for this game

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			Orient3d camera;
			camera.LoadIdentity();
			camera.p.z = -120.0f;

			Orient3d rectOrient1;
			rectOrient1.LoadIdentity();
			rectOrient1.p.Set(40.0f, 30.0f, 0.0f);
			rectOrient1.Rotate(rectOrient1.u, 20.0f);
			rectOrient1.Rotate(rectOrient1.l, -45.0f);
			Orient3d trapezoidOrient1;
			trapezoidOrient1.LoadIdentity();
			trapezoidOrient1.p.Set(0.0f, 30.0f, 0.0f);
			trapezoidOrient1.Rotate(trapezoidOrient1.u, 20.0f);
			trapezoidOrient1.Rotate(trapezoidOrient1.l, -45.0f);
			Orient3d trapezoidOrient2;
			trapezoidOrient2.LoadIdentity();
			trapezoidOrient2.p.Set(-40.0f, 30.0f, 0.0f);
			trapezoidOrient2.Rotate(trapezoidOrient2.u, 20.0f);
			trapezoidOrient2.Rotate(trapezoidOrient2.l, -45.0f);

			GameColor colorsWhite[1] = { GameColor(255, 255, 255, 255) };
			// A quad facing backwards, so use orients that face away from the viewpoint
			ModelVertex rectangleVertices[4] = { ModelVertex(Vector3d(10.0f, 15.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, 15.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, -15.0f, 0.0f), 0), ModelVertex(Vector3d(10.0f, -15.0f, 0.0f), 0) };
			ModelVertex parallelagramVertices[4] = { ModelVertex(Vector3d(10.0f, 15.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, 15.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -15.0f, 0.0f), 0), ModelVertex(Vector3d(21.0f, -15.0f, 0.0f), 0) };
			ModelVertex trapezoidVertices[4] = { ModelVertex(Vector3d(10.0f, 15.0f, 0.0f), 0), ModelVertex(Vector3d(-10.0f, 15.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -15.0f, 0.0f), 0), ModelVertex(Vector3d(9.0f, -15.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoordsNormal[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			ModelVertexTextureCoords texCoordsPerspective1[4] = { ModelVertexTextureCoords(0.0f, 0.0f, 20.0f), ModelVertexTextureCoords(1.0f, 0.0f, 20.0f), ModelVertexTextureCoords(1.0f, 1.0f, 8.0f), ModelVertexTextureCoords(0.0f, 1.0f, 8.0f) };
			ModelVertexTextureCoords texCoordsTrapezoidTexture[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(0.75f, 1.0f, 2.0f), ModelVertexTextureCoords(0.25f, 1.0f, 2.0f) };
			// long segment 20, short segment 8, texture on long segment 1/2, texture on short segment 1
			// so q on top = 20 * 2 / 20, q on short = 8 * 1 / 20.  both could be multiplied by 20, too, for 40 and 8 for same result, or 200 and 40, etc.
			ModelVertexTextureCoords texCoordsPerspectiveTrapezoidTexture[4] = { ModelVertexTextureCoords(0.0f, 0.0f, 2.0f), ModelVertexTextureCoords(0.5f, 0.0f, 2.0f), ModelVertexTextureCoords(1.0f, 1.0f, 0.4f), ModelVertexTextureCoords(0.0f, 1.0f, 0.4f) };

			GameTexture ^texture = GameContext::Instance->TextureRegistry.GetTexture("Checkerboard");

			// no attempt to blend alphas
			graphics->DefaultTransform();
			graphics->ReverseTransform(camera);

			graphics->PushMatrix();
			graphics->Transform(rectOrient1);
			graphics->RenderFilledQuad(colorsWhite, 1, parallelagramVertices, 4, true, texture, texCoordsNormal, 4);
			graphics->PopMatrix();

			graphics->PushMatrix();
			graphics->Transform(trapezoidOrient1);
			graphics->RenderFilledQuad(colorsWhite, 1, trapezoidVertices, 4, true, texture, texCoordsNormal, 4);
			graphics->PopMatrix();

			// move view down (as if camera is higher on y) - could have just done this with a second cameraOrient with a higher y, or two more trapezoidOrients with lower y's
			graphics->Translate(0.0f, -40.0f, 0.0f);

			// render corrections

			// render a perspective interpolation
			graphics->PushMatrix();
			graphics->Transform(trapezoidOrient1);
			graphics->RenderFilledQuad(colorsWhite, 1, trapezoidVertices, 4, true, texture, texCoordsPerspective1, 4); // top side is 20 across, bottom is 8 across, sides are 24.474
			graphics->PopMatrix();

			// use a trapezoidal texture portion on a trapezoidal polygon
			graphics->PushMatrix();
			graphics->Transform(trapezoidOrient2);
			graphics->RenderFilledQuad(colorsWhite, 1, trapezoidVertices, 4, true, texture, texCoordsPerspectiveTrapezoidTexture, 4);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}
	};

	public ref class ProjectedTexture : public GameBase
	{
	public:

		Orient3d *cameraOrient;
		Orient3d *cubeOrient;
		Model3d *cube;
		float horizontalAngle;
		float verticalAngle;
		float rotationAngle;

		ProjectedTexture(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;
			cubeOrient = nullptr;
			cube = nullptr;
		}

		virtual ~ProjectedTexture()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("CheckerBoard", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("flashlight.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("Flashlight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(10.0f);

			cubeOrient = new Orient3d();
			cubeOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				rotationAngle += -float(mouse.offsetX) / 5.0f;
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				horizontalAngle += -float(mouse.offsetX) / 5.0f;
				if (horizontalAngle < -45.0f)
					horizontalAngle = -45.0f;
				if (horizontalAngle > 45.0f)
					horizontalAngle = 45.0f;
				verticalAngle += float(mouse.offsetY) / 5.0f;
				if (verticalAngle < -45.0f)
					verticalAngle = -45.0f;
				if (verticalAngle > 45.0f)
					verticalAngle = 45.0f;
			}
			mouse.ZeroOffsets();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// calculate cube position based on angles
			cubeOrient->LoadIdentity();
			cubeOrient->Rotate(cubeOrient->u, horizontalAngle);
			cubeOrient->Rotate(cubeOrient->l, verticalAngle);
			cubeOrient->Rotate(cubeOrient->f, rotationAngle);
			cubeOrient->p = cubeOrient->p - cubeOrient->f.ScalarMult(3.0f);

			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(*cubeOrient);
			// render the cube
			graphics->Scale(0.1f, 0.1f, 0.2f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			// use values that force an intersection with the plane on all 4 corners.  Don't use lateral projections of more than 0.3
			// keep forward at 1.0f
			float flashlightHorizontalProjection = 0.3f;
			float flashlightVerticalProjection = 0.3f;
			float flashlightForwardProjection = 1.0f;
			Vector3d planePoint = Vector3d(0, 0, 0);
			Vector3d planeNormal = Vector3d(0, 0, 1);
			RenderProjectedTexture(graphics, *cubeOrient, flashlightHorizontalProjection, flashlightVerticalProjection, flashlightForwardProjection, planePoint, planeNormal);

			Orient3d tempCubeOrient;
			tempCubeOrient.LoadIdentity();
			// render another at the center point for match checking on projected texture
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(tempCubeOrient);
			// render the cube
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			// render 4 more half way projected, calculated against the plane
			Vector3d intersectionPoint;
			MathUtilities::LineIntersectPlane(cubeOrient->p, cubeOrient->l.ScalarMult(flashlightHorizontalProjection / 2.0f) + cubeOrient->u.ScalarMult(flashlightVerticalProjection / 2.0f) + cubeOrient->f.ScalarMult(flashlightForwardProjection), planePoint, planeNormal, intersectionPoint);
			tempCubeOrient.p = intersectionPoint;
			// render another at the center point for match checking on projected texture
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(tempCubeOrient);
			// render the cube
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();
			MathUtilities::LineIntersectPlane(cubeOrient->p, cubeOrient->l.ScalarMult(-flashlightHorizontalProjection / 2.0f) + cubeOrient->u.ScalarMult(flashlightVerticalProjection / 2.0f) + cubeOrient->f.ScalarMult(flashlightForwardProjection), planePoint, planeNormal, intersectionPoint);
			tempCubeOrient.p = intersectionPoint;
			// render another at the center point for match checking on projected texture
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(tempCubeOrient);
			// render the cube
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();
			MathUtilities::LineIntersectPlane(cubeOrient->p, cubeOrient->l.ScalarMult(-flashlightHorizontalProjection / 2.0f) + cubeOrient->u.ScalarMult(-flashlightVerticalProjection / 2.0f) + cubeOrient->f.ScalarMult(flashlightForwardProjection), planePoint, planeNormal, intersectionPoint);
			tempCubeOrient.p = intersectionPoint;
			// render another at the center point for match checking on projected texture
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(tempCubeOrient);
			// render the cube
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();
			MathUtilities::LineIntersectPlane(cubeOrient->p, cubeOrient->l.ScalarMult(flashlightHorizontalProjection / 2.0f) + cubeOrient->u.ScalarMult(-flashlightVerticalProjection / 2.0f) + cubeOrient->f.ScalarMult(flashlightForwardProjection), planePoint, planeNormal, intersectionPoint);
			tempCubeOrient.p = intersectionPoint;
			// render another at the center point for match checking on projected texture
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(tempCubeOrient);
			// render the cube
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderProjectedTexture(GraphicsBase *p_graphics, Orient3d &p_flashlightOrient, float p_flashlightHorizontalProjection, float p_flashlightVerticalProjection, float p_flashlightForwardProjection, Vector3d &p_planePoint, Vector3d &p_planeNormal)
		{
			ModelVertex quadVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 2), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 3) };
			GameColor quadColors[4] = { GameColor(255, 255, 255, 255), GameColor(255, 255, 255, 255), GameColor(255, 255, 255, 255), GameColor(255, 255, 255, 255) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };

			// split effort into 16 sections
			p_graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One);
			float horizontalProject = p_flashlightHorizontalProjection;
			float horizontalIncrement = p_flashlightHorizontalProjection / 2.0f;
			for (float x = 0; x < 1.0f; x += 0.25f)
			{
				float verticalProject = p_flashlightVerticalProjection;
				float verticalIncrement = p_flashlightVerticalProjection / 2.0f;
				for (float y = 0; y < 1.0f; y += 0.25f)
				{
					// calculate the 4 vertices (in order ul, ur, lr, ll)
					Vector3d intersectionPoint;
					MathUtilities::LineIntersectPlane(p_flashlightOrient.p, p_flashlightOrient.l.ScalarMult(horizontalProject) + p_flashlightOrient.u.ScalarMult(verticalProject) + p_flashlightOrient.f.ScalarMult(p_flashlightForwardProjection), p_planePoint, p_planeNormal, intersectionPoint);
					quadVertices[0].vertex = intersectionPoint;
					MathUtilities::LineIntersectPlane(p_flashlightOrient.p, p_flashlightOrient.l.ScalarMult(horizontalProject - horizontalIncrement) + p_flashlightOrient.u.ScalarMult(verticalProject) + p_flashlightOrient.f.ScalarMult(p_flashlightForwardProjection), p_planePoint, p_planeNormal, intersectionPoint);
					quadVertices[1].vertex = intersectionPoint;
					MathUtilities::LineIntersectPlane(p_flashlightOrient.p, p_flashlightOrient.l.ScalarMult(horizontalProject - horizontalIncrement) + p_flashlightOrient.u.ScalarMult(verticalProject - verticalIncrement) + p_flashlightOrient.f.ScalarMult(p_flashlightForwardProjection), p_planePoint, p_planeNormal, intersectionPoint);
					quadVertices[2].vertex = intersectionPoint;
					MathUtilities::LineIntersectPlane(p_flashlightOrient.p, p_flashlightOrient.l.ScalarMult(horizontalProject) + p_flashlightOrient.u.ScalarMult(verticalProject - verticalIncrement) + p_flashlightOrient.f.ScalarMult(p_flashlightForwardProjection), p_planePoint, p_planeNormal, intersectionPoint);
					quadVertices[3].vertex = intersectionPoint;

					// now calculate the vertex coordinates
					// This is actually f projected on to the surface - we do it here quickly
					//Vector3d axisAlongPlane = p_flashlightOrient.f;
					//axisAlongPlane.z = 0.0f;
					//if (axisAlongPlane.Normalize() == true)
					//{
						//Vector3d flashlightPositionProjectedToPlane = p_flashlightOrient.p - p_planeNormal.ScalarMult((p_flashlightOrient.p - p_planePoint) * p_planeNormal);
						//Vector3d lateralAxis = axisAlongPlane.CrossProd(p_flashlightOrient.p - flashlightPositionProjectedToPlane);
						//if (lateralAxis.Normalize() == false)
						//{
						//	// flashlight is ON surface.  don't render
						//	return;
						//}

						for (int i = 0; i < 4; i++)
						{
							// imagine we are rendering a trapezoid and solve that problem (lateral distance off the axis)
							// can also subtract p_flashlightOrient.p, same result
							//float q = fabs((quadVertices[i].vertex - flashlightPositionProjectedToPlane) * lateralAxis) * 2.0f;
							//float q = (quadVertices[i].vertex - p_flashlightOrient.p).Magnitude();
							// this works!! it's faster!
							float q = (quadVertices[i].vertex - p_flashlightOrient.p) * p_flashlightOrient.f;

							switch (i)
							{
							case 0:
								texCoords[i].Set(x, y, q);
								break;
							case 1:
								texCoords[i].Set(x + 0.25f, y, q);
								break;
							case 2:
								texCoords[i].Set(x + 0.25f, y + 0.25f, q);
								break;
							case 3:
								texCoords[i].Set(x, y + 0.25f, q);
								break;
							}

							// fade it out as distance increases
							// note: 0 alpha with interpolation just extends the rest of the texture which can cause a lightening as the 0 alpha corner extends
							// so for best effect, split the rendered texture into 16 sections and calculate and set alpha for each.
							int alpha = 255 - int(q * 60);
							if (alpha < 0)
								alpha = 0;
							quadColors[i].alpha = alpha;
						}
					//}
					//else
					//{
					//	// if can't be normalized, then we are shining directly at the surface...
					//	// no need to project!
					//	texCoords[0].Set(0.0f, 0.0f);
					//	texCoords[1].Set(1.0f, 0.0f);
					//	texCoords[2].Set(1.0f, 1.0f);
					//	texCoords[3].Set(0.0f, 1.0f);
					//}

					p_graphics->PushMatrix();
					p_graphics->RenderFilledQuad(quadColors, 4, quadVertices, 4, true, GameContext::Instance->TextureRegistry.GetTexture("CheckerBoard"), texCoords, 4);
					p_graphics->PopMatrix();

					verticalProject -= verticalIncrement;
				}

				horizontalProject -= horizontalIncrement;
			}
			p_graphics->SetBlendFunc(GraphicsBlendFuncEnum::Source_Alpha, GraphicsBlendFuncEnum::One_Minus_Source_Alpha);
		}
	};


	public ref class TestRotatingJet : public GameBase
	{
	public:

		Orient3d *jetOrient;
		Orient3d *cubeOrient;
		Orient3d *cameraOrient;
		Model3d *cube;
		Model3d *jet;
		Model3d *ball;
		Orient3d *ballOrient;

		TestRotatingJet(HWND p_hWnd) : GameBase(p_hWnd)
		{
			jetOrient = nullptr;
			cubeOrient = nullptr;
			cameraOrient = nullptr;
			cube = nullptr;
			jet = nullptr;
			ball = nullptr;
			ballOrient = nullptr;
		}

		virtual ~TestRotatingJet()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			jetOrient = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient = new Orient3d();
			ballOrient = new Orient3d();
			jetOrient->LoadIdentity();
			cubeOrient->LoadIdentity();
			cameraOrient->LoadIdentity();
			ballOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);
			// move the jet forward and over
			jetOrient->p = jetOrient->p + jetOrient->f.ScalarMult(7.0f) + jetOrient->l.ScalarMult(-2.5f) + jetOrient->u.ScalarMult(2.0f);
			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(7.0f) + cubeOrient->l.ScalarMult(2.5f) + cubeOrient->u.ScalarMult(2.0f);
			ballOrient->p = ballOrient->p + ballOrient->f.ScalarMult(7.0f) + ballOrient->l.ScalarMult(2.5f) - ballOrient->u.ScalarMult(2.0f);

			jetOrient->Rotate(jetOrient->u, 180.0f);
			cubeOrient->Rotate(cubeOrient->u, 180.0f);
			ballOrient->Rotate(ballOrient->u, 180.0f);

			cube = new Model3d();
			cube->MakeCube();
			// give it a texture, make front face white to make it pure
			cube->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));
			cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			cube->GetSurface(0)->SetVertexTexCoords(1, 0.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(3, 1.0f, 1.0f);
			cube->GetColor(0)->Set(255, 255, 255);
			cube->GetColor(1)->Set(255, 255, 255);
			cube->GetColor(2)->Set(255, 255, 255);
			cube->GetColor(3)->Set(255, 255, 255);

			jet = new Model3d();
			jet->MakeJet();

			// cheat and make it look like it did before it was fixed
			jet->GetSurface(2)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(2, -1);
			jet->GetSurface(5)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(8)->SetVertexColorOverrideIndex(0, -1);

			ball = new Model3d();
			ball->MakeSphere();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
			if (ballOrient != nullptr)
			{
				delete ballOrient;
				ballOrient = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				jetOrient->Rotate(jetOrient->f, float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(cubeOrient->f, float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(ballOrient->f, -float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				jetOrient->Rotate(Vector3d::Vector(0,1,0), -float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				jetOrient->Rotate(jetOrient->l, -float(mouse.offsetY) / 5.0f);
				cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
				ballOrient->Rotate(ballOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = jetOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(*cubeOrient);
			// render the cube
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the ball
			graphics->Transform(*ballOrient);
			// render the cube
			ball->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(*jetOrient);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class TerrainTest1 : public GameBase
	{
	public:

		TerrainMesh *terrain;
		Orient3d *cameraOrient;
		Orient3d *cubeOrient;
		Model3d *cube;

		TerrainTest1(HWND p_hWnd) : GameBase(p_hWnd)
		{
			terrain = nullptr;
			cameraOrient = nullptr;
			cubeOrient = nullptr;
			cube = nullptr;
		}

		virtual ~TerrainTest1()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			cameraOrient = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			cubeOrient->LoadIdentity();
		
			cube = new Model3d();
			cube->MakeCube();

			terrain = new TerrainMesh();
			terrain->Initialize(1013, 1007, 0.0f, 0.0f, 1.0f); // irregular size to test region calculation
			//terrain->Initialize(237, 244, 0.0f, 0.0f, 4.0f); // irregular size to test region calculation
			//terrain->Initialize(16, 16, 0.0f, 0.0f, 17.0f); // irregular size to test region calculation
			terrain->SetHeight(0.0f);
			//terrain->SetGreatestXZHeight();

			terrain->CalculateLevelOfDetailRegions(37); // irregular region size to test region calculation
			terrain->CalculateLevelOfDetailHeights();
			terrain->CalculateNormalsAndSegments();
			terrain->CalculateBoundingVolumes();

			// back up the camera awat form the 0,0 corner and move it up
			//cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(500.0f);
			float distance = 10.0f;
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(distance) - cameraOrient->l.ScalarMult(distance) + cameraOrient->u.ScalarMult(distance);
			//cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(10.0f);
			// spin it over and down to look down at the terrain
			cameraOrient->Rotate(cameraOrient->u, -45.0f);
			cameraOrient->Rotate(cameraOrient->l, -20.0f);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (terrain != nullptr)
			{
				delete terrain;
				terrain = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				cameraOrient->Rotate(cameraOrient->f, -float(mouse.offsetX));
			}
			if (mouse.leftButton.down)
			{
				// move camera according to mouse and keyboard
				cameraOrient->Rotate(cameraOrient->u, float(mouse.offsetX)/2.0f);
				cameraOrient->Rotate(cameraOrient->l, -float(mouse.offsetY)/2.0f);
			}
			// test collision detection
			if (mouse.middleButton.down)
			{
				float collisionT;
				Vector3d collisionLocation;
				Vector3d collisionNormal;
				if (terrain->SphereCollision(cameraOrient->p, cameraOrient->f.ScalarMult(1000.0f), 0.5f, collisionT, collisionLocation, collisionNormal) == true)
				{
					cubeOrient->p = collisionLocation;
				}
			}

			if (keyboardKeys.GetKey('W')->IsPressed())
				cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('S')->IsPressed())
				cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('A')->IsPressed())
				cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('D')->IsPressed())
				cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('Q')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, 2.0f);
			if (keyboardKeys.GetKey('E')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, -2.0f);

			mouse.ZeroOffsets();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->PushMatrix();

			// render the terrain (no transform)
			terrain->Render(*cameraOrient, *graphics, 10, 50.0f);

			graphics->Transform(*cubeOrient);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class TerrainTest2 : public GameBase
	{
	public:

		TerrainMesh *terrain;
		Orient3d *cameraOrient;
		Orient3d *cubeOrient1, *cubeOrient2;
		Vector3d *collisionNormal;
		Model3d *cube;
		System::Drawing::Bitmap ^bitmap1;
		System::Drawing::Bitmap ^bitmap2;
		System::Drawing::Bitmap ^bitmap3;

		TerrainTest2(HWND p_hWnd) : GameBase(p_hWnd)
		{
			terrain = nullptr;
			cameraOrient = nullptr;
			cubeOrient1 = nullptr;
			cubeOrient2 = nullptr;
			cube = nullptr;
			bitmap1 = nullptr;
			bitmap2 = nullptr;
			bitmap3 = nullptr;
		}

		virtual ~TerrainTest2()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);
			GameContext::Instance->FontRegistry.RegisterFont("Metrics", gcnew System::Drawing::Font("Verdana", 12));

			cameraOrient = new Orient3d();
			cubeOrient1 = new Orient3d();
			cubeOrient2 = new Orient3d();
			cameraOrient->LoadIdentity();
			cubeOrient1->LoadIdentity();
			cubeOrient2->LoadIdentity();
			collisionNormal = new Vector3d();

			try
			{
				bitmap1 = gcnew System::Drawing::Bitmap("heightmap1.jpg");
				bitmap2 = gcnew System::Drawing::Bitmap("heightmap2.bmp");
				bitmap3 = gcnew System::Drawing::Bitmap("heightmap5.jpg");
			}
			catch (System::Exception ^ex)
			{
				Trace::WriteLine(ex->ToString());
			}

			cube = new Model3d();
			cube->MakeCube();

			terrain = new TerrainMesh();
			terrain = new TerrainMesh();
			bool useBitmap = true;
			if (useBitmap == false)
			{
				terrain->Initialize(1013, 1007, 0.0f, 0.0f, 1.0f); // irregular size to test region calculation
				//terrain->Initialize(237, 244, 0.0f, 0.0f, 4.0f); // irregular size to test region calculation
				//terrain->Initialize(16, 16, 0.0f, 0.0f, 17.0f); // irregular size to test region calculation
				terrain->SetHeight(0.0f);
				//terrain->SetGreatestXZHeight();
			}
			else
			{
				String ^terrainFileName = "TerrainTest2.dat";

				if (terrain->LoadMeshFromFile(terrainFileName, 0.0f, 0.0f, 1.0f) == false)
				{
					terrain->Initialize(bitmap1, 0.0f, 0.0f, 1.0f, 0.50f);
					terrain->WriteMeshToFile(terrainFileName);
				}
			}

			terrain->CalculateLevelOfDetailRegions(37); // irregular region size to test region calculation
			terrain->CalculateLevelOfDetailHeights();
			terrain->CalculateNormalsAndSegments();
			terrain->CalculateBoundingVolumes();

			// back up the camera awat form the 0,0 corner and move it up
			//cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(500.0f);
			float distance = 10.0f;
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(distance) - cameraOrient->l.ScalarMult(distance) + cameraOrient->u.ScalarMult(distance);
			//cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(10.0f);
			// spin it over and down to look down at the terrain
			cameraOrient->Rotate(cameraOrient->u, -45.0f);
			cameraOrient->Rotate(cameraOrient->l, -20.0f);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (terrain != nullptr)
			{
				delete terrain;
				terrain = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cubeOrient1 != nullptr)
			{
				delete cubeOrient1;
				cubeOrient1 = nullptr;
			}
			if (cubeOrient2 != nullptr)
			{
				delete cubeOrient2;
				cubeOrient2 = nullptr;
			}
			if (collisionNormal != nullptr)
			{
				delete collisionNormal;
				collisionNormal = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (bitmap1 != nullptr)
			{
				delete bitmap1;
				bitmap1 = nullptr;
			}
			if (bitmap2 != nullptr)
			{
				delete bitmap2;
				bitmap2 = nullptr;
			}
			if (bitmap3 != nullptr)
			{
				delete bitmap3;
				bitmap3 = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();
			
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				cameraOrient->Rotate(cameraOrient->f, -float(mouse.offsetX));
			}
			if (mouse.leftButton.down)
			{
				// move camera according to mouse and keyboard
				cameraOrient->Rotate(cameraOrient->u, float(mouse.offsetX) / 2.0f);
				cameraOrient->Rotate(cameraOrient->l, -float(mouse.offsetY) / 2.0f);
			}
			// test collision detection
			if (mouse.middleButton.down)
			{
				float collisionT;
				Vector3d collisionLocation;
				Vector3d terrainCollisionNormal;
				if (terrain->SphereCollision(cameraOrient->p, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->ConvertViewportCoordinatesToWorldVector(mouse.currentX, mouse.currentY).ScalarMult(100.0f), 0.05f, collisionT, collisionLocation, terrainCollisionNormal) == true)
				{
					cubeOrient1->p = collisionLocation;
					terrainCollisionNormal.Normalize();
					*collisionNormal = terrainCollisionNormal;
					cubeOrient2->p = collisionLocation + collisionNormal->ScalarMult(0.5f);
				}
				else
				{
					cubeOrient1->p = Vector3d(0, 0, 0);
					cubeOrient2->p = Vector3d(0, 0, 0);
					*collisionNormal = Vector3d(0, 0, 0);
				}
			}

			if (keyboardKeys.GetKey('W')->IsPressed())
			{
				if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(1.0f);
				else
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(0.5f);
			}
			if (keyboardKeys.GetKey('S')->IsPressed()) 
			{
				if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(1.0f);
				else
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(0.5f);
			}
			if (keyboardKeys.GetKey('A')->IsPressed())
				cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('D')->IsPressed())
				cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('Q')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, 2.0f);
			if (keyboardKeys.GetKey('E')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, -2.0f);

			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = cameraOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// render the terrain (no transform)
			terrain->Render(*cameraOrient, *graphics, 10, 50.0f);

			graphics->PushMatrix();
			graphics->Transform(*cubeOrient1);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();
			graphics->PushMatrix();
			graphics->Transform(*cubeOrient2);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->Set2dWindowProjection();
			graphics->SetDepthTestEnabled(false);
			graphics->SetDepthWriteEnabled(false);
			graphics->RenderFont("Cube Position: " + String::Format("X: {0:0.0}, Y: {1:0.0}, Z: {2:0.0}", cubeOrient1->p.x, cubeOrient1->p.y, cubeOrient1->p.z),
				GameContext::Instance->FontRegistry.GetFont("Metrics"),
				10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Metrics")->GetHeight() * 3),
				GameColor(255, 255, 0));
			graphics->RenderFont("Collision Normal: " + String::Format("X: {0:0.0}, Y: {1:0.0}, Z: {2:0.0}", collisionNormal->x, collisionNormal->y, collisionNormal->z),
				GameContext::Instance->FontRegistry.GetFont("Metrics"),
				10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Metrics")->GetHeight() * 2),
				GameColor(255, 255, 0));
			graphics->SetDepthWriteEnabled(true);
			graphics->SetDepthTestEnabled(true);

			graphics->FinishRender();
			graphics->SwapBuffers();

			// reset camera transform so that ConvertViewportCoordsToWorldVector works in game loop
			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);
			graphics->DefaultTransform();
			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

		}
	};

	public ref class SkyboxDomeTest : public GameBase
	{
	public:

		SkyboxColorDome *dome;
		Orient3d *cameraOrient;
		Orient3d *cubeOrient;
		Model3d *cube;

		SkyboxDomeTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			dome = nullptr;
			cameraOrient = nullptr;
			cubeOrient = nullptr;
			cube = nullptr;
		}

		virtual ~SkyboxDomeTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			cameraOrient = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			cubeOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();

			dome = new SkyboxColorDome();
			// do this instead of calling new [] within the initialize call.  Putting a new array[] call in the initialize caused an exception on a second initialization.
			//  was it a problem with the Initialize() method being inline?
			GameColor beforeSunriseColor[10] = { GameColor(213, 125, 51), GameColor(234, 161, 70), GameColor(209, 170, 117),
				GameColor(152, 148, 134), GameColor(109, 125, 134), GameColor(75, 106, 129),
				GameColor(54, 87, 116), GameColor(43, 73, 103), GameColor(43, 73, 103),
				GameColor(43, 73, 103) };
			GameColor earlyMorningColor[10] = { GameColor(246, 212, 161), GameColor(226, 225, 219), GameColor(200, 207, 218),
				GameColor(167, 182, 206), GameColor(142, 159, 185), GameColor(119, 136, 166),
				GameColor(104, 121, 151), GameColor(86, 104, 134), GameColor(67, 86, 116),
				GameColor(60, 77, 106) };
			GameColor morningColor[10] = { GameColor(179, 224, 255), GameColor(152, 214, 255), GameColor(121, 189, 252),
				GameColor(99, 167, 238), GameColor(80, 146, 220), GameColor(66, 128, 201),
				GameColor(57, 115, 188), GameColor(47, 104, 173), GameColor(43, 97, 161),
				GameColor(42, 93, 156) };
			dome->Initialize(9, 40, &morningColor[0]);

			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(10);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (dome != nullptr)
			{
				delete dome;
				dome = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				cameraOrient->Rotate(cameraOrient->f, -float(mouse.offsetX));
			}
			if (mouse.leftButton.down)
			{
				// move camera according to mouse and keyboard
				cameraOrient->Rotate(cameraOrient->u, float(mouse.offsetX) / 2.0f);
				cameraOrient->Rotate(cameraOrient->l, -float(mouse.offsetY) / 2.0f);
			}

			if (keyboardKeys.GetKey('W')->IsPressed())
			{
				if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(1.0f);
				else
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(0.5f);
			}
			if (keyboardKeys.GetKey('S')->IsPressed())
			{
				if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(1.0f);
				else
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(0.5f);
			}
			if (keyboardKeys.GetKey('A')->IsPressed())
				cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('D')->IsPressed())
				cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('Q')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, 2.0f);
			if (keyboardKeys.GetKey('E')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, -2.0f);

			mouse.ZeroOffsets();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->PushMatrix();

			// render the skybox with the same world value as the camera point with no depth value
			Orient3d skyboxOrient;
			skyboxOrient.LoadIdentity();
			skyboxOrient.p = cameraOrient->p;
			graphics->Transform(skyboxOrient);
			graphics->SetDepthWriteEnabled(false); // todo: push current depth value then pop it later
			dome->Render(*graphics);
			graphics->SetDepthWriteEnabled(true);
			graphics->PopMatrix();

			graphics->Transform(*cubeOrient);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class StarfieldTest : public GameBase
	{
	public:

		Starfield *starField;
		Orient3d *cameraOrient;
		Orient3d *priorStarfieldCameraOrient;
		Orient3d *priorTrackRef;
		Orient3d *cubeOrient;
		Model3d *cube;

		StarfieldTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			starField = nullptr;
			cameraOrient = nullptr;
			priorStarfieldCameraOrient = nullptr;
			priorTrackRef = nullptr;
			cubeOrient = nullptr;
			cube = nullptr;
		}

		virtual ~StarfieldTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			cameraOrient = new Orient3d();
			priorStarfieldCameraOrient = new Orient3d();
			priorTrackRef = nullptr;
			cubeOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			priorStarfieldCameraOrient->LoadIdentity();
			cubeOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();

			starField = new Starfield();
			starField->Initialize(3000, GameColor(255,255,255), GameColor(64,64,255), 64, -0.7f);

			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(10);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (starField != nullptr)
			{
				delete starField;
				starField = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (priorStarfieldCameraOrient != nullptr)
			{
				delete priorStarfieldCameraOrient;
				priorStarfieldCameraOrient = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			//if (mouse.rightButton.down)
			//{
			//	cameraOrient->Rotate(cameraOrient->f, -float(mouse.offsetX));
			//}
			if (mouse.leftButton.down)
			{
				// move camera according to mouse and keyboard
				// keep a horiztonal l
				cameraOrient->Rotate(Vector3d(0,1,0), float(mouse.offsetX) / 2.0f);
				cameraOrient->Rotate(cameraOrient->l, -float(mouse.offsetY) / 2.0f);
			}

			if (keyboardKeys.GetKey('W')->IsPressed())
			{
				if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(1.0f);
				else
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(0.5f);
			}
			if (keyboardKeys.GetKey('S')->IsPressed())
			{
				if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(1.0f);
				else
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(0.5f);
			}
			if (keyboardKeys.GetKey('A')->IsPressed())
				cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('D')->IsPressed())
				cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('Q')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, 2.0f);
			if (keyboardKeys.GetKey('E')->IsPressed())
				cameraOrient->Rotate(cameraOrient->f, -2.0f);

			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = cameraOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 0, 0));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->PushMatrix();

			// render the starfield with the same world value as the camera point with no depth value
			Orient3d starfieldCameraOrient;
			starfieldCameraOrient.Set(*cameraOrient);
			starfieldCameraOrient.p = Vector3d(0, 0, 0);
			Orient3d starfieldRenderOrient;
			starfieldRenderOrient.LoadIdentity();
			starfieldRenderOrient.p = cameraOrient->p;
			graphics->Transform(starfieldRenderOrient);
			//static Orient3d priorStarfieldCameraOrient = starfieldCameraOrient; // track each render (no way to reset and draw points only in this test)
			graphics->SetDepthWriteEnabled(false); // todo: push current depth value then pop it later

			// test
			//priorStarfieldCameraOrient->Set(starfieldCameraOrient);
			//priorStarfieldCameraOrient->Rotate(priorStarfieldCameraOrient->f, 20.0f);

			starField->Render(*graphics, starfieldCameraOrient, priorTrackRef);
			priorStarfieldCameraOrient->Set(starfieldCameraOrient); // track for next time
			priorTrackRef = priorStarfieldCameraOrient;
			graphics->SetDepthWriteEnabled(true);
			graphics->PopMatrix();

			graphics->Transform(*cubeOrient);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class SmokeTrailTest : public GameBase
	{
	public:

		Orient3d *cameraOrient;

		LinkedList<AlphaTrail> *smokeTrails;

		GameTimer *timer;

		SmokeTrailTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;
			smokeTrails = nullptr;
			timer = nullptr;
		}

		virtual ~SmokeTrailTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			smokeTrails = new LinkedList<AlphaTrail>();

			// a test trail
			LinkedListNode<AlphaTrail> *newTrailNode = smokeTrails->GetNewNode();
			newTrailNode->data.maxLifeMS = 500;
			newTrailNode->data.beginningAlpha = 255;
			newTrailNode->data.Add(Vector3d(10, 10, 30), 9000);
			newTrailNode->data.Add(Vector3d(-10, -10, 30), 0);
			smokeTrails->AddNode(newTrailNode);

			timer = new GameTimer();
			timer->ResetGameTime();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (smokeTrails != nullptr)
			{
				delete smokeTrails;
				smokeTrails = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			//if (mouse.rightButton.down)
			//{
			//	cameraOrient->Rotate(cameraOrient->f, -float(mouse.offsetX));
			//}
			if (mouse.leftButton.down)
			{
				if (mouse.offsetX != 0 || mouse.offsetY != 0)
				{
					Vector3d worldVector = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->ConvertViewportCoordinatesToWorldVector(mouse.currentX, mouse.currentY);
					worldVector = worldVector.ScalarMult(30.0f / worldVector.z);

					smokeTrails->GetFirstNode()->data.Add(worldVector, 0);
				}
			}

			mouse.ZeroOffsets();

			FadeSmokeTrails();

			timer->ResetElapsedTime();

			return true;
		}
		
		void FadeSmokeTrails()
		{
			LinkedListEnumerator<AlphaTrail> smokeTrailsEnumerator = LinkedListEnumerator<AlphaTrail>(*smokeTrails);
			while (smokeTrailsEnumerator.MoveNext())
			{
				AlphaTrail *currentTrail = &(smokeTrailsEnumerator.Current()->data);
				currentTrail->FadeTrail(timer->GetElapsedTimeMS());
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			graphics->SetDepthWriteEnabled(false);
			// todo: render as a long line strip
			LinkedListEnumerator<AlphaTrail> smokeTrailsEnumerator = LinkedListEnumerator<AlphaTrail>(*smokeTrails);
			while (smokeTrailsEnumerator.MoveNext())
			{
				LinkedListEnumerator<AlphaTrailPoint> smokeTrailEnumerator = LinkedListEnumerator<AlphaTrailPoint>(smokeTrailsEnumerator.Current()->data);
				AlphaTrailPoint *priorPoint = nullptr;
				ModelVertex vertices[2];
				GameColor colors[2];
				while (smokeTrailEnumerator.MoveNext())
				{
					AlphaTrailPoint *currentPoint = &(smokeTrailEnumerator.Current()->data);
					if (priorPoint != nullptr)
					{
						vertices[0].vertex = currentPoint->location;
						vertices[1].vertex = priorPoint->location;
						vertices[0].colorIndex = 0;
						vertices[1].colorIndex = 1;
						colors[0] = GameColor(255, 255, 255, currentPoint->alpha);
						colors[1] = GameColor(255, 255, 255, priorPoint->alpha);
						graphics->RenderLineStrip(2.0f, colors, 2, vertices, 2, true);
					}

					priorPoint = currentPoint;
				}

				// if one point left and it's alpha zero, get rid of it
				if (smokeTrailsEnumerator.Current()->data.IsEmpty() == false)
				{
					if (smokeTrailsEnumerator.Current()->data.GetFirstNode() == smokeTrailsEnumerator.Current()->data.GetLastNode())
					{
						if (smokeTrailsEnumerator.Current()->data.GetFirstNode()->data.alpha == 0)
							smokeTrailsEnumerator.Current()->data.Clear();
					}
				}
			}

			graphics->SetDepthWriteEnabled(true);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class JetFlight1 : public GameBase
	{
	public:

		TerrainMesh *terrain;
		Orient3d *jetOrient;
		Vector3d *jetVelocity;
		Orient3d *cameraOrient;
		Orient3d *cubeOrient;
		Orient3d *priorStarfieldCameraOrient = new Orient3d();
		Orient3d *priorTrackRef;
		Starfield *starField;
		SkyboxColorDome *dome;
		GameTimer *timer;

		bool cameraOnJet;

		Model3d *cube;
		Model3d *jet;
		System::Drawing::Bitmap ^bitmap1;
		System::Drawing::Bitmap ^bitmap2;
		System::Drawing::Bitmap ^bitmap3;

		float gravityAccelerationPerMS;

		JetFlight1(HWND p_hWnd) : GameBase(p_hWnd)
		{
			terrain = nullptr;
			cubeOrient = nullptr;
			jetOrient = nullptr;
			cameraOrient = nullptr;
			jetVelocity = nullptr;
			priorStarfieldCameraOrient = nullptr;
			priorTrackRef = nullptr;
			cube = nullptr;
			jet = nullptr;
			bitmap1 = nullptr;
			bitmap2 = nullptr;
			bitmap3 = nullptr;
			starField = nullptr;
			dome = nullptr;
			timer = nullptr;

			// 0.0000032174049586
			gravityAccelerationPerMS = 9.80665f /* m/s^2 */ * 3.28084f /* conversion from 1 m/s^2 to 1 ft/s^2 */ / 10.0f / 1000000.0f;  // since world 1.0f = simulated 10 ft, acceleration should be around 3.2 ft/s^2 instead of 32 ft/s^2
		}

		virtual ~JetFlight1()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Metrics", gcnew System::Drawing::Font("Verdana", 12));

			cubeOrient = new Orient3d();
			cubeOrient->LoadIdentity();
			jetOrient = new Orient3d();
			cameraOrient = new Orient3d();
			jetVelocity = new Vector3d();
			jetVelocity->Set(0, 0, 0);

			priorStarfieldCameraOrient = new Orient3d();
			priorTrackRef = nullptr;

			try
			{
				bitmap1 = gcnew System::Drawing::Bitmap("heightmap1.jpg");
				bitmap2 = gcnew System::Drawing::Bitmap("heightmap2.bmp");
				bitmap3 = gcnew System::Drawing::Bitmap("heightmap5.jpg");
			}
			catch (System::Exception ^ex)
			{
				Trace::WriteLine(ex->ToString());
			}

			cube = new Model3d();
			cube->MakeCube();
			jet = new Model3d();
			jet->MakeJet(0.50f); // rendering it smaller helps with the enternal perception of speed

			cameraOnJet = true;

			dome = new SkyboxColorDome();
			// do this instead of calling new [] within the initialize call.  Putting a new array[] call in the initialize caused an exception on a second initialization.
			//  was it a problem with the Initialize() method being inline?
			GameColor beforeSunriseColor[10] = { GameColor(213, 125, 51), GameColor(234, 161, 70), GameColor(209, 170, 117),
				GameColor(152, 148, 134), GameColor(109, 125, 134), GameColor(75, 106, 129),
				GameColor(54, 87, 116), GameColor(43, 73, 103), GameColor(43, 73, 103),
				GameColor(43, 73, 103) };
			GameColor earlyMorningColor[10] = { GameColor(246, 212, 161), GameColor(226, 225, 219), GameColor(200, 207, 218),
				GameColor(167, 182, 206), GameColor(142, 159, 185), GameColor(119, 136, 166),
				GameColor(104, 121, 151), GameColor(86, 104, 134), GameColor(67, 86, 116),
				GameColor(60, 77, 106) };
			GameColor morningColor[10] = { GameColor(179, 224, 255), GameColor(152, 214, 255), GameColor(121, 189, 252),
				GameColor(99, 167, 238), GameColor(80, 146, 220), GameColor(66, 128, 201),
				GameColor(57, 115, 188), GameColor(47, 104, 173), GameColor(43, 97, 161),
				GameColor(42, 93, 156) };
			dome->Initialize(9, 40, &morningColor[0]);

			starField = new Starfield();
			starField->Initialize(2000, GameColor(255, 255, 255), GameColor(255, 225, 255), 224, -0.1f); // so that stars don't darken the skybox

			terrain = new TerrainMesh();
			bool useBitmap = true;
			if (useBitmap == false)
			{
				terrain->Initialize(1013, 1007, 0.0f, 0.0f, 1.0f); // irregular size to test region calculation
				terrain->SetHeight(0.0f);
			}
			else
			{
				String ^terrainFileName = "JetFlight1Terrain.dat";

				if (terrain->LoadMeshFromFile(terrainFileName, 0.0f, 0.0f, 1.0f) == false)
				{
					terrain->Initialize(bitmap1, 0.0f, 0.0f, 1.0f, 0.50f);
					terrain->WriteMeshToFile(terrainFileName);
				}
			}

			terrain->CalculateLevelOfDetailRegions(37); // irregular region size to test region calculation
			terrain->CalculateLevelOfDetailHeights();
			terrain->CalculateNormalsAndSegments();
			terrain->CalculateBoundingVolumes();

			jetOrient->LoadIdentity();
			jetOrient->p.Set((terrain->GetStartX() + terrain->GetEndX()) / 2.0f, 200.0f, (terrain->GetStartZ() + terrain->GetEndZ()) / 2.0f); // center of the terrain, 2000 feet in the air
			// spin it a little
			jetOrient->Rotate(jetOrient->f, 45.0f);

			cameraOrient->LoadIdentity();
			cameraOrient->p.Set((terrain->GetStartX() + terrain->GetEndX()) / 2.0f, 200.0f, (terrain->GetStartZ() + terrain->GetEndZ()) / 2.0f - 40.0f); // center of the terrain, 2000 feet in the air, a little behind the jet

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.

			timer->ResetGameTime();
		}

		void DestroyGameData()
		{
			if (terrain != nullptr)
			{
				delete terrain;
				terrain = nullptr;
			}
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jetVelocity != nullptr)
			{
				delete jetVelocity;
				jetVelocity = nullptr;
			}
			if (priorStarfieldCameraOrient != nullptr)
			{
				delete priorStarfieldCameraOrient;
				priorStarfieldCameraOrient = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
			if (bitmap1 != nullptr)
			{
				delete bitmap1;
				bitmap1 = nullptr;
			}
			if (bitmap2 != nullptr)
			{
				delete bitmap2;
				bitmap2 = nullptr;
			}
			if (bitmap3 != nullptr)
			{
				delete bitmap3;
				bitmap3 = nullptr;
			}
			if (dome != nullptr)
			{
				delete dome;
				dome = nullptr;
			}
			if (starField != nullptr)
			{
				delete starField;
				starField = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			////////////////////
			// Interpret controls

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			Orient3d *targetOrient = jetOrient;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				jetOrient->Rotate(targetOrient->f, -float(mouse.offsetX));
			}
			if (mouse.leftButton.down)
			{
				// move camera according to mouse and keyboard
				jetOrient->Rotate(targetOrient->u, float(mouse.offsetX) / 2.0f);
				jetOrient->Rotate(targetOrient->l, -float(mouse.offsetY) / 2.0f);
			}

			//if (keyboardKeys.GetKey('W')->IsPressed())
			//{
			//	if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
			//		jetOrient->p = targetOrient->p + cameraOrient->f.ScalarMult(1.0f);
			//	else
			//		jetOrient->p = targetOrient->p + cameraOrient->f.ScalarMult(0.5f);
			//}
			//if (keyboardKeys.GetKey('S')->IsPressed())
			//{
			//	if (keyboardKeys.GetKey(16)->IsPressed()) // shift = boost
			//		jetOrient->p = targetOrient->p - cameraOrient->f.ScalarMult(1.0f);
			//	else
			//		jetOrient->p = targetOrient->p - cameraOrient->f.ScalarMult(0.5f);
			//}
			//if (keyboardKeys.GetKey('A')->IsPressed())
			//	jetOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(1.0f);
			//if (keyboardKeys.GetKey('D')->IsPressed())
			//	jetOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(1.0f);
			if (keyboardKeys.GetKey('Q')->IsPressed())
				jetOrient->Rotate(targetOrient->f, 2.0f);
			if (keyboardKeys.GetKey('E')->IsPressed())
				jetOrient->Rotate(targetOrient->f, -2.0f);

			mouse.ZeroOffsets();

			if (keyboardKeys.GetKey(113)->clicked)
			{
				cameraOnJet = !cameraOnJet;
				if (cameraOnJet == false)
					cameraOrient->p = jetOrient->p;

				keyboardKeys.GetKey(113)->ClearClicked();

				// avoid star lines in render
				priorTrackRef = nullptr;
			}

			float rudder = 0.0f; // - to the left, + to the right
			float leftAileron = 0.0f, rightAileron = 0.0f;  // - up + down
			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					float value = 0;
					if (jValues->primaryX > 0)
						value = float(jValues->primaryX - primaryDeadArea);
					else
						value = float(jValues->primaryX + primaryDeadArea);

					value = value / (1000.0f - primaryDeadArea);
					// apply adjustment
					if (value > 0.0)
						value = float(pow(value, 1.4f));
					else
						value = -float(pow(-value, 1.4f));

					leftAileron = -value;
					rightAileron = value;

					if (jValues->button2Down == false)
					{
						//targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) * (elapsedTimef / 40.0f) / 200.0f, false);
					}
					else
					{
						//targetOrient->Rotate(targetOrient->f, -float(value) * (elapsedTimef / 40.0f) / 200.0f, false);
					}
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					float value = 0;
					if (jValues->primaryY > 0)
						value = float(jValues->primaryY - primaryDeadArea);
					else
						value = float(jValues->primaryY + primaryDeadArea);

					value = value / (1000.0f - primaryDeadArea);
					// apply adjustment
					if (value > 0.0)
						value = float(pow(value, 1.4f));
					else
						value = -float(pow(-value, 1.4f));

					leftAileron += value;
					if (leftAileron < -1.0f)
						leftAileron = -1.0f;
					if (leftAileron > 1.0f)
						leftAileron = 1.0f;
					rightAileron += value;
					if (rightAileron < -1.0f)
						rightAileron = -1.0f;
					if (rightAileron > 1.0f)
						rightAileron = 1.0f;

					//targetOrient->Rotate(targetOrient->l, float(value) * (elapsedTimef / 40.0f) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					float value = 0;
					if (jValues->twist > 0)
						value = float(jValues->twist - twistDeadArea);
					else
						value = float(jValues->twist + twistDeadArea);

					rudder = value / (1000.0f - twistDeadArea);
					// apply adjustment
					if (rudder > 0.0)
						rudder = float(pow(rudder, 1.4f));
					else
						rudder = -float(pow(-rudder, 1.4f));

					//targetOrient->Rotate(targetOrient->u, float(value) * (elapsedTimef / 40.0f) / 200.0f, false);
				}
			}

			float thrust = 0.53f; // about 155 mph with 0.0010f factor drag applied to current velocity before thrust 0.00001f applied, every 5ms
			if (keyboardKeys.GetKey(16)->pressed)
			{
				thrust = 1.06f; // about 300 mph turbo boost
			}
			if (keyboardKeys.GetKey('0')->pressed)
			{
				thrust = 0.0f; // just a test to try stalling
			}

			///////////////////////////
			// update game state
			float elapsedTimef = timer->GetElapsedTimeMSFloat();

			// make it fall! (worry about accurately and effectively applying 10ms chunks across ticks later)
			float elapsedTimeIncrement = 5.0f;
			while (elapsedTimef > elapsedTimeIncrement)
			{
				ApplyFlightPhysics(*jetOrient, *jetVelocity, gravityAccelerationPerMS, elapsedTimeIncrement, thrust, rudder, leftAileron, rightAileron);
				jetOrient->p = jetOrient->p + jetVelocity->ScalarMult(elapsedTimeIncrement);

				elapsedTimef -= elapsedTimeIncrement;
			}
			if (elapsedTimef > 0.0)
			{
				// apply one last time for rest of elapsedTime
				ApplyFlightPhysics(*jetOrient, *jetVelocity, gravityAccelerationPerMS, elapsedTimef, thrust, rudder, leftAileron, rightAileron);
				jetOrient->p = jetOrient->p + jetVelocity->ScalarMult(elapsedTimef);
			}

			timer->ResetElapsedTime();

			return true;
		}

		// rudder and ailerons range from -1.0f to 1.0f
		void ApplyFlightPhysics(Orient3d &p_jetOrient, Vector3d &p_jetVelocityPerMS, float p_gravityPerMS2, float p_MS, float p_thrust, float p_rudder, float p_leftAileron, float p_rightAileron)
		{
			// increase the coeefficients for higher encounter speed, decrease for lower
			// get good numbers for high speed and low speed, and ZERO speed.
			// good thrust and drag for front wind to establish max forward speed too

			// coefficients should change based on airspeed to give the craft different characteristics at different speeds
			// at very low speeds the craft should act like a stone
			// at very high speeds (300mph) it should act like a dart
			// at cruising speed (150mph) it should be a comfortable craft and fun to maneuver

			///////////////////////
			// TEST CONIDITIONS:

			// thrust:
			// max cruising speed should be 150mph or so
			// turbo max speed should be around 300mph or so
			// combination of thrust factor and forward drag factor

			// at thrust zero:
			// as speed decreases on a 45 degree climb, the craft should stall out on a climb and drop because the angle of attack on the wings is too much
			// From a vertical standstill position, the craft's rear wings should catch the wing and quickly turn it downwards
			// from a sideways position, near zero velocity, the plane shoudl quickly drop and turn downward

			// accelerating:
			// from a standstill to normal thrust, should appear 'fun' and energetic
			// from a standstill to turbo: very fast originally
			// from normal thrust to turbo: should feel impactful
			// max cruising speed should be 150mph
			// max turbo speed should be 300mph

			// decelerating:
			// from turbo to zero: should decrease rapidly at first (air collision drag, cavitating) then gradually drop to zero
			// from normal to zero: should generally slow than gradually drop to zero (surface drag), not too quickly << problem here (decrease drag, decrease thrust factors to match max speed)
			// on a climb: should move forward well on its own momentum then be slowed by gravity (not too much drag) << problem here

			// maneuvering:
			// joystick translation
			// at center should feel precise, at end impactful for extremes, and the curve in the center should make the gradual increase make sense instead of feel like a linear math curve

			// rudder operations:
			// at slow speeds should do little.
			// at cruising speed should be fairly maneuverable and have an enjoyable slide aspect (yawing) that corrects when return to center
			// at turbo speed should do little (travelling fast should sacrifice maneuverability a bit) with almost no slide
			// roll:
			// at cruising speed should be fairly maneuverable
			// at turbo speed should do not as much, but increase drag
			// pitch:
			// at cruising speed should be fairly maneuverable and have an enjoyable slide aspect that corrects when return to center (not as much slide as yawing though)
			// at turbo speed should do little (travelling fast should sacrifice maneuverability a bit) but increase drag
			// jet should quickly obey the direction of the wings, especially at higher speeds.  At lower speeds there can be some slippage

			// banking:
			// preferably, banking should be pronounced at cruising speed, not so much at turbo speed
			// I assume this is related to how the nose should be dropping at lower speeds

			// trick maneuvers:
			// travelling sideways - at lower speeds craft should slide downward unless compensated with the rudder.  at high speeds this shouldn't be so necessary
			// travelling upside down - at lower speeds craft should slide downward unless compensated with the ailerons.  at high speeds this shouldn't be so necessary

			// take a surface normal against wind approach

			Vector3d velocityAdjustment = Vector3d::ZeroVector();
			velocityAdjustment.y = -p_gravityPerMS2 * p_MS; // accelerate down!

			Vector3d velocityUnit = p_jetVelocityPerMS;
			float angleOfAttack = 0.0f;
			float liftCoefficient = 0.0f;
			// ignore if no velocity or velocity is backwards
			if ((velocityUnit * p_jetOrient.f > 0.0f) && velocityUnit.Normalize() == true)
			{
				Vector3d windAngleVector = p_jetOrient.f.CrossProd(velocityUnit);
				angleOfAttack = MathUtilities::RadiansToDegrees(atan(windAngleVector.Magnitude()));
				if (velocityUnit * p_jetOrient.u > 0.0f)
					angleOfAttack = -angleOfAttack;
				float minimumAngleOfAttack = -5.0f;
				float maximumAngleOfAttack = 20.0f;
				// triangle - past 20 degrees, all lift is gone
				// todo: make this more gradual to dropoff
				if (angleOfAttack >= minimumAngleOfAttack && angleOfAttack <= maximumAngleOfAttack)
				{
					liftCoefficient = angleOfAttack - minimumAngleOfAttack;
				}
				else if (angleOfAttack > maximumAngleOfAttack)
				{
					liftCoefficient = (maximumAngleOfAttack - minimumAngleOfAttack) - (angleOfAttack - maximumAngleOfAttack) * 2.0f;
					if (liftCoefficient < 0.0f)
						liftCoefficient = 0.0f;
				}
			}

			// forward lift, drag, pitch and roll
			float windStrikingFront = (p_jetVelocityPerMS * p_jetOrient.f);
			float forwardDrag = 0.001f; // too high and the jet slows too fast when drop to 0.0.  should be a good balance for airbraking comfortably and coming to a stop - thrust values for appropriate speeds should match this
			if (windStrikingFront > 0.0f)
			{
				// lift the plane a bit (less than blowing upward on the bottom)
				// make 0 degrees lift for 150 mph, -4 degrees lift for 300 mph (300mph will generate 4* lift of 150mph due to v-squared in formula)
				// 0.22 = feet travelled per ms at 155 mph
				// this means a coefficient of 5 should generate a lift such that 0.022*0.022*5*c = gravity (0.0000032174049586) - c = 0.001329506
				float liftAmount = windStrikingFront * windStrikingFront * liftCoefficient * 0.001329506f;
				velocityAdjustment = velocityAdjustment + p_jetOrient.u.ScalarMult(liftAmount);
				// and drag it
				velocityAdjustment = velocityAdjustment - p_jetOrient.f.ScalarMult(windStrikingFront * forwardDrag);

				// spin it on the rudder and drag
				if (p_rudder != 0.0f)
				{
					p_jetOrient.Rotate(p_jetOrient.u, p_rudder * windStrikingFront * 1.6f * p_MS);
					velocityAdjustment = velocityAdjustment - p_jetOrient.f.ScalarMult(windStrikingFront * abs(p_rudder) * 0.00010f);
				}
				// handle ailerons (pitch, roll, drag)
				float pitch = p_leftAileron + p_rightAileron; // -2.0 to 2.0
				float roll = p_rightAileron - p_leftAileron; // -2.0 to 2.0
				if (pitch != 0.0f)
				{
					p_jetOrient.Rotate(p_jetOrient.l, pitch * windStrikingFront * 2.0f * p_MS);
					//velocityAdjustment = velocityAdjustment - p_jetOrient.f.ScalarMult(windStrikingFront * abs(pitch) * 0.00010f);
				}
				if (roll != 0.0f)
				{
					p_jetOrient.Rotate(p_jetOrient.f, -roll * windStrikingFront * 5.0f * p_MS);
					//velocityAdjustment = velocityAdjustment - p_jetOrient.f.ScalarMult(windStrikingFront * abs(roll) * 0.00010f);
				}
			}

			// start with the tip-down
			float windStrikingUnderside = -(p_jetVelocityPerMS * p_jetOrient.u);
			if (windStrikingUnderside > 0.0f)
			{
				// lift the plane (wind push)
				if (liftCoefficient > 0.0f)
				{
					velocityAdjustment = velocityAdjustment + p_jetOrient.u.ScalarMult(windStrikingUnderside * 0.02f); // 0.1111); // 0.002f);
					// tip it towards the wind
					p_jetOrient.Rotate(p_jetOrient.l, -windStrikingUnderside * 1.0f * p_MS);
				}
				else
				{
					velocityAdjustment = velocityAdjustment + p_jetOrient.u.ScalarMult(windStrikingUnderside * 0.001f); // 0.1111); // 0.002f);
					// tip it towards the wind
					p_jetOrient.Rotate(p_jetOrient.l, -windStrikingUnderside * 5.0f * p_MS);
				}
			}

			// and tip up
			float windStrikingUpperSide = p_jetVelocityPerMS * p_jetOrient.u;
			if (windStrikingUpperSide > 0.0f)
			{
				// drop the plane (wind push)
				velocityAdjustment = velocityAdjustment - p_jetOrient.u.ScalarMult(windStrikingUpperSide * 0.0016f);
				// tip it towards the wind
				p_jetOrient.Rotate(p_jetOrient.l, windStrikingUpperSide * 0.90f * p_MS);
			}

			// now the banks
			float windStrikingLeftSide = p_jetVelocityPerMS * p_jetOrient.l;
			if (windStrikingLeftSide > 0.0f)
			{
				// slide the plane a bit (wind push)
				velocityAdjustment = velocityAdjustment - p_jetOrient.l.ScalarMult(windStrikingLeftSide * 0.003f);
				// tip it left
				p_jetOrient.Rotate(p_jetOrient.u, -windStrikingLeftSide * 0.75f * p_MS);
			}

			float windStrikingRightSide = -(p_jetVelocityPerMS * p_jetOrient.l);
			if (windStrikingRightSide > 0.0f)
			{
				// slide the plane a bit (wind push)
				velocityAdjustment = velocityAdjustment + p_jetOrient.l.ScalarMult(windStrikingRightSide * 0.003f);
				// tip it right
				p_jetOrient.Rotate(p_jetOrient.u, windStrikingRightSide * 0.75f * p_MS);
			}

			// apply thrust
			velocityAdjustment = velocityAdjustment + p_jetOrient.f.ScalarMult(p_thrust * 0.00001f * p_MS);

			// apply acceleration
			p_jetVelocityPerMS = p_jetVelocityPerMS + velocityAdjustment;
		}

		void PerformRender() override
		{
			GameContext::Instance->Metrics.RenderedTriangles.Clear();
			GameContext::Instance->Metrics.RenderedLines.Clear();
			GameContext::Instance->Metrics.RenderedPoints.Clear();

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 0, 0));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 2000.0);

			graphics->DefaultTransform();

			// establish camera position
			if (cameraOnJet == true)
			{
				cameraOrient->Set(*jetOrient);
				// todo: place in cockpit area instead of at center
			}
			else
			{
				// make camera point at jet
				Vector3d offset = jetOrient->p - cameraOrient->p;
				if (offset.Normalize())
				{
					cameraOrient->f = offset;
					cameraOrient->l.Set(cameraOrient->f.z, 0.0f, -cameraOrient->f.x);
					cameraOrient->l.Normalize();
					cameraOrient->u = cameraOrient->f.CrossProd(cameraOrient->l);
				}
			}

			// Render skybox and starfield

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// skybox
			graphics->PushMatrix();
			Orient3d skyboxOrient;
			skyboxOrient.LoadIdentity();
			skyboxOrient.p = cameraOrient->p;
			graphics->Transform(skyboxOrient);
			graphics->SetDepthWriteEnabled(false); // todo: push current depth value then pop it later
			dome->Render(*graphics);
			graphics->SetDepthWriteEnabled(true);
			graphics->PopMatrix();

			// starfield
			graphics->PushMatrix();
			// render the starfield with the same world value as the camera point with no depth value
			Orient3d starfieldCameraOrient;
			starfieldCameraOrient.Set(*cameraOrient);
			starfieldCameraOrient.p = Vector3d(0, 0, 0);
			Orient3d starfieldRenderOrient;
			starfieldRenderOrient.LoadIdentity();
			starfieldRenderOrient.p = cameraOrient->p;
			graphics->Transform(starfieldRenderOrient);
			//static Orient3d priorStarfieldCameraOrient = starfieldCameraOrient; // track each render (no way to reset and draw points only in this test)
			graphics->SetDepthWriteEnabled(false); // todo: push current depth value then pop it later
			starField->Render(*graphics, starfieldCameraOrient, priorTrackRef);
			priorStarfieldCameraOrient->Set(starfieldCameraOrient); // track for next time
			priorTrackRef = priorStarfieldCameraOrient;
			graphics->SetDepthWriteEnabled(true);
			graphics->PopMatrix();

			// render the terrain (no transform)
			terrain->Render(*cameraOrient, *graphics, 10, 50.0f);

			if (cameraOnJet == false)
			{
				graphics->PushMatrix();
				graphics->Transform(*jetOrient);
				jet->Render(*graphics);
				graphics->PopMatrix();
			}

			graphics->PushMatrix();
			graphics->Transform(*cubeOrient);
			cube->Render(*graphics);
			graphics->PopMatrix();

			// render text
			graphics->Set2dWindowProjection();
			graphics->SetDepthTestEnabled(false);
			graphics->RenderFont("Air Speed: " + String::Format("{0:0.0} mph", jetVelocity->Magnitude() * 1000 * 3600 * 10.0f / 5280.0f),
				GameContext::Instance->FontRegistry.GetFont("Metrics"),
				10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Metrics")->GetHeight() * 5 - 10),
				GameColor(255, 255, 0));
			graphics->RenderFont("Points: " + Convert::ToString(GameContext::Instance->Metrics.RenderedPoints.GetCount()),
				GameContext::Instance->FontRegistry.GetFont("Metrics"),
				10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Metrics")->GetHeight() * 3 - 10),
				GameColor(255, 255, 0));
			graphics->RenderFont("Lines: " + Convert::ToString(GameContext::Instance->Metrics.RenderedLines.GetCount()),
				GameContext::Instance->FontRegistry.GetFont("Metrics"),
				10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Metrics")->GetHeight() * 2 - 10),
				GameColor(255, 255, 0));
			graphics->RenderFont("Triangles: " + Convert::ToString(GameContext::Instance->Metrics.RenderedTriangles.GetCount()),
				GameContext::Instance->FontRegistry.GetFont("Metrics"), 
				10.0f, float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Metrics")->GetHeight() - 10),
				GameColor(255, 255, 0));
			graphics->SetDepthTestEnabled(true);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class FontTest1 : public GameBase
	{
	public:

		Orient3d *jetOrient;
		Orient3d *cameraOrient;
		Model3d *jet;

		FontTest1(HWND p_hWnd) : GameBase(p_hWnd)
		{
			jetOrient = nullptr;
			cameraOrient = nullptr;
		}

		virtual ~FontTest1()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);
			GameContext::Instance->FontRegistry.RegisterFont("Test1", gcnew System::Drawing::Font("Verdana", 8));
			GameContext::Instance->FontRegistry.RegisterFont("Test2", gcnew System::Drawing::Font("Verdana", 6));
			GameContext::Instance->FontRegistry.RegisterFont("Test3", gcnew System::Drawing::Font("Verdana", 20));
			GameContext::Instance->FontRegistry.RegisterFont("Test3Bold", gcnew System::Drawing::Font("Verdana", 20, System::Drawing::FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("Test4", gcnew System::Drawing::Font("Times New Roman", 20, System::Drawing::FontStyle::Bold));
			GameContext::Instance->FontRegistry.RegisterFont("Test5", gcnew System::Drawing::Font("Comic Sans", 10, System::Drawing::FontStyle::Bold));

			jetOrient = new Orient3d();
			cameraOrient = new Orient3d();
			jetOrient->LoadIdentity();
			cameraOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);
			// move the jet forward and over
			jetOrient->p = jetOrient->p + jetOrient->f.ScalarMult(7.0f);// +jetOrient->l.ScalarMult(-2.5f);

			jetOrient->Rotate(jetOrient->u, 180.0f);

			jet = new Model3d();
			jet->MakeJet();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				jetOrient->Rotate(jetOrient->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				jetOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				jetOrient->Rotate(jetOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(*jetOrient);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

			graphics->Set2dWindowProjection();
			graphics->SetDepthTestEnabled(false);
			graphics->RenderFont("1234567890!@#$%^&*()qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:", GameContext::Instance->FontRegistry.GetFont("Test1"), 20, 20, GameColor(255, 255, 255));
			graphics->RenderFont("1234567890!@#$%^&*()qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:", GameContext::Instance->FontRegistry.GetFont("Test2"), 20, 40, GameColor(255, 255, 255));
			graphics->RenderFont("1234567890!@#$%^&*()qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:", GameContext::Instance->FontRegistry.GetFont("Test3"), 20, 70, GameColor(255, 255, 255));
			graphics->RenderFont("1234567890!@#$%^&*()qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:", GameContext::Instance->FontRegistry.GetFont("Test3Bold"), 20, 100, GameColor(255, 255, 255));
			graphics->RenderFont("1234567890!@#$%^&*()qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:", GameContext::Instance->FontRegistry.GetFont("Test4"), 20, 130, GameColor(255, 255, 255));
			graphics->RenderFont("1234567890!@#$%^&*()qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:", GameContext::Instance->FontRegistry.GetFont("Test5"), 20, 160, GameColor(255, 255, 255));

			graphics->RenderFont("This is a test string.", GameContext::Instance->FontRegistry.GetFont("Test2"), 20, 200, GameColor(255, 255, 0));
			graphics->RenderFont("iiiiiii", GameContext::Instance->FontRegistry.GetFont("Test2"), 20, 220, GameColor(255, 255, 0));
			graphics->RenderFont("WWWWWW", GameContext::Instance->FontRegistry.GetFont("Test2"), 20, 240, GameColor(255, 255, 0));

			graphics->RenderFont("Ew, Comic Sans!", GameContext::Instance->FontRegistry.GetFont("Test5"), 20, 270, GameColor(255, 255, 255, 128));

			graphics->RenderFont("Faded Black Verdana 8", GameContext::Instance->FontRegistry.GetFont("Test1"), 20, 300, GameColor(0, 0, 0, 64));
			graphics->RenderFont("Solid Red Verdana 6", GameContext::Instance->FontRegistry.GetFont("Test2"), 20, 320, GameColor(255, 0, 0, 255));
			graphics->RenderFont("Ghost Cyan Verdana 20", GameContext::Instance->FontRegistry.GetFont("Test3"), 20, 340, GameColor(0, 255, 255, 128));
			graphics->RenderFont("Ghost Cyan Bold Verdana 20", GameContext::Instance->FontRegistry.GetFont("Test3Bold"), 20, 370, GameColor(0, 255, 255, 128));
			graphics->RenderFont("Yellow Times New Roman", GameContext::Instance->FontRegistry.GetFont("Test4"), 20, 400, GameColor(255, 255, 0));
			graphics->RenderFont("Faded Green Comic Sans", GameContext::Instance->FontRegistry.GetFont("Test5"), 20, 430, GameColor(0, 255, 0, 64));

			graphics->SetDepthTestEnabled(true);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class TestNativeObject : public GameBase
	{
		enum class RenderMode
		{
			Mesh,
			NativeObject
		};

	public:

		Orient3d *meshOrient;
		Orient3d *cameraOrient;
		Model3d *mesh;
		RenderMode renderMode;
		GraphicsNativeObjectContainer *meshNativeRef;

		TestNativeObject(HWND p_hWnd) : GameBase(p_hWnd)
		{
			meshOrient = nullptr;
			cameraOrient = nullptr;
			mesh = nullptr;
			renderMode = RenderMode::Mesh;
			meshNativeRef = nullptr;
		}

		virtual ~TestNativeObject()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = nullptr;
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("CheckerBoard", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			// just testing alpha textures with shaders (if only alpha, renders as black color)
			GameContext::Instance->TextureRegistry.RegisterTexture("SmokePuff1", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::WhiteColorAlphaRed, GameContext::Instance->FileRegistry.RegisterFileResource("SmokePuff1.jpg"));

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			meshOrient = new Orient3d();
			cameraOrient = new Orient3d();
			meshOrient->LoadIdentity();
			cameraOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(10.0f);
			// move the jet forward and over
			meshOrient->p = meshOrient->p + meshOrient->f.ScalarMult(200.0f);
			// turn it towards the camera
			meshOrient->Rotate(meshOrient->l, 90.0f);

			mesh = MakeMesh(GameContext::Instance->TextureRegistry.GetTexture("CheckerBoard"));

			GameBase::Initialize(); // call base initialize too.
		}

		Model3d * MakeMesh(GameTexture ^p_texture)
		{
			// make a square mesh

			Model3d *result = new Model3d();
			
			float meshCellDimension = 400.0f; // how many vertices to a side? (total triangle quantity = (dimension-1) squared * 2) - must be at least 2
			// 800 (1.28 mil) and 1600 (5.12 mil) both render at 36 fps (not rebooted)
			// drawing 4 figures at 800 yields similar results
			// problem for later: 1000x1000 takes a LONG time to remove from memory because there are 2 million surface arrays.  Might need to find a different strategy.  For now, 200 is ok for testing.
			// good solution: set up like OpenGL's arrays - establish a long string of indices that are known to be triangles so that the loop takes them in 3's.  Quads would have to be a different list
			float meshSizeDimension = 100.0f; // how long is a side in world value?
			result->Initialize(1, int(meshCellDimension *meshCellDimension), int((meshCellDimension - 1) *(meshCellDimension - 1)) * 2);

			// set color
			result->GetColor(0)->Set(255, 255, 255, 255);

			// set x, y, z for vertices
			// define indices from lower right to upper left
			// 
			// -------- cellDim *2 etc.
			//			cellDim
			//			0
			// -------- z
			//  2 1 0 x
			for (int xIndex = 0; xIndex < int(meshCellDimension); xIndex++)
			{
				for (int zIndex = 0; zIndex < int(meshCellDimension); zIndex++)
				{
					result->GetVertex(zIndex * int(meshCellDimension) + xIndex)->colorIndex = 0;
					result->GetVertex(zIndex * int(meshCellDimension) + xIndex)->vertex.Set(-meshSizeDimension / 2.0f + (meshCellDimension-1.0f - float(xIndex)) / (meshCellDimension-1.0f) * meshSizeDimension, 0.0f, -meshSizeDimension / 2.0f + (meshCellDimension-1.0f - float(zIndex)) / (meshCellDimension-1.0f) * meshSizeDimension);

					if (xIndex < int(meshCellDimension) - 1 && zIndex < int(meshCellDimension) - 1)
					{
						// define the two surfaces for the cell that uses this vertex as its lower right
						// surface 0 and 1 for the first cell, 2 and 3 for the next, starting with surface cellDim * 2 and +1 on the next z row, etc.

						int lowerRightVertexIndex = (zIndex * int(meshCellDimension) + xIndex);
						int surfaceIndex = (zIndex * int(meshCellDimension-1) + xIndex) * 2;

						ModelSurface *surface = result->GetSurface(surfaceIndex);
						surface->Initialize(3);
						surface->SetVertexIndex(0, lowerRightVertexIndex);
						surface->SetVertexIndex(1, lowerRightVertexIndex+1);
						surface->SetVertexIndex(2, lowerRightVertexIndex + int(meshCellDimension));
						surface->SetTexture0(p_texture);
						surface->SetVertexTexCoords(0, float(xIndex) / float(meshCellDimension - 1.0f), float(zIndex) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(1, float(xIndex+1) / float(meshCellDimension - 1.0f), float(zIndex) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(2, float(xIndex) / float(meshCellDimension - 1.0f), float(zIndex+1) / float(meshCellDimension - 1.0f));

						surface = result->GetSurface(surfaceIndex + 1);
						surface->Initialize(3);
						surface->SetVertexIndex(0, lowerRightVertexIndex + 1);
						surface->SetVertexIndex(1, lowerRightVertexIndex + 1 + int(meshCellDimension));
						surface->SetVertexIndex(2, lowerRightVertexIndex + int(meshCellDimension));
						surface->SetTexture0(p_texture);
						surface->SetVertexTexCoords(0, float(xIndex+1) / float(meshCellDimension - 1.0f), float(zIndex) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(1, float(xIndex + 1) / float(meshCellDimension - 1.0f), float(zIndex+1) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(2, float(xIndex) / float(meshCellDimension - 1.0f), float(zIndex + 1) / float(meshCellDimension - 1.0f));
					}
				}
			}

			return result;
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (mesh != nullptr)
			{
				delete mesh;
				mesh = nullptr;
			}
			if (meshNativeRef != nullptr)
			{
				Trace::WriteLine(String::Format("Destroying Native pointer: {0}", int(meshNativeRef)));
				delete meshNativeRef;
				meshNativeRef = nullptr;
			}
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank mesh according to x offset (number of degrees), always on orient.f vector
				meshOrient->Rotate(meshOrient->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw mesh according to x offset (number of degrees), always on 0,1,0 vector
				meshOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch mesh according to y offset (number of degrees), always on l vector
				meshOrient->Rotate(meshOrient->l, float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			if (keyboardKeys.GetKey(113)->clicked)
			{
				if (renderMode == RenderMode::Mesh)
					renderMode = RenderMode::NativeObject;
				else
					renderMode = RenderMode::Mesh;

				keyboardKeys.GetKey(113)->ClearClicked();
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			Matrix4d mvpMatrix = graphics->GetMVPMatrix();

			// render mesh
			Vector3d oldP = meshOrient->p;
			bool useLoop = false;
			int maxLoop = 1;
			if (useLoop == true)
				maxLoop = 4;
			for (int i = 0; i < maxLoop; i++)
			{
				if (useLoop == true)
				{
					switch (i)
					{
					case 0:
						meshOrient->p.x += 50.0f;
						meshOrient->p.y -= 50.0f;
						break;
					case 1:
						meshOrient->p.y += 100.0f;
						break;
					case 2:
						meshOrient->p.x -= 100.0f;
						break;
					case 3:
						meshOrient->p.y -= 100.0f;
						break;
					}
				}
				graphics->PushMatrix();
				graphics->Transform(*meshOrient);
				switch (renderMode)
				{
				case RenderMode::Mesh:
					mesh->Render(*graphics);
					break;
				case RenderMode::NativeObject:
				{
					if (meshNativeRef == nullptr)
						meshNativeRef = new GraphicsNativeObjectContainer();
					if (meshNativeRef->nativeObjectRef == nullptr)
						graphics->CreateNativeObject(meshNativeRef, mesh->GetColors(), mesh->GetColorQty(), mesh->GetVertices(), mesh->GetVertexQty(), mesh->GetSurfaces(), mesh->GetSurfaceQty());

					GraphicsShaderOptions shaderOptions;
					// go with defaults for model but still set number of lights, matrix, etc.
					//shaderOptions.texture1Ref = mesh->GetSurface(0)->GetTexture();
					//shaderOptions.singleColorRef = mesh->GetColor(0);
					// todo: mvp matrix
					shaderOptions.eyeMVPMatrixRef = &mvpMatrix;
					shaderOptions.modelWorldOrientRef = meshOrient;
					GameColor singleColor(255, 255, 192); // change color
					shaderOptions.singleColorRef = &singleColor;
					graphics->RenderNativeObject(meshNativeRef, shaderOptions);
				}
				break;
				}
				graphics->PopMatrix();

				if (useLoop == true && i == maxLoop - 1)
				{
					meshOrient->p = oldP;
				}
			}

			graphics->Set2dWindowProjection();
			switch (renderMode)
			{
			case RenderMode::Mesh:
				graphics->RenderFont("CPU Mesh", GameContext::Instance->FontRegistry.GetFont("Info"), 20, GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 3, GameColor(255, 255, 0));
				break;
			case RenderMode::NativeObject:
				graphics->RenderFont("Native Mesh", GameContext::Instance->FontRegistry.GetFont("Info"), 20, GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 3, GameColor(255, 255, 0));
				break;
			}

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class TestShader : public GameBase
	{
	public:

		Orient3d *cubeOrient;
		Orient3d *cameraOrient;
		Model3d *cube;
		Orient3d *baseQuadOrient, *texturedQuadOrient, *mapTextureQuadOrient, *texture1QuadOrient, *texture2QuadOrient, *texture3QuadOrient, *texture4QuadOrient, *blendedQuadOrient;

		TestShader(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cubeOrient = nullptr;
			cameraOrient = nullptr;
			baseQuadOrient = nullptr;
			texturedQuadOrient = nullptr;
			mapTextureQuadOrient = nullptr;
			texture1QuadOrient = nullptr;
			texture2QuadOrient = nullptr;
			texture3QuadOrient = nullptr;
			texture4QuadOrient = nullptr;
			blendedQuadOrient = nullptr;
		}

		virtual ~TestShader()
		{
			Destroy();
		}


		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = nullptr;
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("CheckerBoard", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("MapTexture.png"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("MapTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("rocktexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("RockTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			// just bit testing on textures (see red below for results)
			GameContext::Instance->TextureRegistry.RegisterTexture("RockTexture16", GameTextureInternalFormatEnum::RGBA16, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("RockTexture8", GameTextureInternalFormatEnum::RGBA8, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("dirt1.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("DirtTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("Grass_Meadows2.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("GrassTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("icetexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("IceTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("Red_148.bmp"); // no subfolder for now
			// just bit testing on texture (RGBA is loaded fully accurate, 16 bit copies upper 4 bits down to lower 4 bits to keep colors close, and 8 bit loaded from a prepared integer source uploads as 16bit)
			GameContext::Instance->TextureRegistry.RegisterTexture("Red148", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("Red148_16", GameTextureInternalFormatEnum::RGBA16, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("Red148_8", GameTextureInternalFormatEnum::RGBA8, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			cubeOrient = new Orient3d();
			cameraOrient = new Orient3d();
			cubeOrient->LoadIdentity();
			cameraOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(10.0f);
			// move the jet forward and over
			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(7.0f) + cubeOrient->l.ScalarMult(2.5f);

			cubeOrient->Rotate(cubeOrient->u, 180.0f);

			baseQuadOrient = new Orient3d();
			texturedQuadOrient = new Orient3d();
			mapTextureQuadOrient = new Orient3d();
			texture1QuadOrient = new Orient3d();
			texture2QuadOrient = new Orient3d();
			texture3QuadOrient = new Orient3d();
			texture4QuadOrient = new Orient3d();
			blendedQuadOrient = new Orient3d();

			baseQuadOrient->LoadIdentity();
			texturedQuadOrient->LoadIdentity();
			mapTextureQuadOrient->LoadIdentity();
			texture1QuadOrient->LoadIdentity();
			texture2QuadOrient->LoadIdentity();
			texture3QuadOrient->LoadIdentity();
			texture4QuadOrient->LoadIdentity();
			blendedQuadOrient->LoadIdentity();

			baseQuadOrient->p = baseQuadOrient->p + baseQuadOrient->l.ScalarMult(5.0f) + texture3QuadOrient->u.ScalarMult(1.5f);
			texturedQuadOrient->p = texturedQuadOrient->p + texturedQuadOrient->l.ScalarMult(2.5f) + texture3QuadOrient->u.ScalarMult(1.5f);
			mapTextureQuadOrient->p = mapTextureQuadOrient->p + mapTextureQuadOrient->l.ScalarMult(0.0f) + texture3QuadOrient->u.ScalarMult(1.5f);
			texture1QuadOrient->p = texture1QuadOrient->p + texture1QuadOrient->l.ScalarMult(-2.5f) + texture3QuadOrient->u.ScalarMult(1.5f);
			texture2QuadOrient->p = texture2QuadOrient->p + texture2QuadOrient->l.ScalarMult(-5.0f) + texture3QuadOrient->u.ScalarMult(1.5f);
			texture3QuadOrient->p = texture3QuadOrient->p + texture3QuadOrient->l.ScalarMult(5.0f) + texture3QuadOrient->u.ScalarMult(-1.5f);
			texture4QuadOrient->p = texture4QuadOrient->p + texture4QuadOrient->l.ScalarMult(2.5f) + texture3QuadOrient->u.ScalarMult(-1.5f);
			blendedQuadOrient->p = blendedQuadOrient->p + blendedQuadOrient->l.ScalarMult(0.0f) + texture3QuadOrient->u.ScalarMult(-1.5f);

			cube = new Model3d();
			cube->MakeCube();
			// give it a texture, make front face white to make it pure
			cube->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("CheckerBoard"));
			cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			cube->GetSurface(0)->SetVertexTexCoords(1, 0.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(3, 1.0f, 1.0f);
			cube->GetColor(0)->Set(255, 255, 255);
			cube->GetColor(1)->Set(255, 255, 255);
			cube->GetColor(2)->Set(255, 255, 255);
			cube->GetColor(3)->Set(255, 255, 255);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}

			if (baseQuadOrient != nullptr)
			{
				delete baseQuadOrient;
				baseQuadOrient = nullptr;
			}
			if (texturedQuadOrient != nullptr)
			{
				delete texturedQuadOrient;
				texturedQuadOrient = nullptr;
			}
			if (mapTextureQuadOrient != nullptr)
			{
				delete mapTextureQuadOrient;
				mapTextureQuadOrient = nullptr;
			}
			if (texture1QuadOrient != nullptr)
			{
				delete texture1QuadOrient;
				texture1QuadOrient = nullptr;
			}
			if (texture2QuadOrient != nullptr)
			{
				delete texture2QuadOrient;
				texture2QuadOrient = nullptr;
			}
			if (texture3QuadOrient != nullptr)
			{
				delete texture3QuadOrient;
				texture3QuadOrient = nullptr;
			}
			if (texture4QuadOrient != nullptr)
			{
				delete texture4QuadOrient;
				texture4QuadOrient = nullptr;
			}
			if (blendedQuadOrient != nullptr)
			{
				delete blendedQuadOrient;
				blendedQuadOrient = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				cubeOrient->Rotate(cubeOrient->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			//graphics->PushMatrix();
			//// forward transform the cube
			//graphics->Transform(*cubeOrient);
			//// render the cube
			//cube->Render(*graphics);
			//graphics->PopMatrix();

			GameColor colorsRGB[4] = { GameColor(255, 255, 255), GameColor(255, 0, 0), GameColor(0, 255, 0), GameColor(0, 0, 255) };
			GameColor colorsWhite[4] = { GameColor(255, 255, 255), GameColor(255, 255, 255), GameColor(255, 255, 255), GameColor(255, 255, 255) };
			ModelVertex vertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 1), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 2), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 3) };

			// base quad
			graphics->PushMatrix();
			graphics->Transform(*baseQuadOrient);
			graphics->RenderFilledQuad(colorsRGB, 4, vertices, 4, false, nullptr);
			graphics->PopMatrix();

			// textured quad
			graphics->PushMatrix();
			graphics->Transform(*texturedQuadOrient);
			graphics->RenderFilledQuad(colorsRGB, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("CheckerBoard"));
			graphics->PopMatrix();

			// map quad
			graphics->PushMatrix();
			graphics->Transform(*mapTextureQuadOrient);
			graphics->RenderFilledQuad(colorsWhite, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("MapTexture"));
			graphics->PopMatrix();

			// texture1 quad
			graphics->PushMatrix();
			graphics->Transform(*texture1QuadOrient);
			graphics->RenderFilledQuad(colorsWhite, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("RockTexture"));
			graphics->PopMatrix();

			// texture2 quad
			graphics->PushMatrix();
			graphics->Transform(*texture2QuadOrient);
			graphics->RenderFilledQuad(colorsWhite, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("DirtTexture"));
			graphics->PopMatrix();

			// texture3 quad
			graphics->PushMatrix();
			graphics->Transform(*texture3QuadOrient);
			graphics->RenderFilledQuad(colorsWhite, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("GrassTexture"));
			graphics->PopMatrix();

			// texture4 quad
			graphics->PushMatrix();
			graphics->Transform(*texture4QuadOrient);
			//graphics->RenderFilledQuad(colorsWhite, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("Red148_8"));
			graphics->RenderFilledQuad(colorsWhite, 4, vertices, 4, false, GameContext::Instance->TextureRegistry.GetTexture("IceTexture"));
			graphics->PopMatrix();

			// blended quad
			graphics->PushMatrix();
			graphics->Transform(*blendedQuadOrient);
			GraphicsShaderOptions shaderOptions;
			shaderOptions.texture0Ref = GameContext::Instance->TextureRegistry.GetTexture("RockTexture");
			shaderOptions.texture1Ref = GameContext::Instance->TextureRegistry.GetTexture("DirtTexture");
			shaderOptions.texture2Ref = GameContext::Instance->TextureRegistry.GetTexture("GrassTexture");
			//shaderOptions.texture3Ref = GameContext::Instance->TextureRegistry.GetTexture("IceTexture");
			shaderOptions.textureBlendMapRef = GameContext::Instance->TextureRegistry.GetTexture("MapTexture");
			Matrix4d mvpMatrix = graphics->GetMVPMatrix();
			shaderOptions.eyeMVPMatrixRef = &mvpMatrix;
			graphics->RenderQuadShader(colorsWhite, 4, vertices, 4, shaderOptions);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class TestGLShader : public GameBase
	{
	public:
		GLuint vaoId, elementArrayId;
		GLuint programId;
		HDC glDC;
		HGLRC glRC;
		HWND hWnd;

		// extension routines (glext.h)
		PFNGLGETPROGRAMIVPROC glGetProgramiv;
		PFNGLGETPROGRAMINFOLOGPROC glGetProgramInfoLog;
		PFNGLDELETEPROGRAMPROC glDeleteProgram;
		PFNGLCREATEPROGRAMPROC glCreateProgram;
		PFNGLATTACHSHADERPROC glAttachShader;
		PFNGLDELETESHADERPROC glDeleteShader;
		PFNGLCREATESHADERPROC glCreateShader;
		PFNGLSHADERSOURCEPROC glShaderSource;
		PFNGLGETSHADERIVPROC glGetShaderiv;
		PFNGLGETSHADERINFOLOGPROC glGetShaderInfoLog;
		PFNGLGETUNIFORMLOCATIONPROC glGetUniformLocation;
		PFNGLUSEPROGRAMPROC glUseProgram;
		PFNGLUNIFORM3FVARBPROC glUniform3fvARB;
		PFNGLLINKPROGRAMPROC glLinkProgram;
		PFNGLCOMPILESHADERPROC glCompileShader;
		PFNGLDELETEBUFFERSPROC glDeleteBuffers;
		PFNGLDELETEVERTEXARRAYSPROC glDeleteVertexArrays;
		PFNGLGENBUFFERSPROC glGenBuffers;
		PFNGLBINDBUFFERPROC glBindBuffer;
		PFNGLBUFFERDATAPROC glBufferData;
		PFNGLGENVERTEXARRAYSPROC glGenVertexArrays;
		PFNGLBINDVERTEXARRAYPROC glBindVertexArray;
		PFNGLENABLEVERTEXATTRIBARRAYPROC glEnableVertexAttribArray;
		PFNGLVERTEXATTRIBPOINTERPROC glVertexAttribPointer;
		// uniform
		PFNGLUNIFORM4FVPROC glUniform4fv;
		PFNGLUNIFORMMATRIX4FVPROC glUniformMatrix4fv;

		// wglext.h
		PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB;

		TestGLShader(HWND p_hWnd) : GameBase(p_hWnd)
		{
			vaoId = 0;
			programId = 0;

			glGetProgramiv = nullptr;
			glGetProgramInfoLog = nullptr;
			glDeleteProgram = nullptr;
			glCreateProgram = nullptr;
			glAttachShader = nullptr;
			glDeleteShader = nullptr;
			glCreateShader = nullptr;
			glShaderSource = nullptr;
			glGetShaderiv = nullptr;
			glGetShaderInfoLog = nullptr;
			glGetUniformLocation = nullptr;
			glUseProgram = nullptr;
			glUniform3fvARB = nullptr;
			glLinkProgram = nullptr;
			glCompileShader = nullptr;
			glDeleteBuffers = nullptr;
			glGenBuffers = nullptr;
			glBindBuffer = nullptr;
			glBufferData = nullptr;
			glGenVertexArrays = nullptr;
			glBindVertexArray = nullptr;
			glEnableVertexAttribArray = nullptr;
			glVertexAttribPointer = nullptr;
			glUniform4fv = nullptr;
			glUniformMatrix4fv = nullptr;
			wglCreateContextAttribsARB = nullptr;
		}

		virtual ~TestGLShader()
		{
			Destroy();
		}

		void Initialize() override
		{
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				InitializeGL(
					GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWindowHandle(),
					GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth(),
					GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight());
			SetupVAO();
			CompileShaderProgram();

			GameBase::Initialize(); // call base initialize too.
		}

		void InitializeGL(HWND p_hWnd, int p_viewportWidth, int p_viewportHeight);
		void GetExtensionRoutines();
		void CompileShaderProgram();
		void SetupVAO();
		void ClearScreen(GameColor &p_color);
		void RenderVAO();
		void SwapBuffers();
		void DestroyGLObjects();

		void DestroyGameData()
		{
		}

		void Destroy() override
		{
			DestroyGLObjects();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			return true;
		}

		void PerformRender() override
		{
			ClearScreen(GameColor(128, 128, 128));
			RenderVAO();
			SwapBuffers();
		}

	};

	public ref class TestLighting : public GameBase
	{
	public:

		Orient3d *cameraOrient;
		Orient3d *vertexLightQuadOrient;
		Orient3d *fragmentLightQuadOrient;
		Orient3d *meshOrient;
		Orient3d *bumpMapOrient;
		Orient3d *brickQuadOrient;
		Orient3d *bumpMapOrient2;
		Orient3d *light1Orient;
		Orient3d *light2Orient;
		Orient3d *light3Orient;
		Orient3d *light4Orient;
		Orient3d *light5Orient;
		Orient3d *light6Orient;
		Model3d *mesh;

		GraphicsNativeObjectContainer *vertexLightQuadNativeObject;
		GraphicsNativeObjectContainer *fragmentLightQuadNativeObject;
		GraphicsNativeObjectContainer *meshNativeObject;
		GraphicsNativeObjectContainer *bumpMapNativeObject;
		GraphicsNativeObjectContainer *bumpMap2NativeObject;

		Model3d *cube; // for debugging

		GameTexture ^bumpMapTexture;

		TestLighting(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;
			vertexLightQuadOrient = nullptr;
			fragmentLightQuadOrient = nullptr;
			meshOrient = nullptr;
			bumpMapOrient = nullptr;
			brickQuadOrient = nullptr;
			bumpMapOrient2 = nullptr;
			vertexLightQuadNativeObject = nullptr;
			fragmentLightQuadNativeObject = nullptr;
			meshNativeObject = nullptr;
			bumpMapNativeObject = nullptr;
			bumpMap2NativeObject = nullptr;
			light1Orient = nullptr;
			light2Orient = nullptr;
			light3Orient = nullptr;
			light4Orient = nullptr;
			light5Orient = nullptr;
			light6Orient = nullptr;
			cube = nullptr;
			mesh = nullptr;
			bumpMapTexture = nullptr;
		}

		virtual ~TestLighting()
		{
			Destroy();
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		void Initialize() override
		{
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Checkerboard", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("checkerboard_o.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("rocktexture.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Rock", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("rocktexture.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brickwork-texture.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brickwork-texture.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brickwork_normal-map.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("BrickBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brickwork_normal-map.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick2_normal_map.png");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2_normal_map.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick3.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick3", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick3.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick3_norm.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick3BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick3_norm.jpg"));

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(-10.0f);

			vertexLightQuadOrient = new Orient3d();
			vertexLightQuadOrient->LoadIdentity();
			vertexLightQuadOrient->p = vertexLightQuadOrient->p + vertexLightQuadOrient->l.ScalarMult(3.5f) + vertexLightQuadOrient->u.ScalarMult(1.8f);
			fragmentLightQuadOrient = new Orient3d();
			fragmentLightQuadOrient->LoadIdentity();
			fragmentLightQuadOrient->p = fragmentLightQuadOrient->p + fragmentLightQuadOrient->l.ScalarMult(3.5f) + fragmentLightQuadOrient->u.ScalarMult(-1.8f);
			meshOrient = new Orient3d();
			meshOrient->LoadIdentity();
			meshOrient->p = meshOrient->p + meshOrient->l.ScalarMult(0.0f) + meshOrient->u.ScalarMult(1.8f);
			meshOrient->Rotate(meshOrient->l, 90.0f);
			bumpMapOrient = new Orient3d();
			bumpMapOrient->LoadIdentity();
			bumpMapOrient->p = bumpMapOrient->p + bumpMapOrient->l.ScalarMult(0.0f) + bumpMapOrient->u.ScalarMult(-1.8f);
			brickQuadOrient = new Orient3d();
			brickQuadOrient->LoadIdentity();
			brickQuadOrient->p = brickQuadOrient->p + brickQuadOrient->l.ScalarMult(-3.5f) + brickQuadOrient->u.ScalarMult(1.8f);
			bumpMapOrient2 = new Orient3d();
			bumpMapOrient2->LoadIdentity();
			bumpMapOrient2->p = bumpMapOrient2->p + bumpMapOrient2->l.ScalarMult(-3.5f) + bumpMapOrient2->u.ScalarMult(-1.8f);

			light1Orient = new Orient3d();
			light1Orient->LoadIdentity();
			light1Orient->p = vertexLightQuadOrient->p - light1Orient->f.ScalarMult(2.0f);
			light2Orient = new Orient3d();
			light2Orient->LoadIdentity();
			light2Orient->p = fragmentLightQuadOrient->p - light2Orient->f.ScalarMult(2.0f);
			light3Orient = new Orient3d();
			light3Orient->LoadIdentity();
			light3Orient->p = meshOrient->p - light3Orient->f.ScalarMult(2.0f);
			light4Orient = new Orient3d();
			light4Orient->LoadIdentity();
			light4Orient->p = bumpMapOrient->p - light4Orient->f.ScalarMult(2.0f);
			light5Orient = new Orient3d();
			light5Orient->LoadIdentity();
			light5Orient->p = brickQuadOrient->p - light5Orient->f.ScalarMult(2.0f);
			light6Orient = new Orient3d();
			light6Orient->LoadIdentity();
			light6Orient->p = bumpMapOrient2->p - light6Orient->f.ScalarMult(2.0f);

			vertexLightQuadNativeObject = new GraphicsNativeObjectContainer();
			fragmentLightQuadNativeObject = new GraphicsNativeObjectContainer();
			meshNativeObject = new GraphicsNativeObjectContainer();
			bumpMapNativeObject = new GraphicsNativeObjectContainer();
			bumpMap2NativeObject = new GraphicsNativeObjectContainer();

			cube = new Model3d();
			cube->MakeCube();

			int dimension = 40;
			mesh = MakeMesh(3.0f, dimension);

			int height = dimension;
			int width = dimension;
			bumpMapTexture = gcnew GameTexture(width, height, GameTextureInternalFormatEnum::RGB); // normal maps are RGB.
			for (int h = 0; h < width; h++)
			{
				for (int v = 0; v < height; v++)
				{
					unsigned char *pixel = bumpMapTexture->GetTexelPointer(h, v);
					ModelVertex *vertex = mesh->GetVertex(v * dimension + h);
					pixel[0] = unsigned char(127.5f * -vertex->normal.x + 127.5f); // always reverse red.  standard for bumps (positve red faces right, positive green faces up)
					pixel[1] = unsigned char(127.5f * vertex->normal.z + 127.5f);
					pixel[2] = unsigned char(127.5f * vertex->normal.y + 127.5f);
				}
			}
		}

		Model3d * MakeMesh(float p_sizeDimension, int p_cellSideQty)
		{
			// make a square mesh

			Model3d *result = new Model3d();

			float meshCellDimension = float(p_cellSideQty); // how many vertices to a side? (total triangle quantity = (dimension-1) squared * 2) - must be at least 2
			// 800 (1.28 mil) and 1600 (5.12 mil) both render at 36 fps (not rebooted)
			// drawing 4 figures at 800 yields similar results
			// problem for later: 1000x1000 takes a LONG time to remove from memory because there are 2 million surface arrays.  Might need to find a different strategy.  For now, 200 is ok for testing.
			// good solution: set up like OpenGL's arrays - establish a long string of indices that are known to be triangles so that the loop takes them in 3's.  Quads would have to be a different list
			float meshSizeDimension = p_sizeDimension; // how long is a side in world value?
			result->Initialize(1, int(meshCellDimension *meshCellDimension), int((meshCellDimension - 1) *(meshCellDimension - 1)) * 2);

			// set color
			result->GetColor(0)->Set(255, 255, 255, 255);

			// set x, y, z for vertices
			// define indices from lower right to upper left
			// 
			// -------- cellDim *2 etc.
			//			cellDim
			//			0
			// -------- z
			//  2 1 0 x
			for (int xIndex = 0; xIndex < int(meshCellDimension); xIndex++)
			{
				for (int zIndex = 0; zIndex < int(meshCellDimension); zIndex++)
				{
					result->GetVertex(zIndex * int(meshCellDimension) + xIndex)->colorIndex = 0;
					float yValue = 0.0f;
					result->GetVertex(zIndex * int(meshCellDimension) + xIndex)->vertex.Set(-meshSizeDimension / 2.0f + (meshCellDimension - 1.0f - float(xIndex)) / (meshCellDimension - 1.0f) * meshSizeDimension, yValue, -meshSizeDimension / 2.0f + (meshCellDimension - 1.0f - float(zIndex)) / (meshCellDimension - 1.0f) * meshSizeDimension);
					Vector3d *vertex = &result->GetVertex(zIndex * int(meshCellDimension) + xIndex)->vertex;
					float angleFactor = (2.0f * MathConstants::Pi()) / (p_sizeDimension / 4.0f);
					vertex->y = p_sizeDimension / 48.0f * sin(vertex->x * angleFactor) * cos(vertex->z * angleFactor); // make it wave 4 times with a little depth

					if (xIndex < int(meshCellDimension) - 1 && zIndex < int(meshCellDimension) - 1)
					{
						// define the two surfaces for the cell that uses this vertex as its lower right
						// surface 0 and 1 for the first cell, 2 and 3 for the next, starting with surface cellDim * 2 and +1 on the next z row, etc.

						int lowerRightVertexIndex = (zIndex * int(meshCellDimension) + xIndex);
						int surfaceIndex = (zIndex * int(meshCellDimension - 1) + xIndex) * 2;

						ModelSurface *surface = result->GetSurface(surfaceIndex);
						surface->Initialize(3);
						surface->SetVertexIndex(0, lowerRightVertexIndex);
						surface->SetVertexIndex(1, lowerRightVertexIndex + 1);
						surface->SetVertexIndex(2, lowerRightVertexIndex + int(meshCellDimension));
						surface->SetTexture0(GameContext::TextureRegistry.GetTexture("Rock"));
						surface->SetVertexTexCoords(0, float(xIndex) / float(meshCellDimension - 1.0f), float(zIndex) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(1, float(xIndex + 1) / float(meshCellDimension - 1.0f), float(zIndex) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(2, float(xIndex) / float(meshCellDimension - 1.0f), float(zIndex + 1) / float(meshCellDimension - 1.0f));

						surface = result->GetSurface(surfaceIndex + 1);
						surface->Initialize(3);
						surface->SetVertexIndex(0, lowerRightVertexIndex + 1);
						surface->SetVertexIndex(1, lowerRightVertexIndex + 1 + int(meshCellDimension));
						surface->SetVertexIndex(2, lowerRightVertexIndex + int(meshCellDimension));
						surface->SetTexture0(GameContext::TextureRegistry.GetTexture("Rock"));
						surface->SetVertexTexCoords(0, float(xIndex + 1) / float(meshCellDimension - 1.0f), float(zIndex) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(1, float(xIndex + 1) / float(meshCellDimension - 1.0f), float(zIndex + 1) / float(meshCellDimension - 1.0f));
						surface->SetVertexTexCoords(2, float(xIndex) / float(meshCellDimension - 1.0f), float(zIndex + 1) / float(meshCellDimension - 1.0f));
					}
				}
			}

			result->CalculateNormals();

			return result;
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (vertexLightQuadOrient != nullptr)
			{
				delete vertexLightQuadOrient;
				vertexLightQuadOrient = nullptr;
			}
			if (fragmentLightQuadOrient != nullptr)
			{
				delete fragmentLightQuadOrient;
				fragmentLightQuadOrient = nullptr;
			}
			if (meshOrient != nullptr)
			{
				delete meshOrient;
				meshOrient = nullptr;
			}
			if (bumpMapOrient != nullptr)
			{
				delete bumpMapOrient;
				bumpMapOrient = nullptr;
			}
			if (bumpMapOrient2 != nullptr)
			{
				delete bumpMapOrient2;
				bumpMapOrient2 = nullptr;
			}
			if (brickQuadOrient != nullptr)
			{
				delete brickQuadOrient;
				brickQuadOrient = nullptr;
			}
			if (vertexLightQuadNativeObject != nullptr)
			{
				delete vertexLightQuadNativeObject;
				vertexLightQuadNativeObject = nullptr;
			}
			if (fragmentLightQuadNativeObject != nullptr)
			{
				delete fragmentLightQuadNativeObject;
				fragmentLightQuadNativeObject = nullptr;
			}
			if (meshNativeObject != nullptr)
			{
				delete meshNativeObject;
				meshNativeObject = nullptr;
			}
			if (bumpMapNativeObject != nullptr)
			{
				delete bumpMapNativeObject;
				bumpMapNativeObject = nullptr;
			}
			if (bumpMapNativeObject != nullptr)
			{
				delete bumpMap2NativeObject;
				bumpMap2NativeObject = nullptr;
			}
			if (light1Orient != nullptr)
			{
				delete light1Orient;
				light1Orient = nullptr;
			}
			if (light2Orient != nullptr)
			{
				delete light2Orient;
				light2Orient = nullptr;
			}
			if (light3Orient != nullptr)
			{
				delete light3Orient;
				light3Orient = nullptr;
			}
			if (light4Orient != nullptr)
			{
				delete light4Orient;
				light4Orient = nullptr;
			}
			if (light5Orient != nullptr)
			{
				delete light5Orient;
				light5Orient = nullptr;
			}
			if (light6Orient != nullptr)
			{
				delete light6Orient;
				light6Orient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (mesh != nullptr)
			{
				delete mesh;
				mesh = nullptr;
			}
			if (bumpMapTexture != nullptr)
			{
				delete bumpMapTexture;
				bumpMapTexture = nullptr;
			}
		}

		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank mesh according to x offset (number of degrees), always on orient.f vector
				vertexLightQuadOrient->Rotate(vertexLightQuadOrient->f, float(mouse.offsetX) / 5.0f);
				fragmentLightQuadOrient->Rotate(fragmentLightQuadOrient->f, float(mouse.offsetX) / 5.0f);
				meshOrient->Rotate(meshOrient->f, float(mouse.offsetX) / 5.0f);
				bumpMapOrient->Rotate(bumpMapOrient->f, float(mouse.offsetX) / 5.0f);
				brickQuadOrient->Rotate(brickQuadOrient->f, float(mouse.offsetX) / 5.0f);
				bumpMapOrient2->Rotate(bumpMapOrient2->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw mesh according to x offset (number of degrees), always on 0,1,0 vector
				vertexLightQuadOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				fragmentLightQuadOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				meshOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				bumpMapOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				brickQuadOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				bumpMapOrient2->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch mesh according to y offset (number of degrees), always on l vector
				vertexLightQuadOrient->Rotate(vertexLightQuadOrient->l, float(mouse.offsetY) / 5.0f);
				fragmentLightQuadOrient->Rotate(fragmentLightQuadOrient->l, float(mouse.offsetY) / 5.0f);
				meshOrient->Rotate(meshOrient->l, float(mouse.offsetY) / 5.0f);
				bumpMapOrient->Rotate(bumpMapOrient->l, float(mouse.offsetY) / 5.0f);
				brickQuadOrient->Rotate(brickQuadOrient->l, float(mouse.offsetY) / 5.0f);
				bumpMapOrient2->Rotate(bumpMapOrient2->l, float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			// move lights
			float moveSpeed = 0.02f;
			if (keyboardKeys.GetKey('W')->IsPressed())
			{
				light1Orient->p = light1Orient->p + light1Orient->u.ScalarMult(moveSpeed);
				light2Orient->p = light2Orient->p + light2Orient->u.ScalarMult(moveSpeed);
				light3Orient->p = light3Orient->p + light3Orient->u.ScalarMult(moveSpeed);
				light4Orient->p = light4Orient->p + light4Orient->u.ScalarMult(moveSpeed);
				light5Orient->p = light5Orient->p + light5Orient->u.ScalarMult(moveSpeed);
				light6Orient->p = light6Orient->p + light6Orient->u.ScalarMult(moveSpeed);
			}
			if (keyboardKeys.GetKey('S')->IsPressed())
			{
				light1Orient->p = light1Orient->p - light1Orient->u.ScalarMult(moveSpeed);
				light2Orient->p = light2Orient->p - light2Orient->u.ScalarMult(moveSpeed);
				light3Orient->p = light3Orient->p - light3Orient->u.ScalarMult(moveSpeed);
				light4Orient->p = light4Orient->p - light4Orient->u.ScalarMult(moveSpeed);
				light5Orient->p = light5Orient->p - light5Orient->u.ScalarMult(moveSpeed);
				light6Orient->p = light6Orient->p - light6Orient->u.ScalarMult(moveSpeed);
			}
			if (keyboardKeys.GetKey('A')->IsPressed())
			{
				light1Orient->p = light1Orient->p + light1Orient->l.ScalarMult(moveSpeed);
				light2Orient->p = light2Orient->p + light2Orient->l.ScalarMult(moveSpeed);
				light3Orient->p = light3Orient->p + light3Orient->l.ScalarMult(moveSpeed);
				light4Orient->p = light4Orient->p + light4Orient->l.ScalarMult(moveSpeed);
				light5Orient->p = light5Orient->p + light5Orient->l.ScalarMult(moveSpeed);
				light6Orient->p = light6Orient->p + light6Orient->l.ScalarMult(moveSpeed);
			}
			if (keyboardKeys.GetKey('D')->IsPressed())
			{
				light1Orient->p = light1Orient->p - light1Orient->l.ScalarMult(moveSpeed);
				light2Orient->p = light2Orient->p - light2Orient->l.ScalarMult(moveSpeed);
				light3Orient->p = light3Orient->p - light3Orient->l.ScalarMult(moveSpeed);
				light4Orient->p = light4Orient->p - light4Orient->l.ScalarMult(moveSpeed);
				light5Orient->p = light5Orient->p - light5Orient->l.ScalarMult(moveSpeed);
				light6Orient->p = light6Orient->p - light6Orient->l.ScalarMult(moveSpeed);
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1f, 1000.0f);

			graphics->DefaultTransform();
			graphics->ReverseTransform(*cameraOrient);
			Matrix4d mvpMatrix;
			mvpMatrix = graphics->GetMVPMatrix();

			GameColor colors[1] = { GameColor(255, 255, 255) };
			ModelVertex vertices[4] = { ModelVertex(Vector3d(1.5f, 1.5f, 0.0f), 0), ModelVertex(Vector3d(-1.5f, 1.5f, 0.0f), 0), ModelVertex(Vector3d(-1.5f, -1.5f, 0.0f), 0), ModelVertex(Vector3d(1.5f, -1.5f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			Vector3d vertexNormals[4] = { Vector3d(0.0f, 0.0f, -1.0f), Vector3d(0.0f, 0.0f, -1.0f), Vector3d(0.0f, 0.0f, -1.0f), Vector3d(0.0f, 0.0f, -1.0f) };
			// necessary for version of normal map for brick wall - actually for all - red negative (x) always points left on the texture. Always.  Green positive (y) points up on the texture, always.
			// standard for positive red(x) to go right, but in our world positive x is left
			Vector3d vertexTangents[4] = { Vector3d(-1.0f, 0.0f, 0.0f), Vector3d(-1.0f, 0.0f, 0.0f), Vector3d(-1.0f, 0.0f, 0.0f), Vector3d(-1.0f, 0.0f, 0.0f) };
			Vector3d vertexBinormals[4] = { Vector3d(0.0f, 1.0f, 0.0f), Vector3d(0.0f, 1.0f, 0.0f), Vector3d(0.0f, 1.0f, 0.0f), Vector3d(0.0f, 1.0f, 0.0f) };

			gcroot<GameTexture ^>textures[5];
			textures[0] = GameContext::TextureRegistry.GetTexture("Checkerboard");
			textures[1] = nullptr;
			textures[2] = nullptr;
			textures[3] = nullptr;
			textures[4] = nullptr;

			if (vertexLightQuadNativeObject->nativeObjectRef == nullptr)
			{
				graphics->CreateNativeObject(vertexLightQuadNativeObject, colors, 1, vertices, 4, textures, 1, texCoords, 4, nullptr, 0, vertexNormals, 4);
			}
			if (fragmentLightQuadNativeObject->nativeObjectRef == nullptr)
			{
				graphics->CreateNativeObject(fragmentLightQuadNativeObject, colors, 1, vertices, 4, textures, 1, texCoords, 4, nullptr, 0, vertexNormals, 4);
			}
			if (meshNativeObject->nativeObjectRef == nullptr)
			{
				graphics->CreateNativeObject(meshNativeObject, mesh->GetColors(), mesh->GetColorQty(), mesh->GetVertices(), mesh->GetVertexQty(), mesh->GetSurfaces(), mesh->GetSurfaceQty(), true);
			}
			textures[0] = GameContext::TextureRegistry.GetTexture("Rock");
			if (bumpMapNativeObject->nativeObjectRef == nullptr)
			{
				graphics->CreateNativeObject(bumpMapNativeObject, colors, 1, vertices, 4, textures, 1, texCoords, 4, nullptr, 0, vertexNormals, 4, vertexTangents, vertexBinormals, bumpMapTexture);
			}
			if (bumpMap2NativeObject->nativeObjectRef == nullptr)
			{
				graphics->CreateNativeObject(bumpMap2NativeObject, colors, 1, vertices, 4, textures, 1, texCoords, 4, nullptr, 0, vertexNormals, 4, vertexTangents, vertexBinormals, bumpMapTexture);
			}

			GraphicsShaderOptions renderOptions;

			graphics->PushMatrix();
			graphics->Transform(*light1Orient);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			graphics->Transform(*light2Orient);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			graphics->Transform(*light3Orient);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			graphics->Transform(*light4Orient);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			graphics->Transform(*light5Orient);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			graphics->Transform(*light6Orient);
			graphics->Scale(0.05f, 0.05f, 0.05f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			Vector3d ambientColor = Vector3d(0.25f, 0.25f, 0.25f);
			GraphicsShaderMaterial material;
			GraphicsShaderLight lights[1];
			GraphicsShaderLightPtr lightRefs[1];
			lightRefs[0] = &(lights[0]);
			Vector3d cameraPositionWorld;
			material.ambientReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
			material.diffuseReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
			material.specularReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
			material.shininess = 512.0f;
			lights[0].color = Vector3d(1.0f, 1.0f, 1.0f);
			lights[0].diffuseAttenuationFactor = 0.5f; // determine by world scale
			lights[0].specularAttenuationFactor = 0.25f; // determine by world scale
			lights[0].type = GraphicsShaderCompositionLightType::Point;
			renderOptions.lighting = true;
			renderOptions.ambientLightRef = &ambientColor;
			renderOptions.lightingMaterialRef = &material;
			renderOptions.lightRefs = lightRefs;
			renderOptions.lightQty = 1;
			renderOptions.texture1Ref = GameContext::TextureRegistry.GetTexture("Checkerboard");

			// render a vertex-lit quad (lit at vertices)
			graphics->PushMatrix();
			//graphics->Transform(*vertexLightQuadOrient);
			renderOptions.eyeMVPMatrixRef = &mvpMatrix;
			lights[0].worldPosition = light1Orient->p;
			renderOptions.vertexLighting = true;
			renderOptions.modelWorldOrientRef = vertexLightQuadOrient;
			cameraPositionWorld = cameraOrient->p;
			renderOptions.cameraPositionRef = &cameraPositionWorld;
			// todo: tag vertex lighting
			graphics->RenderNativeObject(vertexLightQuadNativeObject, renderOptions);
			//cube->Render(*graphics);
			graphics->PopMatrix();

			// render a fragment lit quad (much more detail)
			graphics->PushMatrix();
			//graphics->Transform(*fragmentLightQuadOrient);
			renderOptions.eyeMVPMatrixRef = &mvpMatrix;
			lights[0].worldPosition = light2Orient->p;
			renderOptions.vertexLighting = false;
			renderOptions.modelWorldOrientRef = fragmentLightQuadOrient;
			cameraPositionWorld = cameraOrient->p;
			renderOptions.cameraPositionRef = &cameraPositionWorld;
			// todo: tag fragment lighting
			graphics->RenderNativeObject(fragmentLightQuadNativeObject, renderOptions);
			//cube->Render(*graphics);
			graphics->PopMatrix();

			renderOptions.texture0Ref = GameContext::TextureRegistry.GetTexture("Rock");
			lights[0].diffuseAttenuationFactor = 0.1f; // determine by world scale
			lights[0].specularAttenuationFactor = 0.05f; // determine by world scale
			material.specularReflectivity = Vector3d(0.5f, 0.5f, 0.5f);
			material.shininess = 50.0f;

			// render a mesh lit by fragment
			graphics->PushMatrix();
			//graphics->Transform(*meshOrient);
			renderOptions.eyeMVPMatrixRef = &mvpMatrix;
			lights[0].worldPosition = light3Orient->p;
			renderOptions.vertexLighting = false;
			renderOptions.modelWorldOrientRef = meshOrient;
			cameraPositionWorld = cameraOrient->p;
			renderOptions.cameraPositionRef = &cameraPositionWorld;
			// todo: tag fragment lighting
			graphics->RenderNativeObject(meshNativeObject, renderOptions);
			//cube->Render(*graphics);
			graphics->PopMatrix();

			// render a mesh bumpmapped
			//renderOptions.texture1Ref = bumpMapTexture;
			renderOptions.textureBumpMapRef = bumpMapTexture;
			graphics->PushMatrix();
			//graphics->Transform(*bumpMapOrient);
			renderOptions.eyeMVPMatrixRef = &mvpMatrix;
			lights[0].worldPosition = light4Orient->p;
			renderOptions.modelWorldOrientRef = bumpMapOrient;
			renderOptions.vertexLighting = false;
			cameraPositionWorld = cameraOrient->p;
			renderOptions.cameraPositionRef = &cameraPositionWorld;
			// todo: tag fragment lighting
			graphics->RenderNativeObject(bumpMapNativeObject, renderOptions);
			//cube->Render(*graphics);
			graphics->PopMatrix();

			lights[0].color = Vector3d(1.0f, 1.0f, 1.0f);
			lights[0].diffuseAttenuationFactor = 0.1f; // determine by world scale
			lights[0].specularAttenuationFactor = 0.05f; // determine by world scale
			material.specularReflectivity = Vector3d(0.1f, 0.1f, 0.1f);
			material.shininess = 50.0f;

			// render a brickwall
			renderOptions.texture0Ref = GameContext::TextureRegistry.GetTexture("Brick");
			renderOptions.textureBumpMapRef = nullptr;
			graphics->PushMatrix();
			//graphics->Transform(*brickQuadOrient);
			renderOptions.eyeMVPMatrixRef = &mvpMatrix;
			lights[0].worldPosition = light5Orient->p;
			renderOptions.vertexLighting = false;
			renderOptions.modelWorldOrientRef = brickQuadOrient;
			cameraPositionWorld = cameraOrient->p;
			renderOptions.cameraPositionRef = &cameraPositionWorld;
			// todo: tag fragment lighting
			graphics->RenderNativeObject(fragmentLightQuadNativeObject, renderOptions);
			//cube->Render(*graphics);
			graphics->PopMatrix();

			// render a brickwall with a bumpmap
			renderOptions.textureBumpMapRef = GameContext::TextureRegistry.GetTexture("BrickBumpMap");;
			graphics->PushMatrix();
			//graphics->Transform(*bumpMapOrient2);
			renderOptions.eyeMVPMatrixRef = &mvpMatrix;
			lights[0].worldPosition = light6Orient->p;
			renderOptions.vertexLighting = false;
			renderOptions.modelWorldOrientRef = bumpMapOrient2;
			cameraPositionWorld = cameraOrient->p;
			renderOptions.cameraPositionRef = &cameraPositionWorld;
			// todo: tag fragment lighting
			graphics->RenderNativeObject(bumpMap2NativeObject, renderOptions);
			//cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->SwapBuffers();
		}
	};

	enum MazeRunnerObjectType
	{
		Player = 1,
		Bullet = 2,
		Monster = 3
	};

	public class MazeRunnerGameObject : public GameObjectBase
	{
	public:
		MazeRunnerObjectType type;
		Orient3d orient;
		Vector3d velocity;
		Vector3d priorPosition;
		bool priorPositionValid;
		int lifeMS; // if 0, indefinite life
	};

	public class MazeRunnerWall
	{
	public:
		// assumed that z is always zero here, for now, with the x,y pairs representing the endpoints of a vertical wall with no defined height.  Otherwise, the wall must be defined as a plane so
		//   that a real normal can be determined, and segment would be meaningless

		Vector3d point0;
		Vector3d point1;
		Vector3d pointsOffset;
		Vector3d unit;
		Vector3d normal;

		MazeRunnerWall()
		{
		}

		MazeRunnerWall(Vector3d &p_point0, Vector3d &p_point1)
		{
			Set(p_point0, p_point1);
		}

		void Set(Vector3d &p_point0, Vector3d &p_point1)
		{
			point0 = p_point0;
			point1 = p_point1;
			pointsOffset = point1 - point0;
			unit = pointsOffset;
			unit.Normalize(); // invalid if wall is just a point - doesn't matter much here, but ideally validation would prevent that
			normal.Set(unit.y, -unit.x, 0);
		}
	};

	public ref class MazeRunnerGame : public GameBase
	{
		// todo: need a game object counter with id
	public:

		Model3d *cube;
		Orient3d *playerOrient;
		GameTimer *timer;
		bool weaponFired; // move to gameobject for player when appropriate
		LinkedList<MazeRunnerGameObject> *bullets;
		LinkedList<MazeRunnerGameObject> *monsters;
		LinkedList<MazeRunnerGameObject> *effects;
		LinkedList<MazeRunnerWall> *walls;

		MazeRunnerGame(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cube = nullptr;
			playerOrient = nullptr;
			timer = nullptr;
			weaponFired = false;
			bullets = nullptr;
			walls = nullptr;
		}

		virtual ~MazeRunnerGame()
		{
			Destroy();
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		void Initialize() override
		{
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			// set up file resources and textures
			GameContext::Instance->FileRegistry.RegisterFileResource("lightmap5.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Bullet", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("lightmap5.bmp"));

			int width = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth();
			int height = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight();
			cube = new Model3d();
			cube->MakeCube();
			playerOrient = new Orient3d();
			playerOrient->p = Vector3d( width / 2.0f, height / 2.0f, 0);
			timer = new GameTimer();
			bullets = new LinkedList<MazeRunnerGameObject>("Bullets");
			monsters = new LinkedList<MazeRunnerGameObject>("Monsters");
			effects = new LinkedList<MazeRunnerGameObject>("Effects");
			walls = new LinkedList<MazeRunnerWall>("Walls");

			// make monsters
			FastRandom random;
			int monsterQty = 20;
			for (int i = 0; i < monsterQty; i++)
			{
				LinkedListNode<MazeRunnerGameObject> *newNode = monsters->GetNewNode();
				newNode->data.deleted = false;
				newNode->data.lifeMS = 0;
				newNode->data.type = MazeRunnerObjectType::Monster;
				newNode->data.orient.LoadIdentity();
				newNode->data.orient.p = Vector3d(float(random.GetRandomInteger(0, width)), float(random.GetRandomInteger(0, height)), 0.0f);
				newNode->data.priorPositionValid = false;
				monsters->AddNode(newNode);
			}

			int wallQty = 3;
			// qty * 2
			Vector3d wallPoints[6] = { Vector3d(300, 300, 0), Vector3d(600, 300, 0), Vector3d(600, 300, 0), Vector3d(450, 500, 0), Vector3d(450, 500, 0), Vector3d(300, 300, 0) };
			for (int i = 0; i < wallQty; i++)
			{
				LinkedListNode<MazeRunnerWall> *newNode = walls->GetNewNode();
				newNode->data.Set(wallPoints[i * 2], wallPoints[i * 2 + 1]);
				walls->AddNode(newNode);
			}
		}

		void DestroyGameData()
		{
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (playerOrient != nullptr)
			{
				delete playerOrient;
				playerOrient = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (bullets != nullptr)
			{
				delete bullets;
				bullets = nullptr;
			}
			if (monsters != nullptr)
			{
				delete monsters;
				monsters = nullptr;
			}
			if (effects != nullptr)
			{
				delete effects;
				effects = nullptr;
			}
			if (walls != nullptr)
			{
				delete walls;
				walls = nullptr;
			}
		}

		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// handle mouse

			// point player's u vector at mouse location
			Vector3d targetLocation = Vector3d(float(mouse.currentX), float(mouse.currentY), 0);

			bool fireWeapon = false;
			if (mouse.leftButton.down == true && weaponFired == false)
			{
				fireWeapon = true;
				weaponFired = true;
			}
			else if (mouse.leftButton.down == false)
				weaponFired = false;

			mouse.ZeroOffsets();

			// handle keys
			Vector3d playerOffset = Vector3d(0, 0, 0);
			if (keyboardKeys.GetKey('W')->IsPressed())
			{
				playerOffset.y = playerOffset.y - 1.0f;
			}
			if (keyboardKeys.GetKey('S')->IsPressed())
			{
				playerOffset.y = playerOffset.y + 1.0f;
			}
			if (keyboardKeys.GetKey('A')->IsPressed())
			{
				playerOffset.x = playerOffset.x - 1.0f;
			}
			if (keyboardKeys.GetKey('D')->IsPressed())
			{
				playerOffset.x = playerOffset.x + 1.0f;
			}
			if (playerOffset.Magnitude() > 1.0f)
				playerOffset.Normalize();
			if (keyboardKeys.GetKey(16)->IsPressed()) // SHIFT
				playerOffset = playerOffset.ScalarMult(1.5f);
			// adjust for gamable speed
			playerOffset = playerOffset.ScalarMult(0.2f);

			// Animate player and weapons
			// move player
			playerOrient->p = playerOrient->p + playerOffset.ScalarMult(timer->GetElapsedTimeMSFloat());
			// point player at target
			Vector3d proposedU = Vector3d(0, 0, 0);
			proposedU.x = targetLocation.x - playerOrient->p.x;
			proposedU.y = targetLocation.y - playerOrient->p.y;
			if (proposedU.Normalize() == true)
			{
				playerOrient->u = proposedU;
				playerOrient->l.x = proposedU.y;
				playerOrient->l.y = -proposedU.x;
			}
			// create weapon if firing
			if (fireWeapon == true)
			{
				LinkedListNode<MazeRunnerGameObject> *newNode = bullets->GetNewNode();
				newNode->data.deleted = false; // ?? need a counter with an id
				newNode->data.lifeMS = 2000;
				newNode->data.orient.Set(*playerOrient);
				newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(5.0f);
				newNode->data.priorPositionValid = false;
				newNode->data.velocity = playerOrient->u.ScalarMult(1.0f);
				newNode->data.type = MazeRunnerObjectType::Bullet;
				bullets->AddNode(newNode);
			}
			// move weapons
			MoveWeapons(timer->GetElapsedTimeMSFloat());
			BehaveMonsters();
			MoveMonsters(timer->GetElapsedTimeMSFloat());
			CheckCollisions();

			CleanDeletedObjects();

			timer->ResetElapsedTime();
			return true;
		}

		void MoveWeapons(float p_elapsedTimeMSf)
		{
			LinkedListEnumerator<MazeRunnerGameObject> enumerator = LinkedListEnumerator<MazeRunnerGameObject>(*bullets);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.deleted == true)
					continue;
				if (enumerator.Current()->data.lifeMS != 0)
				{
					if (float(enumerator.Current()->data.lifeMS) <= p_elapsedTimeMSf)
					{
						enumerator.Current()->data.Delete();
						continue;
					}
					else
					{
						enumerator.Current()->data.lifeMS -= int(p_elapsedTimeMSf);
					}
				}

				// move the bullet
				enumerator.Current()->data.priorPosition = enumerator.Current()->data.orient.p;
				enumerator.Current()->data.orient.p = enumerator.Current()->data.orient.p + enumerator.Current()->data.velocity.ScalarMult(p_elapsedTimeMSf);
				enumerator.Current()->data.priorPositionValid = true;
			}
		}

		void BehaveMonsters()
		{
			float movementRate = 0.15f;
			LinkedListEnumerator<MazeRunnerGameObject> enumerator = LinkedListEnumerator<MazeRunnerGameObject>(*monsters);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.deleted == true)
					continue;

				// turn the monster
				Vector3d proposedU = Vector3d(0, 0, 0);
				proposedU.x = playerOrient->p.x - enumerator.Current()->data.orient.p.x;
				proposedU.y = playerOrient->p.y - enumerator.Current()->data.orient.p.y;
				if (proposedU.Normalize() == true)
				{
					enumerator.Current()->data.orient.u = proposedU;
					enumerator.Current()->data.orient.l.x = proposedU.y;
					enumerator.Current()->data.orient.l.y = -proposedU.x;
				}

				enumerator.Current()->data.velocity = enumerator.Current()->data.orient.u.ScalarMult(movementRate);
			}
		}

		void MoveMonsters(float p_elapsedTimeMSf)
		{
			// check for collisions with other monsters, if so, just don't move
			float collisionRadius = 13.0f;
			LinkedListEnumerator<MazeRunnerGameObject> enumerator = LinkedListEnumerator<MazeRunnerGameObject>(*monsters);
			while (enumerator.MoveNext())
			{
				// check all against all
				LinkedListEnumerator<MazeRunnerGameObject> enumerator2 = LinkedListEnumerator<MazeRunnerGameObject>(*monsters);
				bool collision = false;
				bool slow = false;
				Vector3d velocity1 = enumerator.Current()->data.velocity.ScalarMult(p_elapsedTimeMSf);
				// check against all and find the proper action (collision is handled over slow)
				while (enumerator2.MoveNext())
				{
					// don't check monster against itself
					if (&(enumerator2.Current()->data) == &(enumerator.Current()->data))
						continue;

					Vector3d velocity2 = enumerator2.Current()->data.velocity.ScalarMult(p_elapsedTimeMSf);

					float collisionT;
					// if they didn't move and collide, see if they overlap (if the collision is perfect, they might slip into each other next frame) - if they overlap, only allow move if 1 is moving away from 2
					if (slow == false) // only check if we aren't already slow
					{
						if (MathUtilities::SphereSphereCollision(enumerator.Current()->data.orient.p, velocity1 - velocity2, collisionRadius, enumerator2.Current()->data.orient.p, collisionRadius, collisionT) == true)
						{
							// if enum is ahead of enum2, don't collide
							if ((enumerator.Current()->data.velocity *(enumerator2.Current()->data.orient.p - enumerator.Current()->data.orient.p)) > 0.0f)
							{
								// slow down and let the one ahead keep moving at full
								//slow = true; // slow doesn't work well - they still get caught on each other because both are still moving when next to each other - but crowd dynamic will replace this anyway
								collision = true;
								break;
							}
						}
					}
					if ((enumerator.Current()->data.orient.p - enumerator2.Current()->data.orient.p).Magnitude() < (collisionRadius * 2.0f) && (enumerator.Current()->data.velocity *(enumerator2.Current()->data.orient.p - enumerator.Current()->data.orient.p)) > 0.0f)
					{
						// stop entirely
						collision = true;
						break; // if we hit this condition we are done
					}
				}
				if (collision == true)
				{
					enumerator.Current()->data.velocity = Vector3d(0,0,0);
				}
				else if (slow == true)
				{
					enumerator.Current()->data.velocity = enumerator.Current()->data.velocity.ScalarMult(0.5f);
				}
			}

			// move them
			enumerator = LinkedListEnumerator<MazeRunnerGameObject>(*monsters);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.deleted == true)
					continue;

				// move the monster
				enumerator.Current()->data.priorPosition = enumerator.Current()->data.orient.p;
				enumerator.Current()->data.orient.p = enumerator.Current()->data.orient.p + enumerator.Current()->data.velocity.ScalarMult(p_elapsedTimeMSf);
				enumerator.Current()->data.priorPositionValid = true;
			}
		}

		void CheckCollisions()
		{
			// determine first collision, move objects up to that point, and respond, repeat until all game time is consumed
			// to avoid infinite loops, be careful with responses from collisions that come up after the response to that collision
			// i.e. monster collides with wall (ignore if the direction travelled is so very parallel to the wall)
			// i.e. monster collides with monsters again after slowed or stopped (don't check monster collisions with slowed monsters)

			// monsters not already slowed or stopped can collide with monsters they are 'behind'.  In this case, slow them down, otherwise skip that collision
			//   (another option - let monsters try to move around each other to get where they are going - this shoudl be precalculated in MoveMonsters if that methdology is still used, but
			//    any adjustment to a monsters movement shoudl always be somehow towards the ultiamte goal which is the player, so don't prioritize their current movement direction as being
			//    towards their ultiamte goal because it might have been adjusted previously already)
			// monsters inside other monsters simply stop.  Stopped monsters should not check collisions with othersat all, although moving monsters can still collide with them.
			// bullets can collide with walls.  remove the bullet, place a flash effect
			// bullets can collide with creatures.  remove both. (later: damage the creature, possibly slow it down, remove when no health left, place a flash effect)
			// monsters can collide with walls.  If this occurs, consider where they are trying to move (movement vector) and consume it with the wall normal - face them in the new direction and
			//   move them that way at their current speed for the remaining amount of time

			// finally, if monsters are inside a wall, shunt them out to avoid slight failures at detecting collisions later (can't have monsters going through walls)
			// don't need to do this with monsters vs. monsters because one usually moves out of the other eventually unless they are stuck on each otehr (will be fixed later with crowd movement)

			// Final note: It is possibel that monsters might emerge from the end of a wall and be able to turn towards the player durign their move.  This collision routine does not check for that circumstance
			//  because the calculation can be costly (to determine that a monster is enough past a wall to figure out that moving towards the player is viable again).  After all, the next
			//  game tick will turn them towards the player again anyway.
		}

		void CheckBulletCollisions()
		{
			// check bullets against monsters
			LinkedListEnumerator<MazeRunnerGameObject> bulletEnum = LinkedListEnumerator<MazeRunnerGameObject>(*bullets);
			while (bulletEnum.MoveNext())
			{
				if (bulletEnum.Current()->data.deleted == true)
					continue;
				if (bulletEnum.Current()->data.priorPositionValid == false)
					continue;
				Vector3d bulletPosition = bulletEnum.Current()->data.priorPosition;
				Vector3d bulletVector = bulletEnum.Current()->data.orient.p - bulletEnum.Current()->data.priorPosition;

				LinkedListEnumerator<MazeRunnerGameObject> monsterEnum = LinkedListEnumerator<MazeRunnerGameObject>(*monsters);
				while (monsterEnum.MoveNext())
				{
					if (monsterEnum.Current()->data.deleted == true)
						continue;
					if (monsterEnum.Current()->data.priorPositionValid == false)
						continue;
					Vector3d monsterPosition = monsterEnum.Current()->data.priorPosition;
					Vector3d monsterVector = monsterEnum.Current()->data.orient.p - monsterEnum.Current()->data.priorPosition;

					// todo: move 1.0f and 10.0f to game object or a registry of values for bullet and monster
					float collisionT;
					if (MathUtilities::SphereSphereCollision(bulletPosition, bulletVector - monsterVector, 1.0f, monsterPosition, 10.0f, collisionT) == true)
					{
						BulletHitMonster(bulletEnum.Current()->data, monsterEnum.Current()->data);
						// done with this bullet - it can only hit one mosnter (todo: although we could keep looping until it finds the first monster it hit)
						break;
					}
				}
			}
		}

		void BulletHitMonster(MazeRunnerGameObject &p_bullet, MazeRunnerGameObject &p_monster)
		{
			// remove bullet
			p_bullet.Delete();

			// remove monster
			// later - lower health, dont' kill until dead, cause to slow down for a small time
			p_monster.Delete();
		}

		void CleanDeletedObjects()
		{
			// bullets
			LinkedListNode<MazeRunnerGameObject> *node = bullets->GetFirstNode();
			if (node != nullptr)
			{
				while (node != &(bullets->footer))
				{
					if (node->data.deleted)
					{
						node = node->next;
						bullets->DeleteNode(node->prev);
					}
					else
						node = node->next;
				}
			}

			// monsters
			node = monsters->GetFirstNode();
			if (node != nullptr)
			{
				while (node != &(monsters->footer))
				{
					if (node->data.deleted)
					{
						node = node->next;
						monsters->DeleteNode(node->prev);
					}
					else
						node = node->next;
				}
			}
		}

		////////////////////////////////////////

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 64, 64));

			graphics->Set2dWindowProjection(-1.0f, 100.0f);

			// Do NOT do this on an Ortho projection!
			//graphics->DefaultTransform();

			////////////////
			// render it!
			graphics->PushMatrix();
			graphics->Transform(*playerOrient);
			graphics->Scale(10, 10, 10);
			cube->Render(*graphics);
			graphics->PopMatrix();

			RenderMonsters(graphics);

			// alphas
			RenderBullets(graphics, GameContext::TextureRegistry.GetTexture("Bullet"));

			// walls
			RenderWalls(graphics, GameColor(0, 192, 192), 6.0f);

			// done rendering
			/////////////////

			graphics->SwapBuffers();
		}

		void RenderMonsters(GraphicsBase *p_graphics)
		{
			GameColor colorOverrides[8] = { GameColor(255, 0, 0), GameColor(128, 0, 0), GameColor(64, 0, 0), GameColor(192, 0, 0), GameColor(255, 0, 0), GameColor(128, 0, 0), GameColor(64, 0, 0), GameColor(192, 0, 0) };
			LinkedListEnumerator<MazeRunnerGameObject> enumerator = LinkedListEnumerator<MazeRunnerGameObject>(*monsters);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.deleted == true)
					continue;

				p_graphics->PushMatrix();
				p_graphics->Transform(enumerator.Current()->data.orient);
				p_graphics->Scale(10, 10, 10);
				cube->Render(*p_graphics, colorOverrides, 8);
				p_graphics->PopMatrix();
			}
		}

		void RenderBullets(GraphicsBase *p_graphics, GameTexture ^p_bulletTexture)
		{
			GameColor colors[1] = { GameColor(255,255,0) };
			ModelVertex vertices[4] = { ModelVertex(Vector3d(-2.0f, -20.0f, 0.0f), 0), ModelVertex(Vector3d(2.0f, -0.0f, -0.0f), 0), ModelVertex(Vector3d(2.0f, 20.0f, 0.0f), 0), ModelVertex(Vector3d(-2.0f, 20.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			LinkedListEnumerator<MazeRunnerGameObject> enumerator = LinkedListEnumerator<MazeRunnerGameObject>(*bullets);
			p_graphics->SetDepthTestEnabled(false);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.deleted == true)
					continue;

				p_graphics->PushMatrix();
				p_graphics->Transform(enumerator.Current()->data.orient);
				p_graphics->RenderFilledQuad(colors, 1, vertices, 4, true, p_bulletTexture, texCoords, 4);
				p_graphics->PopMatrix();
			}
			p_graphics->SetDepthTestEnabled(true);
		}

		void RenderWalls(GraphicsBase *p_graphics, GameColor &p_color, float p_lineWidth)
		{
			LinkedListEnumerator<MazeRunnerWall> enumerator = LinkedListEnumerator<MazeRunnerWall>(*walls);
			ModelVertex vertices[2];
			vertices[0].colorIndex = 0;
			vertices[1].colorIndex = 0;
			while (enumerator.MoveNext())
			{
				vertices[0].vertex = enumerator.Current()->data.point0;
				vertices[1].vertex = enumerator.Current()->data.point1;
				p_graphics->RenderLineStrip(p_lineWidth, &p_color, 1, vertices, 2, false);
			}
		}
	};

	///////////////////////////////////////////////

	enum class PlatformDirection
	{
		None = 0,
		Left = 1,
		Right = 2
	};

	// Imitate Castlevania: player quickly crouches when not standing and is traveling upward.  Shortly after start falling, stand full again (don't allow a lot of tolerance for a long jump to a high ledge)
	enum class PlatformPosture
	{
		None = 0, // for init
		Standing = 1,
		Crouching = 2
	};

	public class PlatformPlayerCollisionBlock
	{
	public:
		PlatformPlayerCollisionBlock()
		{
			posture = PlatformPosture::None;
		}

		// values here are hardcoded for simplicity
		PlatformPosture posture;
		// note: offsets are off the position coordinates of the player
		float leftOffset;
		float rightOffset;
		float topOffset;
		float bottomOffset;
		float width;
		float height;
		void SetPosture(PlatformPosture p_posture, bool p_onSurface, float &p_currentY)
		{
			// these values all consider cellSize = 80.0f.  Adjust proportionately if that size changes (or just pass in the size as an argument or as part of the constructor)
			// these sizes don't necessarily have to match sprite sizes - these are purely for collision detection.
			switch (p_posture)
			{
			case PlatformPosture::Standing:
				{
					if (posture != PlatformPosture::Standing)
					{
						if (p_onSurface == true)
						{
							leftOffset = -40.0f;
							rightOffset = 40.0f;
							topOffset = -140.0f;
							bottomOffset = 0.0f;
						}
						else
						{
							// going to full stance in mid air
							leftOffset = -40.0f;
							rightOffset = 40.0f;
							topOffset = -140.0f;
							bottomOffset = 0.0f;
							p_currentY += 20.0f;
						}
					}
				}
				break;
			case PlatformPosture::Crouching:
				{
					if (posture != PlatformPosture::Crouching)
					{
						if (p_onSurface == true)
						{
							leftOffset = -40.0f;
							rightOffset = 40.0f;
							topOffset = -105.0f;
							bottomOffset = 0.0f;
						}
						else
						{
							// must be jumping
							leftOffset = -40.0f;
							rightOffset = 40.0f;
							topOffset = -105.0f;
							bottomOffset = 0.0f;
							p_currentY -= 20.0f;
						}
					}
				}
				break;
			}

			width = rightOffset - leftOffset;
			height = bottomOffset - topOffset;
			posture = p_posture;
		}
	};

	public class PlatformerPlatformInterval
	{
	public:
		int startTimeMS; // time at which to start (also adjustment for formula).  If currentMS this value, skip it.  startTimeMS + intervalLengthMS = next interval's startTimeMS
		int intervalLengthMS; // if zero, skip it

		Vector3d a, b, c;
		// formula is at^2 + bt + c
		Vector3d Calculate(int p_timeMS)
		{
			float t = float(p_timeMS - startTimeMS);
			Vector3d result;
			result = a.ScalarMult(float(t * t)) + b.ScalarMult(float(t)) + c;
			return result;
		}
	};

	public class PlatformerPlatform
	{
	public:
		Vector3d position;
		Vector3d priorPosition;
		bool priorPositionValid;

		// top is always actual top of platform
		// bottom is previous position if travelling upward, otherwise is actual top of platform
		float collisionBlockLeft;
		float collisionBlockRight;
		float collisionBlockTop;
		float collisionBlockBottom;

		PlatformerPlatformInterval intervals[8]; // always 8 - see class definition

		// todo: ideally should push from point 1 to midpoint, then pull to endpoint at other half, so 10 intervals.  But this is good enough for now.

		// formula for position:
		// stages:
		// 0 - accelerating to reach full speed from 1 towards 2
		// 1 - at max speed from 1 towards 2
		// 2 - decelerating to reach endpoint 2
		// 3 - pausing at endpoint 2
		// 4 - accelerating to reach full speed from 2 towards 1
		// 5 - at max speed from 2 towards 1
		// 6 - decelerating to reach endpoint 1
		// 7 - pausing at endpoint 1

		int maxTimerMS; // full cycle
		int currentMS; // where are we at now?
		int offsetMS; // offset to currentMS to stagger platforms
		void Animate(int p_elapsedTimeMS)
		{
			currentMS += p_elapsedTimeMS;
			while (currentMS >= maxTimerMS)
				currentMS -= maxTimerMS;

			int timerToUse = currentMS + offsetMS;
			while (timerToUse >= maxTimerMS)
				timerToUse -= maxTimerMS;

			// calculate position based entirely on currentMS
			bool valid = false;
			Vector3d result;
			for (int i = 0; i < 8; i++)
			{
				if (intervals[i].startTimeMS > timerToUse)
					continue;
				if ((intervals[i].startTimeMS + intervals[i].intervalLengthMS) <= timerToUse)
					continue;
				if (intervals[i].intervalLengthMS == 0)
					continue;

				result = intervals[i].Calculate(timerToUse);
				valid = true;
				break;
			}

			if (valid == false)
				throw gcnew Exception("Unable to find interval for this time on this platform (might need more info here, like a table dump and the currentMS");

			if (priorPositionValid == false)
				priorPosition = result; // set prior and current equal
			else
				priorPosition = position;
			position = result;
			priorPositionValid = true;

			// Calculate collision block
			if (priorPosition.y < position.y)
			{
				// set block to actual platform
				collisionBlockLeft = position.x - 80.0f;
				collisionBlockRight = position.x + 80.0f;
				collisionBlockTop = position.y - 40.0f;
				collisionBlockBottom = position.y;
			}
			else
			{
				// block is going up, include prior position in case character is falling fast - this helps prevent fallthrough before a collision can be detected
				collisionBlockLeft = position.x - 80.0f;
				collisionBlockRight = position.x + 80.0f;
				collisionBlockTop = position.y - 40.0f;
				collisionBlockBottom = priorPosition.y;
			}
		}

		void SetLinear(Vector3d &p_endpoint1, Vector3d &p_endpoint2, int p_totalTimePerCycleMS, int p_pauseAtEndpointMS, int p_offsetMS = 0)
		{
			// build interval table
			intervals[0].intervalLengthMS = 0;

			intervals[1].startTimeMS = 0;
			intervals[1].intervalLengthMS = (p_totalTimePerCycleMS - p_pauseAtEndpointMS * 2) / 2;
			intervals[1].a = Vector3d(0, 0, 0);
			intervals[1].b = (p_endpoint2 - p_endpoint1).ScalarMult(1.0f / float(intervals[1].intervalLengthMS));
			intervals[1].c = p_endpoint1;

			intervals[2].intervalLengthMS = 0;

			intervals[3].startTimeMS = intervals[1].startTimeMS + intervals[1].intervalLengthMS;
			intervals[3].intervalLengthMS = p_pauseAtEndpointMS;
			intervals[3].a = Vector3d(0, 0, 0);
			intervals[3].b = Vector3d(0, 0, 0);;
			intervals[3].c = p_endpoint2;

			intervals[4].intervalLengthMS = 0;

			intervals[5].startTimeMS = intervals[3].startTimeMS + intervals[3].intervalLengthMS;
			intervals[5].intervalLengthMS = p_totalTimePerCycleMS - intervals[1].intervalLengthMS - p_pauseAtEndpointMS * 2; // make the total perfect!
			intervals[5].a = Vector3d(0, 0, 0);
			intervals[5].b = (p_endpoint1 - p_endpoint2).ScalarMult(1.0f / float(intervals[5].intervalLengthMS));
			intervals[5].c = p_endpoint2;

			intervals[6].intervalLengthMS = 0;

			intervals[7].startTimeMS = intervals[5].startTimeMS + intervals[5].intervalLengthMS;
			intervals[7].intervalLengthMS = p_pauseAtEndpointMS;
			intervals[7].a = Vector3d(0, 0, 0);
			intervals[7].b = Vector3d(0, 0, 0);
			intervals[7].c = p_endpoint1;

			maxTimerMS = p_totalTimePerCycleMS; // should be intervals[7].startTimeMS + intervals[7].intervalLengthMS
			priorPositionValid = false;
			currentMS = 0;
			offsetMS = p_offsetMS;
		}

		void SetAccelerated(Vector3d &p_endpoint1, Vector3d &p_endpoint2, int p_totalTimePerCycleMS, int p_pauseAtEndpointMS, float p_maxVelocityPerMS, int p_offsetMS = 0)
		{
			// endpoint1, endpoint2, total cycle time, time at endpoints, max velocity
			// calculate time needed for deceleration - make sure intervals adds up perfectly!
			// to calculate, get time allowed for travelling by subtracting endpoint pauses from total cycle time and halving it.  If < 0, error
			// if = 0 and travel time doesn't get platform exactly to destination, error
			// if > 0 and travel time doesn't get platform past endpoints, error (need that time for deceleration - need to calculate a correct deceleration value so that decel time * 2 + time travelled at max velocity covers the distance)
			// - given v max velocity, and total distance D to cover, T total time between endpoints, find an acceleration/deceleration a and time t1 such that at1^2 + v*(T - 2 * t1) = D, and t1 = v/a
			// - t1 is the time spent decelerating/accelerating, a is the acceleration value.  two variables.  Solve with substitution.
			// a(v/a)^2 + v*(T - 2v/a) = D
			// v^2/a + vT - 2v^2/a = D
			// -v^2/a + vT = D
			// -v^2 + vTa = Da
			// a = v^2/(vT - D), and t1 = v/a
			// if (vT - D) <=0 error (if 0, should have solved with no accel/decel, < 0 means no solution at all)
			// if (T - t1*2) < 0, error (moving too fast to decelerate/accelerate and take time T overall)
			// and once we get a, we get t1 from v/a = t1, which also determines from T - t1*2 the length of time travelled at max velocity.
			float totalDistance = (p_endpoint1 - p_endpoint2).Magnitude();
			if (totalDistance == 0)
			{
				// stationary
				SetLinear(p_endpoint1, p_endpoint2, p_totalTimePerCycleMS, p_pauseAtEndpointMS, p_offsetMS);
				return;
			}

			// handle 1 to 2
			int totalTimeTravelling1to2 = (p_totalTimePerCycleMS - p_pauseAtEndpointMS * 2) / 2;
			float denominator = p_maxVelocityPerMS * totalTimeTravelling1to2 - totalDistance;
			if (denominator == 0)
			{
				// no acceleration/deceleration
				SetLinear(p_endpoint1, p_endpoint2, p_totalTimePerCycleMS, p_pauseAtEndpointMS, p_offsetMS);
				return;
			}
			if (denominator < 0)
			{
				throw gcnew Exception("Max velocity not enough to cover distance between endpoints with indicated times");
			}
			float accel = p_maxVelocityPerMS * p_maxVelocityPerMS / denominator;
			// note: timeAccelerating might have rounding, but since we are dealing with MS, it shouldn't be a big deal at all.
			int timeAccelerating = int(p_maxVelocityPerMS / accel);
			int timeTravellingMaxVelocity = totalTimeTravelling1to2 - timeAccelerating * 2; // make sure total is perfect!
			if (timeTravellingMaxVelocity < 0)
			{
				throw gcnew Exception("Max velocity too high to decelerate and meet the total time cycle");
			}
			Vector3d travelVector = (p_endpoint2 - p_endpoint1).ScalarMult(1.0f / totalDistance);

			intervals[0].startTimeMS = 0;
			intervals[0].intervalLengthMS = timeAccelerating;
			intervals[0].a = travelVector.ScalarMult(0.5f * accel);
			intervals[0].b = Vector3d(0, 0, 0);
			intervals[0].c = p_endpoint1;

			intervals[1].startTimeMS = intervals[0].startTimeMS + intervals[0].intervalLengthMS;
			intervals[1].intervalLengthMS = timeTravellingMaxVelocity;
			intervals[1].a = Vector3d(0, 0, 0);
			intervals[1].b = travelVector.ScalarMult(p_maxVelocityPerMS);
			intervals[1].c = p_endpoint1 + travelVector.ScalarMult(0.5f * accel * float(intervals[0].intervalLengthMS * intervals[0].intervalLengthMS));

			intervals[2].startTimeMS = intervals[1].startTimeMS + intervals[1].intervalLengthMS;
			intervals[2].intervalLengthMS = timeAccelerating;
			intervals[2].a = travelVector.ScalarMult(0.5f * -accel);
			intervals[2].b = travelVector.ScalarMult(p_maxVelocityPerMS);
			intervals[2].c = p_endpoint1 + travelVector.ScalarMult(0.5f * accel * float(intervals[0].intervalLengthMS * intervals[0].intervalLengthMS)) + intervals[1].b.ScalarMult(float(intervals[1].intervalLengthMS));

			intervals[3].startTimeMS = intervals[2].startTimeMS + intervals[2].intervalLengthMS;
			intervals[3].intervalLengthMS = p_pauseAtEndpointMS;
			intervals[3].a = Vector3d(0, 0, 0);
			intervals[3].b = Vector3d(0, 0, 0);
			intervals[3].c = p_endpoint2;

			// handle 2 to 1
			int totalTimeTravelling2to1 = p_totalTimePerCycleMS - totalTimeTravelling1to2 - p_pauseAtEndpointMS * 2; // make sure it's perfect!
			denominator = p_maxVelocityPerMS * totalTimeTravelling2to1 - totalDistance;
			if (denominator == 0)
			{
				// this should have happened already, but whatever
				// no acceleration/deceleration
				SetLinear(p_endpoint1, p_endpoint2, p_totalTimePerCycleMS, p_pauseAtEndpointMS, p_offsetMS);
				return;
			}
			if (denominator < 0)
			{
				// this should have happened already, but whatever
				throw gcnew Exception("Max velocity not enough to cover distance between endpoints with indicated times");
			}
			accel = p_maxVelocityPerMS * p_maxVelocityPerMS / denominator;
			// note: timeAccelerating might have rounding, but since we are dealing with MS, it shouldn't be a big deal at all.
			timeAccelerating = int(p_maxVelocityPerMS / accel);
			timeTravellingMaxVelocity = totalTimeTravelling2to1 - timeAccelerating * 2; // make sure total is perfect!
			if (timeTravellingMaxVelocity < 0)
			{
				throw gcnew Exception("Max velocity too high to decelerate and meet the total time cycle");
			}
			travelVector = (p_endpoint1 - p_endpoint2).ScalarMult(1.0f / totalDistance);

			intervals[4].startTimeMS = intervals[3].startTimeMS + intervals[3].intervalLengthMS;
			intervals[4].intervalLengthMS = timeAccelerating;
			intervals[4].a = travelVector.ScalarMult(0.5f * accel);
			intervals[4].b = Vector3d(0, 0, 0);
			intervals[4].c = p_endpoint2;

			intervals[5].startTimeMS = intervals[4].startTimeMS + intervals[4].intervalLengthMS;
			intervals[5].intervalLengthMS = timeTravellingMaxVelocity;
			intervals[5].a = Vector3d(0, 0, 0);
			intervals[5].b = travelVector.ScalarMult(p_maxVelocityPerMS);
			intervals[5].c = p_endpoint2 + travelVector.ScalarMult(0.5f * accel * float(intervals[4].intervalLengthMS * intervals[4].intervalLengthMS));

			intervals[6].startTimeMS = intervals[5].startTimeMS + intervals[5].intervalLengthMS;
			intervals[6].intervalLengthMS = timeAccelerating;
			intervals[6].a = travelVector.ScalarMult(0.5f * -accel);
			intervals[6].b = travelVector.ScalarMult(p_maxVelocityPerMS);
			intervals[6].c = p_endpoint2 + travelVector.ScalarMult(0.5f * accel * float(intervals[4].intervalLengthMS * intervals[4].intervalLengthMS)) + intervals[5].b.ScalarMult(float(intervals[5].intervalLengthMS));

			intervals[7].startTimeMS = intervals[6].startTimeMS + intervals[6].intervalLengthMS;
			intervals[7].intervalLengthMS = p_totalTimePerCycleMS - intervals[7].startTimeMS; // make it perfect!
			intervals[7].a = Vector3d(0, 0, 0);
			intervals[7].b = Vector3d(0, 0, 0);
			intervals[7].c = p_endpoint1;

			////////

			maxTimerMS = p_totalTimePerCycleMS; // should be intervals[7].startTimeMS + intervals[7].intervalLengthMS
			priorPositionValid = false;
			currentMS = 0;
			offsetMS = p_offsetMS;
		}
	};

	public class PlatformPlayerData
	{
	public:
		Vector3d position; // a single position, which will be evaluated to a specific collision module given cirumstances.  Should be at feet so that standing and crouching don't change position,
							// but this forces a calculation when crouching during a jump, which should be aroudn the center of gravity of the character
		PlatformDirection facing;
		PlatformDirection walkDirection;
		PlatformPosture posture;
		Vector3d velocity; // how is the character currently moving? (left/right move, up/down move)
		PlatformPlayerCollisionBlock collisionBlock; // what is the collision model for the player?  (change its posture as appropriate)
		bool onSurface; // do feet have purchase on something the player is standing on?
		int walkTimerMS; // walking stages
		bool jumping; // is character trying to jump? (saved for after horizontal move to see if character is under a ceiling)
		bool alreadyJumped; // control already pressed, don't allow repeated jumps by holding the key
		unsigned long forceCrouchMS; // time left for forced crouch
		float fallDistance; // how far has player fallen?
		PlatformerPlatform *currentPlatform;  // which platform is the player standing on? (if != nullptr, onSurface will also be true here)

		PlatformPlayerData()
		{
			posture = PlatformPosture::Standing;
		}

		void SetPosture(PlatformPosture p_posture)
		{
			posture = p_posture;
			collisionBlock.SetPosture(posture, onSurface, position.y);
		}

		void ChangeJumpPosture()
		{
			if (posture == PlatformPosture::Standing)
			{
				if (velocity.y < 0.0f && velocity.y > -0.75f) // cellSize = 80.0f, proportional
					SetPosture(PlatformPosture::Crouching);
			}
			else
			{
				if (velocity.y > 0.5f) // cellSize = 80.0f, proportional
					SetPosture(PlatformPosture::Standing);
			}
		}

		bool FallenOnPlatform(PlatformerPlatform &p_platform, Vector3d &p_playerPosition)
		{
			// get movement rectangle on platform and compare against indicated position
			float leftMost = p_playerPosition.x + collisionBlock.leftOffset + 14.5f; // ignore 2.5 pixels
			float rightMost = p_playerPosition.x + collisionBlock.rightOffset - 14.5f; // ignore 2.5 pixels

			if (rightMost <= p_platform.collisionBlockLeft)
				return false;
			if (leftMost >= p_platform.collisionBlockRight)
				return false;
			if (position.y >= p_platform.collisionBlockBottom) // even with bottom doesn't cut it, no purchase
				return false;
			if (position.y < p_platform.collisionBlockTop) // even with top works
				return false;

			return true;
		}

		bool StandingOnPlatform(PlatformerPlatform &p_platform, Vector3d &p_playerPosition)
		{
			// get movement rectangle on platform and compare against indicated position
			float leftMost = p_playerPosition.x + collisionBlock.leftOffset + 14.5f; // ignore 2.5 pixels
			float rightMost = p_playerPosition.x + collisionBlock.rightOffset - 14.5f; // ignore 2.5 pixels

			if (rightMost <= p_platform.collisionBlockLeft)
				return false;
			if (leftMost >= p_platform.collisionBlockRight)
				return false;

			return true;
		}
	};

	enum PlatformCellType
	{
		Empty = 0, // empty
		Solid = 1  // standable or obstacle
	};

	public class PlatformerCell
	{
	public:
		PlatformCellType type;

		// note: for two horizontal adjacent cells, the left cell's right = the right cell's left value, etc.
		float left;
		float top;
		float right;
		float bottom;

		gcroot<GameTexture ^> textureRef; // what should be used to draw it?

		// for width and height, go to the PlatformerCellMap qualities

		PlatformerCell()
		{
			type = PlatformCellType::Empty;
			textureRef = nullptr;
		}
	};

	public class PlatformerCellMap
	{
		// rectangular map
	public:
		float left, top;  // what is upper left coordinate? (supports submaps for a more complex system, later)

		// number of cells in array
		int cellHorizontalQty;
		int cellVerticalQty;

		// what is the world dimension of the cells?
		float cellWidth;
		float cellHeight;

		float mapWidth;
		float mapHeight;

		PlatformerCell *cells;

		PlatformerCellMap()
		{
			cells = nullptr;
			cellHorizontalQty = 0;
			cellVerticalQty = 0;
		}

		~PlatformerCellMap()
		{
			if (cells != nullptr)
			{
				delete [] cells;
				cellHorizontalQty = 0;
				cellVerticalQty = 0;
			}
		}

		PlatformerCell * GetCell(int p_cellX, int p_cellY)
		{
			return &(cells[cellHorizontalQty * p_cellY + p_cellX]);
		}

		void Initialize(float p_left, float p_top, int p_cellHorizontalQty, int p_cellVerticalQty, float p_cellWidth, float p_cellHeight)
		{
			left = p_left;
			top = p_top;

			cellHorizontalQty = p_cellHorizontalQty;
			cellVerticalQty = p_cellVerticalQty;
			cellWidth = p_cellWidth;
			cellHeight = p_cellHeight;

			cells = new PlatformerCell[cellHorizontalQty * cellVerticalQty];
			for (int h = 0; h < cellHorizontalQty; h++)
			{
				for (int v = 0; v < cellVerticalQty; v++)
				{
					PlatformerCell *cell = GetCell(h, v);
					cell->left = left + float(h) * cellWidth;
					cell->top = top + float(v) * cellHeight;
					cell->right = left + float(h + 1) * cellWidth;
					cell->bottom = top + float(v + 1) * cellHeight;
				}
			}

			mapWidth = cellWidth * cellHorizontalQty;
			mapHeight = cellHeight * cellVerticalQty;
		}

		bool PlayerIsAgainstBlockOnRight(PlatformPlayerData &p_playerData)
		{
			return PlayerIsAgainstBlockOnRight(p_playerData, p_playerData.position);
		}
		bool PlayerIsAgainstBlockOnRight(PlatformPlayerData &p_playerData, Vector3d &p_position)
		{
			// see if player is touching a block to the right (on edge or is inside)
			// do not ignore any pixels
			float upperMost = p_position.y + p_playerData.collisionBlock.topOffset;
			float lowerMost = p_position.y + p_playerData.collisionBlock.bottomOffset;
			int upperCellV = int((upperMost - top) / cellHeight);
			int lowerCellV = int((lowerMost - top) / cellHeight);
			// do not count block that player is exactly touching on lower side
			if (lowerCellV == (lowerMost - top) / cellWidth)
				lowerCellV--;

			int cellH = int((p_position.x + p_playerData.collisionBlock.rightOffset - left) / cellWidth); // includes being right on the border, so no need for correction here

			for (int v = upperCellV; v <= lowerCellV; v++)
				if (GetCell(cellH, v)->type == PlatformCellType::Solid)
					return true;

			return false;
		}

		bool PlayerIsAgainstBlockOnLeft(PlatformPlayerData &p_playerData)
		{
			return PlayerIsAgainstBlockOnLeft(p_playerData, p_playerData.position);
		}
		bool PlayerIsAgainstBlockOnLeft(PlatformPlayerData &p_playerData, Vector3d &p_position)
		{
			// see if player is touching a block to the left (on edge or is inside)
			// do not ignore any pixels
			float upperMost = p_position.y + p_playerData.collisionBlock.topOffset;
			float lowerMost = p_position.y + p_playerData.collisionBlock.bottomOffset;
			int upperCellV = int((upperMost - top) / cellHeight);
			int lowerCellV = int((lowerMost - top) / cellHeight);
			// do not count block that player is exactly touching on lower side
			if (lowerCellV == (lowerMost - top) / cellWidth)
				lowerCellV--;

			int cellH = int((p_position.x + p_playerData.collisionBlock.leftOffset - left) / cellWidth);
			// do not use cell result if we are exactly on the border, go left one
			if (cellH == (p_position.x + p_playerData.collisionBlock.leftOffset - left) / cellWidth)
				cellH--;

			for (int v = upperCellV; v <= lowerCellV; v++)
				if (GetCell(cellH, v)->type == PlatformCellType::Solid)
					return true;

			return false;
		}
		bool PlayerIsStandingOnBlock(PlatformPlayerData &p_playerData)
		{
			return PlayerIsStandingOnBlock(p_playerData, p_playerData.position);
		}
		bool PlayerIsStandingOnBlock(PlatformPlayerData &p_playerData, Vector3d &p_position)
		{
			// see if player is standing exactly on a block (used when onSurface = true)
			// ignore left <3 pixels and right >3 pixels (3 is enough to stand on one)
			// assumed that player position in even with the top of the cell row to check
			float leftMost = p_position.x + p_playerData.collisionBlock.leftOffset + 14.5f; // ignore 2.5 pixels
			float rightMost = p_position.x + p_playerData.collisionBlock.rightOffset - 14.5f; // ignore 2.5 pixels
			int leftCellH = int((leftMost - left) / cellWidth);
			int rightCellH = int((rightMost - left) / cellWidth);
			// do not count block that player is exactly touching on right side
			if (rightCellH == (rightMost - left) / cellWidth)
				rightCellH--;

			int cellV = int((p_position.y - top) / cellHeight); // should be exact, assuming position.y is even with the top row of the cell to check (assumed condition of onsurface = true)

			for (int h = leftCellH; h <= rightCellH; h++)
				if (GetCell(h, cellV)->type == PlatformCellType::Solid)
					return true;

			return false;
		}
		bool PlayerIsStandingUnderBlock(PlatformPlayerData &p_playerData, Vector3d &p_position)
		{
			// see if player is standing exactly on a block (used when onSurface = true)
			// ignore left <3 pixels and right >3 pixels (3 is enough to stand on one)
			// assumed that player position in even with the top of the cell row to check
			float leftMost = p_position.x + p_playerData.collisionBlock.leftOffset + 14.5f; // ignore 2.5 pixels
			float rightMost = p_position.x + p_playerData.collisionBlock.rightOffset - 14.5f; // ignore 2.5 pixels
			int leftCellH = int((leftMost - left) / cellWidth);
			int rightCellH = int((rightMost - left) / cellWidth);
			// do not count block that player is exactly touching on right side
			if (rightCellH == (rightMost - left) / cellWidth)
				rightCellH--;

			int cellV = int((p_position.y - top) / cellHeight);
			// could be on platform or a block, check accordingly
			int topCellV = cellV - 3;
			int bottomCellV = cellV - 3;
			if (cellV != ((p_position.y - top) / cellHeight))
			{
				bottomCellV += 1; // check two rows (head just below or inside)
			}

			for (int h = leftCellH; h <= rightCellH; h++)
			{
				for (int v = topCellV; v <= bottomCellV; v++)
				{
					if (v >= 0) // validate v
					{
						if (GetCell(h, v)->type == PlatformCellType::Solid)
							return true;
					}
				}
			}

			return false;
		}
		bool PlayerHasFallenOnBlock(PlatformPlayerData &p_playerData)
		{
			return PlayerHasFallenOnBlock(p_playerData, p_playerData.position);
		}
		bool PlayerHasFallenOnBlock(PlatformPlayerData &p_playerData, Vector3d &p_position)
		{
			// see if player is standing exactly on a block or has partially passed into one
			// ignore left <3 pixels and right >3 pixels (3 is enough to stand on one)

			// other routine works!  yay!  If partially into a cell, the rounding on cellV still works
			return PlayerIsStandingOnBlock(p_playerData, p_position);
		}

		float CellYToStandOn(Vector3d &p_position)
		{
			int cellV = int((p_position.y - top) / cellHeight);
			return float(cellV) * cellHeight + top;
		}
	};

	public class PlatformerViewport
	{
	public:
		Vector3d center;  // viewpoint, basically, for rendering - also affects whether or not some objects disappear from the gamestate, like a thrown weapon

		// size of viewport
		float width;
		float height;

		// full snap
		Vector3d CalculateCenter(PlatformerCellMap &p_cellMap, PlatformPlayerData &p_player)
		{
			// todo: horizontal centering should always snap to the player, but vertical should remain constant until the player in on a surface, and even then move to it at a given speed, not snap there
			// although at a map start or a teleport (optionally), it should absolutely snap

			Vector3d proposedCenter;
			if (p_player.onSurface == false)
				proposedCenter = Vector3d(p_player.position.x + p_player.collisionBlock.leftOffset + p_player.collisionBlock.width / 2.0f, p_player.position.y + p_player.collisionBlock.topOffset + p_player.collisionBlock.height / 2.0f, 0);
			else
			{
				// don't let crouch interfere
				if (p_player.posture == PlatformPosture::Standing)
					proposedCenter = Vector3d(p_player.position.x + p_player.collisionBlock.leftOffset + p_player.collisionBlock.width / 2.0f, p_player.position.y + p_player.collisionBlock.topOffset + p_player.collisionBlock.height / 2.0f, 0);
				else
					// adjust for crouch (-35.0f) - todo: move this to an intelligent class, like the collision block class
					proposedCenter = Vector3d(p_player.position.x + p_player.collisionBlock.leftOffset + p_player.collisionBlock.width / 2.0f, p_player.position.y + p_player.collisionBlock.topOffset - 35.0f + (p_player.collisionBlock.height + 35.0f) / 2.0f, 0);
			}
			// don't let center be placed such that anything outside the cell map would be displayed in the viewport
			// todo: doesn't support left/top in cellmap yet, assumes left,top is at 0,0
			if (proposedCenter.x - (width / 2.0f) < 0)
				proposedCenter.x = width / 2.0f;
			if (proposedCenter.y - (height / 2.0f) < 0)
				proposedCenter.y = height / 2.0f;
			if (proposedCenter.x + (width / 2.0f) > p_cellMap.mapWidth)
				proposedCenter.x = p_cellMap.mapWidth - (width / 2.0f);
			if (proposedCenter.y + (height / 2.0f) > p_cellMap.mapHeight)
				proposedCenter.y = p_cellMap.mapHeight - (height / 2.0f);

			return proposedCenter;
		}
		// with gradual snap when player is on a surface, otherwise leave y alone
		Vector3d CalculateCenter(PlatformerCellMap &p_cellMap, PlatformPlayerData &p_player, float p_elapsedTimeMSf, Vector3d &p_currentCenter)
		{
			// calculate first with full snap
			Vector3d proposedCenter = CalculateCenter(p_cellMap, p_player);
			Vector3d originalProposedCenter = proposedCenter;

			// gradually move current y to proposed y
			// don't move up until the player lands
			if (p_player.onSurface == false && proposedCenter.y < p_currentCenter.y)
				// still in the air - don't adjust y at all
				proposedCenter.y = p_currentCenter.y;
			else
			{
				float ySnapAmountPerMS = 60.0f / 66.0f; // 0.5 block per 33ms (quarter speed of falling)
				float yOffset = proposedCenter.y - p_currentCenter.y;
				float timeToSnapFull = abs(yOffset / ySnapAmountPerMS);
				// if elapsed time isn't enough to snap full, do a partial
				if (timeToSnapFull > p_elapsedTimeMSf)
				{
					if (yOffset > 0.0f)
						proposedCenter.y = p_currentCenter.y + ySnapAmountPerMS * p_elapsedTimeMSf;
					else
						proposedCenter.y = p_currentCenter.y - ySnapAmountPerMS * p_elapsedTimeMSf;

					// follow falling character
					if (proposedCenter.y < (originalProposedCenter.y - height * 0.25f))
					{
						proposedCenter.y = originalProposedCenter.y - height * 0.25f;
						// clamp vertically to map as with original
						if (proposedCenter.y + (height / 2.0f) > p_cellMap.mapHeight)
							proposedCenter.y = p_cellMap.mapHeight - (height / 2.0f);
					}

				}
				else
				{
					// testing only
					int a = 1;
				}
			}

			return proposedCenter;
		}
	};

	public ref class PlatformerCellGame : public GameBase
	{
		// 80.0 world = one cell.  Two cells = 6 feet.  Cells are square.  For Castlevania style, 5.0 = 1 pixel (blocks are 16x16)

		// designed around cells, like Castlevania, rather than being more sophisticated like Rayman legends
		// uses animated sprites
		// camera stays centered on player object, does not allow map to scroll beyond its limit
		// (if it scrolls vertically, what is the logic of when the map scrolls?  Should it scroll with jumps or just when the player lands?)
		// After watching a Castlevania IV video, scroll up to catch up to the player on a landing, never scroll while jumping up.
		// But immediately follow down on a fall
		// More sophisticated maps are made up of submaps with their own scroll limits - the engine should be smart enough to decide with the scrolling limits are depending on the submaps
		//   that are currently displayed (in one instance, the map forcibly scrolled up and locked when the palyer moved from a cavernous area on to outside ground)
		// This demo will just be one large simple rectangular map with blocks, moving platforms, decorative objects, a slower scrolling background with moving clouds, etc.
		// Moving platformers can move linearly or with a sine curve, possibly with a max speed in the middle, maybe even lowering with an acceleration that is faster than gravity to make you fall
		//   to your death if you don't get off soon enough
		// how much should the player object be close to the edge before they fall and are shunted into the open space (ignoring any movement until their feet have purchase again)?
		// should a platform moving away drag a player off a cell, or does it matter which one the player had purchase on when the decision would be made?
		// collisions could be checked by just looking for overlap (such as a falling character hitting a raise platform) or lookign for first collision as usual (which would help with the falling platform situation)
		// this game could also be played in stepped with an agreed amount of movement per step, like in Diablo 2, so that all movements are distinct and require less calculation

		// todo:
		// land on and blocked by blocks (can there continue to be a sideways velocity if you jump but hit an upper wall?  seems fair to do - set this up in the level)
		// - for now, check whenever Simon reaches a block border while travelling left, right or down (not up).  Set the coordinate perfectly at these times rather than advance with math, then do the compare.
		// - keep sideways velocity throughotu a jump - just stop it when a block impedes movement but allow the sideways movement when the block is no longer in the way
		// - bottom of blocks don't block jumps, but having a block directly above you will prevent starting a jump (being inside a block does not)
		// - if pass up into a block while jumping sideways, stop sideways movemetn if there is any amount of block in front of Simon
		// - max falling speed
		// - if walk off a block, immediately max falling distance with sideways velocity
		// - if somehow inside a block when standing on another, sideways walking into more block is stopped but jumping is not (unless there is a block directly above Simon)
		// - center keeps same y until Simon goes up too far or down too far or lands on another block.  moves quickly to new y.  x always snaps immediately.  be ready to init center so that it snaps
		//     in the right circumstances
		// - it is possible for Simon to end up inside a block at the moment he goes from crouching to standing.  So watch for this circumstance.  If this happens, move him on top of that block and end the jump.
		// if fall long distance, crouch for a moment with no chance to move
		// then move on to moving platforms (sideways, up and down)

		// 460ms per walk cycle, even amount per stage, 4 stages, 0-114 standing, 115-229 midstride, 23-344 other stride, 343-459 midstride

		// if walk off an edge, fall down at max speed immediately, and if fall a certain distance, crouch at teh botth for half a second or so?
		// enforce max fall speed - 8.5 blocks in 280 ms = ~2.42 y = 1 block per 33ms

		// Platforms
		// width of two blocks, height of half a block
		// platforms are never interrupted.  just move them according to the time and record their begin and end corodinates in case the player is standing on one, then move the player.
		// coordinate is at bottom center of platform, jsut like Simon
		// Simon is either on a block or on a platform when he's on a surface.  this cannot change even if the platform moves and puts him mostly on a block.  He must walk to change this state,
		//   and if he is enough on a block to stand on it, the block takes over
		// both the block and the platform have the same threshold for slipping off
		// if Simon walks while on a moving horizontal platform, he moves in relation to the level as if the platform was not moving.  If he is not walking, then the platform determines his next position as it
		//   changes its x coordinate.  Vertical platforms change Simon's y coordinate always, and his x corod changes as he walks.
		// Platforms do not add to or subtract from Simon's velocity for walking or jumping.  He always moves as if the platform was never there, when he moves or jumps.
		// if Simon is on a block and walks to be part on block and part on platform, he is still ont he block until he is past the threshold to slip off - then the platform takes over
		// - define:
		// - 1- endpoints, linear, speed, amount of pause at each end
		// - 2- endpoints, accel mode, top speed defined, amount of time for a full cycle (makes it each to keep synced with another platform), error if can't determine
		// - etc.
		// - each definition sets it up so that a maxMS is used to cycle, and the ms on the platform determines its coordinates.  all the engine has to do is tell the platform what time it is.
		// - It is possible to have a platform that moves at zero with both endpoint the same.  It just doesn't move at all.  This can be used ot test stationary platforms.
		// - It is also possible to have platforms that travel diagonally.
		// - if Simons encounters a barrier while on a platform, hell will be shunted.  If that forces him off the platform, he falls if now not standing on a block.  He is even shunted if he is crouching.
		//     if he falls while crouching, he should stand.
		// - test - if required to crouch to get past an obstacle, Simon shoudln't be allowed within that obstacle to jump and get on top of it.  His head being inside a block should also be enough to
		//    prevent a jump.
		// - test - allow Simon to jump stright up through a platform and get on top of it?  Does he have to get above it or can it shunt him upward?  If there is a block there too, which one gets precedence?  The one with the higher y.
		//		what if they are equal?  probably the block.
		// - test - can Simon slip up on to a platform by simply walking on to it (think of a platform almost level with a block it is above, and Simon is walking ont he block)?
		//      is there a tolerance that will allow this?  Or does he need to jump always?
		// - test - hi velocity platform going up, and Simon jumps.  It shoudl itnercept him and interrupt his jump rather than let the platform pass through him and let him fall
		// - test - Simon falling fast towards a platform rising fast.  Should detect him landing on it - but with only overlap collisions being tested... perhaps the collision block for the platform
		//      should be offset by how much the platform moved.  Seems simple enough
		// - test - if on a platforma nd block is above or in head, don't allow jump
		// - test - don't let platform transfer cahracter to another platform withotua  jump - whichever platform is highest when Simon lands, that's the one that wins
		// - test - don't let a platform take Simon through a block downward - up is ok
		// - test - slipping off a platform on to another platform should be possible even if the platforms are very close vertically - if this ends up being a problem, might need to decrease the ms chunk process from 16 to 10, or less.
		// handling player:
		// - tag which platform player is on so that platform can affect the player's sideways movements if they are not moving sideways, or vertical movement
		// - when jump, untag platform
		// - when fall off or give precedence to a block or platform by walking or being shoved, untag platform
		// - at beginning of move character loop, before moving the character, check for being on platform immediately (onSurface MUST be false) - also check when posture changes.  then check according to newPosition later
		// - check for moving into blocks, and being deposited on a block (character should NEVER be allowed to pass down through a block because a platform is moving down)
		// - slip off with same tolerance as slipping off a block
		// ok, algorithm upgrades:
		// - move platforms before moving before to establish their movement offsets
		// - early in moveplayer, if player is not on a surface, immediately see if he is on a platform now (use combined movement collision block vertically, current horizontally).  if so, shunt him to it vertically, stop his y velocity and ignore the y movement that tick
		// - when player changes jump posture, check platforms again
		// - etc. move on platform, consider x, collide with blocks, walk off, blah blahm head inside block prevents jumping blah
		// - possible to collide with both a platform and a block, so discriminate if that happens
		// - if crouching and drop off a platform, stand up,a dn check for block collision
		// bugs:
		// - if player is jumping sideways, x movment should stop when he lands in the loop, but still continue if the player is pressing to the side, so that there are no hiccups in the movement.  right now there are
		//    no hiccups because the player continues to slide in the x direction until the next HandleControls, which he realyl shoudln't do if he's not holding the control
		// - if player lands during a crouch, player will stand up until next handlecontrols, so there will be a flicker of standing

	public:

		PlatformPlayerData *player;
		PlatformerViewport *viewport;
		GameTimer *timer;
		float cellSize = 80.0f;
		float worldPer10Feet = cellSize * 3.0f; // cellSize * 3.33325f; // a block is 80x80, character is 160 tall
		PlatformerCellMap *cellMap;
		LinkedList<PlatformerPlatform> *platforms;

		PlatformerCellGame(HWND p_hWnd) : GameBase(p_hWnd)
		{
			player = nullptr;
			viewport = nullptr;
			timer = nullptr;
			cellMap = nullptr;
		}

		virtual ~PlatformerCellGame()
		{
			Destroy();
		}

		void ViewportSizeChanged(GameViewport ^p_viewport) override
		{
			viewport->width = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth());
			viewport->height = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight());
		}

		void Initialize() override
		{
			DestroyGameData();

			// set up file resources and textures
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevaniablock1.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Block1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevaniablock1.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevaniabrick1.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevaniabrick1.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_simon_sprites.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Simon", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_simon_sprites.bmp"), GameColor(76, 88, 100));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_pillarbaseleft.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("PillarBaseLeft", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_pillarbaseleft.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_pillarbaseright.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("PillarBaseRight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_pillarbaseright.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_pillarleft.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("PillarLeft", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_pillarleft.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_pillarright.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("PillarRight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_pillarright.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_pillardecayedleft.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("PillarDecayedLeft", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_pillardecayedleft.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_pillardecayedright.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("PillarDecayedRight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_pillardecayedright.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_window.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Window", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_window.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_black.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Black", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_black.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_blackright.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("BlackRight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_blackright.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_blackarchleft.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("BlackArchLeft", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_blackarchleft.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_blackarchright.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("BlackArchRight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_blackarchright.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_holeupper.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("HoleUpper", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_holeupper.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_holebottomleft.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("HoleBottomLeft", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_holebottomleft.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_holebottomright.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("HoleBottomRight", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_holebottomright.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("castlevania_platform.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Platform", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("castlevania_platform.bmp"), GameColor(76, 88, 100));
			//GameContext::Instance->FileRegistry.RegisterFileResource("xxxx.bmp");
			//GameContext::Instance->TextureRegistry.RegisterTexture("xxxx", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("xxxx.bmp"));

			viewport = new PlatformerViewport();
			viewport->width = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth());
			viewport->height = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight());

			timer = new GameTimer();

			cellMap = new PlatformerCellMap();
			cellMap->Initialize(0.0f, 0.0f, 48, 27, cellSize, cellSize);  // four HD screens worth of blocks
			String ^mapBlocks = R"(	0000   00000000000000000000000000000000000000000
									0[]  w      w  [] w  w  w  {]  u            w[]0
									0[]      w  u  [}          [] ,. w           {}0
									00000      ,.  00000000000000        /\000000{]0
									0{]   000000   0] /\       [0        Oo      []0
									0{} w   []  w 00} Oo     u [0   000000   w   []0
									0[}     [}     0] 000000,. {0  0             []0
									0[] u w {]   000]   [0]    [0 0  w  /\       []0
									0{},.   ()     0}   [0]  0000       Oo  w    [00
									0[]000000000   0000 [0]    {0   u         /\ {]0
									0[]     [}     0}   [00 /\ [0  ,.         Oo {}0
									00]  w  []  w  0] u [0] Oo [000  0  00  0000 []0
									00)     ()     00,. [0]  0000                []0
									0000   0000    []   [000   {]       w     w  []0
									00000  0000000 ()   00)    ()   000          []0
									000000000000000000  0000000000      00000    [}0
									0{}  w u w    w       w    0  0       {}  00 {}0
									0[}   ,.          u        0   u  w   [}   /\()0
									00]u  000000 /\  ,.0000000    ,.      [}   Oo000
									0[}. 0 {]    Oo  00 [] []    w        []     [}0
									0{} 0  [}    00     [}w[] /\     w    () 000 {}0
									0[]/\  []  00[]     {] [} Oo  u      0000    []0
									0[]Oo  ()    {]  w  [}w{]    ,.   00  {}    u[}0
									0[]   000    [}     [] {]  000000 []  {]   ,.{}0
									0[]  000000  []  00 []w[] ,000000 ()  []  w  {00
									0() 0000000000)  () () ()  0000000000 ()     (00
									000000000000000000000000000000000000000000000000								
		)";
			int mapStringIndex = 0;
			String ^validCharacters = " [](){}0wOo/\\u.,";
			for (int v = 0; v < cellMap->cellVerticalQty; v++)
			{
				for (int h = 0; h < cellMap->cellHorizontalQty; h++)
				{
					while (validCharacters->IndexOf(mapBlocks->Substring(mapStringIndex, 1)) == -1)
						mapStringIndex++;

					if (mapBlocks->Substring(mapStringIndex, 1) == " ")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("Brick1");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "[")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("PillarLeft");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "]")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("PillarRight");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "(")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("PillarBaseLeft");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == ")")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("PillarBaseRight");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "{")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("PillarDecayedLeft");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "}")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("PillarDecayedRight");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "w")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("Window");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "O")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("Black");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "o")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("BlackRight");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "/")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("BlackArchLeft");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "\\")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("BlackArchRight");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "u")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("HoleUpper");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == ".")					
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("HoleBottomRight");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == ",")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Empty;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("HoleBottomLeft");
					}
					if (mapBlocks->Substring(mapStringIndex, 1) == "0")
					{
						cellMap->GetCell(h, v)->type = PlatformCellType::Solid;
						cellMap->GetCell(h, v)->textureRef = GameContext::Instance->TextureRegistry.GetTexture("Block1");
					}
					mapStringIndex++;
				}
			}

			platforms = new LinkedList<PlatformerPlatform>();
			LinkedListNode<PlatformerPlatform> *newPlatform = nullptr;
			newPlatform = platforms->GetNewNode();
			newPlatform->data.SetLinear(Vector3d(2480.0f, 1720.0f, 0), Vector3d(2720.0f, 1720, 0), 4000, 1000);
			platforms->AddNode(newPlatform);
			newPlatform = platforms->GetNewNode();
			//newPlatform->data.SetLinear(Vector3d(2320.0f, 1720.0f, 0), Vector3d(1600.0f, 1720, 0), 4000, 1000, 1200);
			//newPlatform->data.SetAccelerated(Vector3d(2320.0f, 1720.0f, 0), Vector3d(1600.0f, 1720, 0), 4000, 0, 0.6f, 1200);
			newPlatform->data.SetAccelerated(Vector3d(2320.0f, 1720.0f, 0), Vector3d(1600.0f, 1720, 0), 4000, 1000, 1.0f, 1200);
			platforms->AddNode(newPlatform);
			newPlatform = platforms->GetNewNode();
			newPlatform->data.SetAccelerated(Vector3d(2160.0f, 1680.0f, 0), Vector3d(1520.0f, 1680, 0), 8000, 250, 0.25f, 7750); // so that player falls on next platform down when falls off
			platforms->AddNode(newPlatform);
			newPlatform = platforms->GetNewNode();
			newPlatform->data.SetAccelerated(Vector3d(3120.0, 400.0, 0), Vector3d(3120.0, 1200.0, 0), 8000, 1000, 0.35f, 0);
			platforms->AddNode(newPlatform);
			newPlatform = platforms->GetNewNode();
			newPlatform->data.SetAccelerated(Vector3d(800.0f, 1920.0f, 0), Vector3d(1280.0f, 1920.0f, 0), 5000, 2000, 1.0f, 0);
			platforms->AddNode(newPlatform);
			newPlatform = platforms->GetNewNode();
			newPlatform->data.SetAccelerated(Vector3d(1280.0f, 1960.0f, 0), Vector3d(1280.0f, 1480.0f, 0), 5000, 100, 0.4f, 3500);
			platforms->AddNode(newPlatform);
			newPlatform = platforms->GetNewNode();
			newPlatform->data.SetAccelerated(Vector3d(2960, 2000, 0), Vector3d(2960, 1600, 0), 4000, 250, 0.4f, 0);
			platforms->AddNode(newPlatform);

			player = new PlatformPlayerData();
			player->facing = PlatformDirection::Left;
			player->position = Vector3d(cellMap->mapWidth / 2.0f, cellMap->mapHeight - cellMap->cellHeight, 0); // bottom middle of map for now
			player->velocity = Vector3d(0, 0, 0);
			player->onSurface = true;
			player->SetPosture(PlatformPosture::Standing);
			player->walkDirection = PlatformDirection::None;
			player->walkTimerMS = 0;
			player->jumping = false;
			player->alreadyJumped = false;
			player->forceCrouchMS = 0;
			player->fallDistance = 0;
			//player->currentPlatform = &(platforms->GetFirstNode()->next->data);
			player->currentPlatform = nullptr;

			// initialize center without gradual snap
			viewport->center = viewport->CalculateCenter(*cellMap, *player);

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (player != nullptr)
			{
				delete player;
				player = nullptr;
			}
			if (viewport != nullptr)
			{
				delete viewport;
				viewport = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (platforms != nullptr)
			{
				delete platforms;
				platforms = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			timer->Poll();
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			HandleControls();

			mouse.ZeroOffsets();

			Animate(timer->GetElapsedTimeMS());

			// do this at end of rendering instead, we need elapsed time there for center snapping
			//timer->ResetElapsedTime();

			return true;
		}

		void HandleControls()
		{
			bool forceCrouch = false;
			if (player->forceCrouchMS <= timer->GetElapsedTimeMS())
			{
				player->forceCrouchMS = 0;
			}
			else
			{
				player->forceCrouchMS -= timer->GetElapsedTimeMS();
				forceCrouch = true;
			}
			if (forceCrouch == false && keyboardKeys.GetKey('S')->IsPressed() == false && player->onSurface == true)
			{
				// stand up so that sideways movement takes during this tick
				player->SetPosture(PlatformPosture::Standing);
			}

			// check horizontal first, since if jump is activated we won't ahve a chance to stop moving horizontally if we have released the key
			if (forceCrouch == false && keyboardKeys.GetKey('A')->IsPressed() && player->onSurface == true && keyboardKeys.GetKey('D')->IsPressed() == false && player->posture == PlatformPosture::Standing)
			{
				player->velocity.x = cellSize * -4.0f / 1060.0f; // 4 blocks per 1.06 second
				player->facing = PlatformDirection::Left;
			}
			else if (forceCrouch == false && keyboardKeys.GetKey('D')->IsPressed() && player->onSurface == true && keyboardKeys.GetKey('A')->IsPressed() == false && player->posture == PlatformPosture::Standing)
			{
				player->velocity.x = cellSize * 4.0f / 1060.0f; // 4 blocks per 1.06 second
				player->facing = PlatformDirection::Right;
			}
			else if (player->onSurface == true)
			{
				player->velocity.x = 0; // todo: consider being on a platform

				// face in either direction without moving
				if (keyboardKeys.GetKey('D')->IsPressed() && player->onSurface == true && keyboardKeys.GetKey('A')->IsPressed() == false)
					player->facing = PlatformDirection::Right;
				else if(keyboardKeys.GetKey('A')->IsPressed() && player->onSurface == true && keyboardKeys.GetKey('D')->IsPressed() == false)
					player->facing = PlatformDirection::Left;
			}
			// advance or reset walk timer
			if (player->velocity.x != 0 && player->onSurface == true)
			{
				// walking!
				player->walkTimerMS += timer->GetElapsedTimeMS();
				while (player->walkTimerMS > 460)
					player->walkTimerMS -= 460;
			}
			else
				player->walkTimerMS = 0;

			if (keyboardKeys.GetKey('W')->IsPressed() == false)
				player->alreadyJumped = false; // note control is not pressed, this allows a jump next time
			if (forceCrouch == false && keyboardKeys.GetKey('W')->IsPressed() && player->onSurface == true && keyboardKeys.GetKey('S')->IsPressed() == false && player->alreadyJumped == false)
			{
				player->jumping = true;
				player->alreadyJumped = true;
			}
			else if ((forceCrouch == true || (keyboardKeys.GetKey('S')->IsPressed() && keyboardKeys.GetKey('W')->IsPressed() == false)) && player->onSurface == true)
			{
				// crouch
				player->SetPosture(PlatformPosture::Crouching);
				player->walkTimerMS = 0;
			}
			else if (player->onSurface == true)
			{
				// stand up
				player->SetPosture(PlatformPosture::Standing);
			}
		}

		void Animate(int p_elapsedTimeMS)
		{
			while (p_elapsedTimeMS > 0)
			{
				if (p_elapsedTimeMS > 16)
				{
					MoveObjects(16.0f);
					p_elapsedTimeMS -= 16;
				}
				else if (p_elapsedTimeMS > 0)
				{
					MoveObjects(float(p_elapsedTimeMS));
					p_elapsedTimeMS = 0;
				}
			}
		}

		void MoveObjects(float p_elapsedTimeMSf)
		{
			// must move platforms first so that tehy can interact and affect the player
			MovePlatforms(int(p_elapsedTimeMSf));

			MoveCharacter(p_elapsedTimeMSf);
		}

		void MovePlatforms(int p_elapsedTimeMS)
		{
			LinkedListEnumerator<PlatformerPlatform> enumerator = LinkedListEnumerator<PlatformerPlatform>(*platforms);
			while (enumerator.MoveNext())
			{
				enumerator.Current()->data.Animate(p_elapsedTimeMS);
			}
		}

		void MoveCharacter(float p_elapsedTimeMSf)
		{
			float gravityPerMSMS = cellSize * 1.6f * worldPer10Feet / 10.0f / 1000.0f / 1000.0f; // quad gravity for a fast jump rate (Castlevania's gravity isn't accurate to world scale, it's quadruple)

			// check collisions

			// logic:
			// while moving, whenever the player collision block is moving in an ordinal direction and that ordinal direction encounters a cell border, check the contents of all cells the collision block would encounter
			// if the cell is occupied by something solid, if horizontal, cancel the movement into that cell for that ordinal direction (might be falling, and get past it, we want to keep going that way)
			// if the player is travelling diagonally and encounters a cell corner, cancel the horizontal movement and move vertically if travelling down, and give predence to horizontal if travelling upward.
			// - do this ONLY if there are no blockages from above or beside.
			// encountering a border also means seeing if there is empty space and allowing a sideways move during a jump to continue
			// note: some blocks may only take up have a cell, so really, it's almost as if every 'pixel', that is, every 5.0f, has to be checked
			// note: blocks do not block upward movement, althought they do prevent jumping if the character is standing directly below one.  But once inside a block, horizontal movement is impeded if a block
			//   exists in that direction from the character's collision block

			// algorithm:
			// redo: if the character edge is within < 3.0 pixels of the edge of a block, he falls. (he can be inside the block, and can move away but not towards) Also fails to land on a block
			//    if only 3 pixels worth lands on the block
			// - handle in 10ms chunks to handle hiccups.  Each 10ms should reapply the controls of the player in case the movement has been blocked or cancelled at all (unless forcibly crouching)
			// - so stop at horizontal borders to see if we should stop horiztonal movemetn during a walk or a fall
			// - stop at 2.9 before a back side reaches a border to see if there is no block beneath the character and drop him at max velocity
			// - >> should I just move the character a certain number of pixels in a time slice and shunt them around out of blocks and check things instead because of overlaps?
			// - >> at start, mark which vertical block level character was on.  Check which block front travelling edge is in.  See if movement is stopped by being inside a block.  Then move to final position.  If bottom edge
			//    is now in a new level, see if there is a block there.  If so, shunt upwards and place on surface.  check fall distance to see if need to forcibly crouch.  If side edge is in new block, see if
			//    there is a block there.  If so, shunt back to original edge.  See if <3 pixels standing on block.  If so, drop at full velocity.  This seems a lot simpler.
			// - note: having front edge = beginning of the next block start point put it in the prior block, not the next one.  Same for left edge. etc.
			// - and it's certainly possible to move more than one block downward with the max velocity.  So we have to check multiple block levels - check each of them. (should ideally stop the player along sideways
			//     at the first collision if we detect it?)
			// x todo: don't change screen center until player is on a surface, and snap slowly with y unless falling at velocity higher than the snap speed
			// x todo: if jumping repeatedly against an out cropping, Simon sometimes works his way over just enough and is able to jump up.  This is because he is allowed to move x then still jump, even though
			//    he is now in a place where jumping would not have been allowed.  the jump shouldn't happen after the x move if the criteria fails - this also means that if anythign happens in HandleControls()
			//    because jump wasn't allowed, that now has to happen in MoveCharacter after the jump is halted. (fixed by checking ability to jump after horizontal move)
			// x todo: repeatedly jumping against a wall works Simon into it (fixed by checking ability to jump after horizontal move)
			// x todo: block repeated jumps that occur by holding the up button
			// todo: force crouch at end of a long fall
			// if changing jump posture, check now for an overlap on a cell in the block taken up by the change.  If so, place character on top of the block overlapped and end the jump.  but still handle
			//   sideways movement.
			// (old, nto used) now handle movement collisions:
			// - loop:
			// - determine beginning and end position for time to consume, including downward acceleration if not on a surface, same collision shape for each.  calculate downward velocity according to time consumed (clamp to max), then calculate new position (consider reaching max velocity along the way for this).
			// - for each cell border encountered by a travelling edge (even at time 0) in order of occurrence
			//    - note: a travelling edge means both the upper and lower edge in the case of vertical movement to detect for re-opened sideways movement, and both sideways edges in case the player steps off a block
			//    - note: do NOT assume that the collision black is exactly a block wide or tall.  This algorithm should support games with collision blocks that are thinner, wider, taller, shorter, or equal with block dimensions
			//    - set character position so that that edge perfectly aligns with that axis
			//    - check all cells that could block movement along that axis.
			//        - if any are encountered:
			//        - if movement is downward, place player on surface and end vertical velocity entirely on player for this tick (could get set again if player walks off)
			//		      - todo: if fell far enough (>= 4 blocks at top speed), force a momentary crouch (treat as an attempt to crouch (see next))
			//			  - if not trying to crouch, place character in standing position, otherwise crouch and end all sideways movement for this tick (we are done)
			//        - if movement is sideways, stop that movement for this loop, and don't check again until a vertical edge after movement is encountered (a vertical edge encountered at the same time as the horizontal edge in this case does not count - this avoids infinite loops)
			//        - if player is on surface and there are no blocks beneath him, set onsurface = false and set max fall velocity
			//    - note: do not block upward movement, only left right and down
			//    - note: if overlapping a block, don't allow sideways movement into more block
			//    - note: enforce max velocity
			//    - note: upgrade this for continuing movement because of being on a platform (crouching player can move, etc.)
			//
			// Tweaks to movement:
			// - x to make sideways jump up platforms feel less spongey (make it match Castlevania more), increase jump velocity, save change to stand during jump for just a little later, icnrease toelrance to slip off blockt o 2.5 pixels
			//     this makes jump controls feel tighter, more solid.  The delicacy needed to get to a hard jump location should require intent but not utter surgical accuracy.

			// >>> Remaining todos:
			// - check for collision with platform as player goes from crouch to standing during a jump
			// - check for collision with platform as player is in free fall
			// - in both cases, when a collision with a platform happens, make sure it didn't happen with a higher block - if so, use the block instead!
			// - if move from outside a block to inside a block, shunt to its edge rather than set newposition to current to prevent horizontal movement

			// platform tests:
			/*
			jump up to land on platform, only check when on way down
			jump sideways to land on platform, only check when on way down
			walk off block to transfer to platform, platform is even
			walk off block to land on platform, platform is lower
			walk off block to land on platform - platform VERY close, to check detection
			walk off platform to land on platform
			walk off platform to land on platform - platform VERY close, to check detection
			get pushed off platform while crouching - should stand
			get pushed off platform while crouching - land on block quickly (1/2 block orless down) to check detection
			get pushed off platform while crouching - land on platform quickly (1/2 block or less down) to check detection
			get pushed off platform while crouching - transfer to another platform that is at same level
			walk off platform to another moving platform, same level
			jump up on platform while moving up - shoudl intercept jump and stand again
			jump off platform sideways while moving up, check gamability
			stay on current platform when two platforms cross each other vertically - should not transfer
			jump when two platforms cross and Simon could land on either one - whichever is currently higher vertically is the one Simon transfers to
			- test with a slow fall
			- test with a fast fall
			block pushes Simon off platform
			don't go through block from above when on platform - transfer to block
			allowed to go up through block when riding platform
			can't jump when head is directly below a block or inside one while riding platform
			- test when platform takes head upward into block
			- test when crouching then stand up when on platform
			- allowed when head emerges above block
			walk when on platform - horizontal speed should not be affected by platform (when walking with, forward progress on platform is slow.  When walking against, progress on platform is fast)

			todo:
			- test when paltform is traveling diagonally - handle collisions the same - horizontal first, vertical last
			- get shoved into block on a very fast platform - shoudl line up with block

			-----------

			non-paltform tests

			forced crouch:
			- walk off and falling 4 or more cells should forced crouch
			- jump off and falling 3 or more cells shoudl forced crouch
			- walking off 3, or walking off 2 or jumping off 2 should NOT forced crouch			

			*/

			Vector3d newPosition;
			if (player->onSurface == false)
			{
				// see if player fell on a platform as the platforms moved (player might have fell and platform moved into collision since it animated, etc.)
				PlatformerPlatform *platformCollided = nullptr;
				if (player->velocity.y > 0.0f) // can only land on platform if falling
				{
					LinkedListEnumerator<PlatformerPlatform> enumerator = LinkedListEnumerator<PlatformerPlatform>(*platforms);
					while (enumerator.MoveNext())
					{
						if (player->FallenOnPlatform(enumerator.Current()->data, player->position) == true)
						{
							if (platformCollided == nullptr || platformCollided->collisionBlockTop > enumerator.Current()->data.position.y)
							{
								platformCollided = &(enumerator.Current()->data);
							}
						}
					}
				}
				if (platformCollided != nullptr)
				{
					// hit a platform, don't worry about hitting a block, because that was checked last loop and player's new position hasn't been calculated yet
					player->onSurface = true;
					//player->SetPosture(PlatformPosture::Standing); // don't force standing until next handlecontrols
					player->velocity.y = 0.0f;

					// if fell far enough, force a crouch for a small while
					// don't include any travel, save that for the platform check later
					if (player->fallDistance >= 320.0f)
						player->forceCrouchMS = 300;
					player->fallDistance = 0;

					// shunt to platform surface prior position (player will be moved later)
					player->position.y = platformCollided->priorPosition.y - 40.0f;
					player->currentPlatform = platformCollided;
				}
				else
				{
					PlatformPosture priorPosture = player->posture;
					player->ChangeJumpPosture(); // do this here so that collision detection is accurate to end of tick and changing posture at the end doesn't invalidate the results
					if (player->velocity.y < (cellSize / 33.0f))
						// todo: if velocity.y is close to 2.42, this will momentarily allow a faster fall than 2.42 for one frame (fix: figure out when 2.42 will be reached and calculate in two sections,
						//   one with acceleration, one without)
						newPosition = player->position + player->velocity.ScalarMult(p_elapsedTimeMSf) + Vector3d(0, -1.0f, 0).ScalarMult(0.5f * gravityPerMSMS * p_elapsedTimeMSf * p_elapsedTimeMSf);
					else
						newPosition = player->position + player->velocity.ScalarMult(p_elapsedTimeMSf);
					if (priorPosture != player->posture && player->velocity.y > 0.0f)
					{
						// can only fall on block or platform while falling downward
						// if posture changed while falling, so did collision block, and it got larger, so see if we need to shunt upward and place on surface
						if (cellMap->PlayerHasFallenOnBlock(*player) == true)
						{
							player->onSurface = true;
							//player->SetPosture(PlatformPosture::Standing); // don't force standing until next handlecontrols
							player->velocity.y = 0.0f;
							// shunt to block surface
							player->position.y = cellMap->CellYToStandOn(player->position);
							// will be calculated next
							//newPosition = player->position + player->velocity.ScalarMult(p_elapsedTimeMSf);
							player->fallDistance = 0;
						}
					}
				} // didn't fall on platform from platform movement only
			}

			if (player->onSurface == true)
			{
				if (player->currentPlatform != nullptr)
				{
					newPosition.y = player->position.y + (player->currentPlatform->position.y - player->currentPlatform->priorPosition.y);
					if (player->velocity.x == 0)
						newPosition.x = player->position.x + (player->currentPlatform->position.x - player->currentPlatform->priorPosition.x);
					else
						newPosition.x = player->position.x + (player->velocity.x * p_elapsedTimeMSf);
				}
				else
				{
					// change this for walking, etc.
					newPosition = player->position + player->velocity.ScalarMult(p_elapsedTimeMSf);
				}
			}

			// check collisions between player and environment, adjust velocity accordingly
			// todo: adjust logic for walking sideways vs. jumping straight up or sideways - different logic for each

			// check horizontal
			if (newPosition.x < player->position.x) // works with both walking and being moved by platform
			{
				if (cellMap->PlayerIsAgainstBlockOnLeft(*player) == true)
				{
					// keep original velocity
					newPosition.x = player->position.x;
				}
				else if (cellMap->PlayerIsAgainstBlockOnLeft(*player, newPosition) == true)
				{
					// todo: should we set x = right edge of block?
					// keep original velocity
					newPosition.x = player->position.x;
				}
			}
			if (newPosition.x > player->position.x) // works with both walking and being moved by platform
			{
				if (cellMap->PlayerIsAgainstBlockOnRight(*player) == true)
				{
					// keep original velocity
					newPosition.x = player->position.x;
				}
				else if (cellMap->PlayerIsAgainstBlockOnRight(*player, newPosition) == true)
				{
					// todo: should we set x = left edge of block?
					// keep original velocity
					newPosition.x = player->position.x;
				}
			}
			// screen limits for now
			if (newPosition.x + player->collisionBlock.leftOffset < 0)
			{
				newPosition.x = -player->collisionBlock.leftOffset;
				player->velocity.x = 0;
			}
			if (newPosition.x + player->collisionBlock.rightOffset > cellMap->mapWidth)
			{
				newPosition.x = cellMap->mapWidth - player->collisionBlock.rightOffset;
				player->velocity.x = 0;
			}

			// now apply jump - can't jump if blocks are right above the player - checking ability to jump after the horizontal move keeps player from working their way into a block and getting on top of it
			if (player->jumping == true && cellMap->PlayerIsStandingUnderBlock(*player, newPosition) == false)
			{
				// stand up to jump first
				player->SetPosture(PlatformPosture::Standing);
				player->onSurface = false; // unless there is no room to jump - need to check this
				player->currentPlatform = nullptr;
				player->walkTimerMS = 0;
				// player coord should go up 160.0 (height of character) at the apex of the jump
				// with gravity of 32 ft/sec squared and 6ft = 160 world units, 
				// todo: don't allow jump if there is a block immediately in the way above. (should the player be allowed to jump through a block?)
				player->velocity.y = cellSize / -1.95f * worldPer10Feet / 10.0f / 1000.0f;  //cellSize / -1.95f * worldPer10Feet / 10.0f / 1000.0f; // matches Castlevania's jump rate with quadruple gravity - this gets the character 6 feet up and falls back down in about a second

				// calculate new position ONLY in regards to y, different than above - we don't want to interfere witht he x fixes from the horizontal check
				if (player->velocity.y < (cellSize / 33.0f))
					// todo: if velocity.y is close to 2.42, this will momentarily allow a faster fall than 2.42 for one frame (fix: figure out when 2.42 will be reached and calculate in two sections,
					//   one with acceleration, one without)
					newPosition.y = player->position.y + player->velocity.y * p_elapsedTimeMSf - (0.5f * gravityPerMSMS * p_elapsedTimeMSf * p_elapsedTimeMSf);
				else
					newPosition.y = player->position.y + player->velocity.y * p_elapsedTimeMSf;
			}
			player->jumping = false; // cancel jump - it either happens or it's blocked.

			// check vertical
			if (newPosition.y > player->position.y) // handles falling and being deposited by platform
			{
				if (cellMap->PlayerHasFallenOnBlock(*player, newPosition) == true)
				{
					player->onSurface = true;
					player->currentPlatform = nullptr; // in case player was on a platform
					//player->SetPosture(PlatformPosture::Standing); // don't force standing until next handlecontrols
					player->velocity.y = 0.0f;

					// if fell far enough, force a crouch for a small while
					// include this tick's y travel in the compare (it will be added down below for the next loop)
					if (player->fallDistance + newPosition.y - player->position.y >= 320.0f)
						player->forceCrouchMS = 300;
					player->fallDistance = 0;

					// shunt to block surface
					player->position.y = cellMap->CellYToStandOn(newPosition);
					newPosition.y = player->position.y;
				}
			}
			if (player->onSurface == true) // handle walking off block, walking off platform
			{
				// walked off? pushed off?
				if (player->currentPlatform != nullptr) // check only platform
				{
					if (player->StandingOnPlatform(*(player->currentPlatform), newPosition) == false)
					{
						player->onSurface = false;
						player->currentPlatform = nullptr;
						// todo: see if there is another platform to slip to?  could just check that next tick since new position is already set
						player->velocity.y = cellSize / 33.0f; // 1 block per 33ms - since animation happens per 16ms we should be fine, shouldn't pass through multiple blocks on a tick
					}
				}
				else if (cellMap->PlayerIsStandingOnBlock(*player, newPosition) == false) // player is(or was) on block - if player fell on block above, this should register as true
				{
					player->onSurface = false;
					player->velocity.y = cellSize / 33.0f; // 1 block per 33ms - since animation happens per 16ms we should be fine, shouldn't pass through multiple blocks on a tick
				}
			}

			// set new adjusted position, record fall distance
			// to register fall distance must be falling at least 3/4 as fast as originally jumped - willing jump off ledge 2 high does not crouch, 3 does.
			if (newPosition.y > player->position.y && player->velocity.y > (cellSize * 0.75f / 1.95f * worldPer10Feet / 10.0f / 1000.0f)) //(cellSize * 0.75f / 1.95f * worldPer10Feet / 10.0f / 1000.0f)) 
				player->fallDistance += (newPosition.y - player->position.y);
			player->position = newPosition;

			// screen limit for now
			if (newPosition.y > cellMap->mapHeight)
			{
				newPosition.y = cellMap->mapHeight;
				player->onSurface = true;
				player->SetPosture(PlatformPosture::Standing);
				player->velocity.y = 0;
			}

			if (player->onSurface == false)
			{
				// adjust velocity for gravity for next tick if not standing on anything (otherwise what player is standing on affects the move)
				player->velocity = player->velocity + Vector3d(0, gravityPerMSMS, 0).ScalarMult(p_elapsedTimeMSf);
				// if greater than a certain amount, then set it (which also serves as clamping it)
				if (player->velocity.y > (cellSize / 1.95f * worldPer10Feet / 10.0f / 1000.0f)) //(cellSize / 1.95f * worldPer10Feet / 10.0f / 1000.0f)) // jump speed
					player->velocity.y = cellSize / 33.0f;
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			// note that upper left here is 0,0
			graphics->Set2dWindowProjection(-10.0f, 10.0f);

			// get center of platform viewport
			// find center of player collision block
			// very center of collision block for now (could put slightly lower to account for score, etc. up top)
			Vector3d viewportCenter = viewport->CalculateCenter(*cellMap, *player, timer->GetElapsedTimeMSFloat(), viewport->center);
			viewport->center = viewportCenter;

			// done with time, reset it
			timer->ResetElapsedTime();

			// don't do this for ortho!
			//graphics->DefaultTransform();

			// reverse transform the camera accounting for 0,0 being at the upper left of the viewport
			graphics->Translate(-(viewportCenter.x - viewport->width / 2.0f), -(viewportCenter.y - viewport->height / 2.0f), 0);

			RenderMap(graphics, viewport, viewportCenter);
			RenderObjects(graphics, viewport, player, platforms);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderMap(GraphicsBase *p_graphics, PlatformerViewport *p_viewport, Vector3d &p_center)
		{
			p_graphics->SetDepthWriteEnabled(false);

			// assumes always a 1:1 on viewport pixel size to game 'pixel' size ratio that never changes
			// get range of map cells we should render and only render those
			float left = p_center.x - p_viewport->width / 2.0f;
			float top = p_center.y - p_viewport->height / 2.0f;

			int leftStartIndex = int(left / cellSize);
			int topStartIndex = int(top / cellSize);
			int rightStopIndex = int (leftStartIndex + p_viewport->width / cellSize + 1); // +1 just in case only half a cell on the right side is shown (note: on a perfect division, we will draw one extra column of cells on the right that isn't seen
			int bottomStopIndex = int (topStartIndex + p_viewport->height / cellSize + 1); // +1 just in case only half a cell on the right side is shown (note: on a perfect division, we will draw one extra row of cells on the bottom that isn't seen
			if (rightStopIndex >= cellMap->cellHorizontalQty)
				rightStopIndex = cellMap->cellHorizontalQty - 1;
			if (bottomStopIndex >= cellMap->cellVerticalQty)
				bottomStopIndex = cellMap->cellVerticalQty - 1;

			GameColor colors[1] = { GameColor(255, 255, 255) };
			ModelVertex vertices[4];
			vertices[0].colorIndex = 0;
			vertices[1].colorIndex = 0;
			vertices[2].colorIndex = 0;
			vertices[3].colorIndex = 0;
			ModelVertexTextureCoords texCoords[4];
			texCoords[0].Set(0.0f, 0.0f);
			texCoords[1].Set(1.0f, 0.0f);
			texCoords[2].Set(1.0f, 1.0f);
			texCoords[3].Set(0.0f, 1.0f);
			for (int h = leftStartIndex; h <= rightStopIndex; h++)
			{
				for (int v = topStartIndex; v <= bottomStopIndex; v++)
				{
					PlatformerCell *cell = cellMap->GetCell(h, v);
					vertices[0].vertex = Vector3d(cell->left, cell->top, 0);
					vertices[1].vertex = Vector3d(cell->right, cell->top, 0);
					vertices[2].vertex = Vector3d(cell->right, cell->bottom, 0);
					vertices[3].vertex = Vector3d(cell->left, cell->bottom, 0);
					p_graphics->RenderFilledQuad(colors, 1, vertices, 4, false, cell->textureRef, texCoords, 4);
				}
			}
			p_graphics->SetDepthWriteEnabled(true);
		}

		void RenderObjects(GraphicsBase *p_graphics, PlatformerViewport *p_viewport, PlatformPlayerData *p_player, LinkedList<PlatformerPlatform> *p_platforms)
		{
			RenderPlatforms(p_graphics, p_viewport, p_platforms);
			RenderPlayer(p_graphics, p_viewport, p_player);
		}

		void RenderPlatforms(GraphicsBase *p_graphics, PlatformerViewport *p_viewport, LinkedList<PlatformerPlatform> *p_platforms)
		{
			// camera already set on center, so just render the sprite in place in world coordinates

			GameColor colors[1] = { GameColor(255, 255, 255) };
			ModelVertex vertices[4];
			vertices[0].colorIndex = 0;
			vertices[1].colorIndex = 0;
			vertices[2].colorIndex = 0;
			vertices[3].colorIndex = 0;
			GameTexture ^texture = GameContext::Instance->TextureRegistry.GetTexture("Platform");
			ModelVertexTextureCoords texCoords[4];
			texCoords[0].Set(0.0f, 0.0f);
			texCoords[1].Set(1.0f, 0.0f);
			texCoords[2].Set(1.0f, 1.0f);
			texCoords[3].Set(0.0f, 1.0f);
			int spriteCenterX = 16;
			int spriteCenterY = 8;
			int spriteWidth = 32;
			int spriteHeight = 8;

			LinkedListEnumerator<PlatformerPlatform> enumerator = LinkedListEnumerator<PlatformerPlatform>(*p_platforms);
			p_graphics->SetDepthWriteEnabled(false);
			while (enumerator.MoveNext())
			{
				float worldPerPixel = 5.0f;

				vertices[0].vertex.Set(enumerator.Current()->data.position.x - float(spriteCenterX) * worldPerPixel, enumerator.Current()->data.position.y - float(spriteCenterY) * worldPerPixel, 0);
				vertices[1].vertex.Set(enumerator.Current()->data.position.x + float(spriteWidth - spriteCenterX) * worldPerPixel, enumerator.Current()->data.position.y - float(spriteCenterY) * worldPerPixel, 0);
				vertices[2].vertex.Set(enumerator.Current()->data.position.x + float(spriteWidth - spriteCenterX) * worldPerPixel, enumerator.Current()->data.position.y + float(spriteHeight - spriteCenterY) * worldPerPixel, 0);
				vertices[3].vertex.Set(enumerator.Current()->data.position.x - float(spriteCenterX) * worldPerPixel, enumerator.Current()->data.position.y + float(spriteHeight - spriteCenterY) * worldPerPixel, 0);

				p_graphics->RenderFilledQuad(colors, 1, vertices, 4, true, texture, texCoords, 4);
			}
			p_graphics->SetDepthWriteEnabled(true);
		}

		void RenderPlayer(GraphicsBase *p_graphics, PlatformerViewport *p_viewport, PlatformPlayerData *p_player)
		{
			// viewport already transformed to camera, so just draw character where it is in the world

			GameTexture ^texture = nullptr;
			ModelVertexTextureCoords texCoords[4];
			int spriteWidth, spriteHeight;
			int spriteCenterX, spriteCenterY;
			texture = GameContext::Instance->TextureRegistry.GetTexture("Simon");
			// need dimensions on the texture to make sprites work
			if (texture->graphicData == nullptr)
				texture->LoadGraphicData();
			if (player->posture == PlatformPosture::Standing)
			{
				if (player->walkTimerMS < 115)
				{
					if (p_player->facing == PlatformDirection::Right)
					{
						texCoords[0].Set(10.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[1].Set(26.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[2].Set(26.0f / float(texture->width), 31.0f / float(texture->height));
						texCoords[3].Set(10.0f / float(texture->width), 31.0f / float(texture->height));
						spriteCenterX = 8;
						spriteCenterY = 30;
					}
					else
					{
						texCoords[1].Set(10.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[0].Set(26.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[3].Set(26.0f / float(texture->width), 31.0f / float(texture->height));
						texCoords[2].Set(10.0f / float(texture->width), 31.0f / float(texture->height));
						spriteCenterX = 8;
						spriteCenterY = 30;
					}
					spriteWidth = 16;
					spriteHeight = 30;
				}
				else if ((player->walkTimerMS >= 115 && player->walkTimerMS < 230) || player->walkTimerMS >= 345)
				{
					// midstride
					if (p_player->facing == PlatformDirection::Right)
					{
						texCoords[0].Set(52.0f / float(texture->width), 0.0f / float(texture->height));
						texCoords[1].Set(64.0f / float(texture->width), 0.0f / float(texture->height));
						texCoords[2].Set(64.0f / float(texture->width), 32.0f / float(texture->height));
						texCoords[3].Set(52.0f / float(texture->width), 32.0f / float(texture->height));
						spriteCenterX = 5;
						spriteCenterY = 31;
					}
					else
					{
						texCoords[1].Set(52.0f / float(texture->width), 0.0f / float(texture->height));
						texCoords[0].Set(64.0f / float(texture->width), 0.0f / float(texture->height));
						texCoords[3].Set(64.0f / float(texture->width), 32.0f / float(texture->height));
						texCoords[2].Set(52.0f / float(texture->width), 32.0f / float(texture->height));
						spriteCenterX = 7;
						spriteCenterY = 31;
					}
					spriteWidth = 12;
					spriteHeight = 31;
				}
				else if (player->walkTimerMS >= 230 && player->walkTimerMS < 345)
				{
					// other stride
					if (p_player->facing == PlatformDirection::Right)
					{
						texCoords[0].Set(90.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[1].Set(106.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[2].Set(106.0f / float(texture->width), 31.0f / float(texture->height));
						texCoords[3].Set(90.0f / float(texture->width), 31.0f / float(texture->height));
						spriteCenterX = 7;
						spriteCenterY = 30;
					}
					else
					{
						texCoords[1].Set(90.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[0].Set(106.0f / float(texture->width), 1.0f / float(texture->height));
						texCoords[3].Set(106.0f / float(texture->width), 31.0f / float(texture->height));
						texCoords[2].Set(90.0f / float(texture->width), 31.0f / float(texture->height));
						spriteCenterX = 9;
						spriteCenterY = 30;
					}
					spriteWidth = 16;
					spriteHeight = 30;
				}
			}
			else if (player->posture == PlatformPosture::Crouching)
			{
				if (p_player->facing == PlatformDirection::Right)
				{
					texCoords[0].Set(210.0f / float(texture->width), 4.0f / float(texture->height));
					texCoords[1].Set(226.0f / float(texture->width), 4.0f / float(texture->height));
					texCoords[2].Set(226.0f / float(texture->width), 27.0f / float(texture->height));
					texCoords[3].Set(210.0f / float(texture->width), 27.0f / float(texture->height));
					spriteCenterX = 8;
					spriteCenterY = 23;
				}
				else
				{
					texCoords[1].Set(210.0f / float(texture->width), 4.0f / float(texture->height));
					texCoords[0].Set(226.0f / float(texture->width), 4.0f / float(texture->height));
					texCoords[3].Set(226.0f / float(texture->width), 27.0f / float(texture->height));
					texCoords[2].Set(210.0f / float(texture->width), 27.0f / float(texture->height));
					spriteCenterX = 8;
					spriteCenterY = 23;
				}
				spriteWidth = 16;
				spriteHeight = 23;
			}

			// define sprite locations - I'll make a sprite structure later
			//GameTexture ^simonTexture = GameContext::Instance->TextureRegistry.GetTexture("Simon");
			//GameContext::Instance->SpriteRegistry.RegisterSprite("SimonStandRight", simonTexture, 10, 1, 16, 30, 8, 30);
			//GameContext::Instance->SpriteRegistry.RegisterSprite("SimonCrouchRight", simonTexture, 210, 4, 16, 23, 8, 23);

			// just draw the collision box for now
			GameColor colors[1] = { GameColor(255, 255, 255) };
			ModelVertex vertices[4];
			vertices[0].colorIndex = 0;
			vertices[1].colorIndex = 0;
			vertices[2].colorIndex = 0;
			vertices[3].colorIndex = 0;

			float worldPerPixel = 5.0f;

			vertices[0].vertex.Set(p_player->position.x - float(spriteCenterX) * worldPerPixel, player->position.y - float(spriteCenterY) * worldPerPixel, 0);
			vertices[1].vertex.Set(p_player->position.x + float(spriteWidth - spriteCenterX) * worldPerPixel, player->position.y - float(spriteCenterY) * worldPerPixel, 0);
			vertices[2].vertex.Set(p_player->position.x + float(spriteWidth - spriteCenterX) * worldPerPixel, player->position.y + float(spriteHeight - spriteCenterY) * worldPerPixel, 0);
			vertices[3].vertex.Set(p_player->position.x - float(spriteCenterX) * worldPerPixel, player->position.y + float(spriteHeight - spriteCenterY) * worldPerPixel, 0);

			p_graphics->SetDepthWriteEnabled(false);
			p_graphics->PushMatrix();
			p_graphics->RenderFilledQuad(colors, 1, vertices, 4, true, texture, texCoords, 4);
			//p_graphics->RenderFilledQuad(colors, 1, vertices, 4);
			p_graphics->PopMatrix();
			p_graphics->SetDepthWriteEnabled(true);
		}

	};

	public class BouncingBallWall
	{
	public:
		Vector3d point0;
		Vector3d point1;
		Vector3d segmentVector; // offset from p0 to p1
		Vector3d segmentUnit; // unit of segment Vector
		Vector3d normal;

		void Set(Vector3d &p_point0, Vector3d &p_point1)
		{
			point0 = p_point0;
			point1 = p_point1;

			segmentVector = point1 - point0;
			segmentUnit = segmentVector;
			segmentUnit.Normalize(); // if false, segment is just a point, but not worried about that right now
			normal.Set(segmentUnit.y, -segmentUnit.x, 0.0f);
		}
	};

	public class BouncingBall
	{
	public:
		Orient3d orient;
		Vector3d velocity;

		float radius;
		float mass;

		Vector3d remainingMove; // populated and maintained in collision loop only
		float angleDegreesPerMS; // how much should the ball turn per MS
		Vector3d spinAxis; // what is the turn axis on the orient for the ball?

		void ApplySpin(float p_elapsedTimeMSf)
		{
			if (angleDegreesPerMS != 0)
			{
				orient.Rotate(spinAxis, angleDegreesPerMS * p_elapsedTimeMSf);
			}
		}
	};

	public ref class BouncingBallGame : public GameBase
	{
		// this is a 2d bouncing ball demo.  It can be used as a absis for 3d, but you'll need to define surfaces rather than walls that are lines, and check for collisions against segments
		//   in addition to the surfaces and the endpoints
		// there is currently no collision checker for a surface, and it shoudl only check the surface, not the segments of endpoints, since they are shared
		// also be aware that energy is fully conserved currently - balls do not slow down, but if they do, they need to be able to come to rest and/or roll on surfaces, including coming to
		//   rest at the apex of two or three surfaces merging at a point, or just close enough to let the ball roll along them - which should be a challenge for determining the spin, since a ball rollign along two segments has to use the direction it is travelling and its
		//   movement rate along the segments or surfaces to determine its spin.

	public:

		Model3d *ball;
		LinkedList<BouncingBallWall> *walls;
		LinkedList<BouncingBall> *balls;
		GameTimer *timer;

		BouncingBallGame(HWND p_hWnd) : GameBase(p_hWnd)
		{
			ball = nullptr;
			walls = nullptr;
			balls = nullptr;
			timer = nullptr;
		}

		virtual ~BouncingBallGame()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			balls = new LinkedList<BouncingBall>();
			walls = new LinkedList<BouncingBallWall>();
			timer = new GameTimer();

			ball = new Model3d();
			ball->MakeSphere();

			// Initialize viewport dependent data
			SetupGamestate();

			GameBase::Initialize(); // call base initialize too.
		}

		void ViewportSizeChanged(GameViewport ^p_viewport) override
		{
			SetupGamestate();
		}

		void SetupGamestate()
		{
			balls->Clear();
			LinkedListNode<BouncingBall> *newBall;
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f); // so that a more appealing side of the ball shows
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() / 2.0f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.25f, 0);
			newBall->data.velocity.Set(0.2f, 0, 0);
			newBall->data.radius = 10.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.25f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.25f, 0);
			newBall->data.velocity.Set(-0.3f, 0, 0);
			newBall->data.radius = 15.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.75f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.25f, 0);
			newBall->data.velocity.Set(0.25f, 0, 0);
			newBall->data.radius = 20.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.625f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.25f, 0);
			newBall->data.velocity.Set(-0.2f, 0, 0);
			newBall->data.radius = 12.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.375f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.25f, 0);
			newBall->data.velocity.Set(0.1f, 0, 0);
			newBall->data.radius = 17.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);

			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() / 2.0f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.15f, 0);
			newBall->data.velocity.Set(0.2f, 0, 0);
			newBall->data.radius = 10.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.25f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.15f, 0);
			newBall->data.velocity.Set(-0.3f, 0, 0);
			newBall->data.radius = 15.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.75f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.15f, 0);
			newBall->data.velocity.Set(0.25f, 0, 0);
			newBall->data.radius = 20.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.625f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.15f, 0);
			newBall->data.velocity.Set(-0.2f, 0, 0);
			newBall->data.radius = 12.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);
			newBall = balls->GetNewNode();
			newBall->data.orient.LoadIdentity();
			newBall->data.orient.Rotate(Vector3d(0, 1, 0), 180.0f);
			newBall->data.orient.p = Vector3d(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth() * 0.375f, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() * 0.15f, 0);
			newBall->data.velocity.Set(0.1f, 0, 0);
			newBall->data.radius = 17.0f;
			newBall->data.mass = newBall->data.radius * newBall->data.radius * newBall->data.radius / 100.0f;
			newBall->data.angleDegreesPerMS = 0;
			balls->AddNode(newBall);

			// clear the walls
			walls->Clear();
			// setup mew ones for the viewport
			float viewportWidth = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth());
			float viewportHeight = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight());

			LinkedListNode<BouncingBallWall> *newNode;
			newNode = walls->GetNewNode();
			newNode->data.Set(Vector3d(0, 0, 0), Vector3d(viewportWidth - 1, 0, 0));
			walls->AddNode(newNode);
			newNode = walls->GetNewNode();
			newNode->data.Set(Vector3d(viewportWidth - 1, 0, 0), Vector3d(viewportWidth - 1, viewportHeight - 1, 0));
			walls->AddNode(newNode);
			newNode = walls->GetNewNode();
			newNode->data.Set(Vector3d(viewportWidth - 1, viewportHeight - 1, 0), Vector3d(0, viewportHeight - 1, 0));
			walls->AddNode(newNode);
			newNode = walls->GetNewNode();
			newNode->data.Set(Vector3d(0, viewportHeight - 1, 0), Vector3d(0, 0, 0));
			walls->AddNode(newNode);

			newNode = walls->GetNewNode();
			newNode->data.Set(Vector3d(viewportWidth * 0.25f, viewportHeight * 0.75f, 0), Vector3d(viewportWidth * 0.5f, viewportHeight * 0.65f, 0));
			walls->AddNode(newNode);
			newNode = walls->GetNewNode();
			newNode->data.Set(Vector3d(viewportWidth * 0.75f, viewportHeight * 0.75f, 0), Vector3d(viewportWidth * 0.5f, viewportHeight * 0.65f, 0));
			walls->AddNode(newNode);
		}

		void DestroyGameData()
		{
			if (balls != nullptr)
			{
				delete balls;
				balls = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
			if (walls != nullptr)
			{
				delete walls;
				walls = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			timer->Poll();
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.leftButton.down)
			{
				// if was already down, treat like a hold and place a wall
				// if wasn't down, place a first point and start placing a wall
			}
			else
			{
				// finish wall
			}

			mouse.ZeroOffsets();

			ConsumeElapsedTime(timer->GetElapsedTimeMS());

			timer->ResetElapsedTime();

			return true;
		}

		void ConsumeElapsedTime(int p_elapsedTimeMS)
		{
			int elapsedTimeMS = p_elapsedTimeMS;

			bool done = false;
			while (done == false)
			{
				if (elapsedTimeMS >= 10)
				{
					elapsedTimeMS -= 10;
					Animate(10);
				}
				else
				{
					if (elapsedTimeMS > 0)
					{
						Animate(float(elapsedTimeMS));
					}
					done = true;
				}
			}
		}

		void Animate(float p_elapsedTimeMSf)
		{
			MoveAndCheckForCollisions(p_elapsedTimeMSf);
		}

		void MoveAndCheckForCollisions(float p_elapsedTimeMSf)
		{
			float worldPer10Feet = 150.0f; // so that is at least watchable
			float gravityPerMSSquared = 32.0f * worldPer10Feet / 10.0f / (1000.0f * 1000.0f);

			// loops through walls, look for first collision, consume elaspedTimeMS and apply it
			// When a collision occurs, reflect ball velocity without affecting its length, and calculate the new final position according to ball's current location and new position sent (reflect that too)
			while (p_elapsedTimeMSf > 0)
			{
				LinkedListEnumerator<BouncingBall> enumeratorBall = LinkedListEnumerator<BouncingBall>(*balls);
				while (enumeratorBall.MoveNext())
				{
					// re-establish remaining moves for all balls for initialization (first loop) or after adjustments to their velocities (other loops)
					// get new final position offset according to current velocity, total time left to consume and gravity
					enumeratorBall.Current()->data.remainingMove = enumeratorBall.Current()->data.velocity.ScalarMult(p_elapsedTimeMSf) + Vector3d(0, 0.5f * gravityPerMSSquared * p_elapsedTimeMSf * p_elapsedTimeMSf, 0);
				}

				float noCollision = 10.0f; // positive so that comparison during ball collision test works if there were no collisions with walls
				float firstCollisionT = noCollision;
				BouncingBall *collidingBall = nullptr; // ball being tested to collide with other objects
				// objects ball can collide with
				BouncingBallWall *firstWallCollided = nullptr; // a wall
				Vector3d *firstEndpointCollided = nullptr; // a wall endpoint
				BouncingBall *firstBallCollided = nullptr; // another ball

				enumeratorBall = LinkedListEnumerator<BouncingBall>(*balls);
				while (enumeratorBall.MoveNext())
				{
					LinkedListEnumerator<BouncingBallWall> enumeratorWall = LinkedListEnumerator<BouncingBallWall>(*walls);
					// check balls against walls
					while (enumeratorWall.MoveNext())
					{
						float collisionT = 0.0f;
						if (MathUtilities::SphereLineSegmentCollision(enumeratorBall.Current()->data.orient.p, enumeratorBall.Current()->data.remainingMove, enumeratorBall.Current()->data.radius, enumeratorWall.Current()->data.point0, enumeratorWall.Current()->data.point1, &(enumeratorWall.Current()->data.segmentUnit), collisionT) == true)
						{
							if (collisionT < firstCollisionT)
							{
								collidingBall = &(enumeratorBall.Current()->data);
								firstEndpointCollided = nullptr; // cancel endpoitn collision, if any
								firstWallCollided = &(enumeratorWall.Current()->data);
								firstCollisionT = collisionT;
							}
						}
						// check against endpoints
						else if (MathUtilities::SpherePointCollision(enumeratorBall.Current()->data.orient.p, enumeratorBall.Current()->data.remainingMove, enumeratorBall.Current()->data.radius, enumeratorWall.Current()->data.point0, collisionT) == true)
						{
							if (collisionT < firstCollisionT)
							{
								collidingBall = &(enumeratorBall.Current()->data);
								firstWallCollided = nullptr; // cancel wall collision, if any
								firstEndpointCollided = &(enumeratorWall.Current()->data.point0);
								firstCollisionT = collisionT;
							}
						}
						else if (MathUtilities::SpherePointCollision(enumeratorBall.Current()->data.orient.p, enumeratorBall.Current()->data.remainingMove, enumeratorBall.Current()->data.radius, enumeratorWall.Current()->data.point1, collisionT) == true)
						{
							if (collisionT < firstCollisionT)
							{
								collidingBall = &(enumeratorBall.Current()->data);
								firstWallCollided = nullptr; // cancel wall collision, if any
								firstEndpointCollided = &(enumeratorWall.Current()->data.point1);
								firstCollisionT = collisionT;
							}
						}
					}

					// check balls against balls
					// get earliest collision with ball only if the time is less than the collision with the wall above
					// do the triangle shaped test since earlier pairs were already checked
					LinkedListEnumerator<BouncingBall> enumeratorBall2 = LinkedListEnumerator<BouncingBall>(*balls, enumeratorBall.Current());
					// check balls against walls
					while (enumeratorBall2.MoveNext())
					{
						float collisionT = 0.0f;
						if (MathUtilities::SphereSphereCollision(enumeratorBall.Current()->data.orient.p, enumeratorBall.Current()->data.remainingMove - enumeratorBall2.Current()->data.remainingMove, enumeratorBall.Current()->data.radius, enumeratorBall2.Current()->data.orient.p, enumeratorBall2.Current()->data.radius, collisionT) == true)
						{
							if (collisionT < firstCollisionT)
							{
								collidingBall = &(enumeratorBall.Current()->data);
								firstWallCollided = nullptr; // cancel wall collision, if any
								firstEndpointCollided = nullptr; // cancel endpoint collision, if any
								firstBallCollided = &(enumeratorBall2.Current()->data);
								firstCollisionT = collisionT;
							}
						}
					}
				}

				if (firstCollisionT == noCollision)
				{
					enumeratorBall = LinkedListEnumerator<BouncingBall>(*balls);
					while (enumeratorBall.MoveNext())
					{
						// advance all balls the rest of the way
						enumeratorBall.Current()->data.orient.p = enumeratorBall.Current()->data.orient.p + enumeratorBall.Current()->data.remainingMove;
						// apply final acceleration - prevents ball from keeping its full upward velocity after a bounce upwards - otherwise ball would gain height
						enumeratorBall.Current()->data.velocity = enumeratorBall.Current()->data.velocity + Vector3d(0, gravityPerMSSquared * p_elapsedTimeMSf, 0);
						// apply angle spin
						enumeratorBall.Current()->data.ApplySpin(p_elapsedTimeMSf);
					}
					// done
					p_elapsedTimeMSf = 0;
					break;
				}
				else
				{
					// apply collision
					float timeConsumedMSf = p_elapsedTimeMSf * firstCollisionT;
					p_elapsedTimeMSf -= timeConsumedMSf;

					enumeratorBall = LinkedListEnumerator<BouncingBall>(*balls);
					while (enumeratorBall.MoveNext())
					{
						// move all balls up to collision, properly calculate for acceleration
						// important note: the collision assumes linear travel over time, so place the ball as if it travelled linearly - this isn't perfect but it's close enough - this keeps the result of
						//   the collision consistent as detected
						enumeratorBall.Current()->data.orient.p = enumeratorBall.Current()->data.orient.p + enumeratorBall.Current()->data.remainingMove.ScalarMult(firstCollisionT);
						// but calculate velocity as if proper acceleration happened - avoids ball gaining upward reach due to not deceleration on an upward bounce during a time tick
						enumeratorBall.Current()->data.velocity = enumeratorBall.Current()->data.velocity + Vector3d(0, gravityPerMSSquared * timeConsumedMSf, 0);
						// apply angle spin
						enumeratorBall.Current()->data.ApplySpin(timeConsumedMSf);
					}

					if (firstWallCollided != nullptr)
					{
						// reflect velocity off from wall collided with
						// reflect with normal
						collidingBall->velocity = collidingBall->velocity - firstWallCollided->normal.ScalarMult(collidingBall->velocity * firstWallCollided->normal).ScalarMult(2.0f);

						// determine new angle spin
						Vector3d velocityAlongWall = collidingBall->velocity - firstWallCollided->normal.ScalarMult(collidingBall->velocity * firstWallCollided->normal);
						collidingBall->spinAxis = velocityAlongWall.CrossProd(collidingBall->velocity);
						collidingBall->spinAxis.Normalize();
						if (velocityAlongWall.Magnitude() > 0.00001f)
						{
							collidingBall->angleDegreesPerMS = velocityAlongWall.Magnitude() / collidingBall->radius * 180.0f / MathConstants::Pi(); // radians per ms, convert to degrees
						}
						else
							collidingBall->angleDegreesPerMS = 0;
					}
					else if (firstBallCollided != nullptr)
					{
						// bounce the balls off each other
						// reflect their contact vector components and add them to each other, keep the rest
						Vector3d collisionVector = firstBallCollided->orient.p - collidingBall->orient.p;  // points from tested ball to other ball
						collisionVector.Normalize(); // this should succeed, not concerned with error conditions right now
						Vector3d collidingBallTransferToOtherBall = collisionVector.ScalarMult(collidingBall->velocity * collisionVector);
						Vector3d collidingBallKeep = collidingBall->velocity - collidingBallTransferToOtherBall;
						Vector3d firstBallCollidedTransferToTestBall = collisionVector.ScalarMult(firstBallCollided->velocity * collisionVector);
						Vector3d firstBallCollidedKeep = firstBallCollided->velocity - firstBallCollidedTransferToTestBall;
						// apply collision
						// consider mass
						float massRatio2to1 = firstBallCollided->mass / collidingBall->mass;
						float massRatio1to2 = collidingBall->mass / firstBallCollided->mass;
						// don't do mass for now - a small ball coming up behind a large ball just ends up continuing to press against it, causing an infinite loop.
						// todo: if there is some sort of not transfering all of the energy to the other target, there shoudl probably be a bounce away from it
						massRatio2to1 = 1.0f;
						massRatio1to2 = 1.0f;
						collidingBall->velocity = collidingBallKeep + firstBallCollidedTransferToTestBall.ScalarMult(massRatio2to1);
						firstBallCollided->velocity = firstBallCollidedKeep + collidingBallTransferToOtherBall.ScalarMult(massRatio1to2);

						// new spins for each
						Vector3d collisionNormal1 = collisionVector.ScalarMult(-1.0f);
						Vector3d ball1to2Velocity = collidingBall->velocity - firstBallCollided->velocity;
						Vector3d velocityAlongBall2 = ball1to2Velocity - collisionNormal1.ScalarMult(ball1to2Velocity * collisionNormal1);
						collidingBall->spinAxis = velocityAlongBall2.CrossProd(ball1to2Velocity);
						collidingBall->spinAxis.Normalize();
						if (velocityAlongBall2.Magnitude() > 0.00001f)
						{
							collidingBall->angleDegreesPerMS = velocityAlongBall2.Magnitude() / collidingBall->radius * 180.0f / MathConstants::Pi(); // radians per ms, convert to degrees
						}
						else
							collidingBall->angleDegreesPerMS = 0;

						Vector3d collisionNormal2 = collisionVector;
						Vector3d ball2to1Velocity = firstBallCollided->velocity - collidingBall->velocity;
						Vector3d velocityAlongBall1 = ball2to1Velocity - collisionNormal2.ScalarMult(ball2to1Velocity * collisionNormal2);
						firstBallCollided->spinAxis = velocityAlongBall1.CrossProd(ball2to1Velocity);
						firstBallCollided->spinAxis.Normalize();
						if (velocityAlongBall1.Magnitude() > 0.00001f)
						{
							firstBallCollided->angleDegreesPerMS = velocityAlongBall1.Magnitude() / firstBallCollided->radius * 180.0f / MathConstants::Pi(); // radians per ms, convert to degrees
						}
						else
							firstBallCollided->angleDegreesPerMS = 0;
					}
					else if (firstEndpointCollided != nullptr)
					{
						// bounce the ball off the endpoint
						Vector3d collisionNormal = collidingBall->orient.p - *firstEndpointCollided;  // points from tested ball to other ball
						collisionNormal.Normalize(); // this should succeed, not concerned with error conditions right now
						// reflect off the collision normal
						collidingBall->velocity = collidingBall->velocity - collisionNormal.ScalarMult(collidingBall->velocity * collisionNormal).ScalarMult(2.0f);

						// determine new angle spin
						Vector3d velocityAlongEndpoint = collidingBall->velocity - collisionNormal.ScalarMult(collidingBall->velocity * collisionNormal);
						collidingBall->spinAxis = velocityAlongEndpoint.CrossProd(collidingBall->velocity);
						collidingBall->spinAxis.Normalize();
						if (velocityAlongEndpoint.Magnitude() > 0.00001f)
						{
							collidingBall->angleDegreesPerMS = velocityAlongEndpoint.Magnitude() / collidingBall->radius * 180.0f / MathConstants::Pi(); // radians per ms, convert to degrees
						}
						else
							collidingBall->angleDegreesPerMS = 0;
					}

					// calculate new remaining moves for all balls
					enumeratorBall = LinkedListEnumerator<BouncingBall>(*balls);
					while (enumeratorBall.MoveNext())
					{
						// get new final position offset according to current velocity, total time left to consume and gravity
						enumeratorBall.Current()->data.remainingMove = enumeratorBall.Current()->data.velocity.ScalarMult(p_elapsedTimeMSf) + Vector3d(0, gravityPerMSSquared * p_elapsedTimeMSf * p_elapsedTimeMSf, 0).ScalarMult(0.5f);
					}
				}
			}
		}

		//////////////////

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->Set2dWindowProjection(-10.0f, 10.0f);

			//graphics->DefaultTransform();

			// no need for positioning for camera for now

			RenderBalls(graphics);

			// render walls
			RenderWalls(graphics, GameColor(0,255,255), 3.0f);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderBalls(GraphicsBase *p_graphics)
		{
			LinkedListEnumerator<BouncingBall> enumerator = LinkedListEnumerator<BouncingBall>(*balls);
			while (enumerator.MoveNext())
			{
				p_graphics->PushMatrix();
				p_graphics->Transform(enumerator.Current()->data.orient);
				p_graphics->Scale(enumerator.Current()->data.radius, enumerator.Current()->data.radius, 1.0f);
				ball->Render(*p_graphics);
				p_graphics->PopMatrix();
			}
		}

		void RenderWalls(GraphicsBase *p_graphics, GameColor &p_color, float p_lineWidth)
		{
			ModelVertex vertices[2];
			vertices[0].colorIndex = 0;
			vertices[1].colorIndex = 0;

			LinkedListEnumerator<BouncingBallWall> enumerator = LinkedListEnumerator<BouncingBallWall>(*walls);
			while (enumerator.MoveNext())
			{
				vertices[0].vertex = enumerator.Current()->data.point0;
				vertices[1].vertex = enumerator.Current()->data.point1;
				p_graphics->RenderLineStrip(p_lineWidth, &p_color, 1, vertices, 2, false);
			}
		}

	};

	public ref class OrientInterpolationTest : public GameBase
	{
	public:

		Orient3d *orients;
		Model3d *cube;
		GameTimer *timer;

		OrientInterpolationTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			orients = nullptr;
			cube = nullptr;
			timer = nullptr;
		}

		virtual ~OrientInterpolationTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			orients = new Orient3d[5]; // 4 to cycle through, 1 to move

			orients[0].LoadIdentity();
			orients[0].p = orients[0].p + Vector3d(-4.0f, 8.0f, 50.0f);
			orients[0].Rotate(Vector3d(0.5f, 4.0f, 5.0), 70.0f, false);

			//test
			orients[1].LoadIdentity();
			orients[1].p = orients[1].p + Vector3d(-8.0f, -16.0f, 70.0f);
			orients[1].Rotate(Vector3d(4.5f, -4.0f, -10), 110.0f, false);

			orients[2].LoadIdentity();
			orients[2].p = orients[2].p + Vector3d(8.0f, 14.0f, 50.0f);
			orients[2].Rotate(Vector3d(0.5f, -4.0f, 2), 120.0f, false);

			orients[3].LoadIdentity();
			orients[3].p = orients[3].p + Vector3d(12.0f, -10.0f, 30.0f);
			orients[3].Rotate(Vector3d(-0.5f, 4.0f, 1), 200.0f, false);

			orients[4].LoadIdentity(); // the one to move
			orients[4].p = orients[4].p + orients[4].f.ScalarMult(30.0f);

			cube = new Model3d();
			cube->MakeCube();

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (orients != nullptr)
			{
				delete[] orients;
				orients = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
			}
			else if (mouse.leftButton.down)
			{
			}
			mouse.ZeroOffsets();

			Animate(timer->GetElapsedTimeMS());

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(int p_elapsedTimeMS)
		{
			// cycle is 12 seconds, 3 second spent interpolating to each pair
			static int gameTimeMS = 0; // could use timer for this but we are cycling game time here - besides, this is a surrogate for an animation loop structure
			gameTimeMS += p_elapsedTimeMS;
			while (gameTimeMS >= 12000)
				gameTimeMS -= 12000;

			Orient3d *orient1;
			Orient3d *orient2;

			int pair = int(gameTimeMS / 3000);
			switch (pair)
			{
			case 0:
				orient1 = &orients[0];
				orient2 = &orients[1];
				break;
			case 1:
				orient1 = &orients[1];
				orient2 = &orients[2];
				break;
			case 2:
				orient1 = &orients[2];
				orient2 = &orients[3];
				break;
			case 3:
				orient1 = &orients[3];
				orient2 = &orients[0];
				break;
			}

			// now interpolate over 3 seconds!
			float timeToInterpolate = float(gameTimeMS - pair * 3000) / 3000.0f; // gets current time between the two endpoints of the pair
			// interpolate as factor of 0.0 to 1.0 using 3000 as the base
			orients[4] = Orient3d::Interpolate(*orient1, *orient2, timeToInterpolate);
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			// no camera
			//graphics->ReverseTransform(*cameraOrient);

			for (int i = 0; i < 5; i++)
			{
				graphics->PushMatrix();
				// forward transform the cube
				graphics->Transform(orients[i]);
				// render the cube
				cube->Render(*graphics);
				graphics->PopMatrix();
			}

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class JointedModelTest : public GameBase
	{
	public:

		Model3d *fingerKnuckle;
		Model3d *handPalm;
		Orient3d *handOrient;
		Orient3d *handJointOrients;
		JointedModel3d *hand;
		GameTimer *timer;
		float angle;

		JointedModelTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			handOrient = nullptr;
			handJointOrients = nullptr;
			fingerKnuckle = nullptr;
			handPalm = nullptr;
			hand = nullptr;
			timer = nullptr;

			angle = 0;
		}

		virtual ~JointedModelTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			fingerKnuckle = new Model3d();
			fingerKnuckle->Initialize(6, 6, 5);
			fingerKnuckle->GetVertex(0)->colorIndex = 0;
			fingerKnuckle->GetVertex(0)->vertex.Set(0.0f, 0.1f, 0.0f);
			fingerKnuckle->GetVertex(1)->colorIndex = 1;
			fingerKnuckle->GetVertex(1)->vertex.Set(0.09f, -0.09f, 0.0f);
			fingerKnuckle->GetVertex(2)->colorIndex = 2;
			fingerKnuckle->GetVertex(2)->vertex.Set(-0.09f, -0.09f, 0.0f);
			fingerKnuckle->GetVertex(3)->colorIndex = 3;
			fingerKnuckle->GetVertex(3)->vertex.Set(0.0f, 0.1f, 0.5f);
			fingerKnuckle->GetVertex(4)->colorIndex = 4;
			fingerKnuckle->GetVertex(4)->vertex.Set(0.09f, -0.09f, 0.5f);
			fingerKnuckle->GetVertex(5)->colorIndex = 5;
			fingerKnuckle->GetVertex(5)->vertex.Set(-0.09f, -0.09f, 0.5f);
			fingerKnuckle->GetColor(0)->Set(128, 128, 128);
			fingerKnuckle->GetColor(1)->Set(255, 0, 0);
			fingerKnuckle->GetColor(2)->Set(0, 0, 255);
			fingerKnuckle->GetColor(3)->Set(0, 255, 0);
			fingerKnuckle->GetColor(4)->Set(255, 255, 255);
			fingerKnuckle->GetColor(5)->Set(255, 128, 0);

			fingerKnuckle->GetSurface(0)->Initialize(3, true);
			fingerKnuckle->GetSurface(1)->Initialize(4, true);
			fingerKnuckle->GetSurface(2)->Initialize(4, true);
			fingerKnuckle->GetSurface(3)->Initialize(4, true);
			fingerKnuckle->GetSurface(4)->Initialize(3, true);
			fingerKnuckle->GetSurface(0)->SetVertexIndex(0, 0);
			fingerKnuckle->GetSurface(0)->SetVertexIndex(1, 2);
			fingerKnuckle->GetSurface(0)->SetVertexIndex(2, 1);
			fingerKnuckle->GetSurface(1)->SetVertexIndex(0, 0);
			fingerKnuckle->GetSurface(1)->SetVertexIndex(1, 1);
			fingerKnuckle->GetSurface(1)->SetVertexIndex(2, 4);
			fingerKnuckle->GetSurface(1)->SetVertexIndex(3, 3);
			fingerKnuckle->GetSurface(2)->SetVertexIndex(0, 0);
			fingerKnuckle->GetSurface(2)->SetVertexIndex(1, 3);
			fingerKnuckle->GetSurface(2)->SetVertexIndex(2, 5);
			fingerKnuckle->GetSurface(2)->SetVertexIndex(3, 2);
			fingerKnuckle->GetSurface(3)->SetVertexIndex(0, 1);
			fingerKnuckle->GetSurface(3)->SetVertexIndex(1, 2);
			fingerKnuckle->GetSurface(3)->SetVertexIndex(2, 5);
			fingerKnuckle->GetSurface(3)->SetVertexIndex(3, 4);
			fingerKnuckle->GetSurface(4)->SetVertexIndex(0, 3);
			fingerKnuckle->GetSurface(4)->SetVertexIndex(1, 4);
			fingerKnuckle->GetSurface(4)->SetVertexIndex(2, 5);

			handPalm = new Model3d();
			handPalm->Initialize(1, 8, 6);
			handPalm->GetVertex(0)->colorIndex = 0;
			handPalm->GetVertex(1)->colorIndex = 0;
			handPalm->GetVertex(2)->colorIndex = 0;
			handPalm->GetVertex(3)->colorIndex = 0;
			handPalm->GetVertex(4)->colorIndex = 0;
			handPalm->GetVertex(5)->colorIndex = 0;
			handPalm->GetVertex(6)->colorIndex = 0;
			handPalm->GetVertex(7)->colorIndex = 0;
			handPalm->GetVertex(0)->vertex.Set(0.3f, 0.075f, 0.0f);
			handPalm->GetVertex(1)->vertex.Set(0.3f, -0.075f, 0.0f);
			handPalm->GetVertex(2)->vertex.Set(-0.3f, -0.075f, 0.0f);
			handPalm->GetVertex(3)->vertex.Set(-0.3f, 0.075f, 0.0f);
			handPalm->GetVertex(4)->vertex.Set(0.4f, 0.1f, 1.0f);
			handPalm->GetVertex(5)->vertex.Set(0.4f, -0.1f, 1.0f);
			handPalm->GetVertex(6)->vertex.Set(-0.4f, -0.1f, 1.0f);
			handPalm->GetVertex(7)->vertex.Set(-0.4f, 0.1f, 1.0f);
			handPalm->GetColor(0)->Set(128, 128, 128);
			handPalm->GetSurface(0)->Initialize(4, true);
			handPalm->GetSurface(1)->Initialize(4, true);
			handPalm->GetSurface(2)->Initialize(4, true);
			handPalm->GetSurface(3)->Initialize(4, true);
			handPalm->GetSurface(4)->Initialize(4, true);
			handPalm->GetSurface(5)->Initialize(4, true);
			handPalm->GetSurface(0)->SetVertexIndex(0, 0);
			handPalm->GetSurface(0)->SetVertexIndex(1, 3);
			handPalm->GetSurface(0)->SetVertexIndex(2, 2);
			handPalm->GetSurface(0)->SetVertexIndex(3, 1);
			handPalm->GetSurface(1)->SetVertexIndex(0, 0);
			handPalm->GetSurface(1)->SetVertexIndex(1, 1);
			handPalm->GetSurface(1)->SetVertexIndex(2, 5);
			handPalm->GetSurface(1)->SetVertexIndex(3, 4);
			handPalm->GetSurface(2)->SetVertexIndex(0, 7);
			handPalm->GetSurface(2)->SetVertexIndex(1, 4);
			handPalm->GetSurface(2)->SetVertexIndex(2, 5);
			handPalm->GetSurface(2)->SetVertexIndex(3, 6);
			handPalm->GetSurface(3)->SetVertexIndex(0, 7);
			handPalm->GetSurface(3)->SetVertexIndex(1, 6);
			handPalm->GetSurface(3)->SetVertexIndex(2, 2);
			handPalm->GetSurface(3)->SetVertexIndex(3, 3);
			handPalm->GetSurface(4)->SetVertexIndex(0, 0);
			handPalm->GetSurface(4)->SetVertexIndex(1, 4);
			handPalm->GetSurface(4)->SetVertexIndex(2, 7);
			handPalm->GetSurface(4)->SetVertexIndex(3, 3);
			handPalm->GetSurface(5)->SetVertexIndex(0, 1);
			handPalm->GetSurface(5)->SetVertexIndex(1, 2);
			handPalm->GetSurface(5)->SetVertexIndex(2, 6);
			handPalm->GetSurface(5)->SetVertexIndex(3, 5);

			handOrient = new Orient3d();
			handOrient->LoadIdentity();
			handOrient->p = handOrient->p + Vector3d(0.0f, 0.55f, 4.0f);
			handOrient->Rotate(handOrient->u, -135.0f);
			handOrient->Rotate(handOrient->l, -45.0f);
			handOrient->Rotate(handOrient->f, 180.0f);

			hand = new JointedModel3d();
			hand->Initialize(handPalm, 0, 4); // palm rendered on 0 (identity, transformed by handOrient), thumb and 3 fingers, each with two joints and a knuckle extending from each joint
			hand->GetJoint(0)->Initialize(fingerKnuckle, 1, 1);
			hand->GetJoint(1)->Initialize(fingerKnuckle, 2, 1);
			hand->GetJoint(2)->Initialize(fingerKnuckle, 3, 1);
			hand->GetJoint(3)->Initialize(fingerKnuckle, 4, 1);
			hand->GetJoint(0)->GetJoint(0)->Initialize(fingerKnuckle, 5);
			hand->GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 6);
			hand->GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 7);
			hand->GetJoint(3)->GetJoint(0)->Initialize(fingerKnuckle, 8);

			// should return 9
			int jointQty = hand->GetTotalJointOrientQty();
			if (jointQty != 0)
				handJointOrients = new Orient3d[jointQty];

			// will be initialized when they are rotated
			//	for (int i = 0; i < jointQty; i++)
			//	{
			//		handJointOrients[i].LoadIdentity();
			//	}

			//	handJointOrients[0].Rotate(handJointOrients[0].u, 90.0f);
			//	handJointOrients[0].p = handJointOrients[0].p + handJointOrients[0].f.ScalarMult(2.5f);
			//	handJointOrients[4].p = handJointOrients[1].p + handJointOrients[1].f.ScalarMult(2.5f);

			//	handJointOrients[1].p = Vector3d(-0.3f, 0.0f, 1.0f);
			//	handJointOrients[1].Rotate(handJointOrients[1].u, 10.0f);
			//	handJointOrients[2].p = Vector3d(0.0f, 0.0f, 1.0f);
			//	handJointOrients[3].p = Vector3d(0.3f, 0.0f, 1.0f);
			//	handJointOrients[3].Rotate(handJointOrients[3].u, -10.0f);
			//	handJointOrients[5].p = Vector3d(0.0f, 0.0f, 0.5f);
			//	handJointOrients[6].p = Vector3d(0.0f, 0.0f, 0.5f);
			//	handJointOrients[7].p = Vector3d(0.0f, 0.0f, 0.5f);
			//}

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (handOrient != nullptr)
			{
				delete handOrient;
				handOrient = nullptr;
			}
			if (handJointOrients != nullptr)
			{
				delete [] handJointOrients;
				handJointOrients = nullptr;
			}
			if (fingerKnuckle != nullptr)
			{
				delete fingerKnuckle;
				fingerKnuckle = nullptr;
			}
			if (handPalm != nullptr)
			{
				delete handPalm;
				handPalm = nullptr;
			}
			if (hand != nullptr)
			{
				delete hand;
				hand = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				angle -= mouse.offsetY;
				if (angle > 90.0f)
					angle = 90.0f;
				if (angle < 0.0f)
					angle = 0.0f;
			}
			if (mouse.leftButton.down)
			{
				handOrient->Rotate(Vector3d(0, 1, 0), -float(mouse.offsetX));
				if (mouse.rightButton.down == false)
					handOrient->Rotate(handOrient->l, float(mouse.offsetY));
			}
			mouse.ZeroOffsets();

			Animate(timer->GetElapsedTimeMS());

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(int p_elapsedTimeMS)
		{
			// use angle to situate hand joints
			if (handJointOrients != nullptr)
			{
				for (int i = 0; i < hand->GetTotalJointOrientQty(); i++) // this is SLOW
				{
					handJointOrients[i].LoadIdentity();
				}

				handJointOrients[1].Rotate(handJointOrients[0].u, 90.0f);
				handJointOrients[1].p = Vector3d(-0.3f, 0.0f, 0.3f);
				handJointOrients[5].p = Vector3d(0.0f, 0.0f, 0.5f);

				handJointOrients[2].p = Vector3d(-0.3f, 0.0f, 1.0f);
				handJointOrients[2].Rotate(handJointOrients[1].u, 10.0f);
				handJointOrients[3].p = Vector3d(0.0f, 0.0f, 1.0f);
				handJointOrients[4].p = Vector3d(0.3f, 0.0f, 1.0f);
				handJointOrients[4].Rotate(handJointOrients[3].u, -10.0f);
				handJointOrients[6].p = Vector3d(0.0f, 0.0f, 0.5f);
				handJointOrients[7].p = Vector3d(0.0f, 0.0f, 0.5f);
				handJointOrients[8].p = Vector3d(0.0f, 0.0f, 0.5f);

				// adjust all the fingers
				for (int i = 1; i < hand->GetTotalJointOrientQty(); i++) // this is SLOW
				{
					handJointOrients[i].Rotate(handJointOrients[i].l, -angle);
				}
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			// no camera
			//graphics->ReverseTransform(*cameraOrient);

			graphics->PushMatrix();
			graphics->Transform(*handOrient);
			hand->Render(*graphics, handJointOrients, 9);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	public ref class AnimatedModelTest : public GameBase
	{
	public:

		//Model3d *fingerKnuckle;
		//Model3d *handPalm;
		//Model3d *foot;
		//Model3d *head;
		Orient3d *modelOrient;
		Orient3d *modelJointOrients;
		JointedModel3d *triguy;
		GameTimer *timer;
		bool doAnaglyph;
		Orient3d *cameraOrient;

		// standard parts of triguy model
		JointedModelAnimation *standingAnimationRef;
		JointedModelAnimation *walkingAnimationRef;
		JointedModelAnimation *runningAnimationRef;

		JointedModelAnimation *danceStompAnimation; // basic street feet side to side
		JointedModelAnimation *dancePranceAnimation; // two steps in front then stand in stride
		JointedModelAnimation *danceJazzhandAnimation; // hands open, body waving
		JointedModelAnimation *danceHipAnimation; // fists at side, wiggle body
		JointedModelAnimation *danceTiptoeAnimation; // hands back against wall, look off to the side distantly
		JointedModelAnimation *danceThrustAnimation; // fists pulling back, thrusting hips
		JointedModelAnimation *dancePointAnimation; // index fingers pointing, body gyrating
		JointedModelAnimation *danceBendAnimation;  // hands open palms at floor, looking down as if to feel heat while body shifts side to side
		JointedModelAnimation *danceBounceAnimation;  // head looking down sideways, fist at one hip, other hand hanging lax, body bouncing up and down slightly

		JointedModelAnimationTracker *animationTracker;

		AnimatedModelTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			modelOrient = nullptr;
			modelJointOrients = nullptr;
			//fingerKnuckle = nullptr;
			//handPalm = nullptr;
			//foot = nullptr;
			//head = nullptr;
			triguy = nullptr;
			timer = nullptr;
			doAnaglyph = false;
			cameraOrient = nullptr;

			standingAnimationRef = nullptr;
			walkingAnimationRef = nullptr;
			runningAnimationRef = nullptr;

			danceStompAnimation = nullptr;
			dancePranceAnimation = nullptr;
			danceJazzhandAnimation = nullptr;
			danceHipAnimation = nullptr;
			danceTiptoeAnimation = nullptr;
			danceThrustAnimation = nullptr;
			dancePointAnimation = nullptr;
			danceBendAnimation = nullptr;
			danceBounceAnimation = nullptr;

			animationTracker = nullptr;
		}

		virtual ~AnimatedModelTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FileRegistry.RegisterFileResource("TrFace1.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("TriGuyFace1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.GetFile("TrFace1.bmp"));
			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("DeathStarTransp-SWE_512_512.png"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("DeathStar1", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			//fingerKnuckle = new Model3d();
			//fingerKnuckle->Initialize(6, 6, 5);
			//fingerKnuckle->GetVertex(0)->colorIndex = 0;
			//fingerKnuckle->GetVertex(0)->vertex.Set(0.0f, 0.1f, 0.0f);
			//fingerKnuckle->GetVertex(1)->colorIndex = 1;
			//fingerKnuckle->GetVertex(1)->vertex.Set(0.09f, -0.09f, 0.0f);
			//fingerKnuckle->GetVertex(2)->colorIndex = 2;
			//fingerKnuckle->GetVertex(2)->vertex.Set(-0.09f, -0.09f, 0.0f);
			//fingerKnuckle->GetVertex(3)->colorIndex = 3;
			//fingerKnuckle->GetVertex(3)->vertex.Set(0.0f, 0.1f, 0.5f);
			//fingerKnuckle->GetVertex(4)->colorIndex = 4;
			//fingerKnuckle->GetVertex(4)->vertex.Set(0.09f, -0.09f, 0.5f);
			//fingerKnuckle->GetVertex(5)->colorIndex = 5;
			//fingerKnuckle->GetVertex(5)->vertex.Set(-0.09f, -0.09f, 0.5f);
			//fingerKnuckle->GetColor(0)->Set(128, 128, 128);
			//fingerKnuckle->GetColor(1)->Set(255, 0, 0);
			//fingerKnuckle->GetColor(2)->Set(0, 0, 255);
			//fingerKnuckle->GetColor(3)->Set(0, 255, 0);
			//fingerKnuckle->GetColor(4)->Set(255, 255, 255);
			//fingerKnuckle->GetColor(5)->Set(255, 128, 0);
			//fingerKnuckle->GetSurface(0)->Initialize(3, true);
			//fingerKnuckle->GetSurface(1)->Initialize(4, true);
			//fingerKnuckle->GetSurface(2)->Initialize(4, true);
			//fingerKnuckle->GetSurface(3)->Initialize(4, true);
			//fingerKnuckle->GetSurface(4)->Initialize(3, true);
			//fingerKnuckle->GetSurface(0)->SetVertexIndex(0, 0);
			//fingerKnuckle->GetSurface(0)->SetVertexIndex(1, 2);
			//fingerKnuckle->GetSurface(0)->SetVertexIndex(2, 1);
			//fingerKnuckle->GetSurface(1)->SetVertexIndex(0, 0);
			//fingerKnuckle->GetSurface(1)->SetVertexIndex(1, 1);
			//fingerKnuckle->GetSurface(1)->SetVertexIndex(2, 4);
			//fingerKnuckle->GetSurface(1)->SetVertexIndex(3, 3);
			//fingerKnuckle->GetSurface(2)->SetVertexIndex(0, 0);
			//fingerKnuckle->GetSurface(2)->SetVertexIndex(1, 3);
			//fingerKnuckle->GetSurface(2)->SetVertexIndex(2, 5);
			//fingerKnuckle->GetSurface(2)->SetVertexIndex(3, 2);
			//fingerKnuckle->GetSurface(3)->SetVertexIndex(0, 1);
			//fingerKnuckle->GetSurface(3)->SetVertexIndex(1, 2);
			//fingerKnuckle->GetSurface(3)->SetVertexIndex(2, 5);
			//fingerKnuckle->GetSurface(3)->SetVertexIndex(3, 4);
			//fingerKnuckle->GetSurface(4)->SetVertexIndex(0, 3);
			//fingerKnuckle->GetSurface(4)->SetVertexIndex(1, 4);
			//fingerKnuckle->GetSurface(4)->SetVertexIndex(2, 5);

			//handPalm = new Model3d();
			//handPalm->Initialize(1, 8, 6);
			//handPalm->GetVertex(0)->colorIndex = 0;
			//handPalm->GetVertex(1)->colorIndex = 0;
			//handPalm->GetVertex(2)->colorIndex = 0;
			//handPalm->GetVertex(3)->colorIndex = 0;
			//handPalm->GetVertex(4)->colorIndex = 0;
			//handPalm->GetVertex(5)->colorIndex = 0;
			//handPalm->GetVertex(6)->colorIndex = 0;
			//handPalm->GetVertex(7)->colorIndex = 0;
			//handPalm->GetVertex(0)->vertex.Set(0.3f, 0.075f, 0.0f);
			//handPalm->GetVertex(1)->vertex.Set(0.3f, -0.075f, 0.0f);
			//handPalm->GetVertex(2)->vertex.Set(-0.3f, -0.075f, 0.0f);
			//handPalm->GetVertex(3)->vertex.Set(-0.3f, 0.075f, 0.0f);
			//handPalm->GetVertex(4)->vertex.Set(0.4f, 0.1f, 1.0f);
			//handPalm->GetVertex(5)->vertex.Set(0.4f, -0.1f, 1.0f);
			//handPalm->GetVertex(6)->vertex.Set(-0.4f, -0.1f, 1.0f);
			//handPalm->GetVertex(7)->vertex.Set(-0.4f, 0.1f, 1.0f);
			//handPalm->GetColor(0)->Set(128, 128, 128);
			//handPalm->GetSurface(0)->Initialize(4, true);
			//handPalm->GetSurface(1)->Initialize(4, true);
			//handPalm->GetSurface(2)->Initialize(4, true);
			//handPalm->GetSurface(3)->Initialize(4, true);
			//handPalm->GetSurface(4)->Initialize(4, true);
			//handPalm->GetSurface(5)->Initialize(4, true);
			//handPalm->GetSurface(0)->SetVertexIndex(0, 0);
			//handPalm->GetSurface(0)->SetVertexIndex(1, 3);
			//handPalm->GetSurface(0)->SetVertexIndex(2, 2);
			//handPalm->GetSurface(0)->SetVertexIndex(3, 1);
			//handPalm->GetSurface(1)->SetVertexIndex(0, 0);
			//handPalm->GetSurface(1)->SetVertexIndex(1, 1);
			//handPalm->GetSurface(1)->SetVertexIndex(2, 5);
			//handPalm->GetSurface(1)->SetVertexIndex(3, 4);
			//handPalm->GetSurface(2)->SetVertexIndex(0, 7);
			//handPalm->GetSurface(2)->SetVertexIndex(1, 4);
			//handPalm->GetSurface(2)->SetVertexIndex(2, 5);
			//handPalm->GetSurface(2)->SetVertexIndex(3, 6);
			//handPalm->GetSurface(3)->SetVertexIndex(0, 7);
			//handPalm->GetSurface(3)->SetVertexIndex(1, 6);
			//handPalm->GetSurface(3)->SetVertexIndex(2, 2);
			//handPalm->GetSurface(3)->SetVertexIndex(3, 3);
			//handPalm->GetSurface(4)->SetVertexIndex(0, 0);
			//handPalm->GetSurface(4)->SetVertexIndex(1, 4);
			//handPalm->GetSurface(4)->SetVertexIndex(2, 7);
			//handPalm->GetSurface(4)->SetVertexIndex(3, 3);
			//handPalm->GetSurface(5)->SetVertexIndex(0, 1);
			//handPalm->GetSurface(5)->SetVertexIndex(1, 2);
			//handPalm->GetSurface(5)->SetVertexIndex(2, 6);
			//handPalm->GetSurface(5)->SetVertexIndex(3, 5);

			//foot = new Model3d();
			//foot->Initialize(5, 5, 5);
			//foot->GetVertex(0)->colorIndex = 0;
			//foot->GetVertex(1)->colorIndex = 1;
			//foot->GetVertex(2)->colorIndex = 2;
			//foot->GetVertex(3)->colorIndex = 3;
			//foot->GetVertex(4)->colorIndex = 4;
			//foot->GetVertex(0)->vertex.Set(0.0f, 0.25f, 0.0f);
			//foot->GetVertex(1)->vertex.Set(0.5f, -0.25f, 1.5f);
			//foot->GetVertex(2)->vertex.Set(-0.5f, -0.25f, 1.5f);
			//foot->GetVertex(3)->vertex.Set(-0.5f, -0.25f, -0.5f);
			//foot->GetVertex(4)->vertex.Set(0.5f, -0.25f, -0.5f);
			//foot->GetColor(0)->Set(128,128,128);
			//foot->GetColor(1)->Set(255,0,0);
			//foot->GetColor(2)->Set(255,255,255);
			//foot->GetColor(3)->Set(0,0,255);
			//foot->GetColor(4)->Set(0,255,0);
			//foot->GetSurface(0)->Initialize(3, true);
			//foot->GetSurface(1)->Initialize(3, true);
			//foot->GetSurface(2)->Initialize(3, true);
			//foot->GetSurface(3)->Initialize(3, true);
			//foot->GetSurface(4)->Initialize(4, true);
			//foot->GetSurface(0)->SetVertexIndex(0, 0);
			//foot->GetSurface(0)->SetVertexIndex(1, 1);
			//foot->GetSurface(0)->SetVertexIndex(2, 2);
			//foot->GetSurface(1)->SetVertexIndex(0, 0);
			//foot->GetSurface(1)->SetVertexIndex(1, 2);
			//foot->GetSurface(1)->SetVertexIndex(2, 3);
			//foot->GetSurface(2)->SetVertexIndex(0, 0);
			//foot->GetSurface(2)->SetVertexIndex(1, 3);
			//foot->GetSurface(2)->SetVertexIndex(2, 4);
			//foot->GetSurface(3)->SetVertexIndex(0, 0);
			//foot->GetSurface(3)->SetVertexIndex(1, 4);
			//foot->GetSurface(3)->SetVertexIndex(2, 1);
			//foot->GetSurface(4)->SetVertexIndex(0, 4);
			//foot->GetSurface(4)->SetVertexIndex(1, 3);
			//foot->GetSurface(4)->SetVertexIndex(2, 2);
			//foot->GetSurface(4)->SetVertexIndex(3, 1);

			//head = new Model3d();
			//head->Initialize(3, 5, 5);
			//head->GetVertex(0)->colorIndex = 0;
			//head->GetVertex(1)->colorIndex = 0;
			//head->GetVertex(2)->colorIndex = 0;
			//head->GetVertex(3)->colorIndex = 1;
			//head->GetVertex(4)->colorIndex = 2;
			//head->GetColor(0)->Set(255, 255, 255);
			//head->GetColor(1)->Set(255, 0, 0);
			//head->GetColor(2)->Set(0, 0, 255);
			//head->GetVertex(0)->vertex.Set(0.0f, 1.0f, 0.5f);
			//head->GetVertex(1)->vertex.Set(1.5f, -1.0f, 1.5f);
			//head->GetVertex(2)->vertex.Set(-1.5f, -1.0f, 1.5f);
			//head->GetVertex(3)->vertex.Set(-1.5f, -1.0f, -1.5f);
			//head->GetVertex(4)->vertex.Set(1.5f, -1.0f, -1.5f);
			//head->GetSurface(0)->Initialize(3, true);
			//head->GetSurface(1)->Initialize(3, true);
			//head->GetSurface(2)->Initialize(3, true);
			//head->GetSurface(3)->Initialize(3, true);
			//head->GetSurface(4)->Initialize(4, true);
			//head->GetSurface(0)->SetVertexIndex(0, 0);
			//head->GetSurface(0)->SetVertexIndex(1, 1);
			//head->GetSurface(0)->SetVertexIndex(2, 2);
			//head->GetSurface(0)->SetTexture(GameContext::Instance->TextureRegistry.GetTexture("TriGuyFace1"));
			//head->GetSurface(0)->SetVertexTexCoords(0, 0.5f, 0.1f);
			//head->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.9f);
			//head->GetSurface(0)->SetVertexTexCoords(2, 0.0f, 0.9f);
			//head->GetSurface(1)->SetVertexIndex(0, 0);
			//head->GetSurface(1)->SetVertexIndex(1, 2);
			//head->GetSurface(1)->SetVertexIndex(2, 3);
			//head->GetSurface(2)->SetVertexIndex(0, 0);
			//head->GetSurface(2)->SetVertexIndex(1, 3);
			//head->GetSurface(2)->SetVertexIndex(2, 4);
			//head->GetSurface(3)->SetVertexIndex(0, 0);
			//head->GetSurface(3)->SetVertexIndex(1, 4);
			//head->GetSurface(3)->SetVertexIndex(2, 1);
			//head->GetSurface(4)->SetVertexIndex(0, 4);
			//head->GetSurface(4)->SetVertexIndex(1, 3);
			//head->GetSurface(4)->SetVertexIndex(2, 2);
			//head->GetSurface(4)->SetVertexIndex(3, 1);

			modelOrient = new Orient3d();
			modelOrient->LoadIdentity();
			modelOrient->p = modelOrient->p + Vector3d(0.0f, 0.0f, 15.0f);
			modelOrient->Rotate(modelOrient->u, 180.0f);

			triguy = new JointedModel3d();
			triguy->MakeTriGuy(GameContext::TextureRegistry.GetTexture("TriGuyFace1"));
			// orients: 0 head, 1 right hand, 2 left hand, 3 right foot, 4 left foot, 5-12 right fingers (5-6 thumb), 13-20 left fingers (13-14 thumb)
			//triguy->Initialize(nullptr, -1, 5); // head, hand, hand, foot, foot
			//// head
			//triguy->GetJoint(0)->Initialize(head, 0);
			//// right hand
			//triguy->GetJoint(1)->Initialize(handPalm, 1, 4);
			//triguy->GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 5, 1);
			//triguy->GetJoint(1)->GetJoint(1)->Initialize(fingerKnuckle, 6, 1);
			//triguy->GetJoint(1)->GetJoint(2)->Initialize(fingerKnuckle, 7, 1);
			//triguy->GetJoint(1)->GetJoint(3)->Initialize(fingerKnuckle, 8, 1);
			//triguy->GetJoint(1)->GetJoint(0)->GetJoint(0)->Initialize(fingerKnuckle, 9);
			//triguy->GetJoint(1)->GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 10);
			//triguy->GetJoint(1)->GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 11);
			//triguy->GetJoint(1)->GetJoint(3)->GetJoint(0)->Initialize(fingerKnuckle, 12);
			//// left hand
			//triguy->GetJoint(2)->Initialize(handPalm, 2, 4);
			//triguy->GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 13, 1);
			//triguy->GetJoint(2)->GetJoint(1)->Initialize(fingerKnuckle, 14, 1);
			//triguy->GetJoint(2)->GetJoint(2)->Initialize(fingerKnuckle, 15, 1);
			//triguy->GetJoint(2)->GetJoint(3)->Initialize(fingerKnuckle, 16, 1);
			//triguy->GetJoint(2)->GetJoint(0)->GetJoint(0)->Initialize(fingerKnuckle, 17);
			//triguy->GetJoint(2)->GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 18);
			//triguy->GetJoint(2)->GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 19);
			//triguy->GetJoint(2)->GetJoint(3)->GetJoint(0)->Initialize(fingerKnuckle, 20);
			//// right foot
			//triguy->GetJoint(3)->Initialize(foot, 3);
			//// left foot
			//triguy->GetJoint(4)->Initialize(foot, 4);

			// should return 21
			modelJointOrients = triguy->CreateGameObjectJointOrients();

			standingAnimationRef = triguy->GetAnimation(0);
			walkingAnimationRef = triguy->GetAnimation(1);
			runningAnimationRef = triguy->GetAnimation(2);

			danceStompAnimation = CreateDanceStompAnimation();

			animationTracker = new JointedModelAnimationTracker();
			animationTracker->SetAnimation(triguy->GetDefaultAnimation());

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			cameraOrient->p = Vector3d(15.0f, 0.0f, 15.0f);
			cameraOrient->Rotate(cameraOrient->u, 90.0f);

			// just for now
			for (int i = 0; i < triguy->GetTotalJointOrientQty(); i++) // this is SLOW
			{
				modelJointOrients[i].LoadIdentity();
				modelJointOrients[i].p.y = -float(i) / 2.0f;
			}

			// todo: define two stances and an animation routine that loops through them
			// animations have stances at specific times and interpolate to another stance over that time
			// so set up stance 0 and 1, and set up an animation to interpolate from stance 0 to 1 for 1000ms, then from 1 to 0 for 1000ms, and repeat (record 2000 for the entire animation)
			// classes: JointedModelAnimationStance (list of orients and index to apply to array for each, usually 1 to 1), JointedModelAnimation (list of keyframes), JointedModelKeyframe (start stance, end stance, length of time), JointedModelTracker (actual data)
			// usually an animation involving a list of keyframes will all use the same list of orients... validation could check this?

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (modelOrient != nullptr)
			{
				delete modelOrient;
				modelOrient = nullptr;
			}
			if (modelJointOrients != nullptr)
			{
				delete[] modelJointOrients;
				modelJointOrients = nullptr;
			}
			//if (fingerKnuckle != nullptr)
			//{
			//	delete fingerKnuckle;
			//	fingerKnuckle = nullptr;
			//}
			//if (handPalm != nullptr)
			//{
			//	delete handPalm;
			//	handPalm = nullptr;
			//}
			//if (foot != nullptr)
			//{
			//	delete foot;
			//	foot = nullptr;
			//}
			//if (head != nullptr)
			//{
			//	delete head;
			//	head = nullptr;
			//}
			if (triguy != nullptr)
			{
				delete triguy;
				triguy = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}

			//if (standingAnimation != nullptr)
			//{
			//	delete standingAnimation;
			//	standingAnimation = nullptr;
			//}
			//if (walkingAnimation != nullptr)
			//{
			//	delete walkingAnimation;
			//	walkingAnimation = nullptr;
			//}
			//if (runningAnimation != nullptr)
			//{
			//	delete runningAnimation;
			//	runningAnimation = nullptr;
			//}
			if (danceStompAnimation != nullptr)
			{
				delete danceStompAnimation;
				danceStompAnimation = nullptr;
			}
			if (dancePranceAnimation != nullptr)
			{
				delete dancePranceAnimation;
				dancePranceAnimation = nullptr;
			}
			if (danceJazzhandAnimation != nullptr)
			{
				delete danceJazzhandAnimation;
				danceJazzhandAnimation = nullptr;
			}
			if (danceHipAnimation != nullptr)
			{
				delete danceHipAnimation;
				danceHipAnimation = nullptr;
			}
			if (danceTiptoeAnimation != nullptr)
			{
				delete danceTiptoeAnimation;
				danceTiptoeAnimation = nullptr;
			}
			if (danceThrustAnimation != nullptr)
			{
				delete danceThrustAnimation;
				danceThrustAnimation = nullptr;
			}
			if (dancePointAnimation != nullptr)
			{
				delete dancePointAnimation;
				dancePointAnimation = nullptr;
			}
			if (danceBendAnimation != nullptr)
			{
				delete danceBendAnimation;
				danceBendAnimation = nullptr;
			}
			if (danceBounceAnimation != nullptr)
			{
				delete danceBounceAnimation;
				danceBounceAnimation = nullptr;
			}

			if (animationTracker != nullptr)
			{
				delete animationTracker;
				animationTracker = nullptr;
			}
		}
	
		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}

		////////////////////////

		//JointedModelAnimation * CreateStandingAnimation()
		//{
		//	int orientQty = 21;

		//	JointedModelAnimation *animation = new JointedModelAnimation();
		//	animation->Initialize(3);
		//	animation->GetKeyframe(2)->Initialize(orientQty, 1000.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(0)->orientIndex = 0;
		//	animation->GetKeyframe(2)->GetStanceOrient(0)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 1.0f, 0.0f);
		//	//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
		//	//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(1)->orientIndex = 3;
		//	animation->GetKeyframe(2)->GetStanceOrient(1)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(1)->orient.p = Vector3d(-1.0f, -2.5f, 0.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orientIndex = 4;
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = Vector3d(1.0f, -2.5f, 0.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(3)->orientIndex = 1;
		//	animation->GetKeyframe(2)->GetStanceOrient(3)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, 0.5f, 0.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(3)->orient.u, 90.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(3)->orient.l, -45.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(4)->orientIndex = 2;
		//	animation->GetKeyframe(2)->GetStanceOrient(4)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, 0.5f, 0.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(4)->orient.u, -90.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(4)->orient.l, -45.0f);
		//	// right fingers
		//	// thumb
		//	animation->GetKeyframe(2)->GetStanceOrient(5)->orientIndex = 5;
		//	animation->GetKeyframe(2)->GetStanceOrient(5)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
		//	animation->GetKeyframe(2)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(5)->orient.u, -90.0f);
		//	// index
		//	animation->GetKeyframe(2)->GetStanceOrient(6)->orientIndex = 6;
		//	animation->GetKeyframe(2)->GetStanceOrient(6)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(6)->orient.u, -10.0f);
		//	// middle
		//	animation->GetKeyframe(2)->GetStanceOrient(7)->orientIndex = 7;
		//	animation->GetKeyframe(2)->GetStanceOrient(7)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
		//	// pinky
		//	animation->GetKeyframe(2)->GetStanceOrient(8)->orientIndex = 8;
		//	animation->GetKeyframe(2)->GetStanceOrient(8)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(8)->orient.u, 10.0f);
		//	// 4 digits
		//	animation->GetKeyframe(2)->GetStanceOrient(9)->orientIndex = 9;
		//	animation->GetKeyframe(2)->GetStanceOrient(9)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(2)->GetStanceOrient(10)->orientIndex = 10;
		//	animation->GetKeyframe(2)->GetStanceOrient(10)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(2)->GetStanceOrient(11)->orientIndex = 11;
		//	animation->GetKeyframe(2)->GetStanceOrient(11)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(2)->GetStanceOrient(12)->orientIndex = 12;
		//	animation->GetKeyframe(2)->GetStanceOrient(12)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	// left fingers
		//	// thumb
		//	animation->GetKeyframe(2)->GetStanceOrient(13)->orientIndex = 13;
		//	animation->GetKeyframe(2)->GetStanceOrient(13)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
		//	animation->GetKeyframe(2)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(13)->orient.u, 90.0f);
		//	// index
		//	animation->GetKeyframe(2)->GetStanceOrient(14)->orientIndex = 14;
		//	animation->GetKeyframe(2)->GetStanceOrient(14)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(14)->orient.u, 10.0f);
		//	// middle
		//	animation->GetKeyframe(2)->GetStanceOrient(15)->orientIndex = 15;
		//	animation->GetKeyframe(2)->GetStanceOrient(15)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
		//	// pinky
		//	animation->GetKeyframe(2)->GetStanceOrient(16)->orientIndex = 16;
		//	animation->GetKeyframe(2)->GetStanceOrient(16)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(2)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(16)->orient.u, -10.0f);
		//	// digits
		//	animation->GetKeyframe(2)->GetStanceOrient(17)->orientIndex = 17;
		//	animation->GetKeyframe(2)->GetStanceOrient(17)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(2)->GetStanceOrient(18)->orientIndex = 18;
		//	animation->GetKeyframe(2)->GetStanceOrient(18)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(2)->GetStanceOrient(19)->orientIndex = 19;
		//	animation->GetKeyframe(2)->GetStanceOrient(19)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(2)->GetStanceOrient(20)->orientIndex = 20;
		//	animation->GetKeyframe(2)->GetStanceOrient(20)->orient.LoadIdentity();
		//	animation->GetKeyframe(2)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	
		//	//animation->GetKeyframe(1)->Initialize(orientQty, 875.0f); // copy initializes!
		//	animation->CopyKeyframeToKeyframe(2, 1);
		//	animation->GetKeyframe(1)->intervalMSf = 875.0f;
		//	// dip head
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 0.8f, 0.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -5.0f);
		//	// tip feet up
		//	animation->GetKeyframe(1)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(1)->orient.l, 10.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(2)->orient.l, 10.0f);
		//	// lower hands
		//	animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p.y = 0.4f;
		//	animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p.y = 0.4f;
		//	// bend all fingers
		//	animation->GetKeyframe(1)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(5)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(6)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(7)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(8)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(9)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(10)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(11)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(12)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(13)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(14)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(15)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(16)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(17)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(18)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(19)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(20)->orient.l, -45.0f);

		//	// this stance allows quick recovery from walking, running and jumping
		//	//animation->GetKeyframe(0)->Initialize(orientQty, 125.0f);  // copy initializes!
		//	animation->CopyKeyframeToKeyframe(2, 0);
		//	animation->GetKeyframe(0)->intervalMSf = 125.0f;
		//	// dip head
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 0.975f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -0.625f);
		//	// tip feet up
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(1)->orient.l, 1.25f);
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(2)->orient.l, 1.25f);
		//	// lower hands
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p.y = 0.49875f;
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p.y = 0.49875f;
		//	// bend all fingers
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -5.625f);
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -5.625f);

		//	animation->Commit();

		//	return animation;
		//}

		//JointedModelAnimation * CreateWalkingAnimation()
		//{
		//	int orientQty = 21;

		//	JointedModelAnimation *animation = new JointedModelAnimation();
		//	animation->Initialize(4);

		//	// set up base stance
		//	animation->GetKeyframe(0)->Initialize(orientQty, 125.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 1.0f, 0.0f);
		//	//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
		//	//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 3;
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = Vector3d(-1.0f, -2.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 4;
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orient.p = Vector3d(1.0f, -2.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 1;
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, 0.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.u, 90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.l, -45.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orientIndex = 2;
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, 0.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.u, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.l, -45.0f);
		//	// right fingers
		//	// thumb
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orientIndex = 5;
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.u, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -90.0f);
		//	// index
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orientIndex = 6;
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.u, -10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -90.0f);
		//	// middle
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orientIndex = 7;
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -90.0f);
		//	// pinky
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orientIndex = 8;
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.u, 10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -90.0f);
		//	// 4 digits
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orientIndex = 9;
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orientIndex = 10;
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orientIndex = 11;
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orientIndex = 12;
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -90.0f);
		//	// left fingers
		//	// thumb
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orientIndex = 13;
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.u, 90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -90.0f);
		//	// index
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orientIndex = 14;
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.u, 10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -90.0f);
		//	// middle
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orientIndex = 15;
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -90.0f);
		//	// pinky
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orientIndex = 16;
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.u, -10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -90.0f);
		//	// digits
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orientIndex = 17;
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orientIndex = 18;
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orientIndex = 19;
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orientIndex = 20;
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -90.0f);

		//	// copy to other stances
		//	animation->CopyKeyframeToKeyframe(0, 1);
		//	animation->GetKeyframe(1)->intervalMSf = 250.0f;
		//	animation->CopyKeyframeToKeyframe(0, 2);
		//	animation->GetKeyframe(2)->intervalMSf = 125.0f;
		//	animation->CopyKeyframeToKeyframe(0, 3);
		//	animation->GetKeyframe(3)->intervalMSf = 250.0f;

		//	// now modify each so it looks like walking

		//	// right foot stepping up
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(1)->orient.l, 45.0f);

		//	// right foot down
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p + Vector3d(0.5f, -0.5f, 0.5f);
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -10.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.u, -5.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(2)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -1.0f, 0.0f));
		//	animation->GetKeyframe(1)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(3)->orient.u, 45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -0.5f, 0.0f));
		//	animation->GetKeyframe(1)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(4)->orient.u, 45.0f);

		//	// left foot stepping up
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(2)->orient.l, 45.0f);

		//	// left foot down
		//	animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p + Vector3d(-0.5f, -0.5f, 0.5f);
		//	animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.l, -10.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.u, 5.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(1)->orient.l, -45.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -0.5f, 0.0f));
		//	animation->GetKeyframe(3)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(3)->orient.u, -45.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -1.0f, 0.0f));
		//	animation->GetKeyframe(3)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(4)->orient.u, -45.0f);

		//	return animation;
		//}

		//JointedModelAnimation * CreateRunningAnimation()
		//{
		//	int orientQty = 21;

		//	JointedModelAnimation *animation = new JointedModelAnimation();
		//	animation->Initialize(4);

		//	// set up base stance
		//	animation->GetKeyframe(0)->Initialize(orientQty, 85.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 1.0f, 0.0f);
		//	//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
		//	//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 3;
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = Vector3d(-1.0f, -2.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 4;
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(2)->orient.p = Vector3d(1.0f, -2.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 1;
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, 0.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.u, 90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.l, -45.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orientIndex = 2;
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, 0.5f, 0.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.u, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.l, -45.0f);
		//	// right fingers
		//	// thumb
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orientIndex = 5;
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.u, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -90.0f);
		//	// index
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orientIndex = 6;
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.u, -10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -90.0f);
		//	// middle
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orientIndex = 7;
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -90.0f);
		//	// pinky
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orientIndex = 8;
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.u, 10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -90.0f);
		//	// 4 digits
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orientIndex = 9;
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orientIndex = 10;
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orientIndex = 11;
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orientIndex = 12;
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -90.0f);
		//	// left fingers
		//	// thumb
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orientIndex = 13;
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.u, 90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -90.0f);
		//	// index
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orientIndex = 14;
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.u, 10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -90.0f);
		//	// middle
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orientIndex = 15;
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -90.0f);
		//	// pinky
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orientIndex = 16;
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.u, -10.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -90.0f);
		//	// digits
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orientIndex = 17;
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orientIndex = 18;
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orientIndex = 19;
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -90.0f);
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orientIndex = 20;
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.LoadIdentity();
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
		//	animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -90.0f);

		//	// copy to other stances
		//	animation->CopyKeyframeToKeyframe(0, 1);
		//	animation->GetKeyframe(1)->intervalMSf = 179.0f;
		//	animation->CopyKeyframeToKeyframe(0, 2);
		//	animation->GetKeyframe(2)->intervalMSf = 85.0f;
		//	animation->CopyKeyframeToKeyframe(0, 3);
		//	animation->GetKeyframe(3)->intervalMSf = 170.0f;

		//	// now modify each so it looks like walking

		//	// right foot stepping up
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
		//	animation->GetKeyframe(0)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(1)->orient.l, 45.0f);

		//	// right foot down
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p + Vector3d(0.5f, -0.5f, 0.5f);
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -10.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.u, -5.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(2)->orient.l, -45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -1.0f, 0.0f));
		//	animation->GetKeyframe(1)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(3)->orient.u, 45.0f);
		//	animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -0.5f, 0.0f));
		//	animation->GetKeyframe(1)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(4)->orient.u, 45.0f);

		//	// left foot stepping up
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
		//	animation->GetKeyframe(2)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(2)->orient.l, 45.0f);

		//	// left foot down
		//	animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p + Vector3d(-0.5f, -0.5f, 0.5f);
		//	animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.l, -10.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.u, 5.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(1)->orient.l, -45.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -0.5f, 0.0f));
		//	animation->GetKeyframe(3)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(3)->orient.u, -45.0f);
		//	animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -1.0f, 0.0f));
		//	animation->GetKeyframe(3)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(4)->orient.u, -45.0f);

		//	return animation;
		//}

		JointedModelAnimation * CreateDanceStompAnimation()
		{
			// 4 beats in Sia Cheap Thrills = ~2668ms, or ~667ms per beat (2667.75, 666.9375 if you want fuller accuracy)
			// 16 for intro, 32 beats for a verse, 48 for chorus (both twice), 64 for bridge, 48 final chorus, 32 for tail - 213.42 sec/320 beats
			// unfortunately the song is a little uneven as I imagine most are, but as long as the movements are 667ms or so at a time, it should be good enough - in the end it's only off by a small fraction of a second
			int orientQty = 21;

			JointedModelAnimation *animation = new JointedModelAnimation();
			animation->Initialize(8);
			animation->GetKeyframe(0)->Initialize(orientQty, 333.5f);
			animation->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
			//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
			//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
			animation->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = Vector3d(-1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(2)->orient.p = Vector3d(1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 1;
			animation->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, -1.0f, 0.0f);
			animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.u, 90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.l, -45.0f);
			animation->GetKeyframe(0)->GetStanceOrient(4)->orientIndex = 2;
			animation->GetKeyframe(0)->GetStanceOrient(4)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, -1.0f, 0.0f);
			animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.u, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.l, -45.0f);
			// right fingers
			// thumb
			animation->GetKeyframe(0)->GetStanceOrient(5)->orientIndex = 5;
			animation->GetKeyframe(0)->GetStanceOrient(5)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
			animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.u, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -90.0f);
			// index
			animation->GetKeyframe(0)->GetStanceOrient(6)->orientIndex = 6;
			animation->GetKeyframe(0)->GetStanceOrient(6)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
			animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.u, -10.0f);
			animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -90.0f);
			// middle
			animation->GetKeyframe(0)->GetStanceOrient(7)->orientIndex = 7;
			animation->GetKeyframe(0)->GetStanceOrient(7)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
			animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -90.0f);
			// pinky
			animation->GetKeyframe(0)->GetStanceOrient(8)->orientIndex = 8;
			animation->GetKeyframe(0)->GetStanceOrient(8)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
			animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.u, 10.0f);
			animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -90.0f);
			// 4 digits
			animation->GetKeyframe(0)->GetStanceOrient(9)->orientIndex = 9;
			animation->GetKeyframe(0)->GetStanceOrient(9)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(10)->orientIndex = 10;
			animation->GetKeyframe(0)->GetStanceOrient(10)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(11)->orientIndex = 11;
			animation->GetKeyframe(0)->GetStanceOrient(11)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(12)->orientIndex = 12;
			animation->GetKeyframe(0)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(12)->orient.LoadIdentity();
			// left fingers
			// thumb
			animation->GetKeyframe(0)->GetStanceOrient(13)->orientIndex = 13;
			animation->GetKeyframe(0)->GetStanceOrient(13)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
			animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.u, 90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -90.0f);
			// index
			animation->GetKeyframe(0)->GetStanceOrient(14)->orientIndex = 14;
			animation->GetKeyframe(0)->GetStanceOrient(14)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
			animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.u, 10.0f);
			animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -90.0f);
			// middle
			animation->GetKeyframe(0)->GetStanceOrient(15)->orientIndex = 15;
			animation->GetKeyframe(0)->GetStanceOrient(15)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
			animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -90.0f);
			// pinky
			animation->GetKeyframe(0)->GetStanceOrient(16)->orientIndex = 16;
			animation->GetKeyframe(0)->GetStanceOrient(16)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
			animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.u, -10.0f);
			animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -90.0f);
			// digits
			animation->GetKeyframe(0)->GetStanceOrient(17)->orientIndex = 17;
			animation->GetKeyframe(0)->GetStanceOrient(17)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(18)->orientIndex = 18;
			animation->GetKeyframe(0)->GetStanceOrient(18)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(19)->orientIndex = 19;
			animation->GetKeyframe(0)->GetStanceOrient(19)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -90.0f);
			animation->GetKeyframe(0)->GetStanceOrient(20)->orientIndex = 20;
			animation->GetKeyframe(0)->GetStanceOrient(20)->orient.LoadIdentity();
			animation->GetKeyframe(0)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
			animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -90.0f);
			animation->GetKeyframe(1)->Initialize(orientQty, 333.4375f);
			animation->CopyKeyframeToKeyframe(0, 1); // copy hands
			animation->GetKeyframe(1)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(1)->GetStanceOrient(0)->orient.LoadIdentity();
			animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = Vector3d(0.5f, -0.5f, 0.0f);
			animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -15.0f);
			animation->GetKeyframe(1)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(1)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p = Vector3d(-0.5f, -1.5f, 0.0f);
			animation->GetKeyframe(1)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(1)->orient.l, -45.0f);
			animation->GetKeyframe(1)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(1)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p = Vector3d(1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p = Vector3d(-1.5f, -0.5f, 0.0f);
			animation->GetKeyframe(1)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(3)->orient.l, -20.0f);
			animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p = Vector3d(2.5f, -0.5f, 0.0f);
			animation->GetKeyframe(1)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(4)->orient.l, -20.0f);
			animation->GetKeyframe(2)->Initialize(orientQty, 333.5f);
			animation->CopyKeyframeToKeyframe(0, 2); // copy hands
			animation->GetKeyframe(2)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(2)->GetStanceOrient(0)->orient.LoadIdentity();
			animation->GetKeyframe(2)->GetStanceOrient(0)->orient.p = Vector3d(1.0f, 0.0f, 0.0f);
			//animation->GetKeyframe(2)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(0)->orient.u, 30.0f);
			//animation->GetKeyframe(2)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(0)->orient.l, -30.0f);
			animation->GetKeyframe(2)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(0)->orient.f, -7.0f);
			animation->GetKeyframe(2)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(0)->orient.u, 15.0f);
			animation->GetKeyframe(2)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(2)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(2)->GetStanceOrient(1)->orient.p = Vector3d(0.5f, -3.5f, 0.0f);
			animation->GetKeyframe(2)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(2)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = Vector3d(1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(2)->GetStanceOrient(3)->orient.p = Vector3d(-1.0f, -1.0f, 0.0f);
			animation->GetKeyframe(2)->GetStanceOrient(4)->orient.p = Vector3d(3.0f, -1.0f, 0.0f);
			animation->GetKeyframe(3)->Initialize(orientQty, 333.4375f);
			animation->CopyKeyframeToKeyframe(0, 3); // copy hands
			animation->GetKeyframe(3)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(3)->GetStanceOrient(0)->orient.LoadIdentity();
			animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p = Vector3d(0.5f, -0.5f, 0.0f);
			animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.l, -15.0f);
			animation->GetKeyframe(3)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(3)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p = Vector3d(-0.5f, -1.5f, 0.0f);
			animation->GetKeyframe(3)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(1)->orient.l, -45.0f);
			animation->GetKeyframe(3)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(3)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p = Vector3d(1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p = Vector3d(-1.5f, -0.5f, 0.0f);
			animation->GetKeyframe(3)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(3)->orient.l, -20.0f);
			animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p = Vector3d(2.5f, -0.5f, 0.0f);
			animation->GetKeyframe(3)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(4)->orient.l, -20.0f);
			animation->GetKeyframe(4)->Initialize(orientQty, 333.5f);
			animation->CopyKeyframeToKeyframe(0, 4); // copy hands
			animation->GetKeyframe(4)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(4)->GetStanceOrient(0)->orient.LoadIdentity();
			//animation->GetKeyframe(4)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(4)->GetStanceOrient(0)->orient.u, -30.0f);
			//animation->GetKeyframe(4)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(4)->GetStanceOrient(0)->orient.l, -30.0f);
			animation->GetKeyframe(4)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(4)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(4)->GetStanceOrient(1)->orient.p = Vector3d(-1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(4)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(4)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(4)->GetStanceOrient(2)->orient.p = Vector3d(1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(5)->Initialize(orientQty, 333.4375f);
			animation->CopyKeyframeToKeyframe(0, 5); // copy hands
			animation->GetKeyframe(5)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(5)->GetStanceOrient(0)->orient.LoadIdentity();
			animation->GetKeyframe(5)->GetStanceOrient(0)->orient.p = Vector3d(-0.5f, -0.5f, 0.0f);
			animation->GetKeyframe(5)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(5)->GetStanceOrient(0)->orient.l, -15.0f);
			animation->GetKeyframe(5)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(5)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(5)->GetStanceOrient(1)->orient.p = Vector3d(-1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(5)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(5)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(5)->GetStanceOrient(2)->orient.p = Vector3d(0.5f, -1.5f, 0.0f);
			animation->GetKeyframe(5)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(5)->GetStanceOrient(2)->orient.l, -45.0f);
			animation->GetKeyframe(5)->GetStanceOrient(3)->orient.p = Vector3d(-2.5f, -0.5f, 0.0f);
			animation->GetKeyframe(5)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(5)->GetStanceOrient(3)->orient.l, -20.0f);
			animation->GetKeyframe(5)->GetStanceOrient(4)->orient.p = Vector3d(1.5f, -0.5f, 0.0f);
			animation->GetKeyframe(5)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(5)->GetStanceOrient(4)->orient.l, -20.0f);
			animation->GetKeyframe(6)->Initialize(orientQty, 333.5f);
			animation->CopyKeyframeToKeyframe(0, 6); // copy hands
			animation->GetKeyframe(6)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(6)->GetStanceOrient(0)->orient.LoadIdentity();
			animation->GetKeyframe(6)->GetStanceOrient(0)->orient.p = Vector3d(-1.0f, 0.0f, 0.0f);
			//animation->GetKeyframe(6)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(6)->GetStanceOrient(0)->orient.u, 30.0f);
			//animation->GetKeyframe(6)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(6)->GetStanceOrient(0)->orient.l, -30.0f);
			animation->GetKeyframe(6)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(6)->GetStanceOrient(0)->orient.f, 7.0f);
			animation->GetKeyframe(6)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(6)->GetStanceOrient(0)->orient.u, -15.0f);
			animation->GetKeyframe(6)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(6)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(6)->GetStanceOrient(1)->orient.p = Vector3d(-1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(6)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(6)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(6)->GetStanceOrient(2)->orient.p = Vector3d(-0.5f, -3.5f, 0.0f);
			animation->GetKeyframe(6)->GetStanceOrient(3)->orient.p = Vector3d(-3.0f, -1.0f, 0.0f);
			animation->GetKeyframe(6)->GetStanceOrient(4)->orient.p = Vector3d(1.0f, -1.0f, 0.0f);
			animation->GetKeyframe(7)->Initialize(orientQty, 333.4375f);
			animation->CopyKeyframeToKeyframe(0, 7); // copy hands
			animation->GetKeyframe(7)->GetStanceOrient(0)->orientIndex = 0;
			animation->GetKeyframe(7)->GetStanceOrient(0)->orient.LoadIdentity();
			animation->GetKeyframe(7)->GetStanceOrient(0)->orient.p = Vector3d(-0.5f, -0.5f, 0.0f);
			animation->GetKeyframe(7)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(7)->GetStanceOrient(0)->orient.l, -15.0f);
			animation->GetKeyframe(7)->GetStanceOrient(1)->orientIndex = 3;
			animation->GetKeyframe(7)->GetStanceOrient(1)->orient.LoadIdentity();
			animation->GetKeyframe(7)->GetStanceOrient(1)->orient.p = Vector3d(-1.5f, -3.5f, 0.0f);
			animation->GetKeyframe(7)->GetStanceOrient(2)->orientIndex = 4;
			animation->GetKeyframe(7)->GetStanceOrient(2)->orient.LoadIdentity();
			animation->GetKeyframe(7)->GetStanceOrient(2)->orient.p = Vector3d(0.5f, -1.5f, 0.0f);
			animation->GetKeyframe(7)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(7)->GetStanceOrient(2)->orient.l, -45.0f);
			animation->GetKeyframe(7)->GetStanceOrient(3)->orient.p = Vector3d(-2.5f, -0.5f, 0.0f);
			animation->GetKeyframe(7)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(7)->GetStanceOrient(3)->orient.l, -20.0f);
			animation->GetKeyframe(7)->GetStanceOrient(4)->orient.p = Vector3d(1.5f, -0.5f, 0.0f);
			animation->GetKeyframe(7)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(7)->GetStanceOrient(4)->orient.l, -20.0f);
			animation->Commit();

			// move orientations 0-4 up 1 to match walking animation.  oops
			for (int i = 0; i < animation->keyframeQty; i++)
			{
				for (int j = 0; j <= 4; j++)
				{
					animation->GetKeyframe(i)->GetStanceOrient(j)->orient.p.y = animation->GetKeyframe(i)->GetStanceOrient(j)->orient.p.y + 1.0f;
				}
			}

			return animation;
		}
		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
			}
			if (mouse.leftButton.down)
			{
				modelOrient->Rotate(Vector3d(0, 1, 0), -float(mouse.offsetX));
				if (mouse.rightButton.down == false)
					modelOrient->Rotate(modelOrient->l, float(mouse.offsetY));
			}
			mouse.ZeroOffsets();

			Vector3d moveVector = Vector3d(0, 0, 0);
			int moving = 0;
			if (keyboardKeys.GetKey('W')->pressed) // forward
			{
				Vector3d move = modelOrient->f;
				move.y = 0.0f;
				if (move.Normalize() == false)
				{
					move = modelOrient->u.ScalarMult(-1.0f);
					move.y = 0.0f;
					move.Normalize();
				}
				moveVector = moveVector + move;
				moving += 1;
			}
			if (keyboardKeys.GetKey('S')->pressed) // backward
			{
				Vector3d move = modelOrient->f.ScalarMult(-1.0f);
				move.y = 0.0f;
				if (move.Normalize() == false)
				{
					move = modelOrient->u;
					move.y = 0.0f;
					move.Normalize();
				}
				moveVector = moveVector + move;
				moving -= 1;
			}
			if (keyboardKeys.GetKey('A')->pressed) // left
			{
				Vector3d move = modelOrient->l.ScalarMult(1.0f);
				move.y = 0.0f;
				move.Normalize();
				moveVector = moveVector + move;
				moving += 2;
			}
			if (keyboardKeys.GetKey('D')->pressed) // right
			{
				Vector3d move = modelOrient->l.ScalarMult(-1.0f);
				move.y = 0.0f;
				move.Normalize();
				moveVector = moveVector + move;
				moving += 2;
			}
			bool running = false;
			if (keyboardKeys.GetKey(16)->pressed) // shift for run
			{
				running = true;
				moveVector = moveVector.ScalarMult(250.0f / 170.0f); // coordinate with animation
			}
			if (keyboardKeys.GetKey(13)->IsClicked() == true) // click to prevent autorepeat
			{
				doAnaglyph = !doAnaglyph;
			}
			keyboardKeys.ClearClicked();

			if (moving != 0)
			{
				modelOrient->p = modelOrient->p + moveVector.ScalarMult(float(timer->GetElapsedTimeMSFloat() * 2.0f / 250.0f)); // coordinate with animation
				if (running == false)
				{
					if (animationTracker->animationRef != walkingAnimationRef)
						animationTracker->SetAnimation(walkingAnimationRef, 0);
				}
				else
				{
					if (animationTracker->animationRef != runningAnimationRef)
						animationTracker->SetAnimation(runningAnimationRef, 0);
				}
			}
			else
			{ 
				if (keyboardKeys.GetKey(32)->pressed) // space to dance
				{
					animationTracker->SetAnimation(danceStompAnimation, 0);
				}

				if (animationTracker->animationRef != standingAnimationRef && animationTracker->animationRef != danceStompAnimation)
					animationTracker->SetAnimation(standingAnimationRef, 0);
			}

			Animate(timer->GetElapsedTimeMS());

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(int p_elapsedTimeMS)
		{
			animationTracker->Animate(float(p_elapsedTimeMS), modelJointOrients);
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			bool showDeathStarDeepField = true;
			bool showDeathStarAnaglyph = false;
			ModelVertex deathStarVertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			GameTexture ^deathStarTexture = GameContext::Instance->TextureRegistry.GetTexture("DeathStar1");
			GameColor white(255, 255, 255);

			float deathStarDepth = 3.0f;

			if (doAnaglyph == false)
			{
				graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);
				graphics->DefaultTransform();

				// render death star with no depth as a background object
				if (showDeathStarDeepField == true || showDeathStarAnaglyph == true)
				{
					graphics->SetDepthWriteEnabled(false);
					graphics->SetDepthTestEnabled(false);
					graphics->Translate(0.0f, 0.0f, deathStarDepth);
					graphics->RenderFilledQuad(&white, 1, deathStarVertices, 4, true, deathStarTexture, texCoords, 4);
					graphics->SetDepthWriteEnabled(true);
					graphics->SetDepthTestEnabled(true);
				}

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);

				graphics->PushMatrix();
				graphics->Transform(*modelOrient);
				triguy->Render(*graphics, modelJointOrients, 21);
				graphics->PopMatrix();
			}
			else
			{
				//StereoscopicCamera stereoCamera(0.2f, 0.03f);// enhanced depth, close convergence (hard to handle)
				//StereoscopicCamera stereoCamera(15.0f, 0.156f);
				//StereoscopicCamera stereoCamera(15.0f, 0.60f);
				//StereoscopicCamera stereoCamera(0.2f, 0.015f); // good depth field
				//StereoscopicCamera stereoCamera(1.0f, 0.1f); // good depth field (around ratio of 10?)
				//StereoscopicCamera stereoCamera(10.0f, 1.0f); // good depth field (ratio of 10) - ok to resolve but effect a little extreme on triguy
				//StereoscopicCamera stereoCamera(10.0f, 2.0f); // even deeper depth field (ratio of 5) - bad - eyes can't focus on monitor - too used to focusing on somethign far away when that far apart
				//StereoscopicCamera stereoCamera(10.0f, 1.5f); // even deeper depth field - it's ok, ncie and deep but still just a little too hard to compensate
				//StereoscopicCamera stereoCamera(10.0f, 1.75f); // even deeper depth field - still hard to resolve
				//StereoscopicCamera stereoCamera(20.0f, 2.0f); // good depth field (ratio of 10?)
				//StereoscopicCamera stereoCamera(100.0f, 10.0f); // good depth field (ratio of 10?)
				//StereoscopicCamera stereoCamera(1000.0f, 100.0f); // good depth field (ratio of 10?)
				// lesson: ratio of eye to convergence does not determine deepest depth of field position, at least at depth 999, or maybe at 999 using 100,10 just yields a slightly different result...
				//   when infinity would yield the same result?

				StereoscopicCamera stereoCamera(5.0f, 0.5f); // good depth field (around ratio of 10?) - good deep depth, ok effect on triguy
				//StereoscopicCamera stereoCamera(900.0f, 1.0f); // far field even with monitor, all objects poke out of the screen without hurting the eyes too much


				// render death star with no depth as a background object, anaglyph with calculated positions in farthest depth field possible
				if (showDeathStarDeepField == true)
				{
					graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);
					graphics->DefaultTransform();

					graphics->SetDepthWriteEnabled(false);
					graphics->SetDepthTestEnabled(false);

					graphics->PushMatrix();
					graphics->ColorMask(true, false, false, false);
					//graphics->Translate(stereoCamera.eyeSeparationLength / 2.0f / stereoCamera.convergenceDistance / 5.0f, 0.0f, 3.0f);
					graphics->Translate(stereoCamera.eyeSeparationLength / stereoCamera.convergenceDistance / 2.0f * deathStarDepth, 0.0f, deathStarDepth);
					graphics->RenderFilledQuad(&white, 1, deathStarVertices, 4, true, deathStarTexture, texCoords, 4);
					graphics->PopMatrix();

					graphics->PushMatrix();
					graphics->ColorMask(false, true, true, false);
					//graphics->Translate(-stereoCamera.eyeSeparationLength / 2.0f / stereoCamera.convergenceDistance / 5.0f, 0.0f, 3.0f);
					graphics->Translate(-stereoCamera.eyeSeparationLength / stereoCamera.convergenceDistance / 2.0f  * deathStarDepth, 0.0f, deathStarDepth);
					graphics->RenderFilledQuad(&white, 1, deathStarVertices, 4, true, deathStarTexture, texCoords, 4);
					graphics->PopMatrix();

					graphics->ColorMask(true, true, true, true);

					graphics->SetDepthWriteEnabled(true);
					graphics->SetDepthTestEnabled(true);
				}

				graphics->ColorMask(true, false, false, false);
				graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, 0.1, 1000.0, stereoCamera);
				graphics->DefaultTransformStereoscopicLeft(stereoCamera);

				float deathStarAnaglyphDepth = 999.0f;
				if (showDeathStarAnaglyph == true)
				{
					graphics->SetDepthWriteEnabled(false);
					graphics->SetDepthTestEnabled(false);

					graphics->PushMatrix();
					graphics->Translate(0.0f, 0.0f, deathStarAnaglyphDepth);
					graphics->Scale(deathStarAnaglyphDepth / deathStarDepth, deathStarAnaglyphDepth / deathStarDepth, 1.0f);
					graphics->RenderFilledQuad(&white, 1, deathStarVertices, 4, true, deathStarTexture, texCoords, 4);
					graphics->PopMatrix();

					graphics->SetDepthWriteEnabled(true);
					graphics->SetDepthTestEnabled(true);
				}

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);

				graphics->PushMatrix();
				graphics->Transform(*modelOrient);
				triguy->Render(*graphics, modelJointOrients, 21);
				graphics->PopMatrix();

				graphics->ClearDepth();

				graphics->ColorMask(false, true, true, false);
				graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, 0.1, 1000.0, stereoCamera);
				graphics->DefaultTransformStereoscopicRight(stereoCamera);

				if (showDeathStarAnaglyph == true)
				{
					graphics->SetDepthWriteEnabled(false);
					graphics->SetDepthTestEnabled(false);

					graphics->PushMatrix();
					graphics->Translate(0.0f, 0.0f, deathStarAnaglyphDepth);
					graphics->Scale(deathStarAnaglyphDepth / deathStarDepth, deathStarAnaglyphDepth / deathStarDepth, 1.0f);
					graphics->RenderFilledQuad(&white, 1, deathStarVertices, 4, true, deathStarTexture, texCoords, 4);
					graphics->PopMatrix();

					graphics->SetDepthWriteEnabled(true);
					graphics->SetDepthTestEnabled(true);
				}

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);

				graphics->PushMatrix();
				graphics->Transform(*modelOrient);
				triguy->Render(*graphics, modelJointOrients, 21);
				graphics->PopMatrix();

				graphics->ColorMask(true, true, true, true);
			}

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	// this class approximates 3d by transforming each eye in the world space
	// But this isn't exactly accurate, since in the real world, the eyes are displaced to the screen.  So the effect here isn't very prominent
	public ref class AnaglyphSimpleTest : public GameBase
	{
	public:

		Orient3d *jetOrient;
		Orient3d *cubeOrient;
		Orient3d *cameraOrient;
		Model3d *cube;
		Model3d *jet;
		Model3d *ball;
		Orient3d *ballOrient;

		AnaglyphSimpleTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			jetOrient = nullptr;
			cubeOrient = nullptr;
			cameraOrient = nullptr;
			ball = nullptr;
			ballOrient = nullptr;
		}

		virtual ~AnaglyphSimpleTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			jetOrient = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient = new Orient3d();
			ballOrient = new Orient3d();
			jetOrient->LoadIdentity();
			cubeOrient->LoadIdentity();
			cameraOrient->LoadIdentity();
			ballOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);
			// move the jet forward and over
			jetOrient->p = jetOrient->p + jetOrient->f.ScalarMult(7.0f) + jetOrient->l.ScalarMult(-2.5f) + jetOrient->u.ScalarMult(2.0f);
			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(7.0f) + cubeOrient->l.ScalarMult(2.5f) + cubeOrient->u.ScalarMult(2.0f);
			ballOrient->p = ballOrient->p + ballOrient->f.ScalarMult(7.0f) + ballOrient->l.ScalarMult(2.5f) - ballOrient->u.ScalarMult(2.0f);

			jetOrient->Rotate(jetOrient->u, 180.0f);
			cubeOrient->Rotate(cubeOrient->u, 180.0f);
			ballOrient->Rotate(ballOrient->u, 180.0f);

			cube = new Model3d();
			cube->MakeCube();
			// give it a texture, make front face white to make it pure
			cube->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));
			cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			cube->GetSurface(0)->SetVertexTexCoords(1, 0.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(3, 1.0f, 1.0f);
			cube->GetColor(0)->Set(255, 255, 255);
			cube->GetColor(1)->Set(255, 255, 255);
			cube->GetColor(2)->Set(255, 255, 255);
			cube->GetColor(3)->Set(255, 255, 255);

			jet = new Model3d();
			jet->MakeJet();

			// cheat and make it look like it did before it was fixed
			jet->GetSurface(2)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(2, -1);
			jet->GetSurface(5)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(8)->SetVertexColorOverrideIndex(0, -1);

			GameColor base(51, 51, 153);
			// sort of a cool sheen given off by making the cockpit 2 colors
			GameColor cockpitColor1(128, 128, 255);
			GameColor cockpitColor2(0, 255, 255);

			jet->GetColor(0)->Set(base.Modulate(5.0f / 6.0f));
			jet->GetColor(1)->Set(base.Modulate(2.0f / 3.0f));
			jet->GetColor(2)->Set(base.Modulate(1.0f / 3.0f));
			jet->GetColor(3)->Set(cockpitColor1);
			jet->GetColor(4)->Set(cockpitColor2);

			ball = new Model3d();
			ball->MakeSphere();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
			if (ballOrient != nullptr)
			{
				delete ballOrient;
				ballOrient = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				jetOrient->Rotate(jetOrient->f, float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(cubeOrient->f, float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(ballOrient->f, -float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				jetOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				jetOrient->Rotate(jetOrient->l, -float(mouse.offsetY) / 5.0f);
				cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
				ballOrient->Rotate(ballOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = jetOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(115, 115, 115)); // good color for anaglyph

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// prepare eyes - about 5 inches apart in world
			Orient3d leftEye = *cameraOrient;
			leftEye.p = leftEye.p + leftEye.l.ScalarMult(0.208333f);
			Orient3d rightEye = *cameraOrient;
			rightEye.p = rightEye.p + rightEye.l.ScalarMult(-0.208333f);

			// left eye
			// reverse transform the camera
			graphics->PushMatrix();
			graphics->ReverseTransform(leftEye);
			graphics->ColorMask(true, false, false, false);

			DrawElements(graphics);
			graphics->PopMatrix();

			// prep for other render
			graphics->ClearDepth();

			// right eye
			// reverse transform the camera
			graphics->PushMatrix();
			graphics->ReverseTransform(rightEye);
			graphics->ColorMask(false, true, true, false);

			DrawElements(graphics);
			graphics->PopMatrix();

			graphics->ColorMask(true, true, true, true);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawElements(GraphicsBase *graphics)
		{
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(*cubeOrient);
			// render the cube
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the ball
			graphics->Transform(*ballOrient);
			// render the cube
			ball->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(*jetOrient);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

		}

	};

	public ref class AnaglyphTrueTest : public GameBase
	{
	public:

		Orient3d *jetOrient;
		Orient3d *cubeOrient;
		Orient3d *cameraOrient;
		Model3d *cube;
		Model3d *jet;
		Model3d *ball;
		Orient3d *ballOrient;

		AnaglyphTrueTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			jetOrient = nullptr;
			cubeOrient = nullptr;
			cameraOrient = nullptr;
			ball = nullptr;
			ballOrient = nullptr;
		}

		virtual ~AnaglyphTrueTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			jetOrient = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient = new Orient3d();
			ballOrient = new Orient3d();
			jetOrient->LoadIdentity();
			cubeOrient->LoadIdentity();
			cameraOrient->LoadIdentity();
			ballOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);
			// move the jet forward and over
			jetOrient->p = jetOrient->p + jetOrient->f.ScalarMult(7.0f) + jetOrient->l.ScalarMult(-2.5f) + jetOrient->u.ScalarMult(2.0f);
			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(7.0f) + cubeOrient->l.ScalarMult(2.5f) + cubeOrient->u.ScalarMult(2.0f);
			ballOrient->p = ballOrient->p + ballOrient->f.ScalarMult(7.0f) + ballOrient->l.ScalarMult(2.5f) - ballOrient->u.ScalarMult(2.0f);

			jetOrient->Rotate(jetOrient->u, 180.0f);
			cubeOrient->Rotate(cubeOrient->u, 180.0f);
			ballOrient->Rotate(ballOrient->u, 180.0f);

			cube = new Model3d();
			cube->MakeCube();
			// give it a texture, make front face white to make it pure
			cube->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));
			cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			cube->GetSurface(0)->SetVertexTexCoords(1, 0.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(3, 1.0f, 1.0f);
			cube->GetColor(0)->Set(255, 255, 255);
			cube->GetColor(1)->Set(255, 255, 255);
			cube->GetColor(2)->Set(255, 255, 255);
			cube->GetColor(3)->Set(255, 255, 255);

			jet = new Model3d();
			jet->MakeJet();

			// cheat and make it look like it did before it was fixed
			jet->GetSurface(2)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(2, -1);
			jet->GetSurface(5)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(8)->SetVertexColorOverrideIndex(0, -1);

			GameColor base(51, 51, 153);
			// sort of a cool sheen given off by making the cockpit 2 colors
			GameColor cockpitColor1(128, 128, 255);
			GameColor cockpitColor2(0, 255, 255);

			jet->GetColor(0)->Set(base.Modulate(5.0f / 6.0f));
			jet->GetColor(1)->Set(base.Modulate(2.0f / 3.0f));
			jet->GetColor(2)->Set(base.Modulate(1.0f / 3.0f));
			jet->GetColor(3)->Set(cockpitColor1);
			jet->GetColor(4)->Set(cockpitColor2);

			ball = new Model3d();
			ball->MakeSphere();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
			if (ballOrient != nullptr)
			{
				delete ballOrient;
				ballOrient = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				jetOrient->Rotate(jetOrient->f, float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(cubeOrient->f, float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(ballOrient->f, -float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				jetOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				jetOrient->Rotate(jetOrient->l, -float(mouse.offsetY) / 5.0f);
				cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
				ballOrient->Rotate(ballOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = jetOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(115, 115, 115)); // good background color for anaglyph

			// convergence establish world distance that is even with the screen
			// higher eye distance makes poking out of screen more prominent - distance objects show more 'depth'
			//StereoScopicCamera stereoscopicCamera(10.0f, 0.41666f);  // convergence 100 feet into world (dead middle of the models), eye width for pronounced effect
			StereoscopicCamera stereoscopicCamera(10.0f, 0.81666f);  // convergence 100 feet into world (dead middle of the models), eye width for pronounced effect
			//StereoScopicCamera stereoscopicCamera(3.0f, 0.041666f);  // convergence 100 feet into world (dead middle of the models), eye width for pronounced effect

			// left eye
			graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, 0.1, 1000.0, stereoscopicCamera);
			graphics->DefaultTransformStereoscopicLeft(stereoscopicCamera);

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->ColorMask(true, false, false, false);

			DrawElements(graphics);

			// prep for other render
			graphics->ClearDepth();

			// right eye
			graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, 0.1, 1000.0, stereoscopicCamera);
			graphics->DefaultTransformStereoscopicRight(stereoscopicCamera);

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->ColorMask(false, true, true, false);

			DrawElements(graphics);

			// all done
			graphics->ColorMask(true, true, true, true);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawElements(GraphicsBase *graphics)
		{
			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(*cubeOrient);
			// render the cube
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the ball
			graphics->Transform(*ballOrient);
			// render the cube
			ball->Render(*graphics);
			graphics->PopMatrix();

			//Orient3d temp = *jetOrient;
			//jetOrient->p = jetOrient->p + Vector3d(2.0f, -1.5f, -7.0f);
			//for (int i = 0; i < 10; i++)
			//{
				graphics->PushMatrix();
				// forward transform the jet
				//graphics->RenderTestTriangle();
				graphics->Transform(*jetOrient);
				// render the jet
				jet->Render(*graphics);
				graphics->PopMatrix();

				//jetOrient->p = jetOrient->p + Vector3d(0.5f, -0.5f, 3.5f);
			//}
			//*jetOrient = temp;

		}

	};

	public ref class AnaglyphExperimentTest : public GameBase
	{
	public:

		Orient3d *jetOrient;
		Orient3d *cameraOrient;
		Model3d *jet;
		StereoscopicCamera *stereoCamera;
		GameTimer *timer;

		AnaglyphExperimentTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			jetOrient = nullptr;
			cameraOrient = nullptr;
			stereoCamera = nullptr;
			jet = nullptr;
			timer = nullptr;
		}

		virtual ~AnaglyphExperimentTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			jetOrient = new Orient3d();
			cameraOrient = new Orient3d();
			jetOrient->LoadIdentity();
			cameraOrient->LoadIdentity();

			// move the jet forward and over
			jetOrient->p = jetOrient->p + jetOrient->f.ScalarMult(5.0f);

			jetOrient->Rotate(jetOrient->u, 180.0f);

			jet = new Model3d();
			jet->MakeJet();

			// cheat and make it look like it did before it was fixed
			jet->GetSurface(2)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(2, -1);
			jet->GetSurface(5)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(8)->SetVertexColorOverrideIndex(0, -1);

			GameColor base(51, 51, 153);
			// sort of a cool sheen given off by making the cockpit 2 colors
			GameColor cockpitColor1(128, 128, 255);
			GameColor cockpitColor2(0, 255, 255);

			jet->GetColor(0)->Set(base.Modulate(5.0f / 6.0f));
			jet->GetColor(1)->Set(base.Modulate(2.0f / 3.0f));
			jet->GetColor(2)->Set(base.Modulate(1.0f / 3.0f));
			jet->GetColor(3)->Set(cockpitColor1);
			jet->GetColor(4)->Set(cockpitColor2);

			stereoCamera = new StereoscopicCamera(5.0f, 0.156f);

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (stereoCamera != nullptr)
			{
				delete stereoCamera;
				stereoCamera = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			timer->Poll();
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				jetOrient->Rotate(jetOrient->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				jetOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				jetOrient->Rotate(jetOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			float eyeSpeed = 0.000025f;
			float convergenceSpeed = 0.5f / 1000.0f;
			if (keyboardKeys.GetKey('A')->IsPressed() == true)
			{
				stereoCamera->eyeSeparationLength -= (eyeSpeed * timer->GetElapsedTimeMSFloat());
			}
			if (keyboardKeys.GetKey('D')->IsPressed() == true)
			{
				stereoCamera->eyeSeparationLength += (eyeSpeed * timer->GetElapsedTimeMSFloat());
			}
			if (keyboardKeys.GetKey('W')->IsPressed() == true)
			{
				stereoCamera->convergenceDistance += (convergenceSpeed * timer->GetElapsedTimeMSFloat());
			}
			if (keyboardKeys.GetKey('S')->IsPressed() == true)
			{
				stereoCamera->convergenceDistance -= (convergenceSpeed * timer->GetElapsedTimeMSFloat());
			}

			timer->ResetElapsedTime();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(115, 115, 115)); // good background color for anaglyph

			// left eye
			graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, 0.1, 1000.0, *stereoCamera);
			graphics->DefaultTransformStereoscopicLeft(*stereoCamera);

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->ColorMask(true, false, false, false);

			DrawElements(graphics);

			// prep for other render
			graphics->ClearDepth();

			// right eye
			graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, 0.1, 1000.0, *stereoCamera);
			graphics->DefaultTransformStereoscopicRight(*stereoCamera);

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);
			graphics->ColorMask(false, true, true, false);

			DrawElements(graphics);

			// all done
			graphics->ColorMask(true, true, true, true);

			graphics->Set2dWindowProjection();
			graphics->RenderFont(String::Format("Eye Width: {0}", stereoCamera->eyeSeparationLength), GameContext::FontRegistry.GetFont("Info"), 10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::FontRegistry.GetFont("Info")->GetHeight() * 2, GameColor(255, 255, 255));
			graphics->RenderFont(String::Format("Convergence Depth: {0}", stereoCamera->convergenceDistance), GameContext::FontRegistry.GetFont("Info"), 10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::FontRegistry.GetFont("Info")->GetHeight() * 1, GameColor(255, 255, 255));

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawElements(GraphicsBase *graphics)
		{
			//Orient3d temp = *jetOrient;
			//jetOrient->p = jetOrient->p + Vector3d(2.0f, -1.5f, -7.0f);
			//for (int i = 0; i < 10; i++)
			//{
			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(*jetOrient);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

			Orient3d temp;

			// Render another VERY far away
			temp = *jetOrient;
			temp.p = temp.p + Vector3d(30.0, 0.0f, 90.0f);
			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(temp);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

			// Render another off to teh side
			temp = *jetOrient;
			temp.p = temp.p + Vector3d(-4.0, -1.0f, 4.0f);
			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(temp);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

			//jetOrient->p = jetOrient->p + Vector3d(0.5f, -0.5f, 3.5f);
			//}
			//*jetOrient = temp;

		}

	};
	public ref class DungeonHallTest : public GameBase
	{
	public:

		Orient3d *playerOrient;
		Vector3d *playerFallSpeed;
		Vector3d *playerProposedWalkSpeed;
		Vector3d *playerWalkSpeed;
		bool playerFeetOnGround;
		float playerAcceleration;
		Orient3d *playerLightOrient;
		bool playerLightAttached;

		Orient3d *cameraOrient;
		GameTimer *timer;
		float pitchAngleDegrees;
		float rotateAngleDegrees;
		bool doAnaglyph;

		Model3d *cube;
		Orient3d *cubeOrient;
		Model3d *ball;
		Orient3d *ballOrients;
		int ballQty;
		int currentBallIndex;

		ModelVertex *dungeonVertices;
		ModelSurface *dungeonSurfaces;
		int dungeonSurfaceQty;
		int dungeonVertexQty;

		GraphicsNativeObjectContainer *wallNativeRef;
		GraphicsNativeObjectContainer *cubeNativeRef;
		GraphicsNativeObjectContainer *ballNativeRef;
		GraphicsNativeObjectContainer *triguyNativeRef;
		GraphicsNativeObjectContainer *simpleJointedNativeRef;

		JointedModel3d *triguy;
		Orient3d *triguyOrient;
		JointedModelAnimationTracker *triguyAnimationTracker;
		Orient3d *triguyJointOrients;

		Vector3d *ballVelocity;
		float ballRadius;
		float *ballSpinDegreesPerMSf;
		Vector3d *ballSpinAxis;

		JointedModel3d *simpleJointedModel;
		Orient3d *simpleJointedOrient;
		Orient3d *simpleJointedOrients;

		Orient3d *sirenOrient;

		Model3d *blackPanel;
		Orient3d *blackPanelOrient;
		GraphicsNativeObjectContainer *blackPanelNativeRef;

		int lightQty;
		bool *lightOn;

		bool slowMotion;
		bool absorbBallPhysics;

		float ballThrowPower;
		float ballThrowPowerMax;
		float ballThrowPowerIncreaseRate;

		bool debugShadowMaps;
		bool useShadowMaps;
		bool useDirectional; // player light only

		bool showInstructions;

		// for simplicity to prevent calling new
		Vector3d *sceneWorldCenter;
		float sceneWorldRadius;

		ColliderSet *colliderSet;

		GraphicsFrameBufferContainer *frameBuffers;
		GraphicsFrameBufferContainer *frameBuffersCubeMap;
		GraphicsFrameBufferContainer *frameBuffersHires;

		DungeonHallTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			playerOrient = nullptr;
			playerFallSpeed = nullptr;
			playerFeetOnGround = true;
			playerWalkSpeed = nullptr;
			playerProposedWalkSpeed = nullptr;
			playerLightOrient = nullptr;
			cameraOrient = nullptr;
			timer = nullptr;
			doAnaglyph = false;

			cube = nullptr;
			cubeOrient = nullptr;
			ball = nullptr;
			ballOrients = nullptr;
			ballVelocity = nullptr;
			ballSpinAxis = nullptr;
			ballSpinDegreesPerMSf = nullptr;
			currentBallIndex = 0;

			dungeonVertices = nullptr;
			dungeonSurfaces = nullptr;

			wallNativeRef = nullptr;
			cubeNativeRef = nullptr;
			ballNativeRef = nullptr;
			triguyNativeRef = nullptr;
			simpleJointedNativeRef = nullptr;

			triguy = nullptr;
			triguyOrient = nullptr;
			triguyAnimationTracker = nullptr;
			triguyJointOrients = nullptr;

			sirenOrient = nullptr;

			blackPanel = nullptr;
			blackPanelOrient = nullptr;
			blackPanelNativeRef = nullptr;

			simpleJointedModel = nullptr;
			simpleJointedOrient = nullptr;
			simpleJointedOrients = nullptr;

			lightQty = 0;
			lightOn = nullptr;

			slowMotion = false;
			absorbBallPhysics = false;

			colliderSet = nullptr;

			frameBuffers = nullptr;
			frameBuffersCubeMap = nullptr;
			frameBuffersHires = nullptr;

			debugShadowMaps = false;
			useShadowMaps = true;
			useDirectional = false;

			showInstructions = true;
		}

		virtual ~DungeonHallTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GraphicsShaderAppSettings shaderAppSettings;
			shaderAppSettings.escalateLightAspectCheck = false; // just proving that stepping up to a pillar really slows things down with this = false
			//GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->SetShaderAppSettings(shaderAppSettings);
			//GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->SetVSyncEnabled(false);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			GameContext::Instance->FileRegistry.RegisterFileResource("brickwork-texture.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brickwork-texture.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brickwork_normal-map.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("BrickBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brickwork_normal-map.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick2_normal_map.png");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2_normal_map.png"));
			//GameContext::Instance->FileRegistry.RegisterFileResource("flat_normal.png");
			//GameContext::Instance->TextureRegistry.RegisterTexture("Brick2BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flat_normal.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick3.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick3", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick3.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("brick3_norm.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick3BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick3_norm.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Hellraiser1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("cf001_diffuse.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Hellraiser1BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("cf001-01_normal.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Hellraiser1SpecularMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("cf001_specular.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("TrFace1.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("TriGuyFace1", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("TrFace1.bmp"));
			GameContext::Instance->TextureRegistry.RegisterTexture("TriGuyRedEyes", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, GameContext::Instance->FileRegistry.RegisterFileResource("TriGuyRedEyes.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp");
			GameContext::Instance->TextureRegistry.RegisterTexture("Reticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"));
			GameContext::Instance->FileRegistry.RegisterFileResource("LeftReticle.png");
			GameContext::Instance->TextureRegistry.RegisterTexture("LeftReticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("LeftReticle.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("RightReticle.png");
			GameContext::Instance->TextureRegistry.RegisterTexture("RightReticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("RightReticle.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("earth.jpg");
			GameContext::Instance->TextureRegistry.RegisterTexture("Earth", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth.jpg"));
			GameContext::Instance->FileRegistry.RegisterFileResource("earth_normal.png");
			GameContext::Instance->TextureRegistry.RegisterTexture("EarthBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth_normal.png"));
			GameContext::Instance->FileRegistry.RegisterFileResource("earth_specular.png");
			GameContext::Instance->TextureRegistry.RegisterTexture("EarthSpecularMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth_specular.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("EarthCityLights", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("earth_lights_lrg.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("EarthClouds", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::WhiteColorAlphaRed, GameContext::Instance->FileRegistry.RegisterFileResource("3b-over.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("EarthCloudsSpecular", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("3b-over_specmap.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("TileDirt", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("tiledirt.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("TileDirtBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("tiledirt_normal.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Stonework", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Medieval_Stonework.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("StoneworkBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Medieval_Stonework_normal.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Spotlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flashlight2.jpg"));
			//GameContext::Instance->TextureRegistry.RegisterTexture("Spotlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("TrFace1.bmp"));

			//GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			ballRadius = 0.1f;
			float ballScale = ballRadius;
			float cubescale = 0.05f;
			float triguyScale = 0.12f;
			//float simpleScale = 0.10f;

			cube = new Model3d();
			cube->MakeCube();
			cube->GetColor(0)->Set(255, 255, 255);
			cube->GetColor(1)->Set(255, 255, 255);
			cube->GetColor(2)->Set(255, 255, 255);
			cube->GetColor(3)->Set(255, 255, 255);
			cube->GetColor(4)->Set(255, 255, 255);
			cube->GetColor(5)->Set(255, 255, 255);
			cube->GetColor(6)->Set(255, 255, 255);
			cube->GetColor(7)->Set(255, 255, 255);
			cube->GetSurface(0)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
			cube->GetSurface(1)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
			cube->GetSurface(2)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
			cube->GetSurface(3)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
			cube->GetSurface(4)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
			cube->GetSurface(5)->SetTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1"));
			cube->GetSurface(0)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
			cube->GetSurface(1)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
			cube->GetSurface(2)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
			cube->GetSurface(3)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
			cube->GetSurface(4)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
			cube->GetSurface(5)->SetSpecularMapTexture0(GameContext::TextureRegistry.GetTexture("Hellraiser1SpecularMap"));
			cube->GetSurface(0)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
			cube->GetSurface(1)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
			cube->GetSurface(2)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
			cube->GetSurface(3)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
			cube->GetSurface(4)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
			cube->GetSurface(5)->SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Hellraiser1BumpMap"));
			cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
			cube->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);
			cube->GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f);
			cube->GetSurface(1)->SetVertexTexCoords(1, 1.0f, 0.0f);
			cube->GetSurface(1)->SetVertexTexCoords(2, 1.0f, 1.0f);
			cube->GetSurface(1)->SetVertexTexCoords(3, 0.0f, 1.0f);
			cube->GetSurface(2)->SetVertexTexCoords(0, 0.0f, 0.0f);
			cube->GetSurface(2)->SetVertexTexCoords(1, 1.0f, 0.0f);
			cube->GetSurface(2)->SetVertexTexCoords(2, 1.0f, 1.0f);
			cube->GetSurface(2)->SetVertexTexCoords(3, 0.0f, 1.0f);
			cube->GetSurface(3)->SetVertexTexCoords(0, 0.0f, 0.0f);
			cube->GetSurface(3)->SetVertexTexCoords(1, 1.0f, 0.0f);
			cube->GetSurface(3)->SetVertexTexCoords(2, 1.0f, 1.0f);
			cube->GetSurface(3)->SetVertexTexCoords(3, 0.0f, 1.0f);
			cube->GetSurface(4)->SetVertexTexCoords(0, 0.0f, 0.0f);
			cube->GetSurface(4)->SetVertexTexCoords(1, 1.0f, 0.0f);
			cube->GetSurface(4)->SetVertexTexCoords(2, 1.0f, 1.0f);
			cube->GetSurface(4)->SetVertexTexCoords(3, 0.0f, 1.0f);
			cube->GetSurface(5)->SetVertexTexCoords(0, 0.0f, 0.0f);
			cube->GetSurface(5)->SetVertexTexCoords(1, 1.0f, 0.0f);
			cube->GetSurface(5)->SetVertexTexCoords(2, 1.0f, 1.0f);
			cube->GetSurface(5)->SetVertexTexCoords(3, 0.0f, 1.0f);
			// now calculate all the normals again now that we have tex coords
			//cube->ReScale(cubescale);
			cube->CalculateNormals();

			cubeOrient = new Orient3d();
			cubeOrient->LoadIdentity();
			cubeOrient->p = Vector3d(0.2f, 0.7f, 2.0f);
			// give it an eerie tilt
			cubeOrient->Rotate(cubeOrient->l, MathUtilities::RadiansToDegrees(float(asin(1.0f/sqrt(3.0f)))));
			cubeOrient->Rotate(cubeOrient->f, 45.0f);
			// huh.  weird.  why doesn't this put the corner straight up?
			Vector3d corner = (cubeOrient->f - cubeOrient->l + cubeOrient->u);

			ball = new Model3d();
			ball->MakeSphere(GameContext::TextureRegistry.GetTexture("Earth"), GameContext::TextureRegistry.GetTexture("EarthBumpMap"), GameContext::TextureRegistry.GetTexture("EarthSpecularMap"));
			//ball->ReScale(ballScale);
			ball->SkinTexture1(GameContext::TextureRegistry.GetTexture("EarthCityLights"), GraphicsShaderCompositionTextureBlendOption::BlendInverseSqrtLight, GraphicsShaderCompositionTextureLightOption::Emittive);
			ball->SkinTexture2(GameContext::TextureRegistry.GetTexture("EarthClouds"), GraphicsShaderCompositionTextureBlendOption::DecalSaturateAlpha, GraphicsShaderCompositionTextureLightOption::Diffuse, GameContext::TextureRegistry.GetTexture("EarthCloudsSpecular"), GraphicsShaderCompositionSpecularBlendOption::Modulate);
			for (int c = 0; c < ball->GetColorQty(); c++)
			{
				ball->GetColor(c)->Set(GameColor(255, 255, 255));
			}
			ballOrients = new Orient3d[7];
			ballVelocity = new Vector3d[7];
			ballSpinAxis = new Vector3d[7];
			ballSpinDegreesPerMSf = new float[7];
			for (int i = 0; i < 7; i++)
			{
				ballOrients[i].LoadIdentity();
				ballOrients[i].p = Vector3d(float(i)/2.0f, 0.3f, 4.0f);
				ballVelocity[i].Set(0, 0, 0.0001f);
				ballSpinDegreesPerMSf[i] = 0;
			}

			playerOrient = new Orient3d();
			cameraOrient = new Orient3d();
			playerOrient->LoadIdentity();
			cameraOrient->LoadIdentity();
			playerOrient->p = Vector3d(0.0f, 0.1f, 0.5f); // move 5' forward, place 1' up
			playerFallSpeed = new Vector3d();
			playerFallSpeed->Set(0, 0, 0);
			playerWalkSpeed = new Vector3d();
			playerWalkSpeed->Set(0, 0, 0);
			playerProposedWalkSpeed = new Vector3d();
			playerProposedWalkSpeed->Set(0, 0, 0);
			playerAcceleration = 0.0000075f;

			playerLightOrient = new Orient3d();
			playerLightOrient->LoadIdentity();
			playerLightAttached = true;

			rotateAngleDegrees = 0.0f;
			pitchAngleDegrees = 0.0f;

			timer = new GameTimer();

			// set up dungeon
			bool pitHallway = false;
			if (pitHallway == true)
			{
				// make a hallway with a pit
				dungeonVertexQty = 26;
				dungeonVertices = new ModelVertex[dungeonVertexQty];
				dungeonVertices[0].colorIndex = 0;
				dungeonVertices[1].colorIndex = 0;
				dungeonVertices[2].colorIndex = 0;
				dungeonVertices[3].colorIndex = 0;
				dungeonVertices[4].colorIndex = 0;
				dungeonVertices[5].colorIndex = 0;
				dungeonVertices[6].colorIndex = 0;
				dungeonVertices[7].colorIndex = 0;
				dungeonVertices[8].colorIndex = 0;
				dungeonVertices[9].colorIndex = 0;
				dungeonVertices[10].colorIndex = 0;
				dungeonVertices[11].colorIndex = 0;
				dungeonVertices[12].colorIndex = 0;
				dungeonVertices[13].colorIndex = 0;
				dungeonVertices[14].colorIndex = 0;
				dungeonVertices[15].colorIndex = 0;
				dungeonVertices[16].colorIndex = 0;
				dungeonVertices[17].colorIndex = 0;
				dungeonVertices[18].colorIndex = 0;
				dungeonVertices[19].colorIndex = 0;
				dungeonVertices[20].colorIndex = 0;
				dungeonVertices[21].colorIndex = 0;
				dungeonVertices[22].colorIndex = 0;
				dungeonVertices[23].colorIndex = 0;
				dungeonVertices[24].colorIndex = 0;
				dungeonVertices[25].colorIndex = 0;
				dungeonVertices[0].vertex = Vector3d(0.5f, 0.0f, -10.0f); // 100' back
				dungeonVertices[1].vertex = Vector3d(-0.5f, 0.0f, -10.0f);
				dungeonVertices[2].vertex = Vector3d(0.5f, 1.0f, -10.0f);
				dungeonVertices[3].vertex = Vector3d(-0.5f, 1.0f, -10.0f);
				dungeonVertices[4].vertex = Vector3d(0.5f, 0.0f, 12.0f); // 130' hallway, last 10' is a pit
				dungeonVertices[5].vertex = Vector3d(-0.5f, 0.0f, 12.0f);
				dungeonVertices[6].vertex = Vector3d(0.5f, -20.0f, 12.0f); // 200' pit
				dungeonVertices[7].vertex = Vector3d(-0.5f, -20.0f, 12.0f);
				dungeonVertices[8].vertex = Vector3d(0.5f, -20.0f, 13.0f);
				dungeonVertices[9].vertex = Vector3d(-0.5f, -20.0f, 13.0f);
				dungeonVertices[10].vertex = Vector3d(0.5f, -0.3f, 13.0f);
				dungeonVertices[11].vertex = Vector3d(-0.5f, -0.3f, 13.0f);
				dungeonVertices[12].vertex = Vector3d(0.5f, 1.0f, 13.0f);
				dungeonVertices[13].vertex = Vector3d(-0.5f, 1.0f, 13.0f);
				dungeonVertices[14].vertex = Vector3d(0.5f, -0.3f, 14.0f);
				dungeonVertices[15].vertex = Vector3d(-0.5f, -0.3f, 14.0f);
				dungeonVertices[16].vertex = Vector3d(0.5f, 1.0f, 14.0f);
				dungeonVertices[17].vertex = Vector3d(-0.5f, 1.0f, 14.0f);
				// post - provide a little space for player to get through
				dungeonVertices[18].vertex = Vector3d(-0.1f, 1.0f, -2.0f);
				dungeonVertices[19].vertex = Vector3d(0.1f, 1.0f, -2.0f);
				dungeonVertices[20].vertex = Vector3d(-0.1f, 0.0f, -2.0f);
				dungeonVertices[21].vertex = Vector3d(0.1f, 0.0f, -2.0f);
				dungeonVertices[22].vertex = Vector3d(-0.1f, 1.0f, -2.4f);
				dungeonVertices[23].vertex = Vector3d(0.1f, 1.0f, -2.4f);
				dungeonVertices[24].vertex = Vector3d(-0.1f, 0.0f, -2.4f);
				dungeonVertices[25].vertex = Vector3d(0.1f, 0.0f, -2.4f);

				dungeonSurfaceQty = 21;
				dungeonSurfaces = new ModelSurface[dungeonSurfaceQty]; // 6 walls facing inward
				// end 1
				dungeonSurfaces[0].Initialize(4, true);
				dungeonSurfaces[0].SetVertexIndex(0, 0);
				dungeonSurfaces[0].SetVertexIndex(1, 1);
				dungeonSurfaces[0].SetVertexIndex(2, 3);
				dungeonSurfaces[0].SetVertexIndex(3, 2);
				dungeonSurfaces[0].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[0].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[0].SetVertexTexCoords(0, 1.0f, 1.0f);
				dungeonSurfaces[0].SetVertexTexCoords(1, 0.0f, 1.0f);
				dungeonSurfaces[0].SetVertexTexCoords(2, 0.0f, 0.0f);
				dungeonSurfaces[0].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[0].CalculateNormals(dungeonVertices);
				// floor
				dungeonSurfaces[1].Initialize(4, true);
				dungeonSurfaces[1].SetVertexIndex(0, 0);
				dungeonSurfaces[1].SetVertexIndex(1, 4);
				dungeonSurfaces[1].SetVertexIndex(2, 5);
				dungeonSurfaces[1].SetVertexIndex(3, 1);
				dungeonSurfaces[1].SetTexture0(GameContext::TextureRegistry.GetTexture("TileDirt"));
				dungeonSurfaces[1].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("TileDirtBumpMap"));
				dungeonSurfaces[1].SetVertexTexCoords(0, 0.0f, -10.0f);
				dungeonSurfaces[1].SetVertexTexCoords(1, 0.0f, 12.0f);
				dungeonSurfaces[1].SetVertexTexCoords(2, 1.0f, 12.0f);
				dungeonSurfaces[1].SetVertexTexCoords(3, 1.0f, -10.0f);
				dungeonSurfaces[1].CalculateNormals(dungeonVertices);
				// left side
				dungeonSurfaces[4].Initialize(4, true);
				dungeonSurfaces[4].SetVertexIndex(0, 2);
				dungeonSurfaces[4].SetVertexIndex(1, 12);
				dungeonSurfaces[4].SetVertexIndex(2, 4);
				dungeonSurfaces[4].SetVertexIndex(3, 0);
				dungeonSurfaces[4].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[4].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[4].SetVertexTexCoords(0, -10.0f, 1.0f);
				dungeonSurfaces[4].SetVertexTexCoords(1, 13.0f, 1.0f);
				dungeonSurfaces[4].SetVertexTexCoords(2, 12.0f, 0.0f);
				dungeonSurfaces[4].SetVertexTexCoords(3, -10.0f, 0.0f);
				dungeonSurfaces[4].CalculateNormals(dungeonVertices);
				// left side 2 - playing it safe - GL doesn't like 5-vertex polygons
				dungeonSurfaces[5].Initialize(3, true);
				dungeonSurfaces[5].SetVertexIndex(0, 12);
				dungeonSurfaces[5].SetVertexIndex(1, 10);
				dungeonSurfaces[5].SetVertexIndex(2, 4);
				dungeonSurfaces[5].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[5].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[5].SetVertexTexCoords(0, 13.0f, 1.0f);
				dungeonSurfaces[5].SetVertexTexCoords(1, 13.0f, dungeonVertices[10].vertex.y);
				dungeonSurfaces[5].SetVertexTexCoords(2, 12.0f, 0.0f);
				dungeonSurfaces[5].CalculateNormals(dungeonVertices);
				// right side
				dungeonSurfaces[6].Initialize(4, true);
				dungeonSurfaces[6].SetVertexIndex(0, 13);
				dungeonSurfaces[6].SetVertexIndex(1, 3);
				dungeonSurfaces[6].SetVertexIndex(2, 1);
				dungeonSurfaces[6].SetVertexIndex(3, 5);
				dungeonSurfaces[6].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[6].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[6].SetVertexTexCoords(0, 0.0f, 1.0f);
				dungeonSurfaces[6].SetVertexTexCoords(1, 23.0f, 1.0f);
				dungeonSurfaces[6].SetVertexTexCoords(2, 23.0f, 0.0f);
				dungeonSurfaces[6].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[6].CalculateNormals(dungeonVertices);
				// right side 2 - GL doesnt' like my 5-vertex polygon...
				dungeonSurfaces[7].Initialize(3, true);
				dungeonSurfaces[7].SetVertexIndex(0, 13);
				dungeonSurfaces[7].SetVertexIndex(1, 5);
				dungeonSurfaces[7].SetVertexIndex(2, 11);
				dungeonSurfaces[7].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[7].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[7].SetVertexTexCoords(0, 0.0f, 1.0f);
				dungeonSurfaces[7].SetVertexTexCoords(1, 1.0f, 0.0f);
				dungeonSurfaces[7].SetVertexTexCoords(2, 0.0f, dungeonVertices[11].vertex.y);
				dungeonSurfaces[7].CalculateNormals(dungeonVertices);
				// end above pit
				//dungeonSurfaces[2].Initialize(4, true);
				//dungeonSurfaces[2].SetVertexIndex(0, 10);
				//dungeonSurfaces[2].SetVertexIndex(1, 12);
				//dungeonSurfaces[2].SetVertexIndex(2, 13);
				//dungeonSurfaces[2].SetVertexIndex(3, 11);
				//dungeonSurfaces[2].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				//dungeonSurfaces[2].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				//dungeonSurfaces[2].SetVertexTexCoords(0, 0.0f, 6.0f);
				//dungeonSurfaces[2].SetVertexTexCoords(1, 0.0f, 7.0f);
				//dungeonSurfaces[2].SetVertexTexCoords(2, 1.0f, 7.0f);
				//dungeonSurfaces[2].SetVertexTexCoords(3, 1.0f, 6.0f);
				//dungeonSurfaces[2].CalculateNormals(dungeonVertices);
				// ceiling
				dungeonSurfaces[3].Initialize(4, true);
				dungeonSurfaces[3].SetVertexIndex(0, 2);
				dungeonSurfaces[3].SetVertexIndex(1, 3);
				dungeonSurfaces[3].SetVertexIndex(2, 13);
				dungeonSurfaces[3].SetVertexIndex(3, 12);
				dungeonSurfaces[3].SetTexture0(GameContext::TextureRegistry.GetTexture("Stonework"));
				dungeonSurfaces[3].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("StoneworkBumpMap"));
				dungeonSurfaces[3].SetVertexTexCoords(0, 1.0f, -10.0f);
				dungeonSurfaces[3].SetVertexTexCoords(1, 0.0f, -10.0f);
				dungeonSurfaces[3].SetVertexTexCoords(2, 0.0f, 13.0f);
				dungeonSurfaces[3].SetVertexTexCoords(3, 1.0f, 13.0f);
				dungeonSurfaces[3].CalculateNormals(dungeonVertices);

				// pit!!
				// back wall
				dungeonSurfaces[9].Initialize(4, true);
				dungeonSurfaces[9].SetVertexIndex(0, 8);
				dungeonSurfaces[9].SetVertexIndex(1, 10);
				dungeonSurfaces[9].SetVertexIndex(2, 11);
				dungeonSurfaces[9].SetVertexIndex(3, 9);
				dungeonSurfaces[9].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[9].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[9].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[9].SetVertexTexCoords(1, 0.0f, 20.0f + dungeonVertices[10].vertex.y);
				dungeonSurfaces[9].SetVertexTexCoords(2, 1.0f, 20.0f + dungeonVertices[11].vertex.y);
				dungeonSurfaces[9].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[9].CalculateNormals(dungeonVertices);

				dungeonSurfaces[10].Initialize(4, true);
				dungeonSurfaces[10].SetVertexIndex(0, 9);
				dungeonSurfaces[10].SetVertexIndex(1, 11);
				dungeonSurfaces[10].SetVertexIndex(2, 5);
				dungeonSurfaces[10].SetVertexIndex(3, 7);
				dungeonSurfaces[10].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[10].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[10].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[10].SetVertexTexCoords(1, 0.0f, 20.0f + dungeonVertices[11].vertex.y);
				dungeonSurfaces[10].SetVertexTexCoords(2, 1.0f, 20.0f);
				dungeonSurfaces[10].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[10].CalculateNormals(dungeonVertices);

				dungeonSurfaces[11].Initialize(4, true);
				dungeonSurfaces[11].SetVertexIndex(0, 7);
				dungeonSurfaces[11].SetVertexIndex(1, 5);
				dungeonSurfaces[11].SetVertexIndex(2, 4);
				dungeonSurfaces[11].SetVertexIndex(3, 6);
				dungeonSurfaces[11].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[11].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[11].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[11].SetVertexTexCoords(1, 0.0f, 20.0f);
				dungeonSurfaces[11].SetVertexTexCoords(2, 1.0f, 20.0f);
				dungeonSurfaces[11].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[11].CalculateNormals(dungeonVertices);

				dungeonSurfaces[2].Initialize(4, true);
				dungeonSurfaces[2].SetVertexIndex(0, 6);
				dungeonSurfaces[2].SetVertexIndex(1, 4);
				dungeonSurfaces[2].SetVertexIndex(2, 10);
				dungeonSurfaces[2].SetVertexIndex(3, 8);
				dungeonSurfaces[2].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[2].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[2].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[2].SetVertexTexCoords(1, 0.0f, 20.0f);
				dungeonSurfaces[2].SetVertexTexCoords(2, 1.0f, 20.0f + dungeonVertices[10].vertex.y);
				dungeonSurfaces[2].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[2].CalculateNormals(dungeonVertices);

				dungeonSurfaces[8].Initialize(4, true);
				dungeonSurfaces[8].SetVertexIndex(0, 8);
				dungeonSurfaces[8].SetVertexIndex(1, 9);
				dungeonSurfaces[8].SetVertexIndex(2, 7);
				dungeonSurfaces[8].SetVertexIndex(3, 6);
				dungeonSurfaces[8].SetTexture0(GameContext::TextureRegistry.GetTexture("TileDirt"));
				dungeonSurfaces[8].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("TileDirtBumpMap"));
				dungeonSurfaces[8].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[8].SetVertexTexCoords(1, 0.0f, 1.0f);
				dungeonSurfaces[8].SetVertexTexCoords(2, 1.0f, 1.0f);
				dungeonSurfaces[8].SetVertexTexCoords(3, 1.0f, 0.0f);
				dungeonSurfaces[8].CalculateNormals(dungeonVertices);

				// ledge above pit
				dungeonSurfaces[12].Initialize(4, true);
				dungeonSurfaces[12].SetVertexIndex(0, 11);
				dungeonSurfaces[12].SetVertexIndex(1, 15);
				dungeonSurfaces[12].SetVertexIndex(2, 17);
				dungeonSurfaces[12].SetVertexIndex(3, 13);
				dungeonSurfaces[12].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[12].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[12].SetVertexTexCoords(0, 1.0f, dungeonVertices[11].vertex.y);
				dungeonSurfaces[12].SetVertexTexCoords(1, 0.0f, dungeonVertices[15].vertex.y);
				dungeonSurfaces[12].SetVertexTexCoords(2, 0.0f, 1.0f);
				dungeonSurfaces[12].SetVertexTexCoords(3, 1.0f, 1.0f);
				dungeonSurfaces[12].CalculateNormals(dungeonVertices);

				dungeonSurfaces[13].Initialize(4, true);
				dungeonSurfaces[13].SetVertexIndex(0, 15);
				dungeonSurfaces[13].SetVertexIndex(1, 14);
				dungeonSurfaces[13].SetVertexIndex(2, 16);
				dungeonSurfaces[13].SetVertexIndex(3, 17);
				dungeonSurfaces[13].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[13].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[13].SetVertexTexCoords(0, 1.0f, dungeonVertices[15].vertex.y);
				dungeonSurfaces[13].SetVertexTexCoords(1, 0.0f, dungeonVertices[14].vertex.y);
				dungeonSurfaces[13].SetVertexTexCoords(2, 0.0f, 1.0f);
				dungeonSurfaces[13].SetVertexTexCoords(3, 1.0f, 1.0f);
				dungeonSurfaces[13].CalculateNormals(dungeonVertices);

				dungeonSurfaces[14].Initialize(4, true);
				dungeonSurfaces[14].SetVertexIndex(0, 14);
				dungeonSurfaces[14].SetVertexIndex(1, 10);
				dungeonSurfaces[14].SetVertexIndex(2, 12);
				dungeonSurfaces[14].SetVertexIndex(3, 16);
				dungeonSurfaces[14].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[14].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[14].SetVertexTexCoords(0, 1.0f, dungeonVertices[14].vertex.y);
				dungeonSurfaces[14].SetVertexTexCoords(1, 0.0f, dungeonVertices[10].vertex.y);
				dungeonSurfaces[14].SetVertexTexCoords(2, 0.0f, 1.0f);
				dungeonSurfaces[14].SetVertexTexCoords(3, 1.0f, 1.0f);
				dungeonSurfaces[14].CalculateNormals(dungeonVertices);

				dungeonSurfaces[15].Initialize(4, true);
				dungeonSurfaces[15].SetVertexIndex(0, 13);
				dungeonSurfaces[15].SetVertexIndex(1, 17);
				dungeonSurfaces[15].SetVertexIndex(2, 16);
				dungeonSurfaces[15].SetVertexIndex(3, 12);
				dungeonSurfaces[15].SetTexture0(GameContext::TextureRegistry.GetTexture("Stonework"));
				dungeonSurfaces[15].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("StoneworkBumpMap"));
				dungeonSurfaces[15].SetVertexTexCoords(0, 1.0f, 0.0f);
				dungeonSurfaces[15].SetVertexTexCoords(1, 0.0f, 0.0f);
				dungeonSurfaces[15].SetVertexTexCoords(2, 0.0f, 1.0f);
				dungeonSurfaces[15].SetVertexTexCoords(3, 1.0f, 1.0f);
				dungeonSurfaces[15].CalculateNormals(dungeonVertices);

				dungeonSurfaces[16].Initialize(4, true);
				dungeonSurfaces[16].SetVertexIndex(0, 10);
				dungeonSurfaces[16].SetVertexIndex(1, 14);
				dungeonSurfaces[16].SetVertexIndex(2, 15);
				dungeonSurfaces[16].SetVertexIndex(3, 11);
				dungeonSurfaces[16].SetTexture0(GameContext::TextureRegistry.GetTexture("TileDirt"));
				dungeonSurfaces[16].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("TileDirtBumpMap"));
				dungeonSurfaces[16].SetVertexTexCoords(0, 1.0f, 0.0f);
				dungeonSurfaces[16].SetVertexTexCoords(1, 0.0f, 0.0f);
				dungeonSurfaces[16].SetVertexTexCoords(2, 0.0f, 1.0f);
				dungeonSurfaces[16].SetVertexTexCoords(3, 1.0f, 1.0f);
				dungeonSurfaces[16].CalculateNormals(dungeonVertices);

				// post
				// bug here - creates the black column of death that won't let player pass

				dungeonSurfaces[17].Initialize(4, true);
				dungeonSurfaces[17].SetVertexIndex(0, 18);
				dungeonSurfaces[17].SetVertexIndex(1, 19);
				dungeonSurfaces[17].SetVertexIndex(2, 21);
				dungeonSurfaces[17].SetVertexIndex(3, 20);
				dungeonSurfaces[17].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[17].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[17].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[17].SetVertexTexCoords(1, 0.2f, 0.0f);
				dungeonSurfaces[17].SetVertexTexCoords(2, 0.2f, 1.0f);
				dungeonSurfaces[17].SetVertexTexCoords(3, 0.0f, 1.0f);
				dungeonSurfaces[17].CalculateNormals(dungeonVertices);

				dungeonSurfaces[18].Initialize(4, true);
				dungeonSurfaces[18].SetVertexIndex(0, 22);
				dungeonSurfaces[18].SetVertexIndex(1, 18);
				dungeonSurfaces[18].SetVertexIndex(2, 20);
				dungeonSurfaces[18].SetVertexIndex(3, 24);
				dungeonSurfaces[18].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[18].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[18].SetVertexTexCoords(0, -0.4f, 0.0f);
				dungeonSurfaces[18].SetVertexTexCoords(1, 0.0f, 0.0f);
				dungeonSurfaces[18].SetVertexTexCoords(2, 0.0f, 1.0f);
				dungeonSurfaces[18].SetVertexTexCoords(3, -0.4f, 1.0f);
				dungeonSurfaces[18].CalculateNormals(dungeonVertices);

				dungeonSurfaces[19].Initialize(4, true);
				dungeonSurfaces[19].SetVertexIndex(0, 23);
				dungeonSurfaces[19].SetVertexIndex(1, 22);
				dungeonSurfaces[19].SetVertexIndex(2, 24);
				dungeonSurfaces[19].SetVertexIndex(3, 25);
				dungeonSurfaces[19].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[19].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[19].SetVertexTexCoords(0, -0.6f, 0.0f);
				dungeonSurfaces[19].SetVertexTexCoords(1, -0.4f, 0.0f);
				dungeonSurfaces[19].SetVertexTexCoords(2, -0.4f, 1.0f);
				dungeonSurfaces[19].SetVertexTexCoords(3, -0.6f, 1.0f);
				dungeonSurfaces[19].CalculateNormals(dungeonVertices);

				dungeonSurfaces[20].Initialize(4, true);
				dungeonSurfaces[20].SetVertexIndex(0, 19);
				dungeonSurfaces[20].SetVertexIndex(1, 23);
				dungeonSurfaces[20].SetVertexIndex(2, 25);
				dungeonSurfaces[20].SetVertexIndex(3, 21);
				dungeonSurfaces[20].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[20].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[20].SetVertexTexCoords(0, -1.0f, 0.0f);
				dungeonSurfaces[20].SetVertexTexCoords(1, -0.6f, 0.0f);
				dungeonSurfaces[20].SetVertexTexCoords(2, -0.6f, 1.0f);
				dungeonSurfaces[20].SetVertexTexCoords(3, -1.0f, 1.0f);
				dungeonSurfaces[20].CalculateNormals(dungeonVertices);

				// allow 1 ball
				ballQty = 1;
			}
			else
			{
				// make a pillar room (60x40)
				float roomWidth = 6.0f; // x
				float roomLength = 12.0f; // z
				//float roomWidth = 1.0f; // x
				//float roomLength = 12.0f; // z
				float roomHeight = 1.5f; // y
				//float roomHeight = 1.0f; // y
				float pillarSpacing = 1.0f; // 10' apart in the center
				float pillarRadius = 0.0625f; // each about 1.25 feet across, nice 5' circumference
				int pillarWidthQty = 5;
				int pillarLengthQty = 11;
				//int pillarWidthQty = 1;
				//int pillarLengthQty = 1;
				float pillarWidthStart = -2.0f;
				float pillarLengthStart = 1.0f;

				dungeonVertexQty = 8 + (pillarWidthQty * pillarLengthQty) * 8;  // 8 for room, 8 for each pillar
				dungeonVertices = new ModelVertex[dungeonVertexQty];
				for (int i = 0; i < dungeonVertexQty; i++)
					dungeonVertices[i].colorIndex = 0;
				dungeonSurfaceQty = 6 + (pillarWidthQty * pillarLengthQty) * 4; // 6 for room, 4 for each pillar
				dungeonSurfaces = new ModelSurface[dungeonSurfaceQty];

				// vertices 0-7 and surfaces 0-5 are always the room
				// 0-3 -z face, 4-7 +z face, surfaces facing inward
				dungeonVertices[0].vertex = Vector3d(roomWidth / 2.0f, 0.0f, 0.0f);
				dungeonVertices[1].vertex = Vector3d(roomWidth / 2.0f, roomHeight, 0.0f);
				dungeonVertices[2].vertex = Vector3d(-roomWidth / 2.0f, roomHeight, 0.0f);
				dungeonVertices[3].vertex = Vector3d(-roomWidth / 2.0f, 0.0f, 0.0f);
				dungeonVertices[4].vertex = Vector3d(roomWidth / 2.0f, 0.0f, roomLength);
				dungeonVertices[5].vertex = Vector3d(roomWidth / 2.0f, roomHeight, roomLength);
				dungeonVertices[6].vertex = Vector3d(-roomWidth / 2.0f, roomHeight, roomLength);
				dungeonVertices[7].vertex = Vector3d(-roomWidth / 2.0f, 0.0f, roomLength);
				// 6 surfaces
				// 0 -z
				// this arrangement renders the walls AFTER pillars to save framerate because of depth culling
				dungeonSurfaces[dungeonSurfaceQty - 6].Initialize(4, true);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexIndex(0, 3);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexIndex(1, 2);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexIndex(2, 1);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexIndex(3, 0);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[dungeonSurfaceQty - 6].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexTexCoords(1, 0.0f, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexTexCoords(2, roomWidth, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 6].SetVertexTexCoords(3, roomWidth, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 6].CalculateNormals(dungeonVertices);
				// 1 -x
				dungeonSurfaces[dungeonSurfaceQty - 5].Initialize(4, true);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexIndex(0, 7);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexIndex(1, 6);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexIndex(2, 2);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexIndex(3, 3);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[dungeonSurfaceQty - 5].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexTexCoords(1, 0.0f, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexTexCoords(2, roomLength, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 5].SetVertexTexCoords(3, roomLength, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 5].CalculateNormals(dungeonVertices);
				// 2 +z
				dungeonSurfaces[dungeonSurfaceQty - 4].Initialize(4, true);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexIndex(0, 4);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexIndex(1, 5);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexIndex(2, 6);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexIndex(3, 7);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[dungeonSurfaceQty - 4].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexTexCoords(1, 0.0f, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexTexCoords(2, roomWidth, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 4].SetVertexTexCoords(3, roomWidth, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 4].CalculateNormals(dungeonVertices);
				// 3 +x
				dungeonSurfaces[dungeonSurfaceQty - 3].Initialize(4, true);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexIndex(0, 0);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexIndex(1, 1);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexIndex(2, 5);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexIndex(3, 4);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
				dungeonSurfaces[dungeonSurfaceQty - 3].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexTexCoords(1, 0.0f, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexTexCoords(2, roomLength, roomHeight);
				dungeonSurfaces[dungeonSurfaceQty - 3].SetVertexTexCoords(3, roomLength, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 3].CalculateNormals(dungeonVertices);
				// 4 +y (ceiling)
				dungeonSurfaces[dungeonSurfaceQty - 2].Initialize(4, true);
				//dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(0, 5);
				//dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(1, 1);
				//dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(2, 2);
				//dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(3, 6);
				// hide ceiling for now
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(0, 6);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(1, 2);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(2, 1);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexIndex(3, 5);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetTexture0(GameContext::TextureRegistry.GetTexture("Stonework"));
				dungeonSurfaces[dungeonSurfaceQty - 2].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("StoneworkBumpMap"));
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexTexCoords(1, 0.0f, roomLength);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexTexCoords(2, roomWidth, roomLength);
				dungeonSurfaces[dungeonSurfaceQty - 2].SetVertexTexCoords(3, roomWidth, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 2].CalculateNormals(dungeonVertices);
				// 5 -y (floor)
				dungeonSurfaces[dungeonSurfaceQty - 1].Initialize(4, true);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexIndex(0, 0);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexIndex(1, 4);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexIndex(2, 7);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexIndex(3, 3);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetTexture0(GameContext::TextureRegistry.GetTexture("TileDirt"));
				dungeonSurfaces[dungeonSurfaceQty - 1].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("TileDirtBumpMap"));
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexTexCoords(0, 0.0f, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexTexCoords(1, 0.0f, roomLength);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexTexCoords(2, roomWidth, roomLength);
				dungeonSurfaces[dungeonSurfaceQty - 1].SetVertexTexCoords(3, roomWidth, 0.0f);
				dungeonSurfaces[dungeonSurfaceQty - 1].CalculateNormals(dungeonVertices);

				// now each pillar
				int vertexIndex = 8;
				int surfaceIndex = 0;
				for (int h = 0; h < pillarWidthQty; h++)
				{
					float pillarCenterX = pillarWidthStart + float(h) * pillarSpacing;

					for (int v = 0; v < pillarLengthQty; v++)
					{
						float pillarCenterZ = pillarLengthStart + float(v) * pillarSpacing;

						// set up 8 vertices and 4 surfaces
						// vertices are arranged clockwise facing -z with -z face first
						dungeonVertices[vertexIndex + 0].vertex = Vector3d(pillarCenterX + pillarRadius, 0.0f, pillarCenterZ - pillarRadius);
						dungeonVertices[vertexIndex + 1].vertex = Vector3d(pillarCenterX + pillarRadius, roomHeight, pillarCenterZ - pillarRadius);
						dungeonVertices[vertexIndex + 2].vertex = Vector3d(pillarCenterX - pillarRadius, roomHeight, pillarCenterZ - pillarRadius);
						dungeonVertices[vertexIndex + 3].vertex = Vector3d(pillarCenterX - pillarRadius, 0.0f, pillarCenterZ - pillarRadius);
						dungeonVertices[vertexIndex + 4].vertex = Vector3d(pillarCenterX + pillarRadius, 0.0f, pillarCenterZ + pillarRadius);
						dungeonVertices[vertexIndex + 5].vertex = Vector3d(pillarCenterX + pillarRadius, roomHeight, pillarCenterZ + pillarRadius);
						dungeonVertices[vertexIndex + 6].vertex = Vector3d(pillarCenterX - pillarRadius, roomHeight, pillarCenterZ + pillarRadius);
						dungeonVertices[vertexIndex + 7].vertex = Vector3d(pillarCenterX - pillarRadius, 0.0f, pillarCenterZ + pillarRadius);

						// -z face
						dungeonSurfaces[surfaceIndex + 0].Initialize(4, true);
						dungeonSurfaces[surfaceIndex + 0].SetVertexIndex(0, vertexIndex + 0);
						dungeonSurfaces[surfaceIndex + 0].SetVertexIndex(1, vertexIndex + 1);
						dungeonSurfaces[surfaceIndex + 0].SetVertexIndex(2, vertexIndex + 2);
						dungeonSurfaces[surfaceIndex + 0].SetVertexIndex(3, vertexIndex + 3);
						dungeonSurfaces[surfaceIndex + 0].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
						dungeonSurfaces[surfaceIndex + 0].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
						dungeonSurfaces[surfaceIndex + 0].SetVertexTexCoords(0, 0.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 0].SetVertexTexCoords(1, 0.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 0].SetVertexTexCoords(2, pillarRadius * 2.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 0].SetVertexTexCoords(3, pillarRadius * 2.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 0].CalculateNormals(dungeonVertices);

						// -x face
						dungeonSurfaces[surfaceIndex + 1].Initialize(4, true);
						dungeonSurfaces[surfaceIndex + 1].SetVertexIndex(0, vertexIndex + 3);
						dungeonSurfaces[surfaceIndex + 1].SetVertexIndex(1, vertexIndex + 2);
						dungeonSurfaces[surfaceIndex + 1].SetVertexIndex(2, vertexIndex + 6);
						dungeonSurfaces[surfaceIndex + 1].SetVertexIndex(3, vertexIndex + 7);
						dungeonSurfaces[surfaceIndex + 1].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
						dungeonSurfaces[surfaceIndex + 1].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
						dungeonSurfaces[surfaceIndex + 1].SetVertexTexCoords(0, pillarRadius * 2.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 1].SetVertexTexCoords(1, pillarRadius * 2.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 1].SetVertexTexCoords(2, pillarRadius * 4.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 1].SetVertexTexCoords(3, pillarRadius * 4.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 1].CalculateNormals(dungeonVertices);

						// +z face
						dungeonSurfaces[surfaceIndex + 2].Initialize(4, true);
						dungeonSurfaces[surfaceIndex + 2].SetVertexIndex(0, vertexIndex + 7);
						dungeonSurfaces[surfaceIndex + 2].SetVertexIndex(1, vertexIndex + 6);
						dungeonSurfaces[surfaceIndex + 2].SetVertexIndex(2, vertexIndex + 5);
						dungeonSurfaces[surfaceIndex + 2].SetVertexIndex(3, vertexIndex + 4);
						dungeonSurfaces[surfaceIndex + 2].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
						dungeonSurfaces[surfaceIndex + 2].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
						dungeonSurfaces[surfaceIndex + 2].SetVertexTexCoords(0, pillarRadius * 4.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 2].SetVertexTexCoords(1, pillarRadius * 4.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 2].SetVertexTexCoords(2, pillarRadius * 6.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 2].SetVertexTexCoords(3, pillarRadius * 6.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 2].CalculateNormals(dungeonVertices);

						// +x face
						dungeonSurfaces[surfaceIndex + 3].Initialize(4, true);
						dungeonSurfaces[surfaceIndex + 3].SetVertexIndex(0, vertexIndex + 4);
						dungeonSurfaces[surfaceIndex + 3].SetVertexIndex(1, vertexIndex + 5);
						dungeonSurfaces[surfaceIndex + 3].SetVertexIndex(2, vertexIndex + 1);
						dungeonSurfaces[surfaceIndex + 3].SetVertexIndex(3, vertexIndex + 0);
						dungeonSurfaces[surfaceIndex + 3].SetTexture0(GameContext::TextureRegistry.GetTexture("Brick2"));
						dungeonSurfaces[surfaceIndex + 3].SetBumpMapTexture(GameContext::TextureRegistry.GetTexture("Brick2BumpMap"));
						dungeonSurfaces[surfaceIndex + 3].SetVertexTexCoords(0, pillarRadius * 6.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 3].SetVertexTexCoords(1, pillarRadius * 6.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 3].SetVertexTexCoords(2, pillarRadius * 8.0f, roomHeight);
						dungeonSurfaces[surfaceIndex + 3].SetVertexTexCoords(3, pillarRadius * 8.0f, 0.0f);
						dungeonSurfaces[surfaceIndex + 3].CalculateNormals(dungeonVertices);

						surfaceIndex += 4;
						vertexIndex += 8;
					}
				}

				if (surfaceIndex != dungeonSurfaceQty - 6)
					throw gcnew Exception(String::Format("Surface qty wrong!  Counted {0}, calculated {1}", surfaceIndex, dungeonSurfaceQty - 6));
				if (vertexIndex != dungeonVertexQty)
					throw gcnew Exception(String::Format("Vertex qty wrong!  Counted {0}, calculated {1}", vertexIndex, dungeonVertexQty));

				// allow 4 balls
				ballQty = 7;

				// also, put in a black panel!
				// give it a backside so it casts a shadow - correction, don't, see below!
				blackPanel = new Model3d();
				blackPanel->Initialize(1, 4, 1);
				blackPanel->GetColor(0)->Set(0, 0, 0);
				blackPanel->GetVertex(0)->colorIndex = 0;
				blackPanel->GetVertex(1)->colorIndex = 0;
				blackPanel->GetVertex(2)->colorIndex = 0;
				blackPanel->GetVertex(3)->colorIndex = 0;
				// make it 40' long by 8' tall
				blackPanel->GetVertex(0)->vertex.Set(2.0f, -0.4f, 0.0f);
				blackPanel->GetVertex(1)->vertex.Set(2.0f, 0.4f, 0.0f);
				blackPanel->GetVertex(2)->vertex.Set(-2.0f, 0.4f, 0.0f);
				blackPanel->GetVertex(3)->vertex.Set(-2.0f, -0.4f, 0.0f);
				blackPanel->GetSurface(0)->Initialize(4, true);
				blackPanel->GetSurface(0)->SetVertexIndex(0, 0);
				blackPanel->GetSurface(0)->SetVertexIndex(1, 1);
				blackPanel->GetSurface(0)->SetVertexIndex(2, 2);
				blackPanel->GetSurface(0)->SetVertexIndex(3, 3);
				// backside - correction, don't, paper thin surfaces = shadow acne
				//blackPanel->GetSurface(1)->Initialize(4, true);
				//blackPanel->GetSurface(1)->SetVertexIndex(0, 3);
				//blackPanel->GetSurface(1)->SetVertexIndex(1, 2);
				//blackPanel->GetSurface(1)->SetVertexIndex(2, 1);
				//blackPanel->GetSurface(1)->SetVertexIndex(3, 0);
				blackPanel->CalculateNormals();

				blackPanelOrient = new Orient3d();
				blackPanelOrient->LoadIdentity();
				blackPanelOrient->p.Set(-roomWidth/2.0f + 0.01f, 0.5f, roomLength / 2.0f);
				blackPanelOrient->Rotate(blackPanelOrient->u, 90.0f);
			}

			// get scene center and radius for directional light rendering
			Vector3d min;
			Vector3d max;
			for (int i = 0; i < dungeonVertexQty; i++)
			{
				if (i == 0)
				{
					min = dungeonVertices[i].vertex;
					max = dungeonVertices[i].vertex;
				}
				else
				{
					if (dungeonVertices[i].vertex.x < min.x)
						min.x = dungeonVertices[i].vertex.x;
					if (dungeonVertices[i].vertex.y < min.y)
						min.y = dungeonVertices[i].vertex.y;
					if (dungeonVertices[i].vertex.z < min.z)
						min.z = dungeonVertices[i].vertex.z;

					if (dungeonVertices[i].vertex.x > max.x)
						max.x = dungeonVertices[i].vertex.x;
					if (dungeonVertices[i].vertex.y > max.y)
						max.y = dungeonVertices[i].vertex.y;
					if (dungeonVertices[i].vertex.z > max.z)
						max.z = dungeonVertices[i].vertex.z;
				}
			}
			sceneWorldRadius = (max - min).Magnitude() / 2.0f;
			sceneWorldCenter = new Vector3d();
			*sceneWorldCenter = (max + min).ScalarMult(0.5f);

			triguy = new JointedModel3d();
			triguy->MakeTriGuy(GameContext::TextureRegistry.GetTexture("TriGuyFace1"));
			triguyOrient = new Orient3d();
			triguyOrient->LoadIdentity();
			// point mostly towards start
			//triguyOrient->Rotate(triguyOrient->u, 150.0f);
			triguyOrient->Rotate(triguyOrient->u, 180.0f);
			//triguyOrient->Rotate(triguyOrient->u, 90.0f);
			// place at end of hallway
			triguyOrient->p = Vector3d(0.0f, 0.28f, 10.0f); // 2.75 to foot sole, 0.12 scale model (hmm, 0.33 is too high)
			//triguyOrient->p = Vector3d(0.0f, 0.60f, 10.0f); // debugging
			triguyAnimationTracker = new JointedModelAnimationTracker();
			triguyAnimationTracker->SetAnimation(triguy->GetDefaultAnimation());
			triguyJointOrients = triguy->CreateGameObjectJointOrients();
			//triguy->GetJoint(0)->GetJointModel()->GetSurface(0)->SetTexture1(GameContext::TextureRegistry.GetTexture("TriGuyRedEyes"), GraphicsShaderCompositionTextureBlendOption::BlendInverseSqrtLight, GraphicsShaderCompositionTextureLightOption::Emittive);

			sirenOrient = new Orient3d();
			sirenOrient->LoadIdentity();
			sirenOrient->p = Vector3d(0.0f, 0.95f, 5.5f);
			sirenOrient->Rotate(sirenOrient->l, -35.0f);

			// very simple model for shader debugging
			simpleJointedModel = new JointedModel3d();
			simpleJointedModel->Initialize(cube, 0, 1);
			//simpleJointedModel->Initialize(ball, 0, 1);
			//simpleJointedModel->GetJoint(0)->Initialize(cube, 1);
			simpleJointedOrient = new Orient3d();
			simpleJointedOrient->LoadIdentity();
			simpleJointedOrient->p = Vector3d(0.1f, 0.6f, 4.0f);
			simpleJointedOrient->Rotate(Vector3d(0, 1, 0), -90.0f);
			simpleJointedOrients = new Orient3d[1];
			simpleJointedOrients[0].LoadIdentity();
			simpleJointedOrients[0].p = Vector3d(0.0f, 0.0f, 2.0f);
			//simpleJointedOrients[1].LoadIdentity();
			//simpleJointedOrients[1].p = Vector3d(0.0f, 0.0f, 4.0f);
			//simpleJointedOrients[0].Rotate(Vector3d(0,1,0), 30.0f);

			lightOn = new bool[8];
			lightOn[0] = true;
			lightOn[1] = true;
			lightOn[2] = false;
			lightOn[3] = false;
			lightOn[4] = false;
			lightOn[5] = false;
			lightOn[6] = false;
			lightOn[7] = false;
			lightQty = 0;

			// try out the collider
			colliderSet = new ColliderSet();
			colliderSet->InitializePoints(dungeonVertexQty);
			for (int v = 0; v < dungeonVertexQty; v++)
				colliderSet->GetPoint(v)->position = dungeonVertices[v].vertex;
			colliderSet->InitializeSurfaces(dungeonSurfaceQty);
			for (int s = 0; s < dungeonSurfaceQty; s++)
			{
				// set up collider surfaces
				// need tangents, base it on offset from pt 0 to 1 and cross prod with surface normal
				colliderSet->GetSurface(s)->Initialize(dungeonSurfaces[s].GetVertexQty());
				colliderSet->GetSurface(s)->normal = dungeonSurfaces[s].GetNormal();
				colliderSet->GetSurface(s)->point0 = dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(0)->vertexIndex].vertex;
				colliderSet->GetSurface(s)->tangentX = dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(1)->vertexIndex].vertex - dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(0)->vertexIndex].vertex;
				colliderSet->GetSurface(s)->tangentX.Normalize();
				colliderSet->GetSurface(s)->tangentY = colliderSet->GetSurface(s)->tangentX.CrossProd(dungeonSurfaces[s].GetNormal());
				for (int v = 0; v < dungeonSurfaces[s].GetVertexQty(); v++)
				{
					colliderSet->GetSurface(s)->SetSurfacePoint(v,
						Vector2d((dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(v)->vertexIndex].vertex - colliderSet->GetSurface(s)->point0) * colliderSet->GetSurface(s)->tangentX,
								(dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(v)->vertexIndex].vertex - colliderSet->GetSurface(s)->point0) * colliderSet->GetSurface(s)->tangentY));
				}
			}
			int segmentQty = 0;
			for (int s = 0; s < dungeonSurfaceQty; s++)
			{
				segmentQty += dungeonSurfaces[s].GetVertexQty();
			}
			// segments are repeated terribly here
			colliderSet->InitializeSegments(segmentQty);
			int segmentIndex = 0;
			for (int s = 0; s < dungeonSurfaceQty; s++)
			{
				for (int v = 0; v < dungeonSurfaces[s].GetVertexQty(); v++)
				{
					if (v == dungeonSurfaces[s].GetVertexQty() - 1)
					{
						colliderSet->GetSegment(segmentIndex)->point0 = dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(v)->vertexIndex].vertex;
						colliderSet->GetSegment(segmentIndex)->point1 = dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(0)->vertexIndex].vertex;
					}
					else
					{
						colliderSet->GetSegment(segmentIndex)->point0 = dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(v)->vertexIndex].vertex;
						colliderSet->GetSegment(segmentIndex)->point1 = dungeonVertices[dungeonSurfaces[s].GetSurfaceVertex(v+1)->vertexIndex].vertex;
					}
					Vector3d segmentVector = colliderSet->GetSegment(segmentIndex)->point1 - colliderSet->GetSegment(segmentIndex)->point0;
					colliderSet->GetSegment(segmentIndex)->segmentUnit = segmentVector;
					colliderSet->GetSegment(segmentIndex)->segmentUnit.Normalize();
					colliderSet->GetSegment(segmentIndex)->segmentLength = colliderSet->GetSegment(segmentIndex)->segmentUnit * segmentVector;

					segmentIndex++;
				}
			}

			ballThrowPower = 0.0f;
			ballThrowPowerMax = 12.0f / 1000.0f; // 120 ft/sec, just enough to throw it out of a 200' pit
			ballThrowPowerIncreaseRate = ballThrowPowerMax / 2000.0f; // 2 sec to reach max power

			frameBuffers = new GraphicsFrameBufferContainer[8];
			frameBuffersCubeMap = new GraphicsFrameBufferContainer[8];
			frameBuffersHires = new GraphicsFrameBufferContainer[2];

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (playerOrient != nullptr)
			{
				delete playerOrient;
				playerOrient = nullptr;
			}
			if (playerLightOrient != nullptr)
			{
				delete playerLightOrient;
				playerLightOrient = nullptr;
			}
			if (playerFallSpeed != nullptr)
			{
				delete playerFallSpeed;
				playerFallSpeed = nullptr;
			}
			if (playerWalkSpeed != nullptr)
			{
				delete playerWalkSpeed;
				playerWalkSpeed = nullptr;
			}
			if (playerProposedWalkSpeed != nullptr)
			{
				delete playerProposedWalkSpeed;
				playerProposedWalkSpeed = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (wallNativeRef != nullptr)
			{
				Trace::WriteLine(String::Format("Destroying Wall Native pointer: {0}", int(wallNativeRef)));
				delete wallNativeRef;
				wallNativeRef = nullptr;
			}
			if (cubeNativeRef != nullptr)
			{
				Trace::WriteLine(String::Format("Destroying Cube Native pointer: {0}", int(cubeNativeRef)));
				delete cubeNativeRef;
				cubeNativeRef = nullptr;
			}
			if (ballNativeRef != nullptr)
			{
				Trace::WriteLine(String::Format("Destroying Ball Native pointer: {0}", int(ballNativeRef)));
				delete ballNativeRef;
				ballNativeRef = nullptr;
			}
			if (triguyNativeRef != nullptr)
			{
				Trace::WriteLine(String::Format("Destroying Triguy Native pointer: {0}", int(triguyNativeRef)));
				delete triguyNativeRef;
				triguyNativeRef = nullptr;
			}
			if (simpleJointedNativeRef != nullptr)
			{
				Trace::WriteLine(String::Format("Destroying Simple Jointed Native pointer: {0}", int(simpleJointedNativeRef)));
				delete simpleJointedNativeRef;
				simpleJointedNativeRef = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
			if (ballOrients != nullptr)
			{
				delete[] ballOrients;
				ballOrients = nullptr;
			}
			if (ballVelocity != nullptr)
			{
				delete[] ballVelocity;
				ballVelocity = nullptr;
			}
			if (ballSpinAxis != nullptr)
			{
				delete[] ballSpinAxis;
				ballSpinAxis = nullptr;
			}
			if (ballSpinDegreesPerMSf != nullptr)
			{
				delete[] ballSpinDegreesPerMSf;
				ballSpinDegreesPerMSf = nullptr;
			}
			if (triguy != nullptr)
			{
				delete triguy;
				triguy = nullptr;
			}
			if (triguyOrient != nullptr)
			{
				delete triguyOrient;
				triguyOrient = nullptr;
			}
			if (sirenOrient != nullptr)
			{
				delete sirenOrient;
				sirenOrient = nullptr;
			}
			if (triguyAnimationTracker != nullptr)
			{
				delete triguyAnimationTracker;
				triguyAnimationTracker = nullptr;
			}
			if (triguyJointOrients != nullptr)
			{
				delete triguyJointOrients;
				triguyJointOrients = nullptr;
			}
			if (simpleJointedModel != nullptr)
			{
				delete simpleJointedModel;
				simpleJointedModel = nullptr;
			}
			if (simpleJointedOrient != nullptr)
			{
				delete simpleJointedOrient;
				simpleJointedOrient = nullptr;
			}
			if (simpleJointedOrients != nullptr)
			{
				delete simpleJointedOrients;
				simpleJointedOrients = nullptr;
			}
			if (blackPanel != nullptr)
			{
				delete blackPanel;
				blackPanel = nullptr;
			}
			if (blackPanelOrient != nullptr)
			{
				delete blackPanelOrient;
				blackPanelOrient = nullptr;
			}
			if (blackPanelNativeRef != nullptr)
			{
				delete blackPanelNativeRef;
				blackPanelNativeRef = nullptr;
			}
			if (lightOn != nullptr)
			{
				delete lightOn;
				lightOn = nullptr;
			}
			if (colliderSet != nullptr)
			{
				delete colliderSet;
				colliderSet = nullptr;
			}
			if (frameBuffers != nullptr)
			{
				delete [] frameBuffers;
				frameBuffers = nullptr;
			}
			if (frameBuffersCubeMap != nullptr)
			{
				delete[] frameBuffersCubeMap;
				frameBuffersCubeMap = nullptr;
			}
			if (frameBuffersHires != nullptr)
			{
				delete[] frameBuffersHires;
				frameBuffersHires = nullptr;
			}
			if (sceneWorldCenter != nullptr)
			{
				delete sceneWorldCenter;
				sceneWorldCenter = nullptr;
			}
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			timer->Poll();
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
			{
				// show mouse if it was hidden
				if (mouse.IsVisible() == false)
					mouse.Show();

				return false;
			}

			// apply mouse moves based on last collected movement
			if (playerFeetOnGround)
				playerProposedWalkSpeed->Set(0, 0, 0);
			float walkSpeed = 0.00586f / 10.0f * 2.0f;  // brisk 4 miles per hour, double (8mph hustle)
			float runSpeed = 0.022f / 10.0f; // 15 miles per hour
			float moveSpeed = walkSpeed;
			if (mouse.visible == false) // only control camera if mouse is hidden (todo: make this a 'mode' rather than checking the mouse state)
			{
				float mouseSensitivity = 0.25f;
				rotateAngleDegrees += (float(mouse.offsetX) * mouseSensitivity);
				while (rotateAngleDegrees >= 360.0f)
					rotateAngleDegrees -= 360.0f;
				while (rotateAngleDegrees < 0.0f)
					rotateAngleDegrees += 360.0f;
				pitchAngleDegrees -= (float(mouse.offsetY) * mouseSensitivity);
				if (pitchAngleDegrees > 90.0f)
					pitchAngleDegrees = 90.0f;
				if (pitchAngleDegrees < -90.0f)
					pitchAngleDegrees = -90.0f;

				// apply mouse controls
				// create new orientation for player
				Vector3d oldP = playerOrient->p;
				playerOrient->LoadIdentity();
				playerOrient->Rotate(playerOrient->u, rotateAngleDegrees);
				playerOrient->Rotate(playerOrient->l, pitchAngleDegrees);
				playerOrient->p = oldP;

				Vector3d horizontalForward = playerOrient->f;
				Vector3d sideways = playerOrient->l;
				horizontalForward.y = 0.0f;
				if (horizontalForward.Normalize() == false)
				{
					// use u for forward
					horizontalForward = playerOrient->u.ScalarMult(-1.0f);
					horizontalForward.Normalize();
				}
				sideways.Normalize(); // should always be good
				if (keyboardKeys.GetKey('A')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed + sideways);
				}
				if (keyboardKeys.GetKey('D')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed - sideways);
				}
				if (keyboardKeys.GetKey('W')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed + horizontalForward);
				}
				if (keyboardKeys.GetKey('S')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed - horizontalForward);
				}
				if (keyboardKeys.GetKey(16)->IsPressed() == true) // run
				{
					moveSpeed = runSpeed;
				}
				if (keyboardKeys.GetKey(32)->IsPressed() == true && playerFeetOnGround == true) // jump
				{
					if (keyboardKeys.GetKey(16)->IsPressed() == true)
						playerFallSpeed->Set(Vector3d(0, 0.0013f, 0));
					else
						playerFallSpeed->Set(Vector3d(0, 0.001f, 0));
					playerFeetOnGround = false;
				}

				if (mouse.leftButton.down == true)
				{
					// build up ball throw power
					ballThrowPower += ballThrowPowerIncreaseRate * timer->GetElapsedTimeMSFloat();
					if (ballThrowPower > ballThrowPowerMax)
						ballThrowPower = ballThrowPowerMax;
				}
				else if(mouse.leftButton.down == false)
				{
					// throw the ball!
					if (ballThrowPower > 0.0f)
					{
						ballOrients[currentBallIndex].p = playerOrient->p;
						ballOrients[currentBallIndex].p.y = playerOrient->p.y + 70.0f / 120.0f - 0.1f;
						ballOrients[currentBallIndex].p = ballOrients[currentBallIndex].p + playerOrient->f.ScalarMult(ballRadius + 0.05f);
						ballVelocity[currentBallIndex] = playerOrient->f.ScalarMult(ballThrowPower);
						ballThrowPower = 0.0f; // reset

						currentBallIndex++;
						if (currentBallIndex >= ballQty)
							currentBallIndex = 0;
					}
				}
			}

			// light qty
			if (keyboardKeys.GetKey('1')->IsClicked() == true)
			{
				lightOn[0] = !lightOn[0];
			}
			if (keyboardKeys.GetKey('2')->IsClicked() == true)
			{
				lightOn[1] = !lightOn[1];
			}
			if (keyboardKeys.GetKey('3')->IsClicked() == true)
			{
				lightOn[2] = !lightOn[2];
			}
			if (keyboardKeys.GetKey('4')->IsClicked() == true)
			{
				lightOn[3] = !lightOn[3];
			}
			if (keyboardKeys.GetKey('5')->IsClicked() == true)
			{
				lightOn[4] = !lightOn[4];
			}
			if (keyboardKeys.GetKey('6')->IsClicked() == true)
			{
				lightOn[5] = !lightOn[5];
			}
			if (keyboardKeys.GetKey('7')->IsClicked() == true)
			{
				lightOn[6] = !lightOn[6];
			}
			if (keyboardKeys.GetKey('8')->IsClicked() == true)
			{
				lightOn[7] = !lightOn[7];
			}

			if (keyboardKeys.GetKey('R')->IsClicked() == true)
			{
				// reset!
				playerFallSpeed->Set(0, 0, 0);
				playerOrient->LoadIdentity();
				playerOrient->p = Vector3d(0.0f, 0.1f, 0.5f);
				pitchAngleDegrees = 0.0f;
				rotateAngleDegrees = 0.0f;
				playerWalkSpeed->Set(0, 0, 0);
			}
			if (keyboardKeys.GetKey('L')->IsClicked() == true)
			{
				playerLightAttached = !playerLightAttached;
			}
			if (keyboardKeys.GetKey('M')->IsClicked() == true)
			{
				debugShadowMaps = !debugShadowMaps;
			}
			if (keyboardKeys.GetKey('N')->IsClicked() == true)
			{
				useShadowMaps = !useShadowMaps;
			}
			if (keyboardKeys.GetKey('B')->IsClicked() == true)
			{
				useDirectional = !useDirectional;
			}
			if (keyboardKeys.GetKey(13)->IsClicked() == true) // anaglyph yay!
			{
				doAnaglyph = !doAnaglyph;
			}
			if (keyboardKeys.GetKey(186)->IsClicked() == true) // semicolon
			{
				if (mouse.IsVisible() == false)
					mouse.Show();
				else
					mouse.Hide();
			}
			if (keyboardKeys.GetKey(192)->IsClicked() == true) // ~ tilde
			{
				slowMotion = !slowMotion;
			}
			if (keyboardKeys.GetKey('P')->IsClicked() == true) // P
			{
				absorbBallPhysics = !absorbBallPhysics;
			}
			if (keyboardKeys.GetKey('Z')->IsClicked() == true) // Z
			{
				showInstructions = !showInstructions;
			}
			keyboardKeys.ClearClicked();

			if (mouse.visible == false && appActivated == true)
			{
				// move it to the middle of the viewport (should be screen position)
				GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
				mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
			}
			mouse.ZeroOffsets();

			// apply move controls
			// slow down player if they are moving backwards
			if ((*playerProposedWalkSpeed * playerOrient->f) < -0.01f && moveSpeed == runSpeed)
				playerProposedWalkSpeed->Set(playerProposedWalkSpeed->ScalarMult(0.75f));

			static float slowMotionFactor = 1.0f;
			float slowMotionMinimum = 0.1f;
			float slowMotionMaximum = 1.0f;
			float slowMotionFactorRate = (slowMotionMaximum - slowMotionMinimum) / 500.0f; // 1/2 second per transition
			float timeToConsumeMSf = timer->GetElapsedTimeMSFloat();
			if (slowMotion == true)
			{
				if (slowMotionFactor > slowMotionMinimum)
				{
					slowMotionFactor -= timeToConsumeMSf * slowMotionFactorRate;
					if (slowMotionFactor < slowMotionMinimum)
						slowMotionFactor = slowMotionMinimum;
				}
			}
			else
			{
				if (slowMotionFactor < slowMotionMaximum)
				{
					slowMotionFactor += timeToConsumeMSf * slowMotionFactorRate;
					if (slowMotionFactor > slowMotionMaximum)
						slowMotionFactor = slowMotionMaximum;
				}
			}
			timeToConsumeMSf *= slowMotionFactor;
			while (timeToConsumeMSf > 0)
			{
				if (timeToConsumeMSf > 16)
				{
					timeToConsumeMSf -= 16;
					Animate(16.0f, *playerProposedWalkSpeed, moveSpeed);
				}
				else
				{
					Animate(timeToConsumeMSf, *playerProposedWalkSpeed, moveSpeed);
					timeToConsumeMSf = 0;
				}
			}

			// do this in Render - we need elapsedtime there
			//timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elapsedTimeMSf, Vector3d &p_moveVector, float p_moveSpeed)
		{
			float gravityPerMSMS = 32.0f / 10.0f / 1000.0f / 1000.0f; // 10.0f world scale

			if (playerFeetOnGround == false)
			{
				int a = 1; // just debugging
			}

			// apply acceleration
			if (playerFeetOnGround == true)
			{
				Vector3d proposedMoveVector = p_moveVector.ScalarMult(p_moveSpeed);
				Vector3d moveVectorOffset = proposedMoveVector - *playerWalkSpeed;
				float moveVectorOffsetMagnitude = moveVectorOffset.Magnitude();
				if ((playerAcceleration * p_elapsedTimeMSf) >= moveVectorOffsetMagnitude)
					*playerWalkSpeed = proposedMoveVector;
				else
					*playerWalkSpeed = *playerWalkSpeed + moveVectorOffset.ScalarMult((playerAcceleration * p_elapsedTimeMSf) / moveVectorOffsetMagnitude);
			}

			playerOrient->p = playerOrient->p + playerWalkSpeed->ScalarMult(p_elapsedTimeMSf);
			playerOrient->p = playerOrient->p + playerFallSpeed->ScalarMult(p_elapsedTimeMSf) + Vector3d(0, -1, 0).ScalarMult(0.5f * gravityPerMSMS * p_elapsedTimeMSf * p_elapsedTimeMSf);
			playerFallSpeed->Set(*playerFallSpeed + Vector3d(0, -1, 0).ScalarMult(gravityPerMSMS * p_elapsedTimeMSf));

			// treat player as a floating 1' radius ball for now and jsut shunt him according to the plane he intersected with
			// this works until we put convex corners in the map - then we will have to check segments too and recheck every time we shunt
			float radius = 0.1f;
			Vector3d proposedPlayerPosition = playerOrient->p;
			colliderSet->ContainSphere(proposedPlayerPosition, radius); // no need to recede a little here - player will always be contained - can't fail because max move is 16ms always
			if (proposedPlayerPosition.y > playerOrient->p.y)
			{
				playerFallSpeed->Set(0, 0, 0);
				playerFeetOnGround = true;
			}
			if (playerFallSpeed->y < 0.0f)
			{
				// player walked off a ledge or is still falling
				playerFeetOnGround = false;
			}
			playerOrient->p = proposedPlayerPosition;

			//for (int i = 0; i < dungeonSurfaceQty; i++)
			//{
			//	float sinkAmount = (playerOrient->p - dungeonVertices[dungeonSurfaces[i].GetSurfaceVertex(0)->vertexIndex].vertex) * dungeonSurfaces[i].GetNormal();
			//	if (sinkAmount < radius)
			//	{
			//		playerOrient->p = playerOrient->p + dungeonSurfaces[i].GetNormal().ScalarMult(radius - sinkAmount);
			//	}
			//}

			// spin the cube
			cubeOrient->Rotate(Vector3d(0, 1, 0), 360.0f / 12.0f / 1000.0f * p_elapsedTimeMSf); // 12 second rotation

			// spin the sirent
			sirenOrient->Rotate(Vector3d(0, 1, 0), 360.0f / 1000.0f * p_elapsedTimeMSf); // 1 second rotation

			// animate triguy
			triguyAnimationTracker->Animate(p_elapsedTimeMSf, triguyJointOrients);

			// animate ball
			AnimateBall(p_elapsedTimeMSf, gravityPerMSMS);
		}

		void AnimateBall(float p_elapsedTimeMSf, float p_gravityPerMSMS)
		{
			for (int b = 0; b < ballQty; b++)
			{
				Orient3d *ballOrient = &ballOrients[b];

				Vector3d priorBallPosition = ballOrient->p;
				ballOrient->p = ballOrient->p + ballVelocity[b].ScalarMult(p_elapsedTimeMSf) + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(0.5f * p_gravityPerMSMS * p_elapsedTimeMSf * p_elapsedTimeMSf);
				Vector3d moveOffset = ballOrient->p - priorBallPosition;

				// check for collisions with walls
				// just check with passing plane for now, check segments and points when that's possible
				float timeToConsumeMSf = p_elapsedTimeMSf;
				while (timeToConsumeMSf > 0)
				{
					//ModelSurface *collidedWall = nullptr;
					//float collisionTime = 10.0f;
					//for (int w = 0; w < dungeonSurfaceQty; w++)
					//{
					//	float collisionT;
					//	if (MathUtilities::SpherePlaneCollision(priorBallPosition, moveOffset, ballRadius, dungeonVertices[dungeonSurfaces[w].GetSurfaceVertex(0)->vertexIndex].vertex, dungeonSurfaces[w].GetNormal(), collisionT) == true)
					//	{
					//		if (collisionT < collisionTime)
					//		{
					//			collidedWall = &(dungeonSurfaces[w]);
					//			collisionTime = collisionT;
					//		}
					//	}
					//}
					//if (collidedWall == nullptr)
					//{
					//	*ballVelocity = *ballVelocity + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(gravityPerMSMS * timeToConsumeMSf);
					//	// apply the rest of spin
					//	ballOrient->Rotate(*ballSpinAxis, ballSpinDegreesPerMSf * timeToConsumeMSf);
					//	timeToConsumeMSf = 0;
					//	break;
					//}
					//else
					//{
					//	// handle collision
					//	float collisionIntervalMSf = timeToConsumeMSf * collisionTime;
					//	timeToConsumeMSf -= collisionIntervalMSf;
					//	// respond to collision (reflect velocity off collided wall normal)

					//	// pattern:
					//	// move to position at time collision happened
					//	// accelerate velocity - avoids gaining height on an upward bounce
					//	// apply any other natural effects up to the time collided (like spin)
					//	// affect velocity on collided ball and apply other collision effects, like new spin
					//	// calculate new position, get new prior position and move offset, and continue

					//	// move to position at time of collision
					//	ballOrient->p = priorBallPosition + moveOffset.ScalarMult(collisionTime);
					//	// accelerate velocity
					//	*ballVelocity = *ballVelocity + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(gravityPerMSMS * collisionIntervalMSf);
					//	// apply spin
					//	ballOrient->Rotate(*ballSpinAxis, ballSpinDegreesPerMSf * collisionIntervalMSf);
					//	// new spin before change velocity
					//	Vector3d velocityAlongWall = *ballVelocity - collidedWall->GetNormal().ScalarMult(*ballVelocity * collidedWall->GetNormal());
					//	*ballSpinAxis = velocityAlongWall.CrossProd(collidedWall->GetNormal());
					//	if (ballSpinAxis->Normalize() == true)
					//	{
					//		ballSpinDegreesPerMSf = MathUtilities::RadiansToDegrees(velocityAlongWall.Magnitude() / ballRadius);
					//	}
					//	else
					//		ballSpinDegreesPerMSf = 0; // perfect straight on collision with no spin
					//	// change velocity
					//	*ballVelocity = *ballVelocity - collidedWall->GetNormal().ScalarMult(2.0f * (*ballVelocity * collidedWall->GetNormal()));
					//	// new prior, new updated position and move offset
					//	priorBallPosition = ballOrient->p;
					//	ballOrient->p = ballOrient->p + ballVelocity->ScalarMult(timeToConsumeMSf) + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(0.5f * gravityPerMSMS * timeToConsumeMSf * timeToConsumeMSf);
					//	moveOffset = ballOrient->p - priorBallPosition;
					//}

					// trying collider
					void *collidedObject = nullptr;
					ColliderObjectType type;
					float collisionTime = 10.0f;
					Vector3d collisionPoint;
					Vector3d collisionNormal;
					// this was an attempt to allow the ball to come to rest, but the infinitessimal downward acceleration causes a repeated loop where a collision is detected at 0.0000 repeatedly
					// I'll have to fix that before I let the ball come to rest at ball - I may have to detect that I'm in contact with a surface and re-evaluate that each tick, telling the collider to ignore that
					//   surface in the collision and modify the velocity to be parallel to it but keep the ball receded from it enough to not let it fall through, and detect when no more contact occurs then
					//   let it fall accordingly (could be in contact with multiple surfaces, frankly many but usually 1 2 or 3, more than that would be very rare but possible at a symmetrical apex)
					//if (abs(moveOffset.x) < 0.0000001f) moveOffset.x = 0.0f;
					//if (abs(moveOffset.y) < 0.0000001f) moveOffset.y = 0.0f;
					//if (abs(moveOffset.z) < 0.0000001f) moveOffset.z = 0.0f;
					//if (moveOffset.MagnitudeSquared() < 0.000000001f)
					//{ 
					//	// don't even move the ball, let it establish more velocity next tick
					//	ballOrient->p = priorBallPosition;
					//	*ballVelocity = *ballVelocity + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(p_gravityPerMSMS * timeToConsumeMSf);
					//	// apply the rest of spin
					//	ballOrient->Rotate(*ballSpinAxis, ballSpinDegreesPerMSf * timeToConsumeMSf);
					//	timeToConsumeMSf = 0;

					//	// just make sure we aren't inside anything.  JUST in case...
					//	colliderSet->ContainSphere(ballOrient->p, ballRadius);
					//	break;
					//}
					//else 
					if (colliderSet->SphereCollision(priorBallPosition, moveOffset, ballRadius, collisionTime, &collidedObject, type, collisionPoint, collisionNormal) == false)
					{
						ballVelocity[b] = ballVelocity[b] + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(p_gravityPerMSMS * timeToConsumeMSf);
						// apply the rest of spin
						ballOrient->Rotate(ballSpinAxis[b], ballSpinDegreesPerMSf[b] * timeToConsumeMSf);
						timeToConsumeMSf = 0;

						// just make sure we aren't inside anything, and keep it receded, just a little.  JUST in case... (ball went through a wall in slow motion once - this should prevent that)
						colliderSet->ContainSphere(ballOrient->p, ballRadius + 0.00001f);
						break;
					}
					else
					{
						// handle collision
						float collisionIntervalMSf = timeToConsumeMSf * collisionTime;
						timeToConsumeMSf -= collisionIntervalMSf;
						// respond to collision (reflect velocity off collided wall normal)

						// pattern:
						// move to position at time collision happened
						// accelerate velocity - avoids gaining height on an upward bounce
						// apply any other natural effects up to the time collided (like spin)
						// affect velocity on collided ball and apply other collision effects, like new spin
						// calculate new position, get new prior position and move offset, and continue

						// move to position at time of collision
						//ballOrient->p = priorBallPosition + moveOffset.ScalarMult(collisionTime - 0.001f); // recede it just a little from the surface - to keep it separated fromt eh floor, avoid infinite detection
						ballOrient->p = priorBallPosition + moveOffset.ScalarMult(collisionTime);
						// accelerate velocity
						ballVelocity[b] = ballVelocity[b] + Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(p_gravityPerMSMS * collisionIntervalMSf);
						// apply spin
						ballOrient->Rotate(ballSpinAxis[b], ballSpinDegreesPerMSf[b] * collisionIntervalMSf);
						// new spin before change velocity
						Vector3d velocityAlongWall = ballVelocity[b] - collisionNormal.ScalarMult(ballVelocity[b] * collisionNormal);
						Vector3d proposedBallSpinAxis = velocityAlongWall.CrossProd(collisionNormal);
						if (proposedBallSpinAxis.Normalize() == true)
						{
							ballSpinAxis[b] = proposedBallSpinAxis;
							ballSpinDegreesPerMSf[b] = MathUtilities::RadiansToDegrees(velocityAlongWall.Magnitude() / ballRadius);
						}
						else if (ballVelocity->MagnitudeSquared() < 0.00001f)
							// just keep axis the same and just spin according to the velocity - ball is likely coming to rest
							ballSpinDegreesPerMSf[b] = MathUtilities::RadiansToDegrees(velocityAlongWall.Magnitude() / ballRadius);
						else
							// we hit the wall dead on, hard enough to stop spinning.
							ballSpinDegreesPerMSf[b] = 0;

						// todo: use spin to affect new velocity, then use that to determine the spin.  Blocks of code will be switching places here.

						// change velocity
						// if collision was so incredibly slight and collisionTime was very small, zero out the velocity in that direction and adjust acceleration below
						bool preventAcceleration = false;
						float bounceReduction = 0.90f;
						if (abs(ballVelocity[b] * collisionNormal) > 0.00001f)
						{
							if (absorbBallPhysics == false)
								ballVelocity[b] = ballVelocity[b] - collisionNormal.ScalarMult(2.0f * (ballVelocity[b] * collisionNormal));
							else
								// absorb just a tiny bit in the direction of the collisionNormal
								ballVelocity[b] = ballVelocity[b] - collisionNormal.ScalarMult((1.0f + bounceReduction) * (ballVelocity[b] * collisionNormal));
						}
						else
						{
							// ball is 'rolling' indicated by the very light impact
							preventAcceleration = true;
							// note: this is the same as velocity along wall... could just set it to that
							ballVelocity[b] = ballVelocity[b] - collisionNormal.ScalarMult(ballVelocity[b] * collisionNormal);
							if (absorbBallPhysics == true)
							{
								// ball is treated as rolling along a surface, so absorb a little again, but less
								float rollReduction = 0.99f;
								float comeToStopReduction = 0.85f;
								float magnitudeSquared = ballVelocity[b].MagnitudeSquared();
								float magnitudeThreshold = 0.000000016f; // based on world value (this one is 4 foot per second, squared)
								if (magnitudeSquared > magnitudeThreshold || collisionNormal.y < 0.99f) // slightly reduce if on fairly non-horizontal surface or rolling decently (0.06 degree slope)
									ballVelocity[b] = ballVelocity[b].ScalarMult(rollReduction);
								else
								{
									// bring to stop - rolling very slowly on horizontal surface (if slanted at all, gravity will be trying to accelerate it)
									float reduction = rollReduction - (magnitudeThreshold - magnitudeSquared) / magnitudeThreshold * (rollReduction - comeToStopReduction); // slow it down up to 0.75 the closer to zero it gets
									ballVelocity[b] = ballVelocity[b].ScalarMult(reduction);
								}
							}
						}
						// new prior, new updated position and move offset
						priorBallPosition = ballOrient->p;
						Vector3d accelerationComponentOfNewPosition = Vector3d(0.0f, -1.0f, 0.0f).ScalarMult(0.5f * p_gravityPerMSMS * timeToConsumeMSf * timeToConsumeMSf);
						if (preventAcceleration == false)
							ballOrient->p = ballOrient->p + ballVelocity[b].ScalarMult(timeToConsumeMSf) + accelerationComponentOfNewPosition;
						else
						{
							// don't acceleration along the surface this time - collision was so slight we are pretty much rolling - this avoids accelerating in a way to collide with that surface again
							// this avoids infinite loops MUCH better than trying to zero out the move offset or skipping detection later
							accelerationComponentOfNewPosition = accelerationComponentOfNewPosition - collisionNormal.ScalarMult(accelerationComponentOfNewPosition * collisionNormal);
							ballOrient->p = ballOrient->p + ballVelocity[b].ScalarMult(timeToConsumeMSf) + accelerationComponentOfNewPosition;
						}
						moveOffset = ballOrient->p - priorBallPosition;
					}
				}
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 0, 0));

			// prep frame buffers
			int shadowSize = 512;
			int shadowSizeHiRes = 2048;
			for (int i = 0; i < 8; i++)
			{
				if (frameBuffers[i].frameBuffer == nullptr)
					graphics->CreateFrameBuffer(&frameBuffers[i], GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, shadowSize, shadowSize); // 512 is soft edge with pcf.  1024 is too sharp looking, but avoids more bias problems
				if (frameBuffersCubeMap[i].frameBuffer == nullptr)
					graphics->CreateFrameBuffer(&frameBuffersCubeMap[i], GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, shadowSize, shadowSize, 6); // 512 is soft edge with pcf.  1024 is too sharp looking, but avoids more bias problems
				if (i < 2)
				{
					if (frameBuffersHires[i].frameBuffer == nullptr)
						graphics->CreateFrameBuffer(&frameBuffersHires[i], GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, shadowSizeHiRes, shadowSizeHiRes); // 512 is soft edge with pcf.  1024 is too sharp looking, but avoids more bias problems
				}
			}

			// make camera from player
			cameraOrient->Set(*playerOrient);
			cameraOrient->p.y = playerOrient->p.y + 70.0f / 120.0f - 0.1f; // player is 5'10

			bool drawDotHud = false;

			//StereoscopicCamera stereoCamera(0.2f, 0.025f); // 2' from screen, eyes 3" apart
			//StereoscopicCamera stereoCamera(0.2f, 0.01f); // 2' from screen, eyes really close - prevent strain (0.15 isnt' a bad effect, nice and pronounced but up close is jarring)
			//StereoscopicCamera stereoCamera(0.2f, 0.02f); // enhanced depth
			//StereoscopicCamera stereoCamera(0.2f, 0.025f); // really enhanced depth
			//StereoscopicCamera stereoCamera(0.2f, 0.04f); // super enhanced depth, almost too unreal
			//StereoscopicCamera stereoCamera(0.2f, 0.035f);
			//StereoscopicCamera stereoCamera(0.2f, 0.032f); /// good, but seems just outside of sweet pot

			// very acceptable
			//StereoscopicCamera stereoCamera(0.2f, 0.03f); // nicely enhanced depth, pretty good balance here for a 22" monitor 2 feet away with eyes 3" apart
			StereoscopicCamera stereoCamera(0.2f, 0.031f);
			static float currentEyeWidth = 0.0f;
			float maxEyeWidth = stereoCamera.eyeSeparationLength;
			float eyeRate = maxEyeWidth / 4000.0f; // 4 seconds to get to full anaglyph

			// animate eye width
			if (doAnaglyph == false && currentEyeWidth != 0.0f)
			{
				currentEyeWidth = currentEyeWidth - eyeRate * timer->GetElapsedTimeMSFloat();
				if (currentEyeWidth < 0.0f)
					currentEyeWidth = 0.0f;
			}
			else if (doAnaglyph == true && currentEyeWidth != maxEyeWidth)
			{
				currentEyeWidth = currentEyeWidth + eyeRate * timer->GetElapsedTimeMSFloat();
				if (currentEyeWidth > maxEyeWidth)
					currentEyeWidth = maxEyeWidth;
			}

			// prepare lights
			GraphicsShaderLight lights[8];
			// todo:
			// Instead of setting specific lights in the array, make each unchanging and set lightRefs to the lights we want each to represent, if feasible
			GraphicsShaderLightPtr lightRefs[8];
			for (int i = 0; i < 8; i++)
				lightRefs[i] = &(lights[i]);
			Vector3d lightPosition[8];
			int lightIndex = 0;
			int frameBufferIndex = 0;
			int frameBufferCubeMapIndex = 0;
			int frameBufferHiresIndex = 0;
			lightQty = 0;
			bool globeLit = false;
			static FastRandom fastRandom;
			for (int i = 0; i < 8; i++)
			{
				if (lightOn[i])
				{
					switch (i)
					{
					case 0:
						if (playerLightAttached == true)
						{
							playerLightOrient->Set(*cameraOrient);
							playerLightOrient->p = cameraOrient->p + Vector3d(0, -0.2f, 0) + cameraOrient->l.ScalarMult(-0.1f); // held in right hand
						}
						if (useDirectional == true)
							lights[lightIndex].SetDirectional(playerLightOrient->f, GameColor(255, 255, 255).ToVector3d());
						else
							lights[lightIndex].SetSpotlight(playerLightOrient->p, playerLightOrient->f, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), playerLightOrient->p, playerLightOrient->f, playerLightOrient->l, playerLightOrient->u, 45.0f, Vector3d(2.0f, 2.0f, 2.0f), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), playerLightOrient->p, playerLightOrient->f, playerLightOrient->l, playerLightOrient->u, 25.0f, Vector3d(3.0f, 3.0f, 3.0f), 0.25f, 0.125);
						//lights[lightIndex].SetPoint(playerLightOrient->p, Vector3d(1.0f, 1.0f, 1.0f), 0.25f, 0.125);
					
						//lights[lightIndex].SetPoint(playerLightOrient->p, Vector3d(2.0f, 2.0f, 2.0f), 0.25f, 0.125); // bright!
						//lights[lightIndex].SetSpotlight(ballOrient->p, ballOrient->f.ScalarMult(-1.0f), 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), cameraOrient->p, cameraOrient->f, cameraOrient->l, cameraOrient->u, 20.0f, GameColor(255, 255, 255), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlight(cameraOrient->p, cameraOrient->f, 25.0f, GameColor(255,255,255).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetPoint(cameraOrient->p, Vector3d(1.0f, 1.0f, 1.0f), 0.25f, 0.125); // normal
						//lights[lightIndex].SetPoint(cameraOrient->p, GameColor(255,255,255), 0.25f, 0.125);
						//lights[lightIndex].SetPoint(cameraOrient->p + cameraOrient->l.ScalarMult(-0.2f), GameColor(255, 255, 255), 0.25f, 0.125);
						//lights[lightIndex].SetDirectional(cameraOrient->f, GameColor(255,255,255));
						break;
					case 1:
					{
						unsigned char lightValue = 255;
						lights[lightIndex].SetPoint(ballOrients[0].p, GameColor(lightValue, lightValue, lightValue).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), ballOrients[0].p, ballOrients[0].f, ballOrients[0].l, ballOrients[0].u, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlight(ballOrient->p, ballOrient->f, 85.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlight(ballOrient->p, Vector3d(0,0,1), 85.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlight(ballOrient->p, ballOrient->f, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						//unsigned char lightValue = fastRandom.GetRandomInteger(64, 255); // flicker like electricity
						//lights[lightIndex].SetSpotlight(ballOrients[0].p, ballOrients[0].f, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						globeLit = true;
					}
					break;
					case 2:
					{
						if (ballQty > 1)
						{
							lights[lightIndex].SetPoint(ballOrients[1].p, GameColor(255, 128, 128).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[1].p, ballOrients[1].f, 45.0f, GameColor(255, 128, 128).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[1].p, ballOrients[1].f, 110.0f, GameColor(255, 128, 128).ToVector3d(), 0.25f, 0.125);
						}
						else
							lights[lightIndex].SetPoint(Vector3d(0.0f, -10.0f, 12.5f), GameColor(255, 128, 128).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlight(Vector3d(0.49f, -10.0f, 12.5f), Vector3d(-1,1,0), 85.0f, GameColor(255, 128, 128).ToVector3d(), 0.25f, 0.125);
					}
						break;
					case 3:
					{
						if (ballQty > 2)
						{
							lights[lightIndex].SetPoint(ballOrients[2].p, GameColor(128, 255, 128).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), ballOrients[2].p, ballOrients[2].f, ballOrients[2].l, ballOrients[2].u, 45.0f, Vector3d(1.0f, 2.0f, 1.0f), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), ballOrients[2].p, ballOrients[2].f, ballOrients[2].l, ballOrients[2].u, 80.0f, Vector3d(1.0f, 2.0f, 1.0f), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[2].p, ballOrients[2].f, 45.0f, GameColor(128, 255, 128).ToVector3d(), 0.25f, 0.125);
						}
						else
							lights[lightIndex].SetPoint(Vector3d(0.0f, 0.7f, 5.5f), GameColor(128, 255, 128).ToVector3d(), 0.25f, 0.125);
						//lights[lightIndex].SetSpotlight(sirenOrient->p, sirenOrient->f, 35.0f, GameColor(128, 255, 128), 0.25f, 0.125);
						//lights[lightIndex].SetDirectional(sirenOrient->f, GameColor(128, 255, 128));
					}
						break;
					case 4:
					{
						if (ballQty > 3)
						{
							lights[lightIndex].SetPoint(ballOrients[3].p, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[3].p, ballOrients[3].f, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[3].p, ballOrients[3].f, 40.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						}
						else
							lights[lightIndex].SetPoint(Vector3d(0.0f, 0.5f, 0.5f), GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
					}
						break;
					case 5:
					{
						if (ballQty > 4)
						{
							lights[lightIndex].SetPoint(ballOrients[4].p, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[4].p, ballOrients[4].f, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						}
						else
							lights[lightIndex].SetPoint(Vector3d(0.0f, 0.5f, 2.5f), GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
					}
						break;
					case 6:
					{
						if (ballQty > 5)
						{
							lights[lightIndex].SetPoint(ballOrients[5].p, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[5].p, ballOrients[5].f, 45.0f, GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
						}
						else
							lights[lightIndex].SetPoint(Vector3d(0.0f, 0.5f, 7.5f), GameColor(255, 255, 255).ToVector3d(), 0.25f, 0.125);
					}
						break;
					case 7:
					{
						if (ballQty > 6)
						{
							lights[lightIndex].SetPoint(ballOrients[6].p, GameColor(128, 128, 255).ToVector3d(), 0.25f, 0.125);
							//lights[lightIndex].SetSpotlight(ballOrients[6].p, ballOrients[6].f, 45.0f, GameColor(128, 128, 255).ToVector3d(), 0.25f, 0.125);
						}
						else
							lights[lightIndex].SetPoint(Vector3d(0.0f, 0.5f, 9.5f), GameColor(128, 128, 255).ToVector3d(), 0.25f, 0.125);
					}
						break;
					} //switch

					if (lights[lightIndex].shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
					{
						if (lights[lightIndex].type == GraphicsShaderCompositionLightType::Directional)
						{
							lights[lightIndex].shadowMapFrameBufferRef = &frameBuffersHires[frameBufferHiresIndex];
							lights[lightIndex].shadowMapTextureRef = frameBuffersHires[frameBufferHiresIndex].depthBufferTexture;
							frameBufferHiresIndex++;
						}
						else
						{
							lights[lightIndex].shadowMapFrameBufferRef = &frameBuffers[frameBufferIndex];
							lights[lightIndex].shadowMapTextureRef = frameBuffers[frameBufferIndex].depthBufferTexture;
							frameBufferIndex++;
						}
					}
					else
					{
						lights[lightIndex].shadowMapFrameBufferRef = &frameBuffersCubeMap[frameBufferCubeMapIndex];
						lights[lightIndex].shadowMapTextureRef = frameBuffersCubeMap[frameBufferCubeMapIndex].depthBufferTexture;
						frameBufferCubeMapIndex++;
					}

					lightIndex++;
					lightQty++;
				} // lightOn
			} // loop through lightOn
			// prep shadow maps
			if (useShadowMaps == true)
				DrawElements(graphics, nullptr, false, lightRefs, lightQty, true);

			if (doAnaglyph == false && currentEyeWidth == 0.0f)
			{
				graphics->SetPerspectiveProjection(45.0f, 0.01, 1000.0);
				graphics->DefaultTransform();

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);

				DrawElements(graphics, nullptr, false, lightRefs, lightQty, false);
				if (mouse.IsVisible() == false)
					DrawDotHud(graphics);
			}
			else
			{
				stereoCamera.eyeSeparationLength = currentEyeWidth;

				graphics->ColorMask(true, false, false, false);
				graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, 0.01, 1000.0, stereoCamera);
				graphics->DefaultTransformStereoscopicLeft(stereoCamera);

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);

				DrawElements(graphics, &stereoCamera, true, lightRefs, lightQty, false);
				if (mouse.IsVisible() == false)
				{
					if (drawDotHud == false)
						DrawAnaglyphHud(graphics, &stereoCamera, true);
				}

				graphics->ClearDepth();

				graphics->ColorMask(false, true, true, false);
				graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, 0.01, 1000.0, stereoCamera);
				graphics->DefaultTransformStereoscopicRight(stereoCamera);

				// reverse transform the camera
				graphics->ReverseTransform(*cameraOrient);

				DrawElements(graphics, &stereoCamera, false, lightRefs, lightQty, false);
				if (mouse.IsVisible() == false)
				{
					if (drawDotHud == false)
						DrawAnaglyphHud(graphics, &stereoCamera, false);
				}

				graphics->ColorMask(true, true, true, true);

				if (mouse.IsVisible() == false)
				{
					if (drawDotHud == true)
						DrawDotHud(graphics);
				}
			}

			if (debugShadowMaps == true && useShadowMaps == true)
			{
				graphics->ClearDepth();
				Vector3d vertices[4] = { Vector3d(1, -1, 0), Vector3d(1, 1, 0), Vector3d(-1, 1, 0), Vector3d(-1, -1, 0) };
				graphics->SetPerspectiveProjection(45.0f, 0.01, 1000.0);
				graphics->DefaultTransform();
				Matrix4d mvp = graphics->GetMVPMatrix();
				Orient3d shadowMapQuad;
				GraphicsShaderOptions renderOptions;

				if (static_cast<GameTexture ^>(lights[0].shadowMapTextureRef) != nullptr && lights[0].shadowMapFrameBufferRef->IsCubeMap() == false)
				{
					shadowMapQuad.LoadIdentity();
					shadowMapQuad.p = Vector3d(2, 0, 5);
					graphics->PushMatrix();
					renderOptions.eyeMVPMatrixRef = &mvp;
					renderOptions.texture0Ref = lights[0].shadowMapTextureRef;
					renderOptions.modelWorldOrientRef = &shadowMapQuad;
					renderOptions.vertexScale = 1.0f;
					graphics->RenderShadowMap(vertices, renderOptions);
					graphics->PopMatrix();
				}

				if (static_cast<GameTexture ^>(lights[1].shadowMapTextureRef) != nullptr && lights[1].shadowMapFrameBufferRef->IsCubeMap() == false)
				{
					shadowMapQuad.LoadIdentity();
					shadowMapQuad.p = Vector3d(-2, 0, 5);
					graphics->PushMatrix();
					renderOptions.eyeMVPMatrixRef = &mvp;
					renderOptions.modelWorldOrientRef = &shadowMapQuad;
					renderOptions.vertexScale = 1.0f;
					renderOptions.texture0Ref = lights[1].shadowMapTextureRef;
					graphics->RenderShadowMap(vertices, renderOptions);
					graphics->PopMatrix();
				}
			}

			if (showInstructions == true)
				ShowInstructions(graphics);

			graphics->FinishRender();
			graphics->SwapBuffers();

			timer->ResetElapsedTime();
		}

		void DrawElements(GraphicsBase *p_graphics, StereoscopicCamera *p_camera, bool p_left, GraphicsShaderLightPtr *lightRefs, int lightQty, bool prepShadowMapsOnly)
		{
			GameColor color(255, 255, 255);

			bool useShader = true;

			if (useShader == false)
			{
				// draw dungeon walls
				p_graphics->RenderSurfaces(&color, 1, dungeonSurfaces, dungeonSurfaceQty, dungeonVertices, dungeonVertexQty);

				p_graphics->PushMatrix();
				p_graphics->Transform(*cubeOrient);
				p_graphics->Scale(0.05f, 0.05f, 0.05f);
				cube->Render(*p_graphics);
				p_graphics->PopMatrix();

				p_graphics->PushMatrix();
				p_graphics->Transform(*triguyOrient);
				p_graphics->Scale(0.12f, 0.12f, 0.12f);
				triguy->Render(*p_graphics, triguyJointOrients, triguy->GetTotalJointOrientQty());
				p_graphics->PopMatrix();

				for (int b = 0; b < ballQty; b++)
				{
					p_graphics->PushMatrix();
					p_graphics->Transform(ballOrients[b]);
					p_graphics->Scale(0.2f, 0.2f, 0.2f);
					ball->Render(*p_graphics);
					p_graphics->PopMatrix();
				}
			}
			else
			{
				if (wallNativeRef == nullptr)
					wallNativeRef = new GraphicsNativeObjectContainer();
				if (wallNativeRef->nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(wallNativeRef, &color, 1, dungeonVertices, dungeonVertexQty, dungeonSurfaces, dungeonSurfaceQty, true);

				if (cubeNativeRef == nullptr)
					cubeNativeRef = new GraphicsNativeObjectContainer();
				if (cubeNativeRef->nativeObjectRef == nullptr)
					//p_graphics->CreateNativeObject(cubeNativeRef, cube->GetColors(), 8, cube->GetVertices(), 8, cube->GetSurfaces(), 6, true);
					cube->CreateNativeObject(p_graphics, cubeNativeRef, true);

				if (ballNativeRef == nullptr)
					ballNativeRef = new GraphicsNativeObjectContainer();
				if (ballNativeRef->nativeObjectRef == nullptr)
					//p_graphics->CreateNativeObject(ballNativeRef, ball->GetColors(), 18, ball->GetVertices(), 18, ball->GetSurfaces(), 32, true);
					ball->CreateNativeObject(p_graphics, ballNativeRef, true);

				if (triguyNativeRef == nullptr)
					triguyNativeRef = new GraphicsNativeObjectContainer();
				if (triguyNativeRef->nativeObjectRef == nullptr)
					triguy->CreateNativeObject(p_graphics, triguyNativeRef, true);

				if (simpleJointedNativeRef == nullptr)
					simpleJointedNativeRef = new GraphicsNativeObjectContainer();
				if (simpleJointedNativeRef->nativeObjectRef == nullptr)
					simpleJointedModel->CreateNativeObject(p_graphics, simpleJointedNativeRef, true);

				if (blackPanelNativeRef == nullptr)
					blackPanelNativeRef = new GraphicsNativeObjectContainer();
				if (blackPanelNativeRef->nativeObjectRef == nullptr)
					blackPanel->CreateNativeObject(p_graphics, blackPanelNativeRef, true);

				GraphicsNativeObjectRenderOptionsTransformData transformData;

				float cubescale = 0.05f;
				float triguyScale = 0.1f;
				float ballScale = ballRadius;
				float simpleScale = 0.1f;

				Orient3d simpleJointedOrient2(*simpleJointedOrient);
				simpleJointedOrient2.p.z += 0.3f;

				Orient3d wallsOrient;
				wallsOrient.LoadIdentity();

				if (prepShadowMapsOnly == true && useShadowMaps == true)
				{
					GraphicsShaderOptions shaderOptions;
					Matrix4d mvp;
					shaderOptions.lightRefs = lightRefs;
					shaderOptions.eyeMVPMatrixRef = &mvp;
					shaderOptions.transformDataRef = &transformData;
					Matrix4d lightMVPs[6];

					p_graphics->FlipCullFace();
					// at this point all lights that are on start at index 0 and go up to lightQty-1
					for (int i = 0; i < lightQty; i++)
					{
						p_graphics->SetCurrentFrameBuffer(lightRefs[i]->shadowMapFrameBufferRef);

						if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
						{
							if (lightRefs[i]->type == GraphicsShaderCompositionLightType::Directional)
								GraphicsUtilities::PrepareDirectionalShadowFlatMapMVP(p_graphics, shaderOptions, shaderOptions.lightRefs[i], 0.01f, 1000.0f, *sceneWorldCenter, sceneWorldRadius);
							else
								GraphicsUtilities::PrepareSpotlightShadowFlatMapMVP(p_graphics, shaderOptions, shaderOptions.lightRefs[i], 0.01f, 1000.0f);
						}
						else if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
						{
							GraphicsUtilities::PreparePointLightShadowCubeMapMVPs(p_graphics, shaderOptions, shaderOptions.lightRefs[i], lightMVPs, 0.01f, 1000.0f);
						}

						p_graphics->ClearDepth();

						// render it all! (walls last)

						p_graphics->PushMatrix();
						shaderOptions.vertexScale = cubescale;
						shaderOptions.modelWorldOrientRef = cubeOrient;
						if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
							p_graphics->RenderNativeObjectToCubeShadowMap(cubeNativeRef, shaderOptions);
						else
							p_graphics->RenderNativeObjectToShadowMap(cubeNativeRef, shaderOptions);
						p_graphics->PopMatrix();

						// don't shadow the ball to its light!
						for (int b = 0; b < ballQty; b++)
						{
							if (lightRefs[i]->worldPosition.Equals(ballOrients[b].p) == false)
							{
								p_graphics->PushMatrix();
								shaderOptions.modelWorldOrientRef = &ballOrients[b];
								shaderOptions.vertexScale = ballScale;
								if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
									p_graphics->RenderNativeObjectToCubeShadowMap(ballNativeRef, shaderOptions);
								else
									p_graphics->RenderNativeObjectToShadowMap(ballNativeRef, shaderOptions);
								p_graphics->PopMatrix();
							}
						}

						p_graphics->PushMatrix();
						shaderOptions.modelWorldOrientRef = triguyOrient;
						shaderOptions.vertexScale = triguyScale;
						// todo: prepare this separately and have it ready for both lighting rendering and final rendering
						triguy->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), triguyJointOrients, *triguyOrient, triguyScale);
						if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
							p_graphics->RenderNativeObjectToCubeShadowMap(triguyNativeRef, shaderOptions);
						else
							p_graphics->RenderNativeObjectToShadowMap(triguyNativeRef, shaderOptions);
						p_graphics->PopMatrix();

						p_graphics->PushMatrix();
						shaderOptions.modelWorldOrientRef = simpleJointedOrient;
						shaderOptions.vertexScale = simpleScale;
						// todo: prepare this separately and have it ready for both lighting rendering and final rendering
						simpleJointedModel->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), simpleJointedOrients, *simpleJointedOrient, simpleScale);
						if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
							p_graphics->RenderNativeObjectToCubeShadowMap(simpleJointedNativeRef, shaderOptions);
						else
							p_graphics->RenderNativeObjectToShadowMap(simpleJointedNativeRef, shaderOptions);
						p_graphics->PopMatrix();

						p_graphics->PushMatrix();
						shaderOptions.modelWorldOrientRef = &simpleJointedOrient2;
						shaderOptions.vertexScale = simpleScale;
						// todo: prepare this separately and have it ready for both lighting rendering and final rendering
						simpleJointedModel->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), simpleJointedOrients, simpleJointedOrient2, simpleScale);
						if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
							p_graphics->RenderNativeObjectToCubeShadowMap(simpleJointedNativeRef, shaderOptions);
						else
							p_graphics->RenderNativeObjectToShadowMap(simpleJointedNativeRef, shaderOptions);
						p_graphics->PopMatrix();

						// draw panel before walls to help with depth culling
						if (blackPanelOrient != nullptr)
						{
							p_graphics->PushMatrix();
							shaderOptions.modelWorldOrientRef = blackPanelOrient;
							shaderOptions.vertexScale = 1.0f;
							if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
								p_graphics->RenderNativeObjectToCubeShadowMap(blackPanelNativeRef, shaderOptions);
							else
								p_graphics->RenderNativeObjectToShadowMap(blackPanelNativeRef, shaderOptions);
							p_graphics->PopMatrix();
						}

						shaderOptions.modelWorldOrientRef = &wallsOrient;
						shaderOptions.vertexScale = 1.0f;
						if (lightRefs[i]->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
							p_graphics->RenderNativeObjectToCubeShadowMap(wallNativeRef, shaderOptions);
						else
							p_graphics->RenderNativeObjectToShadowMap(wallNativeRef, shaderOptions);
					} // for light

					// back to main
					p_graphics->FlipCullFace();
					p_graphics->SetCurrentFrameBuffer();

					return;
				} // done preparing shadowmaps

				// account for anaglyph
				Vector3d eyeLocation = cameraOrient->p;
				if (p_camera != nullptr)
				{
					if (p_left == true)
					{
						eyeLocation = p_camera->CorrectedEyePositionLeft(*cameraOrient);
					}
					else
					{
						eyeLocation = p_camera->CorrectedEyePositionRight(*cameraOrient);
					}
				}

				GraphicsShaderOptions shaderOptions;
				shaderOptions.transformDataRef = &transformData;
				// go with defaults for model but still set number of lights, matrix, etc.
				Matrix4d mvpMatrix = p_graphics->GetMVPMatrix();
				shaderOptions.eyeMVPMatrixRef = &mvpMatrix;
				shaderOptions.shadowMaps = useShadowMaps;

				// testing to see what gl_position would be set to in the shader for preparation of working with shadowmaps
				Vector4d test = mvpMatrix * Vector4d(Vector3d(cameraOrient->p + cameraOrient->l.ScalarMult(10.0f) + cameraOrient->u.ScalarMult(10.0f) + cameraOrient->f.ScalarMult(1.0f)), 1); // z/w gives you the depth in the volume (0-1)

				// initialize shader options
				//Vector3d ambientColor = Vector3d(0.0f, 0.0f, 0.0f);
				Vector3d ambientColor;
				GraphicsShaderMaterial material;
				if (lightQty > 0 && lightRefs[0]->type == GraphicsShaderCompositionLightType::Directional && lightRefs[0]->directionUnitWorldReversed.y > 0.0f)
				{
					// simulate brightly lit room and don't respond to lesser light so much
					ambientColor = Vector3d(lightRefs[0]->directionUnitWorldReversed.y / 1.5f, lightRefs[0]->directionUnitWorldReversed.y / 1.5f, lightRefs[0]->directionUnitWorldReversed.y / 1.5f);
					material.diffuseReflectivity = Vector3d(1.0f - ambientColor.x, 1.0f - ambientColor.y, 1.0f - ambientColor.z);
				}
				else
				{
					// simulate dark room
					ambientColor = Vector3d(0.0f, 0.0f, 0.0f);
					material.diffuseReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
				}
				Vector3d cameraPositionWorld;
				material.ambientReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
				shaderOptions.lighting = true;
				shaderOptions.ambientLightRef = &ambientColor;
				shaderOptions.lightingMaterialRef = &material;
				shaderOptions.lightRefs = lightRefs;
				shaderOptions.vertexLighting = false;

				shaderOptions.lightQty = lightQty;

				cameraPositionWorld = eyeLocation; // no transformation on eye for walls since they render at LoadIdentity()
				shaderOptions.cameraPositionRef = &cameraPositionWorld;

				// render cube
				cameraPositionWorld = cubeOrient->p + (eyeLocation - cubeOrient->p);// .ScalarMult(1.0f / cubescale); // 1/20 scale model
				shaderOptions.cameraPositionRef = &cameraPositionWorld;
				shaderOptions.eyeMVPMatrixRef = &mvpMatrix;
				shaderOptions.singleColorRef = nullptr; // cancel single color
				shaderOptions.modelWorldOrientRef = cubeOrient;
				shaderOptions.vertexScale = cubescale;
				material.specularReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
				material.shininess = 500.0f; // lower is more diffuse

				p_graphics->PushMatrix();
				p_graphics->RenderNativeObject(cubeNativeRef, shaderOptions);
				p_graphics->PopMatrix();

				// balls
				shaderOptions.cameraPositionRef = &cameraPositionWorld;
				shaderOptions.eyeMVPMatrixRef = &mvpMatrix;
				shaderOptions.singleColorRef = nullptr; // cancel single color
				shaderOptions.vertexScale = ballScale;
				material.specularReflectivity = Vector3d(0.7f, 0.7f, 0.7f);
				material.shininess = 50.0f; // lower is more diffuse
				for (int b = 0; b < ballQty; b++)
				{
					p_graphics->PushMatrix();
					cameraPositionWorld = ballOrients[b].p + (eyeLocation - ballOrients[b].p);// .ScalarMult(1.0f / ballScale); // 1/20 scale model
					shaderOptions.modelWorldOrientRef = &ballOrients[b];
					p_graphics->RenderNativeObject(ballNativeRef, shaderOptions);
					p_graphics->PopMatrix();
				}

				// triguy
				cameraPositionWorld = triguyOrient->p + (eyeLocation - triguyOrient->p);// .ScalarMult(1.0f / triguyScale);
				shaderOptions.lighting = true;
				material.specularReflectivity = Vector3d(0.0f, 0.0f, 0.0f);
				shaderOptions.modelWorldOrientRef = triguyOrient; // not used for joints, just being consistent
				p_graphics->PushMatrix();
				// todo: prepare this separately and have it ready for both lighting rendering and final rendering
				triguy->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), triguyJointOrients, *triguyOrient, triguyScale);
				shaderOptions.vertexScale = triguyScale;
				p_graphics->RenderNativeObject(triguyNativeRef, shaderOptions);
				p_graphics->PopMatrix();

				// render simple jointed model shader
				shaderOptions.lighting = true;
				shaderOptions.modelWorldOrientRef = simpleJointedOrient;
				cameraPositionWorld = simpleJointedOrient->p + (eyeLocation - simpleJointedOrient->p);// .ScalarMult(1.0f / simpleScale);
				if (simpleJointedModel->GetJointModel() == ball)
				{
					material.specularReflectivity = Vector3d(0.5f, 0.5f, 0.5f);
					material.shininess = 50.0f; // lower is more diffuse
				}
				else
				{
					material.specularReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
					material.shininess = 500.0f; // lower is more diffuse
				}
				p_graphics->PushMatrix();
				// todo: prepare this separately and have it ready for both lighting rendering and final rendering
				simpleJointedModel->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), simpleJointedOrients, *simpleJointedOrient, simpleScale);
				shaderOptions.vertexScale = simpleScale;
				p_graphics->RenderNativeObject(simpleJointedNativeRef, shaderOptions);
				p_graphics->PopMatrix();

				p_graphics->PushMatrix();
				// todo: prepare this separately and have it ready for both lighting rendering and final rendering
				simpleJointedModel->PrepareNativeObjectJointOrients(shaderOptions.transformDataRef->GetOrients(), simpleJointedOrients, simpleJointedOrient2, simpleScale);
				shaderOptions.vertexScale = simpleScale;
				p_graphics->RenderNativeObject(simpleJointedNativeRef, shaderOptions);
				p_graphics->PopMatrix();

				// draw black panel before walls to help with depth culling
				if (blackPanelOrient != nullptr)
				{
					shaderOptions.singleColorRef = nullptr;
					material.specularReflectivity.Set(1.0f, 1.0f, 1.0f);
					material.shininess = 1024; // really shine that sucker
					p_graphics->PushMatrix();
					shaderOptions.vertexScale = 1.0f;
					shaderOptions.modelWorldOrientRef = blackPanelOrient;
					p_graphics->RenderNativeObject(blackPanelNativeRef, shaderOptions);
					p_graphics->PopMatrix();
				}

				// walls last!!!
				shaderOptions.singleColorRef = &color;
				material.specularReflectivity = Vector3d(0.1f, 0.1f, 0.1f);
				material.shininess = 50.0f; // lower is more diffuse
				shaderOptions.modelWorldOrientRef = &wallsOrient;
				shaderOptions.vertexScale = 1.0f;
				p_graphics->RenderNativeObject(wallNativeRef, shaderOptions);
			}
		}

		void DrawAnaglyphHud(GraphicsBase *p_graphics, StereoscopicCamera *p_camera, bool p_left)
		{
			p_graphics->PushMatrix();

			// don't worry about anaglyph, just put it all at the convergence plane by rendering straight to the buffer
			// 2.5 feet out, far enough to side to allow converging out to deep field
			// render them at far depth in the middle of the viewport where eyes would look at distant objects
			if (p_left == true)
			{
				p_graphics->DefaultTransformStereoscopicLeft(*p_camera);
				p_graphics->Translate(0.0f, 0.0f, 100.0f);
			}
			else
			{
				p_graphics->DefaultTransformStereoscopicRight(*p_camera);
				p_graphics->Translate(0.0f, 0.0f, 100.0f);
			}
			p_graphics->Scale(1.5f, 1.5f, 1.5f); // surprising it renders so large as a 2x2 but whatever.

			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);

			GameColor color = GameColor(255, 255, 255);
			ModelVertex vertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			if (p_left == true)
				p_graphics->RenderFilledQuad(&color, 1, vertices, 4, true, GameContext::TextureRegistry.GetTexture("LeftReticle"), texCoords, 4);
			else
				p_graphics->RenderFilledQuad(&color, 1, vertices, 4, true, GameContext::TextureRegistry.GetTexture("RightReticle"), texCoords, 4);

			p_graphics->SetDepthTestEnabled(true);
			p_graphics->SetDepthWriteEnabled(true);

			p_graphics->PopMatrix();
		}

		void DrawDotHud(GraphicsBase *p_graphics)
		{
			p_graphics->SetPerspectiveProjection(45.0f, 0.01f, 1000.0f);

			p_graphics->PushMatrix();

			// don't worry about anaglyph, just put it all at the convergence plane by rendering straight to the buffer
			p_graphics->DefaultTransform();
			p_graphics->Translate(0.0f, 0.0f, 1.0f);
			p_graphics->Scale(0.003f, 0.003f, 0.003f);
			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);

			GameColor color = GameColor(255, 255, 255);
			ModelVertex vertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			p_graphics->RenderFilledQuad(&color, 1, vertices, 4, true, GameContext::TextureRegistry.GetTexture("Reticle"), texCoords, 4);

			p_graphics->SetDepthTestEnabled(true);
			p_graphics->SetDepthWriteEnabled(true);

			p_graphics->PopMatrix();
		}

		void ShowInstructions(GraphicsBase *p_graphics)
		{
			p_graphics->Set2dWindowProjection();
			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);

			GameFont ^font = GameContext::FontRegistry.GetFont("Info");

			String ^instructions = R"(; - toggle player mouse and move controls (hides mouse)
					W,A,S,D - move
					mouse - look
					left mouse button (hold and release) - launch bouncing ball at various speeds
					SPACE - jump
					SHIFT - run

					1-8 - toggle light source on/off (1 is player)
					L - toggle detach player light source

					R - reset player position to start
					P - toggle ball comes to rest (will currently lock app if ball is already at rest)
					M - debug 1st and 2nd plane shadowmap
					N - toggle shadows
					B - toggle player light spotlight/directional
					~ - slow motion toggle
					ENTER - toggle red/blue anaglyph

					Z - toggle these instructions)";

			p_graphics->RenderTextBlock(instructions, font, 10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - font->GetTextBlockSize(instructions).Y - 10, GameColor(255, 255, 128));

			p_graphics->SetDepthTestEnabled(true);
			p_graphics->SetDepthWriteEnabled(true);
		}
	};

	public ref class RenderBufferTextureTest : public GameBase
	{
	public:

		Orient3d *cubeOrients;
		int cubeOrientQty;
		Orient3d *cameraOrient;
		Model3d *cube;

		float sceneRotateAngle;
		float scenePitchAngle;
		float bufferQuadRotateAngle;
		float bufferQuadPitchAngle;

		GameTimer *timer;

		GraphicsFrameBufferContainer *frameBuffer1;
		GraphicsFrameBufferContainer *frameBufferShadowMap;

		GraphicsNativeObjectContainer *cubeNativeObject;

		RenderBufferTextureTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cubeOrients = nullptr;
			cubeOrientQty = 0;
			cameraOrient = nullptr;

			timer = nullptr;

			frameBuffer1 = nullptr;
			frameBufferShadowMap = nullptr;

			cubeNativeObject = nullptr;
		}

		virtual ~RenderBufferTextureTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("Spotlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flashlight2.jpg"));

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));

			cubeOrientQty = 6;
			cubeOrients = new Orient3d[cubeOrientQty];
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].LoadIdentity();

				switch(i)
				{
					case 0:
						cubeOrients[i].p = Vector3d(0, 0, 0);
						break;
					case 1:
						cubeOrients[i].p = Vector3d(5, 1, 0);
						break;
					case 2:
						cubeOrients[i].p = Vector3d(-1, 5, 3);
						break;
					case 3:
						cubeOrients[i].p = Vector3d(-3, 2, 0);
						break;
					case 4:
						cubeOrients[i].p = Vector3d(1, -6, 0);
						break;
					case 5:
						cubeOrients[i].p = Vector3d(0, -4, -4);
						break;
				}
			}

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();

			scenePitchAngle = 0;
			sceneRotateAngle = 0;
			bufferQuadPitchAngle = 0;
			bufferQuadRotateAngle = 0;

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrients != nullptr)
			{
				delete [] cubeOrients;
				cubeOrients = nullptr;
				cubeOrientQty = 0;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (frameBuffer1 != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting frameBuffer1 resource {0}", (int)(frameBuffer1->frameBuffer)));
				delete frameBuffer1;
				frameBuffer1 = nullptr;
			}
			if (frameBufferShadowMap != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting frameBufferShadowMap resource {0}", (int)(frameBufferShadowMap->frameBuffer)));
				delete frameBufferShadowMap;
				frameBufferShadowMap = nullptr;
			}
			if (cubeNativeObject != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting cubeNativeObject resource {0}", (int)(cubeNativeObject->nativeObjectRef)));
				delete cubeNativeObject;
				cubeNativeObject = nullptr;
			}
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// rotate scene
				sceneRotateAngle += float(mouse.offsetX);
				while (sceneRotateAngle >= 360.0f)
					sceneRotateAngle -= 360.0f;
				scenePitchAngle += float(mouse.offsetY);
				if (scenePitchAngle > 90.0f)
					scenePitchAngle = 90.0f;
				if (scenePitchAngle < -90.0f)
					scenePitchAngle = -90.0f;
			}
			else if (mouse.leftButton.down)
			{
				// rotate buffer quad
				bufferQuadRotateAngle += float(mouse.offsetX);
				while (bufferQuadRotateAngle >= 360.0f)
					bufferQuadRotateAngle -= 360.0f;
				bufferQuadPitchAngle += float(mouse.offsetY);
				if (bufferQuadPitchAngle > 90.0f)
					bufferQuadPitchAngle = 90.0f;
				if (bufferQuadPitchAngle < -90.0f)
					bufferQuadPitchAngle = -90.0f;
			}
			mouse.ZeroOffsets();

			Animate(timer->GetElapsedTimeMSFloat());

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elaspedTimeMSf)
		{
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].Rotate(Vector3d(0, 1, 0), 360.0f / 6.0f / 1000.0f * p_elaspedTimeMSf); // rotate every 6 seconds
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			graphics->MakeCurrent();

			////////////////////////////////////
			// render to internal buffer texture

			Orient3d spotlightOrient;
			spotlightOrient.LoadIdentity();
			spotlightOrient.Rotate(spotlightOrient.u, sceneRotateAngle);
			spotlightOrient.Rotate(spotlightOrient.l, scenePitchAngle);
			spotlightOrient.p = spotlightOrient.p + spotlightOrient.f.ScalarMult(-10.0f);
			float spotlightAngle = 45.0f;

			// render to a shadow map
			if (frameBufferShadowMap == nullptr)
				frameBufferShadowMap = new GraphicsFrameBufferContainer();
			// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			if (frameBufferShadowMap->frameBuffer == nullptr)
				graphics->CreateFrameBuffer(frameBufferShadowMap, GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, 600, 600);
			// set up renderbuffertexture as render target
			graphics->SetCurrentFrameBuffer(frameBufferShadowMap);
			// projection according to its dimensions
			graphics->SetPerspectiveProjection(spotlightAngle, 0.5, 1000.0); // 45 max for spotlight, so double it for this render - 0.5 makes shadowmap more visible
			// clear to a specific color to keep it distinct
			graphics->ClearDepth();
			graphics->DefaultTransform();
			// set up camera position for scene
			graphics->ReverseTransform(spotlightOrient);
			Matrix4d lightMVP = graphics->GetMVPMatrix(); // save for later
			// render the cubes to the shadowmap using a shader, capture their backsides to avoid shadow acne
			graphics->FlipCullFace();
			RenderCubes(graphics, true, nullptr, 0.0f, nullptr, nullptr, nullptr);
			graphics->FlipCullFace();
			// restore primary viewport as the render target
			graphics->FinishRender();

			// if RenderbuffertextureContainer is null, make a new one
			if (frameBuffer1 == nullptr)
				frameBuffer1 = new GraphicsFrameBufferContainer();
			// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			if (frameBuffer1->frameBuffer == nullptr)
				graphics->CreateFrameBuffer(frameBuffer1, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::Renderbuffer, 800, 600);
			//// set up renderbuffertexture as render target
			graphics->SetCurrentFrameBuffer(frameBuffer1);
			// projection according to its dimensions
			graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible
			// clear to a specific color to keep it distinct
			graphics->ClearScreen(GameColor(128, 128, 128));
			graphics->DefaultTransform();
			// set up camera position for scene
			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), sceneRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, scenePitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-20.0f);
			graphics->ReverseTransform(*cameraOrient);
			// render the cubes to the texture (different dimension and ratio than main viewport
			RenderCubes(graphics, false, &spotlightOrient, spotlightAngle, &(cameraOrient->p), &lightMVP, frameBufferShadowMap->depthBufferTexture);
			// restore primary viewport as the render target
			graphics->FinishRender();

			// reset to main
			graphics->SetCurrentFrameBuffer();

			//////////////////////////////////
			// render to primary viewport now

			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible

			graphics->DefaultTransform();

			// set up camera position for scene
			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), sceneRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, scenePitchAngle);
			// MUST be identical to how shadow map was rendered!!!
			cameraOrient->p = cameraOrient->f.ScalarMult(-30.0f);
			cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(-8.0f, 0, 0));

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// render the cubes to the main viewport
			RenderCubes(graphics, false, &spotlightOrient, spotlightAngle, &(cameraOrient->p), &lightMVP, frameBufferShadowMap->depthBufferTexture);

			// render the color framebuffer quad
			ModelVertex vertices[4] = { ModelVertex(Vector3d(400, 300, 0), 0), ModelVertex(Vector3d(-400, 300, 0), 0), ModelVertex(Vector3d(-400, -300, 0), 0), ModelVertex(Vector3d(400, -300, 0), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 1.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(0.0f, 0.0f) };
			GameColor color(255, 255, 255);

			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), bufferQuadRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, bufferQuadPitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-35.0f);
			cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(8.0f, -8.0f, 0));

			graphics->DefaultTransform();
			graphics->ReverseTransform(*cameraOrient);

			graphics->PushMatrix();
			graphics->Scale(0.02f, 0.02f, 0.02f);
			graphics->RenderFilledQuad(&color, 1, vertices, 4, false, frameBuffer1->colorBufferTexture, texCoords, 4);
			graphics->PopMatrix();

			// render the shadowmap texture quad using a shader
			// ll, ul, ur, lr as required
			Vector3d shadowMapVertices[4] = { Vector3d(300, -300, 0), Vector3d(300, 300, 0), Vector3d(-300, 300, 0), Vector3d(-300, -300, 0) };

			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), bufferQuadRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, bufferQuadPitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-35.0f);
			cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(8.0f, 8.0f, 0));

			graphics->DefaultTransform();
			graphics->ReverseTransform(*cameraOrient);
			Matrix4d mvp = graphics->GetMVPMatrix();
			Orient3d quadOrient;
			quadOrient.LoadIdentity();

			graphics->PushMatrix();
			GraphicsShaderOptions renderOptions;
			renderOptions.eyeMVPMatrixRef = &mvp;
			renderOptions.texture0Ref = frameBufferShadowMap->depthBufferTexture;
			renderOptions.vertexScale = 0.02f;
			renderOptions.modelWorldOrientRef = &quadOrient;
			//renderOptions.texture0Ref = frameBuffer1->colorBufferTexture;
			graphics->RenderShadowMap(shadowMapVertices, renderOptions);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderCubes(GraphicsBase *graphics, bool p_renderToShadowMap, Orient3d *lightOrient, float p_spotlightAngle, Vector3d *p_cameraPosition, Matrix4d *shadowMVP, GameTexture ^p_shadowMapTexture)
		{
			GraphicsShaderOptions shaderOptions;
			Matrix4d mvp;
			shaderOptions.eyeMVPMatrixRef = &mvp;
			shaderOptions.lighting = false;

			// prepare cube native object (they are all identical)
			if (cubeNativeObject == nullptr)
				cubeNativeObject = new GraphicsNativeObjectContainer();
			if (cubeNativeObject->nativeObjectRef == nullptr)
				cube->CreateNativeObject(graphics, cubeNativeObject, true);

			if (p_renderToShadowMap == false)
			{
				Vector3d ambientLight = Vector3d(0.2f, 0.2f, 0.2f);
				shaderOptions.ambientLightRef = &ambientLight;
				GraphicsShaderLight light;
				GraphicsShaderLightPtr lightRef[1];
				lightRef[0] = &light;
				light.SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), lightOrient->p, lightOrient->f, lightOrient->l, lightOrient->u, p_spotlightAngle / 2.0f, Vector3d(1, 1, 1), 0.00025f, 0.000125f); // match what was used to render shadowmap (half the angle of the projection)
				//light.SetSpotlight(lightOrient->p, lightOrient->f, p_spotlightAngle / 2.0f, Vector3d(1, 1, 1), 0.00025f, 0.000125f); // match what was used to render shadowmap (half the angle of the projection)
				GraphicsShaderMaterial material;
				material.shininess = 50.0f;
				material.ambientReflectivity = Vector3d(1, 1, 1);
				material.diffuseReflectivity = Vector3d(1, 1, 1);
				material.specularReflectivity = Vector3d(1, 1, 1);
				shaderOptions.lighting = true;
				shaderOptions.lightQty = 1;
				shaderOptions.lightRefs = &(lightRef[0]);
				shaderOptions.lightingMaterialRef = &material;
				shaderOptions.cameraPositionRef = p_cameraPosition;
				light.shadowMVP = *shadowMVP;
				light.shadowMapTextureRef = p_shadowMapTexture;
				shaderOptions.shadowMaps = true;

				for (int i = 0; i < cubeOrientQty; i++)
				{
					shaderOptions.modelWorldOrientRef = &cubeOrients[i];

					graphics->PushMatrix();
					// forward transform the cube
					mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeOrients[i]);
					//graphics->Transform(cubeOrients[i]);
					// render the cube
					//cube->Render(*graphics);
					graphics->RenderNativeObject(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}
			}
			else
			{
				for (int i = 0; i < cubeOrientQty; i++)
				{
					graphics->PushMatrix();
					// forward transform the cube
					mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeOrients[i]);
					graphics->Transform(cubeOrients[i]);
					// render the cube
					graphics->RenderNativeObjectToShadowMap(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}

			}
		}
	};

	public ref class CubemapTextureTest : public GameBase
	{
	public:

		Orient3d *cubeOrients; // original position
		Orient3d *cubeRenderOrients; // position from camera spin and cube spin
		int cubeOrientQty;
		Orient3d *cameraOrient;
		Model3d *cube;
		float cubeSpinAngle;

		float sceneRotateAngle;
		float scenePitchAngle;
		float bufferQuadRotateAngle;
		float bufferQuadPitchAngle;

		GameTimer *timer;

		GraphicsFrameBufferContainer *cubeMapBuffer1;
		GraphicsFrameBufferContainer *cubeMapShadowMap;

		GraphicsNativeObjectContainer *cubeNativeObject;

		CubemapTextureTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cubeOrients = nullptr;
			cubeRenderOrients = nullptr;
			cubeOrientQty = 0;
			cameraOrient = nullptr;
			cubeSpinAngle = 0;

			timer = nullptr;

			cubeMapBuffer1 = nullptr;
			cubeMapShadowMap = nullptr;

			cubeNativeObject = nullptr;
		}

		virtual ~CubemapTextureTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("Spotlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flashlight2.jpg"));

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));

			cubeOrientQty = 6;
			cubeOrients = new Orient3d[cubeOrientQty];
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].LoadIdentity();

				switch (i)
				{
				case 0:
					cubeOrients[i].p = Vector3d(0, 0, 0);
					break;
				case 1:
					//cubeOrients[i].p = Vector3d(5, 1, 0);
					cubeOrients[i].p = Vector3d(0, 0, 4);
					break;
				case 2:
					cubeOrients[i].p = Vector3d(-1, 5, 3);
					break;
				case 3:
					cubeOrients[i].p = Vector3d(-3, 2, 0);
					break;
				case 4:
					cubeOrients[i].p = Vector3d(1, -6, 0);
					break;
				case 5:
					cubeOrients[i].p = Vector3d(0, -4, -4);
					break;
				}
			}
			cubeRenderOrients = new Orient3d[cubeOrientQty];

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();

			scenePitchAngle = 0;
			sceneRotateAngle = 0;
			bufferQuadPitchAngle = 0;
			bufferQuadRotateAngle = 0;

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrients != nullptr)
			{
				delete[] cubeOrients;
				cubeOrients = nullptr;
				cubeOrientQty = 0;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (cubeMapBuffer1 != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting cubeMapBuffer1 resource {0}", (int)(cubeMapBuffer1->frameBuffer)));
				delete cubeMapBuffer1;
				cubeMapBuffer1 = nullptr;
			}
			if (cubeMapShadowMap != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting cubeMapShadowMap resource {0}", (int)(cubeMapShadowMap->frameBuffer)));
				delete cubeMapShadowMap;
				cubeMapShadowMap = nullptr;
			}
			if (cubeNativeObject != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting cubeNativeObject resource {0}", (int)(cubeNativeObject->nativeObjectRef)));
				delete cubeNativeObject;
				cubeNativeObject = nullptr;
			}
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// rotate scene
				sceneRotateAngle += float(mouse.offsetX);
				while (sceneRotateAngle >= 360.0f)
					sceneRotateAngle -= 360.0f;
				scenePitchAngle += float(mouse.offsetY);
				if (scenePitchAngle > 90.0f)
					scenePitchAngle = 90.0f;
				if (scenePitchAngle < -90.0f)
					scenePitchAngle = -90.0f;
			}
			else if (mouse.leftButton.down)
			{
				// rotate buffer quad
				bufferQuadRotateAngle += float(mouse.offsetX);
				while (bufferQuadRotateAngle >= 360.0f)
					bufferQuadRotateAngle -= 360.0f;
				bufferQuadPitchAngle += float(mouse.offsetY);
				if (bufferQuadPitchAngle > 90.0f)
					bufferQuadPitchAngle = 90.0f;
				if (bufferQuadPitchAngle < -90.0f)
					bufferQuadPitchAngle = -90.0f;
			}
			mouse.ZeroOffsets();

			Animate(timer->GetElapsedTimeMSFloat());

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elaspedTimeMSf)
		{
			cubeSpinAngle += 360.0f / 6.0f / 1000.0f * p_elaspedTimeMSf; // rotate every 6 seconds
			while (cubeSpinAngle >= 360.0f)
				cubeSpinAngle -= 360.0f;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			graphics->MakeCurrent();

			////////////////////////////////////
			// render to internal buffer texture

			// Important note: place all obejcts accurately within the world coordinates, because that is how the cubemap is rendered (although driven by MVPs) and used to shadow (true world vectors)

			// place light
			Orient3d lightOrient;
			lightOrient.LoadIdentity();
			lightOrient.p = Vector3d(0, 0, -2);

			Matrix4d lightMVP;

			// position cubes in world
			Orient3d cubeTransform;
			cubeTransform.LoadIdentity();
			cubeTransform.Rotate(cubeTransform.u, sceneRotateAngle);
			cubeTransform.Rotate(Vector3d(1, 0, 0), scenePitchAngle);

			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeRenderOrients[i].LoadIdentity();
				cubeRenderOrients[i].Rotate(cubeRenderOrients[i].u, sceneRotateAngle);
				cubeRenderOrients[i].Rotate(Vector3d(1,0,0), scenePitchAngle);
				cubeRenderOrients[i].Rotate(cubeRenderOrients[i].u, cubeSpinAngle);
				cubeRenderOrients[i].p = cubeTransform.TransformToWorldSpaceOffset(cubeOrients[i].p);
			}

			// render to a shadow map
			if (cubeMapShadowMap == nullptr)
				cubeMapShadowMap = new GraphicsFrameBufferContainer();
			// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			if (cubeMapShadowMap->frameBuffer == nullptr)
				graphics->CreateFrameBuffer(cubeMapShadowMap, GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, 600, 600, 6);

			// render to the cube depth map!
			graphics->SetCurrentFrameBuffer(cubeMapShadowMap);
			graphics->ClearDepth();
			// it works!
			graphics->SetPerspectiveProjection(90.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible - 90 is CRITICAL here for cube map!, 1000 must match far plane of normal render window
			// pre 6 world eye mvps for light
			Orient3d tempLightOrient;
			graphics->DefaultTransform();
			Matrix4d lightMVPs[6];
			for (int i = 0; i < 6; i++)
			{
				// reset to id (current orientation: +z)
				tempLightOrient = lightOrient;

				// +x, -x, +y, -y, +z, -z, same order as OpenGL
				switch (i)
				{
				case 0: // +x
				{
					tempLightOrient.Rotate(tempLightOrient.u, -90.0f);
				}
				break;
				case 1: // -x
				{
					tempLightOrient.Rotate(tempLightOrient.u, 90.0f);
				}
				break;
				case 2: // +y
				{
					tempLightOrient.Rotate(tempLightOrient.l, 90.0f);
				}
				break;
				case 3: // -y
				{
					tempLightOrient.Rotate(tempLightOrient.l, -90.0f);
				}
				break;
				case 4: // +z
				{
					// all done
				}
				break;
				case 5: // -z
				{
					tempLightOrient.Rotate(tempLightOrient.u, 180.0f);
				}
				break;
				}

				// spin so that x and y are upside down and end tex coords in render target are consistent with what shader needs to access cube during final render
				// this must happen for the results in the cube map to be usable!
				tempLightOrient.Rotate(tempLightOrient.f, 180.0f);

				graphics->PushMatrix();
				graphics->ReverseTransform(tempLightOrient);
				lightMVPs[i] = graphics->GetMVPMatrix();
				graphics->PopMatrix();
			}
			// now render the cubes to the shadow map
			graphics->FlipCullFace();
			RenderCubes(graphics, true, &lightOrient, nullptr, lightMVPs, cubeMapShadowMap->depthBufferTexture);
			graphics->FlipCullFace();
			graphics->SetCurrentFrameBuffer();

			//////////////////////////////////
			// render to primary viewport now

			graphics->ClearScreen(GameColor(0, 128, 128));
			graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible

			graphics->DefaultTransform();

			// set up camera position for scene
			cameraOrient->LoadIdentity();
			cameraOrient->p = Vector3d(-8, 0, -30);

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// render the light using the old pipeline for display purposes
			graphics->PushMatrix();
			graphics->Transform(lightOrient);
			graphics->Scale(0.1f, 0.1f, 0.1f);
			cube->Render(*graphics);
			graphics->PopMatrix();

			// render the cubes to the main viewport, shadowed
			RenderCubes(graphics, false, &lightOrient, &(cameraOrient->p), &lightMVP, cubeMapShadowMap->depthBufferTexture);
			//RenderCubes(graphics, false, &lightOrient, &(cameraOrient->p), &lightMVP, nullptr);

			// render the cube map as the sideways cross by accessing it 6 different ways (ll, ul, ur, lr)
			// These coords are consistent with how the shader will need to access the data (requires spinning the light orient 180degree on f after f is correct)
			ModelVertexTextureCoords3d posZTex[4] = { ModelVertexTextureCoords3d(1, -1, 1), ModelVertexTextureCoords3d(1, 1, 1), ModelVertexTextureCoords3d(-1, 1, 1), ModelVertexTextureCoords3d(-1, -1, 1) };
			ModelVertexTextureCoords3d negZTex[4] = { ModelVertexTextureCoords3d(-1, -1, -1), ModelVertexTextureCoords3d(-1, 1, -1), ModelVertexTextureCoords3d(1, 1, -1), ModelVertexTextureCoords3d(1, -1, -1) };
			ModelVertexTextureCoords3d posYTex[4] = { ModelVertexTextureCoords3d(1, 1, 1), ModelVertexTextureCoords3d(1, 1, -1), ModelVertexTextureCoords3d(-1, 1, -1), ModelVertexTextureCoords3d(-1, 1, 1) };
			ModelVertexTextureCoords3d negYTex[4] = { ModelVertexTextureCoords3d(1, -1, -1), ModelVertexTextureCoords3d(1, -1, 1), ModelVertexTextureCoords3d(-1, -1, 1), ModelVertexTextureCoords3d(-1, -1, -1) };
			// left face
			ModelVertexTextureCoords3d posXTex[4] = { ModelVertexTextureCoords3d(1, -1, -1), ModelVertexTextureCoords3d(1, 1, -1), ModelVertexTextureCoords3d(1, 1, 1), ModelVertexTextureCoords3d(1, -1, 1) };
			// right face
			ModelVertexTextureCoords3d negXTex[4] = { ModelVertexTextureCoords3d(-1, -1, 1), ModelVertexTextureCoords3d(-1, 1, 1), ModelVertexTextureCoords3d(-1, 1, -1), ModelVertexTextureCoords3d(-1, -1, -1) };

			// quad positions
			Vector3d posX[4] = { Vector3d(3, -1, 0), Vector3d(3, 1, 0), Vector3d(1, 1, 0), Vector3d(1, -1, 0) };
			Vector3d posZ[4] = { Vector3d(1, -1, 0), Vector3d(1, 1, 0), Vector3d(-1, 1, 0), Vector3d(-1, -1, 0) };
			Vector3d negX[4] = { Vector3d(-1, -1, 0), Vector3d(-1, 1, 0), Vector3d(-3, 1, 0), Vector3d(-3, -1, 0) };
			Vector3d negZ[4] = { Vector3d(-3, -1, 0), Vector3d(-3, 1, 0), Vector3d(-5, 1, 0), Vector3d(-5, -1, 0) };
			Vector3d posY[4] = { Vector3d(1, 1, 0), Vector3d(1, 3, 0), Vector3d(-1, 3, 0), Vector3d(-1, 1, 0) };
			Vector3d negY[4] = { Vector3d(1, -3, 0), Vector3d(1, -1, 0), Vector3d(-1, -1, 0), Vector3d(-1, -3, 0) };

			graphics->DefaultTransform();
			cameraOrient->LoadIdentity();
			cameraOrient->p = Vector3d(4, 0, -15);
			graphics->ReverseTransform(*cameraOrient);
			Orient3d identityOrient;
			identityOrient.LoadIdentity();
			GraphicsShaderOptions shaderOptions;
			Matrix4d eyeMVP = graphics->GetMVPMatrix();
			shaderOptions.eyeMVPMatrixRef = &eyeMVP;
			shaderOptions.modelWorldOrientRef = &identityOrient;
			shaderOptions.texture0Ref = cubeMapShadowMap->depthBufferTexture;
			graphics->RenderCubeShadowMapFace(posX, posXTex, shaderOptions);
			graphics->RenderCubeShadowMapFace(negX, negXTex, shaderOptions);
			graphics->RenderCubeShadowMapFace(posZ, posZTex, shaderOptions);
			graphics->RenderCubeShadowMapFace(negZ, negZTex, shaderOptions);
			graphics->RenderCubeShadowMapFace(posY, posYTex, shaderOptions);
			graphics->RenderCubeShadowMapFace(negY, negYTex, shaderOptions);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderCubes(GraphicsBase *graphics, bool p_renderToShadowMap, Orient3d *lightOrient, Vector3d *p_cameraPosition, Matrix4d *lightMVPs, GameTexture ^p_shadowMapTexture)
		{
			GraphicsShaderOptions shaderOptions;
			Matrix4d mvp;
			shaderOptions.eyeMVPMatrixRef = &mvp;
			shaderOptions.lighting = false;
			shaderOptions.vertexScale = 1.0f;

			// prepare cube native object (they are all identical)
			if (cubeNativeObject == nullptr)
				cubeNativeObject = new GraphicsNativeObjectContainer();
			if (cubeNativeObject->nativeObjectRef == nullptr)
				cube->CreateNativeObject(graphics, cubeNativeObject, true);

			if (p_renderToShadowMap == false)
			{
				Vector3d ambientLight = Vector3d(0.2f, 0.2f, 0.2f);
				shaderOptions.ambientLightRef = &ambientLight;
				GraphicsShaderLight light;
				GraphicsShaderLightPtr lightRefs[1];
				lightRefs[0] = &light;
				light.SetPoint(lightOrient->p, Vector3d(1, 1, 1), 0.00025f, 0.000125f);
				GraphicsShaderMaterial material;
				material.shininess = 50.0f;
				material.ambientReflectivity = Vector3d(1, 1, 1);
				material.diffuseReflectivity = Vector3d(1, 1, 1);
				material.specularReflectivity = Vector3d(1, 1, 1);
				shaderOptions.lightQty = 1;
				shaderOptions.lightRefs = &(lightRefs[0]);
				shaderOptions.lightingMaterialRef = &material;
				shaderOptions.cameraPositionRef = p_cameraPosition;
				//light.shadowMVP = nullptr; // only need light position for cubemap!
				if (p_shadowMapTexture != nullptr)
				{
					light.shadowMapTextureRef = p_shadowMapTexture;
					shaderOptions.shadowMaps = true;
				}
				else
					shaderOptions.shadowMaps = false;
				shaderOptions.lighting = true;
				//shaderOptions.lighting = true;

				for (int i = 0; i < cubeOrientQty; i++)
				{
					graphics->PushMatrix();
					// forward transform the cube
					mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeRenderOrients[i]);
					//graphics->Transform(cubeOrients[i]);
					// render the cube
					//cube->Render(*graphics);
					graphics->RenderNativeObject(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}
			}
			else
			{
				// the cubemap is the active render surface right now, so the shader can handle six layers via a geometry shader
				shaderOptions.pointLightCubeMVPRef = lightMVPs;
				shaderOptions.pointLightPositionRef = &(lightOrient->p);

				for (int i = 0; i < cubeOrientQty; i++)
				{
					graphics->PushMatrix();
					// forward transform the cube
					//mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeRenderOrients[i]);
					//graphics->Transform(cubeRenderOrients[i]);
					// render the cube
					graphics->RenderNativeObjectToCubeShadowMap(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}

			}
		}
	};

	public ref class TestOrthographicProjection : public GameBase
	{
	public:

		Orient3d *jetOrient;
		Orient3d *cubeOrient;
		Orient3d *cameraOrient;
		Model3d *cube;
		Model3d *jet;
		Model3d *ball;
		Orient3d *ballOrient;

		TestOrthographicProjection(HWND p_hWnd) : GameBase(p_hWnd)
		{
			jetOrient = nullptr;
			cubeOrient = nullptr;
			cameraOrient = nullptr;
			ball = nullptr;
			ballOrient = nullptr;
		}

		virtual ~TestOrthographicProjection()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			jetOrient = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient = new Orient3d();
			ballOrient = new Orient3d();
			jetOrient->LoadIdentity();
			cubeOrient->LoadIdentity();
			cameraOrient->LoadIdentity();
			ballOrient->LoadIdentity();

			// back up the camera
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);
			// move the jet forward and over
			jetOrient->p = jetOrient->p + jetOrient->f.ScalarMult(7.0f) + jetOrient->l.ScalarMult(-2.5f) + jetOrient->u.ScalarMult(2.0f);
			cubeOrient->p = cubeOrient->p + cubeOrient->f.ScalarMult(7.0f) + cubeOrient->l.ScalarMult(2.5f) + cubeOrient->u.ScalarMult(2.0f);
			ballOrient->p = ballOrient->p + ballOrient->f.ScalarMult(7.0f) + ballOrient->l.ScalarMult(2.5f) - ballOrient->u.ScalarMult(2.0f);

			jetOrient->Rotate(jetOrient->u, 180.0f);
			cubeOrient->Rotate(cubeOrient->u, 180.0f);
			ballOrient->Rotate(ballOrient->u, 180.0f);

			cube = new Model3d();
			cube->MakeCube();
			// give it a texture, make front face white to make it pure
			cube->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));
			cube->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			cube->GetSurface(0)->SetVertexTexCoords(1, 0.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
			cube->GetSurface(0)->SetVertexTexCoords(3, 1.0f, 1.0f);
			cube->GetColor(0)->Set(255, 255, 255);
			cube->GetColor(1)->Set(255, 255, 255);
			cube->GetColor(2)->Set(255, 255, 255);
			cube->GetColor(3)->Set(255, 255, 255);

			jet = new Model3d();
			jet->MakeJet();

			// cheat and make it look like it did before it was fixed
			jet->GetSurface(2)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(4)->SetVertexColorOverrideIndex(2, -1);
			jet->GetSurface(5)->SetVertexColorOverrideIndex(0, -1);
			jet->GetSurface(8)->SetVertexColorOverrideIndex(0, -1);

			ball = new Model3d();
			ball->MakeSphere();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (jet != nullptr)
			{
				delete jet;
				jet = nullptr;
			}
			if (jetOrient != nullptr)
			{
				delete jetOrient;
				jetOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
			if (ballOrient != nullptr)
			{
				delete ballOrient;
				ballOrient = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				jetOrient->Rotate(jetOrient->f, float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(cubeOrient->f, float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(ballOrient->f, -float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				jetOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				ballOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				jetOrient->Rotate(jetOrient->l, -float(mouse.offsetY) / 5.0f);
				cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
				ballOrient->Rotate(ballOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			mouse.ZeroOffsets();

			// apply joystick, avoid dead area
			JoystickValues *jValues = joystick->GetJoystickValues();
			Orient3d *targetOrient = jetOrient;
			if (jValues->valid)
			{
				int primaryDeadArea = 150;
				int twistDeadArea = 250;

				if (abs(jValues->primaryX) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryX > 0)
						value = jValues->primaryX - primaryDeadArea;
					else
						value = jValues->primaryX + primaryDeadArea;

					if (jValues->button2Down == false)
						targetOrient->Rotate(targetOrient->f - targetOrient->u, -float(value) / 200.0f, false);
					else
						targetOrient->Rotate(targetOrient->f, -float(value) / 200.0f, false);
				}
				if (abs(jValues->primaryY) > primaryDeadArea)
				{
					int value = 0;
					if (jValues->primaryY > 0)
						value = jValues->primaryY - primaryDeadArea;
					else
						value = jValues->primaryY + primaryDeadArea;

					targetOrient->Rotate(targetOrient->l, float(value) / 200.0f, false);
				}
				if (abs(jValues->twist) > twistDeadArea)
				{
					int value = 0;
					if (jValues->twist > 0)
						value = jValues->twist - twistDeadArea;
					else
						value = jValues->twist + twistDeadArea;

					targetOrient->Rotate(targetOrient->u, float(value) / 200.0f, false);
				}
			}

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetOrthoProjection(0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// size so that models are visible
			graphics->Scale(0.2f, 0.2f, 1.0f);

			graphics->PushMatrix();
			// forward transform the cube
			graphics->Transform(*cubeOrient);
			// render the cube
			cube->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the ball
			graphics->Transform(*ballOrient);
			// render the cube
			ball->Render(*graphics);
			graphics->PopMatrix();

			graphics->PushMatrix();
			// forward transform the jet
			//graphics->RenderTestTriangle();
			graphics->Transform(*jetOrient);
			// render the jet
			jet->Render(*graphics);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}
	};

	public ref class DirectionalLightShadowTest : public GameBase
	{
	public:

		Orient3d *cubeOrients;
		int cubeOrientQty;
		Orient3d *cameraOrient;
		Model3d *cube;

		float sceneRotateAngle;
		float scenePitchAngle;
		float bufferQuadRotateAngle;
		float bufferQuadPitchAngle;

		GameTimer *timer;

		GraphicsFrameBufferContainer *frameBuffer1;
		GraphicsFrameBufferContainer *frameBufferShadowMap;

		GraphicsNativeObjectContainer *cubeNativeObject;

		DirectionalLightShadowTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cubeOrients = nullptr;
			cubeOrientQty = 0;
			cameraOrient = nullptr;

			timer = nullptr;

			frameBuffer1 = nullptr;
			frameBufferShadowMap = nullptr;

			cubeNativeObject = nullptr;
		}

		virtual ~DirectionalLightShadowTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("Spotlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flashlight2.jpg"));

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));

			cubeOrientQty = 6;
			cubeOrients = new Orient3d[cubeOrientQty];
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].LoadIdentity();

				switch (i)
				{
				case 0:
					cubeOrients[i].p = Vector3d(0, 0, 0);
					break;
				case 1:
					cubeOrients[i].p = Vector3d(5, 1, 0);
					break;
				case 2:
					cubeOrients[i].p = Vector3d(-1, 5, 3);
					break;
				case 3:
					cubeOrients[i].p = Vector3d(-3, 2, 0);
					break;
				case 4:
					cubeOrients[i].p = Vector3d(1, -6, 0);
					break;
				case 5:
					cubeOrients[i].p = Vector3d(0, -4, -4);
					break;
				}
			}

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();

			scenePitchAngle = 0;
			sceneRotateAngle = 0;
			bufferQuadPitchAngle = 0;
			bufferQuadRotateAngle = 0;

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrients != nullptr)
			{
				delete[] cubeOrients;
				cubeOrients = nullptr;
				cubeOrientQty = 0;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (frameBuffer1 != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting frameBuffer1 resource {0}", (int)(frameBuffer1->frameBuffer)));
				delete frameBuffer1;
				frameBuffer1 = nullptr;
			}
			if (frameBufferShadowMap != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting frameBufferShadowMap resource {0}", (int)(frameBufferShadowMap->frameBuffer)));
				delete frameBufferShadowMap;
				frameBufferShadowMap = nullptr;
			}
			if (cubeNativeObject != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting cubeNativeObject resource {0}", (int)(cubeNativeObject->nativeObjectRef)));
				delete cubeNativeObject;
				cubeNativeObject = nullptr;
			}
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// rotate scene
				sceneRotateAngle += float(mouse.offsetX);
				while (sceneRotateAngle >= 360.0f)
					sceneRotateAngle -= 360.0f;
				scenePitchAngle += float(mouse.offsetY);
				if (scenePitchAngle > 90.0f)
					scenePitchAngle = 90.0f;
				if (scenePitchAngle < -90.0f)
					scenePitchAngle = -90.0f;
			}
			else if (mouse.leftButton.down)
			{
				// rotate buffer quad
				bufferQuadRotateAngle += float(mouse.offsetX);
				while (bufferQuadRotateAngle >= 360.0f)
					bufferQuadRotateAngle -= 360.0f;
				bufferQuadPitchAngle += float(mouse.offsetY);
				if (bufferQuadPitchAngle > 90.0f)
					bufferQuadPitchAngle = 90.0f;
				if (bufferQuadPitchAngle < -90.0f)
					bufferQuadPitchAngle = -90.0f;
			}
			mouse.ZeroOffsets();

			Animate(timer->GetElapsedTimeMSFloat());

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elaspedTimeMSf)
		{
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].Rotate(Vector3d(0, 1, 0), 360.0f / 6.0f / 1000.0f * p_elaspedTimeMSf); // rotate every 6 seconds
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			graphics->MakeCurrent();

			////////////////////////////////////
			// render to internal buffer texture

			Orient3d directionalLightOrient; // position doesn't matter, just the direction
			directionalLightOrient.LoadIdentity();
			directionalLightOrient.Rotate(directionalLightOrient.u, sceneRotateAngle);
			directionalLightOrient.Rotate(directionalLightOrient.l, scenePitchAngle);
			directionalLightOrient.p = directionalLightOrient.p + directionalLightOrient.f.ScalarMult(-10.0f);

			// render to a shadow map
			if (frameBufferShadowMap == nullptr)
				frameBufferShadowMap = new GraphicsFrameBufferContainer();
			// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			if (frameBufferShadowMap->frameBuffer == nullptr)
				graphics->CreateFrameBuffer(frameBufferShadowMap, GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, 600, 600);
			// set up renderbuffertexture as render target
			graphics->SetCurrentFrameBuffer(frameBufferShadowMap);
			// projection according to its dimensions
			float sceneScale = 0.13f;
			graphics->SetOrthoProjection(0.5 * sceneScale, 1000.0 * sceneScale); // 0.5 makes shadowmap more visible, scale far plane
			// clear to a specific color to keep it distinct
			graphics->ClearDepth();
			graphics->DefaultTransform();
			// set up camera position for scene
			graphics->ReverseTransform(directionalLightOrient);
			graphics->Scale(sceneScale, sceneScale, sceneScale); // scale to catch the whole scene (ortho)
			Matrix4d lightMVP = graphics->GetMVPMatrix(); // save for later
			// render the cubes to the shadowmap using a shader, capture their backsides to avoid shadow acne
			graphics->FlipCullFace();
			RenderCubes(graphics, true, nullptr, nullptr, nullptr, nullptr);
			graphics->FlipCullFace();
			// restore primary viewport as the render target
			graphics->FinishRender();

			// if RenderbuffertextureContainer is null, make a new one
			if (frameBuffer1 == nullptr)
				frameBuffer1 = new GraphicsFrameBufferContainer();
			// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			if (frameBuffer1->frameBuffer == nullptr)
				graphics->CreateFrameBuffer(frameBuffer1, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::Renderbuffer, 800, 600);
			//// set up renderbuffertexture as render target
			graphics->SetCurrentFrameBuffer(frameBuffer1);
			// projection according to its dimensions
			graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible
			// clear to a specific color to keep it distinct
			graphics->ClearScreen(GameColor(128, 128, 128));
			graphics->DefaultTransform();
			// set up camera position for scene
			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), sceneRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, scenePitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-20.0f);
			graphics->ReverseTransform(*cameraOrient);
			// render the cubes to the texture (different dimension and ratio than main viewport
			RenderCubes(graphics, false, &directionalLightOrient, &(cameraOrient->p), &lightMVP, frameBufferShadowMap->depthBufferTexture);
			// restore primary viewport as the render target
			graphics->FinishRender();

			// reset to main
			graphics->SetCurrentFrameBuffer();

			//////////////////////////////////
			// render to primary viewport now

			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible
			graphics->DefaultTransform();

			// set up camera position for scene
			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), sceneRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, scenePitchAngle);
			// MUST be identical to how shadow map was rendered!!!
			cameraOrient->p = cameraOrient->f.ScalarMult(-30.0f);
			cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(-8.0f, 0, 0));

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// render the cubes to the main viewport
			RenderCubes(graphics, false, &directionalLightOrient, &(cameraOrient->p), &lightMVP, frameBufferShadowMap->depthBufferTexture);

			// render the color framebuffer quad
			ModelVertex vertices[4] = { ModelVertex(Vector3d(400, 300, 0), 0), ModelVertex(Vector3d(-400, 300, 0), 0), ModelVertex(Vector3d(-400, -300, 0), 0), ModelVertex(Vector3d(400, -300, 0), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 1.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(0.0f, 0.0f) };
			GameColor color(255, 255, 255);

			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), bufferQuadRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, bufferQuadPitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-35.0f);
			cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(8.0f, -8.0f, 0));

			graphics->DefaultTransform();
			graphics->ReverseTransform(*cameraOrient);

			graphics->PushMatrix();
			graphics->Scale(0.02f, 0.02f, 0.02f);
			graphics->RenderFilledQuad(&color, 1, vertices, 4, false, frameBuffer1->colorBufferTexture, texCoords, 4);
			graphics->PopMatrix();

			// render the shadowmap texture quad using a shader
			// ll, ul, ur, lr as required
			Vector3d shadowMapVertices[4] = { Vector3d(300, -300, 0), Vector3d(300, 300, 0), Vector3d(-300, 300, 0), Vector3d(-300, -300, 0) };

			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), bufferQuadRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, bufferQuadPitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-35.0f);
			cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(8.0f, 8.0f, 0));

			graphics->DefaultTransform();
			graphics->ReverseTransform(*cameraOrient);
			Matrix4d mvp = graphics->GetMVPMatrix();
			Orient3d quadOrient;
			quadOrient.LoadIdentity();

			graphics->PushMatrix();
			GraphicsShaderOptions renderOptions;
			renderOptions.eyeMVPMatrixRef = &mvp;
			renderOptions.texture0Ref = frameBufferShadowMap->depthBufferTexture;
			renderOptions.vertexScale = 0.02f;
			renderOptions.modelWorldOrientRef = &quadOrient;
			//renderOptions.texture0Ref = frameBuffer1->colorBufferTexture;
			graphics->RenderShadowMap(shadowMapVertices, renderOptions);
			graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderCubes(GraphicsBase *graphics, bool p_renderToShadowMap, Orient3d *lightOrient, Vector3d *p_cameraPosition, Matrix4d *shadowMVP, GameTexture ^p_shadowMapTexture)
		{
			GraphicsShaderOptions shaderOptions;
			Matrix4d mvp;
			shaderOptions.eyeMVPMatrixRef = &mvp;
			shaderOptions.lighting = false;

			// prepare cube native object (they are all identical)
			if (cubeNativeObject == nullptr)
				cubeNativeObject = new GraphicsNativeObjectContainer();
			if (cubeNativeObject->nativeObjectRef == nullptr)
				cube->CreateNativeObject(graphics, cubeNativeObject, true);

			if (p_renderToShadowMap == false)
			{
				Vector3d ambientLight = Vector3d(0.2f, 0.2f, 0.2f);
				shaderOptions.ambientLightRef = &ambientLight;
				GraphicsShaderLight light;
				GraphicsShaderLightPtr lightRefs[1];
				lightRefs[0] = &light;
				light.SetDirectional(lightOrient->f, Vector3d(1, 1, 1)); // match what was used to render shadowmap (half the angle of the projection)
				//light.SetSpotlight(lightOrient->p, lightOrient->f, p_spotlightAngle / 2.0f, Vector3d(1, 1, 1), 0.00025f, 0.000125f); // match what was used to render shadowmap (half the angle of the projection)
				GraphicsShaderMaterial material;
				material.shininess = 50.0f;
				material.ambientReflectivity = Vector3d(1, 1, 1);
				material.diffuseReflectivity = Vector3d(1, 1, 1);
				material.specularReflectivity = Vector3d(1, 1, 1);
				shaderOptions.lighting = true;
				shaderOptions.lightQty = 1;
				shaderOptions.lightRefs = &(lightRefs[0]);
				shaderOptions.lightingMaterialRef = &material;
				shaderOptions.cameraPositionRef = p_cameraPosition;
				light.shadowMVP = *shadowMVP;
				light.shadowMapTextureRef = p_shadowMapTexture;
				shaderOptions.shadowMaps = true;

				for (int i = 0; i < cubeOrientQty; i++)
				{
					shaderOptions.modelWorldOrientRef = &cubeOrients[i];

					graphics->PushMatrix();
					// forward transform the cube
					mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeOrients[i]);
					//graphics->Transform(cubeOrients[i]);
					// render the cube
					//cube->Render(*graphics);
					graphics->RenderNativeObject(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}
			}
			else
			{
				for (int i = 0; i < cubeOrientQty; i++)
				{
					graphics->PushMatrix();
					// forward transform the cube
					mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeOrients[i]);
					graphics->Transform(cubeOrients[i]);
					// render the cube
					graphics->RenderNativeObjectToShadowMap(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}

			}
		}
	};

	public ref class TestFrustum : public GameBase
	{
	public:

		Orient3d *cameraOrient;
		Model3d *cube;
		Orient3d *cubeOrient;
		Frustum *frustumMain;
		Frustum *frustumTest;

		Frustum *frustum1;
		Frustum *frustum2;

		TestFrustum(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;
			cube = nullptr;
			cubeOrient = nullptr;
		}

		virtual ~TestFrustum()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();
			cubeOrient = new Orient3d();
			cubeOrient->LoadIdentity();
			cubeOrient->p = Vector3d(0, 0, 10);

			frustumMain = new Frustum();
			frustumTest = new Frustum();

			frustum1 = new Frustum();
			frustum2 = new Frustum();
			Frustum *frustum = nullptr;

			///////// past test code here///////////
			frustum = frustum1;
			frustum->Initialize();
			frustum->AddPlane(Vector3d(0.707106800000f, 0.000000000000f, 0.707106800000f));
			frustum->AddPlane(Vector3d(0.000000000000f, 0.928476700000f, 0.371390700000f));
			frustum->AddPlane(Vector3d(-0.707106800000f, 0.000000000000f, -0.707106800000f));
			frustum->AddPlane(Vector3d(0.000000000000f, -0.966234900000f, 0.257662600000f));
			frustum = frustum2;
			frustum->Initialize();
			frustum->AddPlane(Vector3d(-0.257662600000f, -0.966234900000f, 0.000000000000f));
			frustum->AddPlane(Vector3d(0.707106800000f, 0.000000000000f, 0.707106800000f));
			frustum->AddPlane(Vector3d(-0.371390700000f, 0.928476700000f, 0.000000000000f));
			frustum->AddPlane(Vector3d(-0.857493000000f, 0.000000000000f, -0.514495800000f));
			frustum->AddPlane(Vector3d(0.000000000000f, 0.928476700000f, 0.371390700000f));
			frustum->AddPlane(Vector3d(-0.707106800000f, 0.000000000000f, -0.707106800000f));
			////////////////////////////////////////

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (frustumMain != nullptr)
			{
				delete frustumMain;
				frustumMain = nullptr;
			}
			if (frustumTest != nullptr)
			{
				delete frustumTest;
				frustumTest = nullptr;
			}
			if (frustum1 != nullptr)
			{
				delete frustum1;
				frustum1 = nullptr;
			}
			if (frustum2 != nullptr)
			{
				delete frustum2;
				frustum2 = nullptr;
			}
		}

		void Destroy() override
		{
			DestroyGameData();

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			if (mouse.leftButton.down)
			{
				// apply mouse moves based on last collected movement
				cameraOrient->Rotate(cameraOrient->l, float(-mouse.offsetY) / 5.0f);
				cameraOrient->Rotate(Vector3d(0, 1, 0), float(mouse.offsetX) / 5.0f);
			}
			mouse.ZeroOffsets();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			//graphics->PushMatrix();
			//// forward transform the cube
			//graphics->Transform(*cubeOrient);
			//// render the cube
			//cube->Render(*graphics);
			//graphics->PopMatrix();

			Vector3d frustumTest1[5] = { Vector3d(6, -4, 1), Vector3d(5, 2, 1), Vector3d(-3, -3, 1), Vector3d(-3, -8, 1), Vector3d(-1, 10, 1) };
			Vector3d frustumTest2[3] = { Vector3d(1, 0, -1.0f), Vector3d(0, 1, -1.0f), Vector3d(1, 1, 1.0f)};

			// set up frustum main and render it with the old pipeline
			frustumMain->Initialize();
			frustumMain->AddPlane(cameraOrient->TransformToWorldSpaceOffset(Vector3d(5, 0, 1)));
			frustumMain->AddPlane(cameraOrient->TransformToWorldSpaceOffset(Vector3d(0, 5, 1)));
			frustumMain->AddPlane(cameraOrient->TransformToWorldSpaceOffset(Vector3d(-5, 0, 1)));
			frustumMain->AddPlane(cameraOrient->TransformToWorldSpaceOffset(Vector3d(0, -5, 1)));
			RenderFrustum(graphics, frustumMain, GameColor(255, 255, 255, 64));

			// render the other two frustums
			frustumTest->Initialize();
			for (int i = 0; i < 5; i++)
			{
				frustumTest->AddPlane(frustumTest1[i]);
			}
			RenderFrustum(graphics, frustumTest, GameColor(255, 255, 0, 64));
			frustumTest->Initialize();
			for (int i = 0; i < 3; i++)
			{
				frustumTest->AddPlane(frustumTest2[i]);
			}
			RenderFrustum(graphics, frustumTest, GameColor(255, 255, 0, 64));

			// now render the intersections
			frustumMain->CopyTo(frustumTest);
			for (int i = 0; i < 5; i++)
			{
				frustumTest->AddPlane(frustumTest1[i]);
			}
			RenderFrustum(graphics, frustumTest, GameColor(255, 0, 0, 64));
			frustumMain->CopyTo(frustumTest);
			for (int i = 0; i < 3; i++)
			{
				frustumTest->AddPlane(frustumTest2[i]);
			}
			RenderFrustum(graphics, frustumTest, GameColor(255, 0, 0, 64));

			RenderFrustum(graphics, frustum1, GameColor(255, 0, 0, 64));
			RenderFrustum(graphics, frustum2, GameColor(0, 0, 255, 64));

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderFrustum(GraphicsBase *p_graphics, Frustum *p_frustum, GameColor &p_color)
		{
			// assumes 3d render space reverse transformed to frustum origin

			ModelVertex vertices[16]; // up to 16

			if (p_frustum->IsEmpty())
				return;

			// just build a polygon out of the frustum segments and render it
			LinkedListEnumerator<FrustumPlane> frustumEnumerator = p_frustum->GetPlaneEnumerator();
			int vertexIndex = 0;
			while (frustumEnumerator.MoveNext())
			{
				vertices[vertexIndex].colorIndex = 0;
				vertices[vertexIndex].vertex = frustumEnumerator.Current()->data.intersectSegmentLeft.ScalarMult(100.0f); // works with camera at origin

				vertexIndex++;
				if (vertexIndex >= 16)
					throw gcnew System::Exception("Too many planes - max 16");
			}
			ModelSurface surface;
			surface.Initialize(vertexIndex, true);
			for (int i = 0; i < vertexIndex; i++)
				surface.SetVertexIndex(i, i);

			p_graphics->SetDepthWriteEnabled(false);
			p_graphics->RenderSurfaces(&p_color, 1, &surface, 1, vertices, vertexIndex);
			p_graphics->SetDepthWriteEnabled(true);
		}
	};

	public ref class PortalAlphaTest : public GameBase
	{
	public:

		Orient3d *cameraOrient;
		Orient3d *playerOrient;
		PortalMap *portalMap;

		bool showInstructions;
		bool lightingEnabled;
		bool useFullFrustum;
		bool anaglyph;

		GameTimer *timer;

		Vector3d *playerProposedWalkSpeed;
		Vector3d *playerWalkSpeed;
		float moveSpeed;
		float rotateAngleDegrees;
		float pitchAngleDegrees;
		bool playerFeetOnGround;
		float playerAcceleration;
		float playerOriginRotateAngleDegrees;
		Orient3d *playerOrigin; // reset location
	
		ColliderSet *colliderSet;

		GraphicsFrameBufferContainer *frameBufferCubeMaps;

		PortalAlphaTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;
			playerOrient = nullptr;
			portalMap = nullptr;
			timer = nullptr;

			showInstructions = true;
			lightingEnabled = false;
			useFullFrustum = false;

			playerProposedWalkSpeed = nullptr;
			playerWalkSpeed = nullptr;
			moveSpeed = 0.0f;
			rotateAngleDegrees = 0.0f;
			pitchAngleDegrees = 0.0f;
			playerOrigin = nullptr;

			frameBufferCubeMaps = nullptr;
			colliderSet = nullptr;
			anaglyph = false;
		}

		virtual ~PortalAlphaTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2BumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2_normal_map.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("TileDirt", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("tiledirt.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("TileDirtBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("tiledirt_normal.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Stonework", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Medieval_Stonework.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("StoneworkBumpMap", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Medieval_Stonework_normal.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Reticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"));
			GameContext::Instance->TextureRegistry.RegisterTexture("LeftReticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("LeftReticle.png"));
			GameContext::Instance->TextureRegistry.RegisterTexture("RightReticle", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("RightReticle.png"));

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			timer = new GameTimer();

			GameTexture ^wallTexture = GameContext::TextureRegistry.GetTexture("Brick2");
			GameTexture ^ceilingTexture = GameContext::TextureRegistry.GetTexture("Stonework");
			GameTexture ^floorTexture = GameContext::TextureRegistry.GetTexture("TileDirt");
			GameTexture ^wallBumpMap = GameContext::TextureRegistry.GetTexture("Brick2BumpMap");
			GameTexture ^ceilingBumpMap = GameContext::TextureRegistry.GetTexture("StoneworkBumpMap");
			GameTexture ^floorBumpMap = GameContext::TextureRegistry.GetTexture("TileDirtBumpMap");
			//GameTexture ^wallBumpMap = nullptr;
			//GameTexture ^ceilingBumpMap = nullptr;
			//GameTexture ^floorBumpMap = nullptr;

			portalMap = new PortalMap();

			bool simpleHall = false;
			if (simpleHall == true)
			{
				// 90 degree hallway with a corner
				portalMap->Initialize(2, 12, 1);

				// set up vertices
				portalMap->vertices[0].vertex = Vector3d(10, 0, -1);
				portalMap->vertices[1].vertex = Vector3d(10, 0, 0);
				portalMap->vertices[2].vertex = Vector3d(10, 1, -1);
				portalMap->vertices[3].vertex = Vector3d(10, 1, 0);

				portalMap->vertices[4].vertex = Vector3d(1, 0, -1);
				portalMap->vertices[5].vertex = Vector3d(0, 0, 0);
				portalMap->vertices[6].vertex = Vector3d(1, 1, -1);
				portalMap->vertices[7].vertex = Vector3d(0, 1, 0);

				portalMap->vertices[8].vertex = Vector3d(1, 0, -10);
				portalMap->vertices[9].vertex = Vector3d(0, 0, -10);
				portalMap->vertices[10].vertex = Vector3d(1, 1, -10);
				portalMap->vertices[11].vertex = Vector3d(0, 1, -10);
				for (int i = 0; i < portalMap->vertexQty; i++)
					portalMap->vertices[i].colorIndex = 0;

				// set up portal, facing +x+z frotn face at node 0, back at node 1
				portalMap->portals[0].Initialize(4);
				portalMap->portals[0].vertices[0] = Vector3d(1, 0, -1); //4
				portalMap->portals[0].vertices[1] = Vector3d(0, 0, 0); //5
				portalMap->portals[0].vertices[2] = Vector3d(0, 1, 0); //7
				portalMap->portals[0].vertices[3] = Vector3d(1, 1, -1); //6
				portalMap->portals[0].frontNodeIndex = 0;
				portalMap->portals[0].backNodeIndex = 1;
				portalMap->portals[0].Commit();

				// set up surfaces in nodes
				portalMap->nodes[0].Initialize(5, 1, 6);
				portalMap->nodes[0].portalIndices[0] = 0;

				// end
				portalMap->nodes[0].GetSurface(0)->Initialize(4, true);
				portalMap->nodes[0].GetSurface(0)->SetVertexIndex(0, 2);
				portalMap->nodes[0].GetSurface(0)->SetVertexIndex(1, 3);
				portalMap->nodes[0].GetSurface(0)->SetVertexIndex(2, 1);
				portalMap->nodes[0].GetSurface(0)->SetVertexIndex(3, 0);
				portalMap->nodes[0].GetSurface(0)->SetTexture0(wallTexture);
				portalMap->nodes[0].GetSurface(0)->SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[0].GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
				portalMap->nodes[0].GetSurface(0)->SetVertexTexCoords(1, 1.0f, 1.0f);
				portalMap->nodes[0].GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
				portalMap->nodes[0].GetSurface(0)->SetVertexTexCoords(3, 0.0f, 0.0f);
				// floor
				portalMap->nodes[0].GetSurface(1)->Initialize(4, true);
				portalMap->nodes[0].GetSurface(1)->SetVertexIndex(0, 5);
				portalMap->nodes[0].GetSurface(1)->SetVertexIndex(1, 4);
				portalMap->nodes[0].GetSurface(1)->SetVertexIndex(2, 0);
				portalMap->nodes[0].GetSurface(1)->SetVertexIndex(3, 1);
				portalMap->nodes[0].GetSurface(1)->SetTexture0(floorTexture);
				portalMap->nodes[0].GetSurface(1)->SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[0].GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f);
				portalMap->nodes[0].GetSurface(1)->SetVertexTexCoords(1, 1.0f, 1.0f);
				portalMap->nodes[0].GetSurface(1)->SetVertexTexCoords(2, 1.0f, 10.0f);
				portalMap->nodes[0].GetSurface(1)->SetVertexTexCoords(3, 0.0f, 10.0f);
				// ceiling
				portalMap->nodes[0].GetSurface(2)->Initialize(4, true);
				portalMap->nodes[0].GetSurface(2)->SetVertexIndex(0, 3);
				portalMap->nodes[0].GetSurface(2)->SetVertexIndex(1, 2);
				portalMap->nodes[0].GetSurface(2)->SetVertexIndex(2, 6);
				portalMap->nodes[0].GetSurface(2)->SetVertexIndex(3, 7);
				portalMap->nodes[0].GetSurface(2)->SetTexture0(ceilingTexture);
				portalMap->nodes[0].GetSurface(2)->SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[0].GetSurface(2)->SetVertexTexCoords(0, 0.0f, 10.0f);
				portalMap->nodes[0].GetSurface(2)->SetVertexTexCoords(1, 1.0f, 10.0f);
				portalMap->nodes[0].GetSurface(2)->SetVertexTexCoords(2, 1.0f, 1.0f);
				portalMap->nodes[0].GetSurface(2)->SetVertexTexCoords(3, 0.0f, 0.0f);
				// wall 1
				portalMap->nodes[0].GetSurface(3)->Initialize(4, true);
				portalMap->nodes[0].GetSurface(3)->SetVertexIndex(0, 1);
				portalMap->nodes[0].GetSurface(3)->SetVertexIndex(1, 3);
				portalMap->nodes[0].GetSurface(3)->SetVertexIndex(2, 7);
				portalMap->nodes[0].GetSurface(3)->SetVertexIndex(3, 5);
				portalMap->nodes[0].GetSurface(3)->SetTexture0(wallTexture);
				portalMap->nodes[0].GetSurface(3)->SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[0].GetSurface(3)->SetVertexTexCoords(0, 10.0f, 0.0f);
				portalMap->nodes[0].GetSurface(3)->SetVertexTexCoords(1, 10.0f, 1.0f);
				portalMap->nodes[0].GetSurface(3)->SetVertexTexCoords(2, 0.0f, 1.0f);
				portalMap->nodes[0].GetSurface(3)->SetVertexTexCoords(3, 0.0f, 0.0f);
				// wall 1
				portalMap->nodes[0].GetSurface(4)->Initialize(4, true);
				portalMap->nodes[0].GetSurface(4)->SetVertexIndex(0, 4);
				portalMap->nodes[0].GetSurface(4)->SetVertexIndex(1, 6);
				portalMap->nodes[0].GetSurface(4)->SetVertexIndex(2, 2);
				portalMap->nodes[0].GetSurface(4)->SetVertexIndex(3, 0);
				portalMap->nodes[0].GetSurface(4)->SetTexture0(wallTexture);
				portalMap->nodes[0].GetSurface(4)->SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[0].GetSurface(4)->SetVertexTexCoords(0, 9.0f, 0.0f);
				portalMap->nodes[0].GetSurface(4)->SetVertexTexCoords(1, 9.0f, 1.0f);
				portalMap->nodes[0].GetSurface(4)->SetVertexTexCoords(2, 0.0f, 1.0f);
				portalMap->nodes[0].GetSurface(4)->SetVertexTexCoords(3, 0.0f, 0.0f);
				portalMap->nodes[0].Commit(portalMap->vertices);

				portalMap->nodes[0].GetNodePlane(0)->Set(portalMap->vertices[0].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[0].GetNodePlane(1)->Set(portalMap->vertices[0].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[0].GetNodePlane(2)->Set(portalMap->vertices[0].vertex, Vector3d(0, 0, 1));
				portalMap->nodes[0].GetNodePlane(3)->Set(portalMap->vertices[7].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[0].GetNodePlane(4)->Set(portalMap->vertices[7].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[0].GetNodePlane(5)->Set(portalMap->vertices[7].vertex, Vector3d(0, 0, -1));

				portalMap->nodes[1].Initialize(5, 1, 6);
				portalMap->nodes[1].portalIndices[0] = 0;

				// end
				portalMap->nodes[1].GetSurface(0)->Initialize(4, true);
				portalMap->nodes[1].GetSurface(0)->SetVertexIndex(0, 11);
				portalMap->nodes[1].GetSurface(0)->SetVertexIndex(1, 10);
				portalMap->nodes[1].GetSurface(0)->SetVertexIndex(2, 8);
				portalMap->nodes[1].GetSurface(0)->SetVertexIndex(3, 9);
				portalMap->nodes[1].GetSurface(0)->SetTexture0(wallTexture);
				portalMap->nodes[1].GetSurface(0)->SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[1].GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
				portalMap->nodes[1].GetSurface(0)->SetVertexTexCoords(1, 1.0f, 1.0f);
				portalMap->nodes[1].GetSurface(0)->SetVertexTexCoords(2, 1.0f, 0.0f);
				portalMap->nodes[1].GetSurface(0)->SetVertexTexCoords(3, 0.0f, 0.0f);
				// floor
				portalMap->nodes[1].GetSurface(1)->Initialize(4, true);
				portalMap->nodes[1].GetSurface(1)->SetVertexIndex(0, 5);
				portalMap->nodes[1].GetSurface(1)->SetVertexIndex(1, 9);
				portalMap->nodes[1].GetSurface(1)->SetVertexIndex(2, 8);
				portalMap->nodes[1].GetSurface(1)->SetVertexIndex(3, 4);
				portalMap->nodes[1].GetSurface(1)->SetTexture0(floorTexture);
				portalMap->nodes[1].GetSurface(1)->SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[1].GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f);
				portalMap->nodes[1].GetSurface(1)->SetVertexTexCoords(1, 10.0f, 0.0f);
				portalMap->nodes[1].GetSurface(1)->SetVertexTexCoords(2, 10.0f, 1.0f);
				portalMap->nodes[1].GetSurface(1)->SetVertexTexCoords(3, 1.0f, 1.0f);
				// ceiling
				portalMap->nodes[1].GetSurface(2)->Initialize(4, true);
				portalMap->nodes[1].GetSurface(2)->SetVertexIndex(0, 6);
				portalMap->nodes[1].GetSurface(2)->SetVertexIndex(1, 10);
				portalMap->nodes[1].GetSurface(2)->SetVertexIndex(2, 11);
				portalMap->nodes[1].GetSurface(2)->SetVertexIndex(3, 7);
				portalMap->nodes[1].GetSurface(2)->SetTexture0(ceilingTexture);
				portalMap->nodes[1].GetSurface(2)->SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[1].GetSurface(2)->SetVertexTexCoords(0, 1.0f, 1.0f);
				portalMap->nodes[1].GetSurface(2)->SetVertexTexCoords(1, 10.0f, 1.0f);
				portalMap->nodes[1].GetSurface(2)->SetVertexTexCoords(2, 10.0f, 0.0f);
				portalMap->nodes[1].GetSurface(2)->SetVertexTexCoords(3, 0.0f, 0.0f);
				// wall 1
				portalMap->nodes[1].GetSurface(3)->Initialize(4, true);
				portalMap->nodes[1].GetSurface(3)->SetVertexIndex(0, 7);
				portalMap->nodes[1].GetSurface(3)->SetVertexIndex(1, 11);
				portalMap->nodes[1].GetSurface(3)->SetVertexIndex(2, 9);
				portalMap->nodes[1].GetSurface(3)->SetVertexIndex(3, 5);
				portalMap->nodes[1].GetSurface(3)->SetTexture0(wallTexture);
				portalMap->nodes[1].GetSurface(3)->SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[1].GetSurface(3)->SetVertexTexCoords(0, 0.0f, 1.0f);
				portalMap->nodes[1].GetSurface(3)->SetVertexTexCoords(1, 10.0f, 1.0f);
				portalMap->nodes[1].GetSurface(3)->SetVertexTexCoords(2, 10.0f, 0.0f);
				portalMap->nodes[1].GetSurface(3)->SetVertexTexCoords(3, 0.0f, 0.0f);
				// wall 2
				portalMap->nodes[1].GetSurface(4)->Initialize(4, true);
				portalMap->nodes[1].GetSurface(4)->SetVertexIndex(0, 10);
				portalMap->nodes[1].GetSurface(4)->SetVertexIndex(1, 6);
				portalMap->nodes[1].GetSurface(4)->SetVertexIndex(2, 4);
				portalMap->nodes[1].GetSurface(4)->SetVertexIndex(3, 8);
				portalMap->nodes[1].GetSurface(4)->SetTexture0(wallTexture);
				portalMap->nodes[1].GetSurface(4)->SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[1].GetSurface(4)->SetVertexTexCoords(0, 8.0f, 1.0f);
				portalMap->nodes[1].GetSurface(4)->SetVertexTexCoords(1, 0.0f, 1.0f);
				portalMap->nodes[1].GetSurface(4)->SetVertexTexCoords(2, 0.0f, 0.0f);
				portalMap->nodes[1].GetSurface(4)->SetVertexTexCoords(3, 8.0f, 0.0f);
				portalMap->nodes[1].Commit(portalMap->vertices);

				portalMap->nodes[1].GetNodePlane(0)->Set(portalMap->vertices[5].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[1].GetNodePlane(1)->Set(portalMap->vertices[5].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[1].GetNodePlane(2)->Set(portalMap->vertices[5].vertex, Vector3d(0, 0, -1));
				portalMap->nodes[1].GetNodePlane(3)->Set(portalMap->vertices[10].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[1].GetNodePlane(4)->Set(portalMap->vertices[10].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[1].GetNodePlane(5)->Set(portalMap->vertices[10].vertex, Vector3d(0, 0, 1));

				playerOrigin = new Orient3d();
				playerOrigin->LoadIdentity();
				playerOrigin->p = Vector3d(2.0f, 0.7f, -0.5f); // keep off portal for now until coincident case is handled
				playerOrigin->Rotate(playerOrigin->u, -90.0f);
				playerOriginRotateAngleDegrees = -90.0f;
			}
			else
			{
				// cross hallway with several portals and turns
				portalMap->Initialize(6, 28, 5);

				// vertices
				// floor of cross
				portalMap->vertices[0].vertex = Vector3d(0, 0, 0);
				portalMap->vertices[1].vertex = Vector3d(-1, 0, 0);
				portalMap->vertices[2].vertex = Vector3d(-1, 0, -1);
				portalMap->vertices[3].vertex = Vector3d(0, 0, -1);

				// ceiling of cross
				portalMap->vertices[4].vertex = Vector3d(0, 1, 0);
				portalMap->vertices[5].vertex = Vector3d(-1, 1, 0);
				portalMap->vertices[6].vertex = Vector3d(-1, 1, -1);
				portalMap->vertices[7].vertex = Vector3d(0, 1, -1);

				// left end
				portalMap->vertices[8].vertex = Vector3d(3, 0, -1);
				portalMap->vertices[9].vertex = Vector3d(3, 0, 0);
				portalMap->vertices[10].vertex = Vector3d(3, 1, -1);
				portalMap->vertices[11].vertex = Vector3d(3, 1, 0);

				// -z end
				portalMap->vertices[12].vertex = Vector3d(-1, 0, -4);
				portalMap->vertices[13].vertex = Vector3d(0, 0, -4);
				portalMap->vertices[14].vertex = Vector3d(-1, 1, -4);
				portalMap->vertices[15].vertex = Vector3d(0, 1, -4);

				// right end
				portalMap->vertices[16].vertex = Vector3d(-4, 0, 0);
				portalMap->vertices[17].vertex = Vector3d(-4, 0, -1);
				portalMap->vertices[18].vertex = Vector3d(-4, 1, 0);
				portalMap->vertices[19].vertex = Vector3d(-4, 1, -1);

				// +z corner
				portalMap->vertices[20].vertex = Vector3d(0, 0, 3);
				portalMap->vertices[21].vertex = Vector3d(0, 1, 3);
				portalMap->vertices[22].vertex = Vector3d(-1, 0, 4);
				portalMap->vertices[23].vertex = Vector3d(-1, 1, 4);

				// +z bend corner
				portalMap->vertices[24].vertex = Vector3d(3, 0, 3);
				portalMap->vertices[25].vertex = Vector3d(3, 0, 4);
				portalMap->vertices[26].vertex = Vector3d(3, 1, 3);
				portalMap->vertices[27].vertex = Vector3d(3, 1, 4);

				for (int i = 0; i < portalMap->vertexQty; i++)
					portalMap->vertices[i].colorIndex = 0;

				// portals
				portalMap->portals[0].Initialize(4);
				portalMap->portals[0].vertices[0] = portalMap->vertices[0].vertex;
				portalMap->portals[0].vertices[1] = portalMap->vertices[4].vertex;
				portalMap->portals[0].vertices[2] = portalMap->vertices[5].vertex;
				portalMap->portals[0].vertices[3] = portalMap->vertices[1].vertex;
				portalMap->portals[0].frontNodeIndex = 0;
				portalMap->portals[0].backNodeIndex = 4;
				portalMap->portals[1].Initialize(4);
				portalMap->portals[1].vertices[0] = portalMap->vertices[3].vertex;
				portalMap->portals[1].vertices[1] = portalMap->vertices[7].vertex;
				portalMap->portals[1].vertices[2] = portalMap->vertices[4].vertex;
				portalMap->portals[1].vertices[3] = portalMap->vertices[0].vertex;
				portalMap->portals[1].frontNodeIndex = 0;
				portalMap->portals[1].backNodeIndex = 1;
				portalMap->portals[2].Initialize(4);
				portalMap->portals[2].vertices[0] = portalMap->vertices[2].vertex;
				portalMap->portals[2].vertices[1] = portalMap->vertices[6].vertex;
				portalMap->portals[2].vertices[2] = portalMap->vertices[7].vertex;
				portalMap->portals[2].vertices[3] = portalMap->vertices[3].vertex;
				portalMap->portals[2].frontNodeIndex = 0;
				portalMap->portals[2].backNodeIndex = 2;
				portalMap->portals[3].Initialize(4);
				portalMap->portals[3].vertices[0] = portalMap->vertices[1].vertex;
				portalMap->portals[3].vertices[1] = portalMap->vertices[5].vertex;
				portalMap->portals[3].vertices[2] = portalMap->vertices[6].vertex;
				portalMap->portals[3].vertices[3] = portalMap->vertices[2].vertex;
				portalMap->portals[3].frontNodeIndex = 0;
				portalMap->portals[3].backNodeIndex = 3;
				portalMap->portals[4].Initialize(4);
				portalMap->portals[4].vertices[0] = portalMap->vertices[20].vertex;
				portalMap->portals[4].vertices[1] = portalMap->vertices[21].vertex;
				portalMap->portals[4].vertices[2] = portalMap->vertices[23].vertex;
				portalMap->portals[4].vertices[3] = portalMap->vertices[22].vertex;
				portalMap->portals[4].frontNodeIndex = 4;
				portalMap->portals[4].backNodeIndex = 5;

				// node surfaces and their portals
				// node 0 - cross center
				portalMap->nodes[0].Initialize(2, 4, 6);
				portalMap->nodes[0].portalIndices[0] = 0;
				portalMap->nodes[0].portalIndices[1] = 1;
				portalMap->nodes[0].portalIndices[2] = 2;
				portalMap->nodes[0].portalIndices[3] = 3;
				// floor
				portalMap->nodes[0].surfaces[0].Initialize(4, true);
				portalMap->nodes[0].surfaces[0].SetVertexIndex(0, 0);
				portalMap->nodes[0].surfaces[0].SetVertexIndex(1, 1);
				portalMap->nodes[0].surfaces[0].SetVertexIndex(2, 2);
				portalMap->nodes[0].surfaces[0].SetVertexIndex(3, 3);
				portalMap->nodes[0].surfaces[0].SetTexture0(floorTexture);
				portalMap->nodes[0].surfaces[0].SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[0].surfaces[0].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[0].surfaces[0].SetVertexTexCoords(1, -1, 0);
				portalMap->nodes[0].surfaces[0].SetVertexTexCoords(2, -1, -1);
				portalMap->nodes[0].surfaces[0].SetVertexTexCoords(3, 0, -1);
				// ceiling
				portalMap->nodes[0].surfaces[1].Initialize(4, true);
				portalMap->nodes[0].surfaces[1].SetVertexIndex(0, 7);
				portalMap->nodes[0].surfaces[1].SetVertexIndex(1, 6);
				portalMap->nodes[0].surfaces[1].SetVertexIndex(2, 5);
				portalMap->nodes[0].surfaces[1].SetVertexIndex(3, 4);
				portalMap->nodes[0].surfaces[1].SetTexture0(ceilingTexture);
				portalMap->nodes[0].surfaces[1].SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[0].surfaces[1].SetVertexTexCoords(0, 0, -1);
				portalMap->nodes[0].surfaces[1].SetVertexTexCoords(1, 1, -1);
				portalMap->nodes[0].surfaces[1].SetVertexTexCoords(2, 1, 0);
				portalMap->nodes[0].surfaces[1].SetVertexTexCoords(3, 0, 0);

				portalMap->nodes[0].GetNodePlane(0)->Set(portalMap->vertices[2].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[0].GetNodePlane(1)->Set(portalMap->vertices[2].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[0].GetNodePlane(2)->Set(portalMap->vertices[2].vertex, Vector3d(0, 0, 1));
				portalMap->nodes[0].GetNodePlane(3)->Set(portalMap->vertices[4].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[0].GetNodePlane(4)->Set(portalMap->vertices[4].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[0].GetNodePlane(5)->Set(portalMap->vertices[4].vertex, Vector3d(0, 0, -1));

				// node 1 - left alcove
				portalMap->nodes[1].Initialize(5, 1, 6);
				portalMap->nodes[1].portalIndices[0] = 1;
				// floor
				portalMap->nodes[1].surfaces[0].Initialize(4, true);
				portalMap->nodes[1].surfaces[0].SetVertexIndex(0, 3);
				portalMap->nodes[1].surfaces[0].SetVertexIndex(1, 8);
				portalMap->nodes[1].surfaces[0].SetVertexIndex(2, 9);
				portalMap->nodes[1].surfaces[0].SetVertexIndex(3, 0);
				portalMap->nodes[1].surfaces[0].SetTexture0(floorTexture);
				portalMap->nodes[1].surfaces[0].SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[1].surfaces[0].SetVertexTexCoords(0, 0, -1);
				portalMap->nodes[1].surfaces[0].SetVertexTexCoords(1, 3, -1);
				portalMap->nodes[1].surfaces[0].SetVertexTexCoords(2, 3, 0);
				portalMap->nodes[1].surfaces[0].SetVertexTexCoords(3, 0, 0);
				// ceiling
				portalMap->nodes[1].surfaces[1].Initialize(4, true);
				portalMap->nodes[1].surfaces[1].SetVertexIndex(0, 7);
				portalMap->nodes[1].surfaces[1].SetVertexIndex(1, 4);
				portalMap->nodes[1].surfaces[1].SetVertexIndex(2, 11);
				portalMap->nodes[1].surfaces[1].SetVertexIndex(3, 10);
				portalMap->nodes[1].surfaces[1].SetTexture0(ceilingTexture);
				portalMap->nodes[1].surfaces[1].SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[1].surfaces[1].SetVertexTexCoords(0, 0, -1);
				portalMap->nodes[1].surfaces[1].SetVertexTexCoords(1, 0, 0);
				portalMap->nodes[1].surfaces[1].SetVertexTexCoords(2, 3, 0);
				portalMap->nodes[1].surfaces[1].SetVertexTexCoords(3, 3, -1);
				// end
				portalMap->nodes[1].surfaces[2].Initialize(4, true);
				portalMap->nodes[1].surfaces[2].SetVertexIndex(0, 8);
				portalMap->nodes[1].surfaces[2].SetVertexIndex(1, 10);
				portalMap->nodes[1].surfaces[2].SetVertexIndex(2, 11);
				portalMap->nodes[1].surfaces[2].SetVertexIndex(3, 9);
				portalMap->nodes[1].surfaces[2].SetTexture0(wallTexture);
				portalMap->nodes[1].surfaces[2].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[1].surfaces[2].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[1].surfaces[2].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[1].surfaces[2].SetVertexTexCoords(2, 1, 1);
				portalMap->nodes[1].surfaces[2].SetVertexTexCoords(3, 1, 0);
				// wall 1
				portalMap->nodes[1].surfaces[3].Initialize(4, true);
				portalMap->nodes[1].surfaces[3].SetVertexIndex(0, 3);
				portalMap->nodes[1].surfaces[3].SetVertexIndex(1, 7);
				portalMap->nodes[1].surfaces[3].SetVertexIndex(2, 10);
				portalMap->nodes[1].surfaces[3].SetVertexIndex(3, 8);
				portalMap->nodes[1].surfaces[3].SetTexture0(wallTexture);
				portalMap->nodes[1].surfaces[3].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[1].surfaces[3].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[1].surfaces[3].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[1].surfaces[3].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[1].surfaces[3].SetVertexTexCoords(3, 3, 0);
				// wall 2
				portalMap->nodes[1].surfaces[4].Initialize(4, true);
				portalMap->nodes[1].surfaces[4].SetVertexIndex(0, 9);
				portalMap->nodes[1].surfaces[4].SetVertexIndex(1, 11);
				portalMap->nodes[1].surfaces[4].SetVertexIndex(2, 4);
				portalMap->nodes[1].surfaces[4].SetVertexIndex(3, 0);
				portalMap->nodes[1].surfaces[4].SetTexture0(wallTexture);
				portalMap->nodes[1].surfaces[4].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[1].surfaces[4].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[1].surfaces[4].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[1].surfaces[4].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[1].surfaces[4].SetVertexTexCoords(3, 3, 0);

				portalMap->nodes[1].GetNodePlane(0)->Set(portalMap->vertices[4].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[1].GetNodePlane(1)->Set(portalMap->vertices[4].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[1].GetNodePlane(2)->Set(portalMap->vertices[4].vertex, Vector3d(0, 0, -1));
				portalMap->nodes[1].GetNodePlane(3)->Set(portalMap->vertices[8].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[1].GetNodePlane(4)->Set(portalMap->vertices[8].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[1].GetNodePlane(5)->Set(portalMap->vertices[8].vertex, Vector3d(0, 0, 1));

				// node 2 - -z alcove
				portalMap->nodes[2].Initialize(5, 1, 6);
				portalMap->nodes[2].portalIndices[0] = 2;
				// floor
				portalMap->nodes[2].surfaces[0].Initialize(4, true);
				portalMap->nodes[2].surfaces[0].SetVertexIndex(0, 3);
				portalMap->nodes[2].surfaces[0].SetVertexIndex(1, 2);
				portalMap->nodes[2].surfaces[0].SetVertexIndex(2, 12);
				portalMap->nodes[2].surfaces[0].SetVertexIndex(3, 13);
				portalMap->nodes[2].surfaces[0].SetTexture0(floorTexture);
				portalMap->nodes[2].surfaces[0].SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[2].surfaces[0].SetVertexTexCoords(0, 0, -1);
				portalMap->nodes[2].surfaces[0].SetVertexTexCoords(1, -1, -1);
				portalMap->nodes[2].surfaces[0].SetVertexTexCoords(2, -1, -4);
				portalMap->nodes[2].surfaces[0].SetVertexTexCoords(3, 0, -4);
				// ceiling
				portalMap->nodes[2].surfaces[1].Initialize(4, true);
				portalMap->nodes[2].surfaces[1].SetVertexIndex(0, 7);
				portalMap->nodes[2].surfaces[1].SetVertexIndex(1, 15);
				portalMap->nodes[2].surfaces[1].SetVertexIndex(2, 14);
				portalMap->nodes[2].surfaces[1].SetVertexIndex(3, 6);
				portalMap->nodes[2].surfaces[1].SetTexture0(ceilingTexture);
				portalMap->nodes[2].surfaces[1].SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[2].surfaces[1].SetVertexTexCoords(0, 0, -1);
				portalMap->nodes[2].surfaces[1].SetVertexTexCoords(1, 0, -4);
				portalMap->nodes[2].surfaces[1].SetVertexTexCoords(2, -1, -4);
				portalMap->nodes[2].surfaces[1].SetVertexTexCoords(3, -1, -1);
				// end
				portalMap->nodes[2].surfaces[2].Initialize(4, true);
				portalMap->nodes[2].surfaces[2].SetVertexIndex(0, 12);
				portalMap->nodes[2].surfaces[2].SetVertexIndex(1, 14);
				portalMap->nodes[2].surfaces[2].SetVertexIndex(2, 15);
				portalMap->nodes[2].surfaces[2].SetVertexIndex(3, 13);
				portalMap->nodes[2].surfaces[2].SetTexture0(wallTexture);
				portalMap->nodes[2].surfaces[2].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[2].surfaces[2].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[2].surfaces[2].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[2].surfaces[2].SetVertexTexCoords(2, 1, 1);
				portalMap->nodes[2].surfaces[2].SetVertexTexCoords(3, 1, 0);
				// wall 1
				portalMap->nodes[2].surfaces[3].Initialize(4, true);
				portalMap->nodes[2].surfaces[3].SetVertexIndex(0, 2);
				portalMap->nodes[2].surfaces[3].SetVertexIndex(1, 6);
				portalMap->nodes[2].surfaces[3].SetVertexIndex(2, 14);
				portalMap->nodes[2].surfaces[3].SetVertexIndex(3, 12);
				portalMap->nodes[2].surfaces[3].SetTexture0(wallTexture);
				portalMap->nodes[2].surfaces[3].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[2].surfaces[3].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[2].surfaces[3].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[2].surfaces[3].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[2].surfaces[3].SetVertexTexCoords(3, 3, 0);
				// wall 2
				portalMap->nodes[2].surfaces[4].Initialize(4, true);
				portalMap->nodes[2].surfaces[4].SetVertexIndex(0, 13);
				portalMap->nodes[2].surfaces[4].SetVertexIndex(1, 15);
				portalMap->nodes[2].surfaces[4].SetVertexIndex(2, 7);
				portalMap->nodes[2].surfaces[4].SetVertexIndex(3, 3);
				portalMap->nodes[2].surfaces[4].SetTexture0(wallTexture);
				portalMap->nodes[2].surfaces[4].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[2].surfaces[4].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[2].surfaces[4].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[2].surfaces[4].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[2].surfaces[4].SetVertexTexCoords(3, 3, 0);

				portalMap->nodes[2].GetNodePlane(0)->Set(portalMap->vertices[2].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[2].GetNodePlane(1)->Set(portalMap->vertices[2].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[2].GetNodePlane(2)->Set(portalMap->vertices[2].vertex, Vector3d(0, 0, -1));
				portalMap->nodes[2].GetNodePlane(3)->Set(portalMap->vertices[15].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[2].GetNodePlane(4)->Set(portalMap->vertices[15].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[2].GetNodePlane(5)->Set(portalMap->vertices[15].vertex, Vector3d(0, 0, 1));

				// node 3 - right alcove
				portalMap->nodes[3].Initialize(5, 1, 6);
				portalMap->nodes[3].portalIndices[0] = 3;
				// floor
				portalMap->nodes[3].surfaces[0].Initialize(4, true);
				portalMap->nodes[3].surfaces[0].SetVertexIndex(0, 1);
				portalMap->nodes[3].surfaces[0].SetVertexIndex(1, 16);
				portalMap->nodes[3].surfaces[0].SetVertexIndex(2, 17);
				portalMap->nodes[3].surfaces[0].SetVertexIndex(3, 2);
				portalMap->nodes[3].surfaces[0].SetTexture0(floorTexture);
				portalMap->nodes[3].surfaces[0].SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[3].surfaces[0].SetVertexTexCoords(0, -1, 0);
				portalMap->nodes[3].surfaces[0].SetVertexTexCoords(1, -4, 0);
				portalMap->nodes[3].surfaces[0].SetVertexTexCoords(2, -4, -1);
				portalMap->nodes[3].surfaces[0].SetVertexTexCoords(3, -1, -1);
				// ceiling
				portalMap->nodes[3].surfaces[1].Initialize(4, true);
				portalMap->nodes[3].surfaces[1].SetVertexIndex(0, 5);
				portalMap->nodes[3].surfaces[1].SetVertexIndex(1, 6);
				portalMap->nodes[3].surfaces[1].SetVertexIndex(2, 19);
				portalMap->nodes[3].surfaces[1].SetVertexIndex(3, 18);
				portalMap->nodes[3].surfaces[1].SetTexture0(ceilingTexture);
				portalMap->nodes[3].surfaces[1].SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[3].surfaces[1].SetVertexTexCoords(0, -1, 0);
				portalMap->nodes[3].surfaces[1].SetVertexTexCoords(1, -1, -1);
				portalMap->nodes[3].surfaces[1].SetVertexTexCoords(2, -4, -1);
				portalMap->nodes[3].surfaces[1].SetVertexTexCoords(3, -4, 0);
				// end
				portalMap->nodes[3].surfaces[2].Initialize(4, true);
				portalMap->nodes[3].surfaces[2].SetVertexIndex(0, 16);
				portalMap->nodes[3].surfaces[2].SetVertexIndex(1, 18);
				portalMap->nodes[3].surfaces[2].SetVertexIndex(2, 19);
				portalMap->nodes[3].surfaces[2].SetVertexIndex(3, 17);
				portalMap->nodes[3].surfaces[2].SetTexture0(wallTexture);
				portalMap->nodes[3].surfaces[2].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[3].surfaces[2].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[3].surfaces[2].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[3].surfaces[2].SetVertexTexCoords(2, 1, 1);
				portalMap->nodes[3].surfaces[2].SetVertexTexCoords(3, 1, 0);
				// wall 1
				portalMap->nodes[3].surfaces[3].Initialize(4, true);
				portalMap->nodes[3].surfaces[3].SetVertexIndex(0, 1);
				portalMap->nodes[3].surfaces[3].SetVertexIndex(1, 5);
				portalMap->nodes[3].surfaces[3].SetVertexIndex(2, 18);
				portalMap->nodes[3].surfaces[3].SetVertexIndex(3, 16);
				portalMap->nodes[3].surfaces[3].SetTexture0(wallTexture);
				portalMap->nodes[3].surfaces[3].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[3].surfaces[3].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[3].surfaces[3].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[3].surfaces[3].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[3].surfaces[3].SetVertexTexCoords(3, 3, 0);
				// wall 2
				portalMap->nodes[3].surfaces[4].Initialize(4, true);
				portalMap->nodes[3].surfaces[4].SetVertexIndex(0, 17);
				portalMap->nodes[3].surfaces[4].SetVertexIndex(1, 19);
				portalMap->nodes[3].surfaces[4].SetVertexIndex(2, 6);
				portalMap->nodes[3].surfaces[4].SetVertexIndex(3, 2);
				portalMap->nodes[3].surfaces[4].SetTexture0(wallTexture);
				portalMap->nodes[3].surfaces[4].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[3].surfaces[4].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[3].surfaces[4].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[3].surfaces[4].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[3].surfaces[4].SetVertexTexCoords(3, 3, 0);

				portalMap->nodes[3].GetNodePlane(0)->Set(portalMap->vertices[2].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[3].GetNodePlane(1)->Set(portalMap->vertices[2].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[3].GetNodePlane(2)->Set(portalMap->vertices[2].vertex, Vector3d(0, 0, 1));
				portalMap->nodes[3].GetNodePlane(3)->Set(portalMap->vertices[18].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[3].GetNodePlane(4)->Set(portalMap->vertices[18].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[3].GetNodePlane(5)->Set(portalMap->vertices[18].vertex, Vector3d(0, 0, -1));

				// node 4 - +z hall
				portalMap->nodes[4].Initialize(4, 2, 6);
				portalMap->nodes[4].portalIndices[0] = 0;
				portalMap->nodes[4].portalIndices[1] = 4;
				// floor
				portalMap->nodes[4].surfaces[0].Initialize(4, true);
				portalMap->nodes[4].surfaces[0].SetVertexIndex(0, 0);
				portalMap->nodes[4].surfaces[0].SetVertexIndex(1, 20);
				portalMap->nodes[4].surfaces[0].SetVertexIndex(2, 22);
				portalMap->nodes[4].surfaces[0].SetVertexIndex(3, 1);
				portalMap->nodes[4].surfaces[0].SetTexture0(floorTexture);
				portalMap->nodes[4].surfaces[0].SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[4].surfaces[0].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[4].surfaces[0].SetVertexTexCoords(1, 0, 3);
				portalMap->nodes[4].surfaces[0].SetVertexTexCoords(2, -1, 4);
				portalMap->nodes[4].surfaces[0].SetVertexTexCoords(3, -1, 0);
				// ceiling
				portalMap->nodes[4].surfaces[1].Initialize(4, true);
				portalMap->nodes[4].surfaces[1].SetVertexIndex(0, 4);
				portalMap->nodes[4].surfaces[1].SetVertexIndex(1, 5);
				portalMap->nodes[4].surfaces[1].SetVertexIndex(2, 23);
				portalMap->nodes[4].surfaces[1].SetVertexIndex(3, 21);
				portalMap->nodes[4].surfaces[1].SetTexture0(ceilingTexture);
				portalMap->nodes[4].surfaces[1].SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[4].surfaces[1].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[4].surfaces[1].SetVertexTexCoords(1, -1, 0);
				portalMap->nodes[4].surfaces[1].SetVertexTexCoords(2, -1, 4);
				portalMap->nodes[4].surfaces[1].SetVertexTexCoords(3, 0, 3);
				// wall 1
				portalMap->nodes[4].surfaces[2].Initialize(4, true);
				portalMap->nodes[4].surfaces[2].SetVertexIndex(0, 22);
				portalMap->nodes[4].surfaces[2].SetVertexIndex(1, 23);
				portalMap->nodes[4].surfaces[2].SetVertexIndex(2, 5);
				portalMap->nodes[4].surfaces[2].SetVertexIndex(3, 1);
				portalMap->nodes[4].surfaces[2].SetTexture0(wallTexture);
				portalMap->nodes[4].surfaces[2].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[4].surfaces[2].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[4].surfaces[2].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[4].surfaces[2].SetVertexTexCoords(2, 4, 1);
				portalMap->nodes[4].surfaces[2].SetVertexTexCoords(3, 4, 0);
				// wall 2
				portalMap->nodes[4].surfaces[3].Initialize(4, true);
				portalMap->nodes[4].surfaces[3].SetVertexIndex(0, 0);
				portalMap->nodes[4].surfaces[3].SetVertexIndex(1, 4);
				portalMap->nodes[4].surfaces[3].SetVertexIndex(2, 21);
				portalMap->nodes[4].surfaces[3].SetVertexIndex(3, 20);
				portalMap->nodes[4].surfaces[3].SetTexture0(wallTexture);
				portalMap->nodes[4].surfaces[3].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[4].surfaces[3].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[4].surfaces[3].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[4].surfaces[3].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[4].surfaces[3].SetVertexTexCoords(3, 3, 0);

				portalMap->nodes[4].GetNodePlane(0)->Set(portalMap->vertices[4].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[4].GetNodePlane(1)->Set(portalMap->vertices[4].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[4].GetNodePlane(2)->Set(portalMap->vertices[4].vertex, Vector3d(0, 0, 1));
				portalMap->nodes[4].GetNodePlane(3)->Set(portalMap->vertices[22].vertex, Vector3d(1, 0, 0));
				portalMap->nodes[4].GetNodePlane(4)->Set(portalMap->vertices[22].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[4].GetNodePlane(5)->Set(portalMap->vertices[22].vertex, Vector3d(-1, 0, -1));

				// node 5 - +z bend
				portalMap->nodes[5].Initialize(5, 1, 6);
				portalMap->nodes[5].portalIndices[0] = 4;
				// floor
				portalMap->nodes[5].surfaces[0].Initialize(4, true);
				portalMap->nodes[5].surfaces[0].SetVertexIndex(0, 24);
				portalMap->nodes[5].surfaces[0].SetVertexIndex(1, 25);
				portalMap->nodes[5].surfaces[0].SetVertexIndex(2, 22);
				portalMap->nodes[5].surfaces[0].SetVertexIndex(3, 20);
				portalMap->nodes[5].surfaces[0].SetTexture0(floorTexture);
				portalMap->nodes[5].surfaces[0].SetBumpMapTexture(floorBumpMap);
				portalMap->nodes[5].surfaces[0].SetVertexTexCoords(0, 3, 3);
				portalMap->nodes[5].surfaces[0].SetVertexTexCoords(1, 3, 4);
				portalMap->nodes[5].surfaces[0].SetVertexTexCoords(2, -1, 4);
				portalMap->nodes[5].surfaces[0].SetVertexTexCoords(3, 0, 3);
				// ceiling
				portalMap->nodes[5].surfaces[1].Initialize(4, true);
				portalMap->nodes[5].surfaces[1].SetVertexIndex(0, 27);
				portalMap->nodes[5].surfaces[1].SetVertexIndex(1, 26);
				portalMap->nodes[5].surfaces[1].SetVertexIndex(2, 21);
				portalMap->nodes[5].surfaces[1].SetVertexIndex(3, 23);
				portalMap->nodes[5].surfaces[1].SetTexture0(ceilingTexture);
				portalMap->nodes[5].surfaces[1].SetBumpMapTexture(ceilingBumpMap);
				portalMap->nodes[5].surfaces[1].SetVertexTexCoords(0, 3, 4);
				portalMap->nodes[5].surfaces[1].SetVertexTexCoords(1, 3, 3);
				portalMap->nodes[5].surfaces[1].SetVertexTexCoords(2, 0, 3);
				portalMap->nodes[5].surfaces[1].SetVertexTexCoords(3, -1, 4);
				// end
				portalMap->nodes[5].surfaces[2].Initialize(4, true);
				portalMap->nodes[5].surfaces[2].SetVertexIndex(0, 24);
				portalMap->nodes[5].surfaces[2].SetVertexIndex(1, 26);
				portalMap->nodes[5].surfaces[2].SetVertexIndex(2, 27);
				portalMap->nodes[5].surfaces[2].SetVertexIndex(3, 25);
				portalMap->nodes[5].surfaces[2].SetTexture0(wallTexture);
				portalMap->nodes[5].surfaces[2].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[5].surfaces[2].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[5].surfaces[2].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[5].surfaces[2].SetVertexTexCoords(2, 1, 1);
				portalMap->nodes[5].surfaces[2].SetVertexTexCoords(3, 1, 0);
				// wall 1
				portalMap->nodes[5].surfaces[3].Initialize(4, true);
				portalMap->nodes[5].surfaces[3].SetVertexIndex(0, 25);
				portalMap->nodes[5].surfaces[3].SetVertexIndex(1, 27);
				portalMap->nodes[5].surfaces[3].SetVertexIndex(2, 23);
				portalMap->nodes[5].surfaces[3].SetVertexIndex(3, 22);
				portalMap->nodes[5].surfaces[3].SetTexture0(wallTexture);
				portalMap->nodes[5].surfaces[3].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[5].surfaces[3].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[5].surfaces[3].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[5].surfaces[3].SetVertexTexCoords(2, 4, 1);
				portalMap->nodes[5].surfaces[3].SetVertexTexCoords(3, 4, 0);
				// wall 2
				portalMap->nodes[5].surfaces[4].Initialize(4, true);
				portalMap->nodes[5].surfaces[4].SetVertexIndex(0, 20);
				portalMap->nodes[5].surfaces[4].SetVertexIndex(1, 21);
				portalMap->nodes[5].surfaces[4].SetVertexIndex(2, 26);
				portalMap->nodes[5].surfaces[4].SetVertexIndex(3, 24);
				portalMap->nodes[5].surfaces[4].SetTexture0(wallTexture);
				portalMap->nodes[5].surfaces[4].SetBumpMapTexture(wallBumpMap);
				portalMap->nodes[5].surfaces[4].SetVertexTexCoords(0, 0, 0);
				portalMap->nodes[5].surfaces[4].SetVertexTexCoords(1, 0, 1);
				portalMap->nodes[5].surfaces[4].SetVertexTexCoords(2, 3, 1);
				portalMap->nodes[5].surfaces[4].SetVertexTexCoords(3, 3, 0);

				portalMap->nodes[5].GetNodePlane(0)->Set(portalMap->vertices[22].vertex, Vector3d(1, 0, 1));
				portalMap->nodes[5].GetNodePlane(1)->Set(portalMap->vertices[22].vertex, Vector3d(0, 1, 0));
				portalMap->nodes[5].GetNodePlane(2)->Set(portalMap->vertices[22].vertex, Vector3d(0, 0, -1));
				portalMap->nodes[5].GetNodePlane(3)->Set(portalMap->vertices[26].vertex, Vector3d(-1, 0, 0));
				portalMap->nodes[5].GetNodePlane(4)->Set(portalMap->vertices[26].vertex, Vector3d(0, -1, 0));
				portalMap->nodes[5].GetNodePlane(5)->Set(portalMap->vertices[26].vertex, Vector3d(0, 0, 1));

				// calculate normals, etc.
				portalMap->Commit();

				playerOrigin = new Orient3d();
				playerOrigin->LoadIdentity();
				playerOrigin->p = Vector3d(-0.5f, 0.7f, -0.5f); // center of cross
				//playerOrigin->p = Vector3d(-0.9f, 0.7f, 3.9f); // in portal corner - not able to test - containment keeps fixing it
				playerOriginRotateAngleDegrees = 0.0f;
			}

			colliderSet = new ColliderSet();
			portalMap->MakeColliderSet(*colliderSet);

			// now establish player origin
			playerOrient = new Orient3d();
			playerOrient->Set(*playerOrigin);
			rotateAngleDegrees = playerOriginRotateAngleDegrees;
			playerWalkSpeed = new Vector3d();
			playerWalkSpeed->Set(0, 0, 0);
			playerProposedWalkSpeed = new Vector3d();
			playerProposedWalkSpeed->Set(0, 0, 0);
			playerFeetOnGround = true;
			playerAcceleration = 0.0000075f;

			frameBufferCubeMaps = new GraphicsFrameBufferContainer[2];

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (playerOrient != nullptr)
			{
				delete playerOrient;
				playerOrient = nullptr;
			}
			if (playerOrigin != nullptr)
			{
				delete playerOrigin;
				playerOrigin = nullptr;
			}
			if (portalMap != nullptr)
			{
				delete portalMap;
				portalMap = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (playerProposedWalkSpeed != nullptr)
			{
				delete playerProposedWalkSpeed;
				playerProposedWalkSpeed = nullptr;
			}
			if (playerWalkSpeed != nullptr)
			{
				delete playerWalkSpeed;
				playerWalkSpeed = nullptr;
			}
			if (frameBufferCubeMaps != nullptr)
			{
				delete [] frameBufferCubeMaps;
				frameBufferCubeMaps = nullptr;
			}
			if (colliderSet != nullptr)
			{
				delete colliderSet;
				colliderSet = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			if (keyboardKeys.GetKey(27)->IsPressed())
			{
				// show mouse if it was hidden
				if (mouse.IsVisible() == false)
					mouse.Show();

				return false;
			}

			timer->Poll();

			// handle keyboard
			// assume feet always on ground, change this if jump - see DungeonHall
			playerProposedWalkSpeed->Set(0, 0, 0);
			float walkSpeed = 0.00586f / 10.0f * 2.0f;  // brisk 4 miles per hour, double (8mph hustle)
			float runSpeed = 0.022f / 10.0f; // 15 miles per hour
			float moveSpeed = walkSpeed;
			if (mouse.IsVisible() == false)
			{
				float mouseSensitivity = 0.25f;
				rotateAngleDegrees += (float(mouse.offsetX) * mouseSensitivity);
				while (rotateAngleDegrees >= 360.0f)
					rotateAngleDegrees -= 360.0f;
				while (rotateAngleDegrees < 0.0f)
					rotateAngleDegrees += 360.0f;
				pitchAngleDegrees -= (float(mouse.offsetY) * mouseSensitivity);
				if (pitchAngleDegrees > 90.0f)
					pitchAngleDegrees = 90.0f;
				if (pitchAngleDegrees < -90.0f)
					pitchAngleDegrees = -90.0f;

				// apply mouse controls
				// create new orientation for player
				Vector3d oldP = playerOrient->p;
				playerOrient->LoadIdentity();
				playerOrient->Rotate(playerOrient->u, rotateAngleDegrees);
				playerOrient->Rotate(playerOrient->l, pitchAngleDegrees);
				playerOrient->p = oldP;

				Vector3d horizontalForward = playerOrient->f;
				Vector3d sideways = playerOrient->l;
				horizontalForward.y = 0.0f;
				if (horizontalForward.Normalize() == false)
				{
					// use u for forward
					horizontalForward = playerOrient->u.ScalarMult(-1.0f);
					horizontalForward.Normalize();
				}
				sideways.Normalize(); // should always be good
				if (keyboardKeys.GetKey('A')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed + sideways);
				}
				if (keyboardKeys.GetKey('D')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed - sideways);
				}
				if (keyboardKeys.GetKey('W')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed + horizontalForward);
				}
				if (keyboardKeys.GetKey('S')->IsPressed() == true && playerFeetOnGround == true)
				{
					playerProposedWalkSpeed->Set(*playerProposedWalkSpeed - horizontalForward);
				}
				if (keyboardKeys.GetKey(16)->IsPressed() == true) // run
				{
					moveSpeed = runSpeed;
				}
				//if (keyboardKeys.GetKey(32)->IsPressed() == true && playerFeetOnGround == true) // jump
				//{
				//	if (keyboardKeys.GetKey(16)->IsPressed() == true)
				//		playerFallSpeed->Set(Vector3d(0, 0.0013f, 0));
				//	else
				//		playerFallSpeed->Set(Vector3d(0, 0.001f, 0));
				//	playerFeetOnGround = false;
				//}
			}
			if (keyboardKeys.GetKey('R')->IsClicked() == true)
			{
				// reset!
				//playerFallSpeed->Set(0, 0, 0);
				playerOrient->LoadIdentity();
				playerOrient->Set(*playerOrigin); // keep off portal for now until coincident case is handled
				pitchAngleDegrees = 0.0f;
				rotateAngleDegrees = playerOriginRotateAngleDegrees;
				playerWalkSpeed->Set(0, 0, 0);
			}
			if (keyboardKeys.GetKey('L')->IsClicked() == true)
			{
				lightingEnabled = !lightingEnabled;
			}
			if (keyboardKeys.GetKey('F')->IsClicked() == true)
			{
				useFullFrustum = !useFullFrustum;
			}
			if (keyboardKeys.GetKey(186)->IsClicked() == true) // semicolon
			{
				if (mouse.IsVisible() == false)
					mouse.Show();
				else
					mouse.Hide();
			}
			if (keyboardKeys.GetKey('Z')->IsClicked() == true)
			{
				showInstructions = !showInstructions;
			}
			if (keyboardKeys.GetKey(13)->IsClicked() == true) // click to prevent autorepeat
			{
				anaglyph = !anaglyph;
			}
			if (mouse.IsVisible() == false && appActivated == true)
			{
				// move it to the middle of the viewport (should be screen position)
				GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
				mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
			}
			mouse.ZeroOffsets();
			keyboardKeys.ClearClicked();

			// apply move controls
			// slow down player if they are moving backwards
			if ((*playerProposedWalkSpeed * playerOrient->f) < -0.01f && moveSpeed == runSpeed)
				playerProposedWalkSpeed->Set(playerProposedWalkSpeed->ScalarMult(0.75f));

			float timeElapsedMSf = timer->GetElapsedTimeMSFloat();
			while (timeElapsedMSf > 0.0f)
			{
				if (timeElapsedMSf >= 16.0f)
				{
					Animate(16.0f, *playerProposedWalkSpeed, moveSpeed);
					timeElapsedMSf -= 16.0f;
				}
				else
				{
					Animate(timeElapsedMSf, *playerProposedWalkSpeed, moveSpeed);
					timeElapsedMSf = 0.0f;
				}
			}

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elapsedTimeMSf, Vector3d &p_moveVector, float p_moveSpeed)
		{
			Vector3d proposedMoveVector = p_moveVector.ScalarMult(p_moveSpeed);
			Vector3d moveVectorOffset = proposedMoveVector - *playerWalkSpeed;
			float moveVectorOffsetMagnitude = moveVectorOffset.Magnitude();
			if ((playerAcceleration * p_elapsedTimeMSf) >= moveVectorOffsetMagnitude)
				*playerWalkSpeed = proposedMoveVector;
			else
				*playerWalkSpeed = *playerWalkSpeed + moveVectorOffset.ScalarMult((playerAcceleration * p_elapsedTimeMSf) / moveVectorOffsetMagnitude);

			playerOrient->p = playerOrient->p + playerWalkSpeed->ScalarMult(p_elapsedTimeMSf);
			//playerOrient->p = playerOrient->p + playerFallSpeed->ScalarMult(p_elapsedTimeMSf) + Vector3d(0, -1, 0).ScalarMult(0.5f * gravityPerMSMS * p_elapsedTimeMSf * p_elapsedTimeMSf);
			//playerFallSpeed->Set(*playerFallSpeed + Vector3d(0, -1, 0).ScalarMult(gravityPerMSMS * p_elapsedTimeMSf));

			colliderSet->ContainSphere(playerOrient->p, 0.1f); // no need to recede a little here - player will always be contained - can't fail because max move is 16ms always
		}

		void PerformRender() override
		{
			float nearPlane = 0.01f;
			float farPlane = 1000.0f;

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			graphics->MakeCurrent();

			if (frameBufferCubeMaps[0].frameBuffer == nullptr)
				graphics->CreateFrameBuffer(&frameBufferCubeMaps[0], GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, 512, 512, 6);
			if (frameBufferCubeMaps[1].frameBuffer == nullptr)
				graphics->CreateFrameBuffer(&frameBufferCubeMaps[1], GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, 512, 512, 6);

			GraphicsShaderOptions shaderOptions;
			Matrix4d mvp = graphics->GetMVPMatrix();
			shaderOptions.eyeMVPMatrixRef = &mvp;
			Orient3d worldOrient;
			worldOrient.LoadIdentity();
			shaderOptions.modelWorldOrientRef = &worldOrient;
			shaderOptions.lighting = lightingEnabled;
			// todo: lights, material
			GraphicsShaderMaterial material;
			material.ambientReflectivity = Vector3d(1, 1, 1);
			material.diffuseReflectivity = Vector3d(1, 1, 1);
			material.specularReflectivity = Vector3d(0.1f, 0.1f, 0.1f);
			material.shininess = 50.0f;
			//material.specularReflectivity = Vector3d(1.0f, 1.0f, 1.0f);
			//material.shininess = 512.0f;
			GraphicsShaderLight lights[8];
			GraphicsShaderLightPtr lightRefs[8];
			for (int i = 0; i < 8; i++)
				lightRefs[i] = &lights[i];
			shaderOptions.lightQty = 2;
			shaderOptions.lightingMaterialRef = &material;
			shaderOptions.lightRefs = lightRefs;
			Vector3d ambientColor(0, 0, 0);
			shaderOptions.ambientLightRef = &ambientColor;
			Vector3d cameraPosition = playerOrient->p;
			shaderOptions.cameraPositionRef = &cameraPosition;
			lights[0].SetPoint(Vector3d(-1.05f, 0.5f, -0.5f), Vector3d(2, 2, 2), 0.25f, 0.125f);
			//lights[0].SetPoint(Vector3d(-1.05f, 0.5f, -0.5f), Vector3d(0, 0, 0), 0.25f, 0.125f);
			lights[0].shadowMapFrameBufferRef = &frameBufferCubeMaps[0];
			lights[0].shadowMapTextureRef = frameBufferCubeMaps[0].depthBufferTexture;
			lights[1].SetPoint(Vector3d(2.5f, 0.5f, 3.5f), Vector3d(1, 1, 1), 0.25f, 0.125f);
			lights[1].shadowMapFrameBufferRef = &frameBufferCubeMaps[1];
			lights[1].shadowMapTextureRef = frameBufferCubeMaps[1].depthBufferTexture;
			Matrix4d lightMVPs[6];
			shaderOptions.shadowMaps = true;

			// todo: figure out which lights will be used and populate the lights array with them

			PortalParseResultList nodesSeen[2];

			if (shaderOptions.lighting == true && shaderOptions.shadowMaps == true)
			{
				graphics->FlipCullFace();

				// for each light
				for (int i = 0; i < shaderOptions.lightQty; i++)
				{
					graphics->SetCurrentFrameBuffer(lights[i].shadowMapFrameBufferRef);
					graphics->ClearDepth();

					// prep light shadows
					if (lights[i].shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
					{
						GraphicsUtilities::PreparePointLightShadowCubeMapMVPs(graphics, shaderOptions, shaderOptions.lightRefs[i], lightMVPs, nearPlane, farPlane);
						graphics->ClearDepth();
						Frustum frustumLight;
						frustumLight.Initialize();
						frustumLight.SetOrigin(lights[i].worldPosition);
						int x = 0;
						portalMap->PopulateNodesToRender(nodesSeen[i], &frustumLight, x); // leave null so that it renders the map in all directions
						LinkedListEnumerator<PortalNodeIndex> lightNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(nodesSeen[i].GetFirstNode()->data.nodes);
						while (lightNodeEnumerator.MoveNext())
						{
							portalMap->RenderNodeToCubeMap(graphics, lightNodeEnumerator.Current()->data.index, shaderOptions);
						}
					}
					else
					{
						// todo:
						// prep spotlights and directional
					}
				}
				// done with each light

				graphics->FlipCullFace();
			}

			////////////////////////
			// draw portal map!
			graphics->SetCurrentFrameBuffer();
			graphics->ClearScreen(GameColor(0, 128, 128));

			if (anaglyph == false)
			{
				graphics->SetPerspectiveProjection(45.0f, nearPlane, farPlane); // match near and far on shadowmaps
				graphics->DefaultTransform();

				DrawElements(graphics, shaderOptions, nodesSeen, false, nullptr);

				DrawDotHud(graphics);
			}
			else
			{
				StereoscopicCamera stereoCamera(0.2f, 0.031f);

				// left (red)
				graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, nearPlane, farPlane, stereoCamera); // match near and far on shadowmaps
				graphics->DefaultTransformStereoscopicLeft(stereoCamera);
				graphics->ColorMask(true, false, false, false);
				DrawElements(graphics, shaderOptions, nodesSeen, true, &stereoCamera);
				DrawAnaglyphHud(graphics, &stereoCamera, true);

				graphics->ClearDepth();

				// right (cyan)
				graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, nearPlane, farPlane, stereoCamera); // match near and far on shadowmaps
				graphics->DefaultTransformStereoscopicRight(stereoCamera);
				graphics->ColorMask(false, true, true, false);
				DrawElements(graphics, shaderOptions, nodesSeen, false, &stereoCamera);
				DrawAnaglyphHud(graphics, &stereoCamera, false);

				// restore
				graphics->ColorMask(true, true, true, true);
			}

			////////////////////
			// HUD, etc.
			// draw normally now
			graphics->SetPerspectiveProjection(45.0f, nearPlane, farPlane); // match near and far on shadowmaps
			graphics->DefaultTransform();

			if (showInstructions == true)
				ShowInstructions(graphics);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawElements(GraphicsBase *graphics, GraphicsShaderOptions %p_shaderOptions, PortalParseResultList *p_nodesSeen, bool p_left, StereoscopicCamera *p_camera)
		{
			// reverse transform the camera
			cameraOrient->Set(*playerOrient);
			graphics->ReverseTransform(*cameraOrient);

			*(p_shaderOptions.eyeMVPMatrixRef) = graphics->GetMVPMatrix();

			if (p_camera != nullptr)
			{
				if (p_left == true)
					*(p_shaderOptions.cameraPositionRef) = p_camera->CorrectedEyePositionLeft(*cameraOrient);
				else
					*(p_shaderOptions.cameraPositionRef) = p_camera->CorrectedEyePositionRight(*cameraOrient);
			}
			// set up frustum main and render it with the old pipeline
			Frustum frustumMain;
			float partialFrustumFactor = 0.5f;
			if (p_camera == nullptr)
			{
				// normal
				if (useFullFrustum == false)
				{
					graphics->BuildViewFrustum(*cameraOrient, &frustumMain, partialFrustumFactor);
				}
				else
				{
					graphics->BuildViewFrustum(*cameraOrient, &frustumMain);
				}
			}
			else
			{
				// anaglyph
				if (useFullFrustum == false)
				{
					graphics->BuildViewFrustum(*cameraOrient, &frustumMain, partialFrustumFactor, p_left, p_camera);
				}
				else
				{
					graphics->BuildViewFrustum(*cameraOrient, &frustumMain, 1.0f, p_left, p_camera);
				}
			}

			PortalParseResultList nodesToRender;
			int x;
			portalMap->PopulateNodesToRender(nodesToRender, &frustumMain, x);

			// render the nodes

			LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(nodesToRender.GetFirstNode()->data.nodes);
			while (nodeEnumerator.MoveNext())
			{
				bool okToUseLight = false;
				// see if light 1 can see the node, and if it can't, don't use it
				if (p_nodesSeen[1].GetFirstNode() != nullptr)
				{
					LinkedListEnumerator<PortalNodeIndex> lightNodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(p_nodesSeen[1].GetFirstNode()->data.nodes);
					while (lightNodeEnumerator.MoveNext())
					{
						if (lightNodeEnumerator.Current()->data.index == nodeEnumerator.Current()->data.index)
						{
							okToUseLight = true;
							break;
						}
					}
				}

				if (okToUseLight == true)
					p_shaderOptions.lightQty = 2;
				else
					p_shaderOptions.lightQty = 1;

				portalMap->RenderNode(graphics, nodeEnumerator.Current()->data.index, p_shaderOptions);
			}

			if (useFullFrustum == false)
				RenderFrustum(graphics, &frustumMain, GameColor(255, 128, 128, 64));

			// restore light usage
			p_shaderOptions.lightQty = 2;
		}

		void RenderFrustum(GraphicsBase *p_graphics, Frustum *p_frustum, GameColor &p_color)
		{
			// assumes 3d render space reverse transformed to frustum origin

			ModelVertex vertices[16]; // up to 16

			if (p_frustum->IsEmpty() == true)
				return;

			// just build a polygon out of the frustum segments and render it
			LinkedListEnumerator<FrustumPlane> frustumEnumerator = p_frustum->GetPlaneEnumerator();
			int vertexIndex = 0;
			while (frustumEnumerator.MoveNext())
			{
				vertices[vertexIndex].colorIndex = 0;
				vertices[vertexIndex].vertex = p_frustum->origin + frustumEnumerator.Current()->data.intersectSegmentLeft.ScalarMult(100.0f); // render in far distance so that anaglyph gets a good representation

				vertexIndex++;
				if (vertexIndex >= 16)
					throw gcnew System::Exception("Too many planes - max 16");
			}
			ModelSurface surface;
			surface.Initialize(vertexIndex, true);
			for (int i = 0; i < vertexIndex; i++)
				surface.SetVertexIndex(i, i);

			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);
			p_graphics->RenderSurfaces(&p_color, 1, &surface, 1, vertices, vertexIndex);
			p_graphics->SetDepthWriteEnabled(true);
			p_graphics->SetDepthTestEnabled(true);
		}

		void DrawDotHud(GraphicsBase *p_graphics)
		{
			p_graphics->SetPerspectiveProjection(45.0f, 0.01f, 1000.0f);

			p_graphics->PushMatrix();

			// don't worry about anaglyph, just put it all at the convergence plane by rendering straight to the buffer
			p_graphics->DefaultTransform();
			p_graphics->Translate(0.0f, 0.0f, 1.0f);
			p_graphics->Scale(0.003f, 0.003f, 0.003f);
			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);

			GameColor color = GameColor(255, 255, 255);
			ModelVertex vertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			p_graphics->RenderFilledQuad(&color, 1, vertices, 4, true, GameContext::TextureRegistry.GetTexture("Reticle"), texCoords, 4);

			p_graphics->SetDepthTestEnabled(true);
			p_graphics->SetDepthWriteEnabled(true);

			p_graphics->PopMatrix();
		}

		void DrawAnaglyphHud(GraphicsBase *p_graphics, StereoscopicCamera *p_camera, bool p_left)
		{
			p_graphics->PushMatrix();

			// don't worry about anaglyph, just put it all at the convergence plane by rendering straight to the buffer
			// 2.5 feet out, far enough to side to allow converging out to deep field
			// render them at far depth in the middle of the viewport where eyes would look at distant objects
			if (p_left == true)
			{
				p_graphics->DefaultTransformStereoscopicLeft(*p_camera);
				p_graphics->Translate(0.0f, 0.0f, 100.0f);
			}
			else
			{
				p_graphics->DefaultTransformStereoscopicRight(*p_camera);
				p_graphics->Translate(0.0f, 0.0f, 100.0f);
			}
			p_graphics->Scale(1.5f, 1.5f, 1.5f); // surprising it renders so large as a 2x2 but whatever.

			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);

			GameColor color = GameColor(255, 255, 255);
			ModelVertex vertices[4] = { ModelVertex(Vector3d(1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, 1.0f, 0.0f), 0), ModelVertex(Vector3d(-1.0f, -1.0f, 0.0f), 0), ModelVertex(Vector3d(1.0f, -1.0f, 0.0f), 0) };
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			if (p_left == true)
				p_graphics->RenderFilledQuad(&color, 1, vertices, 4, true, GameContext::TextureRegistry.GetTexture("LeftReticle"), texCoords, 4);
			else
				p_graphics->RenderFilledQuad(&color, 1, vertices, 4, true, GameContext::TextureRegistry.GetTexture("RightReticle"), texCoords, 4);

			p_graphics->SetDepthTestEnabled(true);
			p_graphics->SetDepthWriteEnabled(true);

			p_graphics->PopMatrix();
		}

		void ShowInstructions(GraphicsBase *p_graphics)
		{
			p_graphics->Set2dWindowProjection();
			p_graphics->SetDepthTestEnabled(false);
			p_graphics->SetDepthWriteEnabled(false);

			GameFont ^font = GameContext::FontRegistry.GetFont("Info");

			String ^instructions = R"(; - toggle player mouse and move controls (hides mouse)
					W,A,S,D - move
					mouse - look
					SHIFT - run

					F - toggle partial/full screen frustum
					L - toggle lighting
					R - reset player position to start
					ENTER - toggle anaglyph

					Z - toggle these instructions)";

			p_graphics->RenderTextBlock(instructions, font, 10, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight() - font->GetTextBlockSize(instructions).Y - 10, GameColor(255, 255, 128));

			p_graphics->SetDepthTestEnabled(true);
			p_graphics->SetDepthWriteEnabled(true);
		}

	};

	public class DungeonCell
	{
	public:
		System::Drawing::RectangleF rect;
		bool rock;
		bool bordersRoom;

		int hallwayGroup; // if -1, room
		int nodeId; // if -1 not yet prepped as a node
		int noded; // if -1 not yet made into a node for portal engine

		int hallwayRegion; // 0, 1, 2, etc. when connected, lower region takes precedence and paints over the higher one until only zeroes remain

		bool explored;

		DungeonCell()
		{
			Initialize();
		}
		DungeonCell(System::Drawing::RectangleF &p_rect)
		{
			rect = p_rect;

			Initialize();
		}

	private:
		void Initialize()
		{
			rock = true;
			bordersRoom = false;
			hallwayGroup = -1; // room unless set otherwise
			nodeId = -1;
			noded = false;
			hallwayRegion = -1;
			explored = false;
		}

	};

	class DungeonRoom
	{
	public:
		int left, top, right, bottom, width, height;
		int doorQty;

		DungeonRoom()
		{
			// for array creation
		}

		DungeonRoom(int p_left, int p_top, int p_width, int p_height)
		{
			left = p_left;
			top = p_top;
			width = p_width;
			height = p_height;
			right = left + width;
			bottom = top + height;

			doorQty = 0; // set later
		}

		DungeonRoom(System::Drawing::Rectangle &p_rect)
		{
			left = p_rect.Left;
			right = p_rect.Right;
			top = p_rect.Top;
			bottom = p_rect.Bottom;
			width = p_rect.Width;
			height = p_rect.Height;

			doorQty = 0; // set later
		}

		bool IntersectsWith(System::Drawing::Rectangle &p_rect)
		{
			return (p_rect.IntersectsWith(System::Drawing::Rectangle(left, top, width, height)));
		}
	};

	class DungeonNodeCellRange
	{
	public:
		int startH, startV, stopH, stopV; // a node is always rectangular, inclusive (single 1x1 cell has both starts = stops)
	};

	class DungeonPoint
	{
	public:
		int x, y;
		bool up, down, left, right; // valid directions
		int currentDirection; // 0 left 1 right 2 up 3 down - weights decisions at times of randomness
	};

	public class RandomDungeon
	{
	public:

		int cellWidth, cellHeight;
		DungeonCell *cells;

		RandomDungeon()
		{
			cellWidth = 0;
			cellHeight = 0;

			cells = nullptr;
		}

		~RandomDungeon()
		{
			if (cells != nullptr)
			{
				delete [] cells;
				cells = nullptr;
			}
		}

		DungeonCell * GetCell(int p_h, int p_v)
		{
			return &cells[p_v * cellWidth + p_h];
		}

		void Initialize(int p_cellWidth, int p_cellHeight, float p_startX, float p_startZ, float p_cellSize)
		{
			cellWidth = p_cellWidth;
			cellHeight = p_cellHeight;
			cells = new DungeonCell[cellWidth * cellHeight];
			SetCellRects(p_startX, p_startZ, p_cellSize);
		}

		void SetCellRects(float p_startX, float p_startZ, float p_cellSize)
		{
			float currentX = p_startX;
			for (int h = 0; h < cellWidth; h++)
			{
				float currentZ = p_startZ;
				for (int v = 0; v < cellHeight; v++)
				{
					DungeonCell *cell = GetCell(h, v);
					cell->rect = System::Drawing::RectangleF(currentX, currentZ, p_cellSize, p_cellSize);

					currentZ = p_startZ + float(v + 1) * p_cellSize;
				}

				currentX = p_startX + float(h + 1) * p_cellSize;
			}
		}

		void ApplyRoom(DungeonRoom &p_room)
		{
			for (int h = p_room.left-1; h < p_room.left + p_room.width + 1; h++)
			{
				for (int v = p_room.top-1; v < p_room.top + p_room.height + 1; v++)
				{
					if (h >= p_room.left && h < p_room.left + p_room.width && v >= p_room.top && v < p_room.top + p_room.height)
						GetCell(h, v)->rock = false;
					else
						GetCell(h, v)->bordersRoom = true;
				}
			}
		}

		DungeonPoint GetValidDirections(int p_h, int p_v, int &p_count)
		{
			DungeonPoint point;
			p_count = 0;
			point.x = p_h;
			point.y = p_v;
			point.left = false;
			point.up = false;
			point.right = false;
			point.down = false;

			if (p_h >= 3)
			{
				// left is possible
				if (GetCell(p_h - 2, p_v)->rock == true)
				{
					p_count++;
					point.left = true;
				}
			}
			if (p_v >= 3)
			{
				// up is possible
				if (GetCell(p_h, p_v - 2)->rock == true)
				{
					p_count++;
					point.up = true;
				}
			}
			if (p_h < cellWidth - 3)
			{
				// right is possible
				if (GetCell(p_h + 2, p_v)->rock == true)
				{
					p_count++;
					point.right = true;
				}
			}
			if (p_v < cellHeight - 3)
			{
				// up is possible
				if (GetCell(p_h, p_v + 2)->rock == true)
				{
					p_count++;
					point.down = true;
				}
			}

			return point;
		}

		void MarkNodeExplored(DungeonNodeCellRange &p_cellRange)
		{
			for (int v = p_cellRange.startV; v <= p_cellRange.stopV; v++)
			{
				DungeonCell *cell = GetCell(p_cellRange.startH, v);
				for (int h = p_cellRange.startH; h <= p_cellRange.stopH; h++)
				{
					if (cell->explored == true)
					{
						// we already did that for this node
						return;
					}

					cell->explored = true;
					cell++;
				}
			}
		}
	};

	enum class RandomDungeonGenerateIterationPhase
	{
		RandomRooms,
		RandomHalls,
		RandomDoors,
		PaintRegions,
		ConnectRegions,
		ClearDeadEnds,
		Done
	};

	// class that tracks an iteration of data prep, allowing repeated calls to pick up where a loop left off
	class TestRandomDungeonGenerateIteration
	{
	public:
		RandomDungeonGenerateIterationPhase phase;

		float roomDensity; // how many rooms for a given square area?

		// tracking variables
		int maxRoomQty;
		int roomQty;
		int currentRoom;

		DungeonRoom *rooms;
		int roomRetries; // how many consecutive failures placing a room? - stop at 100
		int roomDoorRetries; // how many consecutive failure to place a room door?  stop at 30

		int currentRemoveDeadEndX, currentRemoveDeadEndY;

		int currentHallwayGroup;

		int currentRegion; // reuses hallway points list to track painting

		// first one in list is always the one being worked on
		// if empty, time to find a new starting point
		LinkedList<DungeonPoint> hallwayPoints;

		TestRandomDungeonGenerateIteration()
		{
			phase = RandomDungeonGenerateIterationPhase::RandomRooms;
			roomQty = 0;
			rooms = nullptr;
			currentRoom = 0;

			roomRetries = 0;
			roomDoorRetries = 0;

			// NOT ZERO!  Code looks in all directions for rocks
			currentRemoveDeadEndX = 1;
			currentRemoveDeadEndY = 1;

			currentHallwayGroup = 0;

			currentRegion = -1; // will be 0 for first paint
		}

		~TestRandomDungeonGenerateIteration()
		{
			if (rooms != nullptr)
			{
				delete[] rooms;
				rooms = nullptr;
			}
		}

		bool AnyRoomsOverlapped(System::Drawing::Rectangle &p_rect)
		{
			for (int i = 0; i < roomQty; i++)
			{
				if (rooms[i].IntersectsWith(p_rect))
					return true;
			}

			return false;
		}

		bool AnyRoomsOverlapped(DungeonRoom &p_room)
		{
			return AnyRoomsOverlapped(System::Drawing::Rectangle(p_room.left, p_room.top, p_room.width, p_room.height));
		}
	};

	class DungeonPortal
	{
	public:
		// portal is either at the right side of a rectangle or the bottom side of a rectangle
		// also, range of cells provide (single line horizontal or vertical)

		int index; // index as it will appear in the portal definition

		// these are search parameters and determine the final vertex values used to calculate the 4-vertex vertical portal
		int startH, stopH; // if 1 cell, startH == stopH
		int startV, stopV; // if 1 cell, startV = stopV
		bool right; // right or bottom?

		// front is ALWAYS facing inward on the cell (up or left)
		int frontNodeIndex;
		int backNodeIndex;

		DungeonPortal()
		{
			frontNodeIndex = -1;
			backNodeIndex = -1;
		}

		bool Matches(int p_startH, int p_stopH, int p_startV, int p_stopV, bool p_right)
		{
			return (
				startH == p_startH
				&& stopH == p_stopH
				&& startV == p_startV
				&& stopV == p_stopV
				&& right == p_right
				);
		}
	};

	class DungeonPortalRegistry
	{
	public:
		LinkedList<DungeonPortal> *portalLists;
		int currentPortalIndex = 0;
		int listsPerRow;
		int rowQty;
		int cellsPerList;
		int portalQty;

		DungeonPortalRegistry()
		{
			portalLists = nullptr;
			portalQty = 0;
		}

		~DungeonPortalRegistry()
		{
			if (portalLists != nullptr)
			{
				delete[] portalLists;
				portalLists = nullptr;
			}
		}

		void Initialize(int p_cellWidth, int p_cellHeight, int p_cellsPerList)
		{
			cellsPerList = p_cellsPerList;
			listsPerRow = p_cellWidth / cellsPerList + 1;
			rowQty = p_cellHeight / cellsPerList + 1;
			portalLists = new LinkedList<DungeonPortal>[listsPerRow * rowQty];
		}

		DungeonPortal * AddPortal(int p_startH, int p_stopH, int p_startV, int p_stopV, bool p_right, bool p_front, int p_nodeIndex)
		{
			LinkedList<DungeonPortal> *list = GetPortalList(p_startH, p_startV);
			DungeonPortal *portal = FindPortal(list, p_startH, p_stopH, p_startV, p_stopV, p_right);
			if (portal == nullptr)
			{
				portal = AddPortal(list, p_startH, p_stopH, p_startV, p_stopV, p_right);
			}
			if (p_front == true)
				portal->frontNodeIndex = p_nodeIndex;
			else
				portal->backNodeIndex = p_nodeIndex;

			return portal;
		}

		void Validate()
		{
			// check all lists, any portals with zero or one side set are invalid (for normal portals)
			LinkedList<DungeonPortal> *list = &(portalLists[0]);
			for (int i = 0; i < listsPerRow * rowQty; i++)
			{
				LinkedListEnumerator<DungeonPortal> enumerator = LinkedListEnumerator<DungeonPortal>(*list);
				while (enumerator.MoveNext())
				{
					int count = 0;
					if (enumerator.Current()->data.frontNodeIndex != -1)
						count++;
					if (enumerator.Current()->data.backNodeIndex != -1)
						count++;

					if (count != 2)
						throw gcnew Exception(String::Format("Portal with {0} sides set", count));
				}
				list++;
			}
		}

	private:
		LinkedList<DungeonPortal> * GetPortalList(int p_startH, int p_startV)
		{
			int list = p_startH / cellsPerList;
			int row = p_startV / cellsPerList;
			if (list >= listsPerRow)
				throw gcnew Exception("list too high");
			if (row >= rowQty)
				throw gcnew Exception("row too high");
			return &(portalLists[row * listsPerRow + list]);
		}

		DungeonPortal * FindPortal(LinkedList<DungeonPortal> *list, int p_startH, int p_stopH, int p_startV, int p_stopV, bool p_right)
		{
			LinkedListEnumerator<DungeonPortal> enumerator = LinkedListEnumerator<DungeonPortal>(*list);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.Matches(p_startH, p_stopH, p_startV, p_stopV, p_right) == true)
					return &(enumerator.Current()->data);
			}

			return nullptr;
		}

		DungeonPortal * AddPortal(LinkedList<DungeonPortal> *list, int p_startH, int p_stopH, int p_startV, int p_stopV, bool p_right)
		{
			if (p_startH != p_stopH && p_startV != p_stopV)
				throw gcnew Exception("Portal must be a horizontal or vertical line of cells - rectangle sent");
			if (p_startH > p_stopH)
				throw gcnew Exception("StartH must be <= StopH");
			if (p_startV > p_stopV)
				throw gcnew Exception("StartV must be <= StopV");
			if (p_right == true && p_startH != p_stopH)
				throw gcnew Exception("If right, StartH must = StopH - portal must be along right side of vertical line of cells");
			if (p_right == false && p_startV != p_stopV)
				throw gcnew Exception("If not right, StartV must = StopV - portal must be along bottom side of horizontal line of cells");

			LinkedListNode<DungeonPortal> *newNode = list->GetNewNode();
			newNode->data.index = portalQty;
			newNode->data.startH = p_startH;
			newNode->data.stopH = p_stopH;
			newNode->data.startV = p_startV;
			newNode->data.stopV = p_stopV;
			newNode->data.right = p_right;
			list->AddNode(newNode);

			portalQty++;

			return &(newNode->data);
		}
	};

	class DungeonVertex
	{
	public:
		int index; // index as it will appear in the portal definition
		Vector3d vertex;
	};

	class DungeonVertexRegistry
	{
		float sizePerCell;

	public:
		int vertexQty;
		int listsPerRow;
		int rowQty;
		LinkedList<DungeonVertex> *vertexLists;

		DungeonVertexRegistry()
		{
			vertexQty = 0;
			vertexLists = nullptr;
		}

		~DungeonVertexRegistry()
		{
			if (vertexLists != nullptr)
			{
				delete[] vertexLists;
				vertexLists = nullptr;
			}
		}

		void Initialize(int p_cellWidth, int p_cellHeight, float p_cellSize, int p_cellsPerList)
		{
			sizePerCell = p_cellSize * float(p_cellsPerList);
			listsPerRow = int(float(p_cellWidth * p_cellSize) / sizePerCell) + 1;
			rowQty = int(float(p_cellHeight * p_cellSize) / sizePerCell) + 1;
			vertexLists = new LinkedList<DungeonVertex>[listsPerRow * rowQty];
		}

		DungeonVertex * AddVertex(Vector3d &p_vertex)
		{
			// see if can find vertex
			LinkedList<DungeonVertex> *list = GetVertexList(p_vertex);
			DungeonVertex *vertex = FindVertex(p_vertex, list);
			if (vertex == nullptr)
			{
				vertex = AddVertex(p_vertex, list);
			}

			return vertex;
		}

	private:
		DungeonVertex * FindVertex(Vector3d &p_vertex)
		{
			LinkedList<DungeonVertex> *list = GetVertexList(p_vertex);
			return FindVertex(p_vertex, list);
		}

		DungeonVertex * AddVertex(Vector3d &p_vertex, LinkedList<DungeonVertex> *p_list)
		{
			// see if can find vertex
			LinkedListNode<DungeonVertex> *newNode = p_list->GetNewNode();
			newNode->data.vertex = p_vertex;
			newNode->data.index = vertexQty;
			vertexQty++;
			p_list->AddNode(newNode);
			return &(newNode->data);
		}

		LinkedList<DungeonVertex> * GetVertexList(Vector3d &p_vertex)
		{
			int list = int(p_vertex.x / sizePerCell);
			int listRow = int(p_vertex.z / sizePerCell);
			if (list >= listsPerRow)
				throw gcnew Exception("list too high");
			if (listRow >= rowQty)
				throw gcnew Exception("listRow too high");
			return &(vertexLists[listRow * listsPerRow + list]);
		}

		DungeonVertex * FindVertex(Vector3d &p_vertex, LinkedList<DungeonVertex> *p_list)
		{
			LinkedListEnumerator<DungeonVertex> enumerator = LinkedListEnumerator<DungeonVertex>(*p_list);
			while (enumerator.MoveNext())
			{
				if (enumerator.Current()->data.vertex.Equals(p_vertex) == true)
					return &(enumerator.Current()->data);
			}

			return nullptr;
		}

	};

	class DungeonNode
	{
	public:
		int index; // index to be used by portal engine in nodes array
		DungeonNodeCellRange cellRange; // a node is always rectangular, inclusive (single 1x1 cell has both starts = stops)

		// note: PortalNodeIndex is supposed to be for a node, not a portal index, but still, serves the purpose here, since it's an int
		LinkedList<PortalNodeIndex> portalIndices;
		int portalIndexQty;

		DungeonNode()
		{
			portalIndexQty = 0;
		}

		~DungeonNode()
		{
		}

		void AddPortalIndex(int p_portalIndex)
		{
			LinkedListNode<PortalNodeIndex> *newNode = portalIndices.GetNewNode();
			newNode->data.index = p_portalIndex;
			portalIndices.AddNode(newNode);
			portalIndexQty++;
		}
	};

	// done this way because DungoenNode has a list, so a DungeonNode constructor would be a bad idea in an implementation loop
	class DungeonNodeRegistry
	{
	public:
		LinkedList<DungeonNode> nodes;
		int nodeQty;

		DungeonNodeRegistry()
		{
			nodeQty = 0;
		}

		DungeonNode * AddNode(int p_index, int p_startH, int p_stopH, int p_startV, int p_stopV)
		{
			LinkedListNode<DungeonNode> *newNode = nodes.GetNewNode();
			newNode->data.index = p_index;
			newNode->data.cellRange.startH = p_startH;
			newNode->data.cellRange.stopH = p_stopH;
			newNode->data.cellRange.startV = p_startV;
			newNode->data.cellRange.stopV = p_stopV;

			// if we retrieved a node from the deleted list, portal indices may be populated!
			newNode->data.portalIndices.Clear();
			// better clear this too!
			newNode->data.portalIndexQty = 0; 

			nodes.AddNode(newNode);
			nodeQty++;

			return &(newNode->data);
		}

		DungeonNode * FindNode(int p_nodeId)
		{
			LinkedListEnumerator<DungeonNode> nodeEnumerator = LinkedListEnumerator<DungeonNode>(nodes);
			while (nodeEnumerator.MoveNext())
			{
				if (nodeEnumerator.Current()->data.index == p_nodeId)
					return &(nodeEnumerator.Current()->data);
			}
			
			return nullptr;
		}
	};

	enum class RandomDungeonMakePortalIterationPhase
	{
		PrepRoomNodes,
		PrepHallwayNodes,
		MakePortalData,
		Done
	};

	// iterations to make data into a portal engine
	// don't run until dungeon generation is finished
	class TestRandomDungeonMakePortalIteration
	{
	public:
		RandomDungeonMakePortalIterationPhase phase;

		int currentRoomIndex; // which rooms are we prepping?

		DungeonVertexRegistry vertexRegistry;
		DungeonPortalRegistry portalRegistry;
		DungeonNodeRegistry nodeRegistry;
		int maxNodeSize;

		// next hallway coord to start looking for a hallway cell to node up
		int nextHallwayH;
		int nextHallwayV;

		LinkedListNode<DungeonNode> *currentNode;
		int surfaceQty;

		gcroot<GameTexture ^>floorTextureRef;
		gcroot<GameTexture ^>floorBumpMapTextureRef;
		gcroot<GameTexture ^>floorSpecularTextureRef;
		gcroot<GameTexture ^>ceilingTextureRef;
		gcroot<GameTexture ^>ceilingBumpMapTextureRef;
		gcroot<GameTexture ^>ceilingSpecularTextureRef;
		gcroot<GameTexture ^>wallTextureRef;
		gcroot<GameTexture ^>wallBumpMapTextureRef;
		gcroot<GameTexture ^>wallSpecularTextureRef;
		gcroot<GameTexture ^>mirrorTextureRef;
		gcroot<GameTexture ^>mirrorBumpMapTextureRef;
		gcroot<GameTexture ^>mirrorSpecularTextureRef;

		TestRandomDungeonMakePortalIteration(int p_cellWidth, int p_cellHeight, float p_cellWorldSize, int p_cellsPerList, int p_maxNodeSize)
		{
			currentRoomIndex = 0;
			phase = RandomDungeonMakePortalIterationPhase::PrepRoomNodes;
			vertexRegistry.Initialize(p_cellWidth, p_cellHeight, p_cellWorldSize, p_cellsPerList);
			portalRegistry.Initialize(p_cellWidth, p_cellHeight, p_cellsPerList);
			maxNodeSize = p_maxNodeSize;
			nextHallwayH = 0;
			nextHallwayV = 0;
			currentNode = nullptr;
			surfaceQty = 0;

			floorTextureRef = nullptr;
			ceilingTextureRef = nullptr;
			wallTextureRef = nullptr;
			mirrorTextureRef = nullptr;
			floorBumpMapTextureRef = nullptr;
			ceilingBumpMapTextureRef = nullptr;
			wallBumpMapTextureRef = nullptr;
			mirrorBumpMapTextureRef = nullptr;
		}
	};

	// class that both dungeon lights and arbiters are aware of to provide a container for extra data to facilate an animated light
	// game loop will determine a new set of interpolation orientations and keep the position updated so that it is caught by the tally
	// render light tally loop will use the data to animate the light to catch it up for the gamestate before preparing its nodes and evaluate the light
	class RandomDungeonArbiterLightData
	{
	public:
		int gameStateId;
		Orient3d beginOrient;
		Orient3d endOrient;
		Orient3d currentOrient;
		float totalInterpolateMS; // how much total time for interpolation?
		float interpolateMS; // counts down to zero, handled in gameloop.  Divide by totalInterpolateMS to get a factor.

		RandomDungeonArbiterLightData()
		{
			gameStateId = -1;
		}

		// call during gameloop
		bool ApplyElapsedTimeMS(float p_elapsedTimeMSf)
		{
			if (p_elapsedTimeMSf == 0.0f)
				return false;

			if (interpolateMS != 0.0f)
			{
				if (interpolateMS < p_elapsedTimeMSf)
				{
					interpolateMS = 0.0f;
				}
				else
				{
					interpolateMS -= p_elapsedTimeMSf;
				}

				return true;
			}

			return false;
		}

		// call before light is tallied, then set it as a spotlight
		void CalculateCurrentOrient()
		{
			if (interpolateMS >= totalInterpolateMS && totalInterpolateMS != 0.0f)
			{
				currentOrient = beginOrient;
			}
			else if (interpolateMS <= 0.0f || totalInterpolateMS == 0.0f) // prevent divide by zero
			{
				// still need to set because position can change as arbiter moves even after interpolation is complete
				currentOrient = endOrient;
			}
			else
			{
				currentOrient = Orient3d::Interpolate(beginOrient, endOrient, (totalInterpolateMS - interpolateMS) / totalInterpolateMS);
			}
		}

		// call during gameloop
		void ApplyPosition(Vector3d &p_position)
		{
			beginOrient.p = p_position;
			endOrient.p = p_position;
			currentOrient.p = p_position;
		}

		// call when gameloop timer calls for a new spotlight interpolation
		// generally called with beginOrient = currentOrient
		void SetNewOrientationInterpolation(Orient3d &p_beginOrient, Orient3d &p_endOrient, float p_interpolationMS)
		{
			totalInterpolateMS = p_interpolationMS;
			interpolateMS = p_interpolationMS;
			beginOrient = p_beginOrient;
			endOrient = p_endOrient;
		}

		static Orient3d RandomSpotlightOrient()
		{
			Orient3d result;
			result.p.Set(0, 0, 0);
			static FastRandom fastRandom;
			Vector3d offset;
			bool valid = false;
			while (valid == false)
			{
				// spotlight can face horizontally or down
				offset = Vector3d(float(fastRandom.GetRandomInteger(-1000, 1000)) / 1000.0f, float(fastRandom.GetRandomInteger(0, -1000)) / 1000.0f, float(fastRandom.GetRandomInteger(-1000, 1000)) / 1000.0f);
				if (offset.MagnitudeSquared() <= 1.0f || offset.MagnitudeSquared() > 0.00001f)
					valid = true;
			}
			result.f = offset;
			result.f.Normalize();
			if (result.f.y > 0.999f)
			{
				result.f = Vector3d(0, 1, 0);
				result.l = Vector3d(1, 0, 0);
			}
			else if (result.f.y < -0.999f)
			{
				result.f = Vector3d(0, -1, 0);
				result.l = Vector3d(1, 0, 0);
			}
			else
			{
				result.l = Vector3d(result.f.z, 0.0f, -result.f.x);
				result.l.Normalize();
			}
			result.u = result.f.CrossProd(result.l);

			/*
			// testing
			#ifdef _DEBUG
			// always point down to test shadowing on other objects
			result.p = Vector3d(0, 0, 0);
			result.f = Vector3d(0, -1, 0);
			result.l = Vector3d(1, 0, 0);
			result.u = result.f.CrossProd(result.l);
			#endif _DEBUG
			*/

			return result;
		}
	};

	class RandomDungeonLight : public GraphicsShaderLight // done this way so that framework tally can make sense of what is stored there
	{
	public:
		//GraphicsShaderLight light;
		// if cleared, regenerate.  Note: if light is outside the map, this will remain clear and will continually fail to populate
		int currentNode; // node that light is in (used to maintain node light lists)
		PortalParseResultList nodesToRender;
		int tallyId; // on what tally was this light last inspected?
		int shadowMapMainRenderId;
		int animationGamestateId; // if animated, is it caught up to gamestate?

		bool flicker; // should it be flickered?
		float flickerFlashTimeLeftMS; // flash is flickering out (determines brightness in flicker with intensity), decreases while flaring up
		float nextFlashTimeLeftMS; // when will next flash occur?
		float flashDurationMS; // how long does this flash last for?
		float flashFlareupMS; // how long of the flashDurationMS is used to to flare up?
		float flashIntensity; // how bright is it?
		float originalBrightness; // what was the brightness before this flash?

		// for arbiters
		// if set, use to animate the light during the tally pass
		RandomDungeonArbiterLightData *arbiterLightDataRef;

		LinkedList<Particle> particles;
		gcroot<GameTexture ^> particleTextureRef;
		float nextParticleMS; // how long until the next particle?
		int particlesGamestateId;  // to keep animation up to date with gamestate
		GameColor flameColor;
		bool intenseParticles;

		Vector3d waggleBegin;
		Vector3d waggleEnd;
		int positionWaggleGamestateId;
		float waggleTimeMS; // counts down to zero
		float totalWaggleTimeMS;
		
		// interpolation
		Vector3d interpolationStartColor;
		Vector3d interpolationEndColor;
		float interpolationGameTimeMS; // if 0.0f, nothing to do, otherwise the value is meaningful
		float totalInterpolationMS;
		GameColor originalFlameColor;
		Vector3d originalIllumination; // what was the color this light was initialized with?

		Vector3d nodePosition;

		void Initialize()
		{
			nodesToRender.Clear();
			currentNode = -1;
			tallyId = -1;
			shadowMapMainRenderId = -1;
			animationGamestateId = -1;
			// clear any assignments from a prior render!
			shadowMapFrameBufferRef = nullptr;
			shadowMapTextureRef = nullptr;

			arbiterLightDataRef = nullptr;

			flicker = false;
			flickerFlashTimeLeftMS = 0.0f;
			nextFlashTimeLeftMS = 0.0f;
			flashDurationMS = 100.0f;
			flashIntensity = 1.0f;

			particles.Clear();
			particleTextureRef = nullptr;
			particlesGamestateId = -1;
			flameColor.Set(255, 255, 255);
			intenseParticles = false; // slow particles

			nextParticleMS = 0.0f;

			positionWaggleGamestateId = -1;
			waggleBegin = Vector3d(0, 0, 0);
			waggleEnd = Vector3d(0, 0, 0);
			waggleTimeMS = 0.0f;
			totalWaggleTimeMS = 100.0f;

			interpolationGameTimeMS = 0.0f;
			totalInterpolationMS = 0.0f;

			GraphicsShaderLight::Initialize();
		}

		// overrides
		void SetSpotlight(Vector3d &p_worldPosition, Vector3d &p_directionWorld, float p_maxAngleDegrees, Vector3d &p_color, float p_diffuseAttenuate, float p_specularAttenuate)
		{
			SetNodePosition(p_worldPosition);
			GraphicsShaderLight::SetSpotlight(p_worldPosition, p_directionWorld, p_maxAngleDegrees, p_color, p_diffuseAttenuate, p_specularAttenuate);
		}

		void SetPoint(Vector3d &p_worldPosition, Vector3d p_color, float p_diffuseAttenuate, float p_specularAttenuate)
		{
			SetNodePosition(p_worldPosition);
			GraphicsShaderLight::SetPoint(p_worldPosition, p_color, p_diffuseAttenuate, p_specularAttenuate);
		}

		void SetSpotlightTexture(GameTexture ^p_spotlightTexture, Vector3d &p_worldPosition, Vector3d &p_directionWorld, Vector3d &p_leftUnitWorld, Vector3d &p_upUnitWorld, float p_maxAngleDegrees, Vector3d &p_colorModulate, float p_diffuseAttenuate, float p_specularAttenuate)
		{
			SetNodePosition(p_worldPosition);
			GraphicsShaderLight::SetSpotlightTexture(p_spotlightTexture, p_worldPosition, p_directionWorld, p_leftUnitWorld, p_upUnitWorld, p_maxAngleDegrees, p_colorModulate, p_diffuseAttenuate, p_specularAttenuate);
		}

		void SetNodePosition(Vector3d &p_position)
		{
			nodePosition = p_position;
			waggleBegin = p_position;
			waggleEnd = p_position;
		}

		// point light
		void SetPosition(Vector3d &p_position)
		{
			// GraphicsShaderLight
			worldPosition = p_position;
			SetNodePosition(p_position);

			nodesToRender.Clear();
		}

		// spotlight
		void SetPositionAndDirection(Vector3d &p_position, Vector3d &p_direction)
		{
			// GraphicsShaderLight
			worldPosition = p_position;
			SetNodePosition(p_position);
			directionUnitWorldReversed = p_direction.ScalarMult(-1.0f);

			nodesToRender.Clear();
		}

		// spotlight with texture
		void SetPositionAndAxes(Vector3d &p_position, Vector3d &p_direction, Vector3d &p_leftUnit, Vector3d &p_upUnit)
		{
			// GraphicsShaderLight
			worldPosition = p_position;
			SetNodePosition(p_position);
			directionUnitWorldReversed = p_direction.ScalarMult(-1.0f);
			float factor = tan(MathUtilities::DegreesToRadians(maxAngleDegrees));
			sAxisWorld = p_leftUnit.ScalarMult(1.0f / (2.0f * factor));
			tAxisWorld = p_upUnit.ScalarMult(1.0f / (2.0f * factor));

			nodesToRender.Clear();
		}

		static Vector3d RandomColor(float p_intensity)
		{
			// make a random color with a component guaranteed to be = p_intensity
			// Don't allow anything to be < 0.5;
			static FastRandom fastRandom;
			Vector3d result(float(fastRandom.GetRandomInteger(1, 255)) / 255.0f, float(fastRandom.GetRandomInteger(1, 255)) / 255.0f, float(fastRandom.GetRandomInteger(1, 255)) / 255.0f);
			float intensity = result.x;
			if (result.y > intensity)
				intensity = result.y;
			if (result.z > intensity)
				intensity = result.z;
			result = result.ScalarMult(1.0f / intensity);
			if (result.x < 0.5f)
				result.x = 0.5f;
			if (result.y < 0.5f)
				result.y = 0.5f;
			if (result.z < 0.5f)
				result.z = 0.5f;
			result = result.ScalarMult(p_intensity);
			return result;
		}

		// for arbiters
		bool IsArbiterLight()
		{
			return (arbiterLightDataRef != nullptr);
		}

		// call during gameloop while moving arbiter
		void SetArbiterLightPosition(Vector3d &p_position)
		{
			arbiterLightDataRef->ApplyPosition(p_position);
			SetPosition(p_position); // allows light to be seen in tally, and clears nodes so they need to be re-prepped
		}

		void ArbiterApplyElapsedTimeMS(float p_elapsedTimeMSf)
		{
			// if interpolation time changes, clear the nodes
			if (arbiterLightDataRef->ApplyElapsedTimeMS(p_elapsedTimeMSf) == true)
				nodesToRender.Clear(); // clear nodes so they need to be re-prepped
		}

		// call during light tally
		void SetArbiterLightOrientation(int p_gameStateId)
		{
			if (arbiterLightDataRef->gameStateId != p_gameStateId)
			{
				arbiterLightDataRef->CalculateCurrentOrient();
				SetPositionAndDirection(arbiterLightDataRef->currentOrient.p, arbiterLightDataRef->currentOrient.f);
				arbiterLightDataRef->gameStateId = p_gameStateId;
			}
		}

		// animation
		void PerformFlicker(float p_elapsedTimeMSf, float p_gameTimeMSf)
		{
			// generate new random brightness
			static FastRandom fastRandom;

			//float proposedBrightness = float(fastRandom.GetRandomInteger(40, 160)) / 100.0f;
			//// interpolate light towards that new brightness so that flicker isn't so intense
			//float newBrightness = brightness;
			//float intensityChangePerMS = 0.0001f;
			//float intensityChange = intensityChangePerMS * p_elapsedTimeMSf;;
			//if (newBrightness > proposedBrightness)
			//{
			//	newBrightness -= intensityChange;
			//	if (newBrightness < proposedBrightness)
			//		newBrightness = proposedBrightness;
			//}
			//else
			//{
			//	newBrightness += intensityChange;
			//	if (newBrightness > proposedBrightness)
			//		newBrightness = proposedBrightness;
			//}
			//brightness = newBrightness;

			// interpolate the color
			if (interpolationGameTimeMS > 0.0f)
			{
				if (p_gameTimeMSf >= (interpolationGameTimeMS + totalInterpolationMS))
				{
					interpolationGameTimeMS = 0.0f;
					color = interpolationEndColor;
				}
				else
				{
					//interpolationMS -= p_elapsedTimeMSf;
					color = Vector3d::Interpolate(interpolationStartColor, interpolationEndColor, (p_gameTimeMSf - interpolationGameTimeMS) / totalInterpolationMS);
				}
			}

			// flicker the color
			float timeToConsumeMSf = p_elapsedTimeMSf;
			while (timeToConsumeMSf > 0)
			{
				if (nextFlashTimeLeftMS > timeToConsumeMSf)
				{
					nextFlashTimeLeftMS -= timeToConsumeMSf;
					flickerFlashTimeLeftMS -= timeToConsumeMSf;
					if (flickerFlashTimeLeftMS < 0.0f)
						flickerFlashTimeLeftMS = 0.0f;
					timeToConsumeMSf = 0.0f;
				}
				else
				{
					timeToConsumeMSf -= nextFlashTimeLeftMS;

					// make a new flash
					//flashDurationMS = float(fastRandom.GetRandomInteger(1400, 2000)); // longer is regularly bright flame, shorter is unsteady
					if (intenseParticles == false)
					{
						flashDurationMS = float(fastRandom.GetRandomInteger(1000, 1500)); // longer is regularly bright flame, shorter is unsteady
						flashFlareupMS = flashDurationMS / 16.0f; // larger is more energetic of a flame, smaller is less bright
						flashIntensity = 1.0f; // larger is brighter.
						flickerFlashTimeLeftMS = flashDurationMS;
						nextFlashTimeLeftMS = float(fastRandom.GetRandomInteger(100, 300)); // longer is less energetic of a flame but also unsteady
					}
					else
					{
						flashDurationMS = float(fastRandom.GetRandomInteger(250, 375)); // longer is regularly bright flame, shorter is unsteady
						flashFlareupMS = flashDurationMS / 64.0f; // larger is more energetic of a flame, smaller is less bright
						flashIntensity = 1.0f; // larger is brighter.
						flickerFlashTimeLeftMS = flashDurationMS;
						nextFlashTimeLeftMS = float(fastRandom.GetRandomInteger(25, 75)); // longer is less energetic of a flame but also unsteady
					}
					originalBrightness = brightness; // brightness could be anything, since the light might not have been visible last frame, but it's good enough for being on the same screen one frame to the next
				}
			}
			// build up to flashIntensity using flareupMS, then fade out
			if (flashFlareupMS > (flashDurationMS - flickerFlashTimeLeftMS))
			{
				// flareup!
				// brightness = original brightness + factor(0.0f-1.0f) * difference between intended brightness and original brightness
				brightness = originalBrightness + ((flashDurationMS - flickerFlashTimeLeftMS) / flashFlareupMS) * (flashIntensity - originalBrightness);
			}
			else
				// dimming
				brightness = (flickerFlashTimeLeftMS / (flashDurationMS - flashFlareupMS)) * flashIntensity;;
		}

		void AddParticle(Vector3d &p_position, float p_startRadius, GameColor &p_color, float p_startLifeMS, bool p_intenseParticle = false, float p_intenseFactor = 1.0f)
		{
			LinkedListNode<Particle> *newParticle = particles.GetNewNode();
			newParticle->data.Initialize();

			newParticle->data.alpha = 1.0f; // alpha doesn't change
			newParticle->data.color = p_color;

			static FastRandom fastRandom;
			if (p_intenseParticle == false)
				newParticle->data.SetRadiusFormula(p_startRadius, -p_startRadius / float(fastRandom.GetRandomInteger(300, 500))); // determines life
			else
				newParticle->data.SetRadiusFormula(p_startRadius, (-p_startRadius * p_intenseFactor) / float(fastRandom.GetRandomInteger(300, 500))); // determines life
			if (p_intenseParticle == false)
				newParticle->data.SetPositionFormula(p_position, Vector3d(0.0f, 0.35f / 1000.0f, 0.0f));
			else
				newParticle->data.SetPositionFormula(p_position, Vector3d(0.0f, p_intenseFactor * 0.35f / 1000.0f, 0.0f));
			newParticle->data.textureIndex = 0;
			newParticle->data.lifeMS = p_startLifeMS;

			particles.AddNode(newParticle);
		}

		void AnimateParticles(float p_elapsedTimeMSf)
		{
			float timeToConsumeMS = p_elapsedTimeMSf;
			while (timeToConsumeMS > 0)
			{
				if (nextParticleMS <= timeToConsumeMS)
				{
					timeToConsumeMS -= nextParticleMS;

					float intenseFactor = 4.0f;

					static FastRandom fastRandom;
					nextParticleMS = float(fastRandom.GetRandomInteger(10,20));
					if (intenseParticles == true)
						nextParticleMS = nextParticleMS / intenseFactor;

					// add a particle around the light's center position
					float initialRadius = 0.030f;
					float verticalOffset = 0.025f; // to coincide with specular highlight at most intense collection of particles
					if (intenseParticles == false)
						AddParticle(nodePosition - Vector3d(0.0f, verticalOffset, 0.0f) + Vector3d(float(fastRandom.GetRandomInteger(-10, 10)) / 1000.0f, 0.0f, float(fastRandom.GetRandomInteger(-10, 10)) / 1000.0f),
							initialRadius, 
							flameColor,
							timeToConsumeMS - p_elapsedTimeMSf);
					else
						AddParticle(nodePosition - Vector3d(0.0f, verticalOffset, 0.0f) + Vector3d(float(fastRandom.GetRandomInteger(-10, 10)) / 1000.0f, 0.0f, float(fastRandom.GetRandomInteger(-10, 10)) / 1000.0f),
						initialRadius,
						flameColor,
						timeToConsumeMS - p_elapsedTimeMSf, 
						intenseParticles, 
						intenseFactor);
				}
				else
				{
					nextParticleMS -= timeToConsumeMS;
					timeToConsumeMS = 0;
				}
			}

			// animate them all!  Use node list because if they are dead we want to remove them
			LinkedListNode<Particle> *particleNode = particles.GetFirstNode();
			if (particleNode != nullptr)
			{
				while (particleNode != &(particles.footer))
				{
					LinkedListNode<Particle> *nextNode = particleNode->next;

					particleNode->data.SetLife(p_elapsedTimeMSf);
					if (particleNode->data.IsDead() == true)
						particles.DeleteNode(particleNode);
					else
					{
						// calculate other variables
						// alpha doesn't change
						particleNode->data.PreparePosition();
						particleNode->data.PrepareRadius();
					}

					particleNode = nextNode;
				}
			}
		}

		void SelectFlameColor(int p_flameNumber = -1, bool p_interpolate = false, float p_interpolationMS = 0.0f, float p_gameTimeMSf = 0)
		{
			static FastRandom fastRandom;
			GameColor redFire(168, 49, 17);
			GameColor blueFire(17, 49, 168);
			GameColor arcaneBlueFire(40, 80, 168);
			GameColor greenFire(49, 168, 17);
			GameColor whiteFire(96, 96, 96);
			GameColor purpleFire(128, 40, 128);
			//GameColor darkRed(204, 24, 24); // testing for horror effect
			GameColor darkRed(204, 10, 10); // testing for horror effect - this is blood red by ratio (blood red is 138, 7, 7)
			GameColor brightGold(204, 164, 80); // testing for angelic effect
			int flameNumber = p_flameNumber;
			if (flameNumber == -1)
				flameNumber = fastRandom.GetRandomInteger(0, 5);
			switch (flameNumber)
			{
			case 0:
				flameColor = redFire;
				break;
			case 1:
				flameColor = blueFire;
				break;
			case 2:
				flameColor = arcaneBlueFire;
				break;
			case 3:
				flameColor = greenFire;
				break;
			case 4:
				flameColor = whiteFire;
				break;
			case 5:
				flameColor = purpleFire;
				break;
			case 6:
				flameColor = darkRed;
				break;
			case 7:
				flameColor = brightGold;
				break;
			}

			// stack particle colors on top of each other and clamp to 1.0f to get the illumination color
			if (flameNumber < 6)
			{
				intenseParticles = false;
			}
			else
				intenseParticles = true;

			Vector3d illuminationColor = CalculateIlluminationColorFromFlameColor();

			if (p_flameNumber == -1)
			{
				// save for restoration
				color = illuminationColor;
				originalFlameColor = flameColor;
				originalIllumination = color; 
			}
			else if (p_interpolate == true)
			{
				if (p_interpolationMS > 0.0f)
				{
					interpolationStartColor = color;
					interpolationEndColor = illuminationColor;
					interpolationGameTimeMS = p_gameTimeMSf; // track game time when interpolation started so that lights that weren't rendered for a while can be properly caught up
					totalInterpolationMS = p_interpolationMS;
				}
				else
				{
					interpolationGameTimeMS = 0.0f;
					color = illuminationColor;
				}
			}
		}

		Vector3d CalculateIlluminationColorFromFlameColor()
		{
			Vector3d illuminationColor;
			float stackAmount = 5.0f;
			illuminationColor.Set(stackAmount * float(flameColor.red) / 255.0f, stackAmount * float(flameColor.green) / 255.0f, stackAmount * float(flameColor.blue) / 255.0f);
			if (intenseParticles == false)
			{
				if (illuminationColor.x > 1.0f)
					illuminationColor.x = 1.0f;
				if (illuminationColor.y > 1.0f)
					illuminationColor.y = 1.0f;
				if (illuminationColor.z > 1.0f)
					illuminationColor.z = 1.0f;
			}

			return illuminationColor;
		}

		void RestoreOriginalIllumination(float p_interpolationMS, float p_gameTimeMSf)
		{
			if (p_interpolationMS > 0.0f)
			{
				interpolationStartColor = color;
				interpolationEndColor = originalIllumination;
				interpolationGameTimeMS = p_gameTimeMSf;
				totalInterpolationMS = p_interpolationMS;
			}
			else
			{
				color = originalIllumination;
			}
			flameColor = originalFlameColor;
			intenseParticles = false;
		}

		void AnimatePositionWaggle(float p_elapsedTimeMSf)
		{
			while (p_elapsedTimeMSf > 0.0f)
			{
				if (waggleTimeMS > p_elapsedTimeMSf)
				{
					waggleTimeMS -= p_elapsedTimeMSf;
					p_elapsedTimeMSf = 0.0f;

					// interpolate!
					worldPosition = waggleBegin + (waggleEnd - waggleBegin).ScalarMult((totalWaggleTimeMS - waggleTimeMS) / totalWaggleTimeMS);
				}
				else
				{
					p_elapsedTimeMSf -= waggleTimeMS;
					waggleBegin = waggleEnd;
					static FastRandom fastRandom;
					//waggleEnd = nodePosition + Vector3d(float(fastRandom.GetRandomInteger(-10, 10)) / 40000.0f, 0.0f, float(fastRandom.GetRandomInteger(-10, 10)) / 40000.0f);
					waggleEnd = nodePosition + Vector3d(float(fastRandom.GetRandomInteger(-10, 10)) / 40000.0f, float(fastRandom.GetRandomInteger(-10, 10)) / 40000.0f, float(fastRandom.GetRandomInteger(-10, 10)) / 40000.0f);

					if (intenseParticles == false)
						totalWaggleTimeMS = float(fastRandom.GetRandomInteger(50, 150));
					else
						totalWaggleTimeMS = float(fastRandom.GetRandomInteger(13, 36));

					waggleTimeMS = totalWaggleTimeMS;

					// in case time remaining is 0.0, calculate position now as if interpolation ran
					worldPosition = waggleBegin;
				}
			}
		}
	};

	typedef RandomDungeonLight * RandomDungeonLightPtr;

	class RandomDungeonBall
	{
	public:
		float radius;
		Vector3d velocity;
		Orient3d orient; // new position this tick, and render position
		Vector3d priorPosition; // prior position this tick - used for collisions otherwise no use.  Always calculated before collisions run
		Vector3d spinAxis;
		float spinDegreesPerMS;

		int playerControlBallId; // does player launch this one (Id >= 0)?  When palyer launches ball, set currentPlayerControlBallId to that position (if not found, make it)

		RandomDungeonLight *lightRef; // which light on the map does this one use?

		// prevent double renders
		int renderId; // prevent rendering ball twice for a final render (each eye in anaglypg are a different render)
		int lightRenderId; // prevent rendering ball twice for a specific shadow map

		LinkedList<PortalNodeIndex> nodesOverlapped; // which nodes should this ball be rendered with?

		int currentNode; // node that center is in - NOT used for collisions, only for tracking target point to jump towards
		Vector3d targetPoint; // point to bounce towards
		int targetPortalIndex; // portal point is bouncing towards (could use its center, but keeping the targetPoint separate allows other things for the future)

		//#define MAX_POTENTIAL_ENERGY_CHECK 8
		//static int potentialEnergyCheck; // see .cpp for init
		//int potentialEnergyCheckId; // when should potential energy be checked?
		//float potentialEnergyTargetY;
		//float potentialEnergyAccelerationPerMSMS;
		//float potentialEnergy; // target energy to be kept

		void Initialize()
		{
			playerControlBallId = -1;
			velocity = Vector3d();
			orient.LoadIdentity();
			radius = 0.1f;
			spinAxis = Vector3d(0, 0, 0);
			spinDegreesPerMS = 0.0f;
			lightRef = nullptr;
			nodesOverlapped.Clear();
			renderId = -1;
			lightRenderId = -1;

			currentNode = -1;
			targetPortalIndex = -1;

			//potentialEnergyCheckId = potentialEnergyCheck;
			//potentialEnergyCheck++;
			//if (potentialEnergyCheck > MAX_POTENTIAL_ENERGY_CHECK)
			//	potentialEnergyCheck = 0;
		}

	//	void SetPotentialEnergy(float p_gravityPerMSMS, float p_targetY)
	//	{
	//		potentialEnergyAccelerationPerMSMS = p_gravityPerMSMS;
	//		potentialEnergyTargetY = p_targetY;

	//		// determine the velocity a ball will have if its current velocity is directed entirely downward (y + magnitude(x+z)) and reaches p_targetY
	//		Vector2d horizontalVelocity = Vector2d(velocity.x, velocity.z);
	//		float potentialDownwardVelocity = float(abs(velocity.y)) + horizontalVelocity.Magnitude();
	//		potentialEnergy = CalculatePotentialEnergy(potentialDownwardVelocity, potentialEnergyAccelerationPerMSMS, orient.p.y, potentialEnergyTargetY);
	//	}

	//	// check on collisions with mostly upward facing normals
	//	// this prevents fast moving sideways bouncers from losing their vertical bounce due to rounding
	//	void CheckPotentialEnergy()
	//	{
	//		if (potentialEnergyCheck == 0)
	//		{
	//			potentialEnergyCheckId = MAX_POTENTIAL_ENERGY_CHECK;

	//			Vector2d horizontalVelocity = Vector2d(velocity.x, velocity.z);
	//			float potentialDownwardVelocity = float(abs(velocity.y)) + horizontalVelocity.Magnitude();
	//			velocity = velocity.ScalarMult(potentialEnergy / CalculatePotentialEnergy(potentialDownwardVelocity, potentialEnergyAccelerationPerMSMS, orient.p.y, potentialEnergyTargetY));
	//		}
	//		else
	//			potentialEnergyCheckId--;
	//	}
	//private:
	//	float CalculatePotentialEnergy(float p_downwardVelocity, float p_acceleration, float p_currentY, float p_targetY)
	//	{
	//		// determine the velocity a ball will have if its current velocity is directed entirely downward (y + magnitude(x+z)) and reaches p_targetY, and adjust velocity
	//		// y + vt + 1/2 at^2 = targetY
	//		// 1/2at^2 + vt + y - targetY = 0;
	//		// t = (-b +- sqrt(b^2 -4ac))/2a
	//		float a = -0.5f * p_acceleration;
	//		float b = -p_downwardVelocity;
	//		float c = p_currentY - p_targetY;
	//		float temp = b * b - 4 * a * c;
	//		if (a == 0.0f)
	//			throw gcnew System::Exception("Unsolvable potential energy (a = 0)");
	//		if (temp < 0.0f)
	//			throw gcnew System::Exception("Unsolvable potential energy (temp < 0)");
	//		float t = (-b + float(sqrt(temp))) / (2 * a);

	//		return p_downwardVelocity + p_acceleration * t;
	//	}
	};

	typedef RandomDungeonBall * RandomDungeonBallPtr; // for node lists

	/////////////////////
	// dressing (statues, obelisks, etc.)

	class RandomDungeonObjectTypeEnum // index for dressing registry array
	{
	public:
		// dressings
		static const int TestCube = 0;
		static const int HellraiserCube = 1;
		static const int BlackObelisk = 2;
		static const int MarbleObelisk = 3;
		static const int StoneObelisk = 4;
		static const int WallSconce = 5;

		// creatures
		static const int Triguy = 6;
		static const int Arbiter = 7;

		// quantity
		static const int Quantity = 8;
	};

	// how to render a dressing, minus the data on the object instance
	class RandomDungeonModel
	{
	public:
		// destroy these!
		// one or the other is set, never both
		Model3d *model; 
		JointedModel3d *jointedModel; 

		GraphicsNativeObjectContainer *nativeObject; 
		GraphicsShaderMaterial material; // material to use for the rendering

		RandomDungeonModel()
		{
			model = nullptr;
			jointedModel = nullptr;
			nativeObject = nullptr;
		}

		~RandomDungeonModel()
		{
			if (model != nullptr)
			{
				delete model;
				model = nullptr;
			}
			if (jointedModel != nullptr)
			{
				delete jointedModel;
				jointedModel = nullptr;
			}
			if (nativeObject != nullptr)
			{
				delete nativeObject;
				nativeObject = nullptr;
			}
		}

		void CheckNativeObject(GraphicsBase *p_graphics)
		{
			if (nativeObject == nullptr)
			{
				nativeObject = new GraphicsNativeObjectContainer();
				if (nativeObject->nativeObjectRef == nullptr)
				{
					// if native object not prepped, do it now.
					if (model != nullptr)
					{
						model->CreateNativeObject(p_graphics, nativeObject, true);
					}
					else
					{
						jointedModel->CreateNativeObject(p_graphics, nativeObject, true);
					}
				}
			}
		}
	};

	// instance of a dressing object
	class RandomDungeonDressing
	{
	public:
		int type; // which model is it?

		Orient3d orient;
		float scale; // full model for now, when shader supports x,y,z scaling, this can be a vector
		float renderRadius; // for determining node overlap
		RandomDungeonModel *modelRef; // how is it rendered?  Reference - do not destroy!
		LinkedList<PortalNodeIndex> nodesOverlapped; // which nodes does this dressing overlap? for rendering

		int renderId; // was this object already rendered for the current final render?  If so, skip it
		int shadowRenderId; // was this object already rendered for the current shadow render?  If so, skip it
		// note: animation only refers to altering orientations for the purpose of rendering accurately, NOT actually moving the object around and interacting using AI routines.
		int animationId; // if animating during render to animate only local items, this prevents animating it twice in the case of rendering anaglyph

		float rotationDegreesPerMS; // for hellraiser cube

		RandomDungeonDressing()
		{
			Initialize();
		}

		// call this when a new node is created for adding to the dressings list - we might be retrieving one from the deleted list.
		void Initialize()
		{
			orient.LoadIdentity();
			scale = 1.0f;
			renderRadius = 1.0f;

			modelRef = nullptr;
			nodesOverlapped.Clear();

			renderId = 0;
			shadowRenderId = 0;

			rotationDegreesPerMS = 0.0f;
		}

		void Render(GraphicsBase *p_graphics, GraphicsShaderOptions %p_renderOptions)
		{
			modelRef->CheckNativeObject(p_graphics);

			// prep shader options
			p_renderOptions.vertexScale = scale;
			p_renderOptions.modelWorldOrientRef = &orient;

			p_renderOptions.lightingMaterialRef = &modelRef->material;

			// render it!
			p_graphics->RenderNativeObject(modelRef->nativeObject, p_renderOptions);
		}
		void RenderToFlatShadowMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_renderOptions)
		{
			// target shadow map must already be the target buffer!

			modelRef->CheckNativeObject(p_graphics);

			// prep shader options
			p_renderOptions.vertexScale = scale;
			p_renderOptions.modelWorldOrientRef = &orient;

			// render it!
			p_graphics->RenderNativeObjectToShadowMap(modelRef->nativeObject, p_renderOptions);
		}
		void RenderToCubeShadowMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_renderOptions)
		{
			// target cube shadow map must already be the target buffer!

			modelRef->CheckNativeObject(p_graphics);

			// prep shader options
			p_renderOptions.vertexScale = scale;
			p_renderOptions.modelWorldOrientRef = &orient;

			// render it!
			p_graphics->RenderNativeObjectToCubeShadowMap(modelRef->nativeObject, p_renderOptions);
		}
	};
	typedef RandomDungeonDressing * RandomDungeonDressingPtr; // for node lists

	// dressing
	//////////////////

	/////////////
	// creature
	class RandomDungeonCreature
	{
	public:
		int type; // which model is it? (RandomDungoneObjectTypeEnum)

		Orient3d orient; // main orientation
		Orient3d *jointOrients; // joints if it's a joint model (initialized when model is assigned - if this is a reused object, it may reuse the existing joints or deallocate and reassign to make a larger array)
		int jointOrientQty; // how many were allocated?  If we need more, deallocate and reallocate
		JointedModelAnimationTracker jointedModelAnimationTracker;
		float scale; // full model for now, when shader supports x,y,z scaling, this can be a vector
		float renderRadius; // for determining node overlap
		RandomDungeonModel *modelRef; // how is it rendered?  Reference - do not destroy!
		LinkedList<PortalNodeIndex> nodesOverlapped; // which nodes does this creature overlap? for rendering

		int nodeIndex; // which node is this object actually in? (evaluated after object is moved with AI routine, for determining a good portal to head towards)
		int targetPortalIndex; // which portal owns the point this object is trying to move towards?
		Vector3d targetPosition; // target position to move towards
		float speed; // how fast is the object moving relative to its normal speed? (based off 1.0)

		int renderId; // was this object already rendered for the current final render?  If so, skip it
		int shadowRenderId; // was this object already rendered for the current shadow render?  If so, skip it

		// note: animation only refers to altering orientations for the purpose of rendering accurately, NOT actually moving the object around and interacting using AI routines.
		int animationId; // if animating during render to animate only local items, this prevents animating it twice in the case of rendering anaglyph

		RandomDungeonLightPtr lightRef; // does this creature have a light attached to it in some way? (keeps light position consistent with creature and allows maintenance of corresponding light
										//    as creature is animated)
										// Remember, all actual lights that exist in the dungeon are stored in the mapLights list and are kept coordinated with the nodeObjectLists[nodeId].lights

		// used only by arbiters, assumed to have a light attached
		RandomDungeonArbiterLightData arbiterLightData;
		float newSpotlightMS; // time for a new spotlight

		GameColor singleColor;
		bool useSingleColor;

		RandomDungeonCreature()
		{
			jointOrients = nullptr;
			Initialize();
		}

		~RandomDungeonCreature()
		{
			if (jointOrients != nullptr)
			{
				delete[] jointOrients;
				jointOrients = nullptr;
			}
		}

		// call this when a new node is created for adding to the dressings list - we might be retrieving one from the deleted list.
		void Initialize()
		{
			// note: we don't initialize jointOrients here - that happens later when we decide if we need to deallocate to make a larger array only. (not perfect, but it will do for now)
			orient.LoadIdentity();
			scale = 1.0f;
			renderRadius = 1.0f;

			modelRef = nullptr;
			nodesOverlapped.Clear();

			renderId = 0;
			shadowRenderId = 0;

			speed = 1.0f;

			nodeIndex = -1;
			targetPortalIndex = -1;

			lightRef = nullptr;
			newSpotlightMS = 2000.0f; // only some types use this

			useSingleColor = false;
		}

		void Render(GraphicsBase *p_graphics, GraphicsShaderOptions %p_renderOptions)
		{
			modelRef->CheckNativeObject(p_graphics);
			if (modelRef->jointedModel != nullptr)
			{
				modelRef->jointedModel->PrepareNativeObjectJointOrients(p_renderOptions.transformDataRef->GetOrients(), jointOrients, orient, scale);
			}

			// prep shader options
			p_renderOptions.vertexScale = scale;
			p_renderOptions.modelWorldOrientRef = &orient;

			p_renderOptions.lightingMaterialRef = &modelRef->material;

			GameColor *originalSingleColor = p_renderOptions.singleColorRef;
			if (useSingleColor == true)
				p_renderOptions.singleColorRef = &singleColor;

			// render it!
			p_graphics->RenderNativeObject(modelRef->nativeObject, p_renderOptions);
		}
		void RenderToFlatShadowMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_renderOptions)
		{
			// target shadow map must already be the target buffer!

			modelRef->CheckNativeObject(p_graphics);
			if (modelRef->jointedModel != nullptr)
			{
				modelRef->jointedModel->PrepareNativeObjectJointOrients(p_renderOptions.transformDataRef->GetOrients(), jointOrients, orient, scale);
			}

			// prep shader options
			p_renderOptions.vertexScale = scale;
			p_renderOptions.modelWorldOrientRef = &orient;

			// render it!
			p_graphics->RenderNativeObjectToShadowMap(modelRef->nativeObject, p_renderOptions);
		}
		void RenderToCubeShadowMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_renderOptions)
		{
			// target cube shadow map must already be the target buffer!

			modelRef->CheckNativeObject(p_graphics);
			if (modelRef->jointedModel != nullptr)
			{
				modelRef->jointedModel->PrepareNativeObjectJointOrients(p_renderOptions.transformDataRef->GetOrients(), jointOrients, orient, scale);
			}

			// prep shader options
			p_renderOptions.vertexScale = scale;
			p_renderOptions.modelWorldOrientRef = &orient;

			// render it!
			p_graphics->RenderNativeObjectToCubeShadowMap(modelRef->nativeObject, p_renderOptions);
		}
	};
	typedef RandomDungeonCreature * RandomDungeonCreaturePtr; // for node lists
	// creature
	///////////////

	//////////////
	// bullets
	// they don't cast shadows.  Render with additive blending, no sorting, billboarded to viewpoint along their travel axis using the polygon queue
	class RandomDungeonBullet
	{
	public:
		Vector3d position;
		Vector3d velocity;
		GameColor color;
		RandomDungeonLightPtr *lightRef; // which light in mapLights is this bullet associated with? (remove light when bullet is removed)
		int bounceQty; // if <= 0 destroy on next impact, otherwise ricochet during collision.
		float collisionRadius; // radius used for collisions (not rendering)
	};
	typedef RandomDungeonBullet * RandomDungeonBulletPtr; // for node lists
	// bullets
	//////////////

	// object references of objects that are in or overlap each node
	class RandomDungeonNodeObjectLists
	{
	public:
		LinkedList<RandomDungeonBallPtr> balls;
		LinkedList<RandomDungeonLightPtr> lights;
		LinkedList<RandomDungeonDressingPtr> dressings;
		LinkedList<RandomDungeonCreaturePtr> creatures;
		LinkedList<RandomDungeonBulletPtr> bullets;

		int lightsGameStateId; // which gameStateId were this node's lights prepared for?
		GraphicsShaderLightTally lightTally; // prepared lights

		DungeonNodeCellRange cellRange;

		RandomDungeonNodeObjectLists()
		{
			lightsGameStateId = -1;
		}
	};

	// wonderful source: http://journal.stuffwithstuff.com/2014/12/21/rooms-and-mazes/
	public ref class TestRandomDungeon : public GameBase
	{
	public:

		RandomDungeon *dungeon;
		TestRandomDungeonGenerateIteration *randomDungeonGenerateIteration;
		TestRandomDungeonMakePortalIteration *randomDungeonMakePortalIteration;
		PortalMap *portalMap;
		VolumePartition<LinkedList<PortalNodeIndex>> *portalPartition;
		LinkedList<RandomDungeonLight> *mapLights; // actual instances of all lights that exist (wall lights, attached to balls, attached to arbiters)
		bool dressingsPlaced;

		GraphicsShadowMapRegistry *shadowMapRegistry;

		// player
		Orient3d *playerOrient;
		float rotateAngleDegrees;
		float pitchAngleDegrees;
		float joystickRollAngleDegreesPerMS;
		float joystickPitchAngleDegreesPerMS;
		float joystickYawAngleDegreesPerMS;
		float joystickSlideFactor;
		float joystickMoveFactor;
		bool fireBullets; // should bullets be fired?
		// bullet behavior
		float bulletDelayMS; // time until next bullet can be fired - this is ALWAYS coutned down to zero and is left waiting for fireBullets to be set to true
		bool bulletHardpointLeft; // should left or right bullet be fired?  (toggle whenever a bullet is fired)
		float bulletSpeedPerMS; // what speed should bullets travel with? (bullet velocity magnitude = bulletSpeedPerMS)
		bool playerRun;
		RandomDungeonLight *playerLightRef;
		bool playerLightAttached;
		int playerLightType;

		Model3d *ball;
		GraphicsNativeObjectContainer *ballNativeObject;
		LinkedList<RandomDungeonBall> *balls;
		int currentPlayerControlBallId;
		float playerBallLaunchPower;
		float playerBallLaunchPowerIncreasePerMSf;
		float playerBallMaxLaunchPower;
		int ballsRendered;

		// dressing
		RandomDungeonModel *dungeonModelRegistry; // array
		LinkedList<RandomDungeonDressing> *dressings; // obelisks, hellraiser cubes, etc.
		LinkedList<RandomDungeonCreature> *creatures; // triguys, spiders, spider hunters, imps, etc.
		LinkedList<RandomDungeonBullet> *bullets; // ship and arbiter (or any other) bullets

		// array of lists = node Qty, tracks all balls overlapping each node.  Maintained by ball list after animation is done.  Balls track which nodes they are overlapping, this list tracks which balls overlap a node.
		// both list structures are kept in sync
		// maintenance is fast because balls are always handled in the same order, so the node that needs to be replaced is usually the first node found in the list
		// plus nodes are small so the number of balls overlapping each node is generally small anyway, but that balls are always handled in the same order even makes 200 balls in one node
		// maintain quickly
		RandomDungeonNodeObjectLists *nodeObjectLists;

		// rendering buffers for postprocessing
		GraphicsFrameBufferContainer *postProcessingFrameBuffer; // render to this frame when we will be doign post processing on it afterwards (has depth buffer and stencil)
		GraphicsFrameBufferContainer *postProcessingPingPongFrameBuffer; // use this frame when needing to ping pong post processing with multiple pass rendering (for now, max 2 for blur)
		GraphicsFrameBufferContainer *currentMainFramebuffer; // nullptr for main render view, otherwise points to postProcessingFrameBuffer for restoration after PrepareLights

		int objectParsesToRender;

		GameTimer *timer;
		float gameTimeMSf; // because we are using slow motion, track game time in the app for now

		float gravityPerMSMS;

		float fov;
		float fovBegin;
		float fovEnd;
		float fovInterpolationMS;
		float totalFovInterpolationMS;

		bool showInformation;
		bool showInstructions;
		bool fullFrustum;
		int stereoScopicMode; // 0 none, 1 anaglyph, 2 splitscreen
		float splitScreenEyeSeparationInches;
		float splitScreenCalibrationValue;
		bool usePartition;
		bool useLighting;
		bool useShadowMaps;
		bool useBackSideOfNodesForShadows;
		bool useWireframe;
		bool showExploredMap;
		bool freezeBalls;
		float slowMotionFactor;
		int maxLightQty;
		int portalDepth; // depth to render nodes in final render (all, 1 2 3 4 5 6)
		bool renderShadowNodes; // skip rendering of shadow maps?
		bool checkLightNodeBounds; // should we try to reject light nodes based on relation to light and final nodes to render?
		bool checkLightNodeBoundsHeavy; // only meaningful if checkLightNodeBounds is true - node checks are heavy for more chances for rejections (more cpu processing but less rendering, occasionally)
		bool useDarkvision; // use darkvision
		float grayScale; // 0.0 = normal, 1.0 = full grayscale  0.0-1.0 mix
		bool renderHiddenCreatures;
		// placements of obejcts during dungeon generation
		bool useMirrors; // a setting, and provides clarity in the code
		bool placeCreatures;
		bool placeDressings;
		bool placeFlames;
		bool placeWallLights;
		bool renderMirrorsWithNodesForDepthCulling; // render mirrors with node geometry in simple fashion to occupy depth buffer (depth culling prevents unnecessary complex fragment operations)
		bool useClipPlanes; // use clip planes while rendering mirrors (required to prevent objects 'behind' the mirror from showing up in the reflection!)
		bool useSingleClipPlane;
		bool allowShadowMapUpdating;
		bool useExceptionTest;
		bool joystickControl;
		int exceptionTestNodeTimerMS;
		float exceptionTestRoomSpinDegreesPerMS;
		bool useZeroMirrorAlpha;
		float gamma; // 2.0-2.4 if used, otherwise 1.0
		float fade; // 0.0-1.0
		// cull out rendering but allow all other parsing to check for cpu-side slowdowns (also allows selection of frame buffers and clearing, just no rendering)
		bool allowScreenRender;
		bool allowShadowMapRender;
		int minimumMirrorLightingDepth; // at what mirror depth should we allow lighting rendering? (all other parsing and light prep and shadow prep occurs, just lighting is not used in the render)
		int maximumRenderSectionAllowed; // at max mirror depth, which rendering section should we stop at? (portal parse, objects, nodes, etc.)
		// toggle out obejcts from various parts of rendering to test framerate
		bool allowObjectsInRender;
		bool allowObjectsInShadowMaps;
		bool allowParticles;
		int uniqueNodeQty;
		String ^uniqueNodeList;
		bool fastPortalParse;
		float blurRadius; // if != 0.0f, perform blur
		float focusByDepthRadius; // if != 0.0f, perform focusByDepth
		// assume anything closer than focusByDepthWorldZMin is entirely in focus
		float focusByDepthWorldZMin; // world z depth to start blur
		float focusByDepthWorldZMax; // world z depth to maximimze blur
		float *blurKernel;
		int blurKernelElementQty;
		float lens;

		// artifacting preventing on mirror edges
		float mirrorClipPlaneNormalAdjustment;
		float mirrorOrientAdjustment;

		int maxMirrorDepth; // mirrors rendered at max depth will be solid instead of rendering their reflections

		int colliderSetsExecuted;
		int parsesToMaintainNodeBallLists;

		// game stuff
		int sconceMode; // 0 = normal, 1 = red, 2 = angelic
		Vector3d *ambientColor;
		Vector3d *ambientColorStart;
		Vector3d *ambientColorEnd;
		Vector3d *ambientColorBase;
		float ambientInterpolationMS;
		float totalAmbientInterpolationMS;

		// halloween stuff
		JointedModel3d *triguy;
		JointedModel3d *triguyRedEyes;
		Orient3d *triguyOrient;
		Orient3d *triguyRedEyesOrient;
		Orient3d *triguyJointOrients;
		JointedModelAnimationTracker *triguyAnimationTracker;
		GraphicsNativeObjectContainer *triguyNativeObject;
		GraphicsNativeObjectContainer *triguyRedEyesNativeObject;
		float jumpScareTimerMSf; // if 0 nothing is happening.  otherwise, following a schedule
		float lightScale;
		Orient3d *sarahOrient;
		Model3d *sarahModel;
		float sarahTimerMSf;
		GraphicsParticleQueue *particleQueue;

		GraphicsShaderAppSettings *shaderAppSettings;

		TestRandomDungeon(HWND p_hWnd);
		~TestRandomDungeon();
		void Initialize() override;
		void DestroyGameData();
		void Destroy() override;
		void ViewportSizeChanged(GameViewport ^p_viewport) override;
		bool DoGameLoop() override;
		void InterpolateAmbientColor(float p_elapsedTimeMSf);
		void InterpolateFov(float p_elapsedTimeMSf);
		LinkedListNode<RandomDungeonBall> * MakeDungeonBallNode();
		void AnimatePlayer(float p_elapsedTimeMSf, Vector3d &p_playerMoveVector, float p_playerMoveSpeed);
		void CycleBulletDelay(float &p_bulletDelayMS);
		void FireBullet(Orient3d &p_playerOrient, bool p_left, GameColor &p_color);
		void Animate(float p_elapsedTimeMSf);
		void AnimateBalls(float p_elapsedTimeMSf);
		void AnimateBall(RandomDungeonBall *p_ball, float p_elapsedTimeMSf);
		void MaintainBallAndLightNodeLists();
		void MaintainLightNodeLists(RandomDungeonLight *p_light);
		void AnimateCreatures(float p_elapsedTimeMSf);
		void MaintainCreatureNodeList(RandomDungeonCreature &p_creature);
		void RunRandomDungeonGenerateIterations(int p_steps);
		void RunRandomDungeonMakePortalIterations(int p_steps);
		void DoRandomDungeonGenerateIteration();
		void DoRandomDungeonMakePortalIteration();
		LinkedListNode<RandomDungeonLight> * MakeNewLight();
		void MakeNodeColliderSets();

		// rendering is in .cpp file:
		void PerformRender() override;
		void RenderRandomDungeon(GraphicsBase *p_graphics, GameColor &p_rockColor, GameColor &p_clearColor, GameColor &p_borderRoom, bool p_showObjectsAndPlayer);
		void RenderInfo(GraphicsBase *p_graphics, int p_nodesParsedForFirstNode, int p_nodesRenderedQty, int p_lightNodesRenderedQty, int p_lightNodesRerenderedQty, int p_frameBufferChangesQty, int p_totalLightsRenderedQty, int p_lightsSkipped, int p_lightNodesRejected);
		void ShowInstructions(GraphicsBase *p_graphics);
		void RenderDungeon(GraphicsBase *p_graphics, int &p_nodesParsedForFirstNode, int &p_nodesRenderedQty, int &p_lightNodesRenderedQty, int &p_lightNodeRerendersQty, int &p_frameBufferChangesQty, int &p_totalLightsRendered, int &p_lightsSkipped, int &p_lightNodesRejected);
		void SetMainProjection(GraphicsBase *p_graphics, Orient3d *p_viewpointOrient, float p_fov, float p_nearPlane, float p_farPlane, StereoscopicCamera *p_camera, bool p_left);
		void DrawElements(GraphicsBase *p_graphics, Orient3d *p_viewpointOrient, Frustum *p_defaultFrustum, float p_fov, float p_nearPlane, float p_farPlane, int &p_nodesParsedForFirstNode, int &p_nodesRenderedQty, int &p_lightNodesRenderedQty, int &p_lightNodeRerendersQty, int &p_frameBufferChanges, int &p_totalLightsRendered, int &p_lightsSkipped, int &p_lightNodesRejected, StereoscopicCamera *p_camera, bool p_left, int p_mainRenderId, int p_firstPortalNodeIndex, int p_mirrorDepth, Vector3d &p_clipPlanePosition, Vector3d &p_clipPlaneNormal, PortalParseResult *p_parseResultData, PortalParseResultList *p_resultList, BoundingVolume3d *p_finalNodeBoundVolume);
		void PrepareLightsAndShadowsForNode(GraphicsBase *p_graphics, LinkedList<PortalNodeIndex> &p_nodesToRender, Orient3d *p_worldOrientRef, int p_nodeIndex, BoundingVolume3d *p_finalNodeBoundingVolume, GraphicsShaderOptions %p_shaderOptions, int &p_lightsSkipped, int &p_lightNodesRejected, int &p_lightNodesRenderedQty, int &p_lightNodeRerendersQty, int &p_frameBufferChanges, int p_gameStateRenderId, int p_currentRenderId, bool &p_restoreMainProjection, Matrix4d *p_lightMVPs, float p_nearPlane, float p_farPlane, RandomDungeonNodeObjectLists *p_nodeObjectLists, float p_elapsedTimeMSf);
		void SelectShadowFrameBuffer(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, GraphicsShaderLightPtr p_lightRef, bool p_clear, bool &p_restoreMainProjection, Matrix4d *p_lightMVPs, float p_nearPlane, float p_farPlane);
		void RenderFrustum(GraphicsBase *p_graphics, Frustum &p_frustum, GameColor &p_color);
		void SetBlurKernel(int p_kernalItemQty);
	};

	public ref class BitonicSortTest : public GameBase
	{
	public:

		int *randomValues; // positive random numbers (if any are negative, they were swapped... render as red once then swap back to positive)
		int randomValueQty;
		// general iteration trackers
		int sortIteration1, sortIteration2, sortIteration3, sortIteration4;
		int parseQty;
		bool bubbleSort;

		BitonicSortTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			randomValues = nullptr;
			randomValueQty = 0;
		}

		virtual ~BitonicSortTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			randomValueQty = 4096; // require power of 2 - if changed to 2049, throws exception.  why?
			randomValues = new int[randomValueQty];

			ResetData(true);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (randomValues != nullptr)
			{
				delete [] randomValues;
				randomValues = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			if (keyboardKeys.GetKey('U')->IsClicked())
			{
				ResetData(true);
			}
			if (keyboardKeys.GetKey('I')->IsClicked())
			{
				ResetData(false);
			}
			keyboardKeys.ClearClicked();

			PerformSortIteration();

			return true;
		}

		void ResetData(bool p_bubbleSort)
		{
			FastRandom fastRandom;
			// initialize
			for (int i = 0; i < randomValueQty; i++)
			{
				randomValues[i] = -1;
			}
			// now set them 1 to randomValueQty in random indices
			int slotsRemaining = randomValueQty;
			bool placeInOrder = false; // place pre-sorted for display test
			for (int i = 1; i <= randomValueQty; i++)
			{
				int index = 0;
				int openSlotCount = fastRandom.GetRandomInteger(1, slotsRemaining);
				if (placeInOrder == true)
					openSlotCount = 1;
				for (int j = 0; j < randomValueQty; j++)
				{
					if (randomValues[j] == -1)
						index++;

					if (index == openSlotCount)
					{
						randomValues[j] = i;
						break;
					}
				}

				slotsRemaining--;
			}
			sortIteration1 = 0;
			sortIteration2 = 0;
			sortIteration3 = 0;
			sortIteration4 = 0;
			parseQty = 0;

			bubbleSort = p_bubbleSort;
		}

		void PerformSortIteration()
		{
			if (sortIteration1 == -1)
				return;

			if (bubbleSort == true)
			{
				for (int i = 0; i < 400; i++)
					PerformBubbleSortIteration();
			}
			else
			{
				for (int i = 0; i < 100; i++)
					PerformBitonicSortIteration();
			}
		}

		void PerformBubbleSortIteration()
		{
			// are we done?
			if (sortIteration1 == -1)
				return;

			// did we just start?
			if (sortIteration1 == 0 && sortIteration2 == 0)
			{
				sortIteration1 = randomValueQty - 2;
				sortIteration2 = 0;
				sortIteration3 = -1;
			}

			// sortIteration1 is the stopping point
			// sortIteration2 +1 are the elements being compared
			// sortIteration3 is where to start the next loop (-1 if no need to start it) - if used, saves 1/30 of parsing.  It's something, but requires an extra compare on every parse
			// but with sortIteration3, with a mostly sorted list, we would also stop early.
			bool swapOccurred = false;
			while (swapOccurred == false)
			{
				// make sure we are comparing positives
				parseQty++;
				if (abs(randomValues[sortIteration2]) > abs(randomValues[sortIteration2 + 1]))
				{
					int temp = randomValues[sortIteration2];
					randomValues[sortIteration2] = randomValues[sortIteration2 + 1];
					randomValues[sortIteration2 + 1] = temp;

					// make them negative for display
					if (randomValues[sortIteration2] > 0)
						randomValues[sortIteration2] = -randomValues[sortIteration2];
					if (randomValues[sortIteration2 + 1] > 0)
						randomValues[sortIteration2 + 1] = -randomValues[sortIteration2 + 1];

					// establish next starting point
					if (sortIteration3 == -1 && sortIteration2 > 0)
					{
						if (abs(randomValues[sortIteration2 - 1]) > abs(randomValues[sortIteration2]))
							sortIteration3 = sortIteration2 - 1;
					}

					swapOccurred = true;
				}

				sortIteration2++;
				if (sortIteration2 > sortIteration1)
				{
					// start over, recede stopping point
					if (sortIteration3 == -1)
					{
						// no need to start again
						sortIteration1 = -1;
						break;
					}

					sortIteration2 = sortIteration3; // or zero, if sortIteration3 not used
					// reset search for next starting point
					sortIteration3 = -1;

					sortIteration1--;
					if (sortIteration1 == 0)
					{
						// done
						sortIteration1 = -1;
						break;
					}
				}
			}
		}

		void PerformBitonicSortIteration()
		{
			// source: http://performanceguidelines.blogspot.com/2013/08/sorting-algorithms-on-gpu.html

			// are we done?
			if (sortIteration1 == -1)
				return;

			// did we just start?
			if (sortIteration1 == 0 && sortIteration2 == 0)
			{
				sortIteration1 = 2;
				sortIteration2 = 2;
				sortIteration3 = 0;
				sortIteration4 = 0;
			}

			// sortIteration1 is the main series (2,4,8,16...,>=elementQuantity)
			// sortIteration2 is the iteration within a series (2,4,8, ..., sortIteration1)
			// sortIteration3 is the first element to compare and swap, always start at zero (compare and swap [sortIteration3] and [sortIteration3 + sortIteration1/sortIteration2], sortIteration3++, flip direction when sortIteration3 is a multiple of sortIteration1, stop when sortIteration3 + sortIteration1/sortIteration2 > elementQty, stop ENTIRELY when this occurs on the first swap)
			// sortIteration4 is the sort direction (0,1,2,3,4) mod %2 = 1 means down, else up
			bool swapOccurred = false;
			while (swapOccurred == false)
			{
				// make sure we are comparing positives
				parseQty++;

				if (sortIteration4 % 2 == 0)
				{
					// sort down
					if (abs(randomValues[sortIteration3]) > abs(randomValues[sortIteration3 + sortIteration1 / sortIteration2]))
					{
						int temp = randomValues[sortIteration3];
						randomValues[sortIteration3] = randomValues[sortIteration3 + sortIteration1 / sortIteration2];
						randomValues[sortIteration3 + sortIteration1 / sortIteration2] = temp;

						// make them negative for display
						if (randomValues[sortIteration3] > 0)
							randomValues[sortIteration3] = -randomValues[sortIteration3];
						if (randomValues[sortIteration3 + sortIteration1 / sortIteration2] > 0)
							randomValues[sortIteration3 + sortIteration1 / sortIteration2] = -randomValues[sortIteration3 + sortIteration1 / sortIteration2];

						swapOccurred = true;
					}
				}
				else
				{
					// sort up
					if (abs(randomValues[sortIteration3]) < abs(randomValues[sortIteration3 + sortIteration1 / sortIteration2]))
					{
						int temp = randomValues[sortIteration3];
						randomValues[sortIteration3] = randomValues[sortIteration3 + sortIteration1 / sortIteration2];
						randomValues[sortIteration3 + sortIteration1 / sortIteration2] = temp;

						// make them negative for display
						if (randomValues[sortIteration3] > 0)
							randomValues[sortIteration3] = -randomValues[sortIteration3];
						if (randomValues[sortIteration3 + sortIteration1 / sortIteration2] > 0)
							randomValues[sortIteration3 + sortIteration1 / sortIteration2] = -randomValues[sortIteration3 + sortIteration1 / sortIteration2];

						swapOccurred = true;
					}
				}

				sortIteration3++;
				// will we sample past the end of the list of we continue?
				if (sortIteration3 + sortIteration1 / sortIteration2 >= randomValueQty)
				{
					// time for a new iteration
					if (sortIteration2 < sortIteration1)
					{
						// next iteration within a series
						sortIteration2 = sortIteration2 * 2;
						sortIteration3 = 0;
						sortIteration4 = 0;
					}
					else
					{
						// new iteration

						// if we haven't even flipped direction yet, we're done, we're in the final series
						if (sortIteration4 == 0)
						{
							// we are DONE!
							sortIteration1 = -1;
							break;
						}
						else
						{
							// next series
							sortIteration1 = sortIteration1 * 2;
							sortIteration2 = 2;
							sortIteration3 = 0;
							sortIteration4 = 0;
						}
					}
				}
				else
				{
					// obey the pattern of the bitonic network graph

					if (sortIteration3 % (sortIteration1 / sortIteration2) == 0)
					{
						// skip ahead
						sortIteration3 += (sortIteration1 / sortIteration2);
					}
					if (sortIteration3 % sortIteration1 == 0)
					{
						// flip sort direction
						sortIteration4++;
					}
				}
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->Set2dWindowProjection();

			RenderRandomValueList(graphics);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderRandomValueList(GraphicsBase *p_graphics)
		{
			p_graphics->SetDepthWriteEnabled(false);

			float lineOffset = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth()) / float(randomValueQty);
			float viewportHeight = float(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight());
			float lineWidth = lineOffset;
			if (lineWidth < 1.0f)
				lineWidth = 1.0f;

			GameColor white(255, 255, 255);
			GameColor red(255, 0, 0);
			float scale = viewportHeight / float(randomValueQty);
			for (int i = 0; i < randomValueQty; i++)
			{
				System::Drawing::RectangleF rect(lineOffset * (float(i) + 0.5f) - lineWidth / 2.0f, viewportHeight - float(abs(randomValues[i])) * scale, lineWidth, float(abs(randomValues[i])) * scale);
				if (randomValues[i] > 0)
					p_graphics->RenderFilledRectangle(rect, white);
				else
				{
					// render as red, swap back to positive
					p_graphics->RenderFilledRectangle(rect, red);
					randomValues[i] = -randomValues[i];
				}
			}

			// render info
			if (bubbleSort == true)
				p_graphics->RenderFont(String::Format("Bubble Sort"), GameContext::Instance->FontRegistry.GetFont("Info"), 10, GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 3, GameColor(0, 0, 0));
			else
				p_graphics->RenderFont(String::Format("Bitonic Sort"), GameContext::Instance->FontRegistry.GetFont("Info"), 10, GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 3, GameColor(0, 0, 0));
			p_graphics->RenderFont(String::Format("Parses: {0}", parseQty), GameContext::Instance->FontRegistry.GetFont("Info"), 10, GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight() - GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight() * 2, GameColor(0, 0, 0));

			p_graphics->SetDepthWriteEnabled(true);

		}

	};

	class TestParticle
	{
	public:
		GameColor color;
		int maxLifeMS; // when should it go away
		bool dead; // dead particle - do not render, assume all particles past this particle are also dead

		// alpha formula for ax+b, where x = lifeMS, usually similar to b-ax where b is max alpha and b-a*maxLifeMS = 0
		// note: max alpha is 1.0, NOT 255
		float alphaA;
		float alphaB;

		// position = at^2 + bt + c, t = lifeMS
		// c is usually start position
		// for a particle that simply floats in a direction, b is the velocity
		// for a particle that responds to gravity, with v = original velocity and g = gravity acceleration:
		//   - c = original position, b = v, and a = 1/2*g
		Vector3d positionA;
		Vector3d positionB;
		Vector3d positionC;

		// linear calculation of radius: a*t+b;
		// for constant radius, a = 0 and b = original radius
		// for expanding radius, a = expansion rate per MS and b = original radius
		float radiusA;
		float radiusB;

		// value for sorting high to low, calculate before each render with a given viewpoint, sorted before render
		float zDepth;

		// other data for rendering
		float rotationAngleDegrees;

		// calculated values
		float lifeMS; // how long has it existed
		Vector3d position;
		float radius;
		float alpha;

		TestParticle()
		{
			Initialize();
		}

		void Initialize()
		{
			lifeMS = 0.0f;
			maxLifeMS = 1000000; // 100 seconds, will be reduced later
			rotationAngleDegrees = 0.0f;
			dead = true; // until some form of values set
		}

		void SetAlphaFormula(float p_startAlpha, float p_alphaReductionPerMS, int p_maxLifeMS = 0)
		{
			alphaB = p_startAlpha;
			if (p_alphaReductionPerMS != 0)
			{
				alphaA = -p_alphaReductionPerMS;
				maxLifeMS = int(p_startAlpha / p_alphaReductionPerMS);
			}
			else
			{
				alphaA = 0;
				maxLifeMS = p_maxLifeMS;
			}
			if (maxLifeMS == 0)
			{
				throw gcnew Exception("Max Life MS cannot be 0");
			}
			if (maxLifeMS < 0)
			{
				throw gcnew Exception("Max Life MS cannot be negative");
			}
			dead = false;
		}

		void SetRadiusFormula(float p_startRadius, float p_radiusExpansionPerMS = 0.0f)
		{
			radiusB = p_startRadius;
			radiusA = p_radiusExpansionPerMS;
			if (radiusA < 0.0)
			{
				int tempMaxLifeMS = int(radiusB / -radiusA);
				if (tempMaxLifeMS == 0)
				{
					throw gcnew Exception("Max Life MS cannot be 0");
				}
				if (tempMaxLifeMS < 0)
				{
					throw gcnew Exception("Max Life MS cannot be negative");
				}

				if (tempMaxLifeMS < maxLifeMS)
					maxLifeMS = tempMaxLifeMS;

				dead = false;
			}
		}

		void SetPositionFormula(Vector3d &p_startPosition, Vector3d &p_velocityPerMS)
		{
			positionC = p_startPosition;
			positionB = p_velocityPerMS;
			positionA = Vector3d(0,0,0);
			dead = false;
		}

		void SetPositionFormula(Vector3d &p_startPosition, Vector3d &p_startVelocityPerMS, Vector3d &p_accelerationPerMSMS)
		{
			positionC = p_startPosition;
			positionB = p_startVelocityPerMS;
			positionA = p_accelerationPerMSMS;
			dead = false;
		}

		//////////////////////////////////////
		// do this before calling Calculate
		void SetLife(float p_elapsedTimeMSf)
		{
			lifeMS += p_elapsedTimeMSf;
			if (lifeMS >= maxLifeMS)
				dead = true;
		}

		bool IsDead()
		{
			return dead;
		}

		/////////////////////////////////
		// calculation before rendering
		void PrepareAlpha()
		{
			if (alphaA == 0)
				alpha = alphaB;
			else
				alpha = alphaB + alphaA * lifeMS;
		}

		void PreparePosition()
		{
			position = positionA.ScalarMult(lifeMS * lifeMS) + positionB.ScalarMult(lifeMS) + positionC;
		}

		void PrepareRadius()
		{
			if (radiusA == 0.0f)
				radius = radiusB;
			else
				radius = radiusB + radiusA * lifeMS;
		}

		//////////////////////////////////////////////////
		// zDepth calculation - need to store for sorting
		void PrepareZDepth(Vector3d &p_viewpointOrigin, Vector3d &p_viewpointForwardVector)
		{
			zDepth = (position - p_viewpointOrigin) * p_viewpointForwardVector;
		}

		Vector3d CalculateRenderOffset(Orient3d &p_viewpointOrient)
		{
			Vector3d offset = position - p_viewpointOrient.p;
			return Vector3d(
				offset * p_viewpointOrient.l,
				offset * p_viewpointOrient.u,
				zDepth
				);
		}
	};

	public ref class BitonicThread
	{
	private:
		int startIndex;
		int parseQty;
		int modCheck;
		TestParticle *particles;
		int particleQty;
		int mainSeries;
		int swapDirection;

	public:
		BitonicThread(int p_startIndex, int p_parseQty, int p_modCheck, TestParticle *p_particles, int p_particleQty, int p_mainSeries, int p_swapDirection)
		{
			startIndex = p_startIndex;
			parseQty = p_parseQty;
			modCheck = p_modCheck;
			particles = p_particles;
			particleQty = p_particleQty;
			mainSeries = p_mainSeries;
			swapDirection = p_swapDirection;
		}

		void BitonicSort()
		{
			int index = startIndex;
			int parses = 0;
			while (parses < parseQty)
			{
				parses++;

				////////////////////////
				// new thread here!  perform this operation in it!
				// index and index + modCheck will never be equal to any of the values sent to the other threads, so none will ever step on each other (0-4, 1-5, 2-6, 3-7, 8-12, 9-13, etc.)
				// optionally, provide values so that multiple pairs are checked and swapped to reduce the number of threads needed (ideally, split all the work among # threads = cpu)
				// threadQty++;

				// do a compare and swap
				bool swap = false;
				if (index + modCheck >= particleQty)
					throw gcnew System::Exception("index + modCheck goes past end of particles");
				if (swapDirection % 2 == 0)
				{
					// down (normal)
					if (particles[index].dead == true && particles[index + modCheck].dead == false)
						swap = true;
					else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth < particles[index + modCheck].zDepth)
						swap = true;
				}
				else
				{
					// up
					if (particles[index].dead == false && particles[index + modCheck].dead == true)
						swap = true;
					else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth > particles[index + modCheck].zDepth)
						swap = true;
				}

				if (swap == true)
				{
					TestParticle temp = particles[index];
					particles[index] = particles[index + modCheck];
					particles[index + modCheck] = temp;
				}

				// todo: thread reports that it is complete on a mutex guarded int (increment it)

				// end thread!
				//////////////////////////

				index++;
				if (index % modCheck == 0)
				{
					index += modCheck;

					if (index % mainSeries == 0)
						swapDirection++;
				}
			}
		}
	};

	public ref class TestParticles : public GameBase
	{
	public:

		// it is assumed that a single particle array is always made up of the same texture and blend aspects.  However each particle can have its own rotation, position and alpha
		// todo: move this to a more intelligent structure that guides the renderer to prep blend aspects and need for sorting (addition particles need not be sorted for depth, but dead ones still need to be moved out)
		//    So, a simple array cannot take advantage of being a mostly sorted list for a bubble sort - that only works when the badly sorted particles are at one end.  When particles die and new ones
		//    are created, dead ones could be anywhere and the new ones will always be at the start of the dead list, so it isn't possible to reliably sort from one end or the other and be done quickly
		// note: linked list particles can have their dead ones moved away and have no limit on size, but sorting that runs faster with indexing will run VERY slow with a linked list
		//TestParticle *particles;
		//int particleQty;
		//int particleArraySize;
		//int deadParticleIndex;
		ParticleArray *particles;
		GraphicsNativeParticlesContainer *particleNative;

		Orient3d *cameraOrient;
		GameTimer *timer;

		bool renderNative;

		int particleMode; // 0 = spiral, 1 = fountain, 2 = missile line
		Vector3d *missileStart;
		Vector3d *missileEnd;
		float spiralAngleDegrees, spiralRadius, spiralDegreesPerMS;
		float particleTravelOffset;
		float particleTravelOffsetPerMS;
		float particleCreationPerMS;
		float particleCurrentMSLeft;

		TestParticles(HWND p_hWnd) : GameBase(p_hWnd)
		{
			particles = nullptr;
			cameraOrient = nullptr;
			timer = nullptr;
			particleNative = nullptr;
			renderNative = false;
		}

		virtual ~TestParticles()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 12));

			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Smoke", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("SmokePuff1.jpg"));

			particles = new ParticleArray(8192, 4096, 1);
			particles->SetTexture(0, GameContext::Instance->TextureRegistry.GetTexture("Smoke"));
			//particleArraySize = 8192;
			//particleQty = 4096;
			//deadParticleIndex = 0;
			//particles = new TestParticle[particleArraySize];
			particleMode = 0;
			missileStart = new Vector3d();
			missileEnd = new Vector3d();
			spiralAngleDegrees = 0;
			spiralRadius = 1.0f;
			spiralDegreesPerMS = 360.0f / 1000.0f; // one rotation per second
			particleCreationPerMS = 1.0f; // create one particle every 1 ms
			particleCurrentMSLeft = 0.0f;
			particleTravelOffset = 1.1f; // force initial creation of travel points
			particleTravelOffsetPerMS = 1.0f / 1000.0f; // 1 sec to complete traveling from start to end
			*missileStart = Vector3d(0, 0, 0);
			*missileEnd = Vector3d(0, 0, 0);

			// back up the camera
			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(3.0f);

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (particles != nullptr)
			{
				delete particles;
				particles = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (missileStart != nullptr)
			{
				delete missileStart;
				missileStart = nullptr;
			}
			if (missileEnd != nullptr)
			{
				delete missileEnd;
				missileEnd = nullptr;
			}
			if (particleNative != nullptr)
			{
				delete particleNative;
				particleNative = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		// todo: in sort, move deadParticleIndex
		// todo: create new particle - get new particle index

		bool DoGameLoop() override
		{
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// bank jet according to x offset (number of degrees), always on orient.f vector
				cameraOrient->Rotate(cameraOrient->f, float(mouse.offsetX) / 5.0f);
			}
			else if (mouse.leftButton.down)
			{
				// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
				cameraOrient->Rotate(Vector3d::Vector(0, 1, 0), float(mouse.offsetX) / 5.0f);
				// pitch jet according to y offset (number of degrees), always on l vector
				cameraOrient->Rotate(cameraOrient->l, -float(mouse.offsetY) / 5.0f);
			}
			// reposition camera based on its orientation
			cameraOrient->p = Vector3d(0,0,0) - cameraOrient->f.ScalarMult(5.0f);

			mouse.ZeroOffsets();

			if (keyboardKeys.GetKey('E')->IsClicked())
			{
				particleMode++;
				if (particleMode >= 3)
					particleMode = 0;
			}
			if (keyboardKeys.GetKey('P')->IsClicked())
			{
				int particleQty = particles->particleQty;
				particleQty *= 2;
				if (particleQty > particles->arraySize)
					particleQty = 512;
				particles->SetParticleQty(particleQty);
			}
			if (keyboardKeys.GetKey('V')->IsClicked())
			{
				particles->SetVerifySort(!(particles->verifySort));
			}
			if (keyboardKeys.GetKey('N')->IsClicked())
			{
				renderNative = !renderNative;
			}
			keyboardKeys.ClearClicked();

			////////////////////

			AnimateParticle(timer->GetElapsedTimeMSFloat());

			return true;
		}

		void AnimateParticle(float p_elapsedTimeMSf)
		{
			static FastRandom fastRandom;

			// depending on particle emitter mode, create a particle
			// create with negative lifeMS relative to amount of MS in gametick - Render will add lifeMS to them for the render, so particle created at end of animate should receive -elapsedTime
			//   and those created at very beginning should get 0
			float timeToConsumeMSf = p_elapsedTimeMSf;
			while (timeToConsumeMSf > 0.0f)
			{
				bool create = false;
				float animateMSf = 0;
				if (particleCurrentMSLeft <= timeToConsumeMSf)
				{
					animateMSf = particleCurrentMSLeft;
					create = true;
					timeToConsumeMSf -= particleCurrentMSLeft;
					particleCurrentMSLeft = particleCreationPerMS;
				}
				else
				{
					animateMSf = timeToConsumeMSf;
					timeToConsumeMSf = 0;
				}

				switch (particleMode)
				{
				case 0: // spiral
					{
						// animate emitter
						spiralAngleDegrees += spiralDegreesPerMS * animateMSf;
						while (spiralAngleDegrees >= 360.0f)
							spiralAngleDegrees -= 360.0f;
						while (spiralAngleDegrees < 0.0f)
							spiralAngleDegrees += 360.0f;

						if (create == true)
						{
							GameEng::Graphics::Particle *newParticle = particles->AddNewParticle();
							if (newParticle != nullptr)
							{
								newParticle->Initialize();
								// create a particle on the spiral that floats slowly upwards
								newParticle->SetPositionFormula(
									Vector3d(
										float(spiralRadius * sin(MathUtilities::DegreesToRadians(spiralAngleDegrees))),
										0.0f,
										float(spiralRadius * cos(MathUtilities::DegreesToRadians(spiralAngleDegrees)))
										),
									Vector3d(0, 1.0f / 4000.0f, 0));
								newParticle->SetAlphaFormula(1.0f, 1.0f / float(particles->particleQty));
								newParticle->SetRadiusFormula(0.05f, 0.1f / float(particles->particleQty));
								unsigned char randomColor = fastRandom.GetRandomInteger(0, 255);
								newParticle->color = GameColor(randomColor, randomColor, randomColor);
								newParticle->rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
								newParticle->lifeMS = timeToConsumeMSf - p_elapsedTimeMSf;
							}
						}
					}
					break;
				case 1: // fountain
					{
						if (create == true)
						{
							GameEng::Graphics::Particle *newParticle = particles->AddNewParticle();
							if (newParticle != nullptr)
							{
								float angle = float(fastRandom.GetRandomInteger(0, 359));
								float speed = 0.0007f;
								newParticle->Initialize();
								// create a particle on the spiral that floats slowly upwards
								newParticle->SetPositionFormula(
									Vector3d(0, 0, 0),
									Vector3d(
										speed * sin(MathUtilities::DegreesToRadians(angle)),
										1.5f * speed,
										speed * cos(MathUtilities::DegreesToRadians(angle))
										),
									Vector3d(0, -32.0f / 10.0f / 1000.0f / 1000.0f / 8.0f, 0)
									);
								newParticle->SetAlphaFormula(1.0f, 1.0f / float(particles->particleQty));
								newParticle->SetRadiusFormula(0.05f, 0.1f / float(particles->particleQty));
								unsigned char randomColor = fastRandom.GetRandomInteger(0, 255);
								newParticle->color = GameColor(randomColor, randomColor, randomColor);
								newParticle->rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
								newParticle->lifeMS = timeToConsumeMSf - p_elapsedTimeMSf;
							}
						}

					}
					break;
				case 2:
					{
						// animate emitter
						particleTravelOffset += (particleTravelOffsetPerMS * animateMSf);
						while (particleTravelOffset > 1.0f)
						{
							*missileStart = *missileEnd;
							*missileEnd = Vector3d(float(fastRandom.GetRandomInteger(0, 100) - 50) / 50.0f, float(fastRandom.GetRandomInteger(0, 100) - 50) / 50.0f, float(fastRandom.GetRandomInteger(0, 100) - 50) / 50.0f);
							particleTravelOffset -= 1.0f;
						}
						if (create == true)
						{
							GameEng::Graphics::Particle *newParticle = particles->AddNewParticle();
							if (newParticle != nullptr)
							{
								newParticle->Initialize();
								// create a particle on the spiral that floats slowly upwards
								newParticle->SetPositionFormula(
									*missileStart + (*missileEnd - *missileStart).ScalarMult(particleTravelOffset),
									Vector3d(0, 0, 0));
								newParticle->SetAlphaFormula(1.0f, 1.0f / float(particles->particleQty));
								newParticle->SetRadiusFormula(0.05f, 0.1f / float(particles->particleQty));
								unsigned char randomColor = fastRandom.GetRandomInteger(0, 255);
								newParticle->color = GameColor(randomColor, randomColor, randomColor);
								newParticle->rotationAngleDegrees = float(fastRandom.GetRandomInteger(0, 359));
								newParticle->lifeMS = timeToConsumeMSf - p_elapsedTimeMSf;
							}
						}

					}
					break;

				}
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			Matrix4d mvpMatrix = graphics->GetMVPMatrix();

			// prep the particles (calculate position, zDepth, sort them all)
			// note: particles created this tick will also move this tick.  consider placing SetLife elsewhere, such as before new particles are placed
			if (renderNative == false)
				graphics->RenderParticles(timer->GetElapsedTimeMSFloat(), *cameraOrient, *particles);
			else
			{
				// animate and sort
				particles->PrepareParticlesForRendering(timer->GetElapsedTimeMSFloat(), cameraOrient->p, cameraOrient->f);

				if (particleNative == nullptr)
					particleNative = new GraphicsNativeParticlesContainer();
				if (particleNative->nativeParticlesRef == nullptr)
					graphics->CreateNativeParticles(particleNative, particles);
				GraphicsShaderParticlesOptions particleOptions; // just use defaults for now

				// note: if particles need and animating sorting in GPU, this has to change (deadParticleIndex isn't known until after sorting which must happen after animating)
				particleOptions.particleQty = particles->deadParticleIndex;
				particleOptions.mvpMatrixRef = &mvpMatrix;
				particleOptions.leftVPAxisRef = &(cameraOrient->l);
				particleOptions.upVPAxisRef = &(cameraOrient->u);

				graphics->SetDepthWriteEnabled(false);
				graphics->RenderNativeParticles(particleNative, particleOptions, particles);
				graphics->SetDepthWriteEnabled(true);
			}

			//for (int i = 0; i < particleQty; i++)
			//{
			//	TestParticle *particle = &particles[i];
			//	// if dead, we are done
			//	if (particle->IsDead())
			//		break;

			//	particle->SetLife(timer->GetElapsedTimeMSFloat());
			//	if (particle->IsDead() == false)
			//	{
			//		particle->PreparePosition();
			//		particle->PrepareZDepth(cameraOrient->p, cameraOrient->f);
			//	}
			//}
			//SortParticles();

			// sort them - back to front by position and move all the farther live ones to the end, and dead ones to the far end (at this point, dead ones are intermixed with live ones)
			// bubble sort if only a few particle to move, otherwise arbitrary length bitonic or quick sort
			// ??

			// now dead ones are all at the end and we can stop when we hit one

			/////////////////////////////
			// Render Particles
			//graphics->SetDepthWriteEnabled(false);

			//// set up render as a billboard (using a quad that faces the origin along the space's z axis)
			//graphics->PushMatrix();
			//graphics->DefaultTransform();

			//// it is assumed that a single particle array is always made up of the same texture and blend aspects.  However each particle can have its own rotation, position and alpha
			//// render the particles
			//GameColor particleColor;
			//ModelVertex particleVertices[4] = { ModelVertex(Vector3d(1, 1, 0), 0), ModelVertex(Vector3d(-1, 1, 0), 0), ModelVertex(Vector3d(-1, -1, 0), 0), ModelVertex(Vector3d(1, -1, 0), 0) };
			//ModelVertexTextureCoords particleTexCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			//GameTexture ^particleTexture = GameContext::TextureRegistry.GetTexture("Smoke");
			////bool testParticleRender = true;
			////if (testParticleRender == true)
			////{
			////	graphics->PushMatrix();
			////	graphics->Translate(Vector3d(0,0,1));
			////	particleColor = GameColor(255, 255, 255, 255);
			////	graphics->RenderFilledQuad(&particleColor, 1, particleVertices, 4, true);
			////	//graphics->RenderFilledQuad(&particleColor, 1, particleVertices, 4, true, particleTexture, particleTexCoords, 4);
			////	graphics->PopMatrix();
			////}
			//for (int i = 0; i < particleQty; i++)
			//{
			//	TestParticle *particle = &particles[i];
			//	// if dead, we are done
			//	if (particle->IsDead())
			//		break;

			//	// calculate the radius and alpha on the non-dead ones
			//	particle->PrepareAlpha();
			//	particle->PrepareRadius();

			//	// render it!
			//	if (particle->zDepth > 0.0f)
			//	{
			//		graphics->PushMatrix();
			//		graphics->Translate(particle->CalculateRenderOffset(*cameraOrient));
			//		if (particle->radius != 1.0f)
			//			graphics->Scale(particle->radius, particle->radius, particle->radius);
			//		if (particle->rotationAngleDegrees != 0.0f)
			//			graphics->Rotate(particle->rotationAngleDegrees, Vector3d(0, 0, 1));
			//		// color
			//		particleColor = particle->color;
			//		particleColor.alpha = int(255.0f * particle->alpha);
			//		// render it as a quad facing the viewpoint
			//		graphics->RenderFilledQuad(&particleColor, 1, particleVertices, 4, true, particleTexture, particleTexCoords, 4);
			//		graphics->PopMatrix();
			//	}
			//	else
			//	{
			//		// if additive, we aren't sorting them, so we can't depend on zDepth to be <=0 to stop
			//		// but for sorted ones, we can...
			//		break;
			//		// todo:
			//	}
			//}

			//// restore original render volume
			//graphics->PopMatrix();

			//graphics->SetDepthWriteEnabled(true);
			// Render Particles
			////////////////////////

			ShowInstructions(graphics);

			graphics->FinishRender();
			graphics->SwapBuffers();

			timer->ResetElapsedTime();
		}

		//void SortParticles()
		//{
		//	// for now just bubble sort them
		//	// todo: analyze which sort needed (of more than a threshold of particles out of place, use bitonic or quick sort)
		//	sortParses = 0;
		//	BitonicSortParticles();
		//}

		//void BubbleSortParticles()
		//{
		//	// this one starts at the tail end and moves back to the front
		//	// todo: sort from the other direction if the ones out of place are mostly there

		//	// move dead ones to the far end
		//	// everything before that, sort high zDepth to low zDepth
		//	// do whatever we can to stop early and don't push dead particles farther past the dead index
		//	for (int i = deadParticleIndex - 2; i >= 0; i--)
		//	{
		//		int deadMovedQty = 0;
		//		bool anySwaps = false;
		//		bool dead = false;

		//		for (int j = 0; j <= i; j++)
		//		{
		//			sortParses++;

		//			bool swap = false;
		//			TestParticle *particle0 = &particles[j];
		//			TestParticle *particle1 = &particles[j+1];
		//			if (particle0->dead == true && particle1->dead == false)
		//			{
		//				swap = true;
		//				dead = true;
		//			}
		//			else if (particle0->dead == false && particle1->dead == false && particle0->zDepth < particle1->zDepth)
		//			{
		//				// don't swap if either are dead - if only one is dead, that is handled by the first case.
		//				swap = true;
		//			}

		//			if (swap == true)
		//			{
		//				TestParticle temp = *particle0;
		//				*particle0 = *particle1;
		//				*particle1 = temp;

		//				anySwaps = true;
		//			}
		//		} // j

		//		if (dead == true)
		//			// if we encountered a dead one, there is definitely a new dead one at the end, so move the index back
		//			deadParticleIndex--;

		//		// if nothing moved, we are done
		//		if (anySwaps == false)
		//			return;
		//	} // i
		//}

		//void BitonicSortParticles()
		//{
		//	int mainSeries = 2;
		//	while (mainSeries <= particleQty)
		//	{
		//		int subSeries = 2;
		//		bool breakOut = false;

		//		while (subSeries <= mainSeries)
		//		{
		//			int modCheck = mainSeries / subSeries;

		//			////////////////////////////////
		//			// multithreading : initialize mutex guarded int to zero
		//			// mutex threadsCompleted = 0;

		//			int index = 0;
		//			int swapDirection = 0;
		//			while (index < particleQty - 1)
		//			{
		//				sortParses++;

		//				////////////////////////
		//				// new thread here!  perform this operation in it!
		//				// index and index + modCheck will never be equal to any of the values sent to the other threads, so none will ever step on each other (0-4, 1-5, 2-6, 3-7, 8-12, 9-13, etc.)
		//				// optionally, provide values so that multiple pairs are checked and swapped to reduce the number of threads needed (ideally, split all the work among # threads = cpu)
		//				// threadQty++;

		//				// do a compare and swap
		//				bool swap = false;
		//				if (swapDirection % 2 == 0)
		//				{
		//					// down (normal)
		//					if (particles[index].dead == true && particles[index + modCheck].dead == false)
		//						swap = true;
		//					else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth < particles[index + modCheck].zDepth)
		//						swap = true;
		//				}
		//				else
		//				{
		//					// up
		//					if (particles[index].dead == false && particles[index + modCheck].dead == true)
		//						swap = true;
		//					else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth > particles[index + modCheck].zDepth)
		//						swap = true;
		//				}

		//				if (swap == true)
		//				{
		//					TestParticle temp = particles[index];
		//					particles[index] = particles[index + modCheck];
		//					particles[index + modCheck] = temp;
		//				}

		//				// todo: thread reports that it is complete on a mutex guarded int (increment it)

		//				// end thread!
		//				//////////////////////////

		//				index++;
		//				if (index % modCheck == 0)

		//				{
		//					index += modCheck;

		//					if (index % mainSeries == 0)

		//						swapDirection++;

		//				}
		//			}

		//			///////////////////////////////////////////////////////////////////////////////////////////////////
		//			// if multi threading, do NOT continue from this point until all threads have reported completed!
		//			// todo: mutex request int, compare its value to # threadQty

		//			if (swapDirection == 0 && subSeries == mainSeries)

		//			{
		//				// we are done
		//				breakOut = true;
		//				break;
		//			}

		//			subSeries *= 2;
		//		}

		//		if (breakOut == true)
		//			break;

		//		mainSeries *= 2;
		//	}

		//	// establish new deadindex - assumed that deadindex should not go up (when new particles are inserted - already done there), only down (after applying lifeMS and resulting in more dead ones)
		//	for (int i = deadParticleIndex; i >= 0; i--)
		//	{
		//		if (i >= particleQty)
		//			continue;

		//		if (particles[i].dead == false)
		//		{
		//			deadParticleIndex = i + 1;
		//			break;
		//		}
		//	}

		//	// check sorting, make sure it's good
		//	if (verifySort == true)
		//	{
		//		for (int i = 0; i < particleQty - 2; i++)
		//		{
		//			if (particles[i].dead == true && particles[i + 1].dead == false)
		//				throw gcnew Exception("Sort failed - dead out of order");
		//			else if (particles[i].dead == false && particles[i + 1].dead == false && particles[i].zDepth < particles[i + 1].zDepth)
		//				throw gcnew Exception("Sort failed - zdepth out of order");
		//		}
		//	}
		//}

		// doesn't work quite right... yet.  But when it does it will be a good template on which to write the GPU threaded sorter
		//void BitonicSortParticlesThreaded()
		//{
		//	int threadQty = 4;
		//	array<System::Threading::Thread^> ^threads = gcnew array<System::Threading::Thread^>(threadQty);

		//	int mainSeries = 2;
		//	while (mainSeries <= particleQty)
		//	{
		//		int subSeries = 2;
		//		bool breakOut = false;

		//		while (subSeries <= mainSeries)
		//		{
		//			int modCheck = mainSeries / subSeries;

		//			////////////////////////////////
		//			// multithreading : initialize mutex guarded int to zero
		//			// mutex threadsCompleted = 0;

		//			int index = 0;
		//			int swapDirection = 0;
		//			int threadIndex = 0;
		//			while (threadIndex < threadQty)
		//			{
		//				sortParses += particleQty / 2 / threadQty;

		//				////////////////////////
		//				// new thread here!  perform this operation in it!
		//				// index and index + modCheck will never be equal to any of the values sent to the other threads, so none will ever step on each other (0-4, 1-5, 2-6, 3-7, 8-12, 9-13, etc.)
		//				// optionally, provide values so that multiple pairs are checked and swapped to reduce the number of threads needed (ideally, split all the work among # threads = cpu)
		//				// threadQty++;
		//				Trace::WriteLine("Creating thread");
		//				threads[threadIndex] = gcnew System::Threading::Thread(gcnew System::Threading::ThreadStart(gcnew BitonicThread(index, particleQty/2/threadQty, modCheck, particles, particleQty, mainSeries, swapDirection), &BitonicThread::BitonicSort));
		//				threads[threadIndex]->Name = String::Format("Bitonic {0}", threadIndex);
		//				threads[threadIndex]->Start();
		//				threadIndex++;
		//				Trace::WriteLine("Done Creating thread");

		//				// do a compare and swap
		//				//bool swap = false;
		//				//if (swapDirection % 2 == 0)
		//				//{
		//				//	// down (normal)
		//				//	if (particles[index].dead == true && particles[index + modCheck].dead == false)
		//				//		swap = true;
		//				//	else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth < particles[index + modCheck].zDepth)
		//				//		swap = true;
		//				//}
		//				//else
		//				//{
		//				//	// up
		//				//	if (particles[index].dead == false && particles[index + modCheck].dead == true)
		//				//		swap = true;
		//				//	else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth > particles[index + modCheck].zDepth)
		//				//		swap = true;
		//				//}

		//				//if (swap == true)
		//				//{
		//				//	TestParticle temp = particles[index];
		//				//	particles[index] = particles[index + modCheck];
		//				//	particles[index + modCheck] = temp;
		//				//}

		//				// todo: thread reports that it is complete on a mutex guarded int (increment it)

		//				// end thread!
		//				//////////////////////////

		//				if (particleQty / threadQty >= mainSeries)
		//					index += particleQty / threadQty;
		//				else
		//				{
		//					index += particleQty / threadQty / 4;
		//					if (threadIndex % (mainSeries / (particleQty / threadQty)) == 0)
		//					{
		//						index += (particleQty / threadQty / 2 + particleQty / threadQty / 4);
		//						swapDirection++;
		//					}
		//				}

		//				//if (index % modCheck == 0)
		//				//{
		//					//index += modCheck;

		//					//if (index % mainSeries == 0 && (mainSeries > particleQty / threadQty))
		//					//	swapDirection++;
		//				//}

		//			}

		//			///////////////////////////////////////////////////////////////////////////////////////////////////
		//			// if multi threading, do NOT continue from this point until all threads have reported completed!
		//			// todo: mutex request int, compare its value to # threadQty
		//			// wait for all to complete
		//			Trace::WriteLine("Waiting on threads...");
		//			for (int t = 0; t < threadQty; t++)
		//			{
		//				threads[t]->Join();
		//				delete threads[t];
		//			}
		//			Trace::WriteLine("Done waiting on threads...");

		//			//if (swapDirection == 0 && subSeries == mainSeries)
		//			//if (subSeries == particleQty / 2)
		//			//{
		//			//	// we are done
		//			//	breakOut = true;
		//			//	break;
		//			//}

		//			subSeries *= 2;
		//		}

		//		if (breakOut == true)
		//			break;

		//		mainSeries *= 2;
		//	}

		//	// establish new deadindex - assumed that deadindex should not go up (when new particles are inserted - already done there), only down (after applying lifeMS and resulting in more dead ones)
		//	for (int i = deadParticleIndex; i >= 0; i--)
		//	{
		//		if (i >= particleQty)
		//			continue;

		//		if (particles[i].dead == false)
		//		{
		//			deadParticleIndex = i + 1;
		//			break;
		//		}
		//	}

		//	// check sorting, make sure it's good
		//	if (verifySort == true)
		//	{
		//		for (int i = 0; i < particleQty - 2; i++)
		//		{
		//			if (particles[i].dead == true && particles[i + 1].dead == false)
		//				throw gcnew Exception("Sort failed - dead out of order");
		//			else if (particles[i].dead == false && particles[i + 1].dead == false && particles[i].zDepth < particles[i+1].zDepth)
		//				throw gcnew Exception("Sort failed - zdepth out of order");
		//		}
		//	}
		//}

		void ShowInstructions(GraphicsBase *p_graphics)
		{
			p_graphics->Set2dWindowProjection();

			String ^message = String::Format("E - switch particle mode\r\nP - switch particle quantity\r\nN - render Native\r\nParticle Mode: {0}\r\nParticle Quantity: {1}\r\nSort parses: {2}\r\nVerify Sort: {3}\r\nRender Native: {4}", 
				(particleMode == 0) ? "Spiral" : (particleMode == 1) ? "Fountain" : "Lines",
				particles->particleQty, 
				particles->sortParses,
				particles->verifySort ? "On" : "Off",
				renderNative ? "YES" : "NO");
			GameFont ^font = GameContext::FontRegistry.GetFont("Info");
			System::Drawing::Point textSize = font->GetTextBlockSize(message);
			p_graphics->RenderTextBlock(message, font, 10, GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight() - textSize.Y - 10, GameColor(255, 255, 0));
		}
	};

	// todo: it's a mystery why trying to only use one clip plane here causes a bug, where with RandomDungeon it works fine
	// then again the clip planes in the shader for RandomDungeon are all based on purely world positions, where
	// in GL the standard procedure is to place your viewpoint, then set the clip plane.  It seems setting the clip plane on the deeper mirror is failing, causing the deeper mirror
	//   reflection to not clip properly and preventing the mirror surface from rendering after its reflection is complete.  Maybe a walkthrough about the position of the GL viewpoint
	//   when its clip plane is set is in order.  Yet... when clip plane 0 and 1 are used, everything works fine, so that doesn't seem like the problem.  The problem should actually
	//   be when the clip plane 0 is set back to its original value when the deeper mirror is complete.  So this is a mystery.
	public ref class TestMirror : public GameBase
	{
	public:

		Orient3d *mirrorOrient;
		Orient3d *mirrorOrient2;
		Orient3d *cubeOrient;
		Orient3d *ballOrient;
		Orient3d *cameraOrient;
		Model3d *cube;
		Model3d *ball;
		Model3d *room;
		float ballRadius;
		Vector3d *ballVelocity;
		Vector3d *ballSpinAxis;
		GameTimer *timer;
		float cameraSpinAngle;
		float cameraPitchAngle;
		bool slowMotion;
		bool paused;

		int maxClipPlanes;
		bool useStencil;
		bool useClipPlanes;
		bool singleClipPlane;

		TestMirror(HWND p_hWnd) : GameBase(p_hWnd)
		{
			mirrorOrient = nullptr;
			mirrorOrient2 = nullptr;
			cubeOrient = nullptr;
			ballOrient = nullptr;
			cameraOrient = nullptr;
			ball = nullptr;
			cube = nullptr;
			room = nullptr;

			ballVelocity = nullptr;
			ballSpinAxis = nullptr;

			timer = nullptr;

			maxClipPlanes = 5;
			useStencil = true;
			useClipPlanes = true;
			singleClipPlane = false;
		}

		virtual ~TestMirror()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("MarbleTexture", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("A4240_3A.jpg"));

			mirrorOrient = new Orient3d();
			mirrorOrient2 = new Orient3d();
			cubeOrient = new Orient3d();
			cameraOrient = new Orient3d();
			ballOrient = new Orient3d();
			mirrorOrient->LoadIdentity();
			cubeOrient->LoadIdentity();
			cameraOrient->LoadIdentity();
			ballOrient->LoadIdentity();
			ballRadius = 0.1f;
			ballVelocity = new Vector3d();
			*ballVelocity = Vector3d(2.0f, 0.0f, 1.0f).ScalarMult(0.5f / 1000.0f);
			ballSpinAxis = new Vector3d();
			*ballSpinAxis = CalculateBallSpinAxis(*ballVelocity);
			cameraSpinAngle = 0.0f;
			cameraPitchAngle = 0.0f;

			// place camera
			cameraOrient->p.Set(0.0f, 0.5f, -0.8f);

			// place other objects
			mirrorOrient->p.Set(-0.2f, 0.5f, 0.8f);
			mirrorOrient2->p.Set(1.5f, 0.5f, 0.5f);
			cubeOrient->p.Set(0.0f, 0.2f, 0.8f);
			ballOrient->p.Set(0.4f, ballRadius, 0.5f);
			mirrorOrient->Rotate(mirrorOrient->u, -135.0f);
			mirrorOrient2->Rotate(mirrorOrient2->u, 135.0f);
			cubeOrient->Rotate(cubeOrient->u, 90.0f);

			cube = new Model3d();
			cube->MakeCube();
			// make it a long tube
			cube->ReScale(0.1f);
			cube->GetVertex(0)->vertex.z = 1.0f;
			cube->GetVertex(1)->vertex.z = 1.0f;
			cube->GetVertex(2)->vertex.z = 1.0f;
			cube->GetVertex(3)->vertex.z = 1.0f;
			cube->GetVertex(4)->vertex.z = -1.0f;
			cube->GetVertex(5)->vertex.z = -1.0f;
			cube->GetVertex(6)->vertex.z = -1.0f;
			cube->GetVertex(7)->vertex.z = -1.0f;

			room = new Model3d();
			room->Initialize(1, 8, 6);
			room->GetColor(0)->Set(255, 255, 255);
			room->GetVertex(0)->colorIndex = 0;
			room->GetVertex(1)->colorIndex = 0;
			room->GetVertex(2)->colorIndex = 0;
			room->GetVertex(3)->colorIndex = 0;
			room->GetVertex(4)->colorIndex = 0;
			room->GetVertex(5)->colorIndex = 0;
			room->GetVertex(6)->colorIndex = 0;
			room->GetVertex(7)->colorIndex = 0;
			room->GetVertex(0)->vertex.Set(2.0f, 1.0f, 1.0f);
			room->GetVertex(1)->vertex.Set(-2.0f, 1.0f, 1.0f);
			room->GetVertex(2)->vertex.Set(-2.0f, 0.0f, 1.0f);
			room->GetVertex(3)->vertex.Set(2.0f, 0.0f, 1.0f);
			room->GetVertex(4)->vertex.Set(2.0f, 1.0f, -1.0f);
			room->GetVertex(5)->vertex.Set(-2.0f, 1.0f, -1.0f);
			room->GetVertex(6)->vertex.Set(-2.0f, 0.0f, -1.0f);
			room->GetVertex(7)->vertex.Set(2.0f, 0.0f, -1.0f);
			room->GetSurface(0)->Initialize(4, true);
			room->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Brick2"));
			room->GetSurface(0)->SetVertexIndex(0, 0);
			room->GetSurface(0)->SetVertexIndex(1, 1);
			room->GetSurface(0)->SetVertexIndex(2, 2);
			room->GetSurface(0)->SetVertexIndex(3, 3);
			room->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 1.0f);
			room->GetSurface(0)->SetVertexTexCoords(1, 4.0f, 1.0f);
			room->GetSurface(0)->SetVertexTexCoords(2, 4.0f, 0.0f);
			room->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 0.0f);
			room->GetSurface(1)->Initialize(4, true);
			room->GetSurface(1)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Brick2"));
			room->GetSurface(1)->SetVertexIndex(0, 1);
			room->GetSurface(1)->SetVertexIndex(1, 5);
			room->GetSurface(1)->SetVertexIndex(2, 6);
			room->GetSurface(1)->SetVertexIndex(3, 2);
			room->GetSurface(1)->SetVertexTexCoords(0, 0.0f, 1.0f);
			room->GetSurface(1)->SetVertexTexCoords(1, 2.0f, 1.0f);
			room->GetSurface(1)->SetVertexTexCoords(2, 2.0f, 0.0f);
			room->GetSurface(1)->SetVertexTexCoords(3, 0.0f, 0.0f);
			room->GetSurface(2)->Initialize(4, true);
			room->GetSurface(2)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Brick2"));
			room->GetSurface(2)->SetVertexIndex(0, 5);
			room->GetSurface(2)->SetVertexIndex(1, 4);
			room->GetSurface(2)->SetVertexIndex(2, 7);
			room->GetSurface(2)->SetVertexIndex(3, 6);
			room->GetSurface(2)->SetVertexTexCoords(0, 0.0f, 1.0f);
			room->GetSurface(2)->SetVertexTexCoords(1, 4.0f, 1.0f);
			room->GetSurface(2)->SetVertexTexCoords(2, 4.0f, 0.0f);
			room->GetSurface(2)->SetVertexTexCoords(3, 0.0f, 0.0f);
			room->GetSurface(3)->Initialize(4, true);
			room->GetSurface(3)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Brick2"));
			room->GetSurface(3)->SetVertexIndex(0, 4);
			room->GetSurface(3)->SetVertexIndex(1, 0);
			room->GetSurface(3)->SetVertexIndex(2, 3);
			room->GetSurface(3)->SetVertexIndex(3, 7);
			room->GetSurface(3)->SetVertexTexCoords(0, 0.0f, 1.0f);
			room->GetSurface(3)->SetVertexTexCoords(1, 2.0f, 1.0f);
			room->GetSurface(3)->SetVertexTexCoords(2, 2.0f, 0.0f);
			room->GetSurface(3)->SetVertexTexCoords(3, 0.0f, 0.0f);
			room->GetSurface(4)->Initialize(4, true);
			room->GetSurface(4)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Brick2"));
			room->GetSurface(4)->SetVertexIndex(0, 0);
			room->GetSurface(4)->SetVertexIndex(1, 4);
			room->GetSurface(4)->SetVertexIndex(2, 5);
			room->GetSurface(4)->SetVertexIndex(3, 1);
			room->GetSurface(4)->SetVertexTexCoords(0, 4.0f, 0.0f);
			room->GetSurface(4)->SetVertexTexCoords(1, 4.0f, 2.0f);
			room->GetSurface(4)->SetVertexTexCoords(2, 0.0f, 2.0f);
			room->GetSurface(4)->SetVertexTexCoords(3, 0.0f, 0.0f);
			room->GetSurface(5)->Initialize(4, true);
			room->GetSurface(5)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("Brick2"));
			room->GetSurface(5)->SetVertexIndex(0, 7);
			room->GetSurface(5)->SetVertexIndex(1, 3);
			room->GetSurface(5)->SetVertexIndex(2, 2);
			room->GetSurface(5)->SetVertexIndex(3, 6);
			room->GetSurface(5)->SetVertexTexCoords(0, 4.0f, 0.0f);
			room->GetSurface(5)->SetVertexTexCoords(1, 4.0f, 2.0f);
			room->GetSurface(5)->SetVertexTexCoords(2, 0.0f, 2.0f);
			room->GetSurface(5)->SetVertexTexCoords(3, 0.0f, 0.0f);
			room->CalculateNormals();

			ball = new Model3d();
			ball->MakeSphere();

			timer = new GameTimer();

			paused = false;
			slowMotion = false;

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (mirrorOrient != nullptr)
			{
				delete mirrorOrient;
				mirrorOrient = nullptr;
			}
			if (mirrorOrient2 != nullptr)
			{
				delete mirrorOrient;
				mirrorOrient = nullptr;
			}
			if (cubeOrient != nullptr)
			{
				delete cubeOrient;
				cubeOrient = nullptr;
			}
			if (ballOrient != nullptr)
			{
				delete ballOrient;
				ballOrient = nullptr;
			}

			if (ballVelocity != nullptr)
			{
				delete ballVelocity;
				ballVelocity = nullptr;
			}
			if (ballSpinAxis != nullptr)
			{
				delete ballSpinAxis;
				ballSpinAxis = nullptr;
			}

			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}

			if (room != nullptr)
			{
				delete room;
				room = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (ball != nullptr)
			{
				delete ball;
				ball = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
			{
				if (mouse.IsVisible() == false)
					mouse.Show();

				return false;
			}

			if (keyboardKeys.GetKey(186)->IsClicked() == true) // semicolon
			{
				if (mouse.IsVisible() == false)
					mouse.Show();
				else
					mouse.Hide();
			}

			if (keyboardKeys.GetKey(192)->IsClicked() == true) // ~
			{
				slowMotion = !slowMotion;
			}
			if (keyboardKeys.GetKey('E')->IsClicked() == true)
			{
				paused = !paused;
			}
			if (keyboardKeys.GetKey('C')->IsClicked() == true)
			{
				useClipPlanes = !useClipPlanes;
			}
			if (keyboardKeys.GetKey('V')->IsClicked() == true)
			{
				useStencil = !useStencil;
			}
			if (keyboardKeys.GetKey('P')->IsClicked() == true)
			{
				singleClipPlane = !singleClipPlane;
			}

			if (mouse.IsVisible() == false)
			{
				// apply mouse moves based on last collected movement
				if (mouse.rightButton.down)
				{
					// spin the mirror
					mirrorOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
					mirrorOrient->Rotate(mirrorOrient->l, -float(mouse.offsetY) / 5.0f);
				}
				else if (mouse.leftButton.down)
				{
					// spin the rod
					cubeOrient->Rotate(Vector3d::Vector(0, 1, 0), -float(mouse.offsetX) / 5.0f);
					cubeOrient->Rotate(cubeOrient->l, -float(mouse.offsetY) / 5.0f);
				}
				else
				{
					// move camera with mouse
					cameraSpinAngle += float(mouse.offsetX) / 2.5f;
					cameraPitchAngle += -float(mouse.offsetY) / 2.5f;
					while (cameraSpinAngle < 0.0f)
						cameraSpinAngle += 360.0f;
					while (cameraSpinAngle >= 360.0f)
						cameraSpinAngle -= 360.0f;
					if (cameraPitchAngle > 90.0f)
						cameraPitchAngle = 90.0f;
					if (cameraPitchAngle < -90.0f)
						cameraPitchAngle = -90.0f;
					Vector3d oldP = cameraOrient->p;
					cameraOrient->LoadIdentity();
					cameraOrient->Rotate(Vector3d::Vector(0, 1, 0), cameraSpinAngle);
					cameraOrient->Rotate(cameraOrient->l, cameraPitchAngle);
					cameraOrient->p = oldP;
				}

				float speed = 1.0f / 1000.0f;
				if (mouse.rightButton.down == false)
				{
					if (keyboardKeys.GetKey('W')->IsPressed() == true)
						cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
					if (keyboardKeys.GetKey('S')->IsPressed() == true)
						cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
					if (keyboardKeys.GetKey('A')->IsPressed() == true)
						cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
					if (keyboardKeys.GetKey('D')->IsPressed() == true)
						cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
				}
				else
				{
					if (keyboardKeys.GetKey('W')->IsPressed() == true)
						mirrorOrient->p = mirrorOrient->p + mirrorOrient->f.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
					if (keyboardKeys.GetKey('S')->IsPressed() == true)
						mirrorOrient->p = mirrorOrient->p - mirrorOrient->f.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
					if (keyboardKeys.GetKey('A')->IsPressed() == true)
						mirrorOrient->p = mirrorOrient->p + mirrorOrient->l.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
					if (keyboardKeys.GetKey('D')->IsPressed() == true)
						mirrorOrient->p = mirrorOrient->p - mirrorOrient->l.ScalarMult(speed * timer->GetElapsedTimeMSFloat());
				}
			}
			if (mouse.IsVisible() == false && appActivated == true)
			{
				// move it to the middle of the viewport (should be screen position)
				GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
				mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
			}

			mouse.ZeroOffsets();
			keyboardKeys.ClearClicked();

			if (paused == false)
			{
				if (slowMotion == false)
					AnimateBall(timer->GetElapsedTimeMSFloat());
				else
					AnimateBall(timer->GetElapsedTimeMSFloat() * 0.1f);
			}

			timer->ResetElapsedTime();

			return true;
		}

		Vector3d CalculateBallSpinAxis(Vector3d &p_velocity)
		{
			Vector3d unit = p_velocity;
			if (unit.Normalize() == false)
				return *ballSpinAxis;

			return Vector3d(0, 1, 0).CrossProd(unit); // l = u x f - actually it's backwards but that's ok, we just reverse the angle to rotate
		}

		void AnimateBall(float p_elapsedTimeMSf)
		{
			// nothing complex here, just checking bounds against walls and adjusting velocity afterwards

			// check bounds and alter velocity
			if (ballOrient->p.x < (-2.0f + ballRadius) && ballVelocity->x < 0.0f)
				ballVelocity->x = -ballVelocity->x;
			if (ballOrient->p.x >(2.0f - ballRadius) && ballVelocity->x > 0.0f)
				ballVelocity->x = -ballVelocity->x;

			if (ballOrient->p.z < (-1.0f + ballRadius) && ballVelocity->z < 0.0f)
				ballVelocity->z = -ballVelocity->z;
			if (ballOrient->p.z >(1.0f - ballRadius) && ballVelocity->z > 0.0f)
				ballVelocity->z = -ballVelocity->z;

			*ballSpinAxis = CalculateBallSpinAxis(*ballVelocity);

			// move ball
			ballOrient->p = ballOrient->p + ballVelocity->ScalarMult(p_elapsedTimeMSf);

			// spin ball
			float angle = MathUtilities::RadiansToDegrees((ballVelocity->ScalarMult(p_elapsedTimeMSf).Magnitude()) / ballRadius);
			ballOrient->Rotate(*ballSpinAxis, -angle);
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));
			graphics->ClearStencil();

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			graphics->ReverseTransform(*cameraOrient);

			// draw room
			DrawRoom(graphics, *cameraOrient, 0, Vector3d(0,0,0), Vector3d(0,0,0));

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawRoom(GraphicsBase *p_graphics, Orient3d &p_viewpointOrient, int p_mirrorDepth, Vector3d &p_clipPlanePosition, Vector3d &p_clipPlaneNormal)
		{
			room->Render(*p_graphics);

			p_graphics->PushMatrix();
			p_graphics->Transform(*cubeOrient);
			cube->Render(*p_graphics);
			p_graphics->PopMatrix();

			p_graphics->PushMatrix();
			p_graphics->Transform(*ballOrient);
			p_graphics->Scale(ballRadius, ballRadius, ballRadius);
			ball->Render(*p_graphics);
			p_graphics->PopMatrix();

			// draw the mirror quad
			//p_graphics->PushMatrix();
			//p_graphics->Transform(*mirrorOrient);
			//p_graphics->RenderFilledQuad(&color, 1, mirrorVertices, 4, false, nullptr);
			//p_graphics->PopMatrix();

			// figure out mirror and re-render room, stop at depth 1
			if (p_mirrorDepth == 0 && useStencil == true)
				p_graphics->SetStencilEnabled(true);
			//GameColor color(255, 128, 128, 96);
			//GameColor color2(128, 255, 128, 96);
			GameColor color(0, 0, 0, 96);
			GameColor color2(0, 0, 0, 96);
			if (p_mirrorDepth < 5)
			{
				CheckMirror(p_graphics, p_viewpointOrient, *mirrorOrient2, &color, p_mirrorDepth, GameContext::Instance->TextureRegistry.GetTexture("MarbleTexture"), p_clipPlanePosition, p_clipPlaneNormal);
				CheckMirror(p_graphics, p_viewpointOrient, *mirrorOrient, &color2, p_mirrorDepth, GameContext::Instance->TextureRegistry.GetTexture("MarbleTexture"), p_clipPlanePosition, p_clipPlaneNormal);
			}
			if (p_mirrorDepth == 0)
				p_graphics->SetStencilEnabled(false);
		}

		void CheckMirror(GraphicsBase *p_graphics, Orient3d &p_viewpointOrient, Orient3d &p_mirrorOrient, GameColor *p_mirrorColor, int p_mirrorDepth, GameTexture ^p_mirrorTexture, Vector3d &p_clipPlanePosition, Vector3d &p_clipPlaneNormal)
		{
			ModelVertex mirrorVertices[4] = { ModelVertex(Vector3d(-0.4f, 0.4f, 0.0f), 0), ModelVertex(Vector3d(0.4f, 0.4f, 0.0f), 0), ModelVertex(Vector3d(0.4f, -0.4f, 0.0f), 0), ModelVertex(Vector3d(-0.4f, -0.4f, 0.0f), 0) };
			ModelVertexTextureCoords mirrorTexCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };
			if ((p_viewpointOrient.p - p_mirrorOrient.p) * p_mirrorOrient.f > 0.0f)
			{
				// and stencil out the surface of the mirror, obeying the depth buffer of everything that has been rendered
				p_graphics->ColorMask(false, false, false, false);

				p_graphics->StencilMask(0xff);
				// if render mirror within mirror, need to render it only within the existing mirror, and if it passes, increment it (1 becomes 2, etc.)
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth, 0xff); // starts at 0 at depth 0 and works its way up as mirrors go deeper (up to 5)
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Increment);

				p_graphics->PushMatrix();
				p_graphics->Transform(p_mirrorOrient);
				p_graphics->RenderFilledQuad(p_mirrorColor, 1, mirrorVertices, 4, false, nullptr);
				//p_graphics->PopMatrix();

				// debugging
				if (false)
				{
					p_graphics->ColorMask(true, true, true, true);
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
					p_graphics->StencilMask(0x0);

					Orient3d testOrient;
					GameColor red(255, 0, 0);
					testOrient = p_viewpointOrient;
					testOrient.Rotate(testOrient.u, 180.0f);
					testOrient.p = testOrient.p - testOrient.f.ScalarMult(0.2f);
					p_graphics->PushMatrix();
					p_graphics->DefaultTransform();
					p_graphics->ReverseTransform(p_viewpointOrient);
					p_graphics->Transform(testOrient);
					p_graphics->RenderFilledQuad(&red, 1, mirrorVertices, 4, false, nullptr);
					p_graphics->PopMatrix();
					p_graphics->ColorMask(false, false, false, false);
				}

				// now clear the depth for it out to the max range, where stencil was successful, so that the mirror universe is fresh to render to
				p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::GreaterThan);
				p_graphics->SetDepthRange(0.9999f, 1.0f);
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, 0xff);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->StencilMask(0x0);

				//p_graphics->PushMatrix();
				//p_graphics->Transform(*mirrorOrient);
				p_graphics->RenderFilledQuad(p_mirrorColor, 1, mirrorVertices, 4, false, nullptr);
				p_graphics->PopMatrix();

				// debugging
				if (false)
				{
					p_graphics->ColorMask(true, true, true, true);
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
					p_graphics->StencilMask(0x0);

					Orient3d testOrient;
					GameColor blue(0, 0, 255);
					testOrient = p_viewpointOrient;
					testOrient.Rotate(testOrient.u, 180.0f);
					testOrient.p = testOrient.p - testOrient.f.ScalarMult(5.0f);
					p_graphics->PushMatrix();
					p_graphics->DefaultTransform();
					p_graphics->ReverseTransform(p_viewpointOrient);
					p_graphics->Transform(testOrient);
					p_graphics->RenderFilledQuad(&blue, 1, mirrorVertices, 4, false, nullptr);
					p_graphics->PopMatrix();
					p_graphics->ColorMask(false, false, false, false);
				}

				// restore rendering and depth buffer operations
				p_graphics->ColorMask(true, true, true, true);
				p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThan);
				p_graphics->SetDepthRange(0.0f, 1.0f);

				// now prep for rendering of area within mirror
				Orient3d reflectedOrient = p_viewpointOrient.ReflectThroughPlane(p_mirrorOrient.p, p_mirrorOrient.f);

				///////////////////////////
				// mirror rendering

				// now render only where stencil is equal, and don't write to stencil
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, 0xff);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->StencilMask(0x0);
				p_graphics->FlipCullFace();
				// and put up a clip plane
				int clipPlaneId = p_mirrorDepth;
				if (clipPlaneId > maxClipPlanes - 1)
					clipPlaneId = maxClipPlanes - 1;
				if (singleClipPlane == true)
					clipPlaneId = 0; // I don't quite yet understand why we can't just use clip plane 0 - but if we don't use multiple clip planes, the second mirror clip fights to render its surface,
				//  and I imagine intersecting mirrors would have artifacts if the first clip plane was moved to the second clip plane's world
				// note: clip planes are required to prevent geometry 'behind' the mirror from showing up in the mirror.
				Vector3d clipPlaneNormal = p_mirrorOrient.f.ScalarMult(-1.0f);
				Vector3d clipPlanePosition = p_mirrorOrient.p; // -clipPlaneNormal.ScalarMult(0.0008f); // tweak plane - not necessary since mirror not perfectly lined up with any geometry
				if (useClipPlanes == true)
					p_graphics->SetClipPlane(clipPlaneId, clipPlanePosition, clipPlaneNormal);

				p_graphics->PushMatrix();
				p_graphics->DefaultTransform();
				p_graphics->ReverseTransform(reflectedOrient);
				// reflect p_viewpointOrient through the mirror plane
				DrawRoom(p_graphics, reflectedOrient, p_mirrorDepth + 1, clipPlanePosition, clipPlaneNormal);
				p_graphics->PopMatrix();

				// restore normal rendering
				p_graphics->FlipCullFace();
				if (useClipPlanes == true)
				{
					if (p_mirrorDepth == 0 || singleClipPlane == false)
						p_graphics->DisableClipPlane(clipPlaneId);
					else
						p_graphics->SetClipPlane(clipPlaneId, p_clipPlanePosition, p_clipPlaneNormal);
				}

				// render mirror surface with depth so that further rendering doesn't intrude on the mirror space
				p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThanEqual);
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, 0xff); // mirror may contain p_mirrorDepth + 1 and higher from stacked mirrors
				// restore stencil in mirror to the value of the space that mirror created itself in (prevents a mirror behind another mirror from mistakenly using that stencil value when it shouldn't
				//   have any visual evidence at all) - recursivity restores entire space to 5, 4, 3, 2, 1, 0 respectively within the mirror.
				// decrement on depth fail and success to make absolutely sure the stencil for the area gets cleared to prevent artifacts from the clip plane allowing fragments with a lower depth
				//   value than the mirror's surface preventing the mirror from clearing the stencil
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Decrement, GraphicsStencilOperationEnum::Decrement);
				p_graphics->StencilMask(0xff);
				p_graphics->PushMatrix();
				p_graphics->Transform(p_mirrorOrient);
				p_graphics->RenderFilledQuad(p_mirrorColor, 1, mirrorVertices, 4, true, p_mirrorTexture, mirrorTexCoords, 4);
				p_graphics->PopMatrix();
				p_graphics->SetDepthFunc(GraphicsDepthFuncEnum::LessThan);

				// debugging
				if (false)
				{
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_mirrorDepth + 1, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
					p_graphics->StencilMask(0x0);

					Orient3d testOrient;
					GameColor red(255, 0, 0);
					testOrient = p_viewpointOrient;
					testOrient.Rotate(testOrient.u, 180.0f);
					testOrient.p = testOrient.p - testOrient.f.ScalarMult(0.2f);
					p_graphics->PushMatrix();
					p_graphics->DefaultTransform();
					p_graphics->ReverseTransform(p_viewpointOrient);
					p_graphics->Transform(testOrient);
					p_graphics->RenderFilledQuad(&red, 1, mirrorVertices, 4, false, nullptr);
					p_graphics->PopMatrix();
				}

				// done with mirror
				//////////////////////

				// tests:
				// mirror surfaces should stack as mirrors go deeper
				// mirror rendered surface should not appear outside another mirror when that mirror is partially within another mirror
				// angled mirrors shoudl show properly
				// crisscrossed mirrors should show properly
				// parallel mirrors should show properly and go to a maximum depth
				// when one mirror is in front of another mirror (both facing same direction), mirror that is behind the other should not be rendered (decrementing stencil when drawing the mirror's surface handles this)
			}
		}
	};

	public ref class PostProcessShaderTest : public GameBase
	{
	public:

		Orient3d *cubeOrients;
		int cubeOrientQty;
		Orient3d *cameraOrient;
		Model3d *cube;

		float sceneRotateAngle;
		float scenePitchAngle;
		//float bufferQuadRotateAngle;
		//float bufferQuadPitchAngle;

		bool useOldPipelineRender;

		float fade;
		float grayScale;
		float gamma;
		float blurPixelsHorizontal;
		float blurPixelsVertical;
		bool depthOfField;

		float *blurKernel; // blur Kernel
		int blurKernelElementQty; // how many elements should be parsed for the blur?

		float focusDepth; // distance along f vector of camera for focus center (further offset by distance camera is backed up from origin)

		float lens;

		GameTimer *timer;

		bool paused;

		GraphicsFrameBufferContainer *frameBuffer1; // initial render target
		GraphicsFrameBufferContainer *frameBuffer2; // secondary to handle two pass blur using ping ponging
		//GraphicsFrameBufferContainer *frameBufferShadowMap;

		GraphicsNativeObjectContainer *cubeNativeObject;

		PostProcessShaderTest(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cubeOrients = nullptr;
			cubeOrientQty = 0;
			cameraOrient = nullptr;

			timer = nullptr;

			frameBuffer1 = nullptr;
			frameBuffer2 = nullptr;
			//frameBufferShadowMap = nullptr;

			cubeNativeObject = nullptr;

			useOldPipelineRender = false;

			fade = 0.0f;
			grayScale = 0.0f;
			gamma = 1.0f;

			lens = 1.0f;

			blurKernel = nullptr;

			blurPixelsHorizontal = 0.0f;
			blurPixelsVertical = 0.0f;

			depthOfField = false;
			focusDepth = 0.0f;

			paused = false;
		}

		virtual ~PostProcessShaderTest()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			//GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			//GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			//GameContext::Instance->TextureRegistry.RegisterTexture("Spotlight", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("flashlight2.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brick2.jpg"));

			//GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			//graphics->LoadTexture(GameContext::Instance->TextureRegistry.GetTexture("TestTexture"));

			cubeOrientQty = 6;
			cubeOrients = new Orient3d[cubeOrientQty];
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].LoadIdentity();

				switch (i)
				{
				case 0:
					cubeOrients[i].p = Vector3d(0, 0, 0);
					break;
				case 1:
					cubeOrients[i].p = Vector3d(5, 1, 0);
					break;
				case 2:
					cubeOrients[i].p = Vector3d(-1, 5, 3);
					break;
				case 3:
					cubeOrients[i].p = Vector3d(-3, 2, 0);
					break;
				case 4:
					cubeOrients[i].p = Vector3d(1, -6, 0);
					break;
				case 5:
					cubeOrients[i].p = Vector3d(0, -4, -4);
					break;
				}
			}

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();

			cube = new Model3d();
			cube->MakeCube();
			// skin it!  Make it white for modulation
			cube->SkinTexture0(GameContext::TextureRegistry.GetTexture("Brick"));
			for (int v = 0; v < cube->GetVertexQty(); v++)
				cube->GetVertex(v)->colorIndex = 7; // white

			scenePitchAngle = 0;
			sceneRotateAngle = 0;
			//bufferQuadPitchAngle = 0;
			//bufferQuadRotateAngle = 0;

			timer = new GameTimer();

			// don't do this in the constructor - the Destroy() function gets called
			blurKernel = new float[MAX_BLUR_KERNEL_ELEMENT_QTY];
			SetBlurKernel(MAX_BLUR_KERNEL_ELEMENT_QTY);
			//SetBlurKernel(2); // 600 fps vs. 330fps

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (cubeOrients != nullptr)
			{
				delete[] cubeOrients;
				cubeOrients = nullptr;
				cubeOrientQty = 0;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (frameBuffer1 != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting frameBuffer1 resource {0}", (int)(frameBuffer1->frameBuffer)));
				delete frameBuffer1;
				frameBuffer1 = nullptr;
			}
			if (frameBuffer2 != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting frameBuffer2 resource {0}", (int)(frameBuffer2->frameBuffer)));
				delete frameBuffer2;
				frameBuffer2 = nullptr;
			}
			//if (frameBufferShadowMap != nullptr)
			//{
			//	Trace::WriteLine(String::Format("Deleting frameBufferShadowMap resource {0}", (int)(frameBufferShadowMap->frameBuffer)));
			//	delete frameBufferShadowMap;
			//	frameBufferShadowMap = nullptr;
			//}
			if (cubeNativeObject != nullptr)
			{
				Trace::WriteLine(String::Format("Deleting cubeNativeObject resource {0}", (int)(cubeNativeObject->nativeObjectRef)));
				delete cubeNativeObject;
				cubeNativeObject = nullptr;
			}
			if (blurKernel != nullptr)
			{
				delete[] blurKernel;
				blurKernel = nullptr;
			}
		}

		void Destroy() override
		{
			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// apply mouse moves based on last collected movement
			if (mouse.rightButton.down)
			{
				// rotate scene
				sceneRotateAngle += float(mouse.offsetX);
				while (sceneRotateAngle >= 360.0f)
					sceneRotateAngle -= 360.0f;
				scenePitchAngle += float(mouse.offsetY);
				if (scenePitchAngle > 90.0f)
					scenePitchAngle = 90.0f;
				if (scenePitchAngle < -90.0f)
					scenePitchAngle = -90.0f;
			}
			else if (mouse.leftButton.down)
			{
				// rotate buffer quad
				//bufferQuadRotateAngle += float(mouse.offsetX);
				//while (bufferQuadRotateAngle >= 360.0f)
				//	bufferQuadRotateAngle -= 360.0f;
				//bufferQuadPitchAngle += float(mouse.offsetY);
				//if (bufferQuadPitchAngle > 90.0f)
				//	bufferQuadPitchAngle = 90.0f;
				//if (bufferQuadPitchAngle < -90.0f)
				//	bufferQuadPitchAngle = -90.0f;
			}
			mouse.ZeroOffsets();

			// key controls
			if (keyboardKeys.GetKey('P')->IsClicked())
			{
				useOldPipelineRender = !useOldPipelineRender;
			}
			if (keyboardKeys.GetKey('B')->IsClicked())
			{
				gamma += 0.1f;
				if (gamma > 3.0f)
					gamma = 1.0f;
			}
			if (keyboardKeys.GetKey('F')->IsClicked())
			{
				if (fade < 1.0f)
				{
					fade += 0.1f;
					if (fade > 1.0f)
						fade = 1.0f;
				}
				else
					fade = 0.0f;
			}
			if (keyboardKeys.GetKey('G')->IsClicked())
			{
				if (grayScale < 1.0f)
				{
					grayScale += 0.1f;
					if (grayScale > 1.0f)
						grayScale = 1.0f;
				}
				else
					grayScale = 0.0f;
			}
			if (keyboardKeys.GetKey('H')->IsClicked())
			{
				if (blurPixelsHorizontal < 2.0f)
				{
					blurPixelsHorizontal += 0.34f;
					if (blurPixelsHorizontal > 2.0f)
						blurPixelsHorizontal = 2.0f;
				}
				else
					blurPixelsHorizontal = 0.0f;
			}
			if (keyboardKeys.GetKey('V')->IsClicked())
			{
				if (blurPixelsVertical < 2.0f)
				{
					blurPixelsVertical += 0.34f;
					if (blurPixelsVertical > 2.0f)
						blurPixelsVertical = 2.0f;
				}
				else
					blurPixelsVertical = 0.0f;
			}
			if (keyboardKeys.GetKey('C')->IsClicked())
			{
				GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
				graphics->SetVSyncEnabled(!graphics->VSyncIsEnabled());
			}
			if (keyboardKeys.GetKey('D')->IsClicked())
			{
				depthOfField = !depthOfField;
			}
			if (keyboardKeys.GetKey('E')->IsClicked())
			{
				paused = !paused;
			}
			if (keyboardKeys.GetKey('L')->IsClicked())
			{
				if (lens >= 1.0f)
				{
					lens += 0.1f;
					if (lens > 2.0f)
						lens = 0.5f;
				}
				else
				{
					lens += 0.05f;
					if (lens > 1.0f)
						lens = 1.0f;
				}
			}
			keyboardKeys.ClearClicked();

			if (paused == false)
				Animate(timer->GetElapsedTimeMSFloat());

			timer->ResetElapsedTime();

			return true;
		}

		void SetBlurKernel(int p_elementQty)
		{
			if (p_elementQty < 2 || p_elementQty > MAX_BLUR_KERNEL_ELEMENT_QTY)
				throw gcnew Exception(String::Format("Blur kernel element quantity must be 2-{0}", MAX_BLUR_KERNEL_ELEMENT_QTY));

			// hurray!  http://dev.theomader.com/gaussian-kernel-calculator/
			blurKernelElementQty = p_elementQty;
			// sigma 10 used
			switch (blurKernelElementQty)
			{
			case 2:
				// 0.110741 0.111296 0.110741
				// 0.111296 0.111853 0.111296
				// 0.110741 0.111296 0.110741
				blurKernel[0] = 0.334444f;
				blurKernel[1] = 0.332778f;
				//blurKernelElementTotal = blurKernel[1] + blurKernel[0] + blurKernel[1];
				break;
			case 3:
				// 0.039206 0.039798 0.039997 0.039798 0.039206
				// 0.039798 0.040399 0.040601 0.040399 0.039798
				// 0.039997 0.040601 0.040804 0.040601 0.039997
				// 0.039798 0.040399 0.040601 0.040399 0.039798
				// 0.039206 0.039798 0.039997 0.039798 0.039206
				blurKernel[0] = 0.202001f;
				blurKernel[1] = 0.200995f;
				blurKernel[2] = 0.198005f;
				//blurKernelElementTotal = blurKernel[2] + blurKernel[1] + blurKernel[0] + blurKernel[1] + blurKernel[2];
				break;
			case 4:
				// 0.019408 0.019899 0.020199 0.0203   0.020199  0.019899  0.019408
				// 0.019899 0.020402 0.02071  0.020814 0.02071  0.020402 0.019899
				// 0.020199 0.02071  0.021023 0.021128 0.021023 0.02071  0.020199
				// 0.020300 0.020814 0.021128 0.021234 0.021128 0.020814 0.0203
				// 0.020199 0.02071  0.021023 0.021128 0.021023 0.02071  0.020199
				// 0.019899 0.020402 0.02071  0.020814 0.02071  0.020402 0.019899
				// 0.019408 0.019899 0.020199 0.0203   0.020199 0.019899 0.019408
				blurKernel[0] = 0.145719f;
				blurKernel[1] = 0.144993f;
				blurKernel[2] = 0.142836f;
				blurKernel[3] = 0.139312f;
				break;
			case 5:
				// 0.011237 0.011637 0.011931 0.012111 0.012172 0.012111 0.011931 0.011637 0.011237
				// 0.011637 0.012051 0.012356 0.012542 0.012605 0.012542 0.012356 0.012051 0.011637
				// 0.011931 0.012356 0.012668 0.01286  0.012924 0.01286  0.012668 0.012356 0.011931
				// 0.012111 0.012542 0.01286  0.013054 0.013119 0.013054 0.01286  0.012542 0.012111
				// 0.012172 0.012605 0.012924 0.013119 0.013185 0.013119 0.012924 0.012605 0.012172
				// 0.012111 0.012542 0.01286  0.013054 0.013119 0.013054 0.01286  0.012542 0.012111
				// 0.011931 0.012356 0.012668 0.01286  0.012924 0.01286  0.012668 0.012356 0.011931
				// 0.011637 0.012051 0.012356 0.012542 0.012605 0.012542 0.012356 0.012051 0.011637
				// 0.011237 0.011637 0.011931 0.012111 0.012172 0.012111 0.011931 0.011637 0.011237
				blurKernel[0] = 0.114825f;
				blurKernel[1] = 0.114253f;
				blurKernel[2] = 0.112553f;
				blurKernel[3] = 0.109777f;
				blurKernel[4] = 0.106004f;
				break;
			case 6:
				// 0.0071   0.007427 0.007691 0.007886 0.008005 0.008045 0.008005 0.007886 0.007691 0.007427 0.0071 
				// 0.007427 0.007768 0.008045 0.008248 0.008373 0.008415 0.008373 0.008248 0.008045 0.007768 0.007427
				// 0.007691 0.008045 0.008331 0.008542 0.008671 0.008714 0.008671 0.008542 0.008331 0.008045 0.007691
				// 0.007886 0.008248 0.008542 0.008758 0.00889  0.008935 0.00889  0.008758 0.008542 0.008248 0.007886
				// 0.008005 0.008373 0.008671 0.00889  0.009025 0.00907  0.009025 0.00889  0.008671 0.008373 0.008005
				// 0.008045 0.008415 0.008714 0.008935 0.00907  0.009115 0.00907  0.008935 0.008714 0.008415 0.008045
				// 0.008005 0.008373 0.008671 0.00889  0.009025 0.00907  0.009025 0.00889  0.008671 0.008373 0.008005
				// 0.007886 0.008248 0.008542 0.008758 0.00889  0.008935 0.00889  0.008758 0.008542 0.008248 0.007886
				// 0.007691 0.008045 0.008331 0.008542 0.008671 0.008714 0.008671 0.008542 0.008331 0.008045 0.007691
				// 0.007427 0.007768 0.008045 0.008248 0.008373 0.008415 0.008373 0.008248 0.008045 0.007768 0.007427
				// 0.0071   0.007427 0.007691 0.007886 0.008005 0.008045 0.008005 0.007886 0.007691 0.007427 0.0071
				blurKernel[0] = 0.095474f;
				blurKernel[1] = 0.094998f;
				blurKernel[2] = 0.093585f;
				blurKernel[3] = 0.091276f;
				blurKernel[4] = 0.088139f;
				blurKernel[5] = 0.084264f;
				break;
			}
		}

		void Animate(float p_elaspedTimeMSf)
		{
			for (int i = 0; i < cubeOrientQty; i++)
			{
				cubeOrients[i].Rotate(Vector3d(0, 1, 0), 360.0f / 6.0f / 1000.0f * p_elaspedTimeMSf); // rotate every 6 seconds
			}
		}

		void ViewportSizeChanged(GameViewport ^p_viewport) override
		{
			// force recreation of framebuffer
			if (frameBuffer1 != nullptr)
				GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->DestroyFrameBuffer(frameBuffer1);
			if (frameBuffer2 != nullptr)
				GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetGraphics()->DestroyFrameBuffer(frameBuffer2);
		}
		
		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			graphics->MakeCurrent();

			////////////////////////////////////
			// render to internal buffer texture

			//Orient3d spotlightOrient;
			//spotlightOrient.LoadIdentity();
			//spotlightOrient.Rotate(spotlightOrient.u, sceneRotateAngle);
			//spotlightOrient.Rotate(spotlightOrient.l, scenePitchAngle);
			//spotlightOrient.p = spotlightOrient.p + spotlightOrient.f.ScalarMult(-10.0f);
			//float spotlightAngle = 45.0f;

			//// render to a shadow map
			//if (frameBufferShadowMap == nullptr)
			//	frameBufferShadowMap = new GraphicsFrameBufferContainer();
			//// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			//if (frameBufferShadowMap->frameBuffer == nullptr)
			//	graphics->CreateFrameBuffer(frameBufferShadowMap, GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, 600, 600);
			//// set up renderbuffertexture as render target
			//graphics->SetCurrentFrameBuffer(frameBufferShadowMap);
			//// projection according to its dimensions
			//graphics->SetPerspectiveProjection(spotlightAngle, 0.5, 1000.0); // 45 max for spotlight, so double it for this render - 0.5 makes shadowmap more visible
			//// clear to a specific color to keep it distinct
			//graphics->ClearDepth();
			//graphics->DefaultTransform();
			//// set up camera position for scene
			//graphics->ReverseTransform(spotlightOrient);
			//Matrix4d lightMVP = graphics->GetMVPMatrix(); // save for later
			//// render the cubes to the shadowmap using a shader, capture their backsides to avoid shadow acne
			//graphics->FlipCullFace();
			//RenderCubes(graphics, true, nullptr, 0.0f, nullptr, nullptr, nullptr);
			//graphics->FlipCullFace();
			//// restore primary viewport as the render target
			//graphics->FinishRender();

			// if RenderbuffertextureContainer is null, make a new one
			if (frameBuffer1 == nullptr)
				frameBuffer1 = new GraphicsFrameBufferContainer();
			// if container buffer is null, use graphics to create one (which registers the resource in the graphcis API for destruction later)
			if (frameBuffer1->frameBuffer == nullptr)
				graphics->CreateFrameBuffer(frameBuffer1, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::Texture, 
					GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
					GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight(), 1, true); // don't really need stencil, just testing
			//// set up renderbuffertexture as render target
			graphics->SetCurrentFrameBuffer(frameBuffer1);
			// projection according to its dimensions
			graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible
			// clear to a specific color to keep it distinct
			graphics->ClearScreen(GameColor(128, 128, 128)); // gray for render to texture
			graphics->DefaultTransform();
			// set up camera position for scene
			cameraOrient->LoadIdentity();
			cameraOrient->Rotate(Vector3d(0, 1, 0), sceneRotateAngle);
			cameraOrient->Rotate(cameraOrient->l, scenePitchAngle);
			cameraOrient->p = cameraOrient->f.ScalarMult(-20.0f);
			graphics->ReverseTransform(*cameraOrient);
			// get value for depth of field blurring later
			Matrix4d mvp = graphics->GetMVPMatrix();
			//float testValue1 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(1.0f + focusDepth));
			//float testValue2 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(1.01f + focusDepth));
			//float testValue3 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(5.0f + focusDepth));
			//float testValue4 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(5.01f + focusDepth));
			//float testValue5 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(10.0f + focusDepth));
			//float testValue6 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(10.01f + focusDepth));
			//float testValue7 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(100.0f + focusDepth));
			//float testValue8 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(100.01f + focusDepth));
			//float testValue9 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(999.0f + focusDepth));
			//float testValue10 = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(999.01f + focusDepth));
			float focusCenterDepthValue = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(20.0f + focusDepth));
			float focusLowDepthMax = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(19.75f + focusDepth));
			float focusLowDepthMin = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(15.75f + focusDepth));
			float focusHighDepthMin = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(20.25f + focusDepth));
			float focusHighDepthMax = mvp.GetDepthBufferValue(cameraOrient->p + cameraOrient->f.ScalarMult(24.25f + focusDepth));
			// render the cubes to the texture (different dimension and ratio than main viewport
			RenderCubes(graphics); // , false, &spotlightOrient, spotlightAngle, &(cameraOrient->p), &lightMVP, frameBufferShadowMap->depthBufferTexture);
			// restore primary viewport as the render target
			graphics->FinishRender();

			// reset to main
			graphics->SetCurrentFrameBuffer();

			//////////////////////////////////
			// render to primary viewport now

			//graphics->ClearScreen(GameColor(0, 128, 128)); // mid-cyan for render to main view

			//graphics->SetPerspectiveProjection(45.0f, 0.5, 1000.0); // 0.5 makes shadowmap more visible

			//graphics->DefaultTransform();

			//// set up camera position for scene
			//cameraOrient->LoadIdentity();
			//cameraOrient->Rotate(Vector3d(0, 1, 0), sceneRotateAngle);
			//cameraOrient->Rotate(cameraOrient->l, scenePitchAngle);
			//// MUST be identical to how shadow map was rendered!!!
			//cameraOrient->p = cameraOrient->f.ScalarMult(-30.0f);
			//cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(-8.0f, 0, 0));

			//// reverse transform the camera
			//graphics->ReverseTransform(*cameraOrient);

			// render the cubes to the main viewport
			//RenderCubes(graphics, false, &spotlightOrient, spotlightAngle, &(cameraOrient->p), &lightMVP, frameBufferShadowMap->depthBufferTexture);

			// render the color framebuffer quad
			ModelVertex vertices[4] = { ModelVertex(Vector3d(400, 300, 1), 0), ModelVertex(Vector3d(-400, 300, 1), 0), ModelVertex(Vector3d(-400, -300, 1), 0), ModelVertex(Vector3d(400, -300, 1), 0) };
			vertices[0].vertex.x = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
			vertices[0].vertex.y = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
			vertices[1].vertex.x = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
			vertices[1].vertex.y = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
			vertices[2].vertex.x = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
			vertices[2].vertex.y = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
			vertices[3].vertex.x = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
			vertices[3].vertex.y = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
			ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 1.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(0.0f, 0.0f) };
			GameColor color(255, 255, 255);

			// set up for full screen rendering of the above quad
			graphics->SetOrthoProjection(0.1f, 100.0f);
			graphics->DefaultTransform();
			graphics->Scale(2.0f / float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()), 2.0f / float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()), 1.0f);
			//graphics->Translate(float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f, float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f, 0.0f);
			//graphics->Scale(0.95f, 0.95f, 1.0f);

			if (useOldPipelineRender == true)
			{
				//cameraOrient->LoadIdentity();
				//cameraOrient->Rotate(Vector3d(0, 1, 0), bufferQuadRotateAngle);
				//cameraOrient->Rotate(cameraOrient->l, bufferQuadPitchAngle);
				//cameraOrient->p = cameraOrient->f.ScalarMult(-35.0f);
				//cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(8.0f, -8.0f, 0));

				//graphics->DefaultTransform();
				//graphics->ReverseTransform(*cameraOrient);

				graphics->PushMatrix();
				//graphics->Scale(0.02f, 0.02f, 0.02f);
				graphics->RenderFilledQuad(&color, 1, vertices, 4, false, frameBuffer1->colorBufferTexture, texCoords, 4);
				graphics->PopMatrix();
			}
			else
			{
				graphics->SetDepthTestEnabled(false);
				graphics->SetDepthWriteEnabled(false);
				GameTexture ^srcColorTexture = frameBuffer1->colorBufferTexture;

				GraphicsPostProcessShaderOptions postProcessOptions;
				postProcessOptions.lens = lens;

				// use the post processing shader
				Matrix4d mvp = graphics->GetMVPMatrix();
				postProcessOptions.mvpMatrixRef = &mvp;
				postProcessOptions.srcTextureRef = srcColorTexture;

				// note: blur scale should also be based on field of view, vertical
				float blurSizeFactor = float(srcColorTexture->GetHeight()) / 518.0f * 4.0f / float(blurKernelElementQty); // base on a 4 element kernel

				float proposedBlurPixelsHorizontal = blurPixelsHorizontal;
				float proposedBlurPixelsVertical = blurPixelsVertical;
				if (proposedBlurPixelsHorizontal != 0.0f && proposedBlurPixelsVertical != 0.0f)
				{
					// set up framebuffer2
					if (frameBuffer2 == nullptr)
						frameBuffer2 = new GraphicsFrameBufferContainer();
					if (frameBuffer2->frameBuffer == nullptr)
						graphics->CreateFrameBuffer(frameBuffer2, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::Renderbuffer,
							GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
							GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());
					graphics->SetCurrentFrameBuffer(frameBuffer2);

					// start the blurring along the horizontal and render to the secondary framebuffer.
					// then reselect the main frame buffer and use the texture from the secondary framebuffer as the source
					if (depthOfField == false)
						postProcessOptions.blur = true;
					else
					{
						postProcessOptions.focusByDepth = true;
						postProcessOptions.focusLowDepthRangeMin = focusLowDepthMin;
						postProcessOptions.focusLowDepthRangeMax = focusLowDepthMax;
						postProcessOptions.focusHighDepthRangeMin = focusHighDepthMin;
						postProcessOptions.focusHighDepthRangeMax = focusHighDepthMax;
						postProcessOptions.depthTextureRef = frameBuffer1->depthBufferTexture; // ALWAYS from frameBuffer 1 here, since it has the scene depth information
					}
					postProcessOptions.blurScaleS = proposedBlurPixelsHorizontal * 1.0f / float(srcColorTexture->GetWidth()) * blurSizeFactor;
					postProcessOptions.blurKernelRef = &(blurKernel[0]);
					postProcessOptions.kernelElementQty = blurKernelElementQty;

					// perform the horizontal blur
					graphics->RenderPostProcessingShaderQuad(vertices, texCoords, postProcessOptions);
					graphics->FinishRender();

					// prevent horizontal blur from being used again
					postProcessOptions.blur = false;
					postProcessOptions.focusByDepth = false;
					postProcessOptions.blurScaleS = 0.0f;
					proposedBlurPixelsHorizontal = 0.0f;

					// use secondary texture as the source, and render to main now
					srcColorTexture = frameBuffer2->colorBufferTexture;
					graphics->SetCurrentFrameBuffer();
					postProcessOptions.srcTextureRef = srcColorTexture;
				}

				GameColor fadeColor(255, 0, 0);
				postProcessOptions.fadeFactor = fade;
				postProcessOptions.fadeColorRef = &fadeColor;
				postProcessOptions.gamma = gamma;
				postProcessOptions.grayScale = grayScale;

				// only one of these will be set now.
				if (proposedBlurPixelsHorizontal != 0.0f)
				{
					if (depthOfField == false)
						postProcessOptions.blur = true;
					else
					{
						postProcessOptions.focusByDepth = true;
						postProcessOptions.focusLowDepthRangeMin = focusLowDepthMin;
						postProcessOptions.focusLowDepthRangeMax = focusLowDepthMax;
						postProcessOptions.focusHighDepthRangeMin = focusHighDepthMin;
						postProcessOptions.focusHighDepthRangeMax = focusHighDepthMax;
						postProcessOptions.depthTextureRef = frameBuffer1->depthBufferTexture; // ALWAYS from frameBuffer 1 here, since it has the scene depth information
					}
					postProcessOptions.blurScaleS = proposedBlurPixelsHorizontal * 1.0f / float(srcColorTexture->GetWidth()) * blurSizeFactor;
					postProcessOptions.blurKernelRef = &(blurKernel[0]);
					postProcessOptions.kernelElementQty = blurKernelElementQty;
				}
				if (proposedBlurPixelsVertical != 0.0f)
				{
					if (depthOfField == false)
					{
						postProcessOptions.blur = true;
						postProcessOptions.blurScaleT = proposedBlurPixelsVertical * 1.0f / float(srcColorTexture->GetHeight()) * blurSizeFactor;
					}
					else
					{
						postProcessOptions.focusByDepth = true;
						// focus by depth vertical is exaggerated, so adjust down by this amount (todo: move this to the framework upload for focusbydepth vertical only, assuming
						//   vertical is always done second...)
						// todo: don't know why the 5/8 needs to be here
						postProcessOptions.blurScaleT = 5.0f / 8.0f * proposedBlurPixelsVertical * 1.0f / float(srcColorTexture->GetHeight()) * blurSizeFactor;
						postProcessOptions.focusLowDepthRangeMin = focusLowDepthMin;
						postProcessOptions.focusLowDepthRangeMax = focusLowDepthMax;
						postProcessOptions.focusHighDepthRangeMin = focusHighDepthMin;
						postProcessOptions.focusHighDepthRangeMax = focusHighDepthMax;
						postProcessOptions.depthTextureRef = frameBuffer1->depthBufferTexture; // ALWAYS from frameBuffer 1 here, since it has the scene depth information
					}
					postProcessOptions.blurKernelRef = &(blurKernel[0]);
					postProcessOptions.kernelElementQty = blurKernelElementQty;
				}
				//postProcessOptions.blurScaleY = 1.0f / float(frameBuffer1->colorBufferTexture->GetHeight());

				graphics->RenderPostProcessingShaderQuad(vertices, texCoords, postProcessOptions);

				graphics->SetDepthTestEnabled(true);
				graphics->SetDepthWriteEnabled(true);
			}

			//// render the shadowmap texture quad using a shader
			//// ll, ul, ur, lr as required
			//Vector3d shadowMapVertices[4] = { Vector3d(300, -300, 0), Vector3d(300, 300, 0), Vector3d(-300, 300, 0), Vector3d(-300, -300, 0) };

			//cameraOrient->LoadIdentity();
			//cameraOrient->Rotate(Vector3d(0, 1, 0), bufferQuadRotateAngle);
			//cameraOrient->Rotate(cameraOrient->l, bufferQuadPitchAngle);
			//cameraOrient->p = cameraOrient->f.ScalarMult(-35.0f);
			//cameraOrient->p = cameraOrient->p + cameraOrient->TransformToWorldSpaceOffset(Vector3d(8.0f, 8.0f, 0));

			//graphics->DefaultTransform();
			//graphics->ReverseTransform(*cameraOrient);
			//Matrix4d mvp = graphics->GetMVPMatrix();
			//Orient3d quadOrient;
			//quadOrient.LoadIdentity();

			//graphics->PushMatrix();
			//GraphicsShaderOptions renderOptions;
			//renderOptions.eyeMVPMatrixRef = &mvp;
			//renderOptions.texture0Ref = frameBufferShadowMap->depthBufferTexture;
			//renderOptions.vertexScale = 0.02f;
			//renderOptions.modelWorldOrientRef = &quadOrient;
			////renderOptions.texture0Ref = frameBuffer1->colorBufferTexture;
			//graphics->RenderShadowMap(shadowMapVertices, renderOptions);
			//graphics->PopMatrix();

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void RenderCubes(GraphicsBase *graphics)//, bool p_renderToShadowMap, Orient3d *lightOrient, float p_spotlightAngle, Vector3d *p_cameraPosition, Matrix4d *shadowMVP, GameTexture ^p_shadowMapTexture)
		{
			GraphicsShaderOptions shaderOptions;
			Matrix4d mvp;
			shaderOptions.eyeMVPMatrixRef = &mvp;
			shaderOptions.lighting = false;

			// prepare cube native object (they are all identical)
			if (cubeNativeObject == nullptr)
				cubeNativeObject = new GraphicsNativeObjectContainer();
			if (cubeNativeObject->nativeObjectRef == nullptr)
				cube->CreateNativeObject(graphics, cubeNativeObject, true);

			//if (p_renderToShadowMap == false)
			{
				//Vector3d ambientLight = Vector3d(0.2f, 0.2f, 0.2f);
				//shaderOptions.ambientLightRef = &ambientLight;
				//GraphicsShaderLight light;
				//GraphicsShaderLightPtr lightRef[1];
				//lightRef[0] = &light;
				//light.SetSpotlightTexture(GameContext::TextureRegistry.GetTexture("Spotlight"), lightOrient->p, lightOrient->f, lightOrient->l, lightOrient->u, p_spotlightAngle / 2.0f, Vector3d(1, 1, 1), 0.00025f, 0.000125f); // match what was used to render shadowmap (half the angle of the projection)
				////light.SetSpotlight(lightOrient->p, lightOrient->f, p_spotlightAngle / 2.0f, Vector3d(1, 1, 1), 0.00025f, 0.000125f); // match what was used to render shadowmap (half the angle of the projection)
				//GraphicsShaderMaterial material;
				//material.shininess = 50.0f;
				//material.ambientReflectivity = Vector3d(1, 1, 1);
				//material.diffuseReflectivity = Vector3d(1, 1, 1);
				//material.specularReflectivity = Vector3d(1, 1, 1);
				shaderOptions.lighting = false;
				shaderOptions.lightQty = 0;
				//shaderOptions.lightRefs = &(lightRef[0]);
				//shaderOptions.lightingMaterialRef = &material;
				//shaderOptions.cameraPositionRef = p_cameraPosition;
				//light.shadowMVP = *shadowMVP;
				//light.shadowMapTextureRef = p_shadowMapTexture;
				//shaderOptions.shadowMaps = true;

				for (int i = 0; i < cubeOrientQty; i++)
				{
					shaderOptions.modelWorldOrientRef = &cubeOrients[i];

					graphics->PushMatrix();
					// forward transform the cube
					mvp = graphics->GetMVPMatrix();
					shaderOptions.modelWorldOrientRef = &(cubeOrients[i]);
					//graphics->Transform(cubeOrients[i]);
					// render the cube
					//cube->Render(*graphics);
					graphics->RenderNativeObject(cubeNativeObject, shaderOptions);
					graphics->PopMatrix();
				}
			}
			//else
			//{
			//	for (int i = 0; i < cubeOrientQty; i++)
			//	{
			//		graphics->PushMatrix();
			//		// forward transform the cube
			//		mvp = graphics->GetMVPMatrix();
			//		shaderOptions.modelWorldOrientRef = &(cubeOrients[i]);
			//		graphics->Transform(cubeOrients[i]);
			//		// render the cube
			//		graphics->RenderNativeObjectToShadowMap(cubeNativeObject, shaderOptions);
			//		graphics->PopMatrix();
			//	}

			//}
		}
	};

	class MotionBlurTestWaypoint
	{
	public:
		Vector3d position;

		MotionBlurTestWaypoint(Vector3d &p_position)
		{
			position = p_position;
		}

		MotionBlurTestWaypoint()
		{
			// to support header and footer nodes
		}
	};

	class MotionBlurCamera
	{
	public:
		Orient3d orient;
		float timeMS;

		MotionBlurCamera()
		{
		}

		MotionBlurCamera(Orient3d &p_orient3d)
		{
			orient = p_orient3d;
			timeMS = 0.0f;
		}
	};

	class MotionBurOrientTrackingList : public LinkedList<MotionBlurCamera>
	{
	public:
		Orient3d GetPriorOrient(float p_elapsedTimeMSf, float p_targetMS, float p_minMS, Orient3d &p_currentCamera)
		{
			// p_targetMS is the frame rate we want
			// p_minMS determines when new ones are added
			bool remove = false;
			LinkedListNode<MotionBlurCamera> *node = GetFirstNode();
			LinkedListNode<MotionBlurCamera> *firstNode = node; // track for later, to make sure list always has at least one
			LinkedListNode<MotionBlurCamera> *useNode = nullptr;
			if (node != nullptr)
			{
				while (node != &(footer))
				{
					LinkedListNode<MotionBlurCamera> *nextNode = node->next;

					if (remove == false)
					{
						node->data.timeMS += p_elapsedTimeMSf;
						if (node->data.timeMS >= p_targetMS && useNode != nullptr)
							// we don't need the rest
							remove = true;
						else if (node->data.timeMS >= p_targetMS && useNode == nullptr)
							useNode = node;
					}
					if (remove == true)
						DeleteNode(node);

					node = nextNode;
				}
			}
			// add current orient if 
			if (GetFirstNode() == nullptr || GetFirstNode()->data.timeMS >= p_minMS)
			{
				// add current in first slot
				LinkedListNode<MotionBlurCamera> *newNode = GetNewNode();
				newNode->data.orient = p_currentCamera;
				newNode->data.timeMS = 0.0f;
				InsertNode(newNode);
			}

			// return result
			if (useNode == nullptr)
				return p_currentCamera;
			else
			{
				// interpolate between the use orient and the current orient depending on time
				Orient3d orient = useNode->data.orient;
				float interpolateFactor = (useNode->data.timeMS - p_targetMS) / useNode->data.timeMS;
				orient = Orient3d::Interpolate(orient, p_currentCamera, interpolateFactor);
				return orient;
			}
		}
	};

	class MotionBlurObject
	{
	public:
		Orient3d orient;
		Vector3d interpolationPriorPosition;
		float interpolationFactor;
		LinkedList<MotionBlurTestWaypoint> *waypointListRef;
		LinkedListNode<MotionBlurTestWaypoint> *nextWaypointNodeRef;
		Model3d *modelRef;
		GraphicsNativeObjectContainer *nativeObjectRef;
		bool spinU;
		bool spinL;
		bool move;
		MotionBurOrientTrackingList priorOrients; // for motion blur

		void Initialize()
		{
			spinU = false;
			spinL = false;
			move = false;
			interpolationFactor = 0.0f;
			waypointListRef = nullptr;
			nextWaypointNodeRef = nullptr;
			modelRef = nullptr;
			nativeObjectRef = nullptr;
		}
	};

	public ref class TestMotionBlur : public GameBase
	{
	public:

		Orient3d *planeOrient;
		Orient3d *cameraOrient;
		Orient3d *priorCameraOrient; // for now

		float cameraSpinDegrees;
		float cameraPitchDegrees;

		Model3d *cube;
		Model3d *rod;
		Model3d *plane;

		GameTimer *timer;

		// object list
		LinkedList<MotionBlurObject> *objectList;

		// waypoint lists and tracking
		LinkedList<MotionBlurTestWaypoint> *movingCubeWaypoints;
		LinkedList<MotionBlurTestWaypoint> *movingSpinningCubeWaypoints;
		LinkedList<MotionBlurTestWaypoint> *movingSpinningRodWaypoints;

		// slow motion
		float slowMotionFactor;

		// simulate low frame rate
		float minimumTimeElapsedMS;
		bool okToRender;

		// render buffers
		GraphicsFrameBufferContainer *renderbuffer1;
		GraphicsMotionBlurModeEnum motionBlurMode;

		// past cameras
		MotionBurOrientTrackingList *pastCameras;

		// native objects
		GraphicsNativeObjectContainer *cubeNativeObject;
		GraphicsNativeObjectContainer *rodNativeObject;
		GraphicsNativeObjectContainer *planeNativeObject;

		float animationElapsedTimeMS;

		TestMotionBlur(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;

			objectList = nullptr;

			planeOrient = nullptr;
			cameraOrient = nullptr;
			priorCameraOrient = nullptr;

			movingCubeWaypoints = nullptr;
			movingSpinningCubeWaypoints = nullptr;
			movingSpinningRodWaypoints = nullptr;

			cube = nullptr;
			rod = nullptr;
			plane = nullptr;

			timer = nullptr;

			slowMotionFactor = 1.0f;
			minimumTimeElapsedMS = 0.0f; // allow 1000ms
			okToRender = true;

			renderbuffer1 = nullptr;
			motionBlurMode = GraphicsMotionBlurModeEnum::None;

			pastCameras = nullptr;

			cubeNativeObject = nullptr;
			rodNativeObject = nullptr;
			planeNativeObject = nullptr;
		}

		virtual ~TestMotionBlur()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameContext::Instance->TextureRegistry.RegisterTexture("Brick", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("brickwork-texture.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Brick2", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Brick2.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("Meadow", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Grass_Meadows2.jpg"));

			objectList = new LinkedList<MotionBlurObject>();
			LinkedListNode<MotionBlurObject> *newNode;

			planeOrient = new Orient3d();

			cube = new Model3d();
			cube->MakeCube();
			// skin it!  Make it white for modulation
			cube->SkinTexture0(GameContext::TextureRegistry.GetTexture("Brick"));
			for (int v = 0; v < cube->GetVertexQty(); v++)
				cube->GetVertex(v)->colorIndex = 7; // white

			rod = new Model3d();
			rod->MakeCube();
			// skin it!  Make it white for modulation
			rod->SkinTexture0(GameContext::TextureRegistry.GetTexture("Brick"));
			for (int v = 0; v < rod->GetVertexQty(); v++)
				rod->GetVertex(v)->colorIndex = 7; // white
			rod->ReScale(Vector3d(0.2f, 0.2f, 2.0f));

			plane = new Model3d();
			plane->Initialize(1, 4, 1);
			plane->GetColor(0)->Set(255, 255, 255);
			plane->GetVertex(0)->colorIndex = 0;
			plane->GetVertex(1)->colorIndex = 0;
			plane->GetVertex(2)->colorIndex = 0;
			plane->GetVertex(3)->colorIndex = 0;
			plane->GetVertex(0)->vertex.Set(100.0f, 0.0f, 100.0f);
			plane->GetVertex(1)->vertex.Set(-100.0f, 0.0f, 100.0f);
			plane->GetVertex(2)->vertex.Set(-100.0f, 0.0f, -100.0f);
			plane->GetVertex(3)->vertex.Set(100.0f, 0.0f, -100.0f);
			plane->GetSurface(0)->Initialize(4, true);
			plane->GetSurface(0)->SetVertexIndex(0, 0);
			plane->GetSurface(0)->SetVertexIndex(1, 1);
			plane->GetSurface(0)->SetVertexIndex(2, 2);
			plane->GetSurface(0)->SetVertexIndex(3, 3);
			plane->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
			plane->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.0f);
			plane->GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
			plane->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);
			plane->GetSurface(0)->SetTexture0(GameContext::TextureRegistry.GetTexture("Meadow"));

			// waypoints
			movingCubeWaypoints = new LinkedList<MotionBlurTestWaypoint>();
			movingCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(4.0f, 2.0f, 0.0f)));
			movingCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(4.0f, 40.0f, 0.0f)));
			movingCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(4.0f, 40.0f, -40.0f)));
			movingCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(4.0f, 2.0f, -40.0f)));
			movingSpinningCubeWaypoints = new LinkedList<MotionBlurTestWaypoint>();
			movingSpinningCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(12.0f, 2.0f, 0.0f)));
			movingSpinningCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(12.0f, 40.0f, 0.0f)));
			movingSpinningCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(12.0f, 40.0f, -40.0f)));
			movingSpinningCubeWaypoints->Add(MotionBlurTestWaypoint(Vector3d(12.0f, 2.0f, -40.0f)));
			movingSpinningRodWaypoints = new LinkedList<MotionBlurTestWaypoint>();
			movingSpinningRodWaypoints->Add(MotionBlurTestWaypoint(Vector3d(-8.0f, 2.0f, 0.0f)));
			movingSpinningRodWaypoints->Add(MotionBlurTestWaypoint(Vector3d(-8.0f, 40.0f, 0.0f)));
			movingSpinningRodWaypoints->Add(MotionBlurTestWaypoint(Vector3d(-8.0f, 40.0f, -40.0f)));
			movingSpinningRodWaypoints->Add(MotionBlurTestWaypoint(Vector3d(-8.0f, 2.0f, -40.0f)));

			cubeNativeObject = new GraphicsNativeObjectContainer();
			rodNativeObject = new GraphicsNativeObjectContainer();
			planeNativeObject = new GraphicsNativeObjectContainer();

			// objects
			// stationary cube
			newNode = objectList->GetNewNode();
			newNode->data.Initialize();
			newNode->data.orient.LoadIdentity();
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(2.0f);
			newNode->data.interpolationPriorPosition = newNode->data.orient.p;
			newNode->data.modelRef = cube;
			newNode->data.nativeObjectRef = cubeNativeObject;
			objectList->AddNode(newNode);
			// moving cube
			newNode = objectList->GetNewNode();
			newNode->data.Initialize();
			newNode->data.orient.LoadIdentity();
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.l.ScalarMult(4.0f);
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(2.0f);
			newNode->data.move = true;
			newNode->data.interpolationPriorPosition = newNode->data.orient.p;
			newNode->data.waypointListRef = movingCubeWaypoints;
			newNode->data.nextWaypointNodeRef = movingCubeWaypoints->GetFirstNode()->next;
			newNode->data.modelRef = cube;
			newNode->data.nativeObjectRef = cubeNativeObject;
			objectList->AddNode(newNode);
			// spinning cube
			newNode = objectList->GetNewNode();
			newNode->data.Initialize();
			newNode->data.orient.LoadIdentity();
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.l.ScalarMult(8.0f);
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(2.0f);
			newNode->data.interpolationPriorPosition = newNode->data.orient.p;
			newNode->data.spinU = true;
			newNode->data.modelRef = cube;
			newNode->data.nativeObjectRef = cubeNativeObject;
			objectList->AddNode(newNode);
			// moving spinning cube
			newNode = objectList->GetNewNode();
			newNode->data.Initialize();
			newNode->data.orient.LoadIdentity();
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.l.ScalarMult(12.0f);
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(2.0f);
			newNode->data.move = true;
			newNode->data.interpolationPriorPosition = newNode->data.orient.p;
			newNode->data.waypointListRef = movingSpinningCubeWaypoints;
			newNode->data.nextWaypointNodeRef = movingSpinningCubeWaypoints->GetFirstNode()->next;
			newNode->data.spinU = true;
			newNode->data.modelRef = cube;
			newNode->data.nativeObjectRef = cubeNativeObject;
			objectList->AddNode(newNode);
			// spinning rod
			newNode = objectList->GetNewNode();
			newNode->data.Initialize();
			newNode->data.orient.LoadIdentity();
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.l.ScalarMult(-4.0f);
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(2.0f);
			newNode->data.interpolationPriorPosition = newNode->data.orient.p;
			newNode->data.spinL = true;
			newNode->data.modelRef = rod;
			newNode->data.nativeObjectRef = rodNativeObject;
			objectList->AddNode(newNode);
			// moving spinning Rod
			newNode = objectList->GetNewNode();
			newNode->data.Initialize();
			newNode->data.orient.LoadIdentity();
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.l.ScalarMult(-8.0f);
			newNode->data.orient.p = newNode->data.orient.p + newNode->data.orient.u.ScalarMult(2.0f);
			newNode->data.move = true;
			newNode->data.interpolationPriorPosition = newNode->data.orient.p;
			newNode->data.waypointListRef = movingSpinningRodWaypoints;
			newNode->data.nextWaypointNodeRef = movingSpinningRodWaypoints->GetFirstNode()->next;
			newNode->data.spinL = true;
			newNode->data.modelRef = rod;
			newNode->data.nativeObjectRef = rodNativeObject;
			objectList->AddNode(newNode);
			// leave plane at origin
			planeOrient->LoadIdentity();

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			// back up the camera
			cameraOrient->Rotate(cameraOrient->u, -45.0f);
			cameraOrient->Rotate(cameraOrient->l, -45.0f);
			// initial position for camera
			cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(-20.0f);
			cameraSpinDegrees = -45.0f;
			cameraPitchDegrees = -45.0f;

			// initialize prior
			priorCameraOrient = new Orient3d();
			*priorCameraOrient = *cameraOrient;

			timer = new GameTimer();

			renderbuffer1 = new GraphicsFrameBufferContainer();

			pastCameras = new MotionBurOrientTrackingList();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (priorCameraOrient != nullptr)
			{
				delete priorCameraOrient;
				priorCameraOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (rod != nullptr)
			{
				delete rod;
				rod = nullptr;
			}
			if (plane != nullptr)
			{
				delete plane;
				plane = nullptr;
			}
			if (objectList != nullptr)
			{
				delete objectList;
				objectList = nullptr;
			}
			if (planeOrient != nullptr)
			{
				delete planeOrient;
				planeOrient = nullptr;
			}
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (movingCubeWaypoints != nullptr)
			{
				delete movingCubeWaypoints;
				movingCubeWaypoints = nullptr;
			}
			if (movingSpinningCubeWaypoints != nullptr)
			{
				delete movingSpinningCubeWaypoints;
				movingSpinningCubeWaypoints = nullptr;
			}
			if (movingSpinningRodWaypoints != nullptr)
			{
				delete movingSpinningRodWaypoints;
				movingSpinningRodWaypoints = nullptr;
			}
			if (renderbuffer1 != nullptr)
			{
				delete renderbuffer1;
				renderbuffer1 = nullptr;
			}
			if (pastCameras != nullptr)
			{
				delete pastCameras;
				pastCameras = nullptr;
			}
			if (cubeNativeObject != nullptr)
			{
				delete cubeNativeObject;
				cubeNativeObject = nullptr;
			}
			if (rodNativeObject != nullptr)
			{
				delete rodNativeObject;
				rodNativeObject = nullptr;
			}
			if (planeNativeObject != nullptr)
			{
				delete planeNativeObject;
				planeNativeObject = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}

		void ViewportSizeChanged(GameViewport ^p_viewport) override
		{
			// force a redo on the stars
			if (renderbuffer1 != nullptr)
			{
				// force recreation of frame buffer to size of viewport (happens in PerformRender)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics()->DestroyFrameBuffer(renderbuffer1);
			}
		}

		bool DoGameLoop() override
		{
			joystick->Poll();
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed())
			{
				if (mouse.IsVisible() == false)
					mouse.Show();
				return false;
			}

			// simulate low frame rate
			okToRender = false;
			if (timer->GetElapsedTimeMSFloat() < minimumTimeElapsedMS)
				return true;
			okToRender = true;

			// mouse
			if (mouse.visible == false)
			{
				float mouseSensitivity = 0.5f;
				cameraSpinDegrees += float(mouse.offsetX) * mouseSensitivity;
				cameraPitchDegrees -= float(mouse.offsetY) * mouseSensitivity;
				while (cameraSpinDegrees > 360.0f)
					cameraSpinDegrees -= 360.0f;
				while (cameraSpinDegrees <= 0.0f)
					cameraSpinDegrees += 360.0f;
				if (cameraPitchDegrees > 90.0f)
					cameraPitchDegrees = 90.0f;
				if (cameraPitchDegrees < -90.0f)
					cameraPitchDegrees = -90.0f;
				Vector3d oldP = cameraOrient->p;
				cameraOrient->LoadIdentity();
				cameraOrient->Rotate(cameraOrient->u, cameraSpinDegrees);
				cameraOrient->Rotate(cameraOrient->l, cameraPitchDegrees);
				cameraOrient->p = oldP;

				// move it!
				float amount = timer->GetElapsedTimeMSFloat() * 20.0f / 1000.0f; // move 20 feet per second
				// no slide correction here.
				if (keyboardKeys.GetKey('W')->IsPressed())
				{
					cameraOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(amount);
				}
				if (keyboardKeys.GetKey('S')->IsPressed())
				{
					cameraOrient->p = cameraOrient->p - cameraOrient->f.ScalarMult(amount);
				}
				if (keyboardKeys.GetKey('A')->IsPressed())
				{
					cameraOrient->p = cameraOrient->p + cameraOrient->l.ScalarMult(amount);
				}
				if (keyboardKeys.GetKey('D')->IsPressed())
				{
					cameraOrient->p = cameraOrient->p - cameraOrient->l.ScalarMult(amount);
				}
			}
			if (mouse.visible == false && appActivated == true)
			{
				// move it to the middle of the viewport (should be screen position)
				GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
				mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
			}
			mouse.ZeroOffsets();

			// keys
			if (keyboardKeys.GetKey(192)->IsClicked() == true) // ~
			{
				if (slowMotionFactor != 1.0f)
					slowMotionFactor = 1.0f;
				else
					slowMotionFactor = 0.1f;
			}
			if (keyboardKeys.GetKey('1')->IsClicked() == true)
			{
				if (minimumTimeElapsedMS == 0.0f)
					minimumTimeElapsedMS = 100.0f;
				else
					minimumTimeElapsedMS = 0.0f;
			}
			if (keyboardKeys.GetKey(186)->IsClicked() == true) // semicolon
			{
				if (mouse.IsVisible() == false)
					mouse.Show();
				else
					mouse.Hide();
			}	
			if (keyboardKeys.GetKey('M')->IsClicked() == true)
			{
				if (motionBlurMode == GraphicsMotionBlurModeEnum::None)
					motionBlurMode = GraphicsMotionBlurModeEnum::CameraOnly;
				else if (motionBlurMode == GraphicsMotionBlurModeEnum::CameraOnly)
					motionBlurMode = GraphicsMotionBlurModeEnum::CameraAndFragmentVelocity;
				else
					motionBlurMode = GraphicsMotionBlurModeEnum::None;
			}
			if (keyboardKeys.GetKey('C')->IsClicked())
			{
				GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
				graphics->SetVSyncEnabled(!graphics->VSyncIsEnabled());
			}
			keyboardKeys.ClearClicked();

			animationElapsedTimeMS = timer->GetElapsedTimeMSFloat() * slowMotionFactor;
			Animate(animationElapsedTimeMS);

			// need for rendering, getting prior camera
			//timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elapsedTimeMSf)
		{
			float timeToConsumeMSf = p_elapsedTimeMSf;
			float consumeStepMS = 16.0f;
			while (timeToConsumeMSf > 0.0f)
			{
				if (timeToConsumeMSf > consumeStepMS)
				{
					AnimateObjects(consumeStepMS);
					timeToConsumeMSf -= consumeStepMS;
				}
				else
				{
					AnimateObjects(timeToConsumeMSf);
					timeToConsumeMSf = 0.0f;
				}
			}
		}

		void AnimateObjects(float p_elapsedTimeMSf)
		{
			float spinDegreesPerMS = 720.0f / 1000.0f; // 2 revolutions per second
			float moveInterpolationPerMS = 1.0f / 1000.0f; // 1 waypoint per second

			LinkedListEnumerator<MotionBlurObject> objectEnumerator = LinkedListEnumerator<MotionBlurObject>(*objectList);
			while (objectEnumerator.MoveNext())
			{
				MotionBlurObject *object = &(objectEnumerator.Current()->data);
				// spin spinners
				if (object->spinU == true)
					object->orient.Rotate(object->orient.u, spinDegreesPerMS * p_elapsedTimeMSf);
				if (object->spinL == true)
					object->orient.Rotate(object->orient.l, 2.0f * spinDegreesPerMS * p_elapsedTimeMSf); // twice as fast

				// move movers
				// interpolate, advance list node reference, etc.
				if (object->move == true)
				{
					float amountOfInterpolation = moveInterpolationPerMS * p_elapsedTimeMSf;
					while (amountOfInterpolation > 0.0f)
					{
						if (amountOfInterpolation >= (1.0f - object->interpolationFactor))
						{
							// advance to next node, reset interpolation
							amountOfInterpolation -= (1.0f - object->interpolationFactor);
							object->interpolationFactor = 0.0f;
							object->interpolationPriorPosition = object->nextWaypointNodeRef->data.position;
							if (object->nextWaypointNodeRef == object->waypointListRef->GetLastNode())
								object->nextWaypointNodeRef = object->waypointListRef->GetFirstNode();
							else
								object->nextWaypointNodeRef = object->nextWaypointNodeRef->next;
						}
						else
						{
							object->interpolationFactor += amountOfInterpolation;
							amountOfInterpolation = 0.0f;
						}
					}
					// calculate position from prior interpolation with target
					object->orient.p = object->interpolationPriorPosition + (object->nextWaypointNodeRef->data.position - object->interpolationPriorPosition).ScalarMult(object->interpolationFactor);
				}
			}
		}

		void PerformRender() override
		{
			// check for simulated low frame rate
			if (okToRender == false)
				return;

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();

			// set up native objects
			if (cubeNativeObject->nativeObjectRef == nullptr)
				cube->CreateNativeObject(graphics, cubeNativeObject, true);
			if (rodNativeObject->nativeObjectRef == nullptr)
				rod->CreateNativeObject(graphics, rodNativeObject, true);
			if (planeNativeObject->nativeObjectRef == nullptr)
				plane->CreateNativeObject(graphics, planeNativeObject, true);

			graphics->MakeCurrent();
			GraphicsFrameBufferColorFormatEnum attachmentFormats[2] = { GraphicsFrameBufferColorFormatEnum::RGB, GraphicsFrameBufferColorFormatEnum::Vector3d16Bit };
			GraphicsAttachedFrameBufferUsageEnum attachmentUsage[2] = { GraphicsAttachedFrameBufferUsageEnum::StandardColor, GraphicsAttachedFrameBufferUsageEnum::MotionBlurFragmentScreenOffset};
			if (motionBlurMode != GraphicsMotionBlurModeEnum::None)
			{
				if (renderbuffer1->frameBuffer == nullptr)
					graphics->CreateFrameBuffer(renderbuffer1, GraphicsFrameBufferTypeEnum::Texture, GraphicsFrameBufferTypeEnum::Texture,
					GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetWidth(),
					GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetHeight(), 
					1,
					false,
					attachmentFormats, 2);

				graphics->SetCurrentFrameBuffer(renderbuffer1);
			}
			else
				// use main
				graphics->SetCurrentFrameBuffer(nullptr);

			graphics->ClearScreen(GameColor(0, 128, 128));
			if (motionBlurMode == GraphicsMotionBlurModeEnum::CameraAndFragmentVelocity)
			{
				// clear velocity buffer
				graphics->ClearBuffer(1, Vector4d(1.0f, 0.0f, 60.0f / 1920.0f, 1.0f));
				//graphics->ClearBuffer(1, Vector4d(60000.0f, 60000.0f, 60000.0f, 1.0f));
				// restore buffers
				int buffers[2] = { 0, 1 };
				// hmm, changing this to 1, 0 had no odd effect - even the depth buffer continued working.  I don't know why.  doesn't even affect the clear color of the main buffer
				// for now, only write to the main one, don't change the 3d data texture
				graphics->SetDrawBuffers(buffers, 2);
			}
			else if(motionBlurMode == GraphicsMotionBlurModeEnum::CameraOnly)
			{
				int buffers[1] = { 0 };
				graphics->SetDrawBuffers(buffers, 1);
			}

			// covers both CameraOnly and Camera with Velocity
			GraphicsAttachedFrameBufferUsageEnum drawBufferUsage[MAX_FRAMEBUFFER_ATTACHMENT_QTY + 1];
			drawBufferUsage[0] = GraphicsAttachedFrameBufferUsageEnum::StandardColor;
			drawBufferUsage[1] = GraphicsAttachedFrameBufferUsageEnum::MotionBlurFragmentScreenOffset;

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);

			graphics->DefaultTransform();

			// reverse transform the camera
			// provides mvp for motion blur postprocessing data
			graphics->ReverseTransform(*cameraOrient);

			GraphicsShaderOptions shaderOptions;
			Matrix4d mvp = graphics->GetMVPMatrix();
			shaderOptions.eyeMVPMatrixRef = &mvp;

			float targetMotionBlurMS = 20.0f;

			LinkedListEnumerator<MotionBlurObject> objectEnumerator = LinkedListEnumerator<MotionBlurObject>(*objectList);
			bool useNative = true;
			while (objectEnumerator.MoveNext())
			{
				if (useNative == false)
				{
					graphics->PushMatrix();
					graphics->Transform(objectEnumerator.Current()->data.orient);
					objectEnumerator.Current()->data.modelRef->Render(*graphics);
					graphics->PopMatrix();
				}
				else
				{
					shaderOptions.modelWorldOrientRef = &(objectEnumerator.Current()->data.orient);
					shaderOptions.drawBuffersUsageArrayRef = drawBufferUsage;

					// just a test value for below
					Orient3d priorOrient = objectEnumerator.Current()->data.priorOrients.GetPriorOrient(animationElapsedTimeMS, targetMotionBlurMS, 10.0f, objectEnumerator.Current()->data.orient);

					// todo: prep velocity buffer
					graphics->RenderNativeObject(objectEnumerator.Current()->data.nativeObjectRef, shaderOptions);

					// motion blur prior ms testing
					//shaderOptions.modelWorldOrientRef = &(priorOrient);
					//graphics->RenderNativeObject(objectEnumerator.Current()->data.nativeObjectRef, shaderOptions);
				}
			}

			if (useNative == false)
			{
				graphics->PushMatrix();
				graphics->Transform(*planeOrient);
				plane->Render(*graphics);
				graphics->PopMatrix();
			}
			else
			{
				Orient3d identity;
				identity.LoadIdentity();
				shaderOptions.modelWorldOrientRef = &(identity);
				graphics->RenderNativeObject(planeNativeObject, shaderOptions);
			}

			// get matrix necessary for calculating motionblur offset for each fragment
			// do this always, if only to insert a new orient just to keep track of everything (no need to interpolate and return a result if we aren't motion blurring, but whatever)
			Orient3d priorOrient = pastCameras->GetPriorOrient(animationElapsedTimeMS, targetMotionBlurMS, 10.0f, *cameraOrient);

			if (motionBlurMode != GraphicsMotionBlurModeEnum::None)
			{
				// now render scene to main
				GraphicsPostProcessShaderOptions postProcessOptions;

				// set motionblur mode, get prior current matrix, set number of samples, etc.

				if (motionBlurMode == GraphicsMotionBlurModeEnum::CameraOnly)
				{
					if (priorOrient.Equals(*cameraOrient) == false)
					{
						// prior and current cameras are different, 30ms apart
						postProcessOptions.motionBlurMode = motionBlurMode;

						Matrix4d currentMvp = graphics->GetMVPMatrix();
						graphics->DefaultTransform();
						graphics->ReverseTransform(priorOrient);
						Matrix4d priorMvp = graphics->GetMVPMatrix();
						Matrix4d currentMvpInverse = currentMvp.GetInverse();
						Matrix4d priorCurrentInverseMvpMatrix = priorMvp * currentMvpInverse;
						postProcessOptions.motionBlurPriorCurrentInverseMvpMatrixRef = &priorCurrentInverseMvpMatrix;
					}
				}
				else if (motionBlurMode == GraphicsMotionBlurModeEnum::CameraAndFragmentVelocity)
				{
					postProcessOptions.motionBlurMode = motionBlurMode;
					postProcessOptions.motionBlurFragmentVelocityTextureRef = renderbuffer1->attachments[0];
				}
				postProcessOptions.motionBlurSamples = 3; // default

				ModelVertex vertices[4] = { ModelVertex(Vector3d(400, 300, 1), 0), ModelVertex(Vector3d(-400, 300, 1), 0), ModelVertex(Vector3d(-400, -300, 1), 0), ModelVertex(Vector3d(400, -300, 1), 0) };
				vertices[0].vertex.x = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
				vertices[0].vertex.y = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
				vertices[1].vertex.x = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
				vertices[1].vertex.y = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
				vertices[2].vertex.x = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
				vertices[2].vertex.y = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
				vertices[3].vertex.x = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth()) / 2.0f;
				vertices[3].vertex.y = -float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()) / 2.0f;
				ModelVertexTextureCoords texCoords[4] = { ModelVertexTextureCoords(0.0f, 1.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(0.0f, 0.0f) };

				graphics->SetCurrentFrameBuffer(nullptr);
				graphics->ClearScreen(GameColor(0, 128, 128));

				// set up for full screen rendering of the above quad
				graphics->SetOrthoProjection(0.1f, 100.0f);
				graphics->DefaultTransform();
				graphics->Scale(2.0f / float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()), 2.0f / float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight()), 1.0f);

				Matrix4d orthoMvp = graphics->GetMVPMatrix();
				postProcessOptions.mvpMatrixRef = &orthoMvp;
				postProcessOptions.srcTextureRef = renderbuffer1->colorBufferTexture;
				postProcessOptions.depthTextureRef = renderbuffer1->depthBufferTexture;
				//postProcessOptions.grayScale = 1.0f; // testing to make sure base post processing works

				//postProcessOptions.debugVector3dBuffer = true;
				//postProcessOptions.debugTextureRef = renderbuffer1->attachments[0];

				graphics->RenderPostProcessingShaderQuad(vertices, texCoords, postProcessOptions);
			}

			// for now, until we track orients per 30ms (or whatever the interval is)
			// don't need this now
			//*priorCameraOrient = *cameraOrient;

			graphics->FinishRender();
			graphics->SwapBuffers();

			timer->ResetElapsedTime();
		}

	};

	// only supported on full HD screens for uploading to youtube for google cardboard for playback on mobile device in google cardboard
	// as long as screen is 16:9, can work in 1080p or 720p
	// the purpose of this demo is to test the most comfortable position of the reticle for distant viewing (straight ahead eye position)
	public ref class TestGoogleCardboardStub : public GameBase
	{
	public:

		float divisionWidth; // in screen amount (0.0-1.0), assumed rest of screen is eye renders on each side (until testing with larger screen iphones)
		float minLeftRightAspectRatio; // where is vanishing point in aspect ratio
		float maxLeftRightAspectRatio; // where is vanishing point in aspect ratio
		float leftRightAspectRatio;
		float aspectIncrement;
		float incrementQty;
		int currentIncrement;
		int maxIncrement;

		float reticleRadius;
		float linePosition;

		TestGoogleCardboardStub(HWND p_hWnd) : GameBase(p_hWnd)
		{
			divisionWidth = 4.0f / 1334.0f; // 4 pixels out of 1334 on iphone7

			// range for adult eyes
			minLeftRightAspectRatio = 2.8f / 8.0f; // with these values, rendering only a dot, best calibration happens around 58-60, more 60, but 58 is deeper.  So, between 3.09f-3.1f / 8.0f?
			//  but I am still able to resolve it if it's stationary all the way out to 50.  So, 3.05 / 8.0f?  I don't know if that's actually beyond eyes looking forward.
			// further experimentation - about 37!!!
			maxLeftRightAspectRatio = 3.3f / 8.0f;
			maxIncrement = 100;
			aspectIncrement = (maxLeftRightAspectRatio - minLeftRightAspectRatio) / float(maxIncrement);
			currentIncrement = 100;
			leftRightAspectRatio = CalculateLeftRightAspectRatio();

			reticleRadius = 2.0f / 1334.0f;

			linePosition = 0.40f; // lines to keep eyes lined up.  10% of screen, ends up being 3-7/8" up on wall at 24 inches distance.  So full screen is 19.375" up at 24" for a fov to top of 38.9 degrees, or total of 77.8 degrees.
		}

		virtual ~TestGoogleCardboardStub()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("Reticle", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			GameContext::Instance->FontRegistry.RegisterFont("VerdanaSmall", gcnew System::Drawing::Font("Verdana", 12, System::Drawing::FontStyle::Bold));


			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// use left and right arrow to move reticle for testing
			// 37 left arrow
			if (keyboardKeys.GetKey(37)->IsClicked())
			{
				currentIncrement--;
				if (currentIncrement < 0)
					currentIncrement = 0;
				leftRightAspectRatio = CalculateLeftRightAspectRatio();
			}
			// 39 right arrow
			if (keyboardKeys.GetKey(39)->IsClicked())
			{
				currentIncrement++;
				if (currentIncrement > maxIncrement)
					currentIncrement = maxIncrement;
				leftRightAspectRatio = CalculateLeftRightAspectRatio();
			}

			keyboardKeys.ClearClicked();

			return true;
		}

		float CalculateLeftRightAspectRatio()
		{
			return minLeftRightAspectRatio + aspectIncrement * float(currentIncrement);
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->Set2dWindowProjection();

			// render a test font
			//graphics->RenderFont("1234567890", GameContext::FontRegistry.GetFont("VerdanaSmall"), 100, 100, GameColor(255, 192, 0));

			// Render division
			ModelVertex quad[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0)};
			GameColor white(255, 255, 255);
			float width = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth());
			float height = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());
			float centerX = width / 2.0f;
			float centerY = width / 2.0f;
			quad[0].vertex.Set(centerX - width * divisionWidth / 2.0f, 0, 0);
			quad[1].vertex.Set(centerX + width * divisionWidth / 2.0f, 0, 0);
			quad[2].vertex.Set(centerX + width * divisionWidth / 2.0f, height, 0);
			quad[3].vertex.Set(centerX - width * divisionWidth / 2.0f, height, 0);
			graphics->RenderFilledQuad(&white, 1, quad, 4);

			// render calibration lines for eyes
			quad[0].vertex.Set(0.0f, height * linePosition, 0);
			quad[1].vertex.Set(width, height * linePosition, 0);
			quad[2].vertex.Set(width, height * linePosition + 2, 0);
			quad[3].vertex.Set(0.0f, height * linePosition + 2, 0);
			graphics->RenderFilledQuad(&white, 1, quad, 4);

			quad[0].vertex.Set(0.0f, height - height * linePosition - 2, 0);
			quad[1].vertex.Set(width, height - height * linePosition - 2, 0);
			quad[2].vertex.Set(width, height - height * linePosition, 0);
			quad[3].vertex.Set(0.0f, height - height * linePosition, 0);
			graphics->RenderFilledQuad(&white, 1, quad, 4);

			// for rendering
			String ^incrementString = String::Format("{0}", currentIncrement);
			System::Drawing::Point incrementSize = GameContext::FontRegistry.GetFont("VerdanaSmall")->GetTextSize(incrementString);

			float renderedReticleRadius = reticleRadius * height;

			// render left eye reticle position and increment according to leftright aspect and radius
			float eyeMinX = 0;
			float eyeMaxX = centerX - width * divisionWidth / 2.0f;
			float reticleCenterX = eyeMinX + leftRightAspectRatio * (eyeMaxX - eyeMinX); // left eye formula
			quad[0].vertex.Set(reticleCenterX - renderedReticleRadius, height / 2.0f - renderedReticleRadius, 0);
			quad[1].vertex.Set(reticleCenterX + renderedReticleRadius, height / 2.0f - renderedReticleRadius, 0);
			quad[2].vertex.Set(reticleCenterX + renderedReticleRadius, height / 2.0f + renderedReticleRadius, 0);
			quad[3].vertex.Set(reticleCenterX - renderedReticleRadius, height / 2.0f + renderedReticleRadius, 0);
			graphics->RenderFilledQuad(&white, 1, quad, 4);
			graphics->RenderFont(incrementString, GameContext::FontRegistry.GetFont("VerdanaSmall"), reticleCenterX - float(incrementSize.X) / 2.0f, float(height / 2.0f + renderedReticleRadius + 1), GameColor(255, 192, 0));

			// render right eye reticle position and increment according to leftright aspect and radius
			eyeMinX = centerX + width * divisionWidth / 2.0f;
			eyeMaxX = width;
			reticleCenterX = eyeMinX + (1.0f - leftRightAspectRatio) * (eyeMaxX - eyeMinX); // right eye formula
			quad[0].vertex.Set(reticleCenterX - renderedReticleRadius, height / 2.0f - renderedReticleRadius, 0);
			quad[1].vertex.Set(reticleCenterX + renderedReticleRadius, height / 2.0f - renderedReticleRadius, 0);
			quad[2].vertex.Set(reticleCenterX + renderedReticleRadius, height / 2.0f + renderedReticleRadius, 0);
			quad[3].vertex.Set(reticleCenterX - renderedReticleRadius, height / 2.0f + renderedReticleRadius, 0);
			graphics->RenderFilledQuad(&white, 1, quad, 4);
			graphics->RenderFont(incrementString, GameContext::FontRegistry.GetFont("VerdanaSmall"), reticleCenterX - float(incrementSize.X) / 2.0f, float(height / 2.0f + renderedReticleRadius + 1), GameColor(255, 192, 0));

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

	// only supported on full HD screens for uploading to youtube for google cardboard for playback on mobile device in google cardboard
	// as long as screen is 16:9, can work in 1080p or 720p
	// the purpose of this demo is to test the most comfortable position of the reticle for distant viewing (straight ahead eye position)
	public ref class TestGoogleCardboardSceneStub : public GameBase
	{
	public:

		Orient3d *cameraOrient;
		Orient3d *farCubeOrient;
		Orient3d *nearCubeOrient;
		Model3d *cube;

		TestGoogleCardboardSceneStub(HWND p_hWnd) : GameBase(p_hWnd)
		{
			cameraOrient = nullptr;
			nearCubeOrient = nullptr;
			farCubeOrient = nullptr;
			cube = nullptr;
		}

		virtual ~TestGoogleCardboardSceneStub()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("lightmap9.bmp"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("Reticle", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);

			GameContext::Instance->FontRegistry.RegisterFont("VerdanaSmall", gcnew System::Drawing::Font("Verdana", 12, System::Drawing::FontStyle::Bold));

			cameraOrient = new Orient3d();
			cameraOrient->LoadIdentity();
			nearCubeOrient = new Orient3d();
			nearCubeOrient->LoadIdentity();
			nearCubeOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(4.0f) - cameraOrient->l.ScalarMult(2.0f); // pretty close (40 feet, off to the side)
			farCubeOrient = new Orient3d();
			farCubeOrient->LoadIdentity();
			farCubeOrient->p = cameraOrient->p + cameraOrient->f.ScalarMult(990.0f); // almost past far (10k feet, 2 miles away)

			cube = new Model3d();
			cube->MakeCube();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (cameraOrient != nullptr)
			{
				delete cameraOrient;
				cameraOrient = nullptr;
			}
			if (farCubeOrient != nullptr)
			{
				delete farCubeOrient;
				farCubeOrient = nullptr;
			}
			if (nearCubeOrient != nullptr)
			{
				delete nearCubeOrient;
				nearCubeOrient = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// rotate orient according to mouse movements

			mouse.ZeroOffsets();
			keyboardKeys.ClearClicked();

			return true;
		}

		void PerformRender() override
		{
			StereoscopicCamera camera(4.0f / 1334.0f, 
				-0.25f, 0.0f, 
				2.75f / 12.0f / 10.0f); // split screen camera (standard iPhone 7), max deep pixel for me, 2.75" eye separation

			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			float fov = 77.8f; // standard for iPhone 4" google cardboard

			DrawElements(graphics, fov, 0.01f, 1000.0f, *cameraOrient, &camera, true); // left eye
			DrawElements(graphics, fov, 0.01f, 1000.0f, *cameraOrient, &camera, false); // right eye

			// restore viewport for next scene clear
			graphics->SetViewportSize(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
				GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());

			// Render division
			graphics->Set2dWindowProjection();
			ModelVertex quad[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
			GameColor white(255, 255, 255);
			float width = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth());
			float height = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());
			float centerX = width / 2.0f;
			float centerY = width / 2.0f;
			quad[0].vertex.Set(centerX - width * camera.divisionWidth / 2.0f, 0, 0);
			quad[1].vertex.Set(centerX + width * camera.divisionWidth / 2.0f, 0, 0);
			quad[2].vertex.Set(centerX + width * camera.divisionWidth / 2.0f, height, 0);
			quad[3].vertex.Set(centerX - width * camera.divisionWidth / 2.0f, height, 0);
			graphics->RenderFilledQuad(&white, 1, quad, 4);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawElements(GraphicsBase *p_graphics, float p_fovY, float p_near, float p_far, Orient3d &p_viewpointOrient, StereoscopicCamera *p_camera, bool p_left)
		{
			// set up projection
			if (p_camera == nullptr)
			{
				// not a case here
			}
			else
			{
				if (p_left == true)
				{
					p_graphics->SetPerspectiveProjectionStereoscopicLeft(p_fovY, p_near, p_far, *p_camera);
					p_graphics->DefaultTransformStereoscopicLeft(*p_camera);
				}
				else
				{
					p_graphics->SetPerspectiveProjectionStereoscopicRight(p_fovY, p_near, p_far, *p_camera);
					p_graphics->DefaultTransformStereoscopicRight(*p_camera);
				}
			}
			p_graphics->ReverseTransform(p_viewpointOrient);

			// render near cube
			p_graphics->PushMatrix();
			p_graphics->Transform(*nearCubeOrient);
			cube->Render(*p_graphics); // render normal size
			p_graphics->PopMatrix();

			// render far cube
			p_graphics->PushMatrix();
			p_graphics->Transform(*farCubeOrient);
			p_graphics->Scale(100.0f, 100.0f, 1.0f); // render large
			cube->Render(*p_graphics);
			p_graphics->PopMatrix();
		}

	};

	class TetherSwingStructure
	{
	public:
		Model3d *modelRef;
		Orient3d orient;
		float scale;

		TetherSwingStructure()
		{
			Initialize();
		}

		void Initialize()
		{
			modelRef = nullptr;
			scale = 1.0f;
		}
	};

	class TetherShooterData
	{
	public:
		Orient3d *ownerRef; // what object owns this shooter? (usually the shooter is just part of the controlled object's structure)
		Vector3d endPosition; // where is the end of the tether?
		Vector3d startPosition; // where does the tether start? (this can change depending on the owner's orientation to the web, to prevent camera overlap)
		Vector3d priorEndPosition; // for collision checking
		// startPosition is more just for rendering.  It must of course obey maxLength when attached, but is adjusted as owner's orient is adjusted for any reason (world gravity, movement, correction for maxLength)
		// generally, the world affects owner entirely after retraction, then if owner's orient disobeys maxlength when attached, the owner's position and velocity are adjusted

		bool active; // is the tether active? (either shooting or attached)
		bool attached; // is the tether stuck to an object?  Otherwise, it is shooting forward (and will stop when it strikes a structure)
		Vector3d velocityPerMS; // which direction is it firing?
		float maxLength; // once attached, maxLength is solid and affects position of owner - it can be rendered as shorter, but once max length is reached, it's stuck at that max
		float retractPerMS; // speed of retraction (pulling in tether)
		float minLength; // tether can be no shorter than this when attached

		bool triggerDown; // prevent repeat fire

		TetherShooterData()
		{
			Initialize();
		}

		void Initialize()
		{
			ownerRef = nullptr;
			active = false;
			retractPerMS = 2.0f / 1000.0f; // 20 feet per second
			minLength = 1.0f; // 10 feet
			triggerDown = false;
		}

		void Retract(float p_elapsedTimeMSf)
		{
			if (attached == true)
			{
				maxLength -= retractPerMS * p_elapsedTimeMSf;
				if (maxLength < minLength)
					maxLength = minLength;
			}
		}

		// tether is firing
		void StartShooter(Vector3d &p_startPosition, Vector3d &p_velocity)
		{
			attached = false;
			active = true;
			startPosition = p_startPosition;
			endPosition = p_startPosition;
			velocityPerMS = p_velocity;
			triggerDown = true;
		}

		// tether just struck an object and is sticking
		void AttachShooter(Vector3d &p_Position)
		{
			attached = true;
			active = true;
			endPosition = p_Position;
			maxLength = (endPosition - startPosition).Magnitude();
		}

		// tether is released
		void RemoveShooter()
		{
			active = false;
		}

		void ClearTriggerDown()
		{
			triggerDown = false;
		}

		bool IsActive()
		{
			return active;
		}

		bool IsAttached()
		{
			return (active && attached);
		}

	};

	class TetherShooterOwnerData
	{
	public:
		Orient3d orient;
		Vector3d velocityPerMS;
		TetherShooterData shooterData;
		bool onGround;
		Vector3d priorPosition;

		// controls
		bool left;
		bool right;
		bool forward;
		bool back;
		bool jumpTriggered;
		bool run;
		bool jumpReleased; // to prevent rapis fire jumping

		void ClearControls()
		{
			left = false;
			right = false;
			forward = false;
			back = false;
			jumpTriggered = false;
			run = false;
		}

		void ClearJumpControl()
		{
			jumpReleased = true;
		}

		TetherShooterOwnerData()
		{
			ClearJumpControl();
			ClearControls();

			onGround = true; // later, let the collision engine make this decision (initialize to false)
		}
	};

	public ref class TestTetherSwing : public GameBase
	{
	public:

		LinkedList<TetherSwingStructure> *structures;

		Model3d *cube;
		Model3d *rectangleShort;
		Model3d *rectangleTall;
		Model3d *plane;
		Model3d *shooter;

		TetherShooterOwnerData *playerData;
		float playerSpinAngleDegrees;
		float playerPitchAngleDegrees;

		GameTimer *timer;

		float timeFactor;

		int stereoScopicMode;

		TestTetherSwing(HWND p_hWnd) : GameBase(p_hWnd)
		{
			structures = nullptr;

			cube = nullptr;
			rectangleShort = nullptr;
			rectangleTall = nullptr;
			plane = nullptr;
			shooter = nullptr;

			playerData = nullptr;

			timer = nullptr;
			timeFactor = 1.0f;

			stereoScopicMode = 0;
		}

		virtual ~TestTetherSwing()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();
			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->TextureRegistry.RegisterTexture("GreenTerrain", GameTextureInternalFormatEnum::RGB, GameTextureFileComponentUsageEnum::RGB, GameContext::Instance->FileRegistry.RegisterFileResource("Grass_Meadows2.jpg"));
			GameContext::Instance->TextureRegistry.RegisterTexture("TileSmoke", GameTextureInternalFormatEnum::Alpha, GameTextureFileComponentUsageEnum::Red, GameContext::Instance->FileRegistry.RegisterFileResource("TileSmokeTexture.png"));

			playerData = new TetherShooterOwnerData();
			playerData->shooterData.ownerRef = &(playerData->orient);
			playerSpinAngleDegrees = 0.0f;
			playerPitchAngleDegrees = 0.0f;

			// set up the player's position
			playerData->orient.LoadIdentity();
			playerData->orient.p.Set(0, 0.0f, 0);   // model collider as a 1 foot sphere at feet and at head 0.5 up, camera will be at 0.55
			playerData->velocityPerMS.Set(0, 0, 0);

			// place some structures
			structures = new LinkedList<TetherSwingStructure>();

			// set up models
			cube = new Model3d();
			cube->MakeCube();
			rectangleShort = new Model3d();
			rectangleShort->MakeCube();
			rectangleTall = new Model3d();
			rectangleTall->MakeCube();

			plane = new Model3d();
			plane->Initialize(1, 4, 1);
			plane->GetColor(0)->Set(255, 255, 255);
			plane->GetVertex(0)->vertex.Set(100, 0, 100);
			plane->GetVertex(1)->vertex.Set(-100, 0, 100);
			plane->GetVertex(2)->vertex.Set(-100, 0, -100);
			plane->GetVertex(3)->vertex.Set(100, 0, -100);
			plane->GetSurface(0)->Initialize(4, true);
			plane->GetSurface(0)->SetVertexIndex(0, 0);
			plane->GetSurface(0)->SetVertexIndex(1, 1);
			plane->GetSurface(0)->SetVertexIndex(2, 2);
			plane->GetSurface(0)->SetVertexIndex(3, 3);
			plane->GetSurface(0)->SetTexture0(GameContext::Instance->TextureRegistry.GetTexture("GreenTerrain"));
			plane->GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
			plane->GetSurface(0)->SetVertexTexCoords(1, 40.0f, 0.0f);
			plane->GetSurface(0)->SetVertexTexCoords(2, 40.0f, 40.0f);
			plane->GetSurface(0)->SetVertexTexCoords(3, 0.0f, 40.0f);
			plane->CalculateNormals();

			// make shooter - will be rendered with scaling
			shooter = new Model3d();
			shooter->MakeCube();
			shooter->GetColor(0)->Set(255, 255, 255, 192);
			for (int i = 0; i < 8; i++)
				shooter->GetVertex(i)->colorIndex = 0;
			// start backside at origin
			shooter->GetVertex(4)->vertex.z = 0.0f;
			shooter->GetVertex(5)->vertex.z = 0.0f;
			shooter->GetVertex(6)->vertex.z = 0.0f;
			shooter->GetVertex(7)->vertex.z = 0.0f;
			shooter->SkinTexture0(GameContext::Instance->TextureRegistry.GetTexture("TileSmoke"));
			for (int i = 0; i < 6; i++)
			{
				switch (i)
				{
				case 0:
					shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, 1.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, 1.0f);
					break;
				case 1:
					shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, 1.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, 1.0f);
					break;
				case 2:
					shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, 1.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, 1.0f);
					break;
				case 3:
					shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, 1.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, 1.0f);
					break;
				case 4:
					shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, 1.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, 1.0f);
					break;
				case 5:
					shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, 0.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, 1.0f);
					shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, 1.0f);
					break;
				}
			}

			timer = new GameTimer();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (playerData != nullptr)
			{
				delete playerData;
				playerData = nullptr;
			}
			if (structures != nullptr)
			{
				delete structures;
				structures = nullptr;
			}
			if (cube != nullptr)
			{
				delete cube;
				cube = nullptr;
			}
			if (rectangleShort != nullptr)
			{
				delete rectangleShort;
				rectangleShort = nullptr;
			}
			if (rectangleTall != nullptr)
			{
				delete rectangleTall;
				rectangleTall = nullptr;
			}
			if (plane != nullptr)
			{
				delete plane;
				plane = nullptr;
			}
			if (shooter != nullptr)
			{
				delete shooter;
				shooter = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			timer->Poll();

			if (keyboardKeys.GetKey(27)->IsPressed()) // Esc exits game app
			{
				if (mouse.IsVisible() == false)
					mouse.Show();
				return false;
			}

			// apply mouse moves based on last collected movement, use shooter
			if (mouse.IsVisible() == false)
			{
				if (mouse.rightButton.down)
				{
					if (playerData->shooterData.IsAttached() == false)
					{
						playerData->shooterData.Retract(timer->GetElapsedTimeMSFloat());
					}
				}
				if (mouse.leftButton.down)
				{
					if (playerData->shooterData.IsActive() == false && playerData->shooterData.triggerDown == false)
					{
						playerData->shooterData.StartShooter(playerData->orient.p + Vector3d(0.0f, 0.45f, 0.0f), playerData->orient.f.ScalarMult(10.0f / 1000.0f + (playerData->velocityPerMS * playerData->orient.f))); // 1 foot below camera, 100 ft / second + velocity in direction of f
					}
				}
				else
				{
					if (playerData->shooterData.IsActive() == true)
					{
						playerData->shooterData.RemoveShooter();
					}
					playerData->shooterData.ClearTriggerDown();
				}

				float mouseSensitivity = 0.4f;
				playerSpinAngleDegrees += float(mouse.offsetX) * mouseSensitivity;
				while (playerSpinAngleDegrees >= 360.0f)
					playerSpinAngleDegrees -= 360.0f;
				while (playerSpinAngleDegrees < 0.0f)
					playerSpinAngleDegrees += 360.0f;
				playerPitchAngleDegrees -= float(mouse.offsetY) * mouseSensitivity;
				if (playerPitchAngleDegrees > 90.0f)
					playerPitchAngleDegrees = 90.0f;
				if (playerPitchAngleDegrees < -90.0f)
					playerPitchAngleDegrees = -90.0f;

				Vector3d oldP = playerData->orient.p;
				playerData->orient.LoadIdentity();
				playerData->orient.Rotate(playerData->orient.u, playerSpinAngleDegrees);
				playerData->orient.Rotate(playerData->orient.l, playerPitchAngleDegrees);
				playerData->orient.p = oldP;
			}

			////////////////
			// keyboard
			if (keyboardKeys.GetKey(186)->IsClicked() == true) // semicolon = hide mouse and control player
			{
				if (mouse.IsVisible() == false)
					mouse.Show(); // handle player movements next tick - could handle this before, doesn't really matter
				else
					mouse.Hide();
			}
			if (keyboardKeys.GetKey('V')->IsClicked() == true) // vsync on/off
			{
				GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
				graphics->SetVSyncEnabled(!graphics->VSyncIsEnabled());
			}
			if (keyboardKeys.GetKey(13)->IsClicked() == true) // stereoscopic mode
			{
				stereoScopicMode++;
				if (stereoScopicMode > 2)
					stereoScopicMode = 0;
			}
			if (keyboardKeys.GetKey(192)->IsClicked() == true) // ~ tilde
			{
				if (timeFactor == 1.0f)
					timeFactor = 0.1f;
				else if (timeFactor == 0.1f)
					timeFactor = 1.0f;
			}

			// player stuff
			playerData->ClearControls();
			if (keyboardKeys.GetKey('W')->IsPressed() == true)
			{
				playerData->forward = true;
			}
			if (keyboardKeys.GetKey('S')->IsPressed() == true)
			{
				playerData->back = true;
			}
			if (keyboardKeys.GetKey('A')->IsPressed() == true)
			{
				playerData->left = true;
			}
			if (keyboardKeys.GetKey('D')->IsPressed() == true)
			{
				playerData->right = true;
			}
			if (keyboardKeys.GetKey(32)->IsPressed() == true) // don't do clicked or rapid fire click will clear the control!
			{
				if (playerData->jumpReleased == true && playerData->onGround == true)
				{
					playerData->jumpTriggered = true;
					playerData->jumpReleased = false;
				}
			}
			else 
			{
				if (playerData->onGround == true)
					playerData->ClearJumpControl();
			}
			if (keyboardKeys.GetKey(16)->IsPressed() == true)
			{
				playerData->run = true;
			}

			//////////////////

			mouse.ZeroOffsets();
			keyboardKeys.ClearClicked();

			//////////////////
			// maintenance
			if (mouse.IsVisible() == false && appActivated == true)
			{
				// move it to the middle of the viewport (should be screen position)
				GameViewport ^viewport = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main");
				mouse.SetScreenPosition(viewport->GetScreenLocation().X + viewport->GetWidth() / 2, viewport->GetScreenLocation().Y + viewport->GetHeight() / 2);
			}

			//////////

			// animate!
			float timeToConsumeMSf = timer->GetElapsedTimeMSFloat() * timeFactor;
			float timeToApplyMS = 16.0f;
			while (timeToConsumeMSf > 0.0f)
			{
				if (timeToConsumeMSf <= timeToApplyMS)
				{
					Animate(timeToConsumeMSf);
					timeToConsumeMSf = 0.0f;
				}
				else
				{
					Animate(timeToApplyMS);
					timeToConsumeMSf -= timeToApplyMS;
				}
			}

			timer->ResetElapsedTime();

			return true;
		}

		void Animate(float p_elapsedTimeMSf)
		{
			// affect player position with velocity and gravity
			AnimatePlayer(p_elapsedTimeMSf);

			// animate shooter and keep attached to player
			AnimateShooter(p_elapsedTimeMSf);

			// correct length of attached tether, affect player velocity (simple reassignment + addition of velocity from tether retraction)
			// ?? if retracting, affect velocity of player based on amount of correction that happened only by retraction (can add to velocity) - record vector of retraction and add to velocity along that line only
			// ??
		}

		void AnimatePlayer(float p_elapsedTimeMSf)
		{
			// determine player velocity

			// correct opposite facing controls
			if (playerData->left == true && playerData->right == true)
			{
				playerData->left = false;
				playerData->right = false;
			}
			if (playerData->forward == true && playerData->back == true)
			{
				playerData->forward = false;
				playerData->back = false;
			}

			// set to zero here.  keep for control loop so that fired shooter has a velocity to work with
			if (playerData->onGround == true)
			{
				playerData->velocityPerMS = Vector3d(0, 0, 0);
			}

			bool moving = false;
			if (playerData->onGround == true)
			{
				// remove all lateral movement
				playerData->velocityPerMS.x = 0.0f;
				playerData->velocityPerMS.z = 0.0f;

				float moveSpeed = 3.0f / 1000.0f; // 20 mph, still pretty much a run
				float runFactor = 2.0f; // 40 feet per second (superhuman)
				Vector3d forwardVector = playerData->orient.f;
				forwardVector.y = 0.0f;
				if (forwardVector.Normalize() == false)
					forwardVector.Set(-playerData->orient.l.z, 0.0f, playerData->orient.l.x);
				Vector3d moveVector = Vector3d(0, 0, 0);
				if (playerData->left == true)
				{
					moveVector = moveVector + playerData->orient.l;
					moving = true;
				}
				if (playerData->right == true)
				{
					moveVector = moveVector - playerData->orient.l;
					moving = true;
				}
				if (playerData->forward == true)
				{
					moveVector = moveVector + forwardVector;
					moving = true;
				}
				if (playerData->back == true)
				{
					moveVector = moveVector - forwardVector;
					moving = true;
				}
				if (moving == true)
				{
					// prevent diagonal slide cheat
					moveVector.Normalize();
					if (playerData->run == true)
						moveVector = moveVector.ScalarMult(runFactor);
					playerData->velocityPerMS = playerData->velocityPerMS + moveVector.ScalarMult(moveSpeed);
				}
			}

			if (playerData->jumpTriggered == true)
			{
				float jumpFactor = 1.0f;
				if (playerData->run == true && moving == true)
					jumpFactor = 1.2f;
				playerData->velocityPerMS = playerData->velocityPerMS + Vector3d(0.0f, 2.5298f, 0.0f).ScalarMult(1.0f / 1000.0f * jumpFactor); // 35.298 ft per second = jump 10 feet in the air.
				playerData->jumpTriggered = false;
			}

			// now animate according to velocity and acceleration
			playerData->priorPosition = playerData->orient.p;
			Vector3d gravity = Vector3d(0.0f, -32.0f / 10.0f / 1000.0f / 1000.0f, 0.0f); // -32 ft/s^2
			//Vector3d gravity = Vector3d(0.0f, 0.0f, 0.0f);
			playerData->orient.p = playerData->orient.p + playerData->velocityPerMS.ScalarMult(p_elapsedTimeMSf) + gravity.ScalarMult(0.5f * p_elapsedTimeMSf * p_elapsedTimeMSf);
			playerData->velocityPerMS = playerData->velocityPerMS + gravity.ScalarMult(p_elapsedTimeMSf);

			// todo: decide later when to set onGround = false - basically if velocity.y is negative.  If on upward velocity and strike surface with a 45.0 degree slope or less, cut out the y, x and z velocities, otherwise just correct for the normal collision.
			// watch out for travelling parallel to a surface and continually colliding with it because of floating point truncation
			if (playerData->orient.p.y < 0.0f && playerData->velocityPerMS.y < 0.0f)
			{
				playerData->velocityPerMS.y = 0.0f;
				playerData->orient.p.y = 0.0f;
				playerData->onGround = true;
			}
			if (playerData->velocityPerMS.y > 0.0f)
			{
				playerData->onGround = false;
			}
		}

		void AnimateShooter(float p_elapsedTimeMSf)
		{
			// advance shooter, check for attachment
			if (playerData->shooterData.IsActive() == true && playerData->shooterData.IsAttached() == false)
			{
				// advance shooter
				playerData->shooterData.priorEndPosition = playerData->shooterData.endPosition;
				playerData->shooterData.endPosition = playerData->shooterData.endPosition + playerData->shooterData.velocityPerMS.ScalarMult(p_elapsedTimeMSf);

				// if shooter is longer than it should be, correct it
				bool tooLong = false;
				Vector3d offset = playerData->shooterData.endPosition - playerData->shooterData.startPosition;
				float length = offset.Magnitude();
				float maxLength = 20.0f;
				if (length > maxLength)
				{
					playerData->shooterData.endPosition = playerData->shooterData.startPosition + offset.ScalarMult(length / maxLength);
					tooLong = true;
				}

				// check for collisions
				// ??
				if (playerData->shooterData.endPosition.y > 5.0f)
				{
					// set attachment position, maxLength
					playerData->shooterData.endPosition.y = 5.0f;
					playerData->shooterData.attached = true;
					playerData->shooterData.maxLength = (playerData->shooterData.endPosition - playerData->shooterData.startPosition).Magnitude();
				}

				// if still not stuck but was too long, remove it, leave trigger up so that repeat fire doesn't happen
				if (playerData->shooterData.IsAttached() == false && tooLong == true)
				{
					playerData->shooterData.RemoveShooter();
				}
			}

			// keep shooter start position moving with player, even if attached
			if (playerData->shooterData.IsActive() == true)
			{
				playerData->shooterData.startPosition = playerData->orient.p + Vector3d(0, 0.55f, 0) - playerData->orient.u.ScalarMult(0.05f) - playerData->orient.l.ScalarMult(0.1f); // 6 inches below camera, for now. and 1 foot to the right
				// todo: this rotation may force a slight length correction because of the rotation only (track old one from last tick?), and could result in a velocity adjsutment if coded that way.
				if (playerData->shooterData.IsActive() == true && playerData->shooterData.IsAttached() == false)
				{
					// establish maxLength if still shooting so that it renders thin
					playerData->shooterData.maxLength = (playerData->shooterData.endPosition - playerData->shooterData.startPosition).Magnitude();
				}
			}
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(128, 128, 128));

			double nearPlane = 0.01f;
			double farPlane = 1000.0f;

			Orient3d viewpoint;
			viewpoint = playerData->orient;
			viewpoint.p = viewpoint.p + Vector3d(0.0f, 0.55f, 0.0f); // camera is 5 feet up

			// set up shooter model now so that it isn't calcualted more than once per game tick
			if (playerData->shooterData.IsActive() == true)
			{
				// 0 and 3 and front abd back facing, so don't fix those
				// todo: reskin texture for sides 1, 2, 4, 5 (need to figure out which ones...)
			}

			// render scene based on stereoscopic mode
			if (stereoScopicMode == 0)
			{
				graphics->SetPerspectiveProjection(45.0f, nearPlane, farPlane);
				graphics->DefaultTransform();

				DrawElements(graphics, viewpoint, nullptr, false);
			}
			else if (stereoScopicMode == 1)
			{
				StereoscopicCamera stereoCamera(0.2f, 0.031f); // converge at 2 feet, 3.72" eye separation for enjoyable depth

				graphics->SetPerspectiveProjectionStereoscopicLeft(45.0f, nearPlane, farPlane, stereoCamera);
				graphics->DefaultTransformStereoscopicLeft(stereoCamera);
				graphics->ColorMask(true, false, false, true);
				DrawElements(graphics, viewpoint, &stereoCamera, true);
				graphics->FinishRender();

				graphics->ClearDepth();

				graphics->SetPerspectiveProjectionStereoscopicRight(45.0f, nearPlane, farPlane, stereoCamera);
				graphics->DefaultTransformStereoscopicRight(stereoCamera);
				graphics->ColorMask(false, true, true, true);
				DrawElements(graphics, viewpoint, &stereoCamera, false);

				graphics->ColorMask(true, true, true, true);
			}
			else if (stereoScopicMode == 2)
			{
				StereoscopicCamera stereoCamera(4.0f / 1334.0f,
					-0.225f, // (60)
					0.0f, 2.75f / 12.0f / 10.0f); // 4" iphone google cardboard

				graphics->SetPerspectiveProjectionStereoscopicLeft(77.8f, nearPlane, farPlane, stereoCamera);
				graphics->DefaultTransformStereoscopicLeft(stereoCamera);
				DrawElements(graphics, viewpoint, &stereoCamera, true);
				graphics->FinishRender();

				graphics->SetPerspectiveProjectionStereoscopicRight(77.8f, nearPlane, farPlane, stereoCamera);
				graphics->DefaultTransformStereoscopicRight(stereoCamera);
				DrawElements(graphics, viewpoint, &stereoCamera, false);

				// restore
				graphics->SetViewportSize(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth(),
					GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());

				// Render division
				graphics->Set2dWindowProjection();
				ModelVertex quad[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
				GameColor white(255, 255, 255);
				float width = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth());
				float height = float(GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetHeight());
				float centerX = width / 2.0f;
				float centerY = width / 2.0f;
				quad[0].vertex.Set(centerX - width * stereoCamera.divisionWidth / 2.0f, 0, 0);
				quad[1].vertex.Set(centerX + width * stereoCamera.divisionWidth / 2.0f, 0, 0);
				quad[2].vertex.Set(centerX + width * stereoCamera.divisionWidth / 2.0f, height, 0);
				quad[3].vertex.Set(centerX - width * stereoCamera.divisionWidth / 2.0f, height, 0);
				graphics->RenderFilledQuad(&white, 1, quad, 4);
			}

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

		void DrawElements(GraphicsBase *p_graphics, Orient3d &p_viewpoint, StereoscopicCamera *p_camera, bool p_left)
		{
			p_graphics->ReverseTransform(p_viewpoint);

			// render structures
			LinkedListEnumerator<TetherSwingStructure> tetherStructureEnumerator = LinkedListEnumerator<TetherSwingStructure>(*structures);
			while (tetherStructureEnumerator.MoveNext())
			{
				p_graphics->PushMatrix();
				p_graphics->Transform(tetherStructureEnumerator.Current()->data.orient);
				p_graphics->Scale(tetherStructureEnumerator.Current()->data.scale, tetherStructureEnumerator.Current()->data.scale, tetherStructureEnumerator.Current()->data.scale);
				tetherStructureEnumerator.Current()->data.modelRef->Render(*p_graphics);
				p_graphics->PopMatrix();
			}

			// render terrain
			plane->Render(*p_graphics);

			////////////////
			// alpha objects

			// render tether
			if (playerData->shooterData.IsActive() == true)
			{
				// point from start to end position
				Vector3d offset = playerData->shooterData.endPosition - playerData->shooterData.startPosition;
				float length = offset.Magnitude();
				if (offset.Normalize() == true) // don't render if length zero
				{
					// normally shooter is 0.005 radius, but if its actual length < maxLength, reshape it
					float xScale = 0.005f;
					float yScale = 0.005f;
					float zScale = length;
					float volume = (xScale * 2.0f) * (yScale * 2.0f) * zScale;
					if (length < playerData->shooterData.maxLength)
					{
						float factor = sqrt(playerData->shooterData.maxLength / length);
						xScale *= factor;
						yScale *= factor;
					}

					// build orient and render it!
					Orient3d shooterOrient;
					shooterOrient.LoadIdentity();
					shooterOrient.f = offset;
					shooterOrient.l.Set(offset.z, 0.0f, -offset.x);
					if (shooterOrient.l.Normalize() == false)
					{
						shooterOrient.l.Set(1.0f, 0.0f, 0.0f);
					}
					shooterOrient.u = shooterOrient.f.CrossProd(shooterOrient.l);
					shooterOrient.p = playerData->shooterData.startPosition;

					// set up texture coordinates so taht shooter looks correct
					float conversion = 0.25f; // 40 feet per texture repeat
					float farT = 1.0f;
					float nearT = farT - playerData->shooterData.maxLength * conversion;
					for (int i = 0; i < 6; i++)
					{
						switch (i)
						{
						case 0:
							break;
						case 1:
							shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, farT);
							shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, farT);
							shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, nearT);
							shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, nearT);
							break;
						case 2:
							shooter->GetSurface(i)->SetVertexTexCoords(0, 1.0f, farT);
							shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, nearT);
							shooter->GetSurface(i)->SetVertexTexCoords(2, 0.0f, nearT);
							shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, farT);
							break;
						case 3:
							break;
						case 4:
							shooter->GetSurface(i)->SetVertexTexCoords(0, 1.0f, farT);
							shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, nearT);
							shooter->GetSurface(i)->SetVertexTexCoords(2, 0.0f, nearT);
							shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, farT);
							break;
						case 5:
							shooter->GetSurface(i)->SetVertexTexCoords(0, 0.0f, farT);
							shooter->GetSurface(i)->SetVertexTexCoords(1, 1.0f, farT);
							shooter->GetSurface(i)->SetVertexTexCoords(2, 1.0f, nearT);
							shooter->GetSurface(i)->SetVertexTexCoords(3, 0.0f, nearT);
							break;
						}
					}

					p_graphics->PushMatrix();
					p_graphics->Transform(shooterOrient);
					p_graphics->Scale(xScale, yScale, zScale);
					shooter->Render(*p_graphics);
					p_graphics->PopMatrix();
				}
			}
		}

	};

	class TestUITestForm1 : public GameUIForm
	{
		GameUIButton *button1;
		GameUIControl *control2;
		GameUILabel *label3;
		GameUITextBox *textBox4;
		GameUILabel *label5;
		GameUIButton *button6;

		bool moveForm;
		Point mousePosition;
		Point originalMousePosition;

	public:
		TestUITestForm1()
		{
			moveForm = false;

			SetPosition(RectangleF(10, 80, 200, 300));
			SetBackColor(GameColor(64, 64, 64, 192));

			SetMouseLeft((GameUIMouseLeft)&TestUITestForm1::Form1_MouseLeft);
			SetMouseEntered((GameUIMouseEntered)&TestUITestForm1::Form1_MouseEntered);
			SetMouseMove((GameUIMouseMove)&TestUITestForm1::Form1_MouseMove);
			SetMouseDown((GameUIMouseDown)&TestUITestForm1::Form1_MouseDown);
			SetMouseUp((GameUIMouseUp)&TestUITestForm1::Form1_MouseUp);

			button1 = (GameUIButton *)AddControl(new GameUIButton(RectangleF(10, 10, 100, 40)));
			button1->SetText("Click me!");
			button1->SetFont(GameContext::Instance->FontRegistry.GetFont("Info"));
			button1->SetMouseLeft((GameUIMouseLeft)&TestUITestForm1::Button1_MouseLeft);
			button1->SetMouseEntered((GameUIMouseEntered)&TestUITestForm1::Button1_MouseEntered);
			button1->SetClick((GameUIClick)&TestUITestForm1::Button1_Clicked);
			button1->SetMouseMove((GameUIMouseMove)&TestUITestForm1::Button1_MouseMove);

			control2 = AddControl(new GameUIControl(RectangleF(-10, 50, 30, 10)));
			control2->SetMouseLeft((GameUIMouseLeft)&TestUITestForm1::Control2_MouseLeft);
			control2->SetMouseEntered((GameUIMouseEntered)&TestUITestForm1::Control2_MouseEntered);

			label3 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, 70, 70, 10)));
			label3->SetText("Test Label");
			label3->SetFont(GameContext::Instance->FontRegistry.GetFont("InfoBold"));
			label3->SetForeColor(GameColor(255, 255, 0));

			textBox4 = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(10, 90, 150, 20)));
			textBox4->SetText("Texting Field");
			//textBox4->SetText("WWWWWWWWWWWW");
			textBox4->SetFont(GameContext::Instance->FontRegistry.GetFont("Info"));
			textBox4->SetForeColor(GameColor(0, 0, 0));
			textBox4->SetBackColor(GameColor(255, 255, 255));
			textBox4->SetBorderColor(GameColor(128, 128, 128));
			textBox4->SetSelectionStart(4);
			textBox4->SetSelectionLength(3);
			textBox4->SetOnFocus((GameUIOnFocus)&TestUITestForm1::TextBox4_OnFocus);
			textBox4->SetOnBlur((GameUIOnBlur)&TestUITestForm1::TextBox4_OnBlur);
			textBox4->SetMouseDown((GameUIMouseDown)&TestUITestForm1::TextBox4_MouseDown);
			textBox4->SetMouseUp((GameUIMouseUp)&TestUITestForm1::TextBox4_MouseUp);
			textBox4->SetKeyDown((GameUIKeyDown)&TestUITestForm1::TextBox4_KeyDown);

			label5 = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, 115, 120, 10)));
			label5->SetText("");
			label5->SetFont(GameContext::Instance->FontRegistry.GetFont("Info"));
			label5->SetForeColor(GameColor(255, 255, 255));

			button6 = (GameUIButton *)AddControl(new GameUIButton(RectangleF(10, 130, 100, 40)));
			button6->SetText("Focus Test");
			button6->SetFont(GameContext::Instance->FontRegistry.GetFont("Info"));
			button6->SetMouseDown((GameUIMouseDown)&TestUITestForm1::Button6_MouseDown);
		}

	private:
		void Form1_MouseEntered()
		{
			SetBackColor(GameColor(255, 255, 255, 192));
		}

		void Form1_MouseLeft()
		{
			SetBackColor(GameColor(64, 64, 64, 192));
		}

		void Form1_MouseMove(MouseMoveArgs &p_moveArgs)
		{
			mousePosition = Point(p_moveArgs.form.X, p_moveArgs.form.Y); // form or scene, doesn't matter, result is the same since originalMousePosition is the same domain
			label5->SetText(String::Format("{0}, {1}", p_moveArgs.form.X, p_moveArgs.form.Y));
			if (moveForm == true)
			{
				RectangleF rect = GetRect();
				SetLocation(PointF(rect.Left + float(mousePosition.X - originalMousePosition.X),
					rect.Top + float(mousePosition.Y - originalMousePosition.Y)));
			}
		}

		void Form1_MouseDown(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				moveForm = true;
				originalMousePosition = mousePosition;
			}
		}

		void Form1_MouseUp(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				moveForm = false;
			}
		}

		void Button1_MouseEntered()
		{
			button1->SetForeColor(GameColor(0, 255, 0));
		}

		void Button1_MouseLeft()
		{
			button1->SetForeColor(GameColor(255, 255, 255));
		}

		void Control2_MouseEntered()
		{
			control2->SetBackColor(GameColor(0, 0, 255));
		}

		void Control2_MouseLeft()
		{
			control2->SetBackColor(GameColor(64, 64, 64));
		}

		void Button1_Clicked()
		{
			SetBackColor(GameColor(255, 0, 0, 192));
		}

		void TextBox4_OnFocus()
		{
			textBox4->SetForeColor(GameColor(255, 0, 255));
		}

		void TextBox4_MouseDown(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
				textBox4->SetBackColor(GameColor(0, 255, 0));
		}

		void TextBox4_OnBlur()
		{
			textBox4->SetForeColor(GameColor(0, 0, 0));
		}

		void TextBox4_MouseUp(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
				textBox4->SetBackColor(GameColor(255, 255, 255));
		}

		void TextBox4_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::M)
				GameContext::Instance->GetUI()->MessageBox("Hitting M pops this up - SPACE makes it go away, text field should be active again, SPACE should NOT apply in text field");
		}

		void Button1_MouseMove(MouseMoveArgs &p_moveArgs)
		{
			label5->SetText(String::Format("{0}, {1}", p_moveArgs.control.X, p_moveArgs.control.Y));
		}

		void Button6_MouseDown(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
				textBox4->Focus();
		}

	};

	class TestUITestForm2 : public GameUIForm
	{
	public:
		GameUIButton *button1;
		GameUIForm *form1Ref;

		bool moveForm;
		Point mousePosition;
		Point originalMousePosition;

		TestUITestForm2()
		{
			moveForm = false;

			SetPosition(RectangleF(100, 100, 200, 300));

			SetBackColor(GameColor(64, 64, 64, 192));

			SetMouseMove((GameUIMouseMove)&TestUITestForm2::Form2_MouseMove);
			SetMouseDown((GameUIMouseDown)&TestUITestForm2::Form2_MouseDown);
			SetMouseUp((GameUIMouseUp)&TestUITestForm2::Form2_MouseUp);

			button1 = (GameUIButton *)AddControl(new GameUIButton(RectangleF(10, 10, 180, 40)));
			button1->SetText("Bring other form to front");
			button1->SetFont(GameContext::Instance->FontRegistry.GetFont("Info"));
			button1->SetClick((GameUIClick)&TestUITestForm2::Button1_Clicked);

			button1 = (GameUIButton *)AddControl(new GameUIButton(RectangleF(10, 60, 180, 40)));
			button1->SetText("Message Box");
			button1->SetFont(GameContext::Instance->FontRegistry.GetFont("Info"));
			button1->SetClick((GameUIClick)&TestUITestForm2::Button2_Clicked);
		}

		void Button1_Clicked()
		{
			form1Ref->Show();
		}

		void Button2_Clicked()
		{
			GameContext::Instance->GetUI()->MessageBox("Test message box!  This is an extra long sentence to illustrate the automatic word wrapping and the capacity for the message box to display a lot of text data in a constrained space.  Woo woo.");
		}

		void Form2_MouseMove(MouseMoveArgs &p_moveArgs)
		{
			mousePosition = Point(p_moveArgs.form.X, p_moveArgs.form.Y); // form or scene, doesn't matter, result is the same since originalMousePosition is the same domain
			if (moveForm == true)
			{
				RectangleF rect = GetRect();
				SetLocation(PointF(rect.Left + float(mousePosition.X - originalMousePosition.X),
					rect.Top + float(mousePosition.Y - originalMousePosition.Y)));
			}
		}

		void Form2_MouseDown(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				moveForm = true;
				originalMousePosition = mousePosition;
			}
		}

		void Form2_MouseUp(MouseButton p_button)
		{
			if (p_button == MouseButton::Left)
			{
				moveForm = false;
			}
		}
	};

	class TestUIGameData
	{
	public:
		bool uiFormActive;
		Model3d jet;
		Orient3d jetOrient;
		Orient3d cameraOrient;
		gcroot<GameMouse^> mouse; // accumulated mouse results piped to game

		TestUIGameData()
		{
			uiFormActive = false;
			mouse = gcnew GameMouse();
		}

		~TestUIGameData()
		{
			if (static_cast<GameMouse^>(mouse) != nullptr)
			{
				delete mouse;
				mouse = nullptr;
			}
		}
	};

	class TestUIGameUI : public GameUI
	{
	public:
		TestUIGameData *gameDataRef;

		TestUIGameUI(TestUIGameData *p_gameData, GameViewport ^p_viewport, GameFont ^p_defaultFont, GameColor &p_defaultForeColor) : GameUI(p_viewport, p_defaultFont, p_defaultForeColor)
		{
			gameDataRef = p_gameData;
			SetPostMouseDown((GameUIMouseDown)&TestUIGameUI::UI_PostMouseDown);
		}

		~TestUIGameUI()
		{

		}

		void UI_PostMouseDown(GameInputEvent &p_event)
		{
			if (p_event.mouseButton == MouseButton::Left)
			{
				if (currentFocusForm == nullptr)
				{
					gameDataRef->uiFormActive = false;
					p_event.handled = true; // block passage to UI, allow message to be processed at game level (for now, the accumulate game states are good enough)
				}
				else
					gameDataRef->uiFormActive = true;
			}
		}
	};

	public ref class TestUI : public GameBase
	{
	public:
		TestUITestForm1 *form1;
		TestUITestForm2 *form2;
		TestUIGameData *gameData;
		TestUIGameUI *gameUI;

		TestUI(HWND p_hWnd) : GameBase(p_hWnd)
		{
			form1 = nullptr;
			form2 = nullptr;
			gameData = nullptr;
			gameUI = nullptr;
		}

		virtual ~TestUI()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			//GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			//GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 10));
			GameContext::Instance->FontRegistry.RegisterFont("InfoBold", gcnew System::Drawing::Font("Verdana", 10, FontStyle::Bold));

			gameData = new TestUIGameData();
			gameData->jet.MakeJet();
			gameData->jetOrient.LoadIdentity();
			gameData->cameraOrient.LoadIdentity();
			gameData->cameraOrient.p = gameData->cameraOrient.p - gameData->cameraOrient.f.ScalarMult(3.0f);
			// move the jet forward and over
			gameData->jetOrient.p = gameData->jetOrient.p + gameData->jetOrient.f.ScalarMult(7.0f) + gameData->jetOrient.l.ScalarMult(-2.5f) + gameData->jetOrient.u.ScalarMult(2.0f);
			gameData->jetOrient.Rotate(gameData->jetOrient.u, 180.0f);

			gameUI = new TestUIGameUI(gameData, GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), GameContext::Instance->FontRegistry.GetFont("Info"), GameColor(255,255,255));
			GameContext::Instance->SetUI(gameUI);

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (gameData != nullptr)
			{
				delete gameData;
				gameData = nullptr;
			}
			if (gameUI != nullptr)
			{
				delete gameUI;
				gameUI = nullptr;
			}
			if (form1 != nullptr)
			{
				delete form1;
				form1 = nullptr;
			}
			if (form2 != nullptr)
			{
				delete form2;
				form2 = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			// process accumulated events - we do this because when a UI is involved, it's just best to treat each event individually, otherwise during some pause such as during
			//   Sleep() or texture loads or connecting to an IP, typing 'dad' or mouse downing, moving, and mouse upping would only be collected by a latest state model as 'da' and a mouse move.
			// ui style: if mouse down on game scene, let game accept key and mouse commands.  if mouse down on a form, ui gets all inputs until mouse down on game scene again
			LinkedListEnumerator<GameInputEvent> eventEnumerator = inputEvents->GetEnumerator();
			while (eventEnumerator.MoveNext())
			{
				bool echoEvents = false;
				switch (eventEnumerator.Current()->data.type)
				{
					// let UI notify whether or not a form has been clicked
					// always let UI know the position of the mouse so that downclicks can occur on forms when ui isn't active
					// let upclick be tracked after scene is clicked from ui, too so that next downclick ont he ui can be tracked meaningfully later
					// a down on a control or form will activate the ui fully
				case GameInputEventType::MouseMove:
					gameUI->ApplyInputEvent(eventEnumerator.Current()->data);
					gameData->mouse->ApplyMouseEvent(eventEnumerator.Current()->data);
					break;
				case GameInputEventType::MouseDown:
					gameUI->ApplyInputEvent(eventEnumerator.Current()->data);
					gameData->mouse->ApplyMouseButton(eventEnumerator.Current()->data.mouseButton, true);
					break;
				case GameInputEventType::MouseUp:
					gameUI->ApplyInputEvent(eventEnumerator.Current()->data);
					gameData->mouse->ApplyMouseButton(eventEnumerator.Current()->data.mouseButton, false);
					break;
				case GameInputEventType::KeyDown:
				case GameInputEventType::KeyUp:
				//case GameInputEventType::KeyPress:
				case GameInputEventType::MouseWheel:
					if (gameData->uiFormActive == true)
						gameUI->ApplyInputEvent(eventEnumerator.Current()->data);
					break;
				}
			}

			if (keyboardKeys.GetKey(27)->IsPressed())
				return false;

			// game control handling when ui isn't active, usues accumulated states on keyboard and mouse rather than handling each event
			if (gameData->uiFormActive == false)
			{
				if (keyboardKeys.GetKey('F')->IsClicked())
				{
					if (form1 == nullptr)
					{
						form1 = new TestUITestForm1();
						form1->Show();
					}

					if (form2 == nullptr)
					{
						form2 = new TestUITestForm2();
						form2->form1Ref = form1;
						form2->Show();
					}
				}
				if (keyboardKeys.GetKey('H')->IsClicked())
				{
					if (form1 != nullptr)
					{
						if (form1->IsVisible() == true)
							form1->Hide();
						else
							form1->Show();
					}
				}
				if (keyboardKeys.GetKey('P')->IsClicked())
				{
					// attempt a series of mosue and keyboard events on the form controls, make sure they all happen
					Sleep(5000);
				}

				// rotate jet with mouse
				// apply mouse moves based on last collected movement
				if (gameData->mouse->rightButton.down)
				{
					// bank jet according to x offset (number of degrees), always on orient.f vector
					gameData->jetOrient.Rotate(gameData->jetOrient.f, float(gameData->mouse->offsetX) / 5.0f);
				}
				else if (gameData->mouse->leftButton.down)
				{
					// yaw jet according to x offset (number of degrees), always on 0,1,0 vector
					gameData->jetOrient.Rotate(Vector3d::Vector(0, 1, 0), -float(gameData->mouse->offsetX) / 5.0f);
					// pitch jet according to y offset (number of degrees), always on l vector
					gameData->jetOrient.Rotate(gameData->jetOrient.l, -float(gameData->mouse->offsetY) / 5.0f);
				}
			}

			// zero offsets on all mice regardless
			gameData->mouse->ZeroOffsets();
			mouse.ZeroOffsets();

			keyboardKeys.ClearClicked();

			return true;
		}

		void PerformRender() override
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->SetPerspectiveProjection(45.0f, 0.1, 1000.0);
			graphics->DefaultTransform();

			// render jet
			graphics->ReverseTransform(gameData->cameraOrient);
			graphics->PushMatrix();
			graphics->Transform(gameData->jetOrient);
			gameData->jet.Render(*graphics);
			graphics->PopMatrix();

			graphics->Set2dWindowProjection();
			int textHeight = GameContext::Instance->FontRegistry.GetFont("Info")->GetHeight();
			graphics->RenderFont("'F' to show forms, 'H' to hide and show first form, 'P' to force a game pause to test event capture",
				GameContext::Instance->FontRegistry.GetFont("Info"), 10, 10, GameColor(255, 255, 0));
			graphics->RenderFont("Key commands only work when game scene is active",
				GameContext::Instance->FontRegistry.GetFont("Info"), 10, 10 + textHeight, GameColor(255, 255, 0));
			graphics->RenderFont("Click left button on game scene to move jet with left mouse button (right mouse button currently does not activate UI)",
				GameContext::Instance->FontRegistry.GetFont("Info"), 10, 10 + textHeight * 2, GameColor(255, 255, 0));
			if (gameData->uiFormActive == true)
				graphics->RenderFont("UI Active",
					GameContext::Instance->FontRegistry.GetFont("Info"), 10, 10 + textHeight * 3, GameColor(255, 255, 0));
			else
				graphics->RenderFont("Game Scene Active",
					GameContext::Instance->FontRegistry.GetFont("Info"), 10, 10 + textHeight * 3, GameColor(255, 255, 0));

			// UI on top of everything
			gameUI->Render(graphics);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};

}
