#pragma once

#include "..\Headers\GameBase.h"
#include "..\Headers\LinkedListTemplate.h"
#include "..\Headers\GameObjectBase.h"
#include "..\Headers\Vector.h"
#include "..\Headers\Orient.h"
#include "..\Headers\GameApplicationContext.h"
#include "..\Headers\GameContext.h"
#include "..\Headers\Orient.h"
#include "..\Headers\Model.h"
#include "..\Headers\JointedModel.h"
#include "..\Headers\TerrainMesh.h"
#include "..\Headers\Skybox.h"
#include "..\Headers\MathConstants.h"
#include "..\Headers\GameWidgets.h"
#include "..\Headers\Collider.h"
#include "..\Headers\Frustum.h"
#include "..\Headers\PortalEngine.h"
#include "..\Headers\GraphicsUtilities.h"
#include "..\Headers\GameNetwork.h"
#include "..\Headers\GameUI.h"

#define VERSIONSTRING "0.1.008"
// guid format..... "12345678-1234-1234-1234-123456789012"
#define VERSIONGUID "fjs45477-d22u-411j-jg6s-489763h91s6a"

namespace GameEngDev {
	using namespace GameEng::Game;
	using namespace GameEng::GameObject;
	using namespace GameEng::Storage;
	using namespace GameEng::Math;
	using namespace GameEng::Tools::Timer;
	using namespace GameEng::Widgets;
	using namespace GameEng::Collider;
	using namespace GameEng::PortalEngine;
	using namespace GameEng::Network;
	using namespace GameEng::UI;

	using namespace System;

	class MessageString
	{
	public:
		gcroot<String ^> message;
	};

	class TestNetworkDownloadedData
	{
	public:
		int size;
		unsigned char *data;
		bool done;
		int bytesReceived;

		TestNetworkDownloadedData()
		{
			data = nullptr;
			size = 0;
			done = true;
			bytesReceived = 0;
		}

		~TestNetworkDownloadedData()
		{
			ClearData();
		}

		void AllocateData(int p_size)
		{
			if (data != nullptr)
				throw gcnew System::Exception(String::Format("Already allocated!Bytes received : {0}/{1}", bytesReceived, size));

			data = new unsigned char[p_size];
			size = p_size;
			done = false;
		}

		void ClearData()
		{
			if (data != nullptr)
			{
				delete[] data;
				data = nullptr;
			}
			size = 0;
			done = true;
			bytesReceived = 0;
		}

		void SaveData(unsigned char *p_data, int p_size)
		{
			if (done == true)
				throw gcnew System::Exception("Already done!");
			if (bytesReceived + p_size > size)
				throw gcnew System::Exception("Too much data!");

			CopyMemory(&data[bytesReceived], p_data, p_size);
			bytesReceived += p_size;
			if (bytesReceived == size)
				done = true;
		}

		String ^Output()
		{
			return String::Format("{0}/{1}", bytesReceived, size);
		}
	};

	class TestNetworkGameData
	{
	public:
		TestNetworkGameData()
		{
			clearData = false;

			for (int i = 0; i < 8; i++)
			{
				fastDataReceived[i] = 0;
				fastDataExpected[i] = 0;
			}
		}

		LinkedList<MessageString> messageStrings;

		LinkedListEnumerator<MessageString> GetMessageStringEnumerator()
		{
			return LinkedListEnumerator<MessageString>(messageStrings);
		}

		bool clearData; // did host command that data be cleared?
		int requestDataSize; // should small packets be requested?
		TestNetworkDownloadedData downloadedData[8]; // data downloaded from server

		int fastDataReceived[8];
		int fastDataExpected[8];

		bool ReadyToDownloadData()
		{
			for (int i = 0; i < 8; i++)
			{
				if (downloadedData[i].done == false)
					return false;
			}

			// all done, clear it all and return true
			ClearDownloadedData();

			return true;
		}

		void ClearDownloadedData()
		{
			for (int i = 0; i < 8; i++)
				downloadedData[i].ClearData();
		}
	};

	class TestNetworkPacketTypes
	{
	public:
		static const int DataHeader = 1; // Data describing data arriving on a channel
		static const int Data = 2; // large data download sent on a guaranteed channel
		static const int DataFooter = 3; // simple - Condifmration data done being sent
		static const int ClearData = 4; // simple - command from server to clear downloaded data 
		static const int ReadyForData = 5; // simple - client telling server it is ready for data
		static const int Sample = 6; // just a single packet sent
		static const int FastDataStart = 7; // data packet sent straight
		static const int FastData = 8; // data packet sent straight
	};

	// channel determines download destination
	struct TestNetworkDataHeaderPacket : NetworkPacketBase // sent guaranteed through a channel
	{
		int totalSize;
	};

	struct TestNetworkDataPacket : NetworkPacketBase  // sent guaranteed through a channel
	{
		// length 12+size
		int size;
		unsigned char data[8000];
	};

	struct TestNetworkClearDataPacket : NetworkPacketBase // sent guaranteed through a channel
	{
		int requestDataSize;
	};

	struct TestNetworkReadyForBulkDataPacket : NetworkPacketBase // sent guaranteed through a channel
	{
		int requestDataSize;
	};

	struct TestNetworkSamplePacket : NetworkPacketBase // sent guaranteed through a channel
	{
		int value; // just a random value
	};

	struct TestNetworkFastDataStartPacket : NetworkPacketBase // sent with straight Send
	{
		int expectedLength;
	};

	struct TestNetworkFastDataPacket : NetworkPacketBase // sent with straight Send
	{
		int dataLength;
		char data[8000];
	};

	class TestNetworkPacketHelper
	{
	public:
		static void PopulateDataHeaderPacket(TestNetworkDataHeaderPacket &dataHeaderPacket, int p_totalSize)
		{
			dataHeaderPacket.length = sizeof(TestNetworkDataHeaderPacket);
			dataHeaderPacket.type = TestNetworkPacketTypes::DataHeader;
			dataHeaderPacket.totalSize = p_totalSize; // size client should allocate
		}

		static void PopulateDataPacket(TestNetworkDataPacket &dataPacket, char *p_data, int p_size)
		{
			dataPacket.type = TestNetworkPacketTypes::Data;
			dataPacket.size = p_size;
			CopyMemory(&dataPacket.data[0], p_data, p_size);
			dataPacket.length = 12 + p_size;
		}

		static void PopulateDataFooterPacket(NetworkSimplePacket &dataFooterPacket)
		{
			dataFooterPacket.length = sizeof(NetworkSimplePacket);
			dataFooterPacket.type = TestNetworkPacketTypes::DataFooter;
		}

		static void PopulateClearDataPacket(TestNetworkClearDataPacket &clearDataPacket, int p_dataSize)
		{
			clearDataPacket.length = sizeof(TestNetworkClearDataPacket);
			clearDataPacket.type = TestNetworkPacketTypes::ClearData;
			clearDataPacket.requestDataSize = p_dataSize;
		}

		static void PopulateReadyForDataPacket(TestNetworkReadyForBulkDataPacket &readyPacket, int p_dataSize)
		{
			readyPacket.length = sizeof(TestNetworkReadyForBulkDataPacket);
			readyPacket.type = TestNetworkPacketTypes::ReadyForData;
			readyPacket.requestDataSize = p_dataSize;
		}

		static void PopulateSamplePacket(TestNetworkSamplePacket &samplePacket, int p_value)
		{
			samplePacket.length = sizeof(TestNetworkSamplePacket);
			samplePacket.type = TestNetworkPacketTypes::Sample;
			samplePacket.value = p_value;
		}

		static void PopulateFastDataStartPacket(TestNetworkFastDataStartPacket &fastDataStartPacket, int p_expectedLength)
		{
			fastDataStartPacket.length = sizeof(TestNetworkFastDataStartPacket);
			fastDataStartPacket.type = TestNetworkPacketTypes::FastDataStart;
			fastDataStartPacket.expectedLength = p_expectedLength;
		}

		static void PopulateFastDataPacket(TestNetworkFastDataPacket &fastDataPacket, char *p_data, int p_dataLength)
		{
			fastDataPacket.length = 12 + p_dataLength;
			fastDataPacket.type = TestNetworkPacketTypes::FastData;
			CopyMemory(&fastDataPacket.data[0], p_data, p_dataLength);
			fastDataPacket.dataLength = p_dataLength;
		}
	};

	class TestNetworkNetwork : public GameNetworkBase
	{
	private:
		TestNetworkGameData *gameDataRef; // note: since this is here, destroy game data AFTER destroying network!!!  Network may try to add a Disconnected message to gameData when it is destroyed

	public:
		TestNetworkNetwork(int p_clientQty, String ^p_versionString, String ^p_versionGuid, TestNetworkGameData *p_gameData) : GameNetworkBase(p_clientQty, p_versionString, p_versionGuid)
		{
			gameDataRef = p_gameData;
		}

		void OnConnectingPreProcess(String ^p_message)
		{
			NetworkMessage(GameNetworkMessageType::Info, p_message);
			// show connecting message!
			GameContext::Instance->GetGame()->BlockRender();
		}

		void OnDisconnect(String ^p_reason) override
		{
			NetworkMessage(GameNetworkMessageType::Disconnect, "Disconnected - " + p_reason);

			gameDataRef->clearData = false;
			gameDataRef->ClearDownloadedData();
		}

		void OnJoined() override
		{
			// do nothing here, the 'Joined' default message is superfluous
		}

		void NetworkMessage(GameNetworkMessageType p_type, String ^p_message) override
		{
			// add to list of strings in game data
			LinkedListNode<MessageString> *newNode = gameDataRef->messageStrings.GetNewNode();
			newNode->data.message = p_message;
			gameDataRef->messageStrings.AddNode(newNode);
		}

		bool CustomValidatePacket(char *p_packet, int p_type) override
		{
			switch (p_type)
			{
			case TestNetworkPacketTypes::DataHeader:
			{
				TestNetworkDataHeaderPacket *packet = (TestNetworkDataHeaderPacket *)p_packet;
				if (packet->length != sizeof(TestNetworkDataHeaderPacket))
					return false;
				if (packet->totalSize <= 0)
					return false;
				if (packet->totalSize > 500000)
					return false;
			}
			break;
			case TestNetworkPacketTypes::Data:
			{
				TestNetworkDataPacket *packet = (TestNetworkDataPacket *)p_packet;
				if (packet->size > 8000)
					return false;
				if (packet->length != 12 + packet->size)
					return false;
			}
			break;
			case TestNetworkPacketTypes::DataFooter:
			{
				NetworkSimplePacket *packet = (NetworkSimplePacket *)p_packet;
				if (packet->length != sizeof(NetworkSimplePacket))
					return false;
			}
			break;
			case TestNetworkPacketTypes::ClearData:
			{
				TestNetworkClearDataPacket *packet = (TestNetworkClearDataPacket *)p_packet;
				if (packet->length != sizeof(TestNetworkClearDataPacket))
					return false;
				if (packet->requestDataSize < 500 || packet->requestDataSize > 8000)
					return false;
			}
			break;
			case TestNetworkPacketTypes::ReadyForData:
			{
				TestNetworkReadyForBulkDataPacket *packet = (TestNetworkReadyForBulkDataPacket *)p_packet;
				if (packet->length != sizeof(TestNetworkReadyForBulkDataPacket))
					return false;
				if (packet->requestDataSize < 500 || packet->requestDataSize > 8000)
					return false;
			}
			break;
			case TestNetworkPacketTypes::Sample:
			{
				TestNetworkSamplePacket *packet = (TestNetworkSamplePacket *)p_packet;
				if (packet->length != sizeof(TestNetworkSamplePacket))
					return false;
				if (packet->value < 1 || packet->value > 32767)
					return false;
			}
			break;
			case TestNetworkPacketTypes::FastDataStart:
			{
				TestNetworkFastDataStartPacket *packet = (TestNetworkFastDataStartPacket *)p_packet;
				if (packet->length != sizeof(TestNetworkFastDataStartPacket))
					return false;
			}
			break;
			case TestNetworkPacketTypes::FastData:
			{
				TestNetworkFastDataPacket *packet = (TestNetworkFastDataPacket *)p_packet;
				if (packet->length != 12 + packet->dataLength)
					return false;
			}
			break;
			default:
				// unknown type
				return false;
				break;
			}
			return true;
		}

		void CustomProcessPacketPlayer(char *p_packet, int p_type) override
		{
			int channel = GameNetworkPacketHelper::GetPacketChannel(p_packet);

			switch (p_type)
			{
			case TestNetworkPacketTypes::ClearData:
			{
				// just set a flag in game data so that client can check its own data, and when all data is ready, it can send a message to the host saying the client is ready for data
				gameDataRef->clearData = true;
				TestNetworkClearDataPacket *packet = (TestNetworkClearDataPacket *)p_packet;
				gameDataRef->requestDataSize = packet->requestDataSize;
			}
			break;
			case TestNetworkPacketTypes::DataHeader:
			{
				TestNetworkDataHeaderPacket *packet = (TestNetworkDataHeaderPacket *)p_packet;
				gameDataRef->downloadedData[channel].AllocateData(packet->totalSize);
			}
			break;
			case TestNetworkPacketTypes::Data:
			{
				TestNetworkDataPacket *packet = (TestNetworkDataPacket *)p_packet;
				gameDataRef->downloadedData[channel].SaveData(&(packet->data[0]), packet->size);
			}
			break;
			case TestNetworkPacketTypes::DataFooter:
			{
				// implementation really doesn't do anythign with this, but we can double check that client is down downloading
				if (gameDataRef->downloadedData[channel].done == false)
					throw gcnew Exception("Not done!!!");
			}
			break;
			case TestNetworkPacketTypes::Sample:
			{
				TestNetworkSamplePacket *packet = (TestNetworkSamplePacket *)p_packet;
				NetworkMessage(GameNetworkMessageType::Info, String::Format("Sample received from server: {0}", packet->value));
			}
			break;
			case TestNetworkPacketTypes::FastDataStart:
			{
				TestNetworkFastDataStartPacket *packet = (TestNetworkFastDataStartPacket *)p_packet;
				gameDataRef->fastDataReceived[channel] = 0;
				gameDataRef->fastDataExpected[channel] = packet->expectedLength;

				// this will get hit for every channel in staggered fashion, but that doesn't matter much
				ResetDataRateCollection();
			}
			break;
			case TestNetworkPacketTypes::FastData:
			{
				// record length
				TestNetworkFastDataPacket *packet = (TestNetworkFastDataPacket *)p_packet;
				gameDataRef->fastDataReceived[channel] += packet->dataLength;
			}
			break;
			default:
				NetworkMessage(GameNetworkMessageType::Info, "Bad packet received - type not recognized by implementation or framework");
			}
		}

		void CustomProcessPacketHost(GameNetworkClient *p_client, char *p_packet, int p_type) override
		{
			switch (p_type)
			{
			case TestNetworkPacketTypes::ReadyForData:
			{
				// Pipe a lot of data on each channel, guaranteed, to the client.
#define MAX_TEST_DATA_SIZE 8000
				char dataJunk[MAX_TEST_DATA_SIZE];
				int totalSize = 500000;

				TestNetworkReadyForBulkDataPacket *packet = (TestNetworkReadyForBulkDataPacket *)p_packet;
				int dataSize = packet->requestDataSize;
				FastRandom fastRandom;
				for (int i = 0; i < dataSize; i++)
				{
					dataJunk[i] = fastRandom.GetRandomInteger(0, 255);
				}

				int testChannels = 8;
				for (int channel = 0; channel < testChannels; channel++)
				{
					TestNetworkDataHeaderPacket headerPacket;
					TestNetworkPacketHelper::PopulateDataHeaderPacket(headerPacket, totalSize);
					SendToClientGuaranteed(p_client, (char *)&headerPacket, headerPacket.length, 0, channel);

					TestNetworkDataPacket dataPacket;
					int sizeToConsume = totalSize;
					int sourceIndex = 0;
					while (sizeToConsume > 0)
					{
						if (sizeToConsume >= dataSize)
						{
							TestNetworkPacketHelper::PopulateDataPacket(dataPacket, &dataJunk[sourceIndex], dataSize);
							SendToClientGuaranteed(p_client, (char *)&dataPacket, dataPacket.length, 0, channel);

							sizeToConsume -= dataSize;
							//sourceIndex += 8000; // only if we are copying from an entire data source instead of repeating a test chunk
						}
						else
						{
							TestNetworkPacketHelper::PopulateDataPacket(dataPacket, &dataJunk[sourceIndex], sizeToConsume);
							SendToClientGuaranteed(p_client, (char *)&dataPacket, dataPacket.length, 0, channel);

							// all done
							sizeToConsume = 0;
						}
					}

					NetworkSimplePacket footerPacket;
					TestNetworkPacketHelper::PopulateDataFooterPacket(footerPacket);
					SendToClientGuaranteed(p_client, (char *)&footerPacket, footerPacket.length, 0, channel);
				}

				NetworkMessage(GameNetworkMessageType::Info, String::Format("Sent bulk data to client '{0}'", p_client->GetName()));
			}
			break;
			case TestNetworkPacketTypes::Sample:
			{
				TestNetworkSamplePacket *packet = (TestNetworkSamplePacket *)p_packet;
				NetworkMessage(GameNetworkMessageType::Info, String::Format("Sample received from client '{0}': {1}", p_client->GetName(), packet->value));
			}
			break;
			}
		}

		// no destructor necessary - base destructor will be called automatically even if we had a destructor override here.

	};

	class TestNetworkConnectDlg : public GameUIForm
	{
	private:
		GameUILabel *clientNameLabel;
		GameUITextBox *clientNameTextBox;
		GameUILabel *clientNameErrorLabel;

		GameUILabel *ipEntryLabel;
		GameUITextBox *ipEntryTextBox;
		GameUILabel *ipEntryErrorLabel;

	public:
		TestNetworkConnectDlg()
		{
			GameFont ^font = GameContext::Instance->FontRegistry.GetFont("InfoBold");
			int textHeight = font->GetHeight();

			SetPosition(RectangleF(80, 80, 250, float(textHeight + 40)));
			SetBackColor(GameColor(64, 64, 64, 128));

			clientNameLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, 10, 230, float(textHeight))));
			clientNameLabel->SetFont(font);
			clientNameLabel->SetForeColor(GameColor(255, 255, 0));
			clientNameLabel->SetText("User Name");
			clientNameLabel->SetBackColor(GameColor(64, 64, 64, 0));

			clientNameTextBox = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(10, clientNameLabel->GetRect().Top + clientNameLabel->GetRect().Height + 2, 230, float(textHeight + 4)))); // allow margins
			clientNameTextBox->SetFont(font);
			clientNameTextBox->SetBackColor(GameColor(64, 64, 64, 64));
			clientNameTextBox->SetMaxLength(32);
			clientNameTextBox->SetKeyDown((GameUIKeyDown)&TestNetworkConnectDlg::ipEntry_KeyDown);

			clientNameErrorLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, clientNameTextBox->GetRect().Top + clientNameTextBox->GetRect().Height + 2, 230, 16)));
			clientNameErrorLabel->SetFont(font);
			clientNameErrorLabel->SetForeColor(GameColor(255, 128, 64));
			clientNameErrorLabel->SetBackColor(GameColor(64, 64, 64, 0));

			ipEntryLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, clientNameErrorLabel->GetRect().Top + clientNameErrorLabel->GetRect().Height + 5, 230, float(textHeight))));
			ipEntryLabel->SetFont(font);
			ipEntryLabel->SetForeColor(GameColor(255, 255, 0));
			ipEntryLabel->SetText("IP Address or Host Name");
			ipEntryLabel->SetBackColor(GameColor(64, 64, 64, 0));

			ipEntryTextBox = (GameUITextBox *)AddControl(new GameUITextBox(RectangleF(10, ipEntryLabel->GetRect().Top + ipEntryLabel->GetRect().Height + 2, 230, float(textHeight + 4)))); // allow margins
			ipEntryTextBox->SetFont(font);
			ipEntryTextBox->SetBackColor(GameColor(64, 64, 64, 64));
			ipEntryTextBox->SetMaxLength(64);
			ipEntryTextBox->SetKeyDown((GameUIKeyDown)&TestNetworkConnectDlg::ipEntry_KeyDown);

			ipEntryErrorLabel = (GameUILabel *)AddControl(new GameUILabel(RectangleF(10, ipEntryTextBox->GetRect().Top + ipEntryTextBox->GetRect().Height + 2, 230, 16)));
			ipEntryErrorLabel->SetFont(font);
			ipEntryErrorLabel->SetForeColor(GameColor(255, 128, 64));
			ipEntryErrorLabel->SetBackColor(GameColor(64, 64, 64, 0));

			SetSize(PointF(GetRect().Width, ipEntryErrorLabel->GetRect().Top + ipEntryErrorLabel->GetRect().Height + 10.0f));
		}

		~TestNetworkConnectDlg()
		{
			// controls are destroyed automatically as long as they are added to the control
		}

		void ipEntry_KeyDown(GameKeyEventArgs &p_event)
		{
			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Enter)
			{
				bool error = false;
				// Validate and show error if needed
				// work up the form backwards so that last error encountered is highest
				ipEntryErrorLabel->SetText("");
				String^ hostAddress = ipEntryTextBox->GetText()->Trim();
				while (hostAddress->IndexOf(" ") >= 0)
				{
					hostAddress = hostAddress->Remove(hostAddress->IndexOf(" "), 1);
				}
				ipEntryTextBox->SetText(hostAddress); // put cleaned version back
				if (hostAddress == "")
				{
					ipEntryErrorLabel->SetText("IP Address Is Required");
					ipEntryTextBox->SelectAll();
					ipEntryTextBox->Focus();
					error = true;
				}

				clientNameErrorLabel->SetText("");
				String^ clientName = clientNameTextBox->GetText()->Trim();
				clientNameTextBox->SetText(clientName); // put cleaned version back
				if (clientName == "")
				{
					clientNameErrorLabel->SetText("User Name is Required");
					clientNameTextBox->SelectAll();
					clientNameTextBox->Focus();
					error = true;
				}

				if (error == false)
				{
					// close it
					Close();

					// Connect!
					// todo: any chance to render screen whiel connecting?  That would be in Connect(), or a virtual that renders the connect message before the attempt.
					GameContext::Instance->GetNetwork()->Connect(hostAddress, 26010, clientName);
				}
			}

			if (System::Windows::Forms::Keys(p_event.keyCode) == System::Windows::Forms::Keys::Escape)
			{
				// close without effect
				Close();
			}
		}

	public:
		void Show()
		{
			throw gcnew Exception("No! ConnectDlg is meant to be a modal form!");
		}

		void ShowModal()
		{
			// clear error
			clientNameErrorLabel->SetText("");
			ipEntryErrorLabel->SetText("");

			// show it!
			GameUIForm::ShowModal();

			clientNameTextBox->SelectAll();
			ipEntryTextBox->SelectAll();
			clientNameTextBox->Focus();
		}

		void SetIPAddress(String ^p_address)
		{
			ipEntryTextBox->SetText(p_address);
		}

		void SetClientName(String ^p_clientName)
		{
			clientNameTextBox->SetText(p_clientName);
		}

		String ^ GetClientName()
		{
			return clientNameTextBox->GetText();
		}
	};

	public ref class TestNetwork : public GameBase
	{
	public:
		TestNetworkGameData *gameData;
		TestNetworkNetwork *network;
		GameTimer *timer;

		GameUI *gameUI;
		TestNetworkConnectDlg *connectDlg;

		TestNetwork(HWND p_hWnd) : GameBase(p_hWnd)
		{
			gameData = nullptr;
			network = nullptr;
			timer = nullptr;
		}

		virtual ~TestNetwork()
		{
			Destroy();
		}

		void Initialize() override
		{
			DestroyGameData();

			GameContext::Instance->SetGame(this);

			GameContext::Instance->Name = "Test";
			if (GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main") != nullptr)
				GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetGraphics(GraphicsTypeEnum::OpenGL);

			//GameFileResource ^fileResource = GameContext::Instance->FileRegistry.RegisterFileResource("TestTexture.jpg"); // no subfolder for now
			//GameContext::Instance->TextureRegistry.RegisterTexture("TestTexture", GameTextureInternalFormatEnum::RGBA, GameTextureFileComponentUsageEnum::ARGB, fileResource);
			GameContext::Instance->FontRegistry.RegisterFont("Info", gcnew System::Drawing::Font("Verdana", 10));
			GameContext::Instance->FontRegistry.RegisterFont("InfoBold", gcnew System::Drawing::Font("Verdana", 10, FontStyle::Bold));

			timer = new GameTimer();
			gameData = new TestNetworkGameData();
			network = new TestNetworkNetwork(16, VERSIONSTRING, VERSIONGUID, gameData); // 2 clients
			GameContext::Instance->SetNetwork(network);
			network->Startup("1.0.2");

			gameUI = new GameUI(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"), GameContext::Instance->FontRegistry.GetFont("Info"), GameColor(255,255,255));
			GameContext::Instance->SetUI(gameUI);
			connectDlg = new TestNetworkConnectDlg();

			GameBase::Initialize(); // call base initialize too.
		}

		void DestroyGameData()
		{
			if (network != nullptr)
			{
				delete network;
				network = nullptr;
			}
			// destroy game data LAST, since network closing may add a disconnect string to it when network is destroyed
			if (gameData != nullptr)
			{
				delete gameData;
				gameData = nullptr;
			}
			if (timer != nullptr)
			{
				delete timer;
				timer = nullptr;
			}
			if (gameUI != nullptr)
			{
				delete gameUI;
				gameUI = nullptr;
			}
			if (connectDlg != nullptr)
			{
				delete connectDlg;
				connectDlg = nullptr;
			}
		}

		void Destroy() override
		{
			// correct way to destroy when API has registered resources to destroy

			GameBase::Destroy();
			// get rid of common game-level resources, leave app-level resources alone
			GameApplicationContext::Instance->DestroyGame();
			// do this after graphics API has done its destroying but before the registries are cleared! (necessary to allow native object destruction in graphics before destroying their
			//  game instances)
			DestroyGameData();
			GameContext::Instance->DestroyGame();
		}
		bool DoGameLoop() override
		{
			timer->ResetElapsedTime();
			timer->Poll();

			// allocate bandwidth for sending, reset socket not ready flags
			network->AllocateBandwidth();

			if (gameData->clearData == true)
			{
				if (gameData->ReadyToDownloadData() == true)
				{
					TestNetworkReadyForBulkDataPacket readyPacket;
					TestNetworkPacketHelper::PopulateReadyForDataPacket(readyPacket, gameData->requestDataSize);
					network->SendToServer((char *)&readyPacket, readyPacket.length, 0);

					// don't send another one!!!
					gameData->clearData = false;
				}
			}

			// style of ui: as long as there is a form up, game scene does not respond to mouse or keyboard.
			// continue piping mouse up and down events to ui in all cases so that mouse state is properly maintained (if ui becomes inactive with mouse down, mouse up needs to be known
			//    by the ui so that the next mouse down when a form pops up is properly handled
			bool uiActive = (connectDlg->IsClosed() == false);
			LinkedListEnumerator<GameInputEvent> eventEnumerator = inputEvents->GetEnumerator();
			if (uiActive == true)
			{
				// clear accumulated Esc key state before gameLoop ran - don't want to come back and end program if user hits Esc in UI
				keyboardKeys.GetKey(27)->ClearClicked();
				keyboardKeys.GetKey(27)->ClearPressed();
			}
			while (eventEnumerator.MoveNext())
			{
				// execute all messages and pipe them into the UI, kick out the moment the ui isn't active anymore
				switch (eventEnumerator.Current()->data.type)
				{
				case GameInputEventType::MouseDown:
				case GameInputEventType::MouseUp:
					// track ups and downs on mouse for UI use, in case mouse was down on a form or control when it was closed (this allows it to handle the mouse lift to clean things up)
					gameUI->ApplyInputEvent(eventEnumerator.Current()->data);
					break;
				case GameInputEventType::MouseMove:
				case GameInputEventType::KeyDown:
				case GameInputEventType::KeyUp:
				//case GameInputEventType::KeyPress:
				case GameInputEventType::MouseWheel:
					// only do these if ui is active
					if (uiActive == true)
						gameUI->ApplyInputEvent(eventEnumerator.Current()->data);
					break;
				}

				// check for done
				uiActive = (connectDlg->IsClosed() == false);
			}
			if (uiActive == false)
			{
				if (keyboardKeys.GetKey(27)->IsPressed())
					return false;
				if (keyboardKeys.GetKey('H')->IsClicked())
				{
					String ^error;
					if (network->IsOkToHost(error) == false)
						network->NetworkMessage(GameNetworkMessageType::Error, error);
					else
					{
						network->Host(26010, "host");
					}
				}
				if (keyboardKeys.GetKey('D')->IsClicked())
				{
					network->Disconnect();
				}
				if (keyboardKeys.GetKey('C')->IsClicked())
				{
					String ^error;
					if (network->IsOkToConnect(error) == false)
						network->NetworkMessage(GameNetworkMessageType::Error, error);
					else
					{
						if (connectDlg->IsClosed() == true)
						{
							FastRandom fastRandom;
							connectDlg->SetIPAddress("127.0.0.1");
							if (connectDlg->GetClientName() == "")
								connectDlg->SetClientName(String::Format("client{0:g}", fastRandom.GetRandomInteger(1, 100)));
							// ui takes over for now
							connectDlg->ShowModal();
						}
					}
				}
				if (keyboardKeys.GetKey('L')->IsClicked())
				{
					String ^error;
					if (network->IsOkToConnect(error) == false)
						network->NetworkMessage(GameNetworkMessageType::Error, error);
					else
					{
						if (connectDlg->IsClosed() == true)
						{
							FastRandom fastRandom;
							connectDlg->SetIPAddress("192.168.1.112");
							if (connectDlg->GetClientName() == "")
								connectDlg->SetClientName(String::Format("client{0:g}", fastRandom.GetRandomInteger(1, 100)));
							// ui takes over for now
							connectDlg->ShowModal();
						}
					}
					//network->Connect("192.168.1.112", 26010, String::Format("client{0:g}", fastRandom.GetRandomInteger(1, 100)));
				}
				if (keyboardKeys.GetKey('I')->IsClicked())
				{
					String ^error;
					if (network->IsOkToConnect(error) == false)
						network->NetworkMessage(GameNetworkMessageType::Error, error);
					else
					{
						if (connectDlg->IsClosed() == true)
						{
							FastRandom fastRandom;
							connectDlg->SetIPAddress("71.10.34.145");
							if (connectDlg->GetClientName() == "")
								connectDlg->SetClientName(String::Format("client{0:g}", fastRandom.GetRandomInteger(1, 100)));
							// ui takes over for now
							connectDlg->ShowModal();
						}
					}
					//network->Connect("71.10.34.145", 26010, String::Format("client{0:g}", fastRandom.GetRandomInteger(1, 100)));
				}
				if (keyboardKeys.GetKey('V')->IsClicked())
				{
					network->SetVerboseReporting(!network->GetVerboseReporting());
				}
				if (keyboardKeys.GetKey('S')->IsClicked())
				{
					if (network->IsActive() == true)
					{
						// send a packet to all clients, or host, depending on operation mode
						FastRandom fastRandom;
						int value = fastRandom.GetRandomInteger(1, 32767);

						TestNetworkSamplePacket samplePacket;
						TestNetworkPacketHelper::PopulateSamplePacket(samplePacket, value);

						if (network->IsServer())
							network->SendToAllClients((char *)&samplePacket, samplePacket.length, 0);
						else
							network->SendToServer((char *)&samplePacket, samplePacket.length, 0);
					}
				}
				if (keyboardKeys.GetKey('X')->IsClicked())
				{
					if (network->IsActive() == true)
					{
						// send two guaranteed packet to all clients, or host, depending on operation mode
						FastRandom fastRandom;
						int value = fastRandom.GetRandomInteger(1, 32767);

						TestNetworkSamplePacket samplePacket;
						TestNetworkPacketHelper::PopulateSamplePacket(samplePacket, value);

						if (network->IsServer())
							network->SendToAllClientsGuaranteed((char *)&samplePacket, samplePacket.length, 0, 0);
						else
							network->SendToServerGuaranteed((char *)&samplePacket, samplePacket.length, 0, 0);

						// send two!
						value = fastRandom.GetRandomInteger(1, 32767);
						TestNetworkPacketHelper::PopulateSamplePacket(samplePacket, value);
						if (network->IsServer())
							network->SendToAllClientsGuaranteed((char *)&samplePacket, samplePacket.length, 0, 0);
						else
							network->SendToServerGuaranteed((char *)&samplePacket, samplePacket.length, 0, 0);
					}
				}
				if (keyboardKeys.GetKey('B')->IsClicked())
				{
					if (network->IsServer() == true)
					{
						TestNetworkClearDataPacket clearDataPacket;
						int dataSize = 8000;
						if (keyboardKeys.GetKey(16)->IsPressed())
							dataSize = 500;
						if (keyboardKeys.GetKey(17)->IsPressed())
							dataSize = 2000;
						TestNetworkPacketHelper::PopulateClearDataPacket(clearDataPacket, dataSize);

						network->SendToAllClients((char *)&clearDataPacket, clearDataPacket.length, 0);

						if (keyboardKeys.GetKey(17)->IsPressed())
							network->NetworkMessage(GameNetworkMessageType::Info, "Bulk clear data sent to clients (medium)");
						else if(keyboardKeys.GetKey(16)->IsPressed())
							network->NetworkMessage(GameNetworkMessageType::Info, "Bulk clear data sent to clients (small)");
						else
							network->NetworkMessage(GameNetworkMessageType::Info, "Bulk clear data sent to clients (large)");
					}
				}
				if (keyboardKeys.GetKey('N')->IsClicked())
				{
					if (network->IsServer() == true)
					{
						int dataSize = 8000;
						if (keyboardKeys.GetKey(16)->IsPressed())
							dataSize = 500;
						if (keyboardKeys.GetKey(17)->IsPressed())
							dataSize = 2000;

						char dataJunk[MAX_TEST_DATA_SIZE];
						FastRandom fastRandom;
						for (int i = 0; i < dataSize; i++)
						{
							dataJunk[i] = fastRandom.GetRandomInteger(0, 255);
						}

						network->ResetDataRateCollection();

						for (int channel = 0; channel < 8; channel++)
						{
							int totalLength = 150000 + 100000 * channel; // 8 channels for 4mil bytes total

							TestNetworkFastDataStartPacket fastDataStartPacket;
							TestNetworkPacketHelper::PopulateFastDataStartPacket(fastDataStartPacket, totalLength);
							network->SendToAllClients((char *)&fastDataStartPacket, fastDataStartPacket.length, 0, channel);

							TestNetworkFastDataPacket fastDataPacket;
							while (totalLength > 0)
							{
								if (totalLength >= dataSize)
								{
									TestNetworkPacketHelper::PopulateFastDataPacket(fastDataPacket, dataJunk, dataSize);
									totalLength -= dataSize;
								}
								else
								{
									TestNetworkPacketHelper::PopulateFastDataPacket(fastDataPacket, dataJunk, totalLength);
									totalLength = 0;
								}

								// hmm, this ends up a lot slower for some reason on localhost
								network->SendToAllClients((char *)&fastDataPacket, fastDataPacket.length, 0, channel);
							}
						}

						if (keyboardKeys.GetKey(17)->IsPressed())
							network->NetworkMessage(GameNetworkMessageType::Info, "Sending fast data (medium)");
						else if (keyboardKeys.GetKey(16)->IsPressed())
							network->NetworkMessage(GameNetworkMessageType::Info, "Sending fast data (small)");
						else
							network->NetworkMessage(GameNetworkMessageType::Info, "Sending fast data (large)");
					}
				}
				if (keyboardKeys.GetKey('P')->IsClicked())
				{
					Sleep(5000);
				}
				if (keyboardKeys.GetKey(32)->IsClicked())
				{
					gameData->messageStrings.Clear();
				}
				if (keyboardKeys.GetKey('A')->IsClicked())
				{
					GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
					graphics->SetVSyncEnabled(!graphics->VSyncIsEnabled());
				}
			}

			///////////////////////////////////////////////////////////
			// all of this runs regardless of ui or scene being active
			keyboardKeys.ClearClicked();

			// game animation and events here

			// run network, process messages, send packets waiting because of bandwidth consumption, etc.
			network->Process();

			return true;
		}

		void PerformRender() override
		{
			DoNetworkRender();
		}

		void BlockRender() override
		{
			DoNetworkRender();
		}

		void DoNetworkRender()
		{
			GraphicsBase *graphics = GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->GetGraphics();
			graphics->MakeCurrent();
			graphics->ClearScreen(GameColor(0, 128, 128));

			graphics->Set2dWindowProjection();

			// render text
			GameFont ^font = GameContext::FontRegistry.GetFont("Info");
			int textHeight = font->GetHeight();
			graphics->RenderFont("'H' to host, 'C' to connect (L for LAN connect, I for internet connect), 'D' to disconnect, 'V' for verbose reporting", font, 0, 0, GameColor(255, 255, 0));
			graphics->RenderFont("'S' to send single packet, 'X' to send two guaranteed packets, SPACE to clear messages,", font, 0, textHeight, GameColor(255, 255, 0));
			graphics->RenderFont("Server only - 'B' for bulk guaranteed 7-channel send, 'N' for large quantity fast data send, SHIFT to send smaller packets", font, 0, textHeight + textHeight, GameColor(255, 255, 0));
			graphics->RenderFont("'P' to pause for 5 seconds for stability testing, 'A' to toggle vsync to test effect on framerate in fullscreen", font, 0, textHeight + textHeight + textHeight, GameColor(255, 255, 0));

			// now render all the text
			int y = textHeight * 4;
			LinkedListEnumerator<MessageString> enumerator = gameData->GetMessageStringEnumerator();
			while (enumerator.MoveNext())
			{
				String ^message = enumerator.Current()->data.message;
				graphics->RenderFont(message, font, 0, y, GameColor(255, 255, 0));
				y += textHeight;
			}

			int x = GameApplicationContext::ViewportRegistry.GetViewport("Main")->GetWidth() - 300;
			if (network->IsServer() == true)
			{
				// render upload progress
				y = 100;

				String ^message = "Client upload progress:";
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Peak upload: ";
				float peakUpload = network->GetPeakUploadDataRate();
				message = message + String::Format("{0} Kb/sec", int(peakUpload * 8.0f / 1024.0f));
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Current upload: ";
				float upload = network->GetImmedateUploadDataRate();
				message = message + String::Format("{0} Kb/sec", int(upload * 8.0f / 1024.0f));
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Sustained upload: ";
				upload = network->GetSustainedUploadDataRate();
				message = message + String::Format("{0} Kb/sec", int(upload * 8.0f / 1024.0f));
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				for (int i = 0; i < network->GetClientQty(); i++)
				{
					if (network->GetClientByIndex(i)->IsConnected() == false)
					{
						message = String::Format("{0}:", i);
					}
					else
					{
						bool notReady = false;
						float percent = network->GetClientPacketsProgress(notReady, i);
						float clientPeakUpload = network->GetClientPeakUploadDataRate(i);
						if (notReady == true)
							message = String::Format("{0}: <{1:g}> ({2} Kb/sec)", i, percent, int(clientPeakUpload * 8.0f / 1024.0f));
						else
							message = String::Format("{0}: {1:g} ({2} Kb/sec)", i, percent, int(clientPeakUpload * 8.0f / 1024.0f));
					}
					graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
					y += textHeight;
				}
			}
			else if (network->IsClient() == true)
			{
				y = 100;

				// render download progress
				String ^message = "Download progress:";
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Peak download: ";
				float peakDownload = network->GetPeakDownloadDataRate();
				message = message + String::Format("{0} Kb/sec", int(peakDownload * 8.0f / 1024.0f));
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Current download: ";
				float download = network->GetImmedateDownloadDataRate();
				message = message + String::Format("{0} Kb/sec", int(download * 8.0f / 1024.0f));
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Sustained download: ";
				download = network->GetSustainedDownloadDataRate();
				message = message + String::Format("{0} Kb/sec", int(download * 8.0f / 1024.0f));
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				message = "Fast data:";
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				for (int i = 0; i < 8; i++)
				{
					message = String::Format("{0}: {1}/{2}", i, gameData->fastDataReceived[i], gameData->fastDataExpected[i]);
					graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
					y += textHeight;
				}

				message = "Guaranteed Data:";
				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;

				for (int i = 0; i < 8; i++)
				{
					message = String::Format("{0}: {1}/{2}", i, gameData->downloadedData[i].bytesReceived, gameData->downloadedData[i].size);
					graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
					y += textHeight;
				}

				y += textHeight;

				bool notReady = false;
				float percent = network->GetClientPacketsProgress(notReady);
				if (notReady == true)
					message = String::Format("Server upload progress: <{0:g}>", percent);
				else
					message = String::Format("Server upload progress: {0:g}", percent);

				graphics->RenderFont(message, font, x, y, GameColor(255, 255, 255));
				y += textHeight;
			}

			// list players
			y += textHeight;
			graphics->RenderFont("Players:", font, x, y, GameColor(255, 255, 255));
			y += textHeight;
			LinkedListEnumerator<GameNetworkPlayerNode> playerEnum = network->GetPlayerEnumerator();
			while (playerEnum.MoveNext())
			{
				graphics->RenderFont(gcnew String(playerEnum.Current()->data.player->name), font, x, y, GameColor(255, 255, 255));
				y += textHeight;
			}

			gameUI->Render(graphics);

			graphics->FinishRender();
			graphics->SwapBuffers();
		}

	};
}