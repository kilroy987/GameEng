Download glext.h and wglext.h from opengl.org and place in d:sdk\gl
They are at https://khronos.org/registry/OpenGL/index_gl.php - just scroll down the page, right click each and save as

GameEngDev gives you access to all the little test apps in the list.  Some may exception out.
FullScreenTest runs one specific test as specified in the Main.cpp.
Use the Set and Starup Project to determine which one executes.
For best performance in Release mode, use Start Without Debugging

- File Organization:
by far, most files are framework.
TestGame.h, TestGame.pp, JetGameHelper.h and JetGameHelper.cpp files are implementation and contain the specific tests.
TestForm.h/TestForm.cpp in the GameEngDev project shows how each is invoked.
In The FullScreenTest project, Main.cpp loads a single test and runs it in fullscreen.

GameEngDev/TestForm.h and FullScreenTest/Main.cpp serve as the thin outer layers that call the appropriate GameBase functions to handle events and execute the game loops.

Prpocessor defines:
_WINSOCK_DEPRECATED_NO_WARNINGS to disable deprecated API warnings in winsock2 in GameNetworkBase.h (using deprecated inet_addr instead of inte_pton)