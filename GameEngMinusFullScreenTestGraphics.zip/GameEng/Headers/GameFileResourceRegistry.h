#pragma once

#include "GameFileResource.h"

namespace GameEng {
	namespace Resource {
		public ref class GameFileResourceRegistry
		{
		private:
			System::Collections::Generic::Dictionary<System::String ^, GameFileResource^> files;
			System::String ^parentFolder;

		public:
			GameFileResourceRegistry()
			{
				parentFolder = ".";
			}

			// member of a static class - can't have a destructor
			//virtual ~GameFileResourceRegistry()
			//{
			//	Destroy();
			//}

			void Destroy()
			{
				for each (System::String ^key in files.Keys)
				{
					delete files[key];
				}
				files.Clear();
			}

			void Clear()
			{
				Destroy();
			}

			void SetParentFolder(System::String ^p_parentFolder)
			{
				parentFolder = p_parentFolder;
			}

			GameFileResource ^ RegisterFileResource(System::String ^p_resourceFilePath)
			{
				System::String ^filePath = "";
				if (parentFolder != ".")
					filePath = p_resourceFilePath;
				else
					filePath = parentFolder + "\\" + p_resourceFilePath;

				GameFileResource ^newResource = gcnew GameFileResource(p_resourceFilePath, filePath);

				if (files.ContainsKey(p_resourceFilePath))
				{
					files[p_resourceFilePath] = newResource;
				}
				else
					files.Add(p_resourceFilePath, newResource);

				return newResource;
			}

			// use this one when an override is provided to update the diskfilepath properly
			//GameFileResource ^ RegisterFileResource(System::String ^p_resourceFilePath, System::String ^p_diskFilePath)
			//{

			//}

			// todo: routine that parses a reousrce folder and populates this entire structure
			// todo: routine that parses a provided resource folder and updates the entire structure

			GameFileResource^ GetFile(System::String ^p_resourceFilePath)
			{
				if (files.ContainsKey(p_resourceFilePath))
					return files[p_resourceFilePath];
				else
					throw gcnew System::Exception("File Resource '" + p_resourceFilePath + "' not registered");
			}

		};
	}
}