#pragma once

#include "GameViewport.h"
#include "GameContext.h"

namespace GameEng {
	namespace Game {

		using namespace GameEng::Graphics;

		// To understand the differetn between GameApplicationContext, and GameContext,
		//   just be aware that GameContext must be accessible by all the components of the system, and hence must have mostly dumb endpoint structures,
		//   where GameApplicationContext is meant to be access by the thin outer layer of the application only to provide information to specific aspects
		//   of the system to make the application runnable withotu requiring the outer layer to provide its own structure.
		public ref class GameApplicationContext
		{
		public:
			// a singleton instance that is reference statically throughout the framework
			static property GameApplicationContext^ Instance { GameApplicationContext^ get() { return %instance; }}

			static GameViewportRegistry ViewportRegistry; // viewports and their graphics

		private:
			GameApplicationContext()
			{
			}
			GameApplicationContext(const GameApplicationContext%) { throw gcnew Exception("singleton cannot be copy constructed"); }
			static GameApplicationContext instance;

		public:
			// cannot have destructor on static class
			//virtual ~GameContext()
			//{
			//	Destroy();
			//}

			void Destroy()
			{
				DestroyApp();
			}

			// ending the game on this process - might start up another one
			void DestroyGame()
			{
				// todo: Get rid of game specific structures, leave app-level resources alone
				// todo: Asusming only 1 viewport and renderer for now, getting rid of resources for that renderer.  Later, will need to support more
				//   than 1 viewport which supports more than one rendering context, each with their own resources (like textures, etc.)

				// get rid of renderer resources
				if (ViewportRegistry.GetViewport(0)->GetGraphics() != nullptr)
				{
					StopGraphicsRenderer(*(ViewportRegistry.GetViewport(0)->GetGraphics()));
					GameContext::Instance->StopGraphicsRenderer(*(ViewportRegistry.GetViewport(0)->GetGraphics()));
				}

				// stop the graphics
				ViewportRegistry.DestroyGraphics();
			}

			// ending the program
			void DestroyApp()
			{
				DestroyGame();

				// get rid of app-level resources
				ViewportRegistry.Destroy();
			}

			// call when ending the game, or changing graphics provider
			void StopGraphicsRenderer(GraphicsBase &p_currentGraphics)
			{
				// nothing to do here for now
			}

		};
	}
}