#pragma once

#include "Vector.h"
#include "GameColor.h"

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;

		class StarfieldPoint
		{
		public:
			Vector3d point;
			GameColor color;
		};
	}
}