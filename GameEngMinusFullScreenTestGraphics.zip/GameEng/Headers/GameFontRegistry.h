#pragma once

#include "GameFont.h"
#include "GraphicsBase.h"

namespace GameEng {
	namespace Resource {

		using namespace System;
		using namespace GameEng::Graphics;

		public ref class GameFontRegistry
		{
		private:
			System::Collections::Generic::Dictionary<String ^, GameFont ^> ^fonts;

		public:
			GameFontRegistry()
			{
				Initialize();
			}

			void Initialize()
			{
				Destroy();

				fonts = gcnew System::Collections::Generic::Dictionary<String ^, GameFont ^>();
			}

			// it's used statically - it can't have a destructor, so call destroy/clear manually from the parent class when appropriate (GameContext)
			//virtual ~GameFontRegistry()
			//{
			//	Destroy();
			//}

			void Destroy()
			{
				if (fonts != nullptr)
				{
					Clear();

					delete fonts;
					fonts = nullptr;
				}
			}

			void Clear()
			{
				if (fonts != nullptr)
				{
					// copy keys to an array because we'll be altering the key list in the loop
					array<System::String^, 1> ^keys = gcnew array<System::String^, 1>(fonts->Keys->Count);
					fonts->Keys->CopyTo(keys, 0);
					for each (System::String ^key in keys)
					{
						if (fonts[key] != nullptr)
							delete fonts[key];
					}
					fonts->Clear();
				}
			}

			void ClearRendererResources(GraphicsBase &p_graphics)
			{
				if (fonts != nullptr)
				{
					// not removing dictionary items, so no need to copy to an array
					for each (System::String ^key in fonts->Keys)
					{
						p_graphics.ClearFontRendererResources(fonts[key]->GetRendererResource()->rendererResource);
						fonts[key]->GetRendererResource()->ClearResource();
					}
				}
			}

			void RegisterFont(String ^p_name, System::Drawing::Font ^p_font)
			{
				if (fonts->ContainsKey(p_name))
					throw gcnew System::Exception("Font '" + p_name + "' already exists");

				fonts->Add(p_name, gcnew GameFont(p_font));
			}

			// opportunity to prevent an exception at times that a user chooses or selects a font for themselves
			bool FontExists(String ^p_name)
			{
				return fonts->ContainsKey(p_name);
			}

			GameFont ^ GetFont(String ^p_name)
			{
				if (fonts->ContainsKey(p_name))
					return fonts[p_name];
				else
					throw gcnew Exception("Font '" + p_name + "' not found");
			}
		};
	}
}