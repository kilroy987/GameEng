#pragma once

#define DIRECTINPUT_VERSION 0x0800 // using DX 8 for directinput

// dx libs
#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dxguid.lib")

#include <dinput.h> // DirectInput for joystick
#include "LinkedListTemplate.h"

namespace GameEng {
	using namespace System;
	using namespace GameEng::Storage;

	namespace Input
	{
		enum MouseButton {
			Left = 0, // array indices on mouse buttons
			Right = 1,
			Middle = 2
		};

		public ref class GameKeyboardKey
		{
		public:
			bool clicked;
			bool pressed;

			GameKeyboardKey()
			{
				ClearClicked();
				ClearPressed();
			}

			void SetClicked()
			{
				clicked = true;
			}

			void SetPressed()
			{
				pressed = true;
			}

			void ClearClicked()
			{
				clicked = false;
			}

			void ClearPressed()
			{
				pressed = false;
			}

			bool IsClicked()
			{
				return clicked;
			}

			bool IsPressed()
			{
				return pressed;
			}

			void Clear()
			{
				ClearClicked();
				ClearPressed();
			}
		};

#define GAMEENG_KEYBOARDKEY_QTY 256
		public ref class GameKeyboardKeys
		{
			array<GameKeyboardKey^> ^keys; // index is keycode

		public:
			GameKeyboardKeys()
			{
				keys = gcnew array<GameKeyboardKey^>(GAMEENG_KEYBOARDKEY_QTY);
				for (int i = 0; i < GAMEENG_KEYBOARDKEY_QTY; i++)
					keys[i] = gcnew GameKeyboardKey();
			}

			~GameKeyboardKeys()
			{
				Destroy();
			}

			void Clear()
			{
				for (int i = 0; i < GAMEENG_KEYBOARDKEY_QTY; i++)
				{
					keys[i]->Clear();
				}
			}

			void ClearClicked()
			{
				for (int i = 0; i < GAMEENG_KEYBOARDKEY_QTY; i++)
				{
					keys[i]->ClearClicked();
				}
			}

			void Destroy()
			{
				if (keys != nullptr)
				{
					delete[] keys;
					keys = nullptr;
				}
			}

			GameKeyboardKey ^ GetKey(int p_keycode)
			{
				if (p_keycode >= 0 && p_keycode < GAMEENG_KEYBOARDKEY_QTY)
					return keys[p_keycode];
				else
					throw gcnew Exception("KeyCode " + p_keycode.ToString() + " must be less than or equal to key array size of " + Convert::ToString(GAMEENG_KEYBOARDKEY_QTY));
			}
		};

		public ref class GameMouseButton
		{
		public:
			bool down;

		private:
			bool clicked; // one true, remains true until ClearClicked() is called.  This serves well for game control purposes.  UI checks old and new button states to decide when to fire click related events

		public:
			GameMouseButton()
			{
				down = false;
				clicked = false;
			}

			void SetDown(bool p_down)
			{
				if (p_down == true)
				{
					if (down == false)
						clicked = true;
				}

				down = p_down;
			}

			bool IsClicked()
			{
				return clicked;
			}

			void ClearClicked()
			{
				clicked = false;
			}
		};

		enum class MouseDownTarget
		{
			None = 0,
			GameScene = 1,
			UI = 2
		};

		enum class GameInputEventType
		{
			KeyDown = 0,
			//KeyPress = 1,		// worked into KeyDown now
			KeyUp = 2,
			MouseDown = 3,
			MouseUp = 4,
			MouseMove = 5,
			MouseWheel = 6
		};

		class GameInputEvent
		{
		public:
			GameInputEventType type;

			bool ctrlModifier;
			bool altModifier;
			bool shiftModifier;

			char keyPressed; // actual text according to modifier keys
			int keyCode; // ASCII code for key ('a' comes as A, etc.)

			MouseButton mouseButton;
			System::Drawing::Point mousePosition;
			int mouseWheelDelta;

			bool handled; // if true, further processing on that message is blocked
			bool suppressKeyPress; // after keydown, if suppressKeyPress is true, KeyPress will be skipped (it's also skipped if the form that keydown happened on is closed or the control became inactive)

			GameInputEvent()
			{
				// to support deleted list only
			}

			void Initialize()
			{
				handled = false;
				suppressKeyPress = false;
				keyPressed = 0;
			}

			GameInputEvent(MouseButton p_mouseButton, bool p_down)
			{
				Initialize();

				if (p_down == true)
					type = GameInputEventType::MouseDown;
				else
					type = GameInputEventType::MouseUp;

				mouseButton = p_mouseButton;
			}

			GameInputEvent(int p_mouseWheelDelta)
			{
				Initialize();

				type = GameInputEventType::MouseWheel;
				mouseWheelDelta = p_mouseWheelDelta;
			}

			GameInputEvent(System::Drawing::Point &p_mousePosition)
			{
				Initialize();

				type = GameInputEventType::MouseMove;
				mousePosition = p_mousePosition;
			}

			//GameInputEvent(char p_char)
			//{
			//	Initialize();

			//	type = GameInputEventType::KeyPress;
			//	keyPressed = p_char;
			//}

			GameInputEvent(GameInputEventType p_type, int p_keyCode, bool p_shiftModifier, bool p_altModifier, bool p_ctrlModifier, char p_char = 0)
			{
				Initialize();

				if (p_type != GameInputEventType::KeyDown && p_type != GameInputEventType::KeyUp)
					throw gcnew Exception("This constructor is for KeyDown and KeyUp only");
				if (p_type == GameInputEventType::KeyUp && p_char != 0)
					throw gcnew Exception("keyPressed can only be part of KeyDown");

				type = p_type;
				shiftModifier = p_shiftModifier;
				altModifier = p_altModifier;
				ctrlModifier = p_ctrlModifier;
				keyCode = p_keyCode;
				keyPressed = p_char; // will trigger KeyPress after KeyDown if != 0 and suppressKeyPress is still false (occurs on same form/control as keydown happened on even if focus changed,
									 //    but will be skipped if the form became closed or inactive or the control became inactive during KeyDown)
			}
		};

		// should really only have one of these
		public ref class GameMouse
		{
		public:
			int currentX, currentY; // last known position
			int offsetX, offsetY; // offset from last position (up to game how these are reset
			int currentWheel;
			int offsetWheel;
			bool visible; // shown? (if hidden, still functions entirely on controls and for game)

			bool applyOffsets;

			GameMouseButton leftButton;
			GameMouseButton rightButton;
			GameMouseButton middleButton;

			MouseDownTarget mouseDownTarget; // if set, mouse is currently down and cannot be treated as down on anything other than what this signifies
											 // elements must check this to see if, when a mouse down is detected, if that element should then set this target and determine what the mouse is down on
											 // the appropriate element further identifies exactly what the mouse is down on
											 // GameBase implementation is responsible for how this value limits game function and is set.  GameUI uses this value automatically to limit mouse function.

			GameMouse()
			{
				InitializeOffsets();
				visible = true;
				mouseDownTarget = MouseDownTarget::None;
			}

			void SetCurrentPosition(int p_x, int p_y)
			{
				currentX = p_x;
				currentY = p_y;
				applyOffsets = true;
			}

			void SetCurrentWheelPosition(int p_value)
			{
				currentWheel = p_value;
				applyOffsets = true;
			}

			void ZeroOffsets()
			{
				offsetX = 0;
				offsetY = 0;
				offsetWheel = 0;
			}

			void ClearClicked()
			{
				leftButton.ClearClicked();
				rightButton.ClearClicked();
				middleButton.ClearClicked();
			}

			void InitializeOffsets()
			{
				ZeroOffsets();
				applyOffsets = false; // called when mouse should not cause a massive offset when it enters the control from a position far removed from where it left from
			}

			void MouseMove(int p_x, int p_y)
			{
				if (applyOffsets == true)
				{
					offsetX += (p_x - currentX);
					offsetY += (p_y - currentY);
				}
				currentX = p_x;
				currentY = p_y;

				applyOffsets = true;
			}

			void MouseWheel(int p_delta)
			{
				if (applyOffsets == true)
				{
					offsetWheel += p_delta;
				}
				currentWheel += p_delta;

				applyOffsets = true;
			}

			void ApplyMouseButton(MouseButton p_button, bool p_down)
			{
				switch (p_button)
				{
				case MouseButton::Left:
					leftButton.SetDown(p_down);
					break;
				case MouseButton::Right:
					rightButton.SetDown(p_down);
					break;
				case MouseButton::Middle:
					middleButton.SetDown(p_down);
					break;
				}
			}

			void CheckMouseUp()
			{
				if (leftButton.down == false && rightButton.down == false && middleButton.down == false)
					mouseDownTarget = MouseDownTarget::None;
			}

			void Hide()
			{
				if (visible == true)
				{
					System::Windows::Forms::Cursor::Hide();
					visible = false;
				}
			}

			void Show()
			{
				if (visible == false)
				{
					System::Windows::Forms::Cursor::Show();
					visible = true;
				}
			}

			bool IsVisible()
			{
				return visible;
			}

			void SetScreenPosition(int p_screenX, int p_screenY)
			{
				System::Drawing::Point current = System::Windows::Forms::Cursor::Position;
				System::Windows::Forms::Cursor::Position = System::Drawing::Point(p_screenX, p_screenY);

				// compensate so that next Poll properly captures offsets
				currentX += (p_screenX - current.X);
				currentY += (p_screenY - current.Y);
			}

			// events

			void ApplyMouseEvent(GameInputEvent &p_event)
			{
				switch (p_event.type)
				{
				case GameInputEventType::MouseDown:
					ApplyMouseButton(p_event.mouseButton, true);
					break;
				case GameInputEventType::MouseUp:
					ApplyMouseButton(p_event.mouseButton, false);
					break;
				case GameInputEventType::MouseMove:
					MouseMove(p_event.mousePosition.X, p_event.mousePosition.Y);
					break;
				case GameInputEventType::MouseWheel:
					MouseWheel(p_event.mouseWheelDelta);
					break;
				default:
					throw gcnew Exception("Only events supported here are MouseUp, MouseDown, MouseMove and MouseWheel");
					break;
				}
			}
		};

		// raw unmodified values from device - game is responsible for deciding how to curve values for more usability
		// recommendation - have the areas closer to the center have less of a linear effect than the outer edges - allows for finer adjustments near the dead area.
		class JoystickValues
		{
		public:
			bool valid; // if false, there is no joystick data to poll

			// -1000 to 1000
			int primaryX; // -1000 left, 1000 right, recommend dead area of +/- 150
			int primaryY; // -1000 forward, 1000 back, recommend dead area of +/- 150
			int twist; // -1000 left, 1000 right - main joystick twist - recommend dead area of +/- 250

			// true/false
			bool button1Down, button2Down, button3Down, button4Down;

			int povAngle; // hat - 0 is straight forward, 270 is left, 90 is right, 180 is back

			JoystickValues()
			{
				Initialize();
			}

			void Initialize()
			{
				valid = false;

				primaryX = 0;
				primaryY = 0;
				twist = 0;

				button1Down = false;
				button2Down = false;
				button3Down = false;
				button4Down = false;
			}
		};

		// see https://www.cs.cmu.edu/~jparise/directx/joystick/ for helpful sample
		class GameJoystick // has to be nonmanaged
		{
			static LPDIRECTINPUT8 dInput;
			static LPDIRECTINPUTDEVICE8 joystickDevice;
			DIJOYSTATE2 joystickDeviceState; // raw values read from device
			HWND hWnd;

		public:
			JoystickValues values;

			GameJoystick(HWND p_hWnd)
			{
				dInput = nullptr;
				joystickDevice = nullptr;
				hWnd = p_hWnd; // necessary for DInput
			}

			virtual ~GameJoystick()
			{
				if (joystickDevice != nullptr)
				{
					joystickDevice->Unacquire();
					joystickDevice->Release();
					// probably shouldn't delete?... it's a system resource polled from DInput
					joystickDevice = nullptr;
				}

				if (dInput != nullptr)
				{ 
					dInput->Release();
					// probably shouldn't delete?... it's a system resource polled
					dInput = nullptr;
				}
			}

			HRESULT Initialize()
			{
				HRESULT hr;

				hr = DirectInput8Create(
					GetModuleHandle(NULL),
					DIRECTINPUT_VERSION,
					IID_IDirectInput8,
					(VOID**)&dInput,
					NULL
					);

				GetJoystick();

				values.Initialize();

				return hr;
			}

			JoystickValues * GetJoystickValues()
			{
				return &values;
			}

		public:
			void Poll()
			{
				PollDevice(&joystickDeviceState);
			}

		private:
			HRESULT PollDevice(DIJOYSTATE2 *js)
			{
				HRESULT     hr;

				values.valid = false; // causes exception when app is ended if joystick is not plugged in

				if (joystickDevice == NULL) {
					return S_OK;
				}

				// Poll the device to read the current state
				// IMPORANT NOTE: This code does NOT like to be debugged - Poll fails, assumed because the cooperative level is generally set to the window level, and the
				//   window is not active within this code
				hr = joystickDevice->Poll();
				if (FAILED(hr)) {
					// DInput is telling us that the input stream has been
					// interrupted. We aren't tracking any state between polls, so
					// we don't have any special reset that needs to be done. We
					// just re-acquire and try again.
					hr = joystickDevice->Acquire();
					while (hr == DIERR_INPUTLOST) {
						hr = joystickDevice->Acquire();
					}

					// If we encounter a fatal error, return failure.
					if ((hr == DIERR_INVALIDPARAM) || (hr == DIERR_NOTINITIALIZED)) {
						return E_FAIL;
					}

					// If another application has control of this device, return successfully.
					// We'll just have to wait our turn to use the joystick.
					if (hr == DIERR_OTHERAPPHASPRIO) {
						return S_OK;
					}
				}

				// Get the input's device state
				if (FAILED(hr = joystickDevice->GetDeviceState(sizeof(DIJOYSTATE2), js))) {
					return hr; // The device should have been acquired during the Poll()
				}

				ConvertDeviceValues();

				return S_OK;
			}

			void ConvertDeviceValues()
			{
				// main joystick
				values.primaryX = joystickDeviceState.lX;
				values.primaryY = joystickDeviceState.lY;

				values.twist = joystickDeviceState.lRz; // main stick twist

				// main buttons
				values.button1Down = (joystickDeviceState.rgbButtons[0] != 0);
				values.button2Down = (joystickDeviceState.rgbButtons[1] != 0);
				values.button3Down = (joystickDeviceState.rgbButtons[2] != 0);
				values.button4Down = (joystickDeviceState.rgbButtons[3] != 0);

				if (((int)joystickDeviceState.rgdwPOV[0]) != -1)
					values.povAngle = joystickDeviceState.rgdwPOV[0] / 100;
				else
					values.povAngle = 0;

				values.valid = true;
			}

			HRESULT GameJoystick::GetJoystick()
			{
				HRESULT hr;

				if (FAILED(hr = dInput->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumJoysticksCallback, NULL, DIEDFL_ATTACHEDONLY)))
				{
					return hr;
				}

				if (joystickDevice == nullptr)
				{
					// no joystick found - nothing will happen on poll
					return hr;
				}
				else
				{
					// we found one, set its properties
					DIDEVCAPS capabilities;

					// Set the data format to "simple joystick" - a predefined data format 
					//
					// A data format specifies which controls on a device we are interested in,
					// and how they should be reported. This tells DInput that we will be
					// passing a DIJOYSTATE2 structure to IDirectInputDevice::GetDeviceState().
					if (FAILED(hr = joystickDevice->SetDataFormat(&c_dfDIJoystick2))) {
						return hr;
					}

					// Set the cooperative level to let DInput know how this device should
					// interact with the system and with other DInput applications.
					// (Dev note: Set to hWnd of the window app - because setting to NULL fails for some reason - no harm for now)
					if (FAILED(hr = joystickDevice->SetCooperativeLevel(hWnd, DISCL_EXCLUSIVE |
						DISCL_FOREGROUND))) {
						return hr;
					}

					// Determine how many axis the joystick has (so we don't error out setting
					// properties for unavailable axis)
					capabilities.dwSize = sizeof(DIDEVCAPS);
					if (FAILED(hr = joystickDevice->GetCapabilities(&capabilities))) {
						return hr;
					}

					// Enumerate the axes of the joyctick and set the range of each axis. Note:
					// we could just use the defaults, but we're just trying to show an example
					// of enumerating device objects (axes, buttons, etc.).
					if (FAILED(hr = joystickDevice->EnumObjects(EnumAxesCallback, NULL, DIDFT_AXIS))) {
						return hr;
					}
				}

				return hr;
			}

			// callbacks must be static
			static BOOL CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE *pdidInstance, VOID *p_Context);
			static BOOL CALLBACK EnumAxesCallback(const DIDEVICEOBJECTINSTANCE* instance, VOID* context);

		};

		class GameInputEventList : protected LinkedList<GameInputEvent>
		{
		public:

			LinkedListEnumerator<GameInputEvent> GetEnumerator()
			{
				return LinkedListEnumerator<GameInputEvent>(*this);
			}

			// not used for now, since each processed in order and then cleared
			//GameInputEvent * GetFrontEvent()
			//{
			//	if (IsEmpty() == false)
			//	{
			//		return (&(GetFirstNode()->data));
			//	}

			//	return nullptr;
			//}

			//GameInputEvent * RemoveFrontEvent()
			//{
			//	if (IsEmpty() == false)
			//	{
			//		DeleteNode(GetFirstNode());
			//	}
			//}

			void Clear()
			{
				LinkedList<GameInputEvent>::Clear();
			}

			void AddEvent(GameInputEvent &p_event)
			{
				LinkedListNode<GameInputEvent> *newNode = GetNewNode();
				newNode->data = p_event;
				AddNode(newNode);
			}
		};

	}
}