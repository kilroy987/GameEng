#pragma once

#include <math.h>

namespace GameEng{
	namespace Math{

		class Vector2d{
		public:
			float x, y;

			Vector2d();
			Vector2d(Vector2d &p_vector2d);
			Vector2d(float p_x, float p_y);

			static Vector2d ZeroVector();
			static Vector2d Vector(float p_x, float p_y);

			Vector2d operator + (const Vector2d &p_vector);
			Vector2d operator - (const Vector2d &p_vector);
			float operator * (const Vector2d &p_vector);

			Vector2d ScalarMult(float p_factor);

			// if both vectors are unit length 1.0, this returns the sin of the angle between them
			float CrossProd(Vector2d &p_vector);

			bool Normalize();
			float Magnitude();
			float MagnitudeSquared();

			void Set(Vector2d &p_vector);
			void Set(float p_x, float p_y);
			bool Equals(Vector2d &p_vector);
		};

		class Vector3d{
		public:
			// VERY important to keep them in this order so that pointer operations like glVertex3fv work properly
			float x, y, z;

			Vector3d();
			Vector3d(Vector3d &p_vector3d);
			Vector3d(float p_x, float p_y, float p_z);

			static Vector3d ZeroVector();
			static Vector3d Vector(float p_x, float p_y, float p_z);

			Vector3d operator + (const Vector3d &p_vector);
			Vector3d operator - (const Vector3d &p_vector);
			float operator * (const Vector3d &p_vector);

			Vector3d ScalarMult(float p_factor);

			// if both vectors are unit length 1.0, the length of the returned vector is the sin of the angle between them
			Vector3d CrossProd(Vector3d &p_vector);

			bool Normalize();
			float Magnitude();
			float MagnitudeSquared();

			void Set(Vector3d &p_vector);
			void Set(float p_x, float p_y, float p_z);
			bool Equals(Vector3d &p_vector);

			void Rotate(Vector3d &p_rotationAxis, float p_degrees, bool p_axisIsUnitLength = true);

			static Vector3d Interpolate(Vector3d &p_start, Vector3d &p_end, float factor);

			System::String ^ToString()
			{
				return System::String::Format("X: {0:0.000}, Y: {1:0.000}, Z: {2:0.000}", x, y, z);
			}
		};

		class Vector4d
		{
		public:
			float x, y, z, w;

			Vector4d();
			Vector4d(Vector4d &p_vector4d);
			Vector4d(float p_x, float p_y, float p_z, float p_w);
			Vector4d(Vector3d &p_vector3d, float p_w);

			void Set(float p_x, float p_y, float p_z, float p_w);
			Vector4d ScalarMult(float p_scalar);
			bool Equals(Vector4d &p_vector);
			bool ApproximatelyEquals(Vector4d &p_vector);
		};
	}
}
