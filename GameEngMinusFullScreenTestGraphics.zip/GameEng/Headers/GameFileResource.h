#pragma once

namespace GameEng {
	namespace Resource {

		// starting over.  this was an ok idea for duplciating a file structure, but it's not necessary for a game resource class.  it's overkill and doesn't well serve the
		//   file reference as "Missions\Textures\Portal1.jpg" model.  Why not just store everything as "folder1\folder2\file1.ext" and let a parser at the beginning figure
		//   out all the paths, and let a secondary folder presented to the app cause overrides?
		// so, see class definition at the bottom.

		//// filename for loading a file resource
		//// ideally, this could really be anything.  Files, binary data for any purpose, etc.  For now, expect all data to be in files
		//public ref class GameFileResource
		//{
		//private:
		//	System::String ^name;
		//	System::String ^diskFilename; // file name as it appears on disk for loading

		//public:
		//	GameFileResource(System::String ^p_resourceName, System::String ^p_diskFilename)
		//	{
		//		name = p_resourceName;
		//		diskFilename = p_diskFilename;
		//	}

		//	System::String ^GetDiskFileName()
		//	{
		//		return diskFilename;
		//	}
		//};

		//// folder for holding files and other folders
		//public ref class GameFileResourceFolder
		//{
		//private:
		//	System::String ^name;
		//	System::Collections::Generic::Dictionary<System::String ^, GameFileResourceFolder^> folders;
		//	System::Collections::Generic::Dictionary<System::String ^, GameFileResource^> files;

		//	void Destroy()
		//	{
		//		for each (System::String ^folder in folders.Keys)
		//		{
		//			delete folders[folder];
		//		}
		//		for each (System::String ^file in files.Keys)
		//		{
		//			delete files[file];
		//		}

		//		folders.Clear();
		//		files.Clear();
		//	}

		//public:
		//	GameFileResourceFolder(System::String ^p_name)
		//	{
		//		name = p_name;
		//	}

		//	virtual ~GameFileResourceFolder()
		//	{
		//		Destroy();
		//	}

		//	GameFileResourceFolder ^ AddFolder(System::String ^p_folderName)
		//	{
		//		if (folders.ContainsKey(p_folderName) == false)
		//		{
		//			folders.Add(p_folderName, gcnew GameFileResourceFolder(p_folderName));
		//			return folders[p_folderName];
		//		}
		//		else
		//			throw gcnew System::Exception("Folder '" + p_folderName + "' already registered");

		//	}

		//	GameFileResourceFolder ^ GetFolder(System::String ^p_folderName)
		//	{
		//		if (FolderExists(p_folderName) == true)
		//			return folders[p_folderName];
		//		else
		//			throw gcnew System::Exception("Folder '" + p_folderName + "' not found");
		//	}

		//	bool FolderExists(System::String ^p_folderName)
		//	{
		//		return folders.ContainsKey(p_folderName);
		//	}

		//	GameFileResource ^ AddFile(System::String ^p_fileName, GameFileResource ^p_resource)
		//	{
		//		if (files.ContainsKey(p_fileName) == false)
		//		{
		//			files.Add(p_fileName, p_resource);
		//			return files[p_fileName];
		//		}
		//		else
		//			throw gcnew System::Exception("File '" + p_fileName + "' already registered");

		//	}

		//	GameFileResource ^ GetFile(System::String ^p_fileName)
		//	{
		//		if (folders.ContainsKey(p_fileName) == true)
		//			return files[p_fileName];
		//		else
		//			throw gcnew System::Exception("File '" + p_fileName + "' not found");
		//	}
		//};

		//// main file resource - has folders, folders can have more folders or files to duplicate a disk structure
		//public ref class GameFileResourceRegistry
		//{
		//	System::Collections::Generic::Dictionary<System::String ^, GameFileResourceFolder^> folders;
		//	System::String ^parentFolderName; // folder name on whatever folder the exe is executed from

		//	void Destroy()
		//	{
		//		for each (System::String ^key in folders.Keys)
		//		{
		//			delete folders[key];
		//		}
		//		folders.Clear();
		//	}

		//public:
		//	GameFileResourceRegistry()
		//	{
		//		parentFolderName = ".";
		//	}

		//	virtual ~GameFileResourceRegistry()
		//	{
		//		Destroy();
		//	}

		//	void Clear()
		//	{
		//		Destroy();
		//	}

		//	void SetParentFolderName(System::String ^p_parentFolderName)
		//	{
		//		parentFolderName = p_parentFolderName;
		//	}

		//	GameFileResourceFolder ^ AddFolder(System::String ^p_folderName)
		//	{
		//		if (folders.ContainsKey(p_folderName) == false)
		//		{
		//			folders.Add(p_folderName, gcnew GameFileResourceFolder(p_folderName));
		//			return folders[p_folderName];
		//		}
		//		else
		//			throw gcnew System::Exception("Folder '" + p_folderName + "' already registered");

		//	}

		//	GameFileResourceFolder ^ GetFolder(System::String ^p_folderPath)
		//	{
		//		array<System::String^, 1>^separator = gcnew array<System::String^, 1>(1) { "\\" };
		//		array<System::String^, 1>^tokens = p_folderPath->Split(separator, System::StringSplitOptions::None);
		//		int maxLevel = tokens->Length;
		//		int currentLevel = 1;
		//		GameFileResourceFolder ^currentFolder = nullptr;
		//		for each(System::String^folder in tokens)
		//		{
		//			if (currentLevel == maxLevel)
		//			{
		//				if (currentFolder == nullptr)
		//				{
		//					if (folders.ContainsKey(folder) == true)
		//						currentFolder = folders[folder];
		//					else
		//						throw gcnew System::Exception("Folder '" + folder + "' not found");
		//				}
		//				else
		//					return currentFolder->GetFolder(folder);
		//			}
		//			else
		//			{
		//				if (currentFolder == nullptr)
		//				{
		//					if (folders.ContainsKey(folder) == true)
		//						currentFolder = folders[folder];
		//					else
		//						throw gcnew System::Exception("Folder '" + folder + "' not found");
		//				}
		//				else
		//					currentFolder = currentFolder->GetFolder(folder);
		//			}

		//			currentLevel++;
		//		}
		//		delete tokens;
		//		tokens = nullptr;
		//		delete separator;
		//		separator = nullptr;
		//	}

		//	GameFileResource ^ GetFile(System::String ^p_filePath)
		//	{
		//		array<System::String^, 1>^separator = gcnew array<System::String^, 1>(1) { "\\" };
		//		array<System::String^, 1>^tokens = p_filePath->Split(separator, System::StringSplitOptions::None);
		//		int maxLevel = tokens->Length;
		//		int currentLevel = 1;
		//		GameFileResourceFolder ^currentFolder = nullptr;
		//		for each(System::String^folder in tokens)
		//		{
		//			if (currentLevel == maxLevel)
		//			{
		//				if (currentFolder == nullptr)
		//					throw gcnew System::Exception("File resources must specify at least one folder deep");
		//				else
		//					return currentFolder->GetFile(folder);
		//			}
		//			else
		//			{
		//				if (currentFolder == nullptr)
		//				{
		//					if (folders.ContainsKey(folder) == true)
		//						currentFolder = folders[folder];
		//					else
		//						throw gcnew System::Exception("Folder '" + folder + "' not found");
		//				}
		//				else
		//					currentFolder = currentFolder->GetFolder(folder);
		//			}

		//			currentLevel++;
		//		}
		//		delete tokens;
		//		tokens = nullptr;
		//		delete separator;
		//		separator = nullptr;
		//	}

		//	// string from which an actual file can be loaded
		//	System::String ^ GetFileDiskPath(System::String ^p_filePath)
		//	{
		//		System::String ^finalPath = parentFolderName;

		//		array<System::String^, 1>^separator = gcnew array<System::String^, 1>(1) { "\\" };
		//		array<System::String^, 1>^tokens = p_filePath->Split(separator, System::StringSplitOptions::None);
		//		int maxLevel = tokens->Length;
		//		int currentLevel = 1;
		//		GameFileResourceFolder ^currentFolder = nullptr;
		//		for each(System::String^folder in tokens)
		//		{
		//			if (currentLevel == maxLevel)
		//			{
		//				if (currentFolder == nullptr)
		//					throw gcnew System::Exception("File resources must specify at least one folder deep");
		//				else
		//				{
		//					finalPath += "\\" + currentFolder->GetFile(folder)->GetDiskFileName();
		//				}
		//			}
		//			else
		//			{
		//				if (currentFolder == nullptr)
		//				{
		//					if (folders.ContainsKey(folder) == true)
		//					{
		//						currentFolder = folders[folder];
		//						finalPath += "\\" + folder;
		//					}
		//					else
		//						throw gcnew System::Exception("Folder '" + folder + "' not found");
		//				}
		//				else
		//				{
		//					currentFolder = currentFolder->GetFolder(folder);
		//					finalPath += "\\" + folder;
		//				}
		//			}

		//			currentLevel++;
		//		}
		//		delete tokens;
		//		tokens = nullptr;
		//		delete separator;
		//		separator = nullptr;

		//		return finalPath;
		//	}


		//	GameFileResource ^ AddFile(System::String ^p_filePath, GameFileResource ^p_fileResource)
		//	{
		//		array<System::String^, 1>^separator = gcnew array<System::String^, 1>(1) { "\\" };
		//		array<System::String^, 1>^tokens = p_filePath->Split(separator, System::StringSplitOptions::None);
		//		int maxLevel = tokens->Length;
		//		int currentLevel = 1;
		//		GameFileResourceFolder ^currentFolder = nullptr;
		//		for each(System::String^folder in tokens)
		//		{
		//			if (currentLevel == maxLevel)
		//			{
		//				if (currentFolder == nullptr)
		//					throw gcnew System::Exception("File resources must specify at least one folder deep");
		//				else
		//				{
		//					return currentFolder->AddFile(folder, p_fileResource);
		//				}
		//			}
		//			else
		//			{
		//				if (currentFolder == nullptr)
		//				{
		//					if (folders.ContainsKey(folder) == true)
		//						currentFolder = folders[folder];
		//					else
		//					{
		//						folders.Add(folder, gcnew GameFileResourceFolder(folder));
		//						currentFolder = folders[folder];
		//					}
		//				}
		//				else
		//				{
		//					if (currentFolder->FolderExists(folder))
		//						currentFolder->GetFolder(folder);
		//					else
		//						currentFolder = currentFolder->AddFolder(folder);
		//				}
		//			}

		//			currentLevel++;
		//		}
		//		delete tokens;
		//		tokens = nullptr;
		//		delete separator;
		//		separator = nullptr;
		//	}
		//};

		public ref class GameFileResource
		{
		private:
			System::String ^resourceFilePath;
			System::String ^diskFilePath; // path to reach file (includes parentFolderName for FileResourceRegistry

		public:
			GameFileResource(System::String ^p_resourceFilePath, System::String ^p_diskFilePath)
			{
				resourceFilePath = p_resourceFilePath;
				diskFilePath = p_diskFilePath;
			}

			System::String ^GetDiskFilePath()
			{
				return diskFilePath;
			}
		};
	}
}