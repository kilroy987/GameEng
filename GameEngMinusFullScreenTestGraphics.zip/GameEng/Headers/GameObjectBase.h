#pragma once

namespace GameEng {
	namespace GameObject {

		using namespace System;

		// prefer an instance rather than a static variable because game could have multiple game object lists, each intended to keep its IDs unique in each list.
		class GameObjectIdCounter
		{
		public:
			GameObjectIdCounter()
			{
				nextId = 1;
			}
			unsigned long nextId;

			unsigned long GetNextId()
			{
				// return current value.  Don't let next value be zero
				int result = nextId++;
				if (nextId == 0)
					nextId++;
				return result;
			}

			void SetNextId(unsigned long p_nextId)
			{
				if (p_nextId != 0)
					nextId = p_nextId;
				else
					throw gcnew Exception("Cannot set Game Object Id counter to zero");
			}
		};

		// a GameObject is a single object in a game that behaves.  A projectile, a creature with AI, etc. and likely with stats like health, velocity, etc.
		// Simpler objects like doors, particles, etc. could be handled differently.
		class GameObjectBase
		{
		public:
			GameObjectBase() // not recommended to call this one, otherwise id will be zero, but fine for implementations that don't require an id to keep things unique
				// - you won't be able to save and reload with references to other objects, and you won't be able to communicate information about an object across the network unless
				//   something else on the object determines which object you will update on the other end
			{
				id = 0;
				deleted = false;
			}

			GameObjectBase(GameObjectIdCounter p_counter)
			{
				Initialize(p_counter);
			}

			bool deleted; // is this object no longer valid? (remains in list for integrity until it is finally removed)
			unsigned long id; // unique id for the primary collection this object is part of

			// call this along with the concrete game object's initialize method
			virtual void Initialize(GameObjectIdCounter &p_counter)
			{
				id = p_counter.GetNextId();
				deleted = false;
			}

			void Delete()
			{
				deleted = true;
			}
		};

		class GameObjectRef
		{
		public:
			GameObjectRef()
			{
				gameObjectRef = nullptr;
			}

			virtual ~GameObjectRef()
			{
				Destroy();
			}

			GameObjectBase *gameObjectRef; // always a reference, never a new instance - object referenced should also be in the same primary list - DO NOT DELETE on Destroy()
			unsigned int expectedId; // id when reference was set - if node is deleted or serves as a new one with a new id for a different purpose, this reference is no longer good

			bool IsValid()
			{
				return (gameObjectRef != nullptr);
			}

			bool IsDeleted()
			{
				if (gameObjectRef != nullptr)
				{
					if (gameObjectRef->deleted)
						return true;
					if (gameObjectRef->id != expectedId)
						return true;
					return false;
				}
				else
					throw gcnew Exception("GameObject reference is null");
			}

			unsigned long Id()
			{
				if (gameObjectRef != nullptr)
					return gameObjectRef->id;
				else
					throw gcnew Exception("GameObject reference is null");
			}

			void Set(GameObjectBase *p_gameObjectRef)
			{
				if (p_gameObjectRef == nullptr)
					Clear();
				else
				{
					gameObjectRef = p_gameObjectRef;
					expectedId = p_gameObjectRef->id;
				}
			}

			void Destroy()
			{
				Clear();
			}

			void Clear()
			{
				gameObjectRef = nullptr;
				expectedId = 0;
			}

			GameObjectBase * Ptr()
			{
				return gameObjectRef;
			}
		};
	} // namespace GameObject
} // namespace GameEng
