#pragma once

#include "LinkedListTemplate.h"
#include "GraphicsBase.h"
#include "GameContext.h"
#include "GameInput.h"
#include "Tools.h"
#include "GameViewport.h"

// Important note:  I have questions about how the control delegates to form actually worked.  GameUIControl has a reference to GameUIForm for its delegate definitions and the delegate calls themselves.
// Second derivations of forms work.  But using GameUIFormBase as the pointer failed to recognize values of pointers inside the implementation class, so I had to change them to GameUIForm
// It works, I don't entirely understand it, not touching it.

namespace GameEng {
	namespace UI
	{
		using namespace GameEng::Storage;
		using namespace System::Drawing;
		using namespace GameEng::Graphics;
		using namespace GameEng::Game;
		using namespace GameEng::Input;
		using namespace GameEng::Tools::Timer;

		class GameUIAspect
		{
		private:
			RectangleF rect; // position and dimension in viewport
			bool visible;
			bool enabled;
			GameColor foreColor;
			GameColor backColor;
			GameColor borderColor;
			GameColor disabledForeColor;
			gcroot<GameFont ^> fontRef;

		public:
			GameUIAspect()
			{
				Initialize();
			}

			GameUIAspect(RectangleF &p_rect)
			{
				rect = p_rect;
				Initialize();
			}

			void Initialize()
			{
				visible = true;
				enabled = true;

				foreColor.Set(255, 255, 255);
				backColor.Set(64, 64, 64);
				borderColor.Set(255, 255, 255);

				fontRef = nullptr;
			}

			bool PointIsInside(float p_x, float p_y)
			{
				if (p_x >= rect.Left && p_x < rect.Left + rect.Width && p_y >= rect.Top && p_y < rect.Top + rect.Height)
					return true;

				return false;
			}

			bool PointIsInside(PointF &p_point)
			{
				return PointIsInside(p_point.X, p_point.Y);
			}

			bool IsVisible()
			{
				return visible;
			}

			bool Hide()
			{
				// return true if there was a change

				if (visible == true)
				{
					visible = false;
					return true;
				}

				return false;
			}

			// overridden by GameUIForm
			bool Show()
			{
				// return true if there was a change

				if (visible == false)
				{
					visible = true;
					return true;
				}

				return false;
			}

			bool IsEnabled()
			{
				return enabled;
			}

			bool Disable()
			{
				// return true if there was a change

				if (enabled == true)
				{
					enabled = false;
					return true;
				}

				return false;
			}

			bool Enable()
			{
				// return true if there was a change

				if (enabled == false)
				{
					enabled = true;
					return true;
				}

				return false;
			}

			bool SetPosition(RectangleF &p_rect)
			{
				bool returnValue = false;
				if (p_rect.Left != rect.Left)
					returnValue = true;
				if (p_rect.Top != rect.Top)
					returnValue = true;
				if (p_rect.Height != rect.Height)
					returnValue = true;
				if (p_rect.Width != rect.Width)
					returnValue = true;
				rect = p_rect;

				// if only position change, fire event moved
				// if size changed, fire event resized
				// todo: or have routine for setting size and position specifically
				// might as well make this a form level function where the events can be fired
				return false;
			}

			void SetLocation(PointF &p_location)
			{
				bool change = false;
				if (p_location.X != rect.Left)
					change = true;
				if (p_location.Y != rect.Top)
					change = true;

				if (change == true)
				{
					rect.X = p_location.X;
					rect.Y = p_location.Y;
				}
			}

			void SetSize(PointF &p_size)
			{
				bool change = false;
				if (p_size.X != rect.Width)
					change = true;
				if (p_size.Y != rect.Height)
					change = true;

				if (change == true)
				{
					rect.Width = p_size.X;
					rect.Height = p_size.Y;
				}
			}

			RectangleF GetRect()
			{
				RectangleF copy = rect;
				return copy;
			}

			GameColor GetBackColor()
			{
				GameColor copy = backColor;
				return copy;
			}

			GameColor GetForeColor()
			{
				GameColor copy = foreColor;
				return copy;
			}

			GameColor GetBorderColor()
			{
				GameColor copy = borderColor;
				return copy;
			}

			void SetBackColor(GameColor &p_color)
			{
				backColor = p_color;
			}

			void SetForeColor(GameColor &p_color)
			{
				foreColor = p_color;
			}

			void SetBorderColor(GameColor &p_color)
			{
				borderColor = p_color;
			}

			virtual bool AcceptsFocus()
			{
				return false;
			}
		};

		enum class GameUITextHorizontalAlignment
		{
			Left,
			Center,
			Right
		};

		enum class GameUITextVerticalAlignment
		{
			Top,
			Center,
			Bottom
		};

		class GameUITextAspect
		{
		private:
			gcroot<String ^> text;
			gcroot<GameFont^> fontRef; // don't destroy this.

			GameUITextHorizontalAlignment horizontalAlignment;
			GameUITextVerticalAlignment verticalAlignment;

		public:
			GameUITextAspect()
			{
				text = "";
				fontRef = nullptr;

				horizontalAlignment = GameUITextHorizontalAlignment::Left;
				verticalAlignment = GameUITextVerticalAlignment::Center;
			}

			~GameUITextAspect()
			{
				if (static_cast<String ^>(text) != nullptr)
				{
					delete text;
					text = nullptr;
				}
			}

			virtual void SetText(String ^p_text)
			{
				text = p_text;
			}

			void SetFont(GameFont ^p_font)
			{
				fontRef = p_font;
			}

			String ^ GetText()
			{
				return text;
			}

			GameFont ^ GetFont()
			{
				return fontRef;
			}

			void SetTextHorizontalAlignment(GameUITextHorizontalAlignment p_horizontalAlignment)
			{
				horizontalAlignment = p_horizontalAlignment;
			}

			void SetTextVerticalAlignment(GameUITextVerticalAlignment p_verticalAlignment)
			{
				verticalAlignment = p_verticalAlignment;
			}

			GameUITextHorizontalAlignment GetTextHorizontalAlignment()
			{
				return horizontalAlignment;
			}

			GameUITextVerticalAlignment GetTextVerticalAlignment()
			{
				return verticalAlignment;
			}
		};

		class GameUIEditableTextAspect : public GameUITextAspect
		{
		public:
			GameColor highlightColor;
			GameColor highlightForeColor; // how does forecolor change when highlighting occurs?
			GameColor disabledHighlightColor; // how does disabling affect the highlight color?

			int maxLength;
			// highlighting variables (start and stop characters), cursor position?  cursor timer (or should cursor timer be global to GameUI because only one control can possibly have input focus?)
			int highlightStartCharacter;
			int highlightLength; // = 0 means no highlight

			int caretIndexPosition; // display caret BEFORE the character.  If at end of string, position is length.
			int pixelStartOffset; // affects side scrolling of text - 0 or less - smaller values scroll to the right

			GameUIEditableTextAspect()
			{
				highlightColor = GameColor(51, 153, 255); // matching default Windows
				highlightForeColor = GameColor(255, 255, 255);
				disabledHighlightColor = GameColor(128, 255, 128);

				maxLength = 255; // default

				ClearHighlighting();
				ResetCaretPosition();
				ResetPixelStartOffset();
			}

			virtual void SetText(String ^p_text)
			{
				String ^text = p_text;
				if (text->Length > maxLength)
					text = text->Substring(0, maxLength);

				GameUITextAspect::SetText(text);

				// adjust highlighting for text
				VerifySelection();
			}

			virtual void SetMaxLength(int p_maxLength)
			{
				if (p_maxLength < 0)
					throw gcnew Exception("Max length must be >= 0");
				if (p_maxLength > 32767)
					throw gcnew Exception("Max length is 32767 currently");

				maxLength = p_maxLength;
				// correct text if needed
				String ^text = GetText();
				if (text->Length > maxLength)
				{
					text = text->Substring(0, maxLength);

					GameUITextAspect::SetText(text);
				}

				// adjust highlighting for text
				// todo: might need more here if set max length with existing text
				VerifySelection();
			}

			void SetSelectionStart(int p_startChar)
			{
				highlightStartCharacter = p_startChar;
				VerifySelection();
			}

			void SetSelectionLength(int p_selectionLength)
			{
				if (p_selectionLength < 0)
					throw gcnew Exception("Length must be >= 0");
				highlightLength = p_selectionLength;
				VerifySelection();
			}

			int GetSelectionStart()
			{
				return highlightStartCharacter;
			}

			int GetSelectionLength()
			{
				return highlightLength;
			}

		protected:

			void VerifySelection()
			{
				int textLength = GetText()->Length;
				if (highlightLength != 0)
				{
					if (textLength < highlightStartCharacter + highlightLength)
					{
						highlightLength -= ((highlightStartCharacter + highlightLength) - textLength);
						if (highlightLength <= 0)
							ClearHighlighting();
					}
				}
			}

			void ClearHighlighting()
			{
				highlightLength = 0; // 0 denotes no highlighting
			}

			void ResetCaretPosition()
			{
				caretIndexPosition = 0;
			}

			int GetCaretPosition()
			{
				return caretIndexPosition;
			}

			void SetCaretPosition(int p_position)
			{
				caretIndexPosition = p_position;
				VerifyCaretPosition();
			}

			void VerifyCaretPosition()
			{
				if (caretIndexPosition > GetText()->Length)
					caretIndexPosition = GetText()->Length;
				if (caretIndexPosition < 0)
					caretIndexPosition = 0;
			}

			void ResetPixelStartOffset()
			{
				pixelStartOffset = 0;
			}

			void SetPixelStartOffset(int p_pixelStartOffset)
			{
				pixelStartOffset = p_pixelStartOffset;
			}

			int GetPixelStartOffset()
			{
				return pixelStartOffset;
			}
		};

		class GameUIButtonAspect : public GameUITextAspect
		{
		private:
			GameColor mouseDownColor; // what color should button be if down?
			bool mouseIsDown; 
			bool renderAsDown; // guides rendering
			bool mouseHasEntered;

			friend class GameUIButton;
			friend class GameUI;

			GameUIButtonAspect()
			{
				mouseDownColor.Set(192, 192, 192);
				mouseIsDown = false;
				renderAsDown = false;
				mouseHasEntered = false;
			}
		};

		class MouseMoveArgs
		{
		public:
			Point control; // mouse position relative to the control, if any - (0,0) if not a form event
			Point form; // mouse position relative to the form
			Point scene; // mouse position relative to the scene

			friend class GameUI;

			MouseMoveArgs(GameMouse ^p_gameMouse, GameUIFormBase *p_form, GameUIControlBase *p_control = nullptr)
			{
				Populate(p_gameMouse, p_form, p_control);
			}

		private:
			void Populate(GameMouse ^p_gameMouse, GameUIFormBase *p_form, GameUIControlBase *p_control);
		};

		class GameKeyEventArgs
		{
		public:
			int keyCode;
			bool shift;
			bool ctrl;
			bool alt;
			bool suppress;

			GameKeyEventArgs(int p_keyCode, bool p_shift, bool p_ctrl, bool p_alt)
			{
				keyCode = p_keyCode;
				shift = p_shift;
				ctrl = p_ctrl;
				alt = p_alt;

				suppress = false;
			}
		};

		class GameKeyPressEventArgs
		{
		public:
			char key;
			bool suppress;

			GameKeyPressEventArgs(char p_key)
			{
				key = p_key;
				suppress = false;
			}
		};

		class GameUIControl : public GameUIAspect, public GameUIControlBase
		{
			friend class GameUI;
			friend class GameUIForm;
			friend class GameUIButton;

		public:
			// delegates for events
			// don't know why this works right now
			typedef void(GameUIForm::* GameUIMouseEntered)(void);
			typedef void(GameUIForm::* GameUIMouseLeft)(void);
			typedef void(GameUIForm::* GameUIMouseUp)(MouseButton);
			typedef void(GameUIForm::* GameUIMouseDown)(MouseButton);
			typedef void(GameUIForm::* GameUIMouseMove)(MouseMoveArgs &);

			typedef void(GameUIForm::* GameUIKeyDown)(GameKeyEventArgs &);
			typedef void(GameUIForm::* GameUIKeyPress)(GameKeyPressEventArgs &);
			typedef void(GameUIForm::* GameUIKeyUp)(GameKeyEventArgs &);

			typedef void(GameUIForm::* GameUIOnBlur)(void);
			typedef void(GameUIForm::* GameUIOnFocus)(void);

		protected:
			bool hasFocus;
			GameUIForm *parentFormRef; // this is of this type here, but must be cast by routines that use it. only a reference, do not destroy

		protected:
			GameUIMouseEntered mouseEntered;
			GameUIMouseLeft mouseLeft;
			GameUIMouseDown mouseDown;
			GameUIMouseUp mouseUp;
			GameUIMouseMove mouseMove;

			GameUIKeyDown keyDown;
			GameUIKeyPress keyPress;
			GameUIKeyUp keyUp;

			GameUIOnBlur onBlur;
			GameUIOnFocus onFocus;

			bool acceptsTab;

		private:
			void Destroy()
			{

			}

		public:
			GameUIControl(RectangleF &p_rect) : GameUIAspect(p_rect)
			{
				hasFocus = false;
				parentFormRef = nullptr;

				mouseEntered = nullptr;
				mouseLeft = nullptr;
				mouseDown = nullptr;
				mouseUp = nullptr;
				mouseMove = nullptr;
				keyDown = nullptr;
				keyPress = nullptr;
				keyUp = nullptr;
				onBlur = nullptr;
				onFocus = nullptr;

				acceptsTab = false;
			}

			virtual ~GameUIControl()
			{
				Destroy();
			}

			virtual void Render(PointF &p_parentRect, GraphicsBase *p_graphics, int p_startingStencilValue)
			{
				ModelVertex controlVertices[5] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
				RectangleF baseRect = GetRect();
				RectangleF rect(baseRect.Left + p_parentRect.X, baseRect.Top + p_parentRect.Y, baseRect.Width, baseRect.Height);
				// render with clip aspects against parent form

				// render control background and border
				// 12
				// 03
				controlVertices[0].vertex.Set(rect.Left, rect.Top + rect.Height, 0.0f);
				controlVertices[0].colorIndex = 0;
				controlVertices[1].vertex.Set(rect.Left, rect.Top, 0.0f);
				controlVertices[1].colorIndex = 0;
				controlVertices[2].vertex.Set(rect.Left + rect.Width, rect.Top, 0.0f);
				controlVertices[2].colorIndex = 0;
				controlVertices[3].vertex.Set(rect.Left + rect.Width, rect.Top + rect.Height, 0.0f);
				controlVertices[3].colorIndex = 0;
				controlVertices[4].vertex.Set(rect.Left, rect.Top + rect.Height, 0.0f);
				controlVertices[4].colorIndex = 0;

				// todo: if there are any child controls, take care of stencil so that child controls can be rendered. (render background with increment stencil, then render child controls, then
				//   restore background stencil and draw border)

				// background
				bool useStencil = true; // for debugging, making sure only the necessaries are rendered as they are clipped
				RenderBackground(p_graphics, controlVertices, p_startingStencilValue, useStencil);
				// contents if any
				RenderContents(p_graphics, controlVertices);
				PostRenderContents(p_graphics, controlVertices, p_startingStencilValue, useStencil);
				// border
				RenderBorder(p_graphics, controlVertices);
			}

		protected:
			virtual void RenderBackground(GraphicsBase *p_graphics, ModelVertex *p_vertices, int p_baseStencilValue = 0, bool p_useStencil = true)
			{
				// render stencil area
				if (p_useStencil == true)
				{
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_baseStencilValue, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Increment, GraphicsStencilOperationEnum::Increment, GraphicsStencilOperationEnum::Increment);
				}

				p_graphics->RenderFilledQuad(&GetBackColor(), 1, p_vertices, 4, true);

				if (p_useStencil == true)
				{
					// clip contents
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_baseStencilValue + 1, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				}
			}

			virtual void RenderContents(GraphicsBase *p_graphics, ModelVertex *p_vertices)
			{
				// overridden by implementation of control
			}

			virtual void PostRenderContents(GraphicsBase *p_graphics, ModelVertex *p_vertices, int p_baseStencilValue = 0, bool p_useStencil = true)
			{
				// unclip contents
				if (p_useStencil == true)
				{
					p_graphics->ColorMask(false, false, false, false);
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_baseStencilValue + 1, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Decrement, GraphicsStencilOperationEnum::Decrement, GraphicsStencilOperationEnum::Decrement);

					p_graphics->RenderFilledQuad(&GetBackColor(), 1, p_vertices, 4, true); // color doesn't matter here

					p_graphics->ColorMask(true, true, true, true);

					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_baseStencilValue, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				}
			}

			virtual void RenderBorder(GraphicsBase *p_graphics, ModelVertex *p_vertices)
			{
				p_graphics->RenderLineStrip(1.0f, &GetBorderColor(), 1, p_vertices, 5, true);
			}

			void Hide()
			{
				if (IsVisible() == true)
				{
					GameContext::Instance->GetUI()->HideControl(this);

					Inactivated();

					GameUIAspect::Hide();
				}
			}

			virtual void Inactivated()
			{
				// special maintenance to be done on control when the form is closed, hidden or inactivated, or control is inactivated or hidden
			}

		public:
			bool HasFocus()
			{
				return hasFocus;
			}

			bool AcceptsTab()
			{
				return acceptsTab;
			}

			void SetAcceptsTab(bool p_acceptsTab)
			{
				acceptsTab = p_acceptsTab;
			}
			
			// in .cpp
			void Focus();

			GameUIForm * GetParentForm()
			{
				return parentFormRef;
			}

			void SetMouseEntered(GameUIMouseEntered p_mouseEntered)
			{
				mouseEntered = p_mouseEntered;
			}

			void SetMouseLeft(GameUIMouseLeft p_mouseLeft)
			{
				mouseLeft = p_mouseLeft;
			}

			void SetMouseDown(GameUIMouseDown p_mouseDown)
			{
				mouseDown = p_mouseDown;
			}

			void SetMouseUp(GameUIMouseUp p_mouseUp)
			{
				mouseUp = p_mouseUp;
			}

			void SetMouseMove(GameUIMouseMove p_mouseMove)
			{
				mouseMove = p_mouseMove;
			}

			void SetKeyDown(GameUIKeyDown p_keydown)
			{
				keyDown = p_keydown;
			}

			void SetKeyPress(GameUIKeyPress p_keyPress)
			{
				keyPress = p_keyPress;
			}

			void SetKeyUp(GameUIKeyUp p_keyUp)
			{
				keyUp = p_keyUp;
			}

			void SetOnBlur(GameUIOnBlur p_onBlur)
			{
				onBlur = p_onBlur;
			}

			void SetOnFocus(GameUIOnBlur p_onFocus)
			{
				onFocus = p_onFocus;
			}

			// friend functions
		private:
			void SetFocus()
			{
				// this does not fire an event - that is handled at the control process level in GameUI by calling Blur()
				hasFocus = true;
			}

			void ClearFocus()
			{
				// this does not fire an event - that is handled at the control process level in GameUI by calling GainedFocus()
				hasFocus = false;
			}

			void SetParentForm(GameUIForm *p_parentForm)
			{
				parentFormRef = p_parentForm;
			}

			virtual bool RendersCaret()
			{
				return false;
			}

		protected:
			////////////////////////////////////////
			// event triggers from GameUI processing
			virtual void MouseEntered(bool p_callEvent)
			{
				// Trigger MouseEntered event
				if (mouseEntered != nullptr && p_callEvent == true)
				{
					((GameUIForm *)(parentFormRef)->*mouseEntered)();
				}
			}

			virtual void MouseLeft(bool p_callEvent)
			{
				// Trigger MouseLeft event
				if (mouseLeft != nullptr && p_callEvent == true)
				{
					((GameUIForm *)(parentFormRef)->*mouseLeft)();
				}
			}

			virtual void MouseDown(MouseButton p_button)
			{
				// Trigger MouseDown event
				if (mouseDown != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*mouseDown)(p_button);
				}
			}

			virtual void MouseUp(MouseButton p_button)
			{
				// Trigger MouseUp event
				if (mouseUp != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*mouseUp)(p_button);
				}
			}

			virtual void MouseMoved(MouseMoveArgs &p_moveArgs)
			{
				// Trigger MouseUp event
				if (mouseMove != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*mouseMove)(p_moveArgs);
				}
			}

			virtual void KeyDown(GameKeyEventArgs &p_keyArgs)
			{
				// Trigger KeyDown event
				if (keyDown != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*keyDown)(p_keyArgs);
				}
			}

			virtual void KeyPress(GameKeyPressEventArgs &p_keyArgs)
			{
				// Trigger KeyPress event
				if (keyPress != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*keyPress)(p_keyArgs);
				}
			}

			virtual void KeyUp(GameKeyEventArgs &p_keyArgs)
			{
				// Trigger KeyUp event
				if (keyUp != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*keyUp)(p_keyArgs);
				}
			}

			virtual void Blur()
			{
				if (onBlur != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*onBlur)();
				}
			}

			virtual void GainedFocus()
			{
				if (onFocus != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*onFocus)();
				}
			}
		};

#pragma region Controls
		// specific controls
		class GameUIButton : public GameUIControl, public GameUIButtonAspect
		{
		public:
			// delegates for events
			typedef void(GameUIForm::* GameUIClick)(void);

			GameUIButton(RectangleF &p_rect) : GameUIControl(p_rect)
			{
				click = nullptr;
				focusColor.Set(128, 128, 128);
				enteredColor.Set(96, 96, 96);
			}

			void SetClick(GameUIClick p_click)
			{
				click = p_click;
			}

			bool AcceptsFocus() override
			{
				return true;
			}

			void SetFocusColor(GameColor &p_color)
			{
				focusColor = p_color;
			}

			GameColor GetFocusColor()
			{
				GameColor copy = focusColor;
				return copy;
			}

			void SetEnteredColor(GameColor &p_color)
			{
				focusColor = p_color;
			}

			GameColor GetEnteredColor()
			{
				GameColor copy = enteredColor;
				return copy;
			}

		private:
			GameUIClick click;
			GameColor focusColor; // color when has focus but not down
			GameColor enteredColor; // color when mouse has entered but nto downed yet

		protected:
			virtual void RenderBackground(GraphicsBase *p_graphics, ModelVertex *p_vertices, int p_baseStencilValue = 0, bool p_useStencil = true) override
			{
				if (p_useStencil == true)
				{
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_baseStencilValue, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Increment, GraphicsStencilOperationEnum::Increment, GraphicsStencilOperationEnum::Increment);
				}

				if (renderAsDown == false)
				{
					if (hasFocus == false)
					{
						if (mouseHasEntered == false)
							p_graphics->RenderFilledQuad(&GetBackColor(), 1, p_vertices, 4, true);
						else
							p_graphics->RenderFilledQuad(&GetEnteredColor(), 1, p_vertices, 4, true);
					}
					else
						p_graphics->RenderFilledQuad(&GetFocusColor(), 1, p_vertices, 4, true);
				}
				else
					p_graphics->RenderFilledQuad(&mouseDownColor, 1, p_vertices, 4, true);

				if (p_useStencil == true)
				{
					p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, p_baseStencilValue + 1, 0xff);
					p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				}
			}

			virtual void RenderContents(GraphicsBase *p_graphics, ModelVertex *p_vertices) override
			{
				String ^caption = GetText();
				if (caption == "")
					return;

				GameFont ^font = GetFont();
				if (font == nullptr)
					throw gcnew Exception("Font not set on button");

				// p_vertices understood to be // ll, ul, ur, lr, ll.  so [1] holds the upper left coordinate for text rendering.  [3] holds lower right
				float centerX = (p_vertices[1].vertex.x + p_vertices[3].vertex.x) / 2.0f;
				float centerY = (p_vertices[1].vertex.y + p_vertices[3].vertex.y) / 2.0f;
				if (renderAsDown == true)
				{
					// shift text to the lr
					centerX++; centerY++;
				}
				Point textSize = font->GetTextSize(caption);
				int x = int(centerX - float(textSize.X) / 2.0f);
				int y = int(centerY - float(textSize.Y) / 2.0f);
				p_graphics->RenderFont(caption, font, x, y, GetForeColor());
			}

			virtual void RenderBorder(GraphicsBase *p_graphics, ModelVertex *p_vertices) override;

			virtual void Inactivated() override
			{
				mouseIsDown = false;
				renderAsDown = false;
			}

			virtual void MouseEntered(bool p_callEvent) override
			{
				if (mouseIsDown == true && hasFocus == true)
					renderAsDown = true;
				mouseHasEntered = true;

				GameUIControl::MouseEntered(p_callEvent);
			}

			virtual void MouseLeft(bool p_callEvent) override
			{
				if (mouseIsDown == true)
					renderAsDown = false;
				mouseHasEntered = false;

				GameUIControl::MouseLeft(p_callEvent);
			}

			virtual void MouseDown(MouseButton p_mouseButton) override
			{
				GameUIControl::MouseDown(p_mouseButton);

				if (p_mouseButton == MouseButton::Left)
				{
					mouseIsDown = true;
					if (hasFocus == true) // it's possible for the MouseDown call to cause this control to lose focus.  In that case, don't click button but still have a mouse over highlight
						renderAsDown = true;
				}
			}

			virtual void MouseUp(MouseButton p_mouseButton) override
			{
				if (renderAsDown == true) // mouse is down and on top of it
					Click();

				mouseIsDown = false;
				renderAsDown = false;

				GameUIControl::MouseUp(p_mouseButton);
			}

			virtual void Click()
			{
				// Trigger MouseEntered event
				if (click != nullptr)
				{
					((GameUIForm *)(parentFormRef)->*click)();
				}
			}
		};

		class GameUILabel : public GameUIControl, public GameUITextAspect
		{
		public:

			GameUILabel(RectangleF &p_rect) : GameUIControl(p_rect)
			{
			}

		protected:

			virtual void RenderContents(GraphicsBase *p_graphics, ModelVertex *p_vertices)
			{
				String ^caption = GetText();
				if (caption == "")
					return;

				GameFont ^font = GetFont();
				if (font == nullptr)
					throw gcnew Exception("Font not set on label");

				// p_vertices understood to be // ll, ul, ur, lr, ll.  so [1] holds the upper left coordinate for text rendering.  [3] holds lower right
				float centerX = (p_vertices[1].vertex.x + p_vertices[3].vertex.x) / 2.0f;
				float centerY = (p_vertices[1].vertex.y + p_vertices[3].vertex.y) / 2.0f;

				Point textSize = font->GetTextSize(caption);
				int x, y;
				switch (GetTextHorizontalAlignment())
				{
				case GameUITextHorizontalAlignment::Left:
					x = int(p_vertices[1].vertex.x);
					break;
				case GameUITextHorizontalAlignment::Center:
					x = int(centerX - float(textSize.X) / 2.0f);
					break;
				case GameUITextHorizontalAlignment::Right:
					x = int(p_vertices[2].vertex.x - textSize.X);
					break;
				}
				switch (GetTextVerticalAlignment())
				{
				case GameUITextVerticalAlignment::Top:
					y = int(p_vertices[1].vertex.y);
					break;
				case GameUITextVerticalAlignment::Center:
					y = int(centerY - float(textSize.Y) / 2.0f);
					break;
				case GameUITextVerticalAlignment::Bottom:
					y = int(p_vertices[0].vertex.y - textSize.Y);
					break;
				}
				p_graphics->RenderFont(caption, font, x, y, GetForeColor());
			}

			virtual void RenderBorder(GraphicsBase *p_graphics, ModelVertex *p_vertices)
			{
				// labels have no borders
			}
		};

		class GameUITextBox : public GameUIControl, public GameUIEditableTextAspect
		{
		public:

			GameUITextBox(RectangleF &p_rect) : GameUIControl(p_rect)
			{
				mouseIsDown = false;
				highlightCaretStartPosition = -1;
			}

			// mouse position is relative to control
			int GetTextIndexPosition(Point &p_mousePosition)
			{
				GameFont ^font = GetFont();
				String ^text = GetText();

				int renderStartPositionX = int(GetTextRenderRectangle().Left) + GetPixelStartOffset();
				int mouseXTest = p_mousePosition.X - renderStartPositionX;
				if (mouseXTest < 0)
					// left of text - return zero
					return 0;
				int mouseXLeft = 0;
				// last half of letter places position at end of that character (the mouse pointer isn't quite lined up visually, so psychologically it's the last third or so)
				int length = GetText()->Length;
				for (int i = 0; i < length; i++)
				{
					Point charWidth = font->GetTextSize(text->Substring(i,1));
					if (float(mouseXTest) < (float(mouseXLeft) + float(charWidth.X) * 0.50f))
						return i;
					mouseXLeft += charWidth.X;
				}

				// not found - return length as result
				return length;
			}

			void SelectAll()
			{
				ClearHighlighting();
				SetSelectionStart(0);
				SetSelectionLength(GetText()->Length);

				// act as if we moved to the front, held shift then jumped to the end
				// todo: this might interfere whiel mouse downing, etc.  more behavior will need to be determined
				MoveCaretToPosition(0, true, false, false);
				// force start of caret select to beginning
				if (highlightCaretStartPosition != -1)
					highlightCaretStartPosition = 0;
				MoveCaretToPosition(GetText()->Length, true, true, false);
			}

		protected:

			Point mousePosition;
			bool mouseIsDown;
			int highlightCaretStartPosition; // helps guide selecting text, both mouse and keyboard.  When -1, keyboard shift down event sets this.

			// relative to control
			RectangleF GetTextRenderRectangle()
			{
				Point textSize = GetFont()->GetTextSize("W");
				// x: allow 1 margin to avoid border and another to provide a little dead space for rendering of caret
				// vertical is just centered despite any loss (make control taller (textHeight + 4) to accommodate)
				return RectangleF(2.0f, GetRect().Height / 2.0f - textSize.Y / 2.0f, GetRect().Width - 4.0f, float(textSize.Y));
			}

			bool AcceptsFocus() override
			{
				return true;
			}

			bool RendersCaret() override
			{
				return true;
			}

			virtual void MouseMoved(MouseMoveArgs &p_moveArgs)
			{
				mousePosition = p_moveArgs.control;
				if (mouseIsDown == true)
				{
					// figure out where caret should go
					int oldCaretPosition = GetCaretPosition();
					MoveCaretToPosition(GetTextIndexPosition(mousePosition), true, true, false);
					if (oldCaretPosition != caretIndexPosition)
						// if moved, reset blinking
						GameContext::Instance->GetUI()->ResetCaret();
					/*
					SetCaretPosition(GetTextIndexPosition(mousePosition));

					// highlight text - set in proper order to prevent validation from halting attempt
					if (GetCaretPosition() <= highlightCaretStartPosition)
					{
						if (GetSelectionLength() < highlightCaretStartPosition - GetCaretPosition())
						{
							SetSelectionStart(GetCaretPosition());
							SetSelectionLength(highlightCaretStartPosition - GetCaretPosition());
						}
						else
						{
							SetSelectionLength(highlightCaretStartPosition - GetCaretPosition());
							SetSelectionStart(GetCaretPosition());
						}
					}
					else
					{
						if (GetSelectionLength() < GetCaretPosition() - highlightCaretStartPosition)
						{
							SetSelectionStart(highlightCaretStartPosition);
							SetSelectionLength(GetCaretPosition() - highlightCaretStartPosition);
						}
						else
						{
							SetSelectionLength(GetCaretPosition() - highlightCaretStartPosition);
							SetSelectionStart(highlightCaretStartPosition);
						}
					}
					*/
				}

				GameUIControl::MouseMoved(p_moveArgs);
			}

			virtual void MouseDown(MouseButton p_mousebutton)
			{
				if (p_mousebutton == MouseButton::Left)
				{
					mouseIsDown = true;

					// figure out where caret should go
					int oldCaretPosition = GetCaretPosition();
					MoveCaretToPosition(GetTextIndexPosition(mousePosition), false, false, false);
					if (oldCaretPosition != GetCaretPosition())
						// if moved, reset blinking
						GameContext::Instance->GetUI()->ResetCaret();

					// Initialize selection
					SetSelectionLength(0);
					SetSelectionStart(GetCaretPosition());
					// track where selection started (works with mouse drag, and also saves it for mouse lift and SHIFT operations)
					highlightCaretStartPosition = GetCaretPosition();
				}

				GameUIControl::MouseDown(p_mousebutton);
			}

			virtual void MouseUp(MouseButton p_mousebutton)
			{
				if (p_mousebutton == MouseButton::Left)
				{
					mouseIsDown = false;
				}

				GameUIControl::MouseUp(p_mousebutton);
			}

			virtual void KeyDown(GameKeyEventArgs &p_eventArgs)
			{
				GameUIControl::KeyDown(p_eventArgs);

				if (mouseIsDown == false && p_eventArgs.suppress == false)
				{
					switch (System::Windows::Forms::Keys(p_eventArgs.keyCode))
					{
					case System::Windows::Forms::Keys::A:
						if (p_eventArgs.ctrl == true) // ctrl A selects all
						{
							SetSelectionStart(0);
							SetSelectionLength(GetText()->Length);
							MoveCaretToPosition(GetText()->Length, false, false, false);
							highlightCaretStartPosition = 0; // in case user uses shift and arrows to adjust later
						}
						break;
					case System::Windows::Forms::Keys::C:
						if (p_eventArgs.ctrl == true && GetSelectionLength() > 0) // ctrl C copies selection to clipboard
						{
							String ^text = GetText()->Substring(GetSelectionStart(), GetSelectionLength());
							System::Windows::Forms::Clipboard::SetText(text);
						}
						break;
					case System::Windows::Forms::Keys::X:
						if (p_eventArgs.ctrl == true && GetSelectionLength() > 0) // ctrl X cuts selection to clipboard
						{
							String ^text = GetText()->Substring(GetSelectionStart(), GetSelectionLength());
							System::Windows::Forms::Clipboard::SetText(text);
							DeleteAtCaret(p_eventArgs.shift);
						}
						break;
					case System::Windows::Forms::Keys::Delete:
						if (p_eventArgs.shift == true && GetSelectionLength() > 0) // shift Delete cuts selection to clipboard
						{
							String ^text = GetText()->Substring(GetSelectionStart(), GetSelectionLength());
							System::Windows::Forms::Clipboard::SetText(text);
							DeleteAtCaret(p_eventArgs.shift);
						}
						else
							DeleteAtCaret(p_eventArgs.shift); // shift del with no selection just performs a normal Delete with no copy to clipboard
						break;
					case System::Windows::Forms::Keys::V:
						if (p_eventArgs.ctrl == true) // ctrl V pastes from clipboard
						{
							String ^text = System::Windows::Forms::Clipboard::GetText();
							InsertOrReplaceText(text); // even if text on clipboard is "", replace what is highlighted or insert at caret
						}
						break;
					case System::Windows::Forms::Keys::Insert:
						if (p_eventArgs.shift == true) // shift insert pastes from clipboard
						{
							String ^text = System::Windows::Forms::Clipboard::GetText();
							InsertOrReplaceText(text); // even if text on clipboard is "", replace what is highlighted or insert at caret
						}
						break;
					case System::Windows::Forms::Keys::Left:
						MoveCaretToPosition(GetCaretPosition()-1, true, p_eventArgs.shift, true);
						break;
					case System::Windows::Forms::Keys::Right:
						MoveCaretToPosition(GetCaretPosition() + 1, true, p_eventArgs.shift, true);
						break;
					case System::Windows::Forms::Keys::Home:
						MoveCaretToPosition(0, true, p_eventArgs.shift, false);
						break;
					case System::Windows::Forms::Keys::End:
						MoveCaretToPosition(GetText()->Length, true, p_eventArgs.shift, false);
						break;
					case System::Windows::Forms::Keys::Back:
						BackspaceAtCaret(p_eventArgs.shift);
						break;
					}
				}
			}

			virtual void KeyPress(GameKeyPressEventArgs &p_keyArgs)
			{
				GameUIControl::KeyPress(p_keyArgs);

				if (p_keyArgs.suppress == false)
				{
					// skip Tab as data unless control accepts TAB
					bool skip = false;
					if (mouseIsDown == true) // don't allow key data entry when mosue is down
						skip = true;
					if (System::Windows::Forms::Keys(p_keyArgs.key) == System::Windows::Forms::Keys::Tab && AcceptsTab() == false)
						skip = true;
					// Skip backspace, was handled in keydown
					else if (System::Windows::Forms::Keys(p_keyArgs.key) == System::Windows::Forms::Keys::Back)
						skip = true;
					// Skip enter.  Don't accept it as data
					else if (System::Windows::Forms::Keys(p_keyArgs.key) == System::Windows::Forms::Keys::Enter)
						skip = true;

					if (skip == false)
					{
						// place character as data
						char charString[2];
						charString[0] = p_keyArgs.key;
						charString[1] = '\0';
						InsertOrReplaceText(gcnew String(charString));
					}
				}
			}

			virtual void InsertOrReplaceText(String ^p_text)
			{
				// inserts at selection or cursor position
				String ^text;
				bool valid = true;
				int startingLength = GetText()->Length;
				int newCaretPosition = 0;
				if (GetSelectionLength() != 0)
				{
					int highlightStart = GetSelectionStart();
					text = "";
					if (GetSelectionStart() > 0)
						text = GetText()->Substring(0, GetSelectionStart());
					text = text + p_text;
					if (GetSelectionStart() + GetSelectionLength() < startingLength)
						text += GetText()->Substring(GetSelectionStart() + GetSelectionLength());

					// too many characters?
					int charsInserted = p_text->Length;
					if (text->Length > maxLength)
					{
						// can it be corrected? (truncate insertion)
						if (p_text->Length > (text->Length - maxLength))
						{
							charsInserted = p_text->Length - (text->Length - maxLength);
							text = GetText()->Substring(0, GetSelectionStart()) + p_text->Substring(0, charsInserted) + GetText()->Substring(GetSelectionStart() + GetSelectionLength());
						}
						else
						{
							valid = false; // no text inserted
							charsInserted = 0;
						}
					}

					newCaretPosition = highlightStart + charsInserted;

					// reset remembered highlight start caret position so that it is re-initialized
					highlightCaretStartPosition = -1;
				}
				else
				{
					text = "";
					if (GetCaretPosition() > 0)
						text = GetText()->Substring(0, GetCaretPosition());
					text = text + p_text;
					if (GetCaretPosition() < startingLength)
						text = text + GetText()->Substring(GetCaretPosition());
					// too many characters?
					int charsInserted = p_text->Length;
					if (text->Length > maxLength)
					{
						// can it be corrected? (truncate insertion)
						if (p_text->Length > (text->Length - maxLength))
						{
							charsInserted = p_text->Length - (text->Length - maxLength);
							text = GetText()->Substring(0, GetCaretPosition()) + p_text->Substring(0, charsInserted) + GetText()->Substring(GetCaretPosition());
						}
						else
						{
							valid = false; // no text inserted
							charsInserted = 0;
						}
					}

					newCaretPosition = GetCaretPosition() + charsInserted;

					// reset remembered highlight start caret position so that it is re-initialized
					highlightCaretStartPosition = -1;
				}

				if (valid == true)
				{
					SetText(text);
					MoveCaretToPosition(newCaretPosition, false, false, false);

					// move caret up as many characters as were added
					ClearHighlighting();
				}
			}

			void MoveCaretToPosition(int p_position, bool p_handleHighlighting, bool p_shift, bool p_jumpScroll)
			{
				// todo: p_jumpScroll forces the text field to show an extra 1/4 width amount of text if the caret moves past the boundary.
				// otherwise, if caret leaves boundary of control, the control is scrolled to show the caret at either edge exactly.
				int oldCaretPosition = GetCaretPosition();
				SetCaretPosition(p_position);

				if (oldCaretPosition != GetCaretPosition())
				{
					// it moved - reset blink
					GameContext::Instance->GetUI()->ResetCaret();

					if (p_shift == true && p_handleHighlighting == true)
					{
						if (highlightCaretStartPosition == -1)
							highlightCaretStartPosition = oldCaretPosition;

						// highlight text - set in proper order to prevent validation from halting attempt
						if (GetCaretPosition() <= highlightCaretStartPosition)
						{
							if (GetSelectionLength() < highlightCaretStartPosition - GetCaretPosition())
							{
								SetSelectionStart(GetCaretPosition());
								SetSelectionLength(highlightCaretStartPosition - GetCaretPosition());
							}
							else
							{
								SetSelectionLength(highlightCaretStartPosition - GetCaretPosition());
								SetSelectionStart(GetCaretPosition());
							}
						}
						else
						{
							if (GetSelectionLength() < GetCaretPosition() - highlightCaretStartPosition)
							{
								SetSelectionStart(highlightCaretStartPosition);
								SetSelectionLength(GetCaretPosition() - highlightCaretStartPosition);
							}
							else
							{
								SetSelectionLength(GetCaretPosition() - highlightCaretStartPosition);
								SetSelectionStart(highlightCaretStartPosition);
							}
						}
					}
				}

				if (p_shift == false && p_handleHighlighting == true)
				{
					ClearHighlighting(); // moved (or tried to move) without shift, so clear highlight
					highlightCaretStartPosition = -1; // wait for key caret move with shift key - mouse down can also set this, but ignores keydowns until lifted
				}

				// now check caret position against render area - if it's past the right side, scroll appropriately
				RectangleF renderRectangle = GetTextRenderRectangle();
				int leftSide = int(renderRectangle.Left);
				int rightSide = int(renderRectangle.Left + renderRectangle.Width);
				int fullTextSizeX = (GetFont()->GetTextSize(GetText())).X;
				// if text is not longer than render area width, pixel position is zero, period
				if (fullTextSizeX <= renderRectangle.Width)
					SetPixelStartOffset(0);
				else
				{
					int caretPixelPosition = leftSide + pixelStartOffset;
					if (GetCaretPosition() > 0)
						caretPixelPosition += (GetFont()->GetTextSize(GetText()->Substring(0, GetCaretPosition()))).X;

					if (caretPixelPosition < leftSide)
					{
						// move text to the right
						if (p_jumpScroll == true)
						{
							// jump scroll shows extra 1/4 of control
							SetPixelStartOffset(GetPixelStartOffset() + (leftSide - caretPixelPosition) + int(renderRectangle.Width / 4));
							// pin it to the left margin
							if (GetPixelStartOffset() > 0)
								SetPixelStartOffset(0);
						}
						else
							SetPixelStartOffset(GetPixelStartOffset() + (leftSide - caretPixelPosition));

					}
					else if (caretPixelPosition > rightSide)
					{
						// move text to the left
						if (p_jumpScroll == true)
						{
							// jump scroll shows extra 1/4 of control
							SetPixelStartOffset(GetPixelStartOffset() - (caretPixelPosition - rightSide) - int(renderRectangle.Width / 4));
							// pin it to the right margin
							if (GetPixelStartOffset() < (int(renderRectangle.Width) - fullTextSizeX))
								SetPixelStartOffset(int(renderRectangle.Width) - fullTextSizeX);
						}
						else
							SetPixelStartOffset(GetPixelStartOffset() - (caretPixelPosition - rightSide));
					}
					else
					{
						// check for gap on the right side and fix (if text is shorter than render rectangle, that is handled above and forces a gap)
						if (fullTextSizeX + GetPixelStartOffset() < int(renderRectangle.Width))
						{
							SetPixelStartOffset(int(renderRectangle.Width) - fullTextSizeX);
						}
					}
				}
			}

			void DeleteAtCaret(bool p_shift)
			{
				// if anything highlighted, delete highlight
				if (GetSelectionLength() != 0)
				{
					DeleteAndClearHighlight(p_shift);
				}
				else
				{
					// delete next character
					if (GetCaretPosition() < GetText()->Length)
					{
						String ^text = GetText();

						String ^newText = "";
						if (GetCaretPosition() > 0)
							newText = text->Substring(0, GetCaretPosition());
						if (GetCaretPosition() < text->Length - 1)
							newText = newText + text->Substring(GetCaretPosition() + 1);

						SetText(newText);

						// keep caret position the same but adjust scrolling (avoid gap at right if possible)
						MoveCaretToPosition(GetCaretPosition(), false, false, false);
					}
				}
			}

			void BackspaceAtCaret(bool p_shift)
			{
				// if anything highlighted, delete highlight
				if (GetSelectionLength() != 0)
				{
					DeleteAndClearHighlight(p_shift);
				}
				else
				{
					// delete prior character and move caret back one place
					if (GetCaretPosition() > 0)
					{
						String ^text = GetText();

						String ^newText = "";
						if (GetCaretPosition() > 1)
							newText = text->Substring(0, GetCaretPosition() - 1);
						if (GetCaretPosition() < text->Length)
							newText = newText + text->Substring(GetCaretPosition());

						SetText(newText);

						// reposition caret and adjust scrolling if necessary
						MoveCaretToPosition(GetCaretPosition() - 1, false, false, false);
					}
				}
			}

			void DeleteAndClearHighlight(bool p_shift)
			{
				if (GetSelectionLength() == 0)
					throw gcnew Exception("Selection length must be > 0!");

				String ^text = GetText();

				String ^newText = "";
				if (GetSelectionStart() > 0)
					newText = text->Substring(0, GetSelectionStart());
				if (GetSelectionStart() + GetSelectionLength() < text->Length)
					newText = newText + text->Substring(GetSelectionStart() + GetSelectionLength());

				int selectionStart = GetSelectionStart();
				ClearHighlighting();
				SetText(newText);

				// place caret at start of selection, adjust scroll if necessary
				MoveCaretToPosition(selectionStart, false, false, false);
				// adjust selection start position
				if (p_shift == true)
					highlightCaretStartPosition = selectionStart;
				else
					highlightCaretStartPosition = -1;
			}

			virtual void RenderContents(GraphicsBase *p_graphics, ModelVertex *p_vertices)
			{
				String ^caption = GetText();

				GameFont ^font = GetFont();
				if (font == nullptr)
					throw gcnew Exception("Font not set for text field");

				// variables needed for both text and caret

				// provide a pixel margin around the text (considering thick border - in the end border style and font size determines the size of a single line control)
				RectangleF renderRectangle = GetTextRenderRectangle();
				int x = int(p_vertices[1].vertex.x) + int(renderRectangle.X);
				int y = int(p_vertices[1].vertex.y) + int(renderRectangle.Y);
				// render limits in pixels
				int leftMargin = x;
				int rightMargin = x + int(renderRectangle.Width);
				// adjust pixel start position of character 0
				x += GetPixelStartOffset();
				int textStartPositionX = x;
				Point textSize = font->GetTextSize(caption);
				float textTop = float(y);
				float textBottom = float(y + textSize.Y);

				// text and highlighting
				if (caption != "")
				{
					// p_vertices understood to be // ll, ul, ur, lr, ll.  so [1] holds the upper left coordinate for text rendering.  [3] holds lower right

					// Get range of characters to render
					int startRenderIndex = 0;
					int characterRenderQty = 0;
					// figure out characters to render - first visible character, number of characters to fill render area
					int length = caption->Length;
					// todo: this doesn't consider characters that recede back to render the next one
					for (startRenderIndex = 0; startRenderIndex < length; startRenderIndex++)
					{
						int charWidth = font->GetTextSize(caption->Substring(startRenderIndex, 1)).X;
						if (x + charWidth > leftMargin)
							// character is partially visible. we start here.
							break;

						x += charWidth;
					}
					if (startRenderIndex >= length)
						throw gcnew Exception("Start Render Index must be < length!");

					int testX = x;
					// todo: this doesn't consider characters that recede back to render the next one
					for (characterRenderQty = 1; characterRenderQty < length - startRenderIndex; characterRenderQty++)
					{
						int charWidth = font->GetTextSize(caption->Substring(startRenderIndex + characterRenderQty - 1, 1)).X;
						testX += charWidth;

						if (testX >= rightMargin)
							break;
					}

					if (startRenderIndex + characterRenderQty > length)
						throw gcnew Exception("startRenderIndex + characterRenderQty should never be > length!");

					// now render the text in sections according to highlighting
					if (GetSelectionLength() == 0 || (startRenderIndex >= GetSelectionStart() + GetSelectionLength()) || hasFocus == false)
						p_graphics->RenderFont(caption->Substring(startRenderIndex, characterRenderQty), font, x, y, GetForeColor());
					else
					{
						Point textSize;
						if (GetSelectionStart() > 0 && startRenderIndex < GetSelectionStart())
						{
							String ^textStart = caption->Substring(startRenderIndex, GetSelectionStart() - startRenderIndex);
							p_graphics->RenderFont(textStart, font, x, y, GetForeColor());
							textSize = font->GetTextSize(textStart);
							x += textSize.X;
						}

						// render highlight background and text
						// don't bother if range of characters does not include the highlight
						if (startRenderIndex < (GetSelectionStart() + GetSelectionLength()) && (startRenderIndex + characterRenderQty >= GetSelectionStart()))
						{
							int startHighlightIndex = GetSelectionStart();
							if (startHighlightIndex < startRenderIndex)
								startHighlightIndex = startRenderIndex;
							int stopHighlightIndex = GetSelectionStart() + GetSelectionLength();
							if (stopHighlightIndex > startRenderIndex + characterRenderQty)
								stopHighlightIndex = startRenderIndex + characterRenderQty;
							if (startRenderIndex != stopHighlightIndex) // shouldn't happen, just in case
							{
								String ^highlightedText = caption->Substring(startHighlightIndex, stopHighlightIndex - startHighlightIndex);
								textSize = font->GetTextSize(highlightedText);
								ModelVertex highlightVertices[4] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
								highlightVertices[0].vertex.Set(float(x), float(y - 1), 0);
								highlightVertices[1].vertex.Set(float(x + textSize.X), float(textTop - 1), 0);
								highlightVertices[2].vertex.Set(float(x + textSize.X), float(textBottom + 1), 0);
								highlightVertices[3].vertex.Set(float(x), float(y + textSize.Y + 1), 0);
								// render highlight background
								p_graphics->RenderFilledQuad(&highlightColor, 1, highlightVertices, 4, true);
								// render highlighted text
								p_graphics->RenderFont(highlightedText, font, x, y, highlightForeColor);
								x += textSize.X;
							}
						}

						// render the rest of the text
						if (GetSelectionStart() + GetSelectionLength() < startRenderIndex + characterRenderQty)
						{
							p_graphics->RenderFont(caption->Substring(GetSelectionStart() + GetSelectionLength(), 
								startRenderIndex + characterRenderQty - (GetSelectionStart() + GetSelectionLength())), 
								font, x, y, GetForeColor());
						}
					}
				}

				// caret
				if (hasFocus == true && GameContext::Instance->GetUI()->CaretIsVisible() == true)
				{
					// render the Caret
					int caretXPosition;
					if (GetCaretPosition() == 0)
						caretXPosition = textStartPositionX;
					else
					{
						int testCaretIndex = GetCaretPosition();
						if (caretIndexPosition > caption->Length)
							testCaretIndex = caption->Length;
						textSize = font->GetTextSize(caption->Substring(0, testCaretIndex));
						caretXPosition = textStartPositionX + textSize.X;
					}
					ModelVertex caretVertices[2] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };
					caretVertices[0].vertex.Set(float(caretXPosition), textTop, 0);
					caretVertices[1].vertex.Set(float(caretXPosition), textBottom, 0);
					p_graphics->RenderLineStrip(1.0f, &GetForeColor(), 1, caretVertices, 2, true);
				}
			}

			virtual void Inactivated() override
			{
				// highlight start memory can be kept
				// but mouse down goes away
				mouseIsDown = false;
			}

			void GainedFocus()
			{
				// keep caret visible when change edit fields for clarity
				GameContext::Instance->GetUI()->ResetCaret();

				GameUIControl::GainedFocus();
			}
		};

#pragma endregion Controls

		class GameUIControlNode
		{
			GameUIControl *control; // this is an instance and must be destroyed

			void Destroy()
			{
				if (control != nullptr)
				{
					delete control;
					control = nullptr;
				}
			}

		public:

			GameUIControlNode()
			{
				control = nullptr;
			}

			~GameUIControlNode()
			{
				Destroy();
			}

			void Initialize()
			{
				Destroy();
			}

			void SetControl(GameUIControl *p_control)
			{
				control = p_control;
			}
			GameUIControl * GetControl()
			{
				return control;
			}
		};

		class GameUIForm : public GameUIAspect, public GameUIFormBase
		{
			friend class GameUI;
			friend class GameUIFormNode;
			friend class GameFormLinkedList;
			friend class GameUIButton;
			friend class GameMessageBoxList;

		public:
			// delegates for events
			typedef void(GameUIForm::* GameUIMouseEntered)(void);
			typedef void(GameUIForm::* GameUIMouseLeft)(void);
			typedef void(GameUIForm::* GameUIMouseUp)(MouseButton);
			typedef void(GameUIForm::* GameUIMouseDown)(MouseButton);
			typedef void(GameUIForm::* GameUIMouseMove)(MouseMoveArgs &);

			typedef void(GameUIForm::* GameUIKeyDown)(GameKeyEventArgs &);
			typedef void(GameUIForm::* GameUIKeyPress)(GameKeyPressEventArgs &);
			typedef void(GameUIForm::* GameUIKeyUp)(GameKeyEventArgs &);


			typedef void(GameUIForm::* GameUIClick)(void);
			typedef void(GameUIForm::* GameUIOnBlur)(void);
			typedef void(GameUIForm::* GameUIOnFocus)(void);

		private:
			LinkedList<GameUIControlNode> controls;
			bool closed; // if not closed, is in UI

			GameUIMouseEntered mouseEntered;
			GameUIMouseLeft mouseLeft;
			GameUIMouseDown mouseDown;
			GameUIMouseUp mouseUp;
			GameUIMouseMove mouseMove;

			GameUIKeyDown keyDown;
			GameUIKeyPress keyPress;
			GameUIKeyUp keyUp;

			GameUIControl *controlWithFocus; // which control currently has focus on this form? (only determines which control gets input focus when this form becomes active again)
											 // also the 'selected control'

			void Destroy()
			{
				if (closed == false)
					Close(); // make sure it's removed from the UI
			}

		public:
			GameUIForm()
			{
				closed = true; // not in UI yet

				mouseEntered = nullptr;
				mouseLeft = nullptr;
				mouseDown = nullptr;
				mouseUp = nullptr;
				mouseMove = nullptr;

				keyDown = nullptr;
				keyPress = nullptr;
				keyUp = nullptr;

				controlWithFocus = nullptr;
			}

			virtual ~GameUIForm()
			{
				Destroy();
			}

			void SetMouseEntered(GameUIMouseEntered p_mouseEntered)
			{
				mouseEntered = p_mouseEntered;
			}

			void SetMouseLeft(GameUIMouseLeft p_mouseLeft)
			{
				mouseLeft = p_mouseLeft;
			}

			void SetMouseDown(GameUIMouseDown p_mouseDown)
			{
				mouseDown = p_mouseDown;
			}

			void SetMouseUp(GameUIMouseUp p_mouseUp)
			{
				mouseUp = p_mouseUp;
			}

			void SetMouseMove(GameUIMouseMove p_mouseMove)
			{
				mouseMove = p_mouseMove;
			}

			void SetKeyDown(GameUIKeyDown p_keydown)
			{
				keyDown = p_keydown;
			}

			void SetKeyPress(GameUIKeyPress p_keyPress)
			{
				keyPress = p_keyPress;
			}

			void SetKeyUp(GameUIKeyUp p_keyUp)
			{
				keyUp = p_keyUp;
			}

			virtual void Render(GraphicsBase *p_graphics, int p_startingStencilValue = 0)
			{
				Render(PointF(0, 0), p_graphics, p_startingStencilValue);
			}

			virtual void Render(PointF &p_offset, GraphicsBase *p_graphics, int p_startingStencilValue)
			{
				// offset repositions the upper left of the form

				ModelVertex controlVertices[5] = { ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0), ModelVertex(Vector3d(0, 0, 0), 0) };

				int stencilValue = p_startingStencilValue;

				// render all controls, then the form
				// render it and its controls!
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Increment, GraphicsStencilOperationEnum::Increment, GraphicsStencilOperationEnum::Increment);
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, stencilValue, 0xff);

				// render form background
				// 01
				// 32
				RectangleF rect = GetRect();
				controlVertices[0].vertex.Set(rect.Left, rect.Top, 0.0f);
				controlVertices[1].vertex.Set(rect.Left + rect.Width, rect.Top, 0.0f);
				controlVertices[2].vertex.Set(rect.Left + rect.Width, rect.Top + rect.Height, 0.0f);
				controlVertices[3].vertex.Set(rect.Left, rect.Top + rect.Height, 0.0f);
				controlVertices[4].vertex.Set(rect.Left, rect.Top, 0.0f);

				// don't render border yet, save it for last

				// background
				p_graphics->RenderFilledQuad(&GetBackColor(), 1, controlVertices, 4, true);

				// render controls back to front
				stencilValue++;
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, stencilValue, 0xff);

				LinkedListEnumerator<GameUIControlNode> controlEnumerator = GetControlEnumerator(false);
				while (controlEnumerator.MoveNext())
				{
					GameUIControl *control = controlEnumerator.Current()->data.GetControl();
					if (control->IsVisible() == false)
						continue;

					if (ControlClippedEntirelyByForm(control) == false)
					{
						control->Render(PointF(rect.Left, rect.Top), p_graphics, stencilValue);
					}
				}

				// restore stencil
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, stencilValue, 0xff);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Decrement, GraphicsStencilOperationEnum::Decrement, GraphicsStencilOperationEnum::Decrement);

				// re-render border to blank out controls that overlapped it

				// background - don't render, just restore stencil
				p_graphics->ColorMask(false, false, false, false);
				p_graphics->RenderFilledQuad(&GetBackColor(), 1, controlVertices, 4, false);
				p_graphics->ColorMask(true, true, true, true);

				// border - normal render using original stencil sent in
				stencilValue--;
				if (stencilValue != p_startingStencilValue)
					throw gcnew Exception("Stencil value does not match starting stencil value!");
				p_graphics->StencilTest(GraphicsStencilTestFuncEnum::Equal, stencilValue, 0xff);
				p_graphics->StencilOperations(GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep, GraphicsStencilOperationEnum::Keep);
				p_graphics->RenderLineStrip(1.0f, &(GetBorderColor()), 1, controlVertices, 5, true);
			}

			GameUIControl * AddControl(GameUIControl *p_control)
			{
				// p_control is a NEW instance of a control, not a copy of or reference to another.

				LinkedListNode<GameUIControlNode> *newControl = controls.GetNewNode();
				newControl->data.Initialize();
				newControl->data.SetControl(p_control);
				newControl->data.GetControl()->SetParentForm(this);

				controls.AddNode(newControl);

				return p_control;
			}

			LinkedListEnumerator<GameUIControlNode> GetControlEnumerator(bool p_reverse = false)
			{
				return LinkedListEnumerator<GameUIControlNode>(controls, p_reverse);
			}

			virtual void Show()
			{
				GameContext::Instance->GetUI()->ShowForm(this);

				// reset closed whether form was already in UI or not
				closed = false;
			}

			virtual void ShowModal()
			{
				GameContext::Instance->GetUI()->ShowForm(this, true);

				// reset closed whether form was already in UI or not
				closed = false;
			}

			void Hide()
			{
				GameContext::Instance->GetUI()->HideForm(this);
			}

			void MoveToFront()
			{
				// nothing happens if form isn't already in the UI
				GameContext::Instance->GetUI()->MoveFormToFront((GameUIFormBase *)this);
			}

			void SetClose()
			{
				closed = true;
			}

			void Close() override
			{
				GameUIBase *ui = GameContext::Instance->GetUI();
				ui->CloseForm(this);
				SetClose(); // in case not found in UI close routine
				FixControlsForFormInactivated();
			}

			bool IsClosed() override
			{
				return closed;
			}

			// friend functions
		private:
			//void ClearAllControlFocus()
			//{
			//	LinkedListEnumerator<GameUIControlNode> controlEnumerator = LinkedListEnumerator<GameUIControlNode>(controls);
			//	while (controlEnumerator.MoveNext())
			//	{
			//		controlEnumerator.Current()->data.GetControl()->ClearFocus();
			//	}
			//}

			void FixControlsForFormInactivated()
			{
				// called when form is closed, hidden or moved from frontmost position
				LinkedListEnumerator<GameUIControlNode> controlEnumerator = GetControlEnumerator();
				while (controlEnumerator.MoveNext())
				{
					controlEnumerator.Current()->data.GetControl()->Inactivated();
				}
			}

			void SetFormVisibility(bool p_visible)
			{
				if (p_visible == true)
					GameUIAspect::Show();
				else
					GameUIAspect::Hide();
			}

			void SetClosed()
			{
				// called when game ui is destroyed
				closed = true;
			}

			bool ControlClippedEntirelyByForm(GameUIControl *p_control)
			{
				// determines if control should even be rendered

				RectangleF controlRect = p_control->GetRect();
				RectangleF formRect = GetRect();
				if (controlRect.Left + controlRect.Width <= 0)
					return true;
				if (controlRect.Left >= formRect.Width)
					return true;
				if (controlRect.Top + controlRect.Height <= 0)
					return true;
				if (controlRect.Top >= formRect.Height)
					return true;

				return false;
			}

			////////////////////////////////////////
			// event triggers from GameUI processing
			void MouseEntered()
			{
				// Trigger MouseEntered event
				if (mouseEntered != nullptr)
				{
					(this->*mouseEntered)();
				}
			}

			void MouseLeft()
			{
				// Trigger MouseLeft event
				if (mouseLeft != nullptr)
				{
					(this->*mouseLeft)();
				}
			}

			void MouseDown(MouseButton p_mouseButton)
			{
				// Trigger MouseDown event
				if (mouseDown != nullptr)
				{
					(this->*mouseDown)(p_mouseButton);
				}
			}

			void MouseUp(MouseButton p_mouseButton)
			{
				// Trigger MouseUp event
				if (mouseUp != nullptr)
				{
					(this->*mouseUp)(p_mouseButton);
				}
			}

			void MouseMoved(MouseMoveArgs &p_moveArgs)
			{
				// Trigger MouseUp event
				if (mouseMove != nullptr)
				{
					(this->*mouseMove)(p_moveArgs);
				}
			}

			virtual void KeyDown(GameKeyEventArgs &p_keyArgs)
			{
				// Trigger KeyDown event
				if (keyDown != nullptr)
				{
					(this->*keyDown)(p_keyArgs);
				}
			}

			virtual void KeyPress(GameKeyPressEventArgs &p_keyArgs)
			{
				// Trigger KeyPress event
				if (keyPress != nullptr)
				{
					(this->*keyPress)(p_keyArgs);
				}
			}

			virtual void KeyUp(GameKeyEventArgs &p_keyArgs)
			{
				// Trigger KeyUp event
				if (keyUp != nullptr)
				{
					(this->*keyUp)(p_keyArgs);
				}
			}

		};

		class GameUIFormNode
		{
		private:
			GameUIForm *formRef; // implementation is responsible for destroying its forms

			void Destroy()
			{
				if (formRef != nullptr)
				{
					//formRef->SetClosed(); // no need to do this - this only happens when the DeletedList goes away, and that means the app is closing, so GameUI should be wiping all the forms anyway
					// besides, it risks causing a corruption because the forms are already deallocated, which is why this was commented out.
					formRef = nullptr;
				}
			}

		public:

			GameUIFormNode()
			{
				formRef = nullptr;
			}

			~GameUIFormNode()
			{
				Destroy();
			}

			void Initialize()
			{
				formRef = nullptr;
			}

			GameUIForm * GetGameForm()
			{
				return formRef;
			}

			void SetGameForm(GameUIForm *p_form)
			{
				formRef = p_form;
			}
		};

		class GameFormLinkedList : public LinkedList<GameUIFormNode>
		{
		public:
			LinkedListNode<GameUIFormNode> * FindForm(GameUIForm *p_form)
			{
				LinkedListEnumerator<GameUIFormNode> enumerator = LinkedListEnumerator<GameUIFormNode>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.GetGameForm() == p_form)
						return enumerator.Current();
				}
				return nullptr;
			}

			void CloseAllForms()
			{
				// tag forms closed so that they don't try to close themselves automatically after the ui is destroyed
				LinkedListEnumerator<GameUIFormNode> enumerator = LinkedListEnumerator<GameUIFormNode>(*this);
				while (enumerator.MoveNext())
				{
					enumerator.Current()->data.GetGameForm()->SetClosed();
				}
			}

			bool AnyFormsEnabledAndVisible()
			{
				LinkedListEnumerator<GameUIFormNode> enumerator = LinkedListEnumerator<GameUIFormNode>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.GetGameForm()->IsVisible() == true && enumerator.Current()->data.GetGameForm()->IsEnabled() == true)
						return true;
				}
				return false;
			}
		};

		class GameUIMessageBoxMessageLabel : public GameUIControl
		{
		public:
			LinkedList<GameLinedRichText> linedRichText;

			GameUIMessageBoxMessageLabel(RectangleF &p_rect) : GameUIControl(p_rect)
			{
				SetBorderColor(GameColor(0, 0, 0, 0)); // no border.
			}

			void RenderContents(GraphicsBase *p_graphics, ModelVertex *p_vertices) override
			{
				// take the lined rich text and render it
				// need to determine render locations for the lines
				PointF origin = PointF(p_vertices[1].vertex.x, p_vertices[1].vertex.y);
				ParseRichText(false, p_graphics, true, &origin);
			}

			void SetText(LinkedList<GameRichText> &p_richText, GameViewport ^p_viewport);
			void ParseRichText(bool p_setControlSize = true, GraphicsBase *p_graphics = nullptr, bool p_render = false, PointF *p_origin = nullptr);
		};

		class GameUIMessageBox : public GameUIForm
		{
			// responds to enter, space, esc - all close it
			// multi-line label has a default width
			// apply rich text to it - splits the text up to a maximum width.  If max width is lower, will make the label thinner smaller

			GameUIMessageBoxMessageLabel *messageLabel;
			bool userClosable;
			bool userClosableByEscOnly;

		public:
			GameUIMessageBox()
			{
				messageLabel = (GameUIMessageBoxMessageLabel *)AddControl(new GameUIMessageBoxMessageLabel(RectangleF(10, 10, 60, 10)));
				userClosable = true;
				userClosableByEscOnly = false;
			}

			void SetMessage(LinkedList<GameRichText> &p_richText, GameViewport ^p_viewport)
			{
				messageLabel->SetText(p_richText, p_viewport);
			}

			void KeyDown(GameKeyEventArgs &p_event) override
			{
				if (userClosable == true)
				{
					switch (System::Windows::Forms::Keys(p_event.keyCode))
					{
					case System::Windows::Forms::Keys::Space:
					case System::Windows::Forms::Keys::Enter:
						if (userClosableByEscOnly == false)
							Close();
						break;
					case System::Windows::Forms::Keys::Escape:
						Close();
						break;
					}
				}
			}

			void SetUserClosable(bool p_userClosable)
			{
				userClosable = p_userClosable;
			}

			void SetUserClosableByEscOnly(bool p_userClosableByEscOnly)
			{
				userClosableByEscOnly = p_userClosableByEscOnly;
			}
		};

		class GameUIMessageBoxNode
		{
		public:
			GameUIMessageBox messageBox;
		};

		class GameMessageBoxList : public LinkedList<GameUIMessageBoxNode>
		{
		public:
			GameUIForm * GetUnusedMessageBox()
			{
				LinkedListEnumerator<GameUIMessageBoxNode> enumerator = LinkedListEnumerator<GameUIMessageBoxNode>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.messageBox.closed == true)
						return &(enumerator.Current()->data.messageBox);
				}

				// create a new one
				LinkedListNode<GameUIMessageBoxNode> *newNode = GetNewNode();
				AddNode(newNode);
				return &(newNode->data.messageBox);
			}
		};

		class GameUIFormControl
		{
		public:
			GameUIForm *form;
			GameUIControl *control;

			GameUIFormControl()
			{
				form = nullptr;
				control = nullptr;
			}

			bool Equals(GameUIFormControl &p_formControl)
			{
				if (p_formControl.form != form)
					return false;
				if (p_formControl.control != control)
					return false;

				return true;
			}
		};

		class GameUITextCaret
		{
		public:
			GameTimer timer; // safe from pauses from main game loop so that caret blinks at a steady reate regardless

			int timeSinceLastBlinkMS;
			int blinkDelayMS;
			bool visible;

			GameUITextCaret(int p_blinkDelayMS)
			{
				blinkDelayMS = p_blinkDelayMS;

				Reset();
			}

			void ApplyElapsedTime()
			{
				timer.Poll();
				timeSinceLastBlinkMS += timer.GetElapsedTimeMS();
				if (timeSinceLastBlinkMS >= blinkDelayMS)
				{
					timeSinceLastBlinkMS = 0;
					visible = !visible;
				}
				timer.ResetElapsedTime();
			}

			// force it visible and reset its blink timer
			void Reset()
			{
				timeSinceLastBlinkMS = 0;
				visible = true;
			}
		};

		// parent class that encompasses all open forms and provides UI state values like current active form, etc.

		// Primary todos:
		// Still need to verify change of focus, etc. when forms are created or removed in the middle of control operations
		// (done) MessageBox needs a constructor that prevents user cancelling by keyboard, primarily to support connecting messages with the UI that will eventually be removed or changed by the code
		// SetText() for TextBoxes needs to intelligently accommodate for caret position and currently highlighted text, properly altering and correcting those values.  Currently, SetText()
		//   is being used for in-control operations, and the verifications there should NOT be the same verifications as what happens when SetText() is called from the outside.  They should be
		//   two separate rotuines.  Setting MaxLength should also intelligentyl crop the text if it is too long (although this is rare - usually max length is set near control creation)
		// Although currently the logic of how to route mouse and keyboard into the ui or the game is completely up to the DoGameLoop() currently and varies according to the situation, there
		//   are not so definable situations that could affect whether or not the UI consumes a control or the game consumes a control - consider the possibility of a few forms displayed
		//   that are there only for information, but another form may or may not be up that accepts mouse and key input, and it may or may not provide the option of clicking it to make
		//   it active. Such a situation might stand for the system as a whole to tell the gameloop if controls were consumed by the UI and possibly hence how they should be used, rather than have the gameloop
		//   make a general decision based on a shallow level of circumstances.  If a subsystem can be designed to handle a case like this, perhaps it can be integrated into a basic
		//   DoGameLoop methodology that services most implementations.
		// Showing a messagebox currently does not support returning a Result to respond to - however, internally, a messagebox could call a DoEvents() on the main windows loop, which varies
		//   depending on the form of the thin outer layer, which still executes everything.  Then a simple messagebox routine can be displayed and responded to.  Something to consider.  I imagine
		//   the thin outer layer DoEvents() routine will either be set up in GameBase, or registered as something in GameContext or GameApplicationContext.

		// test:
		// If mouse down (any button) on a UI element, mouse should not be allowed to affected any aspect of the game.  Mouse should remain 'in' the element until mouse up, even if mouse moves into the
		//    game area or entirely out of it.
		// If mouse down on a game element, mouse should remain in the game element even if the mouse goes over a UI element or leaves the scene area
		// If mouse up after leaving any element it was part of, mouse should finally leave that element and enter the element it entered (currently mouse can 'enter' any UI element, or just not
		//    be in any of them and be in the game area (attributes on forms determine if mouse can even enter them or affect them in any way, such as a form that is only ment for display with nothing
		//    highlightable)
		// If a form has a keyable control with text, no character should affect the game area.  Even Esc should simply leave the focus of the current control
		// (Pending) If a form has a control only affected by arrows keys and tab, only those keys should not affect the game.  Alternatively, any sort of keyable access on a form, or even just the ability
		//    to highlight or focus a control of any sort, should block the keyboard from affecting the game, even if the mouse leaves the UI element and enters the game area without clicking on it.
		// If mouse leaves primary scene control in form mode (either upped mouse leaves the area or a downed mouse leaves the area and then lifts), UI should not attempt to respond to mouse anymore in 
		//    any way.  When mouse re-enters the primary control, it shoudl immediately figure out which UI element it just entered.
		// test: overlap a form or control with the edge of the main scene - move mosue out of scene - form and control should respond when mouse leaves and enters
		// test: pause the thread for a few seconds - all mosue and keyboard events on controls should properly register
		// 
		// focus rules:
		//   control loses focus if a different form moves to the front, and that form's current focus control gains focus
		//   despite a control having input focus, if the form is disabled or the control is disabled, the control is simply rendered as disabled
		//   todo: should a disabled control or a control on a disabled form achieve focus at all?  What does Windows do?  Does the control fire onfocus the moment the control/form becomes active?
		//      this matters because disabling a control prevents it from getting focus in the first place.  So how should this work?
		class GameUI : public GameUIBase
		{
		protected:
			gcroot<GameViewport ^> viewportRef;
			gcroot<GameFont ^> defaultFontRef;
			GameColor defaultForeColor;

			// forms that appear on top of all other forms, prevent mouse controls from reaching them
			GameFormLinkedList modalDialogs;

			// non-modal forms - front one is the active one (they move)
			// todo: possible to have a parent form and child form, click child form, both child and parent should move to the front together in front of the rest.
			GameFormLinkedList forms;

			// only one control can have primary input focus at a time (simpled called 'focus').  This identifies that control.
			// each form however can record which of its controls has the focus on that form, so that focus switches as forms become active
			GameUIControl *currentFocusControl;
			GameUIForm *currentFocusForm;
			GameUIFormControl currentMouseInside; // which form and control is the mosue current inside? (this locks when left down is pressed)

			GameMessageBoxList messageBoxes; // holding place for closed message boxes for re-ruse - will be destroyed with GameUI is destroyed - they are kept persistant rather than
											 //    being immediately destroyed to avoid access problems arising from events destroying forms before the event execution is complete

		private:
			GameUITextCaret *textCaret;

			gcroot<GameMouse^> currentMouse; // accumulated state of mouse for this input process, ui side only

			// being locked does not mean there is a form or control actually locked, but it does mean that without enough information, NOTHING outside the domain of what is locked
			//   can acquire a focus lock until the appropriate mouse buttons are lifted.
			bool lastMouseLeftDown;
			bool lastMouseMiddleDown;
			bool lastMouseRightDown;
			Point lastMousePosition; // used purely for detecting mouse moves when there are no new enters or leaves on any controls for forms.

			// MouseDown form/control locking
			// Left button down only for now
			// when the mouse is downed, whatever it is down on gets the attention of mouse moves until the mouse is lifted.
			// the boolean and the actual item locked are separate because the bool might be true but with no form or control actually locked (such as if the locked form closes, so the form reference is now null).  
			//   The logic of the process still applies.
			// the booleans prevent anything else from registering mouse moves, mouse enters or mouse leaves.
			bool formMouseDownLocked; // right down (and left and middle)
			GameUIForm *lockedMouseDownForm;
			bool controlMouseDownLocked; // left and middle down - ideally, if left down once on a different control while middle is down, middle down effect on control is lost, but form remains locked until all are lifted
			GameUIControl *lockedMouseDownControl;

		public:
			// high level event handling, before events are passed to the forms
			typedef void (GameUI::* GameUIMouseUp)(GameInputEvent &);
			typedef void (GameUI::* GameUIMouseDown) (GameInputEvent &);
			typedef void (GameUI::* GameUIMouseMove) (GameInputEvent &);
			typedef void (GameUI::* GameUIKeyUp) (GameInputEvent &);
			typedef void (GameUI::* GameUIKeyDown) (GameInputEvent &);
			typedef void (GameUI::* GameUIKeyPress) (GameInputEvent &);

		private:
			// entry level events
			// the routines for these should be in the derived class for GameUI for clarity
			GameUIMouseUp preMouseUp;
			GameUIMouseMove preMouseMove;
			GameUIMouseDown preMouseDown;
			GameUIKeyUp preKeyUp;
			GameUIKeyDown preKeyDown;
			GameUIKeyPress preKeyPress;

			GameUIMouseUp postMouseUp;
			GameUIMouseMove postMouseMove;
			GameUIMouseDown postMouseDown;
			GameUIKeyUp postKeyUp;
			GameUIKeyDown postKeyDown;
			GameUIKeyPress postKeyPress;

		public:
			GameUI(GameViewport ^p_viewport, GameFont ^p_defaultFont, GameColor p_defaultForeColor)
			{
				viewportRef = p_viewport;
				defaultFontRef = p_defaultFont;
				defaultForeColor = p_defaultForeColor;

				currentMouse = gcnew GameMouse();

				currentFocusControl = nullptr;
				currentFocusForm = nullptr;

				lastMouseLeftDown = false;
				lastMouseMiddleDown = false;
				lastMouseRightDown = false;
				formMouseDownLocked = false;
				lockedMouseDownForm = nullptr;
				controlMouseDownLocked = false;
				lockedMouseDownControl = nullptr;

				lastMousePosition.X = -1;
				lastMousePosition.Y = -1;

				textCaret = new GameUITextCaret(526);

				// events
				preMouseUp = nullptr;
				preMouseDown = nullptr;
				preMouseMove = nullptr;
				preKeyUp = nullptr;
				preKeyDown = nullptr;
				preKeyPress = nullptr;

				postMouseUp = nullptr;
				postMouseDown = nullptr;
				postMouseMove = nullptr;
				postKeyUp = nullptr;
				postKeyDown = nullptr;
				postKeyPress = nullptr;
			}
			virtual ~GameUI()
			{
				Destroy();
			}

		protected:
			void Destroy()
			{
				modalDialogs.CloseAllForms();
				forms.CloseAllForms();

				modalDialogs.Clear();
				forms.Clear();

				// it's a ref class so it should destroy itself automatically, but just in case, get rid of it explicitly
				if (static_cast<GameMouse^>(currentMouse) != nullptr)
				{
					delete currentMouse;
					currentMouse = nullptr;
				}

				if (textCaret != nullptr)
				{
					delete textCaret;
					textCaret = nullptr;
				}
			}

		public:

			// set events
			void SetPreMouseDown(GameUIMouseDown p_mouseDown)
			{
				preMouseDown = p_mouseDown;
			}

			void SetPreMouseUp(GameUIMouseUp p_mouseUp)
			{
				preMouseUp = p_mouseUp;
			}

			void SetPreMouseMove(GameUIMouseMove p_mouseMove)
			{
				preMouseMove = p_mouseMove;
			}

			void SetPreKeyUp(GameUIKeyUp p_keyUp)
			{
				preKeyUp = p_keyUp;
			}

			void SetPreKeyDown(GameUIMouseDown p_keyDown)
			{
				preKeyDown = p_keyDown;
			}

			void SetPreKeyPress(GameUIKeyPress p_keyPress)
			{
				preKeyPress = p_keyPress;
			}

			void SetPostMouseDown(GameUIMouseDown p_mouseDown)
			{
				postMouseDown = p_mouseDown;
			}

			void SetPostMouseUp(GameUIMouseUp p_mouseUp)
			{
				postMouseUp = p_mouseUp;
			}

			void SetPostMouseMove(GameUIMouseMove p_mouseMove)
			{
				postMouseMove = p_mouseMove;
			}

			void SetPostKeyUp(GameUIKeyUp p_keyUp)
			{
				postKeyUp = p_keyUp;
			}

			void SetPostKeyDown(GameUIMouseDown p_keyDown)
			{
				postKeyDown = p_keyDown;
			}

			void SetPostKeyPress(GameUIKeyPress p_keyPress)
			{
				postKeyPress = p_keyPress;
			}

			// operations
			void ShowForm(GameUIFormBase *p_formRef, bool p_modal = false) override
			{
				// p_form is either a new form or an existing one
				GameUIForm *form = (GameUIForm *)p_formRef;

				// see if form already exists - if so, switch its hidden flag
				LinkedListNode<GameUIFormNode> *formNode = modalDialogs.FindForm(form);
				if (formNode != nullptr)
				{
					if (formNode->data.GetGameForm()->IsVisible() == false)
						formNode->data.GetGameForm()->SetFormVisibility(true);

					if (formNode != modalDialogs.GetFirstNode())
					{
						GameUIForm *frontForm = modalDialogs.GetFirstNode()->data.GetGameForm();

						// move to front
						modalDialogs.DetachNode(formNode);
						modalDialogs.InsertNode(formNode);

						// Give focus to the form's selected control
						SetControlFocus(form, form->controlWithFocus);

						frontForm->FixControlsForFormInactivated();
						//if (frontForm == lockedMouseDownForm)
						//{
						//	lockedMouseDownForm = nullptr;
						//	lockedMouseDownControl = nullptr;
						//}

						// Re-evaluate which form/control mouse is over
						// This doesn't quite work
						//ProcessMouseInputs();
					}

					// todo: fire form activate event
				}
				else
				{
					LinkedListNode<GameUIFormNode> *formNode = forms.FindForm(form);
					if (formNode != nullptr)
					{
						if (formNode->data.GetGameForm()->IsVisible() == false)
							formNode->data.GetGameForm()->SetFormVisibility(true);

						// move to front
						if (formNode != forms.GetFirstNode())
						{
							GameUIForm *frontForm = forms.GetFirstNode()->data.GetGameForm();

							forms.DetachNode(formNode);
							forms.InsertNode(formNode);

							// Give focus to the form's selected control
							SetControlFocus(form, form->controlWithFocus);

							frontForm->FixControlsForFormInactivated();
							//if (frontForm == lockedMouseDownForm)
							//{
							//	lockedMouseDownForm = nullptr;
							//	lockedMouseDownControl = nullptr;
							//}

							// Re-evaluate which form/control mouse is over
							// This doesn't quite work
							//ProcessMouseInputs();
						}

						// todo: fire form activate event
					}
					else
					{
						// otherwise add it
						LinkedListNode<GameUIFormNode> *newForm = forms.GetNewNode();
						newForm->data.Initialize();
						newForm->data.SetGameForm(form);

						if (p_modal == false)
							forms.InsertNode(newForm);
						else
							modalDialogs.InsertNode(newForm);

						// give focus to the new form
						SetControlFocus(form, nullptr);

						// Re-evaluate which form/control mouse is over
						// This doesn't quite work
						//ProcessMouseInputs();

						// todo: fire form instantiation and activation events (this means the constructor on the form is not an event per se and should not be treated as one)
					}
				}
			}

			void CloseForm(GameUIFormBase *p_form) override
			{
				GameUIForm *form = (GameUIForm *)p_form;

				// see if form already exists - if so, switch its hidden flag
				LinkedListNode<GameUIFormNode> *formNode = modalDialogs.FindForm(form);
				if (formNode != nullptr)
				{
					GameUIForm *currentTopForm = GetTopForm();

					// fire closing
					modalDialogs.DeleteNode(formNode);
					if (currentFocusForm == form)
					{
						// cause blurs
						SetControlFocus(nullptr, nullptr);
					}
					// fire closing, accept override
					// ??
					formNode->data.GetGameForm()->SetClose();
					// fire closed
					// ??
					//if (form == lockedMouseDownForm)
					//{
					//	lockedMouseDownForm = nullptr;
					//	lockedMouseDownControl = nullptr;
					//}

					// Re-evaluate which form/control mouse is over
					// This doesn't quite work
					//ProcessMouseInputs();

					// restore focus to next form on top
					GameUIForm *form = GetTopForm();
					if (form != nullptr && form != currentTopForm)
					{
						SetControlFocus(form, form->controlWithFocus);
					}
				}
				else
				{
					LinkedListNode<GameUIFormNode> *formNode = forms.FindForm(form);
					if (formNode != nullptr)
					{
						GameUIForm *currentTopForm = GetTopForm();

						// fire closing
						forms.DeleteNode(formNode);
						if (currentFocusForm == form)
						{
							// cause blurs
							SetControlFocus(nullptr, nullptr);
						}
						formNode->data.GetGameForm()->SetClose();
						// fire closed
						// ??
						//if (form == lockedMouseDownForm)
						//{
						//	lockedMouseDownForm = nullptr;
						//	lockedMouseDownControl = nullptr;
						//}

						// Re-evaluate which form/control mouse is over
						// This doesn't quite work
						//ProcessMouseInputs();
						// restore focus to next form on top

						GameUIForm *form = GetTopForm();
						if (form != nullptr && form != currentTopForm)
						{
							SetControlFocus(form, form->controlWithFocus);
						}
					}
				}
			}

			void CloseAllForms() override
			{
				modalDialogs.CloseAllForms();
				forms.CloseAllForms();

				modalDialogs.Clear();
				forms.Clear();

				SetControlFocus(nullptr, nullptr);
			}

			void HideForm(GameUIFormBase *p_form) override
			{
				GameUIForm *form = (GameUIForm *)p_form;
				if (form->IsVisible() == true)
				{
					form->SetFormVisibility(false);
					form->FixControlsForFormInactivated();
					//if (form == lockedMouseDownForm)
					//{
					//	lockedMouseDownForm = nullptr;
					//	lockedMouseDownControl = nullptr;
					//}
				}
				// todo: give focus back to focus control of new front form
			}

			void HideControl(GameUIControlBase *p_control) override
			{
				// control will do its own maintenance on visibility, this routine jsut performs the special maintenance ui needs to do

				// let ui unlock mouse down on the control
				GameUIControl *control = (GameUIControl *)p_control;
				if (control->IsVisible() == true)
				{
					//if (control == lockedMouseDownControl)
					//{
					//	lockedMouseDownControl = nullptr;
					//}
				}
				// todo: give focus back to next control of form, if possible
			}

			void SetControlFocus(GameUIFormBase *p_form, GameUIControlBase *p_control) override
			{
				GameUIForm *form = (GameUIForm *)p_form;
				GameUIControl *control = (GameUIControl *)p_control;

				if (form == nullptr)
				{
					// nothing is clicked.  clear all focus and leave
					if (currentFocusControl != nullptr)
					{
						currentFocusControl->ClearFocus();
						currentFocusControl->Blur();
					}
					currentFocusForm = nullptr;
					currentFocusControl = nullptr;

					return;
				}

				LinkedListNode<GameUIFormNode> *formNode = modalDialogs.FindForm(form);
				if (formNode == nullptr)
					formNode = forms.FindForm(form);

				// if form isn't changing but we didn't click a control, don't give focus to form.  Forms don't accept focus.
				if (control == nullptr && form != nullptr && form == currentFocusForm)
					return;
				// if form didn't change but control doesn't accept focus or is disabled, don't let control have focus
				bool acceptsFocus = (control != nullptr && control->AcceptsFocus());
				bool isEnabled = (control != nullptr && control->IsEnabled());
				if (control != nullptr && form == currentFocusForm && (acceptsFocus == false || isEnabled == false))
					return;

				// this assumes there is only ever one form with any kind of focus, but currently there is an assumption that more than one control can have pseudo focus, with one control having
				//  primary focus, all on that form
				if (formNode != nullptr)
				{
					if (formNode->data.GetGameForm() == currentFocusForm)
					{
						if (currentFocusControl != control)
						{
							// just clear focus on all other controls on the form and move the focus over
							if (currentFocusControl != nullptr)
							{
								currentFocusControl->ClearFocus();
								currentFocusControl->Blur();
							}
							currentFocusControl = control;
							currentFocusForm->controlWithFocus = control; // track for when form goes inactive and becomes active again
							if (control != nullptr)
							{
								control->SetFocus(); // friend function
								control->GainedFocus();
							}
						}
					}
					else
					{
						if (currentFocusForm != nullptr)
						{
							// do nothing.  forms don't get focus or blur
						}
						if (currentFocusControl != nullptr)
						{
							currentFocusControl->ClearFocus();
							currentFocusControl->Blur();
						}
						currentFocusForm = form;
						if (control != nullptr)
						{
							currentFocusControl = control;
							currentFocusForm->controlWithFocus = control; // track for when form goes inactive and becomes active again
						}
						else
							// restore focus on selected control on form
							currentFocusControl = currentFocusForm->controlWithFocus;
						if (currentFocusControl != nullptr)
						{
							currentFocusControl->SetFocus(); // friend function, setting boolean
							currentFocusControl->GainedFocus(); // fire GotFocus
						}
					}
				}
			}

			void Render(GraphicsBase *p_graphics, bool p_advanceUITime = true)
			{
				// don't always advance if for whatever reason we are rendering the UI multiple times because of multiple scene rendering (3d, etc.)
				// first render should send true, the rest false
				if (p_advanceUITime == true)
					textCaret->ApplyElapsedTime();

				// render back to front
				RenderForms(p_graphics, forms);
				RenderForms(p_graphics, modalDialogs);
			}

			// The meat of how user controls affect form operation, including which form is active, how controls respond and events are fired
			// Since the UI always lies on top of the game scene, inputs should be processed in the UI before they are processed in the game, to give the mouse/keyboard a chance to operate
			//   on UI elements and be consumed before the game responds to them
			void ProcessMouseInputs()
			{
				// pseudo code:
				// rules:
				// - if a mouse is inside a control, it is NOT also inside the form unless the control allows mouse passthrough (in that case, mouse move and mouse left/scroll down still fires on the form)
				// if mouse not currently tracked as down at all:
				// - if mouse not down at all:
				// -- track its movements, entering and exiting forms and controls as appropriate, firing those events and mouse move within those controls
				// -- (note: if mouse leaves the scene control in form mode, it leaves all UI elements.  If it re-enters, UI should immediately respond as if mouse moved again)
				// -- middle button scroll - if left mouse is forcing control focus, only affects that control, otherwise it affects the control the mouse is currently entered
				// - if mouse down in any way:
				// -- right mouse button - activate form, keep that form active, and will be the only one mouse right up causes a respond on.  no other mouse button can cause a response
				//    on any other form, but left down can cause button responses.  If form goes away, mouse right up does nothing.  right mouse up causes the right mouse effect on
				//    whatever control it lifted on
				// -- left mouse button - same as right mouse button, except it is specific to one control (button, text field, etc.) and can only affect that control.  Buttons only
				//    click when mouse left up occurs inside the same button that mouse left down occurred on, etc.
				// -- middle button down - control focus same as left mouse button, except generally its effect only occurs whiel down and stops when it's up
				// -- middle button scroll - if left mouse is forcing control focus, only affects that control, otherwise it affects the control the mouse is currently entered
				// if mouse current down:
				// - if mouse left down was the down event causing mouse down:
				// -- all mouse moves fire only on that control, cannot leave or enter anything else - process move before handling mouse up
				// -- watch for mouse to leave control it downed on, firing proper effects
				// -- if mouse left up, respond properly on each control, calling the proper method
				// - if mouse right down was the down event, mouse left down can still focus on a new control
				// - ui doesn't have strong support for right click operations, but right mouse down should still keep focus on the form it was downed on despite where left down occurs (that is,
				//    left down can only focus on a control in the form that right click occurred on

				// todo: check up and down states on buttons, keep focus locked to affect Getcurrent below
				// todo: see if mouse left main scene, if so affect GetCurrent below

				// see where mouse is and respond with enter and leave events on controls, before handling buttons
				GetCurrentMouseFormAndControl();

				// now process down events
				if (currentMouse->leftButton.down == true)
				{
					if (lastMouseLeftDown == false)
					{
						// track state
						lastMouseLeftDown = true;

						// ignore if mouse not on anything
						if (currentMouseInside.form != nullptr || currentMouseInside.control != nullptr)
						{
							// mark form and controls locked
							controlMouseDownLocked = true;
							formMouseDownLocked = true;

							// mark which form and control locked, even if null
							lockedMouseDownControl = currentMouseInside.control;
							lockedMouseDownForm = currentMouseInside.form;

							// switch focus, fire blur on old and focus on new BEFORE mouse down
							SetControlFocus(lockedMouseDownForm, lockedMouseDownControl);

							if (lockedMouseDownControl != nullptr)
								lockedMouseDownControl->MouseDown(MouseButton::Left);
							else if (lockedMouseDownForm != nullptr)
								lockedMouseDownForm->MouseDown(MouseButton::Left);

							MoveFormToFront(lockedMouseDownForm);
							// activate form event?
							// ??
						}
						else
						{
							// nothing is clicked at all
							// if there are no modal forms up, remove focus from everything
							if (modalDialogs.AnyFormsEnabledAndVisible() == false)
								SetControlFocus(nullptr, nullptr);
						}
					}
				}
				else
				{
					if (lastMouseLeftDown == true)
					{
						// leave focus alone

						if (lockedMouseDownControl != nullptr)
							lockedMouseDownControl->MouseUp(MouseButton::Left);
						else if (lockedMouseDownForm != nullptr)
							lockedMouseDownForm->MouseUp(MouseButton::Left);

						// temp measure so that leave and enter events fire properly
						currentMouseInside.form = lockedMouseDownForm;
						currentMouseInside.control = lockedMouseDownControl;

						formMouseDownLocked = false;
						controlMouseDownLocked = false;
						lockedMouseDownForm = nullptr;
						lockedMouseDownControl = nullptr;

						lastMouseLeftDown = false;
					}
				}

				// record current mouse position for next process
				lastMousePosition.X = currentMouse->currentX;
				lastMousePosition.Y = currentMouse->currentY;
			}

			// moved to .cpp so that GameUIControl's understanding of GameUIForm is well understood
			void ProcessKeyInput(GameInputEvent &p_event);

		private:

			void GetCurrentMouseFormAndControl()
			{
				// note: closing forms don't trigger mouseleft events, but their controls do.  Just like in Windows.  Hiding forms do trigger mouseleft.

				GameUIFormControl sampledCurrentFormControl;
				GetCurrentMouseInside(sampledCurrentFormControl);

				// force focus if locked because of mouse down
				if (sampledCurrentFormControl.form != currentMouseInside.form && formMouseDownLocked == true)
				{
					sampledCurrentFormControl.form = currentMouseInside.form;
					sampledCurrentFormControl.control = nullptr; // prep for mouse up outside of the locked control so that a change can be detected
				}
				if (sampledCurrentFormControl.control != lockedMouseDownControl && controlMouseDownLocked == true)
					sampledCurrentFormControl.control = nullptr; // prep for mouse up outside of the locked control so that a change can be detected

				bool mouseMoveReported = false;
				if (sampledCurrentFormControl.Equals(currentMouseInside) == false)
				{
					if (sampledCurrentFormControl.form == currentMouseInside.form) // mouse still in same form, or control or form is mousedown locked
					{
						// still same form
						if (currentMouseInside.control == nullptr)
						{
							// mouse was inside form, now it's inside control
							if (currentMouseInside.form->IsEnabled() == true && currentMouseInside.form->IsClosed() == false && controlMouseDownLocked == false)
								currentMouseInside.form->MouseLeft();
							if (sampledCurrentFormControl.control->IsEnabled() == true && sampledCurrentFormControl.form->IsEnabled() == true)
							{
								sampledCurrentFormControl.control->MouseEntered(!controlMouseDownLocked);
								MouseMoveArgs moveArgs((GameMouse ^)currentMouse, sampledCurrentFormControl.form, sampledCurrentFormControl.control);
								sampledCurrentFormControl.control->MouseMoved(moveArgs);
								mouseMoveReported = true;
							}
						}
						else
						{
							// mouse has left last current control
							if (currentMouseInside.control->IsEnabled() == true && currentMouseInside.form->IsEnabled() == true)
								currentMouseInside.control->MouseLeft(!controlMouseDownLocked);

							if (sampledCurrentFormControl.control == nullptr)
							{
								// mouse was inside control, now it's inside form
								if (sampledCurrentFormControl.form->IsEnabled() == true && controlMouseDownLocked == false)
								{
									sampledCurrentFormControl.form->MouseEntered();
									MouseMoveArgs moveArgs((GameMouse ^)currentMouse, sampledCurrentFormControl.form);
									sampledCurrentFormControl.form->MouseMoved(moveArgs);
									mouseMoveReported = true;
								}
							}
							else
							{
								// mouse is inside new control
								if (sampledCurrentFormControl.control->IsEnabled() == true && sampledCurrentFormControl.form->IsEnabled() == true)
								{
									sampledCurrentFormControl.control->MouseEntered(!controlMouseDownLocked);
									MouseMoveArgs moveArgs((GameMouse ^)currentMouse, sampledCurrentFormControl.form, sampledCurrentFormControl.control);
									sampledCurrentFormControl.control->MouseMoved(moveArgs);
									mouseMoveReported = true;
								}
							}
						}
					}
					else
					{
						// new form and control
						if (currentMouseInside.control != nullptr)
						{
							if (currentMouseInside.control->IsEnabled() == true && currentMouseInside.form->IsEnabled() && currentMouseInside.form->IsClosed() == false)
								currentMouseInside.control->MouseLeft(!controlMouseDownLocked);
						}
						else if (currentMouseInside.form != nullptr)
						{
							if (currentMouseInside.form->IsEnabled() == true && currentMouseInside.form->IsClosed() == false)
								currentMouseInside.form->MouseLeft();
						}

						if (sampledCurrentFormControl.control != nullptr)
						{
							if (sampledCurrentFormControl.control->IsEnabled() == true && sampledCurrentFormControl.form->IsEnabled() == true)
							{
								sampledCurrentFormControl.control->MouseEntered(!controlMouseDownLocked);
								if (controlMouseDownLocked == false)
								{
									MouseMoveArgs moveArgs((GameMouse ^)currentMouse, sampledCurrentFormControl.form, sampledCurrentFormControl.control);
									sampledCurrentFormControl.control->MouseMoved(moveArgs);
									mouseMoveReported = true;
								}
							}
						}
						else if (sampledCurrentFormControl.form != nullptr)
						{
							if (sampledCurrentFormControl.form->IsEnabled() == true)
							{
								sampledCurrentFormControl.form->MouseEntered();
								MouseMoveArgs moveArgs((GameMouse ^)currentMouse, sampledCurrentFormControl.form);
								sampledCurrentFormControl.form->MouseMoved(moveArgs);
								mouseMoveReported = true;
							}
						}
					}

					currentMouseInside = sampledCurrentFormControl;
				}

				if (mouseMoveReported == false)
				{
					// register moved event if mouse moved and current mouseover hasn't changed
					if (lastMousePosition.X != currentMouse->currentX || lastMousePosition.Y != currentMouse->currentY)
					{
						if (lockedMouseDownControl != nullptr)
						{
							MouseMoveArgs moveArgs((GameMouse ^)currentMouse, lockedMouseDownControl->GetParentForm(), lockedMouseDownControl);
							lockedMouseDownControl->MouseMoved(moveArgs);
						}
						else if (lockedMouseDownForm != nullptr)
						{
							MouseMoveArgs moveArgs((GameMouse ^)currentMouse, lockedMouseDownForm);
							lockedMouseDownForm->MouseMoved(moveArgs);
						}
						else if (currentMouseInside.control != nullptr)
						{
							MouseMoveArgs moveArgs((GameMouse ^)currentMouse, currentMouseInside.form, currentMouseInside.control);
							currentMouseInside.control->MouseMoved(moveArgs);
						}
						else if (currentMouseInside.form != nullptr)
						{
							MouseMoveArgs moveArgs((GameMouse ^)currentMouse, currentMouseInside.form);
							currentMouseInside.form->MouseMoved(moveArgs);
						}
					}
				}
			}

			void GetCurrentMouseInside(GameUIFormControl &p_formControl)
			{
				// todo: if mouse is outside primary scene and left and middle mouse buttons are up, return null on both

				GetCurrentMouseInsideForms(p_formControl, modalDialogs, true);
				if (p_formControl.form != nullptr || p_formControl.control != nullptr)
					return;

				GetCurrentMouseInsideForms(p_formControl, forms, false);
			}

			void GetCurrentMouseInsideForms(GameUIFormControl &p_formControl, GameFormLinkedList &p_formList, bool p_modal)
			{
				// starting top to bottom, find out which form and control (if any) that mouse is currently inside, stop on first occurrence
				LinkedListEnumerator<GameUIFormNode> formEnum = LinkedListEnumerator<GameUIFormNode>(p_formList);
				while (formEnum.MoveNext())
				{
					GameUIForm *form = formEnum.Current()->data.GetGameForm();
					if (form->IsVisible() == false) // todo: enabled too?
						continue;

					if (form->PointIsInside(float(currentMouse->currentX), float(currentMouse->currentY)) == true)
					{
						p_formControl.form = form;

						// see if any controls contain the point
						PointF relativePoint(float(currentMouse->currentX) - form->GetRect().Left, float(currentMouse->currentY) - form->GetRect().Top);
						LinkedListEnumerator<GameUIControlNode> controlEnumerator = form->GetControlEnumerator();
						while (controlEnumerator.MoveNext())
						{
							GameUIControl *control = controlEnumerator.Current()->data.GetControl();
							if (control->IsVisible() == false)
								continue;
							if (control->IsEnabled() == false)
								continue;
							if (control->PointIsInside(relativePoint) == true)
							{
								p_formControl.control = control;
								break; // we're done, this control contains point
							}
						}
						break; // we're done, no controls contain point
					}
					else if (p_modal == true)
					{
						p_formControl.form = form; // modal top form that is visible takes focus regardless (todo: enabled too?)
						return;
					}
				}
			}

			void RenderForms(GraphicsBase *p_graphics, GameFormLinkedList &p_formList, int p_startingStencil = 0)
			{
				p_graphics->Set2dWindowProjection();
				p_graphics->SetDepthTestEnabled(false);
				p_graphics->SetDepthWriteEnabled(false);

				p_graphics->SetStencilEnabled(true);
				p_graphics->StencilMask(0xff);
				int stencilValue = p_startingStencil;

				LinkedListEnumerator<GameUIFormNode> formEnum = LinkedListEnumerator<GameUIFormNode>(p_formList, false);
				while (formEnum.MoveNext())
				{
					GameUIForm *form = formEnum.Current()->data.GetGameForm();
					if (form->IsVisible() == false)
						continue;

					form->Render(p_graphics, p_startingStencil);
				}

				p_graphics->StencilMask(0);
				p_graphics->SetStencilEnabled(false);

				p_graphics->SetDepthWriteEnabled(true);
				p_graphics->SetDepthTestEnabled(true);
			}

			void MoveFormToFront(GameUIFormBase *p_form) override
			{
				GameUIForm *form = (GameUIForm *)p_form;
				// form is invisible, don't do anything
				if (form->IsVisible() == false)
					return;

				GameUIForm *frontForm;
				if (modalDialogs.IsEmpty() == false)
					frontForm = modalDialogs.GetFirstNode()->data.GetGameForm();
				else if (forms.IsEmpty() == false)
					frontForm = forms.GetFirstNode()->data.GetGameForm();
				if (form == frontForm)
					// already in front, nothing to do
					return;

				LinkedListNode<GameUIFormNode> *node = modalDialogs.FindForm(form);
				if (node != nullptr && node != modalDialogs.GetFirstNode())
				{
					modalDialogs.DetachNode(node);
					modalDialogs.InsertNode(node);

					// hand over input focus
					if (node->data.GetGameForm()->IsEnabled() == true)
						SetControlFocus(node->data.GetGameForm(), node->data.GetGameForm()->controlWithFocus);

					// break any hold inputs have on controls
					if (frontForm != nullptr)
						frontForm->FixControlsForFormInactivated();
				}
				else
				{
					LinkedListNode<GameUIFormNode> *node = forms.FindForm(form);
					if (node != nullptr && node != forms.GetFirstNode())
					{
						forms.DetachNode(node);
						forms.InsertNode(node);

						// hand over input focus
						if (node->data.GetGameForm()->IsEnabled() == true)
							SetControlFocus(node->data.GetGameForm(), node->data.GetGameForm()->controlWithFocus);

						// break any hold inputs have on controls
						if (frontForm != nullptr)
							frontForm->FixControlsForFormInactivated();
					}
				}
			}

			void MoveFocusToNextControl(bool p_forward = true) override
			{
				// this assume the form remains the same.  changing forms needs a little more work.
				if (currentFocusForm == nullptr)
					return;

				bool takeNextControl = (currentFocusControl == nullptr); // take first one that accepts focus
				GameUIControl *firstValidControlInList = nullptr;
				GameUIControl *controlToUse = nullptr;
				LinkedListEnumerator<GameUIControlNode> controlEnumerator = currentFocusForm->GetControlEnumerator(p_forward);
				while (controlEnumerator.MoveNext())
				{
					if (controlEnumerator.Current()->data.GetControl()->AcceptsFocus() == true && firstValidControlInList == nullptr)
						firstValidControlInList = controlEnumerator.Current()->data.GetControl();

					if (controlEnumerator.Current()->data.GetControl() == currentFocusControl)
						takeNextControl = true;
					else if (controlEnumerator.Current()->data.GetControl()->AcceptsFocus() == true)
					{
						if (takeNextControl == true)
						{
							controlToUse = controlEnumerator.Current()->data.GetControl();
							break;
						}
					}
				}
				if (controlToUse == nullptr)
					controlToUse = firstValidControlInList; // didn't find one, use the first one
				if (controlToUse != currentFocusControl) // don't bother if control didn't change
				{
					SetControlFocus(currentFocusForm, controlToUse);
				}
			}

			// caret access for controls
			void ResetCaret() override
			{
				textCaret->Reset();
			}

			bool CaretIsVisible() override
			{
				return textCaret->visible;
			}

		public:
			bool ApplyInputEvent(GameInputEvent &p_event)
			{
				// send to ui handler first to see if it gets handled
				switch (p_event.type)
				{
				case GameInputEventType::MouseMove:
					if (preMouseMove != nullptr)
						(this->*preMouseMove)(p_event);
					break;
				case GameInputEventType::MouseUp:
					if (preMouseUp != nullptr)
						(this->*preMouseUp)(p_event);
					break;
				case GameInputEventType::MouseDown:
					if (preMouseDown != nullptr)
						(this->*preMouseDown)(p_event);
					break;
				case GameInputEventType::KeyDown:
					if (preKeyDown != nullptr)
						(this->*preKeyDown)(p_event);
				//	break;
				//case GameInputEventType::KeyPress:
					// todo: do this inside KeyDown because KeyPress happens there too
					if (preKeyPress != nullptr)
						(this->*preKeyPress)(p_event);
					break;
				case GameInputEventType::KeyUp:
					if (preKeyUp != nullptr)
						(this->*preKeyUp)(p_event);
					break;
				}

				bool handled = false;
				if (p_event.handled == false)
				{
					switch (p_event.type)
					{
					case GameInputEventType::MouseMove:
					case GameInputEventType::MouseUp:
					case GameInputEventType::MouseDown:
					case GameInputEventType::MouseWheel:
						currentMouse->ApplyMouseEvent(p_event);
						ProcessMouseInputs();
						handled = true;
						break;

					case GameInputEventType::KeyDown:
					//case GameInputEventType::KeyPress:
					case GameInputEventType::KeyUp:
						ProcessKeyInput(p_event);
						handled = true;

						break;
					}
				}

				if (p_event.handled == false)
				{
					switch (p_event.type)
					{
					case GameInputEventType::MouseMove:
						if (postMouseMove != nullptr)
							(this->*postMouseMove)(p_event);
						break;
					case GameInputEventType::MouseUp:
						if (postMouseUp != nullptr)
							(this->*postMouseUp)(p_event);
						break;
					case GameInputEventType::MouseDown:
						if (postMouseDown != nullptr)
							(this->*postMouseDown)(p_event);
						break;
					case GameInputEventType::KeyDown:
						// todo: do this inside KeyDown because preKeyPress will be there too
						if (postKeyDown != nullptr)
							(this->*postKeyDown)(p_event);
					//	break;
					//case GameInputEventType::KeyPress:
						if (postKeyPress != nullptr)
							(this->*postKeyPress)(p_event);
						break;
					case GameInputEventType::KeyUp:
						if (postKeyUp != nullptr)
							(this->*postKeyUp)(p_event);
						break;
					}
				}

				// todo: return true if mouse event was handled by the UI and triggered a UI event, otherwise game is allowed to handle it.
				// MouseMove might have stopped on a form that doesn't have pass through, might not.  might have foculock on a UI element, might not.  It all matters.  If
				//   the mouse event falls into the game scene, return true - otherwise, return false.
				return handled;
			}

			// get form on top of rendering stack, inactive or not
			GameUIForm * GetTopForm(bool p_activeOnly = false)
			{
				LinkedListEnumerator<GameUIMessageBoxNode> messageBoxEnumerator = LinkedListEnumerator<GameUIMessageBoxNode>(messageBoxes);
				while (messageBoxEnumerator.MoveNext())
				{
					GameUIMessageBox *messageBox = &(messageBoxEnumerator.Current()->data.messageBox);
					if (messageBox->IsClosed() == false)
						return messageBox;
				}

				LinkedListEnumerator<GameUIFormNode> dialogEnumerator = LinkedListEnumerator<GameUIFormNode>(modalDialogs);
				while (dialogEnumerator.MoveNext())
				{
					GameUIForm *dialog = dialogEnumerator.Current()->data.GetGameForm();
					if (dialog->IsVisible() == true && (p_activeOnly == false || dialog->IsEnabled()))
						return dialog;
				}

				LinkedListEnumerator<GameUIFormNode> formEnumerator = LinkedListEnumerator<GameUIFormNode>(forms);
				while (formEnumerator.MoveNext())
				{
					GameUIForm *form = formEnumerator.Current()->data.GetGameForm();
					if (form->IsVisible() == true && (p_activeOnly == false || form->IsEnabled()))
						return form;
				}

				return nullptr;
			}

			GameUIForm * MessageBox(LinkedList<GameRichText> &p_richText, bool p_userClosable = true, bool p_userCloseByEscOnly = false) override // from GameUIBase
			{
				GameUIMessageBox *messageBox = (GameUIMessageBox *)messageBoxes.GetUnusedMessageBox();
				messageBox->SetMessage(p_richText, viewportRef);
				messageBox->SetLocation(PointF(viewportRef->GetWidth() / 2.0f - messageBox->GetRect().Width / 2.0f, viewportRef->GetHeight() / 2.0f - messageBox->GetRect().Height / 2.0f));
				messageBox->SetUserClosable(p_userClosable);
				if (p_userClosable == false)
					messageBox->SetUserClosableByEscOnly(false);
				else
					messageBox->SetUserClosableByEscOnly(p_userCloseByEscOnly);
				messageBox->ShowModal();
				return messageBox;
			}

			GameUIForm * MessageBox(String ^p_message, bool p_userClosable = true, bool p_userCloseByEscOnly = false) override // from GameUIBase
			{
				GameUIMessageBox *messageBox = (GameUIMessageBox *)messageBoxes.GetUnusedMessageBox();
				LinkedList<GameRichText> richText;
				LinkedListNode<GameRichText> *newNode = richText.GetNewNode();
				newNode->data.text = p_message;
				newNode->data.fontRef = defaultFontRef;
				newNode->data.foreColor = defaultForeColor;
				richText.AddNode(newNode);
				messageBox->SetMessage(richText, viewportRef);
				messageBox->SetLocation(PointF(viewportRef->GetWidth() / 2.0f - messageBox->GetRect().Width / 2.0f, viewportRef->GetHeight() / 2.0f - messageBox->GetRect().Height / 2.0f));
				messageBox->SetUserClosable(p_userClosable);
				if (p_userClosable == false)
					messageBox->SetUserClosableByEscOnly(false);
				else
					messageBox->SetUserClosableByEscOnly(p_userCloseByEscOnly);
				messageBox->ShowModal();

				return messageBox;
			}
		};
	}
}