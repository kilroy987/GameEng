#pragma once

#include "Vector.h"
#include "TerrainMeshRegionData.h"
#include "BoundingVolume.h"
#include "GraphicsBase.h"
#include "MathConstants.h"

#include <vcclr.h> // gcroot

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;
		using namespace GameEng::Geometry;

		//class TerrainMeshRegionStitchMap;
		// a single terrain region that is always assumed to be part of a larger region
		// also contains its lods down to 2 cells wide minimum
		// note: level of detail starts at 1 for highest and increases as lod decreases - each step is a reduction by a power of 2, for now, but can change.
		class TerrainMeshRegion
		{
		public:
			float startX, startZ, endX, endZ; // start and end X and Z for each region as they appear in the main mesh

			// which cell index does this region start in the main mesh? (regions always lie exactly on main mesh cell borders)
			int horizontalStartIndex;
			int verticalStartIndex;

			TerrainMeshLevelOfDetail *lods;
			int lodQty;
			BoundingVolume3d boundingVolume; // limit of world coordinates for this region (used to occlude rendering, or other purposes)

			TerrainMeshLevelOfDetail *lodToRenderRef; // repopulated every render to track with LOD to render for each region so that a stitchmap can be built

			TerrainMeshRegion()
			{
				lods = nullptr;
				lodQty = 0;

				horizontalStartIndex = 0;
				verticalStartIndex = 0;
			}

			~TerrainMeshRegion()
			{
				Destroy();
			}

			void Destroy()
			{
				if (lods != nullptr)
				{
					delete [] lods;
					lods = nullptr;
					lodQty = 0;

					horizontalStartIndex = 0;
					verticalStartIndex = 0;
				}
			}

			void Initialize(int p_levelOfDetailQuantity, int p_horizontalStartIndex, int p_verticalStartIndex);
			void CalculateBoundingVolume();
		};

		// Map to use for rendering the center region - the dimensions of the referenced adjacent regions determines how to stitch the rendered region together with the others
		// rules: 
		// If a region has the same or higher level of detail as an adjacent region (1 being highest, > numbers mean lower levels of detail), it is rendering as is
		// If a region as a lower level of detail than an adjacent region, the cells of that edge are discarded and instead the next inner set of points is stitched together with the unmodified
		//   edge of the adjacent region
		// if adjacent region is null, just render the edge cell as is with no modification
		//class TerrainMeshRegionStitchMap
		//{
		//public:
		//	TerrainMeshLevelOfDetail *upperLeftRegionRef;
		//	TerrainMeshLevelOfDetail *upperRegionRef;
		//	TerrainMeshLevelOfDetail *upperRightRegionRef;
		//	TerrainMeshLevelOfDetail *leftRegionRef;
		//	TerrainMeshLevelOfDetail *rightRegionRef;
		//	TerrainMeshLevelOfDetail *lowerLeftRegionRef;
		//	TerrainMeshLevelOfDetail *lowerRegionRef;
		//	TerrainMeshLevelOfDetail *lowerRightRegionRef;

		//	TerrainMeshRegionStitchMap()
		//	{
		//		// at a corner, some regions will be null
		//		upperLeftRegionRef = nullptr;
		//		upperRegionRef = nullptr;
		//		upperRightRegionRef = nullptr;
		//		leftRegionRef = nullptr;
		//		rightRegionRef = nullptr;
		//		lowerLeftRegionRef = nullptr;
		//		lowerRegionRef = nullptr;
		//		lowerRightRegionRef = nullptr;
		//	}
		//};

		class TerrainMesh
		{
			int cellHorizontalQty;
			int cellVerticalQty;

			TerrainMeshCell *cells; // arranged horizontal first, then vertical

			int regionHorizontalQty;
			int regionVerticalQty;

			TerrainMeshRegion *regions; // arranged the same as cells - horizontal row first, then vertical

			float cellWorldWidth;
			float startX, startZ, endX, endZ;  // provide startX and startZ, ends are calculated
			float minY, maxY; // bounding values

			float lodFactor; // factor by which levels of detail become less detailed (usually 2)

			gcroot<GameTexture^>blendMap;

		public:

			// A rectangular large section of terrain, using its own set of textures.  Each height value exists on a square x/z grid, each height measured vertically from each x/z vertex
			// todo: support irregular edges so that artistic landscape assembly can occur
			// todo: support loading regions of terrain as more is needed beyond the current edges, rather than loading full large amounts of terrain at a time.
			// todo: support changing heights later so that everything recalculates down to how the lod regions are represented
			// todo: avoid rendering regions that can't be seen by viewpoint (frustum culling)
			// todo: improve lod y average calculation
			// todo: support factor of lod other than 2 (must be > 1) - done, must test
			// todo: exception on lodfactor <= 1, exception on any main mesh dimension of < 3
			// todo: edge bug on lod calculation - getting y values of e-008

			// - assume terrain is made up of a mesh with square cells, but the overall terrain mesh can be rectangular
			// - this structure automatically supports level of detail and will make regions as square as possible at each level of detail
			// - for best results, however, always used a power of 2 as the cell qty in each dimension
			// - the cell qty in each dimension need not be a power of 2, but must be at least 2 (providing a single point in the center of a renderable region for consistency
			//   with the need to have at least one point within the region kept intact as the borders are stitched during rendering)
			// - the mesh will be divided into regions, and each region will have multiple levels of detail to render to reduce the number of triangles rendered
			// - level of detail is understood to be 1 for the main mesh and the first lod of a region.  lower levels of detail increase the number (2 for the first reduction, then 3, etc.)
			// - system can render adjacent regions that are more than 1 level different in lod
			// - cells have copies of the same vertices for algorithm simplicity and ease of interpreting code (in the case of two horizontally adjacent cells, 
			//   the left cell's ur and lr vertices will equal the right cells ul and ll vertices, etc.).  this is also true for regions of the same lod, and the edges of two
			//   regions regardless of which lod should share the same appropriate coordinates (shared corners should be guaranteed to be equal, edges are only guaranteed to equal on that single coordinate)
			//   - also, regions regardless of lod will absolutely be equal along the x and z coordinates for each edge and corner, although the cell progression along each edge will not be
			//   - that is, a left and right region will share the same right x and left x on their edges accordingly amd have the same ur and lr x,z and ul and ll x,z, but the z's on the cells in between
			//     will not be equal in the case of different lod's

			// The terrain mesh itself is not rendered - its regions are rendered in order to handle them in chunks
			// each region is mostly rendered as a series of triangle fans for quickness
			// however to splice together regions of different lod levels, the edges must be stitched according to how a region is surrounded
			//    by regions of various lod
			// for clarity, stitching involves figuring out which vertex in one region needs to stitch to which point in the other region, and this
			//    is determined by progressing along vertex values naturally
			// regions of lower lod will be forced to take on stitches of higher lod at their edges when rendered next to regions of higher lod
			// edges and corners are stitched separately - the criteria for where edge stitched triangles begin and end in the case of coordinate calues between lods that aren't equal
			//   are arranged so that corner stitching is easier.

			// lod 1 is highest (= main mesh).  2 is half that size, etc. these numbers are only used to determine how many levels removed adjacent regions are in level of detail, and determine
			//   equality durign the rendering loop.

			// terrain is rendered as follows:
			// ----- z
			// | / |
			// ----- 0
			// x   0
			// the coordinates are done this way to coincide with how the Orient3d structure is set up (x is positive to the left, y is positive upwards)
			// so when bitmaps are loaded, the lower right point is the origin
			// cell array is arranged with adjacent cells making up a row horizontally, then rows piled vertically
			// so cell++ will give you the next horizontal cell until you reach the end, then starts over on the first cell of the next row
			// more detailed terrain renderers will place yet another point in the center of the cell - that will be supported with a different class later - such
			//    an arragement would allow the pixel height to represent the center point, and the edges will be averages between one center and the next
			// cells in the main mesh and regions are redundant on the vertices they store: cell h,v ul = cell h+1,v ur = cell h,v+1 ll = cell h+1,v+1 lr.  This is for algorithm simplicity.
			//    Later, the extra vertices can be removed to save space, but for now, it makes the code more readable.

			// Regions will be as much the same size as possible for rendering consistency, and as square as possible for consistency.  
			// Once the regions are established, their borders to each other are solid, and lod will
			//   be handled at the region level - when rendered, adjacent regions may be rendered at different lods

			// note: a 1024x1024 vertex terrain map only has 1023 cells across since the last point is part of the final cell, and one more cell wouldn't have data for the last corner
			// this will need consideration later when two terrain meshes are spliced together for rendering, since two adjacent terrain meshes will NOT share the same edge points (even though
			//   adjacent regions within the same mesh do).  Loading additional terrain meshes and discarding current may be necessary when developing very large games that don't need to record or
			//   determine highly granular activity in terrain that is not within range of the player

			////////////////
			// Creation logic
			// - Establish main cell dimensions, max region cell dimension, world cell size
			//	  - Determine start/end X/Z
			//	  - Determine regions (as square as possible, obeying max size but could be smaller)
			//		- Determine start/end X/Z for region
			//		- Determine LOD lists within regions (dimensions only, down to min cell dimension 2), lod 1 being = main mesh cells, 2 being half the cell dimension with same world size of region, etc.
			//		   - Determine X/Z values for each cell in each lod
			//		   - Note: LODs share the same start/end X/Z - it's the cell dimensions and x/z coords of each cell point that differ, and the y values are averaged/calculated from the main mesh
			// - Establish height values on main terrain mesh
			//	  - Determine all LOD height values
			//		 - If a good y (that is, equal) cannot be determined between adjacent regions of the same lod due to differing cell dimensions, a cleanup routine can give 
			//          precedence to the lower x/z region and force the higher one to have the same y values.  So call a cleanup routine afterwards
			//	  - Calculate normals
			// - This can be accomplished with manual method calls, or basing the terrain mesh on a grayscale height map
			// - It is possible to save off the calculated structure and just load it later to prevent all of this extra calculation

			///////////////
			// Rendering
			// - Based on distance criteria provided, determine the lod to use for each region (prepare the entire structure for the mesh and submit it with the lower level render)
			// - Send orientation of camera to help occlude regions that cannot be seen
			// - adjacent regions of same lod don't need to be stitched, but the corners might if the corner lod is higher
			// - adjacent regions of differing lod will give precedence to the better lod and abandon the edge vertices of the worse lod region, stitching them together one cell in and keeping
			//    texture coordinates proper where applicable

			TerrainMesh()
			{
				cellHorizontalQty = 0;
				cellVerticalQty = 0;
				cells = nullptr;

				regionHorizontalQty = 0;
				regionVerticalQty = 0;
				regions = nullptr;

				cellWorldWidth = 0.0f;

				lodFactor = 2.0f;

				blendMap = nullptr;
			}

			~TerrainMesh()
			{
				Destroy();
			}

			void Destroy()
			{
				if (cells != nullptr)
				{
					delete[] cells;
					cells = nullptr;
					cellHorizontalQty = 0;
					cellVerticalQty = 0;
				}

				if (regions != nullptr)
				{
					delete[] regions;
					regions = nullptr;
					regionHorizontalQty = 0;
					regionVerticalQty = 0;
				}

				if (static_cast<GameTexture^>(blendMap) != nullptr)
				{
					delete blendMap;
					blendMap = nullptr;
				}
			}

			// use a gray-scale terrain bitmap to populate the heights
			void Initialize(System::Drawing::Bitmap ^p_gameBitmap, float p_startWorldX, float p_startWorldZ, float p_cellWorldWidth, float p_heightValuePerColorValue, float p_lodFactor = 2.0f)
			{
				cellHorizontalQty = p_gameBitmap->Width-1; // don't make a cell for the last pixel - it will be contained in the last cell of the terrain
				cellVerticalQty = p_gameBitmap->Height-1;
				CreateCells(p_gameBitmap->Height-1, p_gameBitmap->Width-1);

				startX = p_startWorldX;
				startZ = p_startWorldZ;
				cellWorldWidth = p_cellWorldWidth;
				endX = startX + cellWorldWidth * float(cellHorizontalQty);
				endZ = startZ + cellWorldWidth * float(cellVerticalQty);

				lodFactor = p_lodFactor;

				SetXZ();

				PopulateHeights(p_gameBitmap, p_heightValuePerColorValue);
			}
			void Initialize(int p_cellHorizontalQty, int p_cellVerticalQty, float p_startWorldX, float p_startWorldZ, float p_cellWorldWidth, float p_lodFactor = 2.0f)
			{
				CreateCells(p_cellHorizontalQty, p_cellVerticalQty);
				startX = p_startWorldX;
				startZ = p_startWorldZ;
				cellWorldWidth = p_cellWorldWidth;
				endX = startX + cellWorldWidth * float(p_cellHorizontalQty);
				endZ = startZ + cellWorldWidth * float(p_cellVerticalQty);
				lodFactor = p_lodFactor;

				SetXZ();
			}

			float GetStartX() { return startX;  }
			float GetStartZ() { return startZ; }
			float GetEndX() { return endX; }
			float GetEndZ() { return endZ; }

		private:
			//void PopulateHeights(GameBitmap *p_gameBitmap, float p_heightValuePerColorValue);
			void CreateCells(int p_horizontalQty, int p_verticalQty);

		public:
			// method to controllably populate a terrain
			// set entire terrain to a given height
			void SetHeight(float p_height); // mostly for testing
			void SetGreatestXZHeight(); // mostly for testing
			void PlaceSquarePlateau(float p_startX, float p_startZ, float p_endX, float p_endZ, float p_height, float p_inclinationAngleDegrees);
			void PlaceCircularMountain(float p_centerX, float p_centerZ, float p_height, float p_inclinationAngleDegrees);

			// largest region dimension is recommended to be 64 or 128 for now, but can be any value (must be at least 2)
			// call in this order
			void CalculateNormalsAndSegments();
			void CalculateColors(Vector3d &p_lightSourceDirectionUnit, GameColor p_shadeColor, GameColor p_brightColor); // requires normals
			void ObscureColorByYValue(GameColor &p_color, float p_startingDepth, float p_factorPerUnit);
			void CalculateLevelOfDetailRegions(int p_largestRegionCellDimension); // requires colors from main
			void CalculateLevelOfDetailHeights(); // requires lod regions
			void CalculateLevelOfDetailColors(); // requires lod regions
			void CalculateBoundingVolumes(); // requires lod regions

			// figure out lods to use for each region and render each
			// minimum level of detail actually referes to how many steps down the lod can go - 1 means render at max.  3 means go 2 levels deep max, etc.
			TerrainMeshLevelOfDetail * DetermineLevelOfDetailToRender(Orient3d &p_camera, TerrainMeshRegion *p_region, int p_mininumLevelOfDetail, float p_worldDistancePerLevelOfDetail);
			void Render(Orient3d &p_camera, GraphicsBase &p_graphics, int p_minimumLevelOfDetail, float p_worldDistancePerLevelOfDetail, gcroot<GameTexture^> *p_textures = nullptr, float p_XZPerWrap = 0.0f);

			// simple file outputs for now
			bool LoadMeshFromFile(String ^p_filePath, float p_startWorldX, float p_startWorldY, float p_cellWorldWidth, float p_lodFactor = 2.0f);
			void WriteMeshToFile(String ^p_filePath);

			void CreateBlendMap(float p_minimumHeight, int p_minimumHeightTerrainType, float p_maximumHeight, int p_maximumHeightTerrainType, float p_maximumSlope, int p_maximumSlopeTerrainType, int p_remainingType);

		private:
			float CalculateLevelOfDetailHeight(float p_worldX, float p_worldZ, float p_widthX, float p_widthZ);
			GameColor CalculateLevelOfDetailColor(float p_worldX, float p_worldZ, float p_widthX, float p_widthZ);
			void SetXZ()
			{
				float currentZ = startZ;
				for (int cellVerticalIndex = 0; cellVerticalIndex < cellVerticalQty; cellVerticalIndex++)
				{
					float currentX = startX;
					for (int cellHorizontalIndex = 0; cellHorizontalIndex < cellHorizontalQty; cellHorizontalIndex++)
					{
						TerrainMeshCell *cell = &cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex];

						cell->SetXZ(currentX, currentZ, currentX + cellWorldWidth, currentZ + cellWorldWidth);

						currentX += cellWorldWidth;
					}
					currentZ += cellWorldWidth;
				}
			}

			void PopulateHeights(System::Drawing::Bitmap ^p_Bitmap, float p_heightValuePerColorValue)
			{
				int cellHorizontalIndex = 0;
				// don't parse last pixel, grab it within the cell setting
				for (int hPixel = 0; hPixel < p_Bitmap->Width-2; hPixel++)
				{
					int cellVerticalIndex = 0;
					for (int vPixel = 0; vPixel < p_Bitmap->Height - 2; vPixel++)
					{
						System::Drawing::Color colorLR = p_Bitmap->GetPixel(hPixel, vPixel);
						System::Drawing::Color colorLL = p_Bitmap->GetPixel(hPixel+1, vPixel);
						System::Drawing::Color colorUR = p_Bitmap->GetPixel(hPixel, vPixel+1);
						System::Drawing::Color colorUL = p_Bitmap->GetPixel(hPixel+1, vPixel+1);

						TerrainMeshCell *cell = &cells[cellVerticalIndex * cellHorizontalQty + cellHorizontalIndex];
						cell->SetY(
							float(colorLR.R) * p_heightValuePerColorValue,
							float(colorLL.R) * p_heightValuePerColorValue,
							float(colorUR.R) * p_heightValuePerColorValue,
							float(colorUL.R) * p_heightValuePerColorValue
							);

						cellVerticalIndex++;
					}

					cellHorizontalIndex++;
				}
			}

		public:
			bool SphereCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, float &p_collisionT, Vector3d &p_collisionLocation, Vector3d &p_collisionNormal);
			bool SphereIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_collisionNormal);
		};
	}
}