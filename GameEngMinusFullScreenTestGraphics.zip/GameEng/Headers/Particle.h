#pragma once

#include "Vector.h"
#include "GameColor.h"
#include "Orient.h"
#include "GameTexture.h"
#include <vcclr.h> // gcroot

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;

		// a single particle to render
		// textures to be used for particles are stored in the ParticleArray
		class Particle
		{
		public:
			GameColor color;
			int maxLifeMS; // when should it go away
			bool dead; // dead particle - do not render, assume all particles past this particle are also dead
			int textureIndex;

			// alpha formula for ax+b, where x = lifeMS, usually similar to b-ax where b is max alpha and b-a*maxLifeMS = 0
			// note: max alpha is 1.0, NOT 255
			float alphaA;
			float alphaB;

			// position = at^2 + bt + c, t = lifeMS
			// c is usually start position
			// for a particle that simply floats in a direction, b is the velocity
			// for a particle that responds to gravity, with v = original velocity and g = gravity acceleration:
			//   - c = original position, b = v, and a = 1/2*g
			Vector3d positionA;
			Vector3d positionB;
			Vector3d positionC;

			// linear calculation of radius: a*t+b;
			// for constant radius, a = 0 and b = original radius
			// for expanding radius, a = expansion rate per MS and b = original radius
			float radiusA;
			float radiusB;

			// value for sorting high to low, calculate before each render with a given viewpoint, sorted before render
			float zDepth;

			// other data for rendering
			float rotationAngleDegrees;

			// calculated values
			float lifeMS; // how long has it existed
			Vector3d position;
			float radius;
			float alpha; // 0.0-1.0, not 0-255

			Particle()
			{
				Initialize();
			}

			void Initialize()
			{
				lifeMS = 0.0f;
				maxLifeMS = 1000000; // 100 seconds, will be reduced later
				rotationAngleDegrees = 0.0f;
				dead = true; // until some form of values set
				textureIndex = 0;
			}

			void SetTextureIndex(int p_textureIndex)
			{
				textureIndex = p_textureIndex;
			}

			void SetAlphaFormula(float p_startAlpha, float p_alphaReductionPerMS, int p_maxLifeMS = 0)
			{
				alphaB = p_startAlpha;
				if (p_alphaReductionPerMS != 0)
				{
					alphaA = -p_alphaReductionPerMS;
					maxLifeMS = int(p_startAlpha / p_alphaReductionPerMS);
				}
				else
				{
					alphaA = 0;
					maxLifeMS = p_maxLifeMS;
				}
				if (maxLifeMS == 0)
				{
					throw gcnew Exception("Max Life MS cannot be 0");
				}
				if (maxLifeMS < 0)
				{
					throw gcnew Exception("Max Life MS cannot be negative");
				}
				dead = false;
			}

			void SetRadiusFormula(float p_startRadius, float p_radiusExpansionPerMS = 0.0f)
			{
				radiusB = p_startRadius;
				radiusA = p_radiusExpansionPerMS;
				if (radiusA < 0.0)
				{
					int tempMaxLifeMS = int(radiusB / -radiusA);
					if (tempMaxLifeMS == 0)
					{
						throw gcnew Exception("Max Life MS cannot be 0");
					}
					if (tempMaxLifeMS < 0)
					{
						throw gcnew Exception("Max Life MS cannot be negative");
					}

					if (tempMaxLifeMS < maxLifeMS)
						maxLifeMS = tempMaxLifeMS;

					dead = false;
				}
			}

			void SetPositionFormula(Vector3d &p_startPosition)
			{
				positionC = p_startPosition;
				positionB = Vector3d(0, 0, 0);
				positionA = Vector3d(0, 0, 0);
				dead = false;
			}

			void SetPositionFormula(Vector3d &p_startPosition, Vector3d &p_velocityPerMS)
			{
				positionC = p_startPosition;
				positionB = p_velocityPerMS;
				positionA = Vector3d(0, 0, 0);
				dead = false;
			}

			void SetPositionFormula(Vector3d &p_startPosition, Vector3d &p_startVelocityPerMS, Vector3d &p_accelerationPerMSMS)
			{
				positionC = p_startPosition;
				positionB = p_startVelocityPerMS;
				positionA = p_accelerationPerMSMS;
				dead = false;
			}

			//////////////////////////////////////
			// do this before calling Calculate
			void SetLife(float p_elapsedTimeMSf)
			{
				lifeMS += p_elapsedTimeMSf;
				if (lifeMS >= maxLifeMS)
					dead = true;
			}

			bool IsDead()
			{
				return dead;
			}

			/////////////////////////////////
			// calculation before rendering
			void PrepareAlpha()
			{
				if (alphaA == 0)
					alpha = alphaB;
				else
				{
					alpha = alphaB + alphaA * lifeMS;
				}

				if (alpha > 1.0f)
					alpha = 1.0f;
				if (alpha < 0.0f)
					alpha = 0.0f;
			}

			void PreparePosition()
			{
				position = positionA.ScalarMult(lifeMS * lifeMS) + positionB.ScalarMult(lifeMS) + positionC;
			}

			void PrepareRadius()
			{
				if (radiusA == 0.0f)
					radius = radiusB;
				else
				{
					radius = radiusB + radiusA * lifeMS;
				}

				if (radius < 0.0f)
					radius = 0.0f;
			}

			//////////////////////////////////////////////////
			// zDepth calculation - need to store for sorting
			void PrepareZDepth(Vector3d &p_viewpointOrigin, Vector3d &p_viewpointForwardVector)
			{
				zDepth = (position - p_viewpointOrigin) * p_viewpointForwardVector;
			}

			Vector3d CalculateRenderOffset(Orient3d &p_viewpointOrient)
			{
				Vector3d offset = position - p_viewpointOrient.p;
				return Vector3d(
					offset * p_viewpointOrient.l,
					offset * p_viewpointOrient.u,
					zDepth
					);
			}
		};

		// a single particle storage, rendered with the same blending option (additive for energy effects like sparks, energy blasts and fire, alpha for occlusion effects like smoke and fogged glass)
		// a single particle storage is rendering as one large unit - it is not intermixed with other particles in any sort of scene graph - but multiple particle storages can be rendered back to
		//   front if they have been arranged that way
		class ParticleArray
		{
		public:
			// note: dead particles are grouped at the end by sorting.  as lifeMS is applied, more die but stay where they are until sorted, at which point the dead ones are again collected at the end and
			//   deadParticleIndex is updated (reduced)
			// deadParticleIndex is increased when new particles are added unless full (deadParticleIndex = particleQty)
			// during rendering:
			// - calculate position for all particles and calculate zdepth so that they can be sorted
			// - if not blending additive, sort them back to front
			// - loop through all particles up to deadParticle Index
			//	- calculate alpha and radius
			//	- render particle

			// 3 main ways to render particles:
			// 1 - animate, sort, prepare alpha and radius and render all CPU-side with old pipeline (RenderParticles)
			// 2 - animate, sort, prepare alpha and radius, upload to GPU CPU-side, render with shader GPU-side (CreateNativeParticles, RenderNativeParticles)
			// 3 - add only new particles to GPU and provide new particleQty CPU-side (instruct to initialize if changed), then animate, sort, prepare alpha and radius and render GPU-side, provide new deadParticleIndex back to CPU-side (CreateNativeParticles, AddAnimateAndRenderNativeParticles)
			Particle *particles;
			int arraySize; // size of array
			int particleQty; // max index to use for actual particles, -1 (allows toggling different numbers of particles) - MUST be a power of 2 for bitonic sorting!!!!
			int deadParticleIndex; // index of first dead particle

			gcroot<GameTexture^> *textures;
			int textureQty;

			bool verifySort;
			int sortParses; // metrics

			bool additiveBlending;

			ParticleArray(int p_arraySize, int p_particleQty, int p_textureQty)
			{
				particles = nullptr;
				arraySize = 0;
				particleQty = 0;
				deadParticleIndex = 0;
				verifySort = false;
				sortParses = 0;
				additiveBlending = false;

				Initialize(p_arraySize, p_particleQty, p_textureQty);
			}

			~ParticleArray()
			{
				if (particles != nullptr)
				{
					delete[] particles;
					particles = nullptr;
					particleQty = 0;
					arraySize = 0;
					deadParticleIndex = 0;
				}
				if (textures != nullptr)
				{
					delete[] textures;
					textures = nullptr;
					textureQty = 0;
				}
			}

			void Initialize(int p_arraySize, int p_particleQty, int p_textureQty)
			{
				arraySize = p_arraySize;
				particles = new Particle[arraySize];
				SetParticleQty(p_particleQty);

				if (p_textureQty > 0 && p_textureQty < 8)
				{
					textures = new gcroot<GameTexture^>[p_textureQty];
					textureQty = p_textureQty;
				}
				// todo: error on too many textures
			}

			void SetTexture(int p_index, GameTexture ^p_texture)
			{
				textures[p_index] = p_texture;
			}

			void SetParticleQty(int p_particleQty)
			{
				if (particleQty <= arraySize)
				{
					particleQty = p_particleQty;
					for (int i = 0; i < particleQty; i++)
					{
						particles[i].Initialize();
					}
					deadParticleIndex = 0;
					ValidateParticleQty();
				}
			}

			void SetVerifySort(bool p_verifySort)
			{
				verifySort = p_verifySort;
			}

			void ValidateParticleQty()
			{
				if (particleQty < 2 || ((particleQty & (particleQty - 1)) != 0))
					throw gcnew Exception("Particle Qty MUST be a power of 2 for bitonic sort");
			}

			Particle *AddNewParticle()
			{
				if (deadParticleIndex < particleQty)
				{
					deadParticleIndex++;
					return &particles[deadParticleIndex - 1];
				}
				else
					return nullptr;
			}

			void PrepareParticlesForRendering(float p_elapsedTimeMSf, Vector3d &p_viewpointPosition, Vector3d &p_viewpointForwardVector)
			{
				// animate them
				Particle *particle = &particles[0];
				for (int i = 0; i < deadParticleIndex; i++)
				{
					particle->SetLife(p_elapsedTimeMSf);
					if (particle->dead == false)
					{
						particle->PreparePosition();
						particle->PrepareZDepth(p_viewpointPosition, p_viewpointForwardVector);
					}
					particle++;
				}

				// sort them ALWAYS - to move dead ones to the end (todo: faster algorithm to ONLY move the dead ones when additiveBlending is true, no need to sort the rest in that case)
				// this modifies the deadParticleIndex (only to be smaller)
				BitonicSortParticles();

				// final preparation before rendering
				particle = &particles[0];
				for (int i = 0; i < deadParticleIndex; i++)
				{
					if (particle->zDepth > 0)
					{
						particle->PrepareAlpha();
						particle->PrepareRadius();
					}
					particle++;
				}
			}

			/////////////////
			private:
			void BitonicSortParticles()
			{
				sortParses = 0;

				int mainSeries = 2;
				while (mainSeries <= particleQty)
				{
					int subSeries = 2;
					bool breakOut = false;

					while (subSeries <= mainSeries)
					{
						int modCheck = mainSeries / subSeries;

						////////////////////////////////
						// multithreading : initialize mutex guarded int to zero
						// mutex threadsCompleted = 0;

						int index = 0;
						int swapDirection = 0;
						while (index < particleQty - 1)
						{
							sortParses++;

							////////////////////////
							// new thread here!  perform this operation in it!
							// index and index + modCheck will never be equal to any of the values sent to the other threads, so none will ever step on each other (0-4, 1-5, 2-6, 3-7, 8-12, 9-13, etc.)
							// optionally, provide values so that multiple pairs are checked and swapped to reduce the number of threads needed (ideally, split all the work among # threads = cpu)
							// threadQty++;

							// do a compare and swap
							bool swap = false;
							if (swapDirection % 2 == 0)
							{
								// down (normal)
								if (particles[index].dead == true && particles[index + modCheck].dead == false)
									swap = true;
								else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth < particles[index + modCheck].zDepth)
									swap = true;
							}
							else
							{
								// up
								if (particles[index].dead == false && particles[index + modCheck].dead == true)
									swap = true;
								else if (particles[index].dead == false && particles[index + modCheck].dead == false && particles[index].zDepth > particles[index + modCheck].zDepth)
									swap = true;
							}

							if (swap == true)
							{
								Particle temp = particles[index];
								particles[index] = particles[index + modCheck];
								particles[index + modCheck] = temp;
							}

							// todo: thread reports that it is complete on a mutex guarded int (increment it)

							// end thread!
							//////////////////////////

							index++;
							if (index % modCheck == 0)

							{
								index += modCheck;

								if (index % mainSeries == 0)

									swapDirection++;

							}
						}

						///////////////////////////////////////////////////////////////////////////////////////////////////
						// if multi threading, do NOT continue from this point until all threads have reported completed!
						// todo: mutex request int, compare its value to # threadQty

						if (swapDirection == 0 && subSeries == mainSeries)

						{
							// we are done
							breakOut = true;
							break;
						}

						subSeries *= 2;
					}

					if (breakOut == true)
						break;

					mainSeries *= 2;
				}

				// establish new deadindex - assumed that deadindex should not go up (when new particles are inserted - already done there), only down (after applying lifeMS and resulting in more dead ones)
				for (int i = deadParticleIndex; i >= 0; i--)
				{
					// not really needed, just being safe
					if (i >= particleQty)
						continue;

					if (particles[i].dead == false)
					{
						deadParticleIndex = i + 1;
						break;
					}
				}

				// check sorting, make sure it's good
				if (verifySort == true)
				{
					for (int i = 0; i < particleQty - 2; i++)
					{
						if (particles[i].dead == true && particles[i + 1].dead == false)
							throw gcnew Exception("Sort failed - dead out of order");
						else if (particles[i].dead == false && particles[i + 1].dead == false && particles[i].zDepth < particles[i + 1].zDepth)
							throw gcnew Exception("Sort failed - zdepth out of order");
					}
				}
			}
		};
	}
}