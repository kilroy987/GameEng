#pragma once

#include "Vector.h"
#include "LinkedListTemplate.h"

namespace GameEng {
	namespace Widgets {

		using namespace GameEng::Math;
		using namespace GameEng::Storage;

		// This class is in heavy need of a templated upgrade, allowing additional values on the trail itself to identify its purpose and additional values to guide the interpolation of the points,
		//   and additional vlaues on the points themselves, along with implementation calls (or virtual overrides) to populate those values meaningfully as events occur

		class AlphaTrailPoint
		{
		public:
			Vector3d location; // position in world space
			unsigned char alpha; // could be a float, but really doesn't matter much here
			int lifeMS; // how long has the point existed
			float totalLength; // guides how to texture map the trail
		};

		// the idea of the smoke trail:
		// - it can be released at various speeds, and each point should only last a given number of seconds (the same for each), starting at beginning alpha and linearally reducing to zero
		// - each point will need a life span that starts at full alpha and counts down to 0.  Alpha is linearly interpolated between two points, and
		//    when one point disappears due to 0 alpha, the point will move along its segment providing the 0 alpha point as the other point works its way to 0,
		//    providing a clean linear disappearance of the effect (the ratio of how much the non-zero alpha point reduced its alpha this tick is how much the line shortens)
		// - additionally, optionally the trail widens at an linear rate to simulate smoke spread
		// - the render can happen as a multidirectional polygonal shape or as a billboard structure, or simply lines, whatever is appropriate.  The main
		//   methodology is the alpha disappearance of the trail.  The rendering is implementation specific.  The disappearance of the snoke trail is the main
		//   functionality here.
		// later nodes are assumed to be newer than prior nodes. (smaller lifeMS)
		class AlphaTrail : public LinkedList<AlphaTrailPoint>
		{
		public:
			int maxLifeMS; // how long does the smoke last?
			unsigned char beginningAlpha; // current alpha = beginningAlpha * (maxLifeMS - lifeMS) / maxLifeMS until zero, then shorten segment or remove point as appropriate
			int type; // implementation defined type to deal with rendering

			unsigned char CalculateAlpha(int p_lifeMS)
			{
				if (p_lifeMS >= maxLifeMS)
					return 0;
				else if (p_lifeMS <= 0) // shouldn't happen, but just in case
					return maxLifeMS;
				else
					return unsigned char(float(beginningAlpha) * float(maxLifeMS - p_lifeMS) / float(maxLifeMS));
			}

			LinkedListNode<AlphaTrailPoint> * Add(Vector3d p_location, int p_lifeMS = 0)
			{
				LinkedListNode<AlphaTrailPoint> *newPoint = nullptr;
				newPoint = GetNewNode();
				newPoint->data.location = p_location;
				newPoint->data.lifeMS = p_lifeMS;
				newPoint->data.alpha = CalculateAlpha(newPoint->data.lifeMS);

				if (IsEmpty())
					newPoint->data.totalLength = 0.0f;
				else
				{
					if (p_lifeMS > GetLastNode()->data.lifeMS)
						throw gcnew System::Exception("LifeMS must be equal to or lower than the current last node's lifeMS");

					newPoint->data.totalLength = (GetLastNode()->data.location - newPoint->data.location).Magnitude() + GetLastNode()->data.totalLength;
				}

				AddNode(newPoint);

				return newPoint;
			}

			void FadeTrail(int p_elapsedTimeMS)
			{
				// this loop assumes that lifeMS continues downward as the parse moves forward in the list. (Add() prevents anoy other condition)
				// otherwise, an exception may occur as inappropriate nodes are deleted or false assumptions are made by the code.
				// this structure could be later upgraded to allow dipes in lifeMS, but the expectation would be to have the fading travel outward from the alpha = 0 point in both directions,
				//   or split the list (which would require a reference to an alpha trail list where another could be created)

				if (p_elapsedTimeMS == 0)
					return;

				LinkedListEnumerator<AlphaTrailPoint> smokeTrailEnumerator = LinkedListEnumerator<AlphaTrailPoint>(*this);
				LinkedListNode<AlphaTrailPoint> *priorPointNode = nullptr;
				while (smokeTrailEnumerator.MoveNext())
				{
					AlphaTrailPoint *currentPoint = &(smokeTrailEnumerator.Current()->data);
					int oldAlpha = currentPoint->alpha;
					currentPoint->lifeMS += p_elapsedTimeMS;
					currentPoint->alpha = CalculateAlpha(currentPoint->lifeMS);

					if (currentPoint->alpha == 0)
					{
						if (priorPointNode != nullptr)
						{
							// get rid of prior node - both alphas are zero (this doesn't impact the enumerator since we passed it already)
							DeleteNode(priorPointNode);
						}
					}
					else if (priorPointNode != nullptr)
					{
						if (priorPointNode->data.alpha == 0)
						{
							// shorten the prior segment by the ratio the alpha reduced
							float ratio = float(currentPoint->alpha) / float(oldAlpha);
							priorPointNode->data.location = currentPoint->location + (priorPointNode->data.location - currentPoint->location).ScalarMult(ratio);
							// adjust length to keep texture mapping sensible
							priorPointNode->data.totalLength = currentPoint->totalLength - (priorPointNode->data.location - currentPoint->location).Magnitude();
						}
					}

					priorPointNode = smokeTrailEnumerator.Current();
				}

				// if only one node left and the alpha is zero, clear the whole thing.
				if (header.next->next == (&footer) && header.next->data.alpha == 0)
				{
					Clear();
				}
			}
		};
	}
}