#pragma once

#include <string.h>
#include <winsock.h>
#include "LinkedListTemplate.h"
#include "Tools.h"

namespace GameEng {
	namespace Network {

#define INCOMING_PACKET_STORAGE_SIZE 32000
#define INCOMING_PACKET_MAX_SIZE 9000
#define INTERNAL_PACKET_MAX_SIZE 8400 // leaves room for hash guid if ever coded up (total can't exceed 9000)

#define UDP_HASH_KERNEL_SIZE 16
#define UDP_HASH_SALT_SIZE 16

#define GAMENETWORK_FRAMEWORK_VERSION "1.0.2"

// 1.0.2 - connect routine no longer blocks process - OnConnectFailure() or OnConnectSuccess() will eventually be called, game process should ALWAYS call network->Process() when active.

		using namespace System;
		using namespace GameEng::Storage;
		using namespace GameEng::Tools::Timer;
		using namespace GameEng::Tools::Random;

		// player data, including the server player, if any
		// game is expected to override this with all other data (color, game specific elements, etc. but id is the tag that equates the player with the client data)
		class GameNetworkPlayerBase
		{
		public:
			int id; // matching id in GameNetworkClient (player id = client id, for now, to keep them related)
			char name[33]; // player name = client[].name - need this here because client machines don't maintain a client list
			bool server; // is this player the server?
			bool host; // is this player the game host? (server hosting, or player joining as Host)

			GameNetworkPlayerBase()
			{
				Clear(); // note: this will call the derived class Clear() which should then call our clear.
			}

			virtual ~GameNetworkPlayerBase()
			{
				Clear(); // note: this will call the derived class Clear() which should then call our clear.
			}

			virtual void Clear()
			{
				id = -1;
				strcpy_s(name, 33, "");
			}

			String ^GetName()
			{
				return gcnew String(name);
			}
		};

		typedef GameNetworkPlayerBase * GameNetworkPlayerBasePtr;

		public class GameNetworkPlayerNode
		{
		public:
			GameNetworkPlayerBasePtr player;

			GameNetworkPlayerNode()
			{
				player = nullptr;
			}

			~GameNetworkPlayerNode()
			{
				Destroy();
			}

			void Destroy()
			{
				// this is a rare circmstance where we create and destroy an element constantly, which could be a problem in a system with thousands of joiners and leavers
				if (player != nullptr)
				{
					delete player;
					player = nullptr;
				}
			}
		};

		class GameNetworkPlayerList : protected LinkedList<GameNetworkPlayerNode>
		{
		public:
			// p_player is a created instance that should NOT be destroyed
			// this is a rare circumstance where we create and destroy an element constantly, which could be a problem in a system with thousands of joiners and leavers
			void AddPlayer(GameNetworkPlayerBasePtr p_newPlayer)
			{
				if (p_newPlayer->id < 0)
					throw gcnew Exception("ID on new player must be >= 0");
				if (strlen(p_newPlayer->name) == 0)
					throw gcnew Exception("Name must not be empty");

				LinkedListNode<GameNetworkPlayerNode> *newNode = GetNewNode();
				// deallocate what's there
				newNode->data.Destroy();
				newNode->data.player = p_newPlayer;
				AddNode(newNode);
			}

			GameNetworkPlayerBasePtr GetPlayer(int p_id)
			{
				LinkedListNode<GameNetworkPlayerNode> *playerNode = GetPlayerNode(p_id);
				if (playerNode != nullptr)
					return playerNode->data.player;

				return nullptr;
			}

			GameNetworkPlayerBasePtr GetHostPlayer()
			{
				LinkedListNode<GameNetworkPlayerNode> *hostNode = GetHostPlayerNode();
				if (hostNode != nullptr)
					return hostNode->data.player;

				return nullptr;
			}

			void RemovePlayer(int p_id)
			{
				LinkedListNode<GameNetworkPlayerNode> *playerNode = GetPlayerNode(p_id);
				if (playerNode != nullptr)
				{
					playerNode->data.Destroy();
					DeleteNode(playerNode);
				}
			}

			void Clear()
			{
				LinkedList<GameNetworkPlayerNode>::Clear();
			}

			LinkedListEnumerator<GameNetworkPlayerNode> GetEnumerator()
			{
				return LinkedListEnumerator<GameNetworkPlayerNode>(*this);
			}

		private:
			LinkedListNode<GameNetworkPlayerNode> * GetPlayerNode(int p_id)
			{
				LinkedListEnumerator<GameNetworkPlayerNode> playerEnumerator = GetEnumerator();
				while (playerEnumerator.MoveNext())
				{
					if (playerEnumerator.Current()->data.player->id == p_id)
						return playerEnumerator.Current();
				}

				return nullptr;
			}

			LinkedListNode<GameNetworkPlayerNode> * GetHostPlayerNode()
			{
				LinkedListEnumerator<GameNetworkPlayerNode> playerEnumerator = GetEnumerator();
				while (playerEnumerator.MoveNext())
				{
					if (playerEnumerator.Current()->data.player->host == true)
						return playerEnumerator.Current();
				}

				return nullptr;
			}
		};

		// do NOT use an int above 0xffff.
		// the two high order bytes are a confirmation id that must be sent back and channel.  any packet can get this condition
		class NetworkPacketTypes
		{
		public:
			// 0xff2's are sent by server only
			// 0xff4's are sent by client only
			// 0xff0's are either

			// sent by either
			static const int Keepalive = 0xff00;
			static const int Wakeup = 0xff01;
			static const int IAmAwake = 0xff02;
			static const int PacketConfirmation = 0xff03;
			static const int QueuePacket = 0xff04; // many packets stuffed into one
			static const int HashedPacket = 0xff05; // usually sent via UDP to detection corruption but can also be sent in TCP/UDP to prevent tampering

			// sent by server
			static const int Message = 0xff20;
			static const int Disconnect = 0xff21;
			static const int SendLoginInfo = 0xff22;
			static const int YouAreValidated = 0xff23; // (send immediately when login info is received with tcp only, and after udp login received in udp system)
			// related to players
			static const int AddPlayer = 0xff24; // (player joined)
			static const int PlayerLeft = 0xff25;
			static const int PlayerTimingOut = 0xff26;
			static const int PlayerTimedOut = 0xff27;
			static const int PlayerNoLongerTimingOut = 0xff28;
			// todo: player updates of various types (local, server, etc.)
			// udp related
			static const int SendUDPLogin = 0xff29; // (triggers client to login with udp)

			// sent by client
			static const int LoginInfo = 0xff40;
			static const int IAmDisconnecting = 0xff41;
			// udp related
			static const int UDPLogin = 0xff42;
			static const int UDPConfirmation = 0xff43; // final packet that validates UDP client on server side
		};

		// packets
		// ALL packets start with packet length (4 bytes) followed by packet type (4 bytes)
		// the rest is important data
		// hash to come later for tamper checking
		// type is separated into bytes 0 1 2 3, where 2 and 3 are the type, the top 3 bytes of byte 0 are the guaranteed channel and the bottom 5 bytes of 0 and 1 are the confirmation id.  Zero is a non-confirmation,
		//   so if that is zero, so should the channel bits.

		// ALL packets must derive from this!
		struct NetworkPacketBase
		{
			int length; // 8
			int type;
		};

		// sendlogininfo, keepalive, wakeup, iamawake, disconnecting
		struct NetworkSimplePacket : NetworkPacketBase
		{
		};

		struct NetworkPacketConfirmationPacket : NetworkPacketBase
		{
			// length 16
			int confirmationId;
			int channel;
		};

		// server messages
		struct NetworkMessagePacket : NetworkPacketBase
		{
			// length 9 + len(message)
			char message[8000]; // up to 7999 characters long
		};

		// command client to disconnect
		struct NetworkDisconnectPacket : NetworkPacketBase
		{
			// length 9 + len(reason)
			char reason[1000]; // reason for disconnect
		};

		struct NetworkYouAreValidatedPacket : NetworkPacketBase
		{
			// length 12
			int id; // assigned id
		};

		struct NetworkSendUDPLoginPacket : NetworkPacketBase
		{
			// length NetworkSendUDPLoginPacket
			int id; // assigned client id - not yet fully validated though, still need to negotiate udp

			int kernelByteQty;
			int saltBeginByteQty;
			int saltEndByteQty;
			char hashKernel[16];
			char saltBegin[16];
			char saltEnd[16];
		};

		struct NetworkUDPLoginPacket : NetworkPacketBase // sent udp
		{
			// length 12
			// todo: could use a guid.
			int id; // assigned id so that server can fully verify login
		};

		struct NetworkUDPConfirmationPacket : NetworkPacketBase // send tcp
		{
			// length 8
		};

		//struct NetworkClientJoinedPacket : NetworkPacketBase
		//{
		//	// length 13+len(name)
		//	int id; // assigned id
		//	char name[36]; // name of client
		//};

		struct NetworkLoginPacket : NetworkPacketBase
		{
			// length 96
			char userName[36]; // user's name
			char appVersionString[16]; // readable version string for comparison
			char appVersionGuid[40]; // 36 character version id, must match to allow join, plus terminator for 37
		};

		/////////////////
		// player packets
		// expected that this structure is overidden and worked with in SendAddPlayerPacket()
		struct NetworkAddPlayerPacketBase : NetworkPacketBase
		{
			// base length 80 full (implementation should include this in its length in addition to everything else in its addplayer packet)
			int id; // client/player id
			bool server;
			bool host;
			bool echo; // should information be echoed to the screen as information?
			char name[36]; // ad end so taht base length can depedn on name length (implementation should NOT do that!)
		};

		struct NetworkPlayerTimingOutPacket : NetworkPacketBase
		{
			// length 20
			int id; // client/player id
			int timeOutQty;
			int maxTimeOutQty;
		};

		struct NetworkPlayerTimedOutPacket : NetworkPacketBase
		{
			// length 12
			int id; // client/player id
		};

		struct NetworkPlayerNoLongerTimingOutPacket : NetworkPacketBase
		{
			// length 12
			int id; // client/player id
		};

		struct NetworkPlayerLeftPacket : NetworkPacketBase
		{
			// length 12
			int id; // client/player id
		};

		struct NetworkQueuePacket : NetworkPacketBase
		{
			// length 8 + bytes used
			char packets[INTERNAL_PACKET_MAX_SIZE];
		};

		struct NetworkHashedPacket : NetworkPacketBase
		{
			// length 12 + length of internal packet
			int hash;
			char hashedPacket[INTERNAL_PACKET_MAX_SIZE];
		};

		/////////////////////

		class GameNetworkPacketHelper
		{
		private:

		public:
			static String ^ CharArrayToString(char *p_source)
			{
				String^ temp = gcnew String(p_source);
				return temp;
			}

			static void CopyStringToCharArray(char *p_destination, int p_maxLength, String ^p_string)
			{
				int length = p_string->Length;
				if (length > p_maxLength - 1)
					length = p_maxLength - 1;
				for (int i = 0; i < length; i++)
				{
					p_destination[i] = (char)p_string[i];
				}
				p_destination[length] = '\0';
			}

			static void CopyStringToCharArray(wchar_t *p_destination, int p_maxLength, String ^p_string)
			{
				int length = p_string->Length;
				if (length > p_maxLength - 1)
					length = p_maxLength - 1;
				for (int i = 0; i < length; i++)
				{
					p_destination[i] = (char)p_string[i];
				}
				p_destination[length] = '\0';
			}

			// prevents reading into protected memory if a packet is corrupted or tampered
			// basically the same as strlen_s called with (p_string, p_maxLength+1), p_maxLength+1 being the 'too long' value (for a [1000] string, 1000 would be too long, 999 is ok)
			static int StringLength(char *p_string, int p_maxLength)
			{
				for (int i = 0; i < p_maxLength; i++)
					if (p_string[i] == '\0')
						return i; // less than

				if (p_string[p_maxLength] == '\0')
					return p_maxLength; // equal
				else
					return p_maxLength + 1; // string too long
			}

			static int GetPacketLength(char *p_packet)
			{
				int length = *((int *)&p_packet[0]);
				return length;
			}

			static int GetPacketType(char *p_packet)
			{
				int unmodifiedType = *((int *)&p_packet[4]);
				return unmodifiedType;
			}

			// type without any confirmation Id or channel, used to strip them off or figure out how to validate and identify message
			static int GetCleanPacketType(char *p_packet)
			{
				int cleanPacketType = (unsigned int(0xffff & GetPacketType(p_packet)));
				return cleanPacketType;
			}

			static int GetPacketConfirmationId(char *p_packet)
			{
				int unmodifiedType = *((int *)&p_packet[4]);
				int confirmationId = (unsigned int(0x1fff0000 & unmodifiedType)) >> 16;
				return confirmationId;
			}

			static int GetPacketChannel(char *p_packet)
			{
				int unmodifiedType = *((int *)&p_packet[4]);
				int channel = (unsigned int(0xe0000000 & unmodifiedType)) >> 29;
				return channel;
			}

			static bool PacketHasConfirmationId(char *p_packet)
			{
				return (GetPacketConfirmationId(p_packet) != 0);
			}

			static void SetPacketConfirmationId(char *p_packet, int p_confirmationId, int p_channel)
			{
				int cleanType = GetCleanPacketType(p_packet);
				int typeWithConfirmationId = cleanType + p_confirmationId * 65536 + p_channel * 65536 * 256 * 32;
				*((int *)&p_packet[4]) = typeWithConfirmationId;
			}

			static void SetPacketChannel(char *p_packet, int p_channel)
			{
				int cleanType = GetCleanPacketType(p_packet);
				int typeWithConfirmationId = cleanType + p_channel * 65536 * 256 * 32;
				*((int *)&p_packet[4]) = typeWithConfirmationId;
			}

			// blindly set to whatever type is with no guarantee of cleanliness.  For cleanliness, call GetPacketType first
			static void SetPacketType(char *p_packet, int p_type)
			{
				*((int *)&p_packet[4]) = p_type;
			}

			//////////

			static void PopulateKeepAlivePacket(NetworkSimplePacket &p_packet)
			{
				p_packet.length = sizeof(NetworkSimplePacket);
				p_packet.type = NetworkPacketTypes::Keepalive;
			}

			static void PopulateWakeupPacket(NetworkSimplePacket &p_packet)
			{
				p_packet.length = sizeof(NetworkSimplePacket);
				p_packet.type = NetworkPacketTypes::Wakeup;
			}

			static void PopulateIAmAwakePacket(NetworkSimplePacket &p_packet)
			{
				p_packet.length = sizeof(NetworkSimplePacket);
				p_packet.type = NetworkPacketTypes::IAmAwake;
			}

			static void PopulatePacketConfirmationPacket(NetworkPacketConfirmationPacket &p_packet, int p_confirmationId, int p_channel)
			{
				p_packet.length = sizeof(NetworkPacketConfirmationPacket);
				p_packet.type = NetworkPacketTypes::PacketConfirmation;
				p_packet.confirmationId = p_confirmationId;
				p_packet.channel = p_channel;
			}

			static void PopulateNetworkMessagePacket(NetworkMessagePacket &p_packet, String ^p_message)
			{
				p_packet.type = NetworkPacketTypes::Message;
				CopyStringToCharArray(p_packet.message, 8000, p_message);
				p_packet.length = 9 + strlen(p_packet.message);
			}

			static void PopulateSendLoginInfoPacket(NetworkSimplePacket &p_packet)
			{
				p_packet.length = sizeof(NetworkSimplePacket);
				p_packet.type = NetworkPacketTypes::SendLoginInfo;
			}

			static void PopulateDisconnectPacket(NetworkDisconnectPacket &p_packet, String ^p_reason)
			{
				p_packet.type = NetworkPacketTypes::Disconnect;
				CopyStringToCharArray(p_packet.reason, 1000, p_reason);
				p_packet.length = 9 + strlen(p_packet.reason);
			}

			static void PopulatePlayerTimingOutPacket(NetworkPlayerTimingOutPacket &p_packet, int p_id, int p_timeOutQty, int p_maxTimeOutQty)
			{
				p_packet.length = sizeof(NetworkPlayerTimingOutPacket);
				p_packet.type = NetworkPacketTypes::PlayerTimingOut;
				p_packet.id = p_id;
				p_packet.timeOutQty = p_timeOutQty;
				p_packet.maxTimeOutQty = p_maxTimeOutQty;
			}

			static void PopulatePlayerTimedOutPacket(NetworkPlayerTimedOutPacket &p_packet, int p_id)
			{
				p_packet.length = sizeof(NetworkPlayerTimedOutPacket);
				p_packet.type = NetworkPacketTypes::PlayerTimedOut;
				p_packet.id = p_id;
			}

			static void PopulatePlayerTimedOutPacket(NetworkPlayerNoLongerTimingOutPacket &p_packet, int p_id)
			{
				p_packet.length = sizeof(NetworkPlayerNoLongerTimingOutPacket);
				p_packet.type = NetworkPacketTypes::PlayerNoLongerTimingOut;
				p_packet.id = p_id;
			}

			static void PopulateYouAreValidatedPacket(NetworkYouAreValidatedPacket &p_packet, int p_id)
			{
				p_packet.length = sizeof(NetworkYouAreValidatedPacket);
				p_packet.type = NetworkPacketTypes::YouAreValidated;
				p_packet.id = p_id;
			}

			static void PopulateSendUDPLoginPacket(NetworkSendUDPLoginPacket &p_packet, int p_id, int p_kernelByteQty, int p_saltBeginByteQty, int p_saltEndByteQty, unsigned char *p_hashKernel, unsigned char *p_saltBegin, unsigned char *p_saltEnd)
			{
				p_packet.length = sizeof(NetworkSendUDPLoginPacket);
				p_packet.type = NetworkPacketTypes::SendUDPLogin;
				p_packet.id = p_id;
				p_packet.kernelByteQty = p_kernelByteQty;
				p_packet.saltBeginByteQty = p_saltBeginByteQty;
				p_packet.saltEndByteQty = p_saltEndByteQty;
				CopyMemory(p_packet.hashKernel, p_hashKernel, UDP_HASH_KERNEL_SIZE);
				CopyMemory(p_packet.saltBegin, p_saltBegin, UDP_HASH_SALT_SIZE);
				CopyMemory(p_packet.saltEnd, p_saltEnd, UDP_HASH_SALT_SIZE);
			}

			static void PopulateUDPLoginPacket(NetworkUDPLoginPacket &p_packet, int p_id)
			{
				p_packet.length = sizeof(NetworkUDPLoginPacket);
				p_packet.type = NetworkPacketTypes::UDPLogin;
				p_packet.id = p_id;
			}

			static void PopulateUDPConfirmationPacket(NetworkUDPConfirmationPacket &p_packet)
			{
				p_packet.length = sizeof(NetworkUDPConfirmationPacket);
				p_packet.type = NetworkPacketTypes::UDPConfirmation;
			}

			// it's expected for the implementation to have its own version of populating an add player packet and use that one instead inside SendAddPlayerPacket()
			static void PopulateAddPlayerPacket(NetworkAddPlayerPacketBase &p_packet, GameNetworkPlayerBase *p_player, bool p_echo)
			{
				p_packet.type = NetworkPacketTypes::AddPlayer;
				p_packet.id = p_player->id;
				p_packet.server = p_player->server;
				p_packet.host = p_player->host;
				p_packet.echo = p_echo;
				strcpy_s(p_packet.name, 36, p_player->name);
				p_packet.length = 49 + strlen(p_packet.name);
			}

			static void PopulatePlayerLeftPacket(NetworkPlayerLeftPacket &p_packet, int p_id)
			{
				p_packet.length = sizeof(NetworkPlayerLeftPacket);
				p_packet.type = NetworkPacketTypes::PlayerLeft;
				p_packet.id = p_id;
			}

			static void PopulateDisconnectingPacket(NetworkSimplePacket &p_packet)
			{
				p_packet.length = sizeof(NetworkSimplePacket);
				p_packet.type = NetworkPacketTypes::IAmDisconnecting;
			}

			static void PopulateLoginPacket(NetworkLoginPacket &p_packet, char *p_userName, char *p_appVersionString, char *p_appVersionGuid)
			{
				p_packet.length = sizeof(NetworkLoginPacket);
				p_packet.type = NetworkPacketTypes::LoginInfo;
				strcpy_s(p_packet.userName, 33, p_userName);
				strcpy_s(p_packet.appVersionString, 16, p_appVersionString);
				strcpy_s(p_packet.appVersionGuid, 37, p_appVersionGuid); // guid format (32 chars, 5 dashes)
			}

			static void PopulateHashedPacket(NetworkHashedPacket &p_packet, char *p_packetToHash, int p_hash)
			{
				p_packet.length = 12 + GameNetworkPacketHelper::GetPacketLength(p_packetToHash);
				p_packet.type = NetworkPacketTypes::HashedPacket;
				p_packet.hash = p_hash;
				CopyMemory(&p_packet.hashedPacket[0], p_packetToHash, GameNetworkPacketHelper::GetPacketLength(p_packetToHash));
			}
		};


		class GameNetworkPacketSendType
		{
		public:
			static const int Critical = 1;
			static const int Now = 2;
			static const int Send = 3; // normal
			static const int Guaranteed = 4;
			static const int None = 5;
		};

		// packet stored in a guaranteed and waiting send list
		// constant size to prevent a lot of fragmented memory from resized allocations
		class GameNetworkPacket
		{
		public:
			char packet[INCOMING_PACKET_MAX_SIZE]; // max data size 9000 - note: type includes channel and confirmation id
			int size;
			int flags;
			int sendType;

			// Guaranteed lists and delayed lists only
			int confirmationId;
			bool sent; // only needed for delayed list.  In guaranteed list, whatever node is first is assumed to have been sent, everything behind it not so
			int timeSinceSentMS; // track how long packet has been awaiting confirmation - if pass a certain amoutn of time, send again

			// Lag lists only
			// Lag packets are fed into the socket Do* methods when they are ready, which just sends them through the normal send methods, 
			//    where they then encounter bandwidth, unfinished packets, delayed packets and guaranteed packets.
			int lagToConsumeMS; // for lag list only, this will be > 0.  Does not count for the rest

			void CopyPacket(char *p_source, int p_size, int p_flags)
			{
				CopyMemory(&packet[0], p_source, p_size);
				size = p_size;
				flags = p_flags;
			}

			GameNetworkPacket()
			{
				Initialize();
			}

			void Initialize()
			{
				size = 0;
				sent = false;
				confirmationId = 0;
				sendType = GameNetworkPacketSendType::None;
				timeSinceSentMS = 0;
				lagToConsumeMS = 0;
			}
		};

		class GameNetworkPacketList : protected LinkedList<GameNetworkPacket>
		{
		private:
			int nodeCount;

		public:
			GameNetworkPacketList()
			{
				nodeCount = 0;
			}

			GameNetworkPacket * GetFirstPacket()
			{
				if (GetFirstNode() != nullptr)
					return &(GetFirstNode()->data);

				return nullptr;
			}

			void RemoveFrontPacket()
			{
				LinkedListNode<GameNetworkPacket> *frontNode = GetFirstNode();
				if (frontNode != nullptr)
				{
					DeleteNode(frontNode);
					nodeCount--;

#ifdef _DEBUG
					if (nodeCount != LinkedList<GameNetworkPacket>::Count())
						throw gcnew Exception(String::Format("Node count {0} does not match predicted node count {1}!", nodeCount, LinkedList<GameNetworkPacket>::Count()));
#endif
					if (IsEmpty() == true && nodeCount != 0)
						throw gcnew Exception(String::Format("Node count should be zero!  List is empty and still predicts {0} nodes", nodeCount));

				}
			}

			int GetNodeCount()
			{
				return nodeCount;
			}

			void Clear()
			{
				LinkedList<GameNetworkPacket>::Clear();
				nodeCount = 0;
			}

			bool IsEmpty()
			{
				return LinkedList<GameNetworkPacket>::IsEmpty();
			}

			LinkedListEnumerator<GameNetworkPacket> GetEnumerator()
			{
				return LinkedListEnumerator<GameNetworkPacket>(*this);
			}

			// lag list only
			void ConsumeLag(int p_elapsedTimeMS)
			{
				LinkedListEnumerator<GameNetworkPacket> enumerator = GetEnumerator();
				bool inserted = false;
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.lagToConsumeMS <= p_elapsedTimeMS)
						enumerator.Current()->data.lagToConsumeMS = 0;
					else
						enumerator.Current()->data.lagToConsumeMS -= p_elapsedTimeMS;
				}
			}

			// lag list only
			void AddLagPacket(char *p_packet, int p_flags, int p_sendType, int p_lagMS)
			{
				AddPacket(p_packet, p_flags, p_sendType, GameNetworkPacketSendType::None, p_lagMS);
			}

			// delayed and guaranteed lists
			void AddPacket(char *p_packet, int p_flags, int p_sendType, int p_placeInFrontOfType = GameNetworkPacketSendType::None, int p_lagMS = 0)
			{
				int length = GameNetworkPacketHelper::GetPacketLength(p_packet);
				int confirmationId = GameNetworkPacketHelper::GetPacketConfirmationId(p_packet);
				int channel = GameNetworkPacketHelper::GetPacketChannel(p_packet);

				LinkedListNode<GameNetworkPacket> *newNode = GetNewNode();
				newNode->data.Initialize();
				newNode->data.CopyPacket(p_packet, length, p_flags);
				newNode->data.size = length;
				newNode->data.sendType = p_sendType;

				// only important for guaranteed and delayed lists
				newNode->data.confirmationId = confirmationId;

				// only important for lag lists
				newNode->data.lagToConsumeMS = p_lagMS;
				if (newNode->data.lagToConsumeMS < 0)
					newNode->data.lagToConsumeMS = 0;

				if (p_placeInFrontOfType == GameNetworkPacketSendType::None)
				{
					AddNode(newNode);
				}
				else
				{
					// start at beginning
					// if current node is of a type of lower precedence, place node in front of it
					LinkedListEnumerator<GameNetworkPacket> enumerator = GetEnumerator();
					bool inserted = false;
					while (enumerator.MoveNext())
					{
						if (enumerator.Current()->data.sendType > newNode->data.sendType)
						{
							// insert in front of this node
							InsertNode(newNode, enumerator.Current()->prev); // works for first node or a mid node
							inserted = true;
							break;
						}
					}
					if (inserted == false)
					{
						// just place at end
						AddNode(newNode);
					}
				}
				nodeCount++;

#ifdef _DEBUG
				if (nodeCount != LinkedList<GameNetworkPacket>::Count())
					throw gcnew Exception(String::Format("Node count {0} does not match predicted node count {1}!", nodeCount, LinkedList<GameNetworkPacket>::Count()));
#endif
			}
		};

		// note - this socket has no awareness if it is tcp or udp, for now
		// I was concerned returning a CreateSocket() would uninstantiate the socket created and ruin it, making the call useless
		class GameNetworkSocket
		{
		public:
			SOCKET sk;

			GameNetworkSocket()
			{
				sk = INVALID_SOCKET;
			}

			bool IsOpen()
			{
				return (sk != INVALID_SOCKET);
			}

			void Close()
			{
				if (IsOpen() == true)
				{
					// shutdown - flush send data only, forcing written data to go under linger
					// For some reason, if shut down both (2), this doesn't work as intended to let the data out under linger, so only shut down send (1)
					// thanks to 
					// https://blog.netherlabs.nl/articles/2009/01/18/the-ultimate-so_linger-page-or-why-is-my-tcp-not-reliable
					// bug: still doesn't allow a receiver receiving lots of data to send a message, but does allow a sender sending lots of data to get a final message out
					//  (that is, generally, the server can successfully tell the clients it closed, but clients can't always tell the server - this is testing on localhost)
					// bug: this works on localhost - NOT over a LAN, and I imagine also over the internet
					int error = shutdown(sk, 1);

					error = closesocket(sk);
					sk = INVALID_SOCKET;
				}
			}

			// not used for listening socket, but used for communication sockets, including the temp one in ListenForConnections
			bool ReadyForWriting(int p_timeOutMS = 0)
			{
				fd_set fd;
				FD_ZERO(&fd); // clear socket set
				FD_SET(sk, &fd); // check only this socket

				struct timeval timeout;
				timeout.tv_sec = p_timeOutMS / 1000; // seconds
				timeout.tv_usec = p_timeOutMS % 1000; // ms

				// Make sure the socket is ready to be written to...
				// returns when ready, or after timeout expires
				// check 1 socket, return number of sockets ready for writing
				long retcode = select(1, NULL, &fd, NULL, &timeout);

				if (retcode == 1)
				{
					return true;
				}
				else
					return false;
			}

			bool ReadyForReading(int p_timeOutMS = 0)
			{
				fd_set fd;
				FD_ZERO(&fd); // clear socket set
				FD_SET(sk, &fd); // check only this socket

				struct timeval timeout;
				timeout.tv_sec = p_timeOutMS / 1000; // seconds
				timeout.tv_usec = p_timeOutMS % 1000; // ms

				// Make sure the socket is ready to be written to...
				// returns when ready, or after timeout expires
				// check 1 socket, return number of sockets ready for reading
				long retcode = select(1, &fd, NULL, NULL, &timeout);

				if (retcode == 1)
				{
					return true;
				}
				else
					return false;
			}

			void MakeBlocking(bool p_blocking)
			{
				unsigned long cmd = 1;

				if (p_blocking == false)
				{
					cmd = 1;
				}
				else
				{
					cmd = 0;
				}

				int error = ioctlsocket(sk, FIONBIO, &cmd);
			}

			void SetLinger(int p_seconds)
			{
				struct linger st_linger = { 1, 4 };	// on, 4 seconds
				st_linger.l_linger = p_seconds;

				int error = setsockopt(sk, SOL_SOCKET, SO_LINGER, (char *)&st_linger, sizeof(st_linger));
			}

			~GameNetworkSocket()
			{
				Close();
			}
		};

		public class GameNetworkBandwidthTracking
		{
		public:
			int accumulatedTimeMS; // counts up to 1 second
			int accumulatedDataBytes; // data send in that time

			GameNetworkBandwidthTracking()
			{
				Initialize();
			}

			void Initialize()
			{
				accumulatedTimeMS = 0;
				accumulatedDataBytes = 0;
			}

			float GetDataRate()
			{
				if (accumulatedTimeMS == 0)
					return 0.0f;
				else
					return float(accumulatedDataBytes) / (float(accumulatedTimeMS) / 1000.0f);
			}
		};

		public class GameNetworkBandwidthTrackingList : protected LinkedList<GameNetworkBandwidthTracking>
		{
		private:
			int nodeCount;
			int totalDataBytes;
			int totalTimeMS; // keep whole number since we dont' sue slow motion on these lists
			int maxListTimeMS;
			float peakDataRate;

		public:
			GameNetworkBandwidthTrackingList()
			{
				Initialize();

				maxListTimeMS = 30000; // 30 seconds (don't make this < maxNodeTime! We need a second node, always)
			}

		private:
			void Initialize()
			{
				nodeCount = 0;
				totalDataBytes = 0;
				totalTimeMS = 0;
				peakDataRate = 0;

				Clear();

				// put up one node with no time or databyte count so that bandwidth can be tracked without exception in the event that sockets are used to send data before Process() is called
				LinkedListNode<GameNetworkBandwidthTracking> *newNode = GetNewNode();
				newNode->data.Initialize();
				InsertNode(newNode);
			}

		public:
			virtual ~GameNetworkBandwidthTrackingList()
			{

			}

			void ApplyTimeElapsed(int p_elapsedTimeMS)
			{
				int maxNodeTimeMS = 1000;

				// each node builds up to maxNodeTimeMS
				// This application preps nodes to receive bandwidth data, closing off nodes when they reach 1 second, and removing nodes that 30 seconds old
				LinkedListNode<GameNetworkBandwidthTracking> *firstNode = GetFirstNode();
				if (firstNode == nullptr)
				{
					LinkedListNode<GameNetworkBandwidthTracking> *newNode = GetNewNode();
					newNode->data.Initialize();
					AddNode(newNode);
				}
				firstNode = GetFirstNode();
				firstNode->data.accumulatedTimeMS += p_elapsedTimeMS;
				totalTimeMS += p_elapsedTimeMS;

				// finish off nodes as their time fills up and create new ones
				while (firstNode->data.accumulatedTimeMS > maxNodeTimeMS)
				{
					int remainingTimeMS = firstNode->data.accumulatedTimeMS - maxNodeTimeMS;
					firstNode->data.accumulatedTimeMS = maxNodeTimeMS;

					LinkedListNode<GameNetworkBandwidthTracking> *newNode = GetNewNode();
					newNode->data.Initialize();
					newNode->data.accumulatedTimeMS = remainingTimeMS;
					InsertNode(newNode);
					firstNode = GetFirstNode();

					// now that second node is full, see if it reached peak data rate
					if (firstNode->next != &footer)
					{
						float dataRate = firstNode->next->data.GetDataRate();
						if (dataRate > peakDataRate)
							peakDataRate = dataRate;
					}
				}

				// clean off old nodes
				while (totalTimeMS > maxListTimeMS)
				{
					LinkedListNode<GameNetworkBandwidthTracking> *lastNode = GetLastNode();
					if (lastNode == nullptr)
						throw gcnew Exception("Trying to delete last node but list is empty!");
					totalTimeMS -= lastNode->data.accumulatedTimeMS;
					totalDataBytes -= lastNode->data.accumulatedDataBytes;

					LinkedList<GameNetworkBandwidthTracking>::DeleteNode(lastNode);
				}
			}

		private:
			void InsertNode(LinkedListNode<GameNetworkBandwidthTracking> *newNode)
			{
				nodeCount++;

				// totalTime was added above
				totalDataBytes += newNode->data.accumulatedDataBytes;

				LinkedList<GameNetworkBandwidthTracking>::InsertNode(newNode); // shove at front
			}

			void DeleteNode(LinkedListNode<GameNetworkBandwidthTracking> *newNode)
			{
				LinkedList<GameNetworkBandwidthTracking>::DeleteNode(newNode);
				nodeCount--;

				if (nodeCount < 0)
					throw gcnew Exception("Node count < 0!");
				if (IsEmpty() == true && nodeCount != 0)
					throw gcnew Exception(String::Format("Empty but Node count = {0}", nodeCount));
			}

		public:
			float GetSustainedDataRate()
			{
				if (totalTimeMS == 0)
					return 0.0f;
				else
					return float(totalDataBytes) / (float(totalTimeMS) / 1000.0f);
			}

			float GetImmediateDataRate()
			{
				if (GetFirstNode() == nullptr) // shouldn't happen
					return 0.0f;
				if (GetFirstNode()->next == &footer) // happens when socket has been open < 1 second
					return 0.0f;
				return (GetFirstNode()->next->data.GetDataRate()); // second packet has most recent 1 second slice of upload sampling
			}

			float GetPeakDataRate()
			{
				return peakDataRate;
			}

			void ResetPeakDataRate()
			{
				peakDataRate = 0.0f;
			}

			void ApplyDataBytes(int p_dataBytes)
			{
				if (GetFirstNode() == nullptr)
					throw gcnew Exception("Trying to add bytes but list is empty!");

				GetFirstNode()->data.accumulatedDataBytes += p_dataBytes;
				totalDataBytes += p_dataBytes;
			}

			void Reset()
			{
				Initialize();
			}
		};

		// socket used to send and receive data
		class GameNetworkCommunicationSocket : public GameNetworkSocket
		{
		public:
			// Rules for packet lists:
			// Only SendNow and Send packets are placed in the delayed packet list. SendNow packets are always placed in front of Send packets in the order in which each are submitted
			// Guaranteed packets and Send packets are placed in the guaranteed packet list, in the order in which they are submitted.  New guaranteed packets are placed behind existing Send packets if they exist.
			// Packets from the Guaranteed packet list are ONLY sent if the delayed packet list is empty.
			// The delayed packet list is only populated when the socket is not ready for writing or bandwidth for that iteration is tagged consumed
			// SendCritical packets are sent in front of everything without storage.  If the packet isn't ready within the timeMS provided, the packet is discarded and not sent (usually reserved for disconnect commands)
			// SendNow packets are sent ahead of the guaranteed packet list and NEVER stored there.  If the socket can't be written to (not ready or bandwidth consumed), it is placed in the delayed list after the last SendNow packet encountered
			// Send packets are placed behind the Guaranteed packets if any exist in the guaranteed list[0].  If that list is empty, but the delayed packet list is populated, it is place at the end of that list
			// When processing:
			// 1. Update all guaranteed sent packets at front of guaranteed list timeSinceSentMS += elapsedTime
			// 2. Delayed list processing: if bandwidth is not consumed and the socket can be written to, packets are sent from the delayed list and removed from it at the front
			// 3. Guaranteed list processing: on each front packet check, if bandwidth is consumed or packet is not ready, stop.  Otherwise, if the first node is not sent, send it now - if it is a Send packet, remove it, otherwise it's a guaranteed packet and should now be tagged sent.  
			//    If it is already sent, it should be a guaranteed packet.  If no confirmation response for the packet has arrived after being sent for a given period of time, send the packet again.
			//    Send() packets should never have a sent boolean of true - they should be sent and removed immediately.
			// note: when a confirmation packet is received, whatever packets that can be sent from the guaranteed list should do so unless there are packets waiting in the delayed list, in which case just
			//    remove the front sent guaranteed packet.  If the confirmation received doesn't match the front packet, just discard it without an error (was likely a resend for a resent guaranteed packet)
			// It is possible for the front packet in the guaranteed list to be a Send() packet - it hasn't been sent because bandwidth is consumed, the packet wasn't ready, or there are packets waiting in the delayed packet list

			// packets waiting because of socket not ready for writing (SendNow packets in front, Send packets behind)
			GameNetworkPacketList delayedPackets; // only used by host to manage packets going to clients.  clients use their localUser.waitingPackets
			// packets waiting because a confirmation is waiting on the last packet sent (front one is waiting to get cleared out) (Send packets can exist in the front here)
			// channels 0-7 - use 0 for most common important packets that dictate game operation, use 1-7 dispersed to distribute data downloads
			GameNetworkPacketList guaranteedPackets[8]; // only used by host to manage packets going to clients.  clients use their localUser.waitingPackets.  Index is channel[0-7]
			int nextConfirmationId[8]; // next confirmation Id to send
			int lastReceivedConfirmationId[8]; // last confirmation Id received to prevent re-processing of packets

			// for simulated lag testing
			GameNetworkPacketList incomingLagPackets; // packets wait here then are fed into the Do* methods
			GameNetworkPacketList outgoingLagPackets; // packets wait here after being pulled off a socket before being sent to Validate and ProcessPacket routines

			char incomingPacket[INCOMING_PACKET_STORAGE_SIZE];
			unsigned int bytesReceived;

			int bandwidthBytesAllowed; // bytes allowed, if packet sent would use this up by more than half the packet, divert it to a waiting list, allow it to go negative
			bool ignoreBandwidth;
			bool notReady; // set to false at beginning of Process().  If a socket ever becomes notReady, this is set to true and all sending on that socket is halted for the remainder of that
						   // Process iteration and any other sends except for Criticals until Process() is called again

			// when a send() fails to send off all the bytes, the packet is saved here.  Only one packet can be saved here, and is given absolute priority over any other sends until complete
			char unfinishedSendPacket[INCOMING_PACKET_STORAGE_SIZE];
			int unfinishedSendPacketBytesToSend;
			int unfinishedSendPacketStartIndex;
			int unfinishedSendPacketFlags;

			int nextGuaranteedPacketList; // distribute attempts to send guaranteed lists across the lists

			int maxWaitingPacketsQty; // wavers with packet activity, used to determine finish percentage

			GameNetworkBandwidthTrackingList bandwidthTrackingSent;
			GameNetworkBandwidthTrackingList bandwidthTrackingReceived;

			GameTimer *networkTimerRef; // reference to main network timer

			bool checkConnectionStatus;  // only true when used for connecting, and set to false when result is obtained (and OnConnectFailure() or OnConnectSuccess() is called)

		private:
			int simulatedLagMS; // amount of lag to simulate (affects both uplods and downloads)

		public:

			GameNetworkCommunicationSocket()
			{
				ResetSocketVariables();
				ignoreBandwidth = false; // default
				networkTimerRef = nullptr;
				simulatedLagMS = 0;
			}

			void ResetSocketVariables()
			{
				bytesReceived = 0;
				for (int i = 0; i < 8; i++)
				{
					lastReceivedConfirmationId[i] = 0;
					nextConfirmationId[i] = 0;
				}
				bandwidthBytesAllowed = 0;
				notReady = false;
				unfinishedSendPacketBytesToSend = 0;
				nextGuaranteedPacketList = 0;
				maxWaitingPacketsQty = 0;

				bandwidthTrackingSent.Reset();
				bandwidthTrackingReceived.Reset();

				checkConnectionStatus = false;
			}

			void SetSimulatedLag(int p_lagMS)
			{
				if (p_lagMS < 0)
					throw gcnew Exception("Negative lag not allowed!");
				if (p_lagMS > 2000)
					throw gcnew Exception("Lag greater than 2000ms not allowed!");

				simulatedLagMS = p_lagMS;
			}

			int GetSimulatedLag()
			{
				return simulatedLagMS;
			}

			void ConsumeLag(int p_elapsedTimeMS)
			{
				incomingLagPackets.ConsumeLag(p_elapsedTimeMS);
				outgoingLagPackets.ConsumeLag(p_elapsedTimeMS);
			}

			void Close()
			{
				incomingLagPackets.Clear();
				outgoingLagPackets.Clear();
				delayedPackets.Clear();
				for (int i = 0; i < 8; i++)
				{
					guaranteedPackets[i].Clear();
				}

				ResetSocketVariables();

				GameNetworkSocket::Close();
			}

			int GetNextConfirmationId(int p_channel)
			{
				nextConfirmationId[p_channel]++;
				// clamp it
				nextConfirmationId[p_channel] = nextConfirmationId[p_channel] & 0x1fff;
				// skip zero, since zero means there isn't a confirmation id
				if (nextConfirmationId[p_channel] == 0)
					nextConfirmationId[p_channel]++;
				return nextConfirmationId[p_channel];
			}

			void AddBandwidth(int p_bandwidthBytes)
			{
				bandwidthBytesAllowed += p_bandwidthBytes;

				// don't allow more than bandwidth added
				if (bandwidthBytesAllowed > p_bandwidthBytes)
					bandwidthBytesAllowed = p_bandwidthBytes;
			}

			void AddElapsedTime(int p_elapsedTimeMS)
			{
				bandwidthTrackingSent.ApplyTimeElapsed(p_elapsedTimeMS);
				bandwidthTrackingReceived.ApplyTimeElapsed(p_elapsedTimeMS);
			}

			int GetTotalWaitingPackets()
			{
				int count = 0;
				if (unfinishedSendPacketBytesToSend > 0)
					count++;
				count += delayedPackets.GetNodeCount();
				for (int i = 0; i < 8; i++)
					count += guaranteedPackets[i].GetNodeCount();

				return count;
			}

			void ProcessWaitingPackets()
			{
				int total = GetTotalWaitingPackets();
				if (total == 0)
					maxWaitingPacketsQty = 0;
				else if (total > maxWaitingPacketsQty)
					maxWaitingPacketsQty = total;
			}

			float GetPacketsProgess(bool &p_socketNotReady)
			{
				p_socketNotReady = false;

				if (maxWaitingPacketsQty == 0)
					return 0.0;
				else
				{
					if (delayedPackets.GetNodeCount() > 0 || unfinishedSendPacketBytesToSend > 0)
						p_socketNotReady = true;
					return (float(GetTotalWaitingPackets()) / float(maxWaitingPacketsQty));
				}
			}

			void AddTimeElapsedToGuaranteedSentPackets(int p_elapsedTimeMS)
			{
				for (int i = 0; i < 8; i++)
				{
					if (guaranteedPackets[i].IsEmpty() == false)
					{
						GameNetworkPacket *packet = guaranteedPackets[i].GetFirstPacket();
						if (packet->confirmationId != 0 && packet->sent == true) // realistically, sent would only be true if it is a guaranteed packet, otherwise it would have been removed after being sent as a normal Send
							packet->timeSinceSentMS += p_elapsedTimeMS;
					}
				}
			}

			void ReceiveConfirmationId(int p_confirmationId, int p_channel)
			{
				// compare to first node in guaranteed packets of [p_channel], and if matches, remove that packet and send all in rest of list
				// until sent the first guaranteed packet encountered, or it's empty, or bandwidth is consumed or socket isn't ready (returned sent byte count 0)
				GameNetworkPacket *firstPacket = guaranteedPackets[p_channel].GetFirstPacket();
				if (firstPacket != nullptr)
				{
					if (firstPacket->confirmationId == p_confirmationId)
					{
						guaranteedPackets[p_channel].RemoveFrontPacket();

						// if packet isn't ready, don't bother trying to send
						if (notReady == true)
							return;

						// don't do anything at all after this - let ProcessWaitingPackets handle it (speed isn't impacted much and distribution of bandwidth across channels is even)
						return;

						// code below is not executed unless return; is removed.  It works and data rate is nearly unchanged.

						// Don't send anything if delayed packets have contents
						// todo: also if partial send packet needs to be completed
						if (delayedPackets.GetNodeCount() == 0)
						{
							// Start sending (Send and Guaranteed packets as they occur from the front)!  If packet not ready then halt.  If consume bandwidth then halt.
							while (guaranteedPackets[p_channel].GetNodeCount() > 0)
							{
								// if socket isn't ready, leave packet it in this list - don't move it to the delayed list
								if (notReady == false && ReadyForWriting(0) == false)
								{
									notReady = true;
									break;
								}

								GameNetworkPacket *packet = guaranteedPackets[p_channel].GetFirstPacket();
								if ((bandwidthBytesAllowed >= packet->size / 2) || ignoreBandwidth == true)
								{
									// todo: for safety, if sent = 0, store packet in an incomplete send and obligate those bytes to be what is sent next, even before Criticals
									int totalSent = 0;
									while (totalSent < packet->size)
									{
										int sent = send(sk, &(packet->packet[totalSent]), packet->size, packet->flags);
										if (sent < 0)
										{
											SavePartiallySentPacket(&(packet->packet[totalSent]), packet->size - totalSent, packet->flags);
											notReady = true;
											break;
										}
										totalSent += sent;
										bandwidthTrackingSent.ApplyDataBytes(sent);
									}

									if (ignoreBandwidth == false)
										bandwidthBytesAllowed -= packet->size;

									// check packet type sent
									if (packet->confirmationId == 0)
										// sent a non-guaranteed packet (Send only for this list) - keep going!
										guaranteedPackets[p_channel].RemoveFrontPacket();
									else
									{
										// sent a guaranteeed packet - stop!  leave packet there and wait for confirmation from receiver.
										packet->sent = true;
										packet->timeSinceSentMS = 0;
										break;
									}
								}
								else
									break;
							}
						} // no delayed packets
					} // first packet has matching confirmationId

					// else ignore.  chances are this is a resend of a prior confirmation packet that we already handled that was re-sent back because of a guaranteed packet re-send
				}

				// no error, packet was removed because of a prior receipt of confirmation, see above for how this happens
			}

			// send whatever packets for simualted lag testing are ready to be sent
			void SendLagPackets()
			{
				GameNetworkPacket *packet = outgoingLagPackets.GetFirstPacket();
				while (packet != nullptr)
				{
					if (packet->lagToConsumeMS <= 0)
					{
						int length = GameNetworkPacketHelper::GetPacketLength(&(packet->packet[0]));

						switch (packet->sendType)
						{
						case GameNetworkPacketSendType::Now:
							DoSendNow(&(packet->packet[0]), length, packet->flags);
							break;
						case GameNetworkPacketSendType::Send:
							DoSend(&(packet->packet[0]), length, packet->flags);
							break;
						case GameNetworkPacketSendType::Guaranteed:
							DoSendGuaranteed(&(packet->packet[0]), length, packet->flags);
							break;
						default:
							throw gcnew Exception("Unsupported send type for Lag packet list!");
							break;
						}

						outgoingLagPackets.RemoveFrontPacket();
						packet = outgoingLagPackets.GetFirstPacket();
					}
					else
						break; // stop, we're done
				}
			}

			bool SendUnfinishedPacket(int p_waitMS = 0)
			{
				// ignore bandwidth for this packet - it's already been registered
				if (unfinishedSendPacketBytesToSend == 0)
					return true; // nothing to send
				if (notReady == true)
					return false; // can't send it

				while (unfinishedSendPacketStartIndex < unfinishedSendPacketBytesToSend)
				{
					if (ReadyForWriting(p_waitMS) == false)
					{
						notReady = true;
						break;
					}
					int sent = send(sk, &unfinishedSendPacket[unfinishedSendPacketStartIndex], unfinishedSendPacketBytesToSend, unfinishedSendPacketFlags);
					if (sent < 0)
					{
						// might have lost connection - don't throw exception here
						notReady = true;
						break;
					}
					unfinishedSendPacketStartIndex += sent;
					unfinishedSendPacketBytesToSend -= sent;
					bandwidthTrackingSent.ApplyDataBytes(sent);
				}
				if (notReady == false)
				{
					if (unfinishedSendPacketBytesToSend != 0)
						throw gcnew Exception("Done sending unfinished packet, but bytes to send are not zero!");
					return true;
				}
				else
					return false; // didn't send it all
			}

		private:
			void SavePartiallySentPacket(char *p_packet, int p_numberOfBytes, int p_flags)
			{
				// note: p_packet points to the bytes the send stopped on

				if (unfinishedSendPacketBytesToSend != 0)
					throw gcnew Exception("Trying to save unfinished packet, but there is already an unfinished packet saved!");

				CopyMemory(&unfinishedSendPacket[0], &p_packet[0], p_numberOfBytes);
				unfinishedSendPacketBytesToSend = p_numberOfBytes;
				unfinishedSendPacketStartIndex = 0;
				unfinishedSendPacketFlags = p_flags;
			}

		public:
			bool SendWaitingPacket(char *p_packet, int p_length, int p_flags, bool &p_sent)
			{
				// send packet without any concern for whether or not bandwidth is consumed, or submitting to a waiting list or altering type (but save unfinished packet)
				// called only by SendwaitingPackets()
				// if (return bytes sent < packet size, consider socket not ready now, but if any bytes sent, packet can be treated as sent)
				// reduce bandwidth if not ignored

				if (ReadyForWriting() == true && SendUnfinishedPacket() == true)
				{
					p_sent = true;

					int totalSent = 0;
					while (totalSent < p_length)
					{
						int sent = send(sk, &p_packet[totalSent], p_length - totalSent, p_flags);
						if (sent < 0)
						{
							SavePartiallySentPacket(&p_packet[totalSent], p_length - totalSent, p_flags);
							notReady = true;
							break;
						}
						totalSent += sent;
						bandwidthTrackingSent.ApplyDataBytes(sent);
					}

					if (ignoreBandwidth == false)
						bandwidthBytesAllowed -= p_length;

					if (totalSent < p_length)
						return false; // didn't send all bytes, assume socket not ready
					else
						return true; // sent it all
				}
				else
				{
					p_sent = false;
					return false; // no bytes sent
				}
			}

			int SendCritical(char *p_packet, int p_length, int p_flags, int p_waitMS)
			{
				// IGNORE SIMULATED LAG - this routine is for sending disconnect messages because client is leaving - no point in delaying it

				// completely ignore waiting list and just try to send it - if that fails, just don't bother
				// ignore bandwidth consumption too - this routine is reserved for rare deeply critical messages (usually a disconn before closing the socket)

				// SendCritical packets never get a confirmation, clean it off if any
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));

				// todo: try to obligate sending the final packet, THEN wait to send the critical packet?  Note that any time this routine waits halts the current thread, so it can halt the app
				//   or halt all network communication for that time.
				// check for socket ready after a period of time
				if (ReadyForWriting(p_waitMS) == true && SendUnfinishedPacket(p_waitMS) == true)
				{
					int totalSent = 0;
					while (totalSent < p_length)
					{
						int sent = send(sk, &p_packet[totalSent], p_length - totalSent, p_flags);
						if (sent < 0)
						{
							notReady = true;
							break; // no error, just drop out, we don't have time to send the rest
						}
						totalSent += sent;
						bandwidthTrackingSent.ApplyDataBytes(sent);
					}

					return p_length;
				}
				else
					return 0; // not sent
			}

			int SendNow(char *p_packet, int p_length, int p_flags)
			{
				// SendNow packets never get a confirmation, clean it off if any
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));

				if (simulatedLagMS > 0 || outgoingLagPackets.IsEmpty() == false)
				{
					outgoingLagPackets.AddLagPacket(p_packet, p_flags, GameNetworkPacketSendType::Now, simulatedLagMS);
					return 0;
				}
				else
					return DoSendNow(p_packet, p_length, p_flags);
			}

		private:
			int DoSendNow(char *p_packet, int p_length, int p_flags)
			{
				// todo: also check for bandwidth consumed
				if (notReady == false && ReadyForWriting(0) == false)
					notReady = true;
				if (notReady == false && ((bandwidthBytesAllowed >= p_length / 2) || ignoreBandwidth == true) && SendUnfinishedPacket() == true && delayedPackets.IsEmpty() == true)
				{
					int totalSent = 0;
					while (totalSent < p_length)
					{
						int sent = send(sk, &(p_packet[totalSent]), p_length - totalSent, p_flags);
						if (sent < 0)
						{
							SavePartiallySentPacket(&p_packet[totalSent], p_length - totalSent, p_flags);
							notReady = true;
							break;
						}
						totalSent += sent;
						bandwidthTrackingSent.ApplyDataBytes(sent);
					}

					if (ignoreBandwidth == false)
						bandwidthBytesAllowed -= p_length;
					return p_length;
				}
				else
				{
					// place in delayed packet list behind all other SendNow packets (delayed list only has Now and Send packets - place in front of Send packets)
					delayedPackets.AddPacket(p_packet, p_flags, GameNetworkPacketSendType::Now, GameNetworkPacketSendType::Send);
				}

				return 0;
			}

		public:
			int Send(char *p_packet, int p_length, int p_flags, int p_channel = 0)
			{
				// clean off confirmation id, apply channel
				GameNetworkPacketHelper::SetPacketChannel(p_packet, p_channel);

				if (simulatedLagMS > 0 || outgoingLagPackets.IsEmpty() == false)
				{
					outgoingLagPackets.AddLagPacket(p_packet, p_flags, GameNetworkPacketSendType::Send, simulatedLagMS);
					return 0;
				}
				else
					return DoSend(p_packet, p_length, p_flags);
			}

			int SendUDP(char *p_packet, int p_length, int p_flags, sockaddr *p_sockaddr)
			{
				// clean off confirmation id and channel
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));

				int sent = sendto(sk, p_packet, p_length, p_flags, p_sockaddr, sizeof(sockaddr_in));

				// todo: register bandwidth uploaded
				// todo: use simualted lag
				// todo: consume bandwidth, populate waiting packets

				// if error, packet didn't go out.
				if (sent < 0)
					sent = 0;

				return sent;
			}

		private:
			int DoSend(char *p_packet, int p_length, int p_flags)
			{
				int channel = GameNetworkPacketHelper::GetPacketChannel(p_packet);

				// see if confirmation packets for channel 0 have nodes (or any delayed), and if so, place packet there to wait
				if (guaranteedPackets[channel].IsEmpty() == false || delayedPackets.IsEmpty() == false || unfinishedSendPacketBytesToSend > 0)
				{
					guaranteedPackets[channel].AddPacket(p_packet, p_flags, GameNetworkPacketSendType::Send);
				}
				else
				{
					if (notReady == false && ReadyForWriting(0) == false)
						notReady = true;
					if (notReady == false && ((bandwidthBytesAllowed >= p_length / 2) || ignoreBandwidth == true) && SendUnfinishedPacket() == true)
					{
						int totalSent = 0;
						while (totalSent < p_length)
						{
							int sent = send(sk, &(p_packet[totalSent]), p_length - totalSent, p_flags);
							if (sent < 0)
							{
								SavePartiallySentPacket(&p_packet[totalSent], p_length - totalSent, p_flags);
								notReady = true;
								break;
							}
							totalSent += sent;
							bandwidthTrackingSent.ApplyDataBytes(sent);
						}

						if (ignoreBandwidth == false)
							bandwidthBytesAllowed -= p_length;
						return p_length;
					}
					else
					{
						// place in delayed packet list behind all packets - delayed list only has Now and Send packets
						delayedPackets.AddPacket(p_packet, p_flags, GameNetworkPacketSendType::Send);
					}
				}

				return 0;
			}

		public:
			int SendGuaranteed(char *p_packet, int p_length, int p_flags, int p_channel)
			{
				// guaranteed packets never end up in the delayed packet list.  They always remain in the guaranteed packet list, and when sent, remain as the first node in the guaranteed
				// list until they are confirmed received by the receiver - then the packet is remove and what is behind it is sent unless there are delayed packets, or until the packet 
				// isn't ready or a new guaranteed packet is encountered

				// prep packet for confirmation
				// clean what's there
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet)); // no need to clean really since SetPacketConfirmation will replace it anyway
				// and set
				int confirmationId = GetNextConfirmationId(p_channel);
				GameNetworkPacketHelper::SetPacketConfirmationId(p_packet, confirmationId, p_channel);

				if (simulatedLagMS > 0 || outgoingLagPackets.IsEmpty() == false)
				{
					outgoingLagPackets.AddLagPacket(p_packet, p_flags, GameNetworkPacketSendType::Guaranteed, simulatedLagMS);
					return 0;
				}
				else
					return DoSendGuaranteed(p_packet, p_length, p_flags);
			}

		private:
			int DoSendGuaranteed(char *p_packet, int p_length, int p_flags)
			{
				int channel = GameNetworkPacketHelper::GetPacketChannel(p_packet);

				// see if confirmation packets for channel 0 have nodes, and if so, place packet there to wait
				if (guaranteedPackets[channel].IsEmpty() == false || delayedPackets.IsEmpty() == false || unfinishedSendPacketBytesToSend > 0)
				{
					guaranteedPackets[channel].AddPacket(p_packet, p_flags, GameNetworkPacketSendType::Guaranteed);
				}
				else
				{
					// place in guaranteed packet list and see if socket is ready for send or bandwidth isn't taken up.  If can't, just leave there
					guaranteedPackets[channel].AddPacket(p_packet, p_flags, GameNetworkPacketSendType::Guaranteed);
					if (delayedPackets.IsEmpty() == true)
					{
						if (notReady == false && ReadyForWriting() == false)
							notReady = true;

						if (notReady == false && ((bandwidthBytesAllowed >= p_length / 2) || ignoreBandwidth == true) && SendUnfinishedPacket() == true)
						{
							int totalSent = 0;
							while (totalSent < p_length)
							{
								int sent = send(sk, &(p_packet[totalSent]), p_length - totalSent, p_flags);
								if (sent < 0)
								{
									SavePartiallySentPacket(&p_packet[totalSent], p_length - totalSent, p_flags);
									notReady = true;
									break;
								}
								totalSent += sent;
								bandwidthTrackingSent.ApplyDataBytes(sent);
							}

							if (ignoreBandwidth == false)
								bandwidthBytesAllowed -= p_length;
							// mark sent even though it may only be partially sent so far
							guaranteedPackets[channel].GetFirstPacket()->sent = true;
							guaranteedPackets[channel].GetFirstPacket()->timeSinceSentMS = 0;
							return p_length;
						}
					}
				}

				return 0;
			}

		};
		
		enum class NetworkClientStatus
		{
			NotConnected, // not being used
			Pending, // connected, awaiting login information
			Validated // login info received, guid validated, ready to participate
		};

		// base network client data
		class GameNetworkClient
		{
		private:
			char name[33]; // login name
			bool host; // is this player the 'host' with special permissions?  (not to be confused with the server, but most of the time the server is the host)
			int id; // network id for player (each new connection increments this).  When this is set, player is validated (= player id for now to keep them related)
			bool validated; // used only by client to determine if login has been accepted and is ready to participate in all packets
			bool doneProcessing; // flag for Process() to skip over this client because socket can't be written to, or for any other reason
			NetworkClientStatus status; // only server uses this - mode for this client (not connected, pending, validated).  If != NotConnected, socket.sk should be set, and if Validate, id should != -1 and name set

			// when did this machine last send a keepalive?
			unsigned int timeSinceLastKeepaliveSentMS;
			// data about machine at other end of socket (for client's localUser, this is information about the server)
			unsigned int timeSinceLastPacketReceivedMS;
			unsigned int timeOutQty;
			GameNetworkCommunicationSocket socket; // connection to client for host in player data array, or localUser's connection to server - server does not use this element in localUser

			friend class GameNetworkBase;

			// for UDP usage
			bool waitingForUDPLogin; // if true, port is ignorable
			char ipAddress[256]; // address of TCP and UDP connection (set when TCP connection occurs), used to verify udp login source from client
			int udpPort; // port that user logged in from on UDP channel
			// simple structure to quickly use for communicating back to client, where ipAddress and udpPort came from
			sockaddr_in udpAddress;
			bool udpConfirmed; // two-way communicated established - good for normal operation now (after this is true, player can be treated as having joined, and can receive players, gamestate, etc.)
			int timeSinceUDPValidationSentMS; // if UDPConfirmationRequired() = true, send YouAreValidated every 500ms

		public:
			GameNetworkClient()
			{
				Reset();
			}

		private:
			void Reset()
			{
				strcpy_s(name, 33, "");
				host = false;
				id = -1; // < 0 is invalid for a client id
				timeSinceLastPacketReceivedMS = 0;
				timeOutQty = 0;
				status = NetworkClientStatus::NotConnected;
				doneProcessing = false;
				validated = false;

				// clear udp variables
				waitingForUDPLogin = true;
				udpConfirmed = false;
				strcpy_s(ipAddress, 256, "");
				udpPort = -1;
				memset(&udpAddress, 0, sizeof(sockaddr_in));
				timeSinceUDPValidationSentMS = 0;
			}

			bool UDPLoginFromClientRequired()
			{
				return (id != -1 && waitingForUDPLogin == true);
			}

			bool UDPLoginToServerRequired()
			{
				return (id != -1 && validated == false);
			}

			bool UDPConfirmationRequired()
			{
				return (id != -1 && waitingForUDPLogin == false && udpConfirmed == false);
			}

		public:
			bool IsConnected()
			{
				return (status != NetworkClientStatus::NotConnected);
			}

			bool IsValidated()
			{
				return (status == NetworkClientStatus::Validated);
			}

			int GetId()
			{
				return id;
			}

			String ^ GetName()
			{
				return gcnew String(name);
			}

			// probably shouldn't have this, just keeping things simple for now, preventing a lot of conversion
			char * GetCharName()
			{
				return name;
			}

			NetworkClientStatus GetStatus()
			{
				return status;
			}

			float GetSustainedUploadDataRate()
			{
				return socket.bandwidthTrackingSent.GetSustainedDataRate();
			}

			float GetSustainedDownloadDataRate()
			{
				return socket.bandwidthTrackingReceived.GetSustainedDataRate();
			}

			// called after getclientfromid using client id from UDP login packet
			bool UDPLoginIsValid(char *p_incomingIpAddress)
			{
				if (strcmp(ipAddress, p_incomingIpAddress) == 0 && waitingForUDPLogin == true)
					return true;
				else
					return false;
			}

			bool UDPAddressPortMatches(char *p_incomingIpAddress, int p_incomingPort)
			{
				if (id != -1 && waitingForUDPLogin == false && strcmp(ipAddress, p_incomingIpAddress) == 0 && udpPort == p_incomingPort)
					return true;
			}
		};

		enum class GameNetworkMessageType
		{
			Info,
			Error,
			Disconnect
		};

		public class GameNetworkPacketQueue
		{
			NetworkQueuePacket queuePacket;
			bool started;
			int sendType;
			int flags;
			int channel;
			int onlyClientId;
			int excludedClientId;

		public:
			GameNetworkPacketQueue()
			{
				started = false;
			}
			
			void Start(int p_sendType, int p_flags, int p_channel = 0, int p_onlyClientId = -1, int p_excludedClientId = -1)
			{
				if (p_sendType != GameNetworkPacketSendType::Now && p_sendType != GameNetworkPacketSendType::Send && p_sendType != GameNetworkPacketSendType::Guaranteed)
					throw gcnew Exception("Only send types of Now, Send and Guaranteed are supported");
				if (channel != 0 && p_sendType == GameNetworkPacketSendType::Now)
					throw gcnew Exception("Channels are not supported for Now packets");

				if (started == false)
				{
					sendType = p_sendType;
					flags = p_flags;
					channel = p_channel;
					onlyClientId = p_onlyClientId;
					excludedClientId = p_excludedClientId;

					queuePacket.type = NetworkPacketTypes::QueuePacket;
					queuePacket.length = 8;

					started = true;
				}
				else
					throw gcnew Exception("Stop Queue first before starting again");
			}

			void SubmitPacket(char *p_packet, int p_length)
			{
				if (started == false)
					throw gcnew Exception("Queue not started");

				if ((queuePacket.length + p_length) > sizeof(NetworkQueuePacket))
					SendPacket();

				CopyPacket(p_packet, p_length);
			}

			void Finish()
			{
				if (started == true)
				{
					SendPacket();
					started = false;
				}
			}
		private:
			void Clear()
			{
				queuePacket.length = 8;
			}

			bool IsEmpty()
			{
				return (queuePacket.length == 8);
			}

			void SendPacket(); // in .cpp

			void CopyPacket(char *p_packet, int p_length)
			{
				if (queuePacket.length + p_length > sizeof(NetworkQueuePacket))
					throw gcnew Exception(String::Format("Packet being copied into queue is too large ({0} bytes, max {1})", p_length, int(INTERNAL_PACKET_MAX_SIZE - 8)));

				CopyMemory(&queuePacket.packets[queuePacket.length - 8], p_packet, p_length);
				queuePacket.length += p_length;
			}
		};

		// set by GameContext::SetNetwork(gameNetwork), where gameNetwork is the game implementation of GameNetworkBase
		// destroy at GameBase level along with all other game objects
		// override to provide processing for incoming implementation packets and responses to network events
		// implementation Network should have access to game implementation class so taht packets can direct events and data on game elements
		// game implementation classes can in turn access base network to send data via GameContext::GetNetwork()

		// Primary todos:
		// (done) Get unblocking connection working:
		// - set socket to non-blocking before calling connect
		// - set boolan on socket saying that waitingforconfirmedConnection = true
		// - in Process(), check boolean and if it is true, see if socket is ready for writing (or use getsockopt() because checking for ready for writing might be too optimistic), 
		//     and if it is, set boolean to false and call OnConnectSuccess()
		// - if at ANY time bytes are received on the socket and this boolean is true, set it to false and call OnConnectSuccess() - the reason we check here is because
		//     ReadyforWriting() might not have had a chance to be true because the server might have sent a message back and immediately closed the connection.  Safe coding.
		// - in implementations, UI message box showing conenction should not be cancellable by keyboard input
		// - it is possible we never get bytes or a readyforwriting on the socket.  In that event (wait for a period of time), we need to be ready to fire an OnConnectFailure() and close the socket.
		// - getsockopt(fd, SOL_SOCKET, SO_ERROR) might be the better way to determine that a socket successfully connected, or just call connect() again on it (don't, see below) and get a
		//      WASEINPROGRESS, WSALREADY or WSAEINVAL, or WASEISCONN for is already connected.  
		//      Eventually if not successful the error on getsockopt() will show with WSATIMEDOUT, WSAENETUNREACH, or WSAEHOSTUNREACH or other.  This seems to be the better option so that
		//      connect() doesn't try to connect again in the event of a realized failure that opens the socket to attempt again.
		//      In any event, after a set period of time (max 30 seconds since a bad IP takes around 20 seconds to return?), if we get neither result, we should close the socket and call OnConnectFailure() with a "Undetermined error" message
		// - test with successful connection, IP address reachable but no one hosting, host address reachable but no one hosting, IP address unreachable, host address unreachable, machine network error,
		//      where possible
		// - The methodology used in CheckForConnectionStatus() works for Windows TCP - unknown how it would work on Linux or BSD sockets.
		// (done) Provide a way for the connection process to be interrupted - allow the user to break out of the connection if desired so that they don't have to wait to attempt another connection quickly,
		//      for convenience
		// (done) There is no timing out of the server tracked on the client, since it is assumed the server will instruct the client to send login info or reject the connection.  but if this never happens,
		//      the client should be able to detect that the server is not responding and close itself after 3 timeouts.
		// accept() has the ability to provide the IP address and port of a connecting socket.  Might want to register this in the clients, for options of banning by IP address, although banning
		//      an address is useless if the person's IP address floats, but having the information is useful.  Is it possible for someone to change their IP address after they join but
		//      stay connected to fool the information collection?
		// Disconnect() linger/block/send still does not guarantee delivery before the socket closes.  Not sure what's wrong there.  Must guarantee from the server side and client side on ALL sends
		//      of the critical Disconnect message.  Debug testing: verbose output from client confirming that disconnect message was sent or not, and linger, block, shuitdown and close did not return an error.
		//      Watch for message differences when server doesn't notice a client left.  Pausing the host doesn't cause the disconnecting client to linger on the socket at all.  Maybe the socket process
		//      still runs even when the program is paused?
		// Expects IPv4 addresses, but it might be possible to receive IPv6 addresses, might error out when try to collect IPv4 address(haven't tested).  
		//      This would be true on inet_ntoa() calls, trying to match up address or address/port for udp and sending packets out through udp.
		// Finishing up UDP:
		// - support Simulate Lag (need to store send address for outgoing lag, client for incoming lag, and recognize that a client might have disconnected in that time)
		// - keepalives along udp path to keep connection alive and monitored - udp packets can drop so the system shouldn't complain too much, but if the pathway is now blocked,
		//     that is a critical situation - so somehow if NO packets are recieved over an extended period, there should be a warning even though udp packets drop naturally.  At some
		//     poor performance threshold, including total loss of pathway, the client should be disconnected.
		// - consume outgoing bandwidth for a socket, store waiting packets and send them out in cooperation with waiting tcp packets.
		// - (done) record outgoing bandwidth and incoming bandwidth in server and client data so that UDP traffic can be tracked.  (possibly, track it separately, with routines that can combine
		//     the results of each - didn't do this yet)
		// How relevant would it be to send a different hash table to every client?  This would prevent a hacker from trying to log on just to get the hash table then start messing with packets
		//     for every possible client.  Wouldn't be hard to do.  It doesn't stop a hacker from listening in on a client's login to get that client's hash table and messing with packets for that
		//     specific client, but it can help deter.  Also, loop through multiply, add and subtract - that is, add that aspect to each part of the kernel.
		//     Of course none of this would stop a hacker hacking his own application to win by altering his gamestate and letting that send data to the host - the host would need to verify any 
		//     data sent and make sure it isn't giving any player an advantage.
		// Possible problem with Nagle algorithm: https://en.wikipedia.org/wiki/Nagle%27s_algorithm
		//     The article says write-write-read is a killer.  Is this why TTop sees Palmer disconnecting a lot?  Host is trying to send out packets and failing to receive any from him?
		//     The article just says this causes a constant delay of 500ms.  So that might not be the problem.
		//     According to the article, the Nagle algorithm ONLY affects TCP, not UDP.
		// It is possible to implement a reliable UDP by checking packet corruption, re-sending packets for which no confirmation was received, preventing processing on a packet that has already arrived,
		//    and since we don't send the next packet until the current one gets a confirmation, order is guaranteed (unless we keep a buffer of say 5 packets that we send and don't proceed until
		//    the earliest one gets a confirmation, and the 5 can be altered to provide more throughput).  Discussions suggest TCP hogs the connection and induces packet loss for UDP.  So that's
		//    something to consider.  It's still possible to send a guaranteed-less UDP packet for speed and mix it with packets that require a confirmation.  Just be aware of the 1420 byte size packet
		//    being the max of what can be sent without forcing the data to arrive in segmnets that need to be reassembled.  Asteroids probably works fine because only a small percentage of the full bandwidth
		//    is even being used.  Combining reliable UDP packets with normal UDP should be handled the same as mixing TCP and UDP for simplicity.  Send reliable ordered packets for critical information and
		//    don't let the unreliability of normal UDP destroy that in that least or make the reliable packets dependent upon them in the least.  If reliable UDP is going to have delayed lists, etc. then
		//    clients need the delayed lists instead of the socket, because there is only ever one UDP socket in a system on each end no matter how many clients there are.  Just be VERY aware that the one main
		//    thing reliable UDP CANNOT do is detect that a client's download bacndwidth has been consumed.  It only knows if the local machine's uplaod bandwidth has been consumed.  So
		//    if a client is strapped for bandwidth, packets may get sent out with a LOT of drops.  A good question here: Can a TCP socket with NO data EVER sent through it be used to determine if a
		//    remote client's download bandwidth is taken up? (bear in mind usually the upload bandwidth of a host is generally less than the download bandwidth of clients, although there are some with
		//    both 100Mb up and 100Mb down, and that 100Mb up beats my download.).  Note that UDP will need SendReliable, Send (goes in line behind reliable), SendNow, SendNowReliable (like chat messages)
		//    and SendCritical for disconnecting (at least this would circumvent the need for linger).  Keepalives would still be necessary but if UDP loss is rampant, they wouldn't be received,
		//    and if keepalives aren't received, how hard should the line be pounded with them?  So there needs to be some variance about how a reliable packet is delivered, and the kind of action
		//    if there is no response.
		//    - So big questions:
		//		o How soon should the system re-send a packet it hasn't received a confirmation for, and how many bytes of data shoudl be sent in bulk for the other side to reassamble in the proper order
		//         to increase throughput?
		//      o Need to design packet precedence system so that at several levels, packets can be delievered with a certian amount of precedence, preserving ordering or not, reliable (confirmation)
		//         or not.  Will a channel system work, with Now and Critical packets just sent in front without caring if they arrive?  Critical will need to arrive because it's disconnent.
		//         Normal packets should be sent behind reliable ones to prevent bad updates, assuming that's how implementation plans to use them.  If a normal packet doesnt' have to go in behind
		//         reliable ones, sue a different channel.  Simple.
		//      o On the subject of disconnect, host would need to wait for a sertian amount of time for clients to confirm they got the packet before disconnecting, but not so long that the
		//         server is locked from closing.  Say, 4 seconds for up to 16 clients, 10 seconds for up to 100?
		//      o Naturally this design will require a delayed packet list and channel guaranteed packet lists for a representation of what needs to go out the socket first.  No need for a partial
		//         packet to send because that doesn't happen with UDP.
		// Question to answer:
		// - in a high bitrate environment, why does sending small packets take so much longer than sending large packets?  Is there a bug with how packets are being sent into the
		//     socket or read from them?  Seems to take longer on a slow bitrate system, too, which doesn't make sense unles the client is taking longer to pull off the bytes,
		//     but recv() just tries to fill up the available buffer space - it doesn't pull bytes based on packetsize.  So is there a problem with send()?  Unknown right now.
		//     Note that if the Nagle algorithm is involved, small ping packets are sent and come back within 16ms on a local network, so there is not a significant delay in sending a 16-20 byte packet.
		//     Need to more solidly confirm that smaller packets are indeed slower in an internet environment.

		// UDP preparation
		// The primary connection, verification and gamestate communciation can happen via TCP for stability
		// However, pings and minor but necessary object updates benefit from UDP for having a faster arrival time for a more playable gamestate on all machines.
		// So, a second port can be made available for connection via UDP, and the host can provide this information to the client so that the UDP connection can also be established.
		//    But since both ports will be part of the constructor, the client already knows this information anyway.
		// The host will have to receive ALL UDP packets from clients through the same socket (unelss you want to open up a port for each client to communicate to) and determine which client
		//    an incoming packet is coming from by comparing the sending address and port to the stored data on each client when it originally registered through the UDP socket.  Packets addressed
		//    to a client MUST use the identical address and port the packet was received from so that the firewall at the destination allows the packet through.  Keepalives should be sent occasionally
		//    to keep the firewall's attention.
		// Be aware that UDP packets can arrive out of order, not at all, twice, or corrupted (16-bit checksum, so in a way 1 in 65536 chance - I have seen this - so make sure data that can arrive via UDP is sanitary, 
		//    including a bad packet length at the beginning NOT disconnecting the client unless the ACTUAL packet size, not the indicated packet size, ends up being larger than the allowed max size).  
		//    So UDP packets might need an incrementing ID so that the receiving systems can identify duplicates or packets received out of order, or just design the system so that 
		//    receiving packets out of order, in duplicate, corrupted, or not at all is not harmful despite the detriment.
		// Presumably, UDP packets CANNOT be sent only partially since that would split up the packet.  They also arrive fully, all or none (a partial read off the socket loses the rest).  
		//    But keep the size 1492 or smaller to prevent complicated reassembly in the network.
		// Note that UDP packets can't be larger than 64k (65535 bytes), but one CAN arrive that is that large, so have a buffer ready to hold that much to prevent memory overwrite, or only
		//    only read as much as the lergest packet your app expects and the rest will get dumped out (watch out for non-terminated strings that you check the length of).
		//    In fact, it might be wise to replace any string length validation with a more custom method that simply looks for the string terminator up to a give byte length,
		//    and if that fails, so does the validation.  This would prevent string read protected memory errors, a risk even for TCP packets.
		// Also verify that the UDP packet is arriving from an expected source (a client we have instructed to register int he UDP socket).  If it isn't, throw up a warning and discard the packet.
		//    This is also true for a valid registering packet from a client we haven't registered from TCP yet.  Never assume a good packet is coming from a reliable source.
		// UDP packets are fine for quick important updates, but to help maintain a solid game state, TCP packet updates should be sent every now and then for gamestate stability.  This can be
		//    a challenge for servers trying to detect cheating, though.  Hackers can sent volatile data in either packet type that makes the gamestate erratic for other players.  Servers should
		//    be able to determine if a particular move allows a player to move too fast, fire too often, etc. compared to their last best state.
		// Examples of corrupted UDP packets:
		// - ping results in smaller travel time, flagging system to re-estimate game time, but game time is corrupted and is way off - discard if gametime adjsutment would be far too much.
		// Combatting corrupted UDP packets (or rather, detecting that they are corrupted)
		// - hash element that is rechecked on receipt - if it fails to match, the packet got corrupted (the 16-bit checksum wasn't good enough to catch it).  This also helps prevent packet tampering.
		//     the server can send salt for each end along with a kernel for the hash (TCP of course) that the client then uses for all of its sends and verifies all received UDP packets.  All
		//     UDP packets should be wrapped in that larger packet (length, type, hash, packet length?, packet data), the HMAC can just be a simple addition of all bytes in the packet, multiplied
		//     by the kernel as it advances for a final total, including the salt at the beginning and end. Be aware this increases the size of a simple ping packet or a small gamestate
		//     update.  This hash can work for both TCP and UDP packets - there is no distinction.  The hash should be sent with the SendUDPLoginUDP packet, a new type, with hash info - either
		//     validates the client.  The server chould generate new hash kernels and salts every time it hosts, with varying length on the salts and the kernel despite the data sent down, jsut
		//     to make things a little harder.  SO - salt, both ends, hash kernel, send full data chunk with all bytes meaningfully populated, but data that says how many of each to use (and that
		//     data can be very coded to reassemble, 4 bits each grabbed from specific locations, and maybe even that is a pattern that is sent.)
		// Any possibility of multi-addressing UDP packets to reduce overhead of sending it to multiple receivers?
		// Any need to watch for a socket not ready to be written to?  Need another set of delayed packets for it?  (UDP should only support normal sends, frankly, until the need of quickly sending well 
		//    organized data is necessary.  But supporting delayed packets are fine although waiting too long completely defeats the purpose of UDP.)
		// Work the bandwidth calculation into the UDP communication - TCP and UDP have to share it.
		// Problem with UDP - it has NO way of knowing if the receiver's download bitrate is used up, so the upload bitrate on the sender is all that will cause the socket to not be ready for writing.
		//    If a packet is then sent, I iamgine it will not arrive very often.  Usually it is the uploader's bitrate that is maxed out, however, so this usualyl shouldn't be a problem
		// Another potential issue - important TCP updates will be needed to help keep gamestates in sync, but a quick small UDP update sent out after a TCP update might arrive before the TCP update.
		//    Might want to design the system to hold on to the UDP update for a small period of time so it can be re-applied after the TCP update arrives (both should have a gametime on them)

		// Documentation:
		// - Packets can be sent Now (would only be placed behind Now packets that are waiting because of a clogged socket), Normally (placed behind waiting and packets awaiting confirmation), and
		//     Guaranteed (channel selected (0-7), confirmation id will be assigned, receiver must send back a confirmation packet so that sender can send the next packet).  Channel 0 is for usual
		//     game packets. 1-7 is for ancillary data, like graphics or other data not critical for operation but good for the receiver.  Split ancillary guaranteed packets among channels 1-7 so that
		//     streams of graphics or data do not have to wait in line for each other, and use channel 0 for more critical game data that dictates correct operation.  Critical packets utterly ignore
		//     any waiting list and are usually reserved for such things as a disconnect message from the client or disconnect command from the server.
		// - If a socket is not ready for writing, that means upload bandwidth on the local machine is used up or the receiver's download bandwidth is used up.  Packets that can't be written will be
		//     placed in a waiting queue in front of the confirmation queue.  Packet order of precedence is described in the prior note.
		// - When a client connects, the server will tell the client to send login info, for which the client provides its version string guid that the server matches up to its own.  If the guid matches,
		//     the client is validated and its information provided to all the other clients.
		// - If a client must be disconnected immediately, if the client must be notified, then a disconnect command shoudl be sent with linger, then the socket closed, and all waiting packets should 
		//     be cleared and the socket closed without harm.
		// - During process, a number of bytes should be provided as the maximum to send in total per process, the maximum to send per client on an iteration (repeatable, and clients with larger sends pay for it
		//     in the loop), and the maximum bytes to receive total, and the maximum bytes to receive for a client on an iteration (again, larger data clients pay for it in the loop)
		// - Packets waiting because of a clogged socket must tag the kind of operation (now, normal, guaranteed) so that other packets trying ot be sent during a clogged packet can decide where they need
		//     to be placed in the list (now packets are sent immediately if waiting list is empty, or in front of the first encountered normal or guaranteed packet)
		// - Connecting is a multi stage process.  Client first connects to the server socket.  The Server either immediately rejects the connection due to no free slots or tells the client to send login 
		//     info and keeps the client in a pending state.  If no login info is received over a period of time, the connection is rejected and freed up.  When the login info
		//     is received, the server validates it and rejects the client or tells the client he is validated and provides the client's information to everyone else.  Then the implementation can provide all the game data
		//     to the client, maintaining its own temporary states on the clients.
		// - Optimally, on the server, the occurrence of waiting packets should affect how the network allocates bandwidth for sending to specific clients if only those clients are noticed to be slow.  
		//     Appropriate diagnostic messages should reflect this.  Receiving does not need a similar
		//     bottleneck since the client's connection is slow anyway and won't take away from anyone else's bandwidth unfairly.  Clients don't need such throttling since all of their communication
		//     is through one socket.
		// - Later: Support UDP in parallel with TCP.

		// Connection steps:
		// Check if possible with IsOkToConnect()
		// Call Connect()
		// if a blocking connect, will have a result when Connect() returns (should display something inside OnConnectingPreProcess() with a game->BlockRender() call so that user sees something,
		//    then when OnConnectingPostProcess() is called, remove it if relevant).  App will freeze until winsock connect() returns, which usually takes longest when connecting to an IP that doesn't exist.
		//    Connect() will return true if successful, false if it was not.  OnConnectSuccess() and OnConnectFailed() will also be called relevantly, so success can be determined by either method.
		// if a non-blocking connect, make sure network->Process() is repeatedly called until a connect result is obtained.  (OnConnectingPreProcess() and OnConnectingPostProcess() are just as
		//    relevant here, except that game->BlockRender() is not necessary to display what OnConnectingPreProcess() created.)
		//    Connect() will return true as long as a serious error was not encountered before the connect() call.  Successful connection will be determined only by a call to OnConnectSuccess() or OnConnectFailed(),
		//    same as with a blocking connect.
		// if during the connecting process, OnConnectingContinue returns false, the connection is cancelled and OnConnectingCanceled is called (OnConnectingPostProcess, OnConnectionSuccess and OnConnectionFailure are NOT called)
		// If UDP is involved, when send login info, server will provide hash kernel for UDP packets and instruct client to send a UDP Login repeatedly to the UDP hosting port to open a channel through the client's firewall.
		//    When that login packet is received, the server will send a test UDP packet repeatedly back to the client through the UDP channel.  When that succeeds, the client considers itself validated and will send a UDP confirmation back to the
		//    server through the TCP connection (only one send needed), at which point the server will consider the client validated, inform the other players, and should send or prep for sending the gamestate down to the client (OnPlayerJoined()).

		// Test:
		// Host - should succeed.  If try to host again, should complain network already active.  If another process tries to host, should complain that port is occupied
		// Connect - should fail with no server response if server not hosting.  Otherwise should succeed unless no slots available, in which case client should be notified.  If try to connect again,
		//    should complain that network is already active.
		// If client connection succeeds, client should recieve request for login info from server, and client should provide it for validation.  If server fails to send login request, client should
		//    complain about host timing out and give up.  If login request is received and reply sent back to host by validation fails because of a suspect packet or bad version, 
		//    client should be forcibly disconnected with a proper notification
		// If login succeeds, server should show a message showing client successfully logged in, display an incrementing ID that doesn't repeat (unless a reconnect is detected - this is implementation specific)
		//    and notify the other clients
		// If server disconnects, clients should be notified that session was closed and disconnect with a proper message
		// If server app stops, clients should be notified that session was closed and disconnect with a proper message
		// If client disconnects, server should receive a normal client left session message and notify the other clients
		// If server pauses, clients should complain about server timing out and eventually give up
		// If a client pauses, server should complain about client timing out and send notifications to clients, including notifying them if host gives up on client and disconnects them
		// If a client pauses, server should complain about client timing out and send notifications to clients, including notifying them if host gives up on client and disconnects them
		// If a receiver is temporarilty paused and continues, even after wakeups are sent, all packets shoudl arrive properly and the process should continue as normal
		// If suspect packet is received by server or client, self-forced disconnect should occur with a notification to sender (client to server and server to client)
		// If bad packet is received by server or client, packet should be skipped and a notification shown, with notification to sender
		// -
		// Guaranteed packets:
		// Multichannel guaranteed packets should be received in parallel, but in each channel, received in order
		// If a receiving source is paused, sender should repeatedly try to send the guaranteed packet every second, just in case
		// If a guaranteed packet is received more than once, receiver should only accept the first one and skip the rest without notification
		// Packet ordering (critical, now, normal, guaranteed when there are packets of any combination in the delayed and guaranteed packet lists?)
		// Bandwidth should be consumed per client as usual until all packets are sent or socket is no longer ready, and guaranteed lists should pick up on the next one when the client is processed again
		// When a series of complex guaranteed sends are occuring with many more waiting, clients should be able to gracefullt disconnect or close the app and have the server receive a disconnect message
		// When a series of complex guaranteed sends are occuring with many more waiting, if host closes or disconnects, clients shoudl receive a graceful disconnect message
		// -
		// Send a large stream of normal packets to test transfer bandwidth speed.  Try many tiny packets vs. many very large packets.  Determine optimal packet size.  Possibly per connection's bandwidth.
		// Send a stream of normal send packets, then send one send packet.  That final packet should arrive after all of the rest.
		// Sends sent on a channel should arrive on that channel
		// -
		// Implementation tests:
		// When login is successful, server should send a notification to the game host machine that a login occurred.  Game host should send any additional information and maintain its own
		//    states on players for who can participate at a given level.  Players should maintain their own states and special information as well.
		// Todo: When client ID is assigned, should it allow a reconnect?  If Game Host is assigning client ID/name/etc. to game data and can use it to detect a reconnect, Game Host should be able
		//    to make a decision about which ID to assign or reserve that ID in case a client reconnects
		// -
		// Timeouts:
		// When a timeout occurs from a client, server should notify clients and send a wakeup for the timing out client to respond to.  After max timeouts, client is disconnected and clients are notified
		// When a timeout occurs from the server, client send a wakeup for the timing out server to respond to.  After max timeouts, client disconnects and gives up on session
		// -
		// All stability testing should be done on these environments: localhost, LAN network, internet broadband, internet slow connection
		//
		// Current tests indicate approximate a 4 Mb transfer speed.  Distributed channel guaranteed packets ultimately travel faster than a large stream of straight sends of 8k sized packets.
		// Each socket seems to be able to handle a 800k-1M bytes/sec, meaning n clients can potentially result in the server sending n times that amount, limited by the upload bandwidth allowed
		//    by the connection (localhost allows the most, local LAN allow a lot, wifi less (but still allows a lot of bandwidth per socket regardless of 1-8 clients, although fewer clients allow more, 
		//    more significantly in scaling than local LAN),  and the internet is limited by the upload speed of the connection (the internet part and scalability effect across 1-8 clients has not been tested).
		// A stream of Send or SendNow packets naturally is sent the fastest, since guaranteed packets must wait for a confirmation before proceeding.  Still need to test how fast small Normal and
		//    Now packets are sent compared to large ones over the internet, but it's a fair conclusion that guaranteed data transferred is fastest when the packets are large (around 8k bytes) 
		//
		// Times in seconds with 4 MB of normal packet data transferred (8k packets, unless noted), TCP only:
		//                               1 client   8 clients          small packet effect          notes
		// localhost                       4.4        6.5 (40 Mb/sec)  slower in window (7.3 sec)   1 client faster because of a bug fix not emptying the receive buffer, 8 clients now slower with the same fix (some finish VERY fast though)?  CPU heavy?
		// local LAN wired                 5.3        5.7              almost double (10 sec)       similar to localhost, interesting speedup since it's through the wire to another machine instead of within the same machine with 9 processes running (100Mb network, hits around 45Mb/sec, around 50%)
		// local LAN wifi                  4.7        9                +5.5 sec                     unknown why the 1 client test is faster than wired.  9-10 is expected for 8 clients though, since travel time is supposed to have a further latency.  Also, 500 byte packets take 13 seconds with 8 clients.
		// internet, 6Mb/sec upload (8k)   25         45                                            25 seconds for 1 client, 26 for 4.  Still evidence of single socket maxing out on bandwidth (160K/sec) - for 8, each socket 87KB/sec
		// internet, 6Mb/sec upload (500)
		// internet, slowish client (8k)   24														with 2 clients on the same box (3Mb/sec download), still got ~27 seconds.  1 client received 150k/sec, 2 clients received 300k/sec.  My upload speed is 750k/sec.  Client download speed is 375k/sec
		// internet, slowish client (500)  38                          smaller packets still take longer - must be the local overhead of loading them into the socket?  Since it's always delivered as a stream, wouldn't be slower on client end.
		// On a local 100 Mb network, around 12 clients can accept full data speed with 8k packets and use the max bandwidth allowed on the network (around 87 Mbps - 
		//    I presume the rest of the bandwidth is used for TCP guaranteed delivery - so expect about 13% of the total allowed bandwidth to be used up by TCP to deliver the packet)
		// On the same network, wifi reaches around 42Mbps and uses an additional 10% for TCP overhead. (this is on battery, haven't tried on power, doesn't really matter much)
		// I really wonder how much faster UDP would be, ignoring packet loss.
		// internet upload tops aout at 5.6Mb/sec when sending to a 100Mb/sec download client, 90% of the bandwith available. (Broadband test recorded 5.8Mb/sec)
		// important note: I fixed a bug that was causing the receive buffers to only be checked once on an iteration.  Now they empty as much as they can.  As a result, most times are actually a little slower.  I don't know why.
		// These behaviors - that is, noticing that transfer speeds seem to love overlapping TCP streams to make use of all the bandwidth and discourage and practically punish single socket use - 
		//     seems to be a natural aspect of TCP, which is why there is so much talk about parallel TCP, which is using multiple TCP sockets to send data to a receiver.  
		//     This would present the challenge of receiving unguided packets out of order as with UDP since there is no guarantee
		//     when a packet arrives, but without the packet loss of UDP.  However, if the application using this code can achieve max upload bandwidth with only a few clients, then there is little reason for
		//     using a parallel TCP strategy, since once those few clients connect, all benefits of the parallel TCP are lost - that is, unless the app design only calls for occasional bulk uploads to specific clients
		//     at a time, in which case those clients can enjoy the benefits.  An application that has steady uploading that cannot achieve max bandwidth even with max clietns would benefit will from parallel TCP.
		// It is currently unknown if multiple TCP sockets would still help with bulk upload of small packets, as numbers above suggest they are significantly slower to send - even though once
		//     on the wire there is no reason for speed difference when they arrive at the receiver, since TCP is a stream protocol that simply sends bytes, not packets.
		// These times change in fullscreen, regardless of vsync - small packet sends are faster but consume more framerate with the effort needed to shove so many more into one socket (might be worth collecting
		//     them into a single large packet for upload, but this would break the rule of distributing available bandwidth across the multiple lists).
		class GameNetworkBase
		{
		private:
			bool valid;  // valid if WSAStartup was successful, network is usable, may host or connect
			bool active; // network is active and is either hosting or connected (although being connected does NOT mean logged in and validated)
			bool server; // is this application instance serving as the server in a server-client architecture?  (a client can be the 'host', that is, the one with special permissions, but
						 // that is entirely game implementation specific
						 // if this is true, clientValidated is meaningless and should remain false

			unsigned int maxTimeOutQty;
			unsigned int timeOutDelayMS; // how long until a socket times out once?
			unsigned int sendKeepalivePacketDelayMS; // when to send keepalives
			int resendGuaranteedPacketDelayMS; // time to resend packet needing confirmation (should be unsigned int but I don't care, warns on comparison since p_elapsedTimeMS is int)

			// could be gcroot(String^), but whatever
			// as a rule of thumb, whenever there is an app change, both of these should change (version string should increment meaningfully, and guide should be something it never was before)
			// since users will be downloading the app to use and there is no guarantee which user in the group has which version, it's best if everyone just has the same one, since bugs fixes
			//    might have only fixed clients or the server and might not even need a new network contract, but everyone should have the latest fixes so that the intended experience is stable.
			char versionString[16]; // readable version string for the app
			char versionGuid[37]; // version Guid

			GameNetworkClient *clients;
			int clientQty; // number of clients in array (max slots available for clients)

			int currentClientId; // incremented as clients are validated, skipped past -1, host is usually 0

			GameNetworkSocket serverListeningSocket;
			char sessionPassword[33];
			int nextClientId; // for assigning id's to connecting clients

			int nextClientToProcess; // which client should have waiting packets sent next? (distributes bandwdith across multiple sockets for single uplaod connection)

			bool verboseEventReporting; // should all events that occur be reported?

			float peakUploadDataRate; // fastest upload speed
			float peakDownloadDataRate; // fastest download speed

			GameTimer networkTimer; // timer safe from slowmotion modifiers and pausing, unlike the one in the main game loop

			// udp communication
			// this is a secondary socket that is only used when hosting with an additional udpPort.
			GameNetworkCommunicationSocket udpSocket;
			sockaddr_in serverUDPAddress;
			int timeSinceUDPLoginSentMS; // Process() repeatedly sends udp login packet every 500ms once id != -1
			// Hash data
			unsigned char hashKernel[UDP_HASH_KERNEL_SIZE]; // kernel to cycle through while hashing
			unsigned char hashSaltBegin[UDP_HASH_SALT_SIZE]; // bytes to hash at beginning
			unsigned char hashSaltEnd[UDP_HASH_SALT_SIZE]; // bytes to has at end
			// bytes to use for random variance
			int kernelByteQty; // 12-16
			int saltBeginBytes; // 12-16
			int saltEndBytes; // 12-16
			// uses main timeout counter variables for clients that aren't validated, depending on status (waiting for tcp login, udp login, udp confirmation)
			int udpTimeoutMS; // 4000ms

		protected:
			GameNetworkClient localUser; // this app's username and data

			// players (including host)
			GameNetworkPlayerList players;

		public:
			GameNetworkBase(int p_clientQty, String ^p_versionString, String ^p_versionGuid)
			{
				Initialize(p_clientQty, p_versionString, p_versionGuid);
			}

		private:
			void Initialize(int p_clientQty, String ^p_versionString, String ^p_versionGuid)
			{
				valid = false;
				active = false;
				server = false;

				clients = new GameNetworkClient[p_clientQty];
				clientQty = p_clientQty;

				// references to network timer
				localUser.socket.networkTimerRef = &networkTimer;
				for (int i = 0; i < clientQty; i++)
					clients[i].socket.networkTimerRef = &networkTimer;

				GameNetworkPacketHelper::CopyStringToCharArray(versionString, 16, p_versionString);
				GameNetworkPacketHelper::CopyStringToCharArray(versionGuid, 33, p_versionGuid);

				maxTimeOutQty = 3;
				timeOutDelayMS = 10 * 1000;
				sendKeepalivePacketDelayMS = 7 * 1000;
				resendGuaranteedPacketDelayMS = 1 * 1000;
				udpTimeoutMS = 4 * 1000;

				strcpy_s(sessionPassword, 33, "");
				localUser.socket.ignoreBandwidth = true; // no need for localUser socket to be concerned about bandwidth consumption - when it is used, this machine is a client with only one socket,
				//  so no need to be concerned about distributing bandwidth among multiple sockets

				ResetSessionVariables();

				verboseEventReporting = false;
			}

			void ResetSessionVariables()
			{
				nextClientId = 0;
				nextClientToProcess = 0;

				peakUploadDataRate = 0;
				peakDownloadDataRate = 0;

				timeSinceUDPLoginSentMS = 0;
			}

		public:
			virtual ~GameNetworkBase() // make sure to call this in GameNetwork implementation destructor
			{
				Destroy();

				Trace::WriteLine("Destroying GameNetworkBase...");
			}

			// properties
			bool IsValid()
			{
				return (valid == true);
			}

			bool IsActive()
			{
				return (active == true);
			}

			bool IsServer()
			{
				return (IsActive() == true && server == true);
			}

			bool IsClient()
			{
				return (IsActive() == true && server == false);
			}

			bool UsesUDP()
			{
				return (udpSocket.IsOpen());
			}

			// allowed to participate in game
			bool IsValidatedClient()
			{
				return (IsActive() == true && server == false && localUser.validated == true);
			}

			void SetVerboseReporting(bool p_report)
			{
				verboseEventReporting = p_report;
				if (p_report == true)
					NetworkMessage(GameNetworkMessageType::Info, "Verbose reporting on");
				else
					NetworkMessage(GameNetworkMessageType::Info, "Verbose reporting off");
			}

			bool GetVerboseReporting()
			{
				return verboseEventReporting;
			}

			// commands
			void Startup(String ^p_frameworkVersionCheck)
			{
				if (p_frameworkVersionCheck != GAMENETWORK_FRAMEWORK_VERSION)
					throw gcnew Exception("GameNetwork guid has changed.  Change your implementation network guid and replace the version check in Startup()!");

				// wsastartup, check to make sure it was successful, if it wasn't show a message and leave valid = false, block any attempts to host or connect

				WSADATA wsaData;
				WORD wVersionRequested;
				int err;

				wVersionRequested = MAKEWORD(2, 2);
				err = WSAStartup(wVersionRequested, &wsaData);

				if (err != 0)
				{
					OnInitializationFailed(2, 2);
					WSACleanup();
				}
				else
					valid = true;
			}

			void SimulateLag(int p_oneWayTravelTimeMS = 0)
			{
				// The lag is half a round trip, so it will double the ping value

				if (p_oneWayTravelTimeMS < 0)
					throw gcnew Exception("Negative travel time not allowed!");
				if (p_oneWayTravelTimeMS > 2000)
					throw gcnew Exception("Travel time greater than 2000ms not allowed!");

				localUser.socket.SetSimulatedLag(p_oneWayTravelTimeMS);
				for (int i = 0; i < clientQty; i++)
					clients[i].socket.SetSimulatedLag(p_oneWayTravelTimeMS);
			}

			// implementation can call this to determine if hosting can be attempted
			bool IsOkToHost(String^ %p_error)
			{
				// p_error will be populated with error string

				if (active == true)
				{
					if (server == true)
						p_error = String::Format("Already hosting - disconnect first before trying to host");
					else
						p_error = String::Format("Already connected - disconnect first before trying to host");

					return false;
				}

				return true;
			}

			bool Host(int p_tcpPort, String ^p_username, String ^p_password = "", bool p_nonBlocking = true, int p_udpPort = -1)
			{
				// if p_udpPort != 1 then we are also handling a udp socket

				bool useUDP = (p_udpPort != -1);

				String ^error;
				if (IsOkToHost(error) == false)
				{
					NetworkMessage(GameNetworkMessageType::Error, error);
					return false;
				}
				else if (p_tcpPort == p_udpPort)
				{
					NetworkMessage(GameNetworkMessageType::Error, String::Format("TCP and UPD port are both {0} - they must be different", p_tcpPort));
					return false;
				}
				else
				{
					// start up listener!
					// Try to bind the socket
					sockaddr_in saServerAddress;

					serverListeningSocket.sk = socket(AF_INET, SOCK_STREAM, 0);	// SOCK_STREAM = TCP  SOCK_DGRAM = UDP
					if (serverListeningSocket.sk == INVALID_SOCKET)
					{
						OnHostFailure("Unable to create a TCP socket for listening!  Did you call WSAStartup()?");
						return false;
					}

					memset(&saServerAddress, 0, sizeof(sockaddr_in));
					saServerAddress.sin_family = AF_INET;	// internetwork: UDP, TCP, etc
					saServerAddress.sin_addr.s_addr = htonl(INADDR_ANY);
					saServerAddress.sin_port = htons(p_tcpPort);
					if (bind(serverListeningSocket.sk, (sockaddr*)&saServerAddress,
						sizeof(sockaddr)) == SOCKET_ERROR)
					{
						OnHostFailure(String::Format("Unable to bind socket with port {0}.  Are you already hosting on this machine on the same port with another process?", p_tcpPort));
						return false;
					}

					// This chunk makes it non-blocking!
					// If blocking, accept() will not return until a connection arrives
					if (p_nonBlocking == true)
					{
						serverListeningSocket.MakeBlocking(false);
					}

					// udp
					if (useUDP == true)
					{
						udpSocket.sk = socket(AF_INET, SOCK_DGRAM, 0);
						if (udpSocket.sk == INVALID_SOCKET)
						{
							OnHostFailure("Unable to create a UDP socket for communication!");

							serverListeningSocket.Close();
							udpSocket.Close();

							return false;
						}

						// bind it to the port for listening
						struct sockaddr_in myaddr;
						memset((char *)&myaddr, 0, sizeof(myaddr));
						myaddr.sin_family = AF_INET;
						myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
						myaddr.sin_port = htons(p_udpPort);

						if (bind(udpSocket.sk, (struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR) 
						{
							OnHostFailure(String::Format("Unable to bind UDP socket to port {0} - is another process using it?", p_udpPort));

							serverListeningSocket.Close();
							udpSocket.Close();

							return false;
						}

						udpSocket.MakeBlocking(false);
					}

					if (listen(serverListeningSocket.sk, 32) != SOCKET_ERROR)
					{
						// No need to set linger on a socket that only takes incoming data

						active = true;
						networkTimer.ResetElapsedTime(); // Process() can now run, so reset timer
						server = true;

						if (useUDP == true)
						{
							// generate hash kernal
							GenerateHashKernel();
						}

						GameNetworkPacketHelper::CopyStringToCharArray(localUser.name, 33, p_username);
						GameNetworkPacketHelper::CopyStringToCharArray(sessionPassword, 33, p_password);

						localUser.id = GetNextClientId();
						ServerAddPlayer(localUser, true, true); // always host for now
						OnHostSuccess();
						OnJoined();

						return true;
					}
					else
					{
						OnHostFailure("Unable to start listener with 32 backlog\r\n");
						serverListeningSocket.Close();
						if (useUDP == true)
							udpSocket.Close();
						return false;
					}					
				}
			}

		private:
			void GenerateHashKernel()
			{
				LecuyerRandom rng;
				kernelByteQty = rng.GetRandomInteger(UDP_HASH_KERNEL_SIZE - 4, UDP_HASH_KERNEL_SIZE);
				saltBeginBytes = rng.GetRandomInteger(UDP_HASH_SALT_SIZE - 4, UDP_HASH_SALT_SIZE);
				saltEndBytes = rng.GetRandomInteger(UDP_HASH_SALT_SIZE - 4, UDP_HASH_SALT_SIZE);

				for (int i = 0; i < UDP_HASH_KERNEL_SIZE; i++)
				{
					hashKernel[i] = rng.GetRandomInteger(0, 255);
				}
				for (int i = 0; i < UDP_HASH_SALT_SIZE; i++)
				{
					hashSaltBegin[i] = rng.GetRandomInteger(0, 255);
					hashSaltEnd[i] = rng.GetRandomInteger(0, 255);
				}
			}

			int CalculatePacketHash(char *p_packet, int p_length)
			{
				int kernelIndex = 0;
				int hashResult = 0;

				// salt begin
				for (int i = 0; i < saltBeginBytes; i++)
				{ 
					hashResult += hashSaltBegin[i] * hashKernel[kernelIndex];
					kernelIndex++;
					if (kernelIndex >= kernelByteQty)
						kernelIndex = 0;
				}

				// packet
				for (int i = 0; i < p_length; i++)
				{
					hashResult += p_packet[i] * hashKernel[kernelIndex];
					kernelIndex++;
					if (kernelIndex >= kernelByteQty)
						kernelIndex = 0;
				}

				// salt end
				for (int i = 0; i < saltEndBytes; i++)
				{
					hashResult += hashSaltEnd[i] * hashKernel[kernelIndex];
					kernelIndex++;
					if (kernelIndex >= kernelByteQty)
						kernelIndex = 0;
				}

				return hashResult;
			}

		public:
			// implementation can call this to determine if connection can be attempted
			bool IsOkToConnect(String^ %p_error)
			{
				// p_error will be populated with error string

				if (active == true)
				{
					if (server == true)
						p_error = String::Format("Already hosting - disconnect first before trying to connect");
					else
						p_error = String::Format("Already connected - disconnect first before trying to connect");

					return false;
				}

				return true;
			}

			bool Connect(String ^p_hostAddress, int p_tcpPort, String ^p_userName, bool p_nonBlockingSocket = true, bool p_nonBlockingConnect = true, int p_udpPort = -1)
			{
				// p_nonBlockingSocket determines if socket will be blocking after connection occurs
				// p_nonBlockingConnect determines if socket will wait for connection before connect() returns

				bool useUDP = (p_udpPort != -1);

				// connect
				struct sockaddr_in	serv_addr;
				LPHOSTENT			lpHost;
				int					err;

				String ^error;
				if (IsOkToConnect(error) == false)
				{
					OnConnectFailure(error);
					return false;
				}
				else
				{
					// Open the socket
					localUser.socket.sk = socket(AF_INET, SOCK_STREAM, 0);
					if (localUser.socket.sk == INVALID_SOCKET)
					{
						OnConnectFailure("Unable to make TCP socket for connecting - did you call WSAStartup()?");
						return false;
					}

					// udp
					if (useUDP == true)
					{
						udpSocket.sk = socket(AF_INET, SOCK_DGRAM, 0);
						if (udpSocket.sk == INVALID_SOCKET)
						{
							OnConnectFailure(String::Format("Unable to create a UDP socket for communication!  Is port {0} being used by another process?", p_udpPort));

							localUser.socket.Close();
							udpSocket.Close();

							return false;
						}

						udpSocket.MakeBlocking(false);
					}

					char hostAddress[256];
					GameNetworkPacketHelper::CopyStringToCharArray(hostAddress, 256, p_hostAddress);
					String ^hostAddressString = GameNetworkPacketHelper::CharArrayToString(hostAddress);
					bool ip = true;
					memset(&serv_addr, 0, sizeof(sockaddr_in));
					if (useUDP == true)
						memset(&serverUDPAddress, 0, sizeof(sockaddr_in));
					serv_addr.sin_family = AF_INET;
					// todo: 'inet_addr': Use inet_pton() or InetPton() instead or define _WINSOCK_DEPRECATED_NO_WARNINGS to disable deprecated API warnings
					// I used inet_addr() here, it works, I couldn't get inet_pton() or InetPton() to compile, and set _WINSOCK_DEPRECATED_NO_WARNINGS in the project precompile defines
					serv_addr.sin_addr.s_addr = inet_addr(hostAddress);
					if (useUDP == true)
					{
						serverUDPAddress.sin_family = AF_INET;
						serverUDPAddress.sin_addr.s_addr = inet_addr(hostAddress);
					}
					if (serv_addr.sin_addr.s_addr == INADDR_NONE)
					{
						ip = false;
					}
					// gethostbyname() and connect() have a chance to pause the process, so display some information in OnConnectingPreProcess() and do a BlockRender() always for the gethostbyname() freeze
					if (ip == true)
						OnConnectingPreProcess(String::Format("Connecting to {0}...", hostAddressString));
					else
						OnConnectingPreProcess(String::Format("Connecting to '{0}'...", hostAddressString));
					if (ip == false)
					{
						lpHost = gethostbyname(hostAddress); // supports named host ('myaddress.com', etc.)
						if (lpHost != NULL)
						{
							serv_addr.sin_addr.s_addr = ((LPIN_ADDR)lpHost->h_addr)->s_addr;
							if (useUDP == true)
								serverUDPAddress.sin_addr.s_addr = ((LPIN_ADDR)lpHost->h_addr)->s_addr;
						}
						else
						{
							// NOTE: If your ISP auto-returns a "not found" page in your
							//    web browser, this error will not be generated
							OnConnectingPostProcess(); // remove anything created in OnConnectingPreProcess()
							OnConnectFailure(String::Format("Failed to resolve host name '{0}'", hostAddressString));	// Failed to resolve host name
							localUser.socket.Close();
							udpSocket.Close();
							return false;
						}
					}

					// Assign the port
					serv_addr.sin_port = htons(p_tcpPort);
					if (useUDP == true)
						serverUDPAddress.sin_port = htons(p_udpPort);

					// This chunk makes it non-blocking!
					// Make the socket non-blocking before trying to connect, and check for a readyforwriting status periodically to confirm (or let received data confirm it).  if
					//   after a time it isn't ready for writing, close the socket and note an error attempting to connect.  This prevents having to display a connecting message
					//   while the app thread freezes.
					// If done this way, don't call OnConnectSuccess until we know the socket connected (by receiving data or detecting a ready for writing condition)
					if (p_nonBlockingConnect == true)
					{
						localUser.socket.MakeBlocking(false);
					}

					// Establish the connection
					err = connect(localUser.socket.sk, (struct sockaddr*)&serv_addr, sizeof(sockaddr));
					// just debugging - trying to see if we can detect a more severe connection error or just make sure we have an expected one
					// but socketError = 0 in normal circumstances.
					//if (err == SOCKET_ERROR)
					//{
						//int socketError;
						//int len = sizeof(socketError);
						//getsockopt(localUser.socket.sk, SOL_SOCKET, SO_ERROR, (char *)&socketError, &len); // this return 0 in socketError

						//int socketError = WSAGetLastError(); // this returns 10035 - WSAEWOULDBLOCK.  Note: repeated connect() calls would be expected to return WSAEALREADY for in process and WSAEISCONN for connected, and
															 // WSAECONNREFUSED, WSAENETUNREACH and WSAETIMEDOUT for failed connections.  After that, another attempted connect() call can be made to start over.
															 // All of this is ignored and just handled by calls to CheckConnectionStatus() later, which checks for these errors on the socket using getsockopt()
															 //   and verified writeability on the socket for a successful connection, since WSAEISCONN is not reported by getsockopt() - no repeated connect() calls are made.
					//}
					// must wait for result from Process() call to CheckConnectionStatus() now, since socket is non-blocking
					if (p_nonBlockingConnect == true)
						localUser.socket.checkConnectionStatus = true;
					else
					{
						// we have a connection result, so call OnConnectingPostProcess() now!
						OnConnectingPostProcess(); // remove anything created in OnConnectingPreProcess()

						// blocking connect result
						if (err == SOCKET_ERROR)
						{
							// connection error on blocking connect, leave now
							if (ip == true)
								OnConnectFailure("Connect Error - No Response from Host IP");
							else
								OnConnectFailure("Connect Error - No Response from Host Address");

							localUser.socket.Close();
							udpSocket.Close();

							return false;
						}
						else
						{
							// if socket is supposed to be non- blocking after a blocking connect, do so now
							if (p_nonBlockingSocket == true)
							{
								localUser.socket.MakeBlocking(false);
							}

							// Set the socket to linger so that outgoing packet sends will complete before the socket closes, if Close() is called directly after a SendCritical
							struct linger st_linger = { 1, 3 };
							setsockopt(localUser.socket.sk, SOL_SOCKET, SO_LINGER, (char *)&st_linger, sizeof(st_linger));
						}
					}

					// these will change if there is a connection error when Process() calls CheckConnectionStatus()
					active = true;
					networkTimer.ResetElapsedTime(); // Process() can now run, so reset timer
					server = false;
					GameNetworkPacketHelper::CopyStringToCharArray(localUser.name, 33, p_userName); // save for when server asks for login info

					// if was a blocking connect and we made it here, it was successful
					if (p_nonBlockingConnect == false)
					{
						OnConnectSuccess();
					}

					return true;
				}
			}

		private:
			bool ValidatePacket(char *p_packet)
			{
				// return true if handled

				int type = GameNetworkPacketHelper::GetCleanPacketType(p_packet);

				switch (type)
				{
				case NetworkPacketTypes::AddPlayer:
				{
					if (ValidateAddPlayerPacket((NetworkAddPlayerPacketBase *)p_packet) == false)
						return false;
				}
				break;
				case NetworkPacketTypes::PlayerLeft:
				{
					NetworkPlayerLeftPacket *packet = (NetworkPlayerLeftPacket *)p_packet;
					if (packet->id < 0)
						return false;
					if (packet->length != sizeof(NetworkPlayerLeftPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::PlayerTimingOut:
				{
					NetworkPlayerTimingOutPacket *packet = (NetworkPlayerTimingOutPacket *)p_packet;
					if (packet->id < 0)
						return false;
					if (packet->length != sizeof(NetworkPlayerTimingOutPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::PlayerTimedOut:
				{
					NetworkPlayerTimedOutPacket *packet = (NetworkPlayerTimedOutPacket *)p_packet;
					if (packet->id < 0)
						return false;
					if (packet->length != sizeof(NetworkPlayerTimedOutPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::PlayerNoLongerTimingOut:
				{
					NetworkPlayerNoLongerTimingOutPacket *packet = (NetworkPlayerNoLongerTimingOutPacket *)p_packet;
					if (packet->id < 0)
						return false;
					if (packet->length != sizeof(NetworkPlayerNoLongerTimingOutPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::Disconnect:
				{
					NetworkDisconnectPacket *packet = (NetworkDisconnectPacket *)p_packet;
					int reasonLength = GameNetworkPacketHelper::StringLength(packet->reason, 999);
					if (reasonLength > 999)
						return false;
					if (packet->length != 9 + reasonLength)
						return false;
				}
				break;
				case NetworkPacketTypes::IAmAwake:
				{
					NetworkSimplePacket *packet = (NetworkSimplePacket *)p_packet;
					if (packet->length != sizeof(NetworkSimplePacket))
						return false;
				}
				break;
				case NetworkPacketTypes::IAmDisconnecting:
				{
					NetworkSimplePacket *packet = (NetworkSimplePacket *)p_packet;
					if (packet->length != sizeof(NetworkSimplePacket))
						return false;
				}
				break;
				case NetworkPacketTypes::Keepalive:
				{
					NetworkSimplePacket *packet = (NetworkSimplePacket *)p_packet;
					if (packet->length != sizeof(NetworkSimplePacket))
						return false;
				}
				break;
				case NetworkPacketTypes::LoginInfo:
				{
					NetworkLoginPacket *packet = (NetworkLoginPacket *)p_packet;
					int userNameLength = GameNetworkPacketHelper::StringLength(packet->userName, 32);
					int versionStringLength = GameNetworkPacketHelper::StringLength(packet->appVersionString, 15);
					int versionGuidLength = GameNetworkPacketHelper::StringLength(packet->appVersionGuid, 36);
					if (userNameLength > 32)
						return false;
					if (versionStringLength > 15)
						return false;
					if (versionGuidLength > 36)
						return false;
					if (packet->length != sizeof(NetworkLoginPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::Message:
				{
					NetworkMessagePacket *packet = (NetworkMessagePacket *)p_packet;
					int messageLength = GameNetworkPacketHelper::StringLength(packet->message, 7999);
					if (messageLength > 7999)
						return false;
					if (packet->length != 9 + messageLength)
						return false;
				}
				break;
				case NetworkPacketTypes::PacketConfirmation:
				{
					NetworkPacketConfirmationPacket *packet = (NetworkPacketConfirmationPacket *)p_packet;
					if (packet->confirmationId < 0)
						return false;
					if (packet->channel < 0 || packet->channel > 7)
						return false;
					if (packet->length != sizeof(NetworkPacketConfirmationPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::SendLoginInfo:
				{
					NetworkSimplePacket *packet = (NetworkSimplePacket *)p_packet;
					if (packet->length != sizeof(NetworkSimplePacket))
						return false;
				}
				break;
				case NetworkPacketTypes::Wakeup:
				{
					NetworkSimplePacket *packet = (NetworkSimplePacket *)p_packet;
					if (packet->length != sizeof(NetworkSimplePacket))
						return false;
				}
				break;
				case NetworkPacketTypes::YouAreValidated:
				{
					NetworkYouAreValidatedPacket *packet = (NetworkYouAreValidatedPacket *)p_packet;
					if (packet->id < 0)
						return false;
					if (packet->length != sizeof(NetworkYouAreValidatedPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::SendUDPLogin:
				{
					NetworkSendUDPLoginPacket *packet = (NetworkSendUDPLoginPacket *)p_packet;
					if (packet->id < 0)
						return false;
					if (packet->kernelByteQty < (UDP_HASH_KERNEL_SIZE - 4) || packet->kernelByteQty > UDP_HASH_KERNEL_SIZE)
						return false;
					if (packet->saltBeginByteQty < (UDP_HASH_SALT_SIZE - 4) || packet->saltBeginByteQty > UDP_HASH_SALT_SIZE)
						return false;
					if (packet->saltEndByteQty < (UDP_HASH_SALT_SIZE - 4) || packet->saltEndByteQty > UDP_HASH_SALT_SIZE)
						return false;
					if (packet->length != sizeof(NetworkSendUDPLoginPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::UDPLogin:
				{
					NetworkUDPLoginPacket *packet = (NetworkUDPLoginPacket *)p_packet;
					if (packet->length != sizeof(NetworkUDPLoginPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::UDPConfirmation:
				{
					NetworkUDPConfirmationPacket *packet = (NetworkUDPConfirmationPacket *)p_packet;
					if (packet->length != sizeof(NetworkUDPConfirmationPacket))
						return false;
				}
				break;
				case NetworkPacketTypes::QueuePacket:
				{
					NetworkQueuePacket *queuePacket = (NetworkQueuePacket *)p_packet;
					if (queuePacket->length > sizeof(NetworkQueuePacket))
						return false;

					int index = 0;
					while ((index + 8) < queuePacket->length)
					{
						char *packet = &(queuePacket->packets[index]);
						if (ValidatePacket(packet) == false)
							return false;
						else
							index += GameNetworkPacketHelper::GetPacketLength(packet);
					}
					if (index + 8 != queuePacket->length)
						return false;
				}
				break;
				default:
					return CustomValidatePacket(p_packet, type);
				}

				return true;
			}

			// process delayed packets to send until upload bandwidth consumed (socket not ready for writing, no concern about bandwidth numbers)
			// resend guaranteed packets that had no response for a time if nothing delayed
			// if a socket has absolutely no packets to send (haven't tried to send any), or isn't ready, we are done with this loop

			bool SendWaitingPackets(GameNetworkCommunicationSocket &p_socket, GameNetworkClient *p_client, bool &p_anyPacketsSent, bool p_ignoreBandwidth = false)
			{
				// on return:
				// there are no packets left on this socket to send, so don't call this again
				// the routine returned because bandwidth was consumed, and this routien should be called again after more bandwidth is allocated
				// the socket isn't ready - don't call this again until that flag is reset

				// Routine that handles all waiting and guaranteed packets, single iteration for a single socket
				// for the socket, send incomplete packet, then send delayed packets, then spin through the guaranteed packet lists, starting with the list after the last one packets were sent for, until socket isn't ready, bandwidth is consumed, or there are no more packets that can be sent

				// return true if there are still packets to send after bandwidth is used up, otherwise return false (no more packets to send or socket no longer ready)
				// essentially, should this socket be revisited on another iteration pass in this Process cycle?

				// todo: even out the number of bytes sent per guaranteed list (a guaranteed list full of small packets sends slower than the others - if they are all Send packets, that is -
				//   Guarnateed packets have to wait for a confirmation anyway)

				if (p_socket.notReady == true)
					return false; // nothing to do

				// send unfinished packet if any
				if (p_socket.SendUnfinishedPacket() == false)
					return false; // socket not ready, skip out

				// send delayed packets
				while (p_socket.notReady == false)
				{
					if (p_socket.delayedPackets.IsEmpty() == false)
					{
						GameNetworkPacket *packet = p_socket.delayedPackets.GetFirstPacket();
						if (packet->sendType != GameNetworkPacketSendType::Now && packet->sendType != GameNetworkPacketSendType::Send)
							throw gcnew Exception("Only Now or Send packets allowed in delayed packet list");
						if (p_ignoreBandwidth == false || p_socket.bandwidthBytesAllowed >= packet->size / 2)
						{
							bool sent = false;
							bool socketReady = p_socket.SendWaitingPacket(&packet->packet[0], packet->size, packet->flags, sent);
							if (sent == true)
							{
								// we sent part of it or at least saved it
								p_socket.delayedPackets.RemoveFrontPacket();
							}
							if (socketReady == false)
							{
								// treat as not ready if not all bytes sent and skip out - this socket is done
								p_socket.notReady = true;
								return false;
							}
						}
					}
					else
						break;
				}

				// send packets in guaranteed list
				bool noPacketsSent = true;
				int stopGuaranteedPacketList = p_socket.nextGuaranteedPacketList;

				// track last list data sent for so that later lists have a chance - gear so that if no packets sent at all, the current list is started with again
				// todo: this variable doesn't guarantee a good spread, but it's better than it was
				int lastListPacketsSentFor = p_socket.nextGuaranteedPacketList - 1;
				if (lastListPacketsSentFor < 0)
					lastListPacketsSentFor = 7;

				// todo: check for complete loop and if no packets sent without kicking out for an error, return false
				bool anyListSkippedBecauseOfBandwidthOnly = false;
				while (p_socket.notReady == false)
				{
					if (p_socket.guaranteedPackets[p_socket.nextGuaranteedPacketList].IsEmpty() == false)
					{
						GameNetworkPacket *packet = p_socket.guaranteedPackets[p_socket.nextGuaranteedPacketList].GetFirstPacket();
						if (packet->sendType != GameNetworkPacketSendType::Send && packet->sendType != GameNetworkPacketSendType::Guaranteed)
							throw gcnew Exception("Guaranteed lists should only have Guaranteed and Send packets");
						if (packet->sendType == GameNetworkPacketSendType::Send)
						{
							// check remaining bandwidth
							if (p_ignoreBandwidth == true || p_socket.bandwidthBytesAllowed >= packet->size / 2)
							{
								// Send packet
								bool sent = false;
								bool socketReady = p_socket.SendWaitingPacket(&(packet->packet[0]), packet->size, packet->flags, sent);
								if (sent == true)
								{
									// we sent part of it or at least saved it
									lastListPacketsSentFor = p_socket.nextGuaranteedPacketList;
									p_socket.guaranteedPackets[p_socket.nextGuaranteedPacketList].RemoveFrontPacket();
								}
								if (socketReady == false)
								{
									// treat as not ready if not all bytes sent and skip out - this socket is done
									p_socket.notReady = true;

									// give list after last list packets sent for a chance for next time
									p_socket.nextGuaranteedPacketList = lastListPacketsSentFor + 1;
									if (p_socket.nextGuaranteedPacketList >= 8)
										p_socket.nextGuaranteedPacketList = 0;

									return false;
								}

								noPacketsSent = false; // we sent one, well want to loop back on this one again
							}
							else
								anyListSkippedBecauseOfBandwidthOnly = true;

							// proceed to next list
						}
						else
						{
							// Guaranteed packet
							// send for the first time or re-send it
							if (packet->sent == false || packet->timeSinceSentMS >= resendGuaranteedPacketDelayMS)
							{
								if (p_ignoreBandwidth == true || p_socket.bandwidthBytesAllowed >= packet->size / 2)
								{
									// don't flag bandwidth consumption here - any guaranteed send from this list means it's done!

									// Send packet
									bool sent = false;
									bool socketReady = p_socket.SendWaitingPacket(&(packet->packet[0]), packet->size, packet->flags, sent);
									if (sent == true)
									{
										// we sent part of it or at least saved it
										lastListPacketsSentFor = p_socket.nextGuaranteedPacketList;
										// do NOT remove the packet!  Wait for confirmation!

										int channel = GameNetworkPacketHelper::GetPacketChannel(&(packet->packet[0]));
										if (packet->sent == true)
										{
											if (verboseEventReporting == true)
												OnGuaranteedPacketReSent(p_client, packet->confirmationId, channel); // need client identified
										}
										else
										{
											packet->sent = true;
											if (verboseEventReporting == true)
												OnGuaranteedPacketSent(p_client, packet->confirmationId, channel); // need client identified
										}
										// reset time sent
										packet->timeSinceSentMS = 0;
									}
									if (socketReady == false)
									{
										// treat as not ready if not all bytes sent and skip out - this socket is done
										p_socket.notReady = true;

										// give list after last list packets sent for a chance for next time
										p_socket.nextGuaranteedPacketList = lastListPacketsSentFor + 1;
										if (p_socket.nextGuaranteedPacketList >= 8)
											p_socket.nextGuaranteedPacketList = 0;

										return false;
									}

									// we sent one, but no point in looping back on this one because we need a confirmation packet to proceed, so don't identify that a packet was sent
									// so leave noPacketsSent alone
								}
								else
									anyListSkippedBecauseOfBandwidthOnly = true;

								// don't change noPacketsLeft here

								// proceed to next list
							} // if
						} // else
					} // if

					// next list
					p_socket.nextGuaranteedPacketList++;
					if (p_socket.nextGuaranteedPacketList >= 8)
						p_socket.nextGuaranteedPacketList = 0;

					if (p_socket.nextGuaranteedPacketList == stopGuaranteedPacketList)
					{
						if (noPacketsSent == true)
						{
							// give list after last list packets sent for a chance for next time
							p_socket.nextGuaranteedPacketList = lastListPacketsSentFor + 1;
							if (p_socket.nextGuaranteedPacketList >= 8)
								p_socket.nextGuaranteedPacketList = 0;

							if (anyListSkippedBecauseOfBandwidthOnly == true)
								return true; // can revisit
							else
								return false; // can't revisit, nothing to do (no packets or socket not ready)
						}

						// reset and keep going, we might be able to send more
						noPacketsSent = true;
					}
				}

				if (p_socket.notReady == true)
					return false; // don't revisit this socket on this process cycle anymore
				else
					return true; // socket can be revisited - we stopped because of bandwidth and there are still sockets to be sent out
			}

		public:

			void AllocateBandwidth(int p_bandwidthBytesToSend = 20000, bool p_resetNotReadyFlags = true)
			{
				// allocating bandwidth is all about distributing uploads through all sockets to be communicated through.  When bandwidth is used up
				//   on a socket, later incoming packets are then stored in their respective holding area (delayed, guaranteed) until SendWaitingPackets() is called,
				//   then more bandwidth is allocated to each socket and more packets are sent, and the process is repeated until no packets remain or all 
				//   of the sockets aren't ready.  This way, sending thousands of packets to each client causes a few packets to get fed through each socket at a time,
				//   giving the upload bandwidth of the server machine a chance to provide fair distribution among all sockets being sent out.
				if (active == true)
				{
					if (server == true)
					{
						for (int i = 0; i < clientQty; i++)
						{
							// do this on ALL sockets, even the not connected ones, so that new connection sockets found later have bandwidth to use
							// todo: if there is only one client, this really isn't necessary.

							// reset not ready flag - if it's set later, send iteration loop below will skip it
							if (p_resetNotReadyFlags == true)
								clients[i].socket.notReady = false;
							clients[i].socket.AddBandwidth(p_bandwidthBytesToSend);
						}
					}
					else
					{
						// client doesn't use bandwidth, but it does reset the flag
						if (p_resetNotReadyFlags == true)
							localUser.socket.notReady = false;
					}
				}
			}

		private:
			void ConsumeLag(int p_elapsedTimeMS)
			{
				localUser.socket.ConsumeLag(p_elapsedTimeMS);
				for (int i = 0; i < clientQty; i++)
					clients[i].socket.ConsumeLag(p_elapsedTimeMS);
			}

			bool CheckConnectionStatus(GameNetworkCommunicationSocket &p_socket)
			{
				// note: this routine works even if the host imemdiately closed the socket due to connections being full.  The socket is able to receive the
				//   rejection message.  OnConnectSuccess() will be called, then the rejection packet will be received and processed.

				// NOTE: This methodology works on Windows TCP sockets.  Unknown if it works on Linux, BSD sockets, etc.
				// some methodologies might call for calling connect() again, etc.  but calling connect() again on a socket with a confirmed failure would
				//   make it try to connect again, so code with caution.

				// return true if connection confirmed
				// return false if connection either not confirmed or there was an error and socket was closed

				if (OnConnectingContinue() == false)
				{
					// connection is cancelled

					// don't check anymore
					p_socket.checkConnectionStatus = false;

					// Disconnect without calling OnDisconnect()
					Disconnect("", false, "", true);

					OnConnectingCanceled();
					return false;
				}

				long error;
				int len = sizeof(error);
				int status = getsockopt(p_socket.sk, SOL_SOCKET, SO_ERROR, (char *)&error, &len); // always returns socket error
				if (error == 0)
				{
					// no confirmed error yet, see if communication is possible
					if (p_socket.ReadyForWriting() == true)
					{
						// we know a result - call OnConnectingPostProcess()!
						OnConnectingPostProcess();

						// socket is functional - assume we have a successful connection

						// don't check anymore
						p_socket.checkConnectionStatus = false;

						// Set the socket to linger so that outgoing packet sends will complete before the socket closes, if Close() is called directly after a SendCritical
						struct linger st_linger = { 1, 3 };
						setsockopt(p_socket.sk, SOL_SOCKET, SO_LINGER, (char *)&st_linger, sizeof(st_linger));

						OnConnectSuccess();
						return true;
					}
				}
				else if (error == WSAETIMEDOUT)
				{
					// we know a result - call OnConnectingPostProcess()!
					OnConnectingPostProcess();

					// failed to connect at all (bad address)

					// don't check anymore
					p_socket.checkConnectionStatus = false;

					// Disconnect without calling OnDisconnect()
					Disconnect("", false, "", true);

					OnConnectFailure("Connection Error - Host IP not found");
					return false;
				}
				else if (error == WSAECONNREFUSED)
				{
					// we know a result - call OnConnectingPostProcess()!
					OnConnectingPostProcess();

					// reached IP address, no hosting available

					// don't check anymore
					p_socket.checkConnectionStatus = false;

					// Disconnect without calling OnDisconnect()
					Disconnect("", false, "", true);

					OnConnectFailure("Connection Error - No response from Host IP");
					return false;
				}
				else if (error == WSAENETUNREACH)
				{
					// we know a result - call OnConnectingPostProcess()!
					OnConnectingPostProcess();

					// reached IP address, no hosting available

					// don't check anymore
					p_socket.checkConnectionStatus = false;

					// Disconnect without calling OnDisconnect()
					Disconnect("", false, "", true);

					OnConnectFailure("Connection Error - Host IP unreachable");
					return false;
				}
				else
				{
					// we know a result - call OnConnectingPostProcess()!
					OnConnectingPostProcess();

					// some other error

					// don't check anymore
					p_socket.checkConnectionStatus = false;

					// Disconnect without calling OnDisconnect()
					Disconnect("", false, "", true);

					OnConnectFailure(String::Format(String::Format("Connection Error - Unhandled WSA error {0}", error)));
					return false;
				}

				// no result yet.
				return false;
			}

		public:

			// NOTE: If network is active, you MUST call this every game tick to determine successful connection as a client, and to process incoming packets and send waiting outgoing packets!
			void Process(int p_bandwidthBytesPerIteration = 20000)
			{
				networkTimer.ResetElapsedTime();
				networkTimer.Poll();

				if (active == false)
					return;

				// if client is trying to connect and we haven't gotten a result yet, evaluate now (call OnConnectSuccess() or OnConnectFailure() appropriately)
				if (server == false)
				{
					if (localUser.socket.checkConnectionStatus == true)
					{
						// returns true if connection successful
						// returns false if connection not confirmed yet or there was a failure and socket was closed in response
						if (CheckConnectionStatus(localUser.socket) == false)
							return;
					}
				}

				int timeElapsedMS = networkTimer.GetElapsedTimeMS();

				// catchall execution of network process loop
				// should be called near end of loop after game events have attempted to send their own packets

				// allocate time to all bandwidth lists
				localUser.socket.AddElapsedTime(timeElapsedMS);
				if (server == true)
				{
					for (int i = 0; i < clientQty; i++)
					{
						if (clients[i].IsConnected() == true)
						{
							clients[i].socket.AddElapsedTime(timeElapsedMS);
						}
					}
				}

				// anything else need to be taken care of before process received packets and send out waiting ones?
				CustomProcess(networkTimer.GetElapsedTimeMS());

				// should we send a keepalive?
				localUser.timeSinceLastKeepaliveSentMS += timeElapsedMS;
				bool sendKeepalive = false;
				if (localUser.timeSinceLastKeepaliveSentMS >= sendKeepalivePacketDelayMS)
				{
					sendKeepalive = true;
					localUser.timeSinceLastKeepaliveSentMS = 0;
				}

				// look for packets from each source
				if (server == true)
				{
					// server process
					int keepAlivesSent = 0;

					// set all sockets with bandwidthallowed
					AllocateBandwidth(p_bandwidthBytesPerIteration, false);

					ConsumeLag(timeElapsedMS);

					// look for connections
					// reject new clients for no slots
					if (server == true)
						LookForConnections(timeElapsedMS);

					ProcessUDPPacketsFromClients();

					// loop through each connected client, process incoming packets (no need to start at last index, since incoming packets are pulled in from all sockets when they arrive)
					for (int i = 0; i < clientQty; i++)
					{
						if (clients[i].status == NetworkClientStatus::NotConnected)
							continue;

						clients[i].timeSinceLastPacketReceivedMS += timeElapsedMS;

						if (clients[i].status == NetworkClientStatus::Pending)
						{
							if (UsesUDP() == true)
							{
								// send out appropriate negotiation packets
								if (clients[i].UDPConfirmationRequired() == true)
								{
									clients[i].timeSinceUDPValidationSentMS += timeElapsedMS;
									if (clients[i].timeSinceUDPValidationSentMS >= 500)
									{
										clients[i].timeSinceUDPValidationSentMS = 0;

										// send another confirmation until client gets it and returns a confirmation via TCP
										// this is just a resend of the client id, which the client already has if UDP is being used
										NetworkYouAreValidatedPacket validatedPacket;
										GameNetworkPacketHelper::PopulateYouAreValidatedPacket(validatedPacket, clients[i].id);

										SendToClientUDP(&clients[i], (char *)&validatedPacket, validatedPacket.length, 0);
									}
								}
							}
						}

						// send keepalive
						if (clients[i].status == NetworkClientStatus::Validated)
						{
							if (sendKeepalive == true)
							{
								NetworkSimplePacket keepAlivePacket;
								GameNetworkPacketHelper::PopulateKeepAlivePacket(keepAlivePacket);
								clients[i].socket.SendNow((char *)&keepAlivePacket, keepAlivePacket.length, 0);
								keepAlivesSent++;
							}
						}

						// interpret all packets from each (including routing to implementation), and send next guaranteed packets and normal packets to send when confirmation received, put in line behind delayed
						// reject connection on huge packet length
						// validate packets, report error on bad ones
						// reject pending client for bad login info
						// respond to wakeups from clients
						// todo: if upload max byte sends exceeded on this initial loop, place packets to send in delayed packet list - these packets will get another pass later
						ProcessPacketsFromClient(clients[i]);

						// handle timeouts on pending and validated clients
						// if timing out, notify clients and send wakeups only for a validated client
						// if timed out, kick client, and notify other clients only if validated
						if (clients[i].status != NetworkClientStatus::NotConnected)
						{
							if (clients[i].timeSinceLastPacketReceivedMS > timeOutDelayMS)
							{
								clients[i].timeOutQty++;
								clients[i].timeSinceLastPacketReceivedMS = 0;

								if (clients[i].timeOutQty < maxTimeOutQty)
								{
									// 1 timeoutn

									// echo locally
									if (clients[i].status != NetworkClientStatus::Validated)
										OnPendingClientTimingOut(clients[i], clients[i].timeOutQty, maxTimeOutQty);
									else
										OnPlayerTimingOut(clients[i].id, clients[i].timeOutQty, maxTimeOutQty);

									// if client isn't validated, don't even send wakeup or notify
									if (clients[i].status == NetworkClientStatus::Validated)
									{
										// send wakeup
										NetworkSimplePacket keepAlivePacket;
										GameNetworkPacketHelper::PopulateWakeupPacket(keepAlivePacket);
										clients[i].socket.SendNow((char *)&keepAlivePacket, keepAlivePacket.length, 0);
										if (verboseEventReporting == true)
											OnWakeupSent(&clients[i]);

										// notify clients
										NetworkPlayerTimingOutPacket timingOutPacket;
										GameNetworkPacketHelper::PopulatePlayerTimingOutPacket(timingOutPacket, clients[i].id, clients[i].timeOutQty, maxTimeOutQty);
										SendToAllClientsNow((char *)&timingOutPacket, timingOutPacket.length, 0, clients[i].id);
									}
								}
								else
								{
									// too many timeouts
									// echo locally
									if (clients[i].status != NetworkClientStatus::Validated)
									{
										OnPendingClientTimingOut(clients[i], clients[i].timeOutQty, maxTimeOutQty);
										OnPendingClientTimedOut(clients[i]);
									}
									else
									{
										OnPlayerTimingOut(clients[i].id, clients[i].timeOutQty, maxTimeOutQty);
										OnPlayerTimedOut(clients[i].id);
									}

									// if client isn't validated, don't even notify
									if (clients[i].status == NetworkClientStatus::Validated)
									{
										// notify clients
										NetworkPlayerTimingOutPacket timingOutPacket;
										GameNetworkPacketHelper::PopulatePlayerTimingOutPacket(timingOutPacket, clients[i].id, clients[i].timeOutQty, maxTimeOutQty);
										SendToAllClientsNow((char *)&timingOutPacket, timingOutPacket.length, 0, clients[i].id);

										NetworkPlayerTimedOutPacket timedOutPacket;
										GameNetworkPacketHelper::PopulatePlayerTimedOutPacket(timedOutPacket, clients[i].id);
										SendToAllClientsNow((char *)&timedOutPacket, timedOutPacket.length, 0, clients[i].id);
									}

									// disconnect client
									DisconnectClient(&clients[i], "You timed out bro", false, true); // reason will not be sent to client, just clear out from local client list
								}
							} // timeout happened
						} // check for timeouts
					}
					// done with timeouts

					if (keepAlivesSent > 0)
					{
						if (verboseEventReporting == true)
							OnKeepaliveSent(keepAlivesSent);
					}

					// reset client not ready flags so that loop can go through all clients
					for (int i = 0; i < clientQty; i++)
						if (clients[i].status != NetworkClientStatus::NotConnected)
							clients[i].doneProcessing = false;

					// process waiting packets
					while (true)
					{
						// reset bandwidth again on sockets not timed out
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].doneProcessing == true)
								continue;

							if (clients[i].status != NetworkClientStatus::NotConnected)
							{
								if (clients[i].socket.notReady == false)
									clients[i].socket.bandwidthBytesAllowed += p_bandwidthBytesPerIteration;

								// don't allow more than bandwidth
								if (clients[i].socket.bandwidthBytesAllowed > p_bandwidthBytesPerIteration)
									clients[i].socket.bandwidthBytesAllowed = p_bandwidthBytesPerIteration;
							}
						}

						// process delayed packets to send to max of current bandwidth, distributed among all clients 
						// - (loop around uploading a number of total bytes for each, skip those that become tagged to have sockets not ready for writing, done when all are not ready or packets gone of course)
						// resend guaranteed packets that had no response for a time if nothing delayed
						// if a socket has absolutely no packets to send, set done processing = true so that client is skipped this iteration (if haven't tried to send any on an iteration, doneProcessing on that client)
						// todo: this logic breaks down if the sockets being sent out in this loop require sending new packets on other sockets - currently not in the design

						// increase time since sent on guaranteed packets, and send lag packets
						for (int i = 0; i < clientQty; i++)
						{
							clients[i].socket.SendLagPackets();
							clients[i].socket.AddTimeElapsedToGuaranteedSentPackets(timeElapsedMS);
						}

						int iterationClientStop = nextClientToProcess;

						// track last client packets sent for - if none ever sent for any, arrange for nextClietnToProcess to not change
						int lastClientPacketSentFor = nextClientToProcess - 1;
						if (lastClientPacketSentFor < 0)
							lastClientPacketSentFor = clientQty - 1;

						bool continueLooping = false;
						while (true)
						{
							if (clients[nextClientToProcess].status != NetworkClientStatus::NotConnected)
							{
								if (clients[nextClientToProcess].doneProcessing == false)
								{
									// refresh client bandwidth
									clients[nextClientToProcess].socket.AddBandwidth(p_bandwidthBytesPerIteration);

									// send waiting packets, consider bandwidth
									bool anyPacketsSent = false;
									bool socketOkToRevisit = SendWaitingPackets(clients[nextClientToProcess].socket, &clients[nextClientToProcess], anyPacketsSent);
									if (anyPacketsSent == true)
										lastClientPacketSentFor = nextClientToProcess;
									if (socketOkToRevisit == true)
									{
										if (clients[nextClientToProcess].socket.notReady == false)
											continueLooping = true;
									}
									else
									{
										clients[nextClientToProcess].doneProcessing = true;
									}
								}
							} // if client connected

							nextClientToProcess++;
							if (nextClientToProcess >= clientQty)
								nextClientToProcess = 0;
							if (nextClientToProcess == iterationClientStop)
							{
								if (continueLooping == false)
								{
									// whichever client had packets sent, send for the next one
									// todo: if last client sent for ended up with a socket not ready, maybe they could be obligated for the next send since they got cheated on bandwidth
									// todo: OR if the last client sent for hit a socket not ready in the middle of their guaranteed list loop, the list packets weren't sent for should really be next
									// but the chaos of which client a socket is used up for will probably even out fine unless it's so exact that one client in particular keeps getting bumped, in which case
									//   that client's guaranteed lists will suffer a delay in comparison to everyone else
									nextClientToProcess = lastClientPacketSentFor + 1;
									if (nextClientToProcess >= clientQty)
										nextClientToProcess = 0;
									// all finished, finally
									break;
								}
								else
								{
									// do another loop!
									// reset flag
									continueLooping = false;
								}
							}

						} // while looping once through clients

						if (continueLooping == false)
							break;

					} // while looping multiple times through clients

					// evaluate percent of packets remaining for easy display, and tag if there are any delayed
					ProcessWaitingPackets();
					ProcessPeakDataRates();
				}
				else
				{
					// client process

					// client doesn't use bandwidth, but it does need to reset the not ready flag here
					AllocateBandwidth(0, false);

					ConsumeLag(timeElapsedMS);

					localUser.timeSinceLastPacketReceivedMS += timeElapsedMS;

					// send keepalive
					if (localUser.validated == true)
					{
						if (sendKeepalive == true)
						{
							NetworkSimplePacket keepAlivePacket;
							GameNetworkPacketHelper::PopulateKeepAlivePacket(keepAlivePacket);
							localUser.socket.SendNow((char *)&keepAlivePacket, keepAlivePacket.length, 0);

							if (verboseEventReporting == true)
								OnKeepaliveSent();
						}
					}

					// interpret all packets from server (including routing to implementation), and send next guaranteed packets and normal packets to send when confirmation received, put in line behind delayed
					// reject connection on huge packet length
					// validate packets, report error on bad ones
					// respond to wakeups from server
					// force disconnect if that packet received without responding to server
					ProcessPacketsFromServer();

					if (localUser.validated == false) // if still not validated, handle UDP login sending if needed
					{
						if (UsesUDP() == true)
						{
							// send out appropriate negotiation packets
							if (localUser.UDPLoginToServerRequired() == true)
							{
								// need to send login packet until we get a server UDP validated packet
								timeSinceUDPLoginSentMS += timeElapsedMS;
								if (timeSinceUDPLoginSentMS >= 500)
								{
									timeSinceUDPLoginSentMS = 0;

									// send another login until server gets it and returns a udp test
									NetworkUDPLoginPacket udpLoginPacket;
									GameNetworkPacketHelper::PopulateUDPLoginPacket(udpLoginPacket, localUser.id);

									SendToServerUDP((char *)&udpLoginPacket, udpLoginPacket.length, 0);
								}
							}
						}
					}
					
					// handle timeouts, disconnect for host max timeouts.  no notifications to others for this
					// let not yet validated client track host timing out, but only send a keepalive if validated
					if (localUser.timeSinceLastPacketReceivedMS > timeOutDelayMS)
					{
						localUser.timeOutQty++;
						localUser.timeSinceLastPacketReceivedMS = 0;

						if (localUser.timeOutQty < maxTimeOutQty)
						{
							// 1 timeout

							// echo locally
							OnServerTimingOut(localUser.timeOutQty, maxTimeOutQty);

							if (localUser.validated == true)
							{
								// send wakeup
								NetworkSimplePacket keepAlivePacket;
								GameNetworkPacketHelper::PopulateWakeupPacket(keepAlivePacket);
								localUser.socket.SendNow((char *)&keepAlivePacket, keepAlivePacket.length, 0);
								if (verboseEventReporting == true)
									OnWakeupSent();
							}
						}
						else
						{
							// too many timeouts
							// echo locally
							OnServerTimingOut(localUser.timeOutQty, maxTimeOutQty);
							OnServerTimedOut();

							// disconnect client
							Disconnect("Server Timed Out", false); // echo reason locally
						}
					}

					// process waiting packets without any concern for bandwidth

					localUser.socket.SendLagPackets();

					// increase time since sent on guarnateed packets
					localUser.socket.AddTimeElapsedToGuaranteedSentPackets(timeElapsedMS);

					bool anyPacketsSent = false;
					SendWaitingPackets(localUser.socket, nullptr, anyPacketsSent, true);

					// evaluate percent of packets remaining for easy display, and tag if there are any delayed
					ProcessWaitingPackets();
					ProcessPeakDataRates();
				}
			}

		private:

			void ProcessPeakDataRates()
			{
				float uploadRate = GetImmedateUploadDataRate();
				if (uploadRate > peakUploadDataRate)
					peakUploadDataRate = uploadRate;

				float downloadRate = GetImmedateDownloadDataRate();
				if (downloadRate > peakDownloadDataRate)
					peakDownloadDataRate = downloadRate;
			}

			void LookForConnections(int p_elapsedTimeMS)
			{
				// elapsed time is just for allocation bandwidth nodes when a new client connects

				// listen!
				sockaddr_in		saClientAddress;
				int				iClientSize = sizeof(sockaddr_in);

				bool done = false;

				while (done == false)
				{
					// Note: Created sockets here have the same attributes as this listening
					//  socket (non-blocking, etc.)
					// Keeps set as INVALID_SOCKET if there is no incoming connection
					GameNetworkSocket incomingSocket;
					incomingSocket.sk =
						accept(serverListeningSocket.sk, (struct sockaddr *)&saClientAddress, &iClientSize);

					if (incomingSocket.sk != INVALID_SOCKET)
					{
						// Set the socket to linger so that outgoing packet sends will complete before the socket closes
						struct linger st_linger = { 1, 3 };
						setsockopt(incomingSocket.sk, SOL_SOCKET, SO_LINGER, (char *)&st_linger, sizeof(st_linger));

						// do we have a free slot available?  If not, can't connect
						GameNetworkClient *availableClient = GetAvailableClientSlot();
						if (availableClient == nullptr)
						{
							// send a rejection to the connection and close it now
							NetworkDisconnectPacket disconnectPacket;
							GameNetworkPacketHelper::PopulateDisconnectPacket(disconnectPacket, "Server full");
							if (incomingSocket.ReadyForWriting(1000) == true)
							{
								send(incomingSocket.sk, (char *)&disconnectPacket, disconnectPacket.length, 0);
							}
							// close, with linger from above
							incomingSocket.Close();

							OnClientRejectedNoAvailableSlot();
						}
						else
						{
							availableClient->status = NetworkClientStatus::Pending;
							availableClient->socket.AddElapsedTime(p_elapsedTimeMS); // provide bandwidth tracking ndoes
							// copy over socket along with its linger aspect
							availableClient->socket.sk = incomingSocket.sk;
							incomingSocket.sk = INVALID_SOCKET; // yeah, you're not losing scope on me and destroying yourself, nice try

							// store ip address so that there is a verification process when client sends a login request into the udp socket
							// inet_ntop() is not available.  This works, though
							strcpy_s(availableClient->ipAddress, 256, inet_ntoa(saClientAddress.sin_addr));

							OnClientConnect(GetNotConnectedClientCount(), clientQty);

							// tell client we need login info
							NetworkSimplePacket sendLoginPacket;
							GameNetworkPacketHelper::PopulateSendLoginInfoPacket(sendLoginPacket);
							availableClient->socket.SendNow((char *)&sendLoginPacket, sendLoginPacket.length, 0);
						}
					}
					else
						done = true; // no connections waiting
				}
			}

			GameNetworkClient * GetAvailableClientSlot()
			{
				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].status == NetworkClientStatus::NotConnected)
						return &clients[i];
				}

				return nullptr;
			}

			void ProcessUDPPacketsFromClients()
			{
				bool done = false;
				// NEVER support more than this in size, EVER.  Hacker could be sending a huge packet
				char udpIncomingBuffer[INCOMING_PACKET_MAX_SIZE];
				while (done == false)
				{
					// return false if nothing to read
					if (udpSocket.ReadyForReading() == false)
						break;

					sockaddr_in inAddress;
					int structLen = sizeof(sockaddr_in);
					// returns -1 if nothing to read
					int length = recvfrom(udpSocket.sk, udpIncomingBuffer, INCOMING_PACKET_MAX_SIZE, 0, (sockaddr *)&inAddress, &structLen);
					if (length <= 0)
					{
						int error = WSAGetLastError();
						break; // nothing to pull off
					}
					else
					{
						GameNetworkClient *client = nullptr;

						// todo: find client this packet's source address is a match for
						// it might be a login request to establish communication from server to client through firewall
						// otherwise if no match...  report a verbose error
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].id != -1 && clients[i].status != NetworkClientStatus::NotConnected)
							{
								if (memcmp(&clients[i].udpAddress, &inAddress, sizeof(sockaddr_in)) == 0)
								{
									client = &clients[i];
									client->socket.bandwidthTrackingReceived.ApplyDataBytes(length);
									break;
								}
							}
						}

						// so, what do we have in the packet...

						if (GameNetworkPacketHelper::GetPacketLength(&udpIncomingBuffer[0]) != length)
						{
							// don't panic, might just be corrupted, still, we can't use it
							if (verboseEventReporting == true)
							{
								if (client != nullptr)
									OnBadClientPacketReceived(*client, "Length on UDP packet does not match bytes pulled from buffer - packet ignored");
								else
									OnBadUDPPacketReceived("Length on UDP packet does not match bytes pulled from buffer - packet ignored");
							}
						}
						else
						{
							// doesn't seem corrupted.  Is it a hash packet?
							if (GameNetworkPacketHelper::GetCleanPacketType(udpIncomingBuffer) == NetworkPacketTypes::HashedPacket)
							{
								// still seems good.
								NetworkHashedPacket *packet = (NetworkHashedPacket *)&udpIncomingBuffer[0];
								char *internalPacket = &(packet->hashedPacket[0]);
								int internalPacketLength = GameNetworkPacketHelper::GetPacketLength(internalPacket);
								if (internalPacketLength == length - 12)
								{
									if (CalculatePacketHash(internalPacket, internalPacketLength) == packet->hash)
									{
										// looks good and uncorrupted.  process it!
										if (client != nullptr)
										{
											ProcessPacketServer(internalPacket, *client);

											// todo: stuff into lag list if simulating lag.
										}
										// it should be a UDP login if we don't have a client yet, so process it here.
										// verify length, get client ID, verify
										else if (GameNetworkPacketHelper::GetCleanPacketType(internalPacket) == NetworkPacketTypes::UDPLogin)
										{
											if (ValidatePacket(internalPacket) == false)
											{
												OnBadUDPPacketReceived("UDP Login packet from pending client is invalid");
											}
											else
											{
												// note: if this is a duplicate packet, we wouldn't be here since we would have gotten a client match on address earlier

												NetworkUDPLoginPacket *packet = (NetworkUDPLoginPacket *)internalPacket;
												client = GetClientByClientId(packet->id);
												// if any of these errors occurred and the client hasn't disconnected, assume the packet is from an untrusted source
												if (client == nullptr)
												{
													if (verboseEventReporting == true)
														OnBadUDPPacketReceived(String::Format("UDP Login packet client ID {0} not found!", packet->id));
												}
												else if (client->status != NetworkClientStatus::Pending)
												{
													if (verboseEventReporting == true)
														OnBadUDPPacketReceived("UDP Login packet has ID of a client that is already validated!");
												}
												else if (client->UDPLoginFromClientRequired() == false)
												{
													if (verboseEventReporting == true)
														OnBadUDPPacketReceived("UDP Login packet has ID of a client that already sent UDP login!");
												}
												else if (strcmp(client->ipAddress, inet_ntoa(inAddress.sin_addr)) != 0)
												{
													OnBadUDPPacketReceived("UDP Login source IP address does not match identified client's IP address!");
												}
												else
												{
													// all good - ready to send YouAreValidated along UDP and wait for confirmation from client to finish negotiation
													CopyMemory(&(client->udpAddress), &inAddress, sizeof(sockaddr_in));
													client->waitingForUDPLogin = false;
													client->timeSinceUDPValidationSentMS = 0;
													// Process() loop will now send out a server UDP test to client via UDP, awaiting client confirmation via TCP.
												}
											}
										}
										else
										{
											// valid concern, since no other packet should be arriving when client == nullptr
											if (verboseEventReporting == true)
												OnBadUDPPacketReceived("UDP packet received by unconfirmed client is not a login packet");
										}
									}
									else
									{
										// We can't use packets that fail the hash test.  Anything could be bad and disrupt the gamestate or worse
										if (verboseEventReporting == true)
										{
											if (client != nullptr)
												OnBadClientPacketReceived(*client, "Hashed UDP packet failed hash test - possible corruption - packet ignored");
											else
												OnBadUDPPacketReceived("Hashed UDP packet failed hash test - possible corruption - packet ignored");
										}
									}
								}
								else
								{
									// We can't use packets that have a corrupted length.  Anything could be bad and disrupt the gamestate or worse
									if (verboseEventReporting == true)
									{
										if (client != nullptr)
											OnBadClientPacketReceived(*client, "Length on UDP hash packet does not accommodate indicated length of internal packet - packet ignored");
										else
											OnBadUDPPacketReceived("Length on UDP hash packet does not accommodate indicated length of internal packet - packet ignored");
									}
								}
							}
							else
							{
								// if not a hashed packet, don't bother - we hash ALL udp packets to prevent/detect corruption
								if (verboseEventReporting == true)
								{
									if (client != nullptr)
										OnBadClientPacketReceived(*client, "UDP packet was not hashed - ignored");
									else
										OnBadUDPPacketReceived("UDP packet was not hashed - ignored");
								}
							}
						}
					}
				}
			}

			// send storage to copy packet to after it is received
			// todo: handle bad packet (number of bytes in first 4 bytes is very large
			void ProcessPacketsFromClient(GameNetworkClient &p_client) // modify sent bytes to receive, changes it to bytes not received but still done
			{
				char packet[INCOMING_PACKET_MAX_SIZE]; // incoming packet

				int timeElapsedMS = networkTimer.GetElapsedTimeMS();

				// process lag packets
				GameNetworkPacket *lagPacket = p_client.socket.incomingLagPackets.GetFirstPacket();
				while (lagPacket != nullptr)
				{
					if (lagPacket->lagToConsumeMS <= 0)
					{
						ProcessPacketServer(&(lagPacket->packet[0]), p_client);

						// if client was kicked out, we're done here
						if (p_client.status == NetworkClientStatus::NotConnected)
							return;

						p_client.socket.incomingLagPackets.RemoveFrontPacket();
						lagPacket = p_client.socket.incomingLagPackets.GetFirstPacket();
					}
					else
						break;
				}

				bool done = false;
				while (done == false)
				{
					if (p_client.socket.ReadyForReading() == false)
						break;

					int bytesToReceive = INCOMING_PACKET_STORAGE_SIZE - p_client.socket.bytesReceived;
					int received = recv(p_client.socket.sk, &p_client.socket.incomingPacket[p_client.socket.bytesReceived], bytesToReceive, 0);
					if (received == SOCKET_ERROR)
					{
						// there was a problem.
						// ?? how to handle this? need to return something so that GameNetworkBase can respond
						done = true;
					}
					else if (received == 0)
					{
						done = true;
					}
					else
					{
						p_client.socket.bytesReceived += received;
						p_client.socket.bandwidthTrackingReceived.ApplyDataBytes(received);

						bool packetDone = false;
						while (p_client.socket.bytesReceived >= 4 && packetDone == false)
						{
							unsigned int packetLength = *((unsigned int *)(&p_client.socket.incomingPacket[0]));
							if (packetLength > INCOMING_PACKET_MAX_SIZE)
							{
								// SEVERE problem - packet is too large - should we eject the connection?  Probably.

								OnBadClientPacketReceived(p_client, "Dangerous packet length received");

								DisconnectClient(&p_client, "Suspect packet received", true, true);
								return;
							}
							if (p_client.socket.bytesReceived >= packetLength)
							{
								// copy incoming to temp packet for processing
								CopyMemory(&packet[0], &p_client.socket.incomingPacket[0], packetLength);
								p_client.socket.bytesReceived -= packetLength;
								// move remaining packets to beginning of incoming
								CopyMemory(&p_client.socket.incomingPacket[0], &p_client.socket.incomingPacket[packetLength], p_client.socket.bytesReceived);
								// todo: check hash for tampering?

								if (p_client.socket.GetSimulatedLag() > timeElapsedMS || p_client.socket.incomingLagPackets.IsEmpty() == false)
								{
									p_client.socket.incomingLagPackets.AddLagPacket(&packet[0], 0, GameNetworkPacketSendType::None, p_client.socket.GetSimulatedLag() - timeElapsedMS);
								}
								else
								{
									ProcessPacketServer(&packet[0], p_client);

									// if client was kicked out, we're done here
									if (p_client.status == NetworkClientStatus::NotConnected)
										return;
								}
							}
							else
								packetDone = true; // not enough bytes to copy next packet - it isn't all received yet
						}
					}
				}
			}

			void ProcessPacketsFromServer() // modify sent bytes to receive, changes it to bytes not received but still done
			{
				char packet[INCOMING_PACKET_MAX_SIZE]; // incoming packet

				int timeElapsedMS = networkTimer.GetElapsedTimeMS();

				// process lag packets
				GameNetworkPacket *lagPacket = localUser.socket.incomingLagPackets.GetFirstPacket();
				while (lagPacket != nullptr)
				{
					if (lagPacket->lagToConsumeMS <= 0)
					{
						ProcessPacketClient(&(lagPacket->packet[0]));
						localUser.socket.incomingLagPackets.RemoveFrontPacket();
						lagPacket = localUser.socket.incomingLagPackets.GetFirstPacket();
					}
					else 
						break;
				}

				// UDP socket
				bool done = false;
				// NEVER support more than this in size, EVER.  Hacker could be sending a huge packet
				char udpIncomingBuffer[INCOMING_PACKET_MAX_SIZE];
				while (done == false)
				{
					// returns false if nothing to read
					if (udpSocket.ReadyForReading() == false)
						break;

					sockaddr_in inAddress;
					int structLen = sizeof(sockaddr_in);
					// returns -1 if nothing to read
					int length = recvfrom(udpSocket.sk, udpIncomingBuffer, INCOMING_PACKET_MAX_SIZE, 0, (sockaddr *)&inAddress, &structLen);
					if (length <= 0)
						break; // nothing to pull off
					else
					{
						// verify inAddress as coming from server (ex. hacker could be sending a disconnect message to client to get them to disconnect)
						// - should know ip address and port of server at this point since we connected to it...  so set these in Connect() and use them here.
						if (memcmp(&serverUDPAddress, &inAddress, sizeof(sockaddr_in)) == 0)
						{
							localUser.socket.bandwidthTrackingReceived.ApplyDataBytes(length);

							// so, what do we have in the packet...

							if (GameNetworkPacketHelper::GetPacketLength(&udpIncomingBuffer[0]) != length)
							{
								// don't panic, might just be corrupted, still, we can't use it
								if (verboseEventReporting == true)
									OnBadServerPacketReceived("Length on UDP server packet does not match bytes pulled from buffer - packet ignored");
							}
							else
							{
								// doesn't seem corrupted.  Is it a hash packet?
								if (GameNetworkPacketHelper::GetCleanPacketType(udpIncomingBuffer) == NetworkPacketTypes::HashedPacket)
								{
									// still seems good.
									NetworkHashedPacket *packet = (NetworkHashedPacket *)&udpIncomingBuffer[0];
									char *internalPacket = &(packet->hashedPacket[0]);
									int internalPacketLength = GameNetworkPacketHelper::GetPacketLength(internalPacket);
									if (internalPacketLength == length - 12)
									{
										if (CalculatePacketHash(internalPacket, internalPacketLength) == packet->hash)
										{
											// looks good and uncorrupted.  process it!
											ProcessPacketClient(internalPacket);

											// todo: stuff into lag list if simulating lag.
										}
										else if (verboseEventReporting == true)
											OnBadServerPacketReceived("Hashed UDP packet failed hash test - possible corruption - packet ignored");

									}
									else
									{
										if (verboseEventReporting == true)
											OnBadServerPacketReceived("Length on UDP server hash packet does not accommodate indicated length of internal packet - packet ignored");
									}
								}
								else if (verboseEventReporting == true)
								{
									// if not a hashed packet, don't bother - we hash our udp packets to prevent/detect corruption
									if (verboseEventReporting == true)
										OnBadServerPacketReceived("UDP packet was not hashed - ignored");
								}
							}
						} // udp packet is from server
					}
				}
				
				// TCP socket
				done = false;
				while (done == false)
				{
					if (localUser.socket.ReadyForReading() == false)
						break;

					int bytesToReceive = INCOMING_PACKET_STORAGE_SIZE - localUser.socket.bytesReceived;
					int received = recv(localUser.socket.sk, &localUser.socket.incomingPacket[localUser.socket.bytesReceived], bytesToReceive, 0);
					if (received == SOCKET_ERROR)
					{
						// there was a problem.
						// ?? how to handle this? need to return something so that GameNetworkBase can respond
						done = true;
					}
					else if (received == 0)
					{
						done = true;
					}
					else
					{
						localUser.socket.bytesReceived += received;
						localUser.socket.bandwidthTrackingReceived.ApplyDataBytes(received);

						bool packetDone = false;
						while (localUser.socket.bytesReceived >= 4 && packetDone == false)
						{
							unsigned int packetLength = *((unsigned int *)(&localUser.socket.incomingPacket[0]));
							if (packetLength > INCOMING_PACKET_MAX_SIZE)
							{
								// SEVERE problem - packet is too large - should we eject the connection?  Probably.

								OnBadServerPacketReceived("Dangerous packet length received from server");

								Disconnect("Suspect packet received", true);
								return;
							}
							if (localUser.socket.bytesReceived >= packetLength)
							{
								// copy incoming to temp packet for processing
								CopyMemory(&packet[0], &localUser.socket.incomingPacket[0], packetLength);
								localUser.socket.bytesReceived -= packetLength;
								// move remaining packets to beginning of incoming
								CopyMemory(&localUser.socket.incomingPacket[0], &localUser.socket.incomingPacket[packetLength], localUser.socket.bytesReceived);
								// todo: check hash for tampering?

								if (localUser.socket.GetSimulatedLag() > timeElapsedMS || localUser.socket.incomingLagPackets.IsEmpty() == false)
								{
									localUser.socket.incomingLagPackets.AddLagPacket(&packet[0], 0, GameNetworkPacketSendType::None, localUser.socket.GetSimulatedLag() - timeElapsedMS);
								}
								else
								{
									ProcessPacketClient(&packet[0]);
								}
							}
							else
								packetDone = true; // not enough bytes to copy next packet - it isn't all received yet
						}
					}
				}
			}

			void ProcessPacketServer(char *p_packet, GameNetworkClient &p_client, bool p_processingQueuePacket = false)
			{
				// register last time packet received to handle timeouts
				p_client.timeSinceLastPacketReceivedMS = 0;
				if (p_client.timeOutQty != 0)
				{
					if (p_client.status != NetworkClientStatus::Validated)
						OnPendingClientNoLongerTimingOut(p_client);
					else
						OnPlayerNoLongerTimingOut(p_client.id);
				}
				p_client.timeOutQty = 0;

				// packet came from a specific client
				if (p_client.status == NetworkClientStatus::Pending)
				{
					// should only receive LoginInfo in this status
					// if receive anything else, reject connection
					int type = GameNetworkPacketHelper::GetCleanPacketType(p_packet);
					switch (type)
					{
					case NetworkPacketTypes::LoginInfo:
						{
							if (ValidatePacket(p_packet) == false)
							{
								OnBadClientPacketReceived(p_client, "Login packet from pending client is invalid");

								DisconnectClient(&p_client, "Suspect packet received", true, false);
								return;
							}

							// handle the login
							// check guid, if they match, assign name and id and send a validation and notify all other clients
							NetworkLoginPacket *packet = (NetworkLoginPacket *)p_packet;
							if (strcmp(packet->appVersionGuid, versionGuid) == 0)
							{
								// looks good, 
								// assign id in client slot, tell client they are good, tell everyone else a client connected
								p_client.id = GetNextClientId();
								strcpy_s(p_client.name, 33, packet->userName);

								// final validation for 
								if (UsesUDP() == false)
								{
									FinalClientValidation(p_client);
								}
								else
								{
									// clear out address so that no incoming address matches it
									memset(&p_client.udpAddress, 0, sizeof(sockaddr_in));

									// give client udp kernel hash and tell client to login through udp now (send through tcp).
									// (client will respond with a login through udp, then server will respond with a test through udp, then client will respond with a success through tcp,
									//   triggering final validation
									NetworkSendUDPLoginPacket validateUDPPacket;
									GameNetworkPacketHelper::PopulateSendUDPLoginPacket(validateUDPPacket, p_client.id, kernelByteQty, saltBeginBytes, saltEndBytes, hashKernel, hashSaltBegin, hashSaltEnd);
									p_client.socket.SendNow((char *)&validateUDPPacket, validateUDPPacket.length, 0);
								}
							}
							else
							{
								// nope, reject client, tell them the correct version id (not guid) and shut down the connection
								String ^versionError = String::Format("Incorrect client app version {0}, host is running version {1}",
									GameNetworkPacketHelper::CharArrayToString(packet->appVersionString),
									GameNetworkPacketHelper::CharArrayToString(versionString));

								NetworkDisconnectPacket rejectPacket;
								GameNetworkPacketHelper::PopulateDisconnectPacket(rejectPacket, versionError);

								OnBadClientPacketReceived(p_client, versionError);

								DisconnectClient(&p_client, versionError, true, false);
								return;
							}
						}
						break;
					case NetworkPacketTypes::UDPLogin:
						{
							// if this packet type gets here, it's a duplicate.  The real login is handled in ProcessPacketsFromClient()
							if (p_client.UDPLoginFromClientRequired() == true)
							{
								throw gcnew Exception("If UDP Login still required when get here, there is a problem in the code.");

								if (ValidatePacket(p_packet) == false)
								{
									OnBadClientPacketReceived(p_client, "UDP Login packet from pending client is invalid");

									DisconnectClient(&p_client, "Suspect packet received", true, false);
									return;
								}

								NetworkUDPLoginPacket *packet = (NetworkUDPLoginPacket *)p_packet;
							}
						}
						break;
					case NetworkPacketTypes::UDPConfirmation:
					{
						if (p_client.UDPConfirmationRequired() == true)
						{
							if (ValidatePacket(p_packet) == false)
							{
								OnBadClientPacketReceived(p_client, "UDP Confirmation packet from pending client is invalid");

								DisconnectClient(&p_client, "Suspect packet received", true, false);
								return;
							}

							p_client.udpConfirmed = true;

							// Validate the client!
							FinalClientValidation(p_client);
						}
					}
					break;
					case NetworkPacketTypes::IAmDisconnecting:
					{
						// player left after connecting but before receiving validation
						// close the socket without sending a disconnect command or informing others (player isn't even validated yet, other clients don't know about him)
						OnPendingClientLeft(p_client); // treat as client leaving (if udp negotiation is occurring, we will have username info, but that doesn't really matter - this is a rare corner case)
						DisconnectClient(&p_client, "", false, false);
					}
					break;
					default:
						OnBadClientPacketReceived(p_client, "Packet from pending client is not login info, UDP login, UDP confirmation, or disconnect");

						DisconnectClient(&p_client, "Suspect packet received", true, false); // don't need to tell other players
						return;
						break;
					}
				}
				else
				{
					// any other packet is fine here

					// send guaranteed confirmation
					int confirmationId = GameNetworkPacketHelper::GetPacketConfirmationId(p_packet);
					if (confirmationId != 0)
					{
						int channel = GameNetworkPacketHelper::GetPacketChannel(p_packet);

						if (verboseEventReporting == true)
							OnGuaranteedPacketReceived(&p_client, confirmationId, channel);

						NetworkPacketConfirmationPacket packetConfirmationPacket;
						GameNetworkPacketHelper::PopulatePacketConfirmationPacket(packetConfirmationPacket, confirmationId, channel);

						p_client.socket.SendNow((char *)&packetConfirmationPacket, packetConfirmationPacket.length, 0);

						if (verboseEventReporting == true)
							OnConfirmationIdSent(&p_client, confirmationId, channel);

						// if we already handled this guaranteed packet, don't process it, just return
						if (p_client.socket.lastReceivedConfirmationId[channel] == confirmationId)
							return;
						// track the confirmation id
						p_client.socket.lastReceivedConfirmationId[channel] = confirmationId;
					}
					bool valid = true;
					if (p_processingQueuePacket == false)
						valid = ValidatePacket(p_packet);
					if (valid == false)
					{
						OnBadClientPacketReceived(p_client, String::Format("Packet contents invalid (type '{0:g}')", GameNetworkPacketHelper::GetCleanPacketType(p_packet)));
					}
					else
					{
						// process it!
						switch (GameNetworkPacketHelper::GetCleanPacketType(p_packet))
						{
						case NetworkPacketTypes::Keepalive:
						{
							// register last time packet received (already handled above)

							if (verboseEventReporting == true)
								OnKeepaliveReceived(&p_client);
						}
						break;
						case NetworkPacketTypes::Wakeup:
						{
							if (verboseEventReporting == true)
								OnWakeupReceived(&p_client);

							// send back an IAnAwake packet
							NetworkSimplePacket iAmAwakePacket;
							GameNetworkPacketHelper::PopulateIAmAwakePacket(iAmAwakePacket);
							p_client.socket.SendNow((char *)&iAmAwakePacket, iAmAwakePacket.length, 0);

							if (verboseEventReporting == true)
								OnIAmAwakeSent(&p_client);
						}
						break;
						case NetworkPacketTypes::IAmAwake:
						{
							// register last time packet received (already handled above)

							if (verboseEventReporting == true)
								OnIAmAwakeReceived(&p_client);
						}
						break;
						case NetworkPacketTypes::IAmDisconnecting:
						{
							// close the socket without sending a disconnect command
							if (p_client.status == NetworkClientStatus::Validated)
								OnPlayerLeft(p_client.id); // treat as player leaving
							else
								OnPendingClientLeft(p_client); // treat as client leaving
							DisconnectClient(&p_client, "", false, true); // tell other players
						}
						break;
						case NetworkPacketTypes::PacketConfirmation:
						{
							// handle guaranteed packet lists
							NetworkPacketConfirmationPacket *packet = (NetworkPacketConfirmationPacket *)p_packet;
							int confirmationId = packet->confirmationId;
							int channel = packet->channel;

							if (verboseEventReporting == true)
								OnConfirmationIdReceived(&p_client, confirmationId, channel);

							p_client.socket.ReceiveConfirmationId(confirmationId, channel);
						}
						break;
						case NetworkPacketTypes::QueuePacket:
						{
							NetworkQueuePacket *queuePacket = (NetworkQueuePacket *)p_packet;

							int index = 0;
							while ((index + 8) < queuePacket->length)
							{
								char *packet = &(queuePacket->packets[index]);
								ProcessPacketServer(packet, p_client, true); // don't validate
								index += GameNetworkPacketHelper::GetPacketLength(packet);
							}
						}
						break;
						default:
							CustomProcessPacketHost(&p_client, p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));
							break;
						}
					}
				}
			}

			void FinalClientValidation(GameNetworkClient &p_client)
			{
				p_client.status = NetworkClientStatus::Validated;

				if (UsesUDP() == false)
				{
					// in UDP system, this was already sent - in UDP, a client received the UDP test from the server is the validation
					NetworkYouAreValidatedPacket validatePacket;
					GameNetworkPacketHelper::PopulateYouAreValidatedPacket(validatePacket, p_client.id);
					p_client.socket.SendNow((char *)&validatePacket, validatePacket.length, 0);
				}

				GameNetworkPlayerBase *newPlayer = ServerAddPlayer(p_client, false, false); // todo: watch for joining host

				// send joining player to other players, except the new player
				SendAddPlayerPacket(newPlayer);

				// send player list to new player
				SendAddPlayerPacket(newPlayer, &p_client);

				// send gamestate information regarding player to other players, and prep for sending gamestate down to the new player (either now or trigger further negotiation)
				OnPlayerJoined(newPlayer->id);
			}

			int GetNextClientId()
			{
				bool done = false;
				while (done == false)
				{
					nextClientId++;
					if (nextClientId < 0)
						nextClientId = 0;

					if (server == true && nextClientId == localUser.id)
						continue;

					for (int i = 0; i < clientQty; i++)
					{
						if (clients[i].status == NetworkClientStatus::Validated && clients[i].id == nextClientId)
							continue;
					}

					done = true;
				}

				return nextClientId;
			}

			int GetNotConnectedClientCount()
			{
				int count = 0;
				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].status == NetworkClientStatus::NotConnected)
						count++;
				}
				return count;
			}

			void ProcessPacketClient(char *p_packet, bool p_processingQueuePacket = false)
			{
				// packet clearly came from server socket

				// register last time packet received to handle timeouts
				localUser.timeSinceLastPacketReceivedMS = 0;
				if (localUser.timeOutQty != 0)
					OnServerNoLongerTimingOut();
				localUser.timeOutQty = 0;

				bool valid = true;
				if (p_processingQueuePacket == false)
					valid = ValidatePacket(p_packet);
				if (valid == false)
				{
					OnBadServerPacketReceived(String::Format("Packet contents invalid (type '{0:g}')", GameNetworkPacketHelper::GetCleanPacketType(p_packet)));
				}
				else
				{
					if (localUser.validated == false)
					{
						// can only receive request for login info and a forced disconnect
						switch (GameNetworkPacketHelper::GetCleanPacketType(p_packet))
						{
						case NetworkPacketTypes::SendLoginInfo:
						{
							NetworkLoginPacket loginPacket;
							GameNetworkPacketHelper::PopulateLoginPacket(loginPacket, localUser.name, versionString, versionGuid);
							localUser.socket.Send((char *)&loginPacket, loginPacket.length, 0);
						}
						break;
						case NetworkPacketTypes::Disconnect:
						{
							NetworkDisconnectPacket *packet = (NetworkDisconnectPacket *)p_packet;

							// command from server to disconnect - messages will be sent to other clients by server
							// no need to tell server
							Disconnect(GameNetworkPacketHelper::CharArrayToString(packet->reason), false);
						}
						break;
						case NetworkPacketTypes::YouAreValidated:
						{
							NetworkYouAreValidatedPacket *packet = (NetworkYouAreValidatedPacket *)p_packet;

							if (UsesUDP() == true)
							{
								// UDP system
								if (localUser.id == packet->id) // was already set from SendUDPLogin, so just checking here
								{
									if (localUser.validated == false)
									{
										localUser.validated = true;

										// send confirmation to server via TCP
										NetworkUDPConfirmationPacket confirmationPacket;
										GameNetworkPacketHelper::PopulateUDPConfirmationPacket(confirmationPacket);
										SendToServer((char *)&confirmationPacket, confirmationPacket.length, 0);
									}
								}
							}
							else
							{
								// TCP only system

								// accept id from server
								localUser.id = packet->id;
								localUser.validated = true;
							}

							// welcome message comes from Joined() event when called
						}
						break;
						case NetworkPacketTypes::SendUDPLogin:
						{
							NetworkSendUDPLoginPacket *packet = (NetworkSendUDPLoginPacket *)p_packet;

							// accept id from server
							localUser.id = packet->id;

							// welcome message comes from Joined() event when called

							kernelByteQty = packet->kernelByteQty;
							saltBeginBytes = packet->saltBeginByteQty;
							saltEndBytes = packet->saltEndByteQty;
							CopyMemory(hashKernel, packet->hashKernel, UDP_HASH_KERNEL_SIZE);
							CopyMemory(hashSaltBegin, packet->saltBegin, UDP_HASH_SALT_SIZE);
							CopyMemory(hashSaltEnd, packet->saltEnd, UDP_HASH_SALT_SIZE);

							// This is a trigger to start sending the UDP login to the server.
						}
						break;
						default:
							// ?? error!  received a bad packet!  Should only receive what's above!
							// todo: notify bad packet type
							break;
						}
					}
					else
					{
						// send guaranteed confirmation
						int confirmationId = GameNetworkPacketHelper::GetPacketConfirmationId(p_packet);
						if (confirmationId != 0)
						{
							int channel = GameNetworkPacketHelper::GetPacketChannel(p_packet);

							if (verboseEventReporting == true)
								OnGuaranteedPacketReceived(nullptr, confirmationId, channel);

							NetworkPacketConfirmationPacket packetConfirmationPacket;
							GameNetworkPacketHelper::PopulatePacketConfirmationPacket(packetConfirmationPacket, confirmationId, channel);

							localUser.socket.SendNow((char *)&packetConfirmationPacket, packetConfirmationPacket.length, 0);

							if (verboseEventReporting == true)
								OnConfirmationIdSent(nullptr, confirmationId, channel);

							// if we already handled this guaranteed packet, don't process it, just return
							if (localUser.socket.lastReceivedConfirmationId[channel] == confirmationId)
								return;
							// track the confirmation id
							localUser.socket.lastReceivedConfirmationId[channel] = confirmationId;
						}

						// process it!
						switch (GameNetworkPacketHelper::GetCleanPacketType(p_packet))
						{
						case NetworkPacketTypes::YouAreValidated:
						{
							// thsi would be received on multiple UDP sends from the server in an attempt to confirm udp communication with the client.
							// so this isn't an error - just ignore it.
						}
						break;
						case NetworkPacketTypes::Keepalive:
						{
							// register last time packet received (already handled above)

							if (verboseEventReporting == true)
								OnKeepaliveReceived();
						}
						break;
						case NetworkPacketTypes::Wakeup:
						{
							if (verboseEventReporting == true)
								OnWakeupReceived();

							// send back an IAnAwake packet
							NetworkSimplePacket iAmAwakepacket;
							GameNetworkPacketHelper::PopulateIAmAwakePacket(iAmAwakepacket);
							localUser.socket.SendNow((char *)&iAmAwakepacket, iAmAwakepacket.length, 0);

							if (verboseEventReporting == true)
								OnIAmAwakeSent();
						}
						break;
						case NetworkPacketTypes::IAmAwake:
						{
							// register last time packet received (already handled above)

							if (verboseEventReporting == true)
								OnIAmAwakeReceived();
						}
						break;
						case NetworkPacketTypes::PacketConfirmation:
						{
							// handle guaranteed packet lists
							NetworkPacketConfirmationPacket *packetConfirmation = (NetworkPacketConfirmationPacket *)p_packet;
							int confirmationId = packetConfirmation->confirmationId;
							int channel = packetConfirmation->channel;

							if (verboseEventReporting == true)
								OnConfirmationIdReceived(nullptr, confirmationId, channel);

							localUser.socket.ReceiveConfirmationId(confirmationId, channel);
						}
						break;
						case NetworkPacketTypes::AddPlayer:
						{
							NetworkAddPlayerPacketBase *packet = (NetworkAddPlayerPacketBase *)p_packet;
							ClientAddPlayer(packet); // virtual override
							if (packet->echo == true)
								OnPlayerJoined(packet->id); // virtual override
							if (packet->id == GetLocalUserId())
								OnJoined(); // local player is validated and has a record!  Welcome message?  If server has to determine a specific one, send from OnPlayerJoined
						}
						break;
						case NetworkPacketTypes::PlayerLeft:
						{
							int id = ((NetworkPlayerLeftPacket *)p_packet)->id;
							OnPlayerLeft(id);
							players.RemovePlayer(id);
						}
						break;
						case NetworkPacketTypes::PlayerTimingOut:
						{
							NetworkPlayerTimingOutPacket *packet = (NetworkPlayerTimingOutPacket *)p_packet;
							OnPlayerTimingOut(packet->id, packet->timeOutQty, packet->maxTimeOutQty);
						}
						break;
						case NetworkPacketTypes::PlayerTimedOut:
						{
							int id = ((NetworkPlayerTimedOutPacket *)p_packet)->id;
							OnPlayerTimedOut(id);
						}
						break;
						case NetworkPacketTypes::PlayerNoLongerTimingOut:
						{
							int id = ((NetworkPlayerNoLongerTimingOutPacket *)p_packet)->id;
							OnPlayerNoLongerTimingOut(id);
						}
						break;
						case NetworkPacketTypes::Disconnect:
						{
							NetworkDisconnectPacket *packet = (NetworkDisconnectPacket *)p_packet;

							// command from server to disconnect - messages will be sent to other clients by server
							// no need to tell server
							Disconnect(GameNetworkPacketHelper::CharArrayToString(packet->reason), false);
						}
						break;
						case NetworkPacketTypes::Message:
						{
							NetworkMessagePacket *packet = (NetworkMessagePacket *)p_packet;

							NetworkMessage(GameNetworkMessageType::Info, String::Format("* {0}", GameNetworkPacketHelper::CharArrayToString(packet->message)));
						}
						break;
						case NetworkPacketTypes::QueuePacket:
						{
							NetworkQueuePacket *queuePacket = (NetworkQueuePacket *)p_packet;

							int index = 0;
							while ((index + 8) < queuePacket->length)
							{
								char *packet = &(queuePacket->packets[index]);
								ProcessPacketClient(packet, true);  // don't validate
								index += GameNetworkPacketHelper::GetPacketLength(packet);
							}
						}
						break;
						default:
							CustomProcessPacketPlayer(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));
							// todo: notify bad packet type
							break;
						}
					}
				}
			}

		public:
			String^ GetLocalIP()
			{
				// WSAStartup() must be called before this routine for it to work.
				// It is possible to have multiple candidate ports - this routine only returns the first one, for now, for simplicity

				// Determines most likely candidate for local network card
				char ac[80];
				if (gethostname(ac, sizeof(ac)) == SOCKET_ERROR)
				{
					return "(Error getting local host name)";
				}

				struct hostent *phe = gethostbyname(ac);
				if (phe == 0)
				{
					return "(Bad host lookup)";
				}
				char address[400];
				String ^localIPResult = "(Unknown)";
				for (int i = 0; phe->h_addr_list[i] != 0; ++i)
				{
					struct in_addr addr;
					memcpy(&addr, phe->h_addr_list[i], sizeof(struct in_addr));
					strcpy_s(address, 400, inet_ntoa(addr));
					if (!strcmp(address, "127.0.0.1"))
						continue;
					if (address[0] >= '0' && address[0] <= '9')
					{
						if (localIPResult == "(Unknown)")
						{
							localIPResult = gcnew String(inet_ntoa(addr));
							// return now rather than return multiple addresses
							return localIPResult;
						}
						else
						{
							localIPResult = localIPResult + ", ";
							localIPResult = localIPResult + gcnew String(inet_ntoa(addr));
						}
					}
				}

				return localIPResult;
			}

			float GetPeakUploadDataRate()
			{
				return peakUploadDataRate;
			}

			void ResetPeakUploadDataRate()
			{
				peakUploadDataRate = 0.0f;
			}

			float GetPeakDownloadDataRate()
			{
				return peakDownloadDataRate;
			}

			void ResetPeakDownloadDataRate()
			{
				peakDownloadDataRate = 0.0f;
			}

			float GetSustainedUploadDataRate()
			{
				float uploadDataRate = 0.0f;

				if (active == true)
				{
					if (server == false)
						uploadDataRate += localUser.socket.bandwidthTrackingSent.GetSustainedDataRate();
					else
					{
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].IsConnected() == true)
								uploadDataRate += clients[i].socket.bandwidthTrackingSent.GetSustainedDataRate();
						}
					}
				}

				return uploadDataRate;
			}

			float GetSustainedDownloadDataRate()
			{
				float downloadDataRate = 0.0f;

				if (active == true)
				{
					if (server == false)
						downloadDataRate += localUser.socket.bandwidthTrackingReceived.GetSustainedDataRate();
					else
					{
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].IsConnected() == true)
								downloadDataRate += clients[i].socket.bandwidthTrackingReceived.GetSustainedDataRate();
						}
					}
				}

				return downloadDataRate;
			}

			float GetImmedateUploadDataRate()
			{
				float uploadDataRate = 0.0f;

				if (active == true)
				{
					if (server == false)
						uploadDataRate += localUser.socket.bandwidthTrackingSent.GetImmediateDataRate();
					else
					{
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].IsConnected() == true)
								uploadDataRate += clients[i].socket.bandwidthTrackingSent.GetImmediateDataRate();
						}
					}
				}

				return uploadDataRate;
			}

			float GetImmedateDownloadDataRate()
			{
				float downloadDataRate = 0.0f;

				if (active == true)
				{
					if (server == false)
						downloadDataRate += localUser.socket.bandwidthTrackingReceived.GetImmediateDataRate();
					else
					{
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].IsConnected() == true)
								downloadDataRate += clients[i].socket.bandwidthTrackingReceived.GetImmediateDataRate();
						}
					}
				}

				return downloadDataRate;
			}

			void ResetDataRateCollection()
			{
				if (active == true)
				{
					if (server == false)
					{
						localUser.socket.bandwidthTrackingSent.Reset();
						localUser.socket.bandwidthTrackingReceived.Reset();
					}
					else
					{
						for (int i = 0; i < clientQty; i++)
						{
							if (clients[i].IsConnected() == true)
							{
								clients[i].socket.bandwidthTrackingSent.Reset();
								clients[i].socket.bandwidthTrackingReceived.Reset();
							}
						}
					}
				}

				ResetPeakUploadDataRate();
				ResetPeakDownloadDataRate();
			}

			void DisconnectClient(GameNetworkClient *p_client, String ^p_reason, bool p_sendDisconnectMessage = true, bool p_tellAllClients = true)
			{
				if (IsClient())
					throw gcnew Exception("Cannot disconnect a client on a client instance!");

				// p_sendDisconnectMessage only needed if client has not disconnected themselves and sent a message
				// p_tellAllClients only needed if other clients need to know client has disconnected

				if (p_client->socket.IsOpen())
				{
					if (p_sendDisconnectMessage == true)
					{
						p_client->socket.notReady = false; // reset condition to allow a packet to leave, just in case

						// give linger a chance to work
						p_client->socket.SetLinger(4);
						p_client->socket.MakeBlocking(true);

						// send a forced disconnect to the client (maybe not if timed out) with linger (sendnow)
						NetworkDisconnectPacket disconnectPacket;
						GameNetworkPacketHelper::PopulateDisconnectPacket(disconnectPacket, p_reason);
						p_client->socket.SendCritical((char *)&disconnectPacket, disconnectPacket.length, 0, 1000);
					}

					if (p_tellAllClients == true && p_client->status == NetworkClientStatus::Validated)
					{
						// tell everyone else client has disconnected
						NetworkPlayerLeftPacket messagePacket;
						GameNetworkPacketHelper::PopulatePlayerLeftPacket(messagePacket, p_client->id);
						SendToAllClientsNow((char *)&messagePacket, messagePacket.length, 0, p_client->id);
					}

					// close it, reset data
					p_client->socket.Close();

					// we told clients player left, we might as well act like they left normally
					OnPlayerLeft(p_client->id, false);

					// maintain local player list
					players.RemovePlayer(p_client->id);

					// reset client data
					p_client->Reset();
				}
			}

			void SendToAllClientsGuaranteed(char *p_packet, int p_length, int p_flags, int p_channel, int p_excludeClientId = -1)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to a client on a client instance!");

				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].status == NetworkClientStatus::Validated && clients[i].id != p_excludeClientId)
					{
						clients[i].socket.SendGuaranteed(p_packet, p_length, p_flags, p_channel);
					}
				}
			}

			void SendToAllClients(char *p_packet, int p_length, int p_flags, int p_channel = 0, int p_excludeClientId = -1)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to a client on a client instance!");

				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].status == NetworkClientStatus::Validated && clients[i].id != p_excludeClientId)
					{
						clients[i].socket.Send(p_packet, p_length, p_flags, p_channel);
					}
				}
			}

			void SendToAllClientsNow(char *p_packet, int p_length, int p_flags, int p_excludeClientId = -1)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to a client on a client instance!");

				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].status == NetworkClientStatus::Validated && clients[i].id != p_excludeClientId)
					{
						clients[i].socket.SendNow(p_packet, p_length, p_flags);
					}
				}
			}

			void SendToAllClientsUDP(char *p_packet, int p_length, int p_flags, int p_excludeClientId = -1)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to client on the client instance!");

				if (UsesUDP() == false)
					throw gcnew Exception("UDP was not established in Host()!");

				NetworkHashedPacket hashPacket;
				int length = GameNetworkPacketHelper::GetPacketLength(p_packet);
				// clean off confirmation id and channel
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));
				GameNetworkPacketHelper::PopulateHashedPacket(hashPacket, p_packet, CalculatePacketHash(p_packet, length));

				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].status == NetworkClientStatus::Validated && clients[i].id != p_excludeClientId && clients[i].udpConfirmed == true)
					{
						int sent = udpSocket.SendUDP((char *)&hashPacket, hashPacket.length, p_flags, (sockaddr *)&(clients[i].udpAddress));
						clients[i].socket.bandwidthTrackingSent.ApplyDataBytes(sent);
					}
				}
			}


			void SendToClientGuaranteed(GameNetworkClient *p_client, char *p_packet, int p_length, int p_flags, int p_channel)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to a client on a client instance!");

				p_client->socket.SendGuaranteed(p_packet, p_length, p_flags, p_channel);
			}

			void SendToClient(GameNetworkClient *p_client, char *p_packet, int p_length, int p_flags, int p_channel = 0)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to a client on a client instance!");

				p_client->socket.Send(p_packet, p_length, p_flags, p_channel);
			}

			void SendToClientNow(GameNetworkClient *p_client, char *p_packet, int p_length, int p_flags)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to a client on a client instance!");

				p_client->socket.SendNow(p_packet, p_length, p_flags);
			}

			void SendToClientUDP(GameNetworkClient *p_client, char *p_packet, int p_length, int p_flags)
			{
				if (IsClient())
					throw gcnew Exception("Cannot send to client on the client instance!");

				if (UsesUDP() == false)
					throw gcnew Exception("UDP was not established in Host()!");

				if (p_client->waitingForUDPLogin == true)
					throw gcnew Exception("Client hasn't logged into UDP yet!");

				NetworkHashedPacket hashPacket;
				int length = GameNetworkPacketHelper::GetPacketLength(p_packet);
				// clean off confirmation id and channel
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));
				GameNetworkPacketHelper::PopulateHashedPacket(hashPacket, p_packet, CalculatePacketHash(p_packet, length));

				int sent = udpSocket.SendUDP((char *)&hashPacket, hashPacket.length, p_flags, (sockaddr *)&(p_client->udpAddress));
				p_client->socket.bandwidthTrackingSent.ApplyDataBytes(sent);
			}

			// client sends
			void SendToServer(char *p_packet, int p_length, int p_flags, int p_channel = 0)
			{
				if (IsServer())
					throw gcnew Exception("Cannot send to server on the server instance!");

				localUser.socket.Send(p_packet, p_length, p_flags, p_channel);
			}

			void SendToServerNow(char *p_packet, int p_length, int p_flags)
			{
				if (IsServer())
					throw gcnew Exception("Cannot send to server on the server instance!");

				localUser.socket.SendNow(p_packet, p_length, p_flags);
			}

			void SendToServerGuaranteed(char *p_packet, int p_length, int p_flags, int p_channel)
			{
				if (IsServer())
					throw gcnew Exception("Cannot send to server on the server instance!");

				localUser.socket.SendGuaranteed(p_packet, p_length, p_flags, p_channel);
			}

			void SendToServerUDP(char *p_packet, int p_length, int p_flags)
			{
				if (IsServer())
					throw gcnew Exception("Cannot send to server on the server instance!");

				if (UsesUDP() == false)
					throw gcnew Exception("UDP was not established in Connect()!");

				NetworkHashedPacket hashPacket;
				int length = GameNetworkPacketHelper::GetPacketLength(p_packet);
				// clean off confirmation id and channel
				GameNetworkPacketHelper::SetPacketType(p_packet, GameNetworkPacketHelper::GetCleanPacketType(p_packet));
				GameNetworkPacketHelper::PopulateHashedPacket(hashPacket, p_packet, CalculatePacketHash(p_packet, length));

				int sent = udpSocket.SendUDP((char *)&hashPacket, hashPacket.length, p_flags, (sockaddr *)&serverUDPAddress);
				localUser.socket.bandwidthTrackingSent.ApplyDataBytes(sent);
			}

			// this version is called from the outside
			void Disconnect()
			{
				if (active == true)
				{
					if (server == true)
					{
						// server disconnecting
						Disconnect("Normal disconnect", true, "Server closed session");
					}
					else
					{
						// client disconnecting
						Disconnect("Normal disconnect", true);
					}
				}
			}

		private:
			void ProcessWaitingPackets()
			{
				if (server == true)
				{
					for (int i = 0; i < clientQty; i++)
					{
						if (clients[i].status != NetworkClientStatus::NotConnected)
							clients[i].socket.ProcessWaitingPackets();
					}
				}
				else
				{
					localUser.socket.ProcessWaitingPackets();
				}
			}

		public:
			float GetClientPacketsProgress(bool &p_socketNotReady, int p_index = -1)
			{
				// p_index is meaningless if process is client
				// todo: not ture if proxy hosting and multichannel guaranteed is supported

				if (p_index >= 0 && server == true)
				{
					return clients[p_index].socket.GetPacketsProgess(p_socketNotReady);
				}
				else if (server == false)
				{
					return localUser.socket.GetPacketsProgess(p_socketNotReady);
				}

				return 0.0;
			}

			float GetClientPeakUploadDataRate(int p_index = -1)
			{
				if (p_index >= 0 && server == true)
				{
					return clients[p_index].socket.bandwidthTrackingSent.GetPeakDataRate();
				}
				else if (server == false)
				{
					return localUser.socket.bandwidthTrackingSent.GetPeakDataRate();
				}

				return 0.0;
			}

			GameNetworkClient * GetClientByIndex(int p_index)
			{
				if (p_index < 0)
					throw gcnew Exception("Index must be >= 0");
				if (p_index >= clientQty)
					throw gcnew Exception(String::Format("Index must be < {0}", clientQty));

				return &clients[p_index];
			}

			int GetClientQty()
			{
				return clientQty;
			}

		private:
			void Disconnect(String ^p_reason, bool p_tellServer = true, String ^p_clientReason = "", bool p_connectionFailedOrCancelled = false)
			{
				// Disconnect everything
				// p_tellServer is for when client disconnects and decides whether or not to inform the server
				// clientReason is only for when the server disconnects for its own reason and provides a reason to the clients

				// p_tellServer is for client side telling itself to disconnect, set to false when told by server to disconnect

				// shut down all sockets catchall
				// if hosting, and any clients open, send disconnect packets with linger and close each
				// ??
				// if hosting, reset client data, and clear out waiting and confirmation packets
				// if client, clear out host waiting and confirmation packets
				// ??

				// shut down user's socket (server listening or client connection to server)
				if (active == true)
				{
					if (server == true)
					{
						// server

						for (int i = 0; i < clientQty; i++)
						{
							// clear out clients, tell them to disconnect
							DisconnectClient(&clients[i], p_clientReason, true, false);
						}

						if (serverListeningSocket.IsOpen() == true)
						{
							serverListeningSocket.Close();

							// this would actually only be true if a client's connect failed or was cancelled, which doesn't happen to a server
							if (p_connectionFailedOrCancelled == false)
								OnDisconnect(p_reason);
						}

						// close udp socket if used
						udpSocket.Close();

						ResetSessionVariables();
						ClearAllPlayers();
						SimulateLag(0);
					}
					else
					{
						// client

						if (localUser.socket.IsOpen() == true)
						{
							if (p_tellServer == true)
							{
								localUser.socket.notReady = false; // reset condition to allow a packet to leave, just in case

								// give linger a chance to work
								localUser.socket.SetLinger(4);
								localUser.socket.MakeBlocking(true);

								// send I AM Disconnecting packet with linger (sendnow)
								NetworkSimplePacket disconnectingPacket;
								GameNetworkPacketHelper::PopulateDisconnectingPacket(disconnectingPacket);
								localUser.socket.SendCritical((char *)&disconnectingPacket, disconnectingPacket.length, 0, 1000);
							}

							// close tcp connection
							localUser.socket.Close();
							// close udp socket if used
							udpSocket.Close();

							if (p_connectionFailedOrCancelled == false)
								OnDisconnect(p_reason);

							ResetSessionVariables();
							ClearAllPlayers();
							SimulateLag(0);
						}
					}

					active = false;
					localUser.Reset();
				}
			}
			
			void Destroy()
			{
				Shutdown();

				// get rid of client data, destroy implementation data as well
				if (clients != nullptr)
				{
					delete [] clients;
					clients = nullptr;
					clientQty = 0;
				}
			}

			void Shutdown()
			{
				Disconnect("Application closed", true, "Server application closed"); // catchall for client telling server it disconnected and server telling clients it shut down
				// note: when client disconnects, server just reports that a client left with no reason.
				// the first reason is what would be displayed locally if the app was still open to echo something after disconnecting

				if (valid == true)
				{
					WSACleanup();
					valid = false;

					OnNetworkClosed();
				}
			}

			// player-related routines

		private:
			void ClearAllPlayers()
			{
				players.Clear();
			}

		public:
			int GetHostUserId()
			{
				if (IsServer())
					return localUser.id;
				else
				{
					LinkedListEnumerator<GameNetworkPlayerNode> playerEnum = players.GetEnumerator();
					while (playerEnum.MoveNext())
					{
						if (playerEnum.Current()->data.player->host == true)
							return playerEnum.Current()->data.player->id;
					}
				}

				throw gcnew Exception("Host user id not found!  Is player list created properly with a single host flag = true?");
			}

			GameNetworkPlayerBase * GetPlayer(int p_id)
			{
				return players.GetPlayer(p_id);
			}

			LinkedListEnumerator<GameNetworkPlayerNode> GetPlayerEnumerator()
			{
				return players.GetEnumerator();
			}

			GameNetworkClient * GetClientByClientId(int p_id)
			{
				for (int i = 0; i < clientQty; i++)
				{
					if (clients[i].id == p_id)
						return &(clients[i]);
				}
				return nullptr;
			}

			int GetLocalUserId()
			{
				return localUser.id;
			}

		protected:
			//////////////////////
			// override methods
			virtual void OnInitializationFailed(int p_version, int p_subVersion); // WSA Startup failed

			// server only
			virtual void OnHostSuccess(); // hosting was successful
			virtual void OnHostFailure(String ^p_reason); // hosting failed
			virtual void OnClientConnect(int p_slotsRemaining, int p_maxSlots); // client connecting through sockets, may not necessarily be allowed (slots might be full)
			virtual void OnClientRejectedNoAvailableSlot(); // client cannot connect if slots full
			virtual void OnClientLogin(GameNetworkClient &p_client); // when receive base network login information, further login information can be requested later as dictated by implementation
			virtual void OnClientRejectedBadLogin(GameNetworkClient &p_client); // client cannot connect if correct version not sent
			virtual void OnPendingClientTimingOut(GameNetworkClient &p_client, int p_timeOutQty, int p_maxTimeouts); // client has not sent keepalive
			virtual void OnPendingClientTimedOut(GameNetworkClient &p_client); // client reached max timeouts and has been disconnected
			virtual void OnPendingClientNoLongerTimingOut(GameNetworkClient &p_client); // client woke up
			virtual void OnPendingClientLeft(GameNetworkClient &p_client); // client left normally
			virtual void OnClientReconnect(GameNetworkClient &p_client); // implementation specific - client managed to be detected to reconnect (game data available that allows network to verify a reconnection)
			virtual void OnBadClientPacketReceived(GameNetworkClient &p_client, String ^p_error); // bad data in packet, possible tampering
			virtual void OnBadUDPPacketReceived(String ^p_error); // UDP packet with no establish client source (login not yet registered)

			// client only
			virtual void OnConnectSuccess(); // connect succeeded (still need to send correct login information to participate)
			virtual void OnJoined(); // player has been validated and has a player record
			virtual void OnConnectFailure(String ^p_reason); // connect failed
			virtual void OnConnectingPreProcess(String ^p_message); // just before connect(), usually to display connecting message, at least to display something while gethostbyname() executes
			virtual bool OnConnectingContinue(); // nonblocking connect only - cancel connection in process?
			virtual void OnConnectingCanceled(); // nonblocking connect only - connection in process was cancelled (OnConnectingPostProcess, OnConnectSuccess and OnConnectFailure will NOT be called)
			virtual void OnConnectingPostProcess(); // after the results of connect() are determinable, whether if a blocking connect() completes or checking the connection status determines a result - main purpose is to undo what OnConnectingPreProcess did, if necessary
			virtual void OnServerTimingOut(int p_timeOutQty, int p_maxTimeouts); // server has not sent keepalive
			virtual void OnServerTimedOut(); // server reached max timeouts and has been disconnected
			virtual void OnServerNoLongerTimingOut(); // server woke up
			virtual void OnBadServerPacketReceived(String ^p_error); // bad data in packet, possible tampering

			// both server and client
			virtual void OnSocketNotReady(); // communication socket is clogged, can't write a packet
			virtual void OnSocketReady(); // packet was successfully written to socket
			virtual void OnDisconnect(String ^p_reason); // disconnecting (commanded by server or user choice) - maintain game data here or in OnNetworkClosed()
			virtual void OnNetworkClosed(); // when network is shut down for any reason

			virtual void OnKeepaliveSent(int p_keepaliveQty = 1); // when keepalive packet sent
			virtual void OnKeepaliveReceived(GameNetworkClient *p_client = nullptr); // when keepalive packet received
			virtual void OnWakeupSent(GameNetworkClient *p_client = nullptr);
			virtual void OnWakeupReceived(GameNetworkClient *p_client = nullptr);
			virtual void OnIAmAwakeSent(GameNetworkClient *p_client = nullptr);
			virtual void OnIAmAwakeReceived(GameNetworkClient *p_client = nullptr);
			virtual void OnGuaranteedPacketSent(GameNetworkClient *p_client, int p_confirmationId, int p_channel);
			virtual void OnGuaranteedPacketReSent(GameNetworkClient *p_client, int p_confirmationId, int p_channel);
			virtual void OnGuaranteedPacketReceived(GameNetworkClient *p_client, int p_confirmationId, int p_channel);
			virtual void OnConfirmationIdSent(GameNetworkClient *p_client, int p_confirmationId, int p_channel);
			virtual void OnConfirmationIdReceived(GameNetworkClient *p_client, int p_confirmationId, int p_channel);

			virtual void CustomProcess(int p_elapsedTimeMS); // usually handles special timed pack sending, like pings
			virtual bool CustomValidatePacket(char *p_packet, int p_type); // if no override, returns false naturally
			virtual void CustomProcessPacketPlayer(char *p_packet, int p_type) = 0; // must override - implementation decides how to process the packet, routing to its own server, host, client or player routine
			virtual void CustomProcessPacketHost(GameNetworkClient *p_client, char *p_packet, int p_type) = 0; // must override - implementation decides how to process the packet, routing to its own server, host, client or player routine

			// player data method overrides, as GameNetworkPlayerBase is derived.  Implementation is expected to handle its own verison of GameNetworkPlayerBase in all of these routines,
			//    including any approprate packets to send or handle

			// server
			virtual GameNetworkPlayerBase * ServerAddPlayer(GameNetworkClient &p_client, bool p_server, bool p_host); // server receives validating login
			virtual void SendAddPlayerPacket(GameNetworkPlayerBase *p_player, GameNetworkClient *p_destinationClient = nullptr); // when player joins; nullptr sends to all except the new player, p_destinationClient sends all players to that client including the one just added for that client

			// client
			virtual bool ValidateAddPlayerPacket(NetworkAddPlayerPacketBase *p_packet); // when add player packet received
			virtual void ClientAddPlayer(NetworkAddPlayerPacketBase *p_packet); // client adding player as commanding by server

			// both
			virtual GameNetworkPlayerBase * CreatePlayer(); // could have just created the corresponding class in implementation of AddServerPlayer and ClientAddPlayer, but, this separates things fine
			virtual void OnPlayerJoined(int p_id); // report that a player is finally part of the official game now by framework standards (however, the implementation might have further criteria)
			virtual void OnPlayerLeft(int p_id, bool p_echo = true); // report that a player left from player information (on server, a client is a player only after validated).  if p_echo == false, don't display it, just maintain data
			virtual void OnPlayerTimingOut(int p_id, int p_timeOutQty, int p_maxTimeouts); // player has not sent keepalive
			virtual void OnPlayerTimedOut(int p_id); // player reached max timeouts and has been disconnected
			virtual void OnPlayerNoLongerTimingOut(int p_id); // player woke up

		public:
			virtual void NetworkMessage(GameNetworkMessageType p_type, String ^p_message); // message to display or write to log, determined by implementation
		};
	}
}