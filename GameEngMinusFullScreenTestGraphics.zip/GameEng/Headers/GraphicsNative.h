#pragma once

#include "LinkedListTemplate.h"
#include "GameTexture.h"
#include "GameColor.h"
#include "Matrix.h"
#include "Orient.h"
#include "ModelSurface.h"
#include "GraphicsNativeEnums.h"
#include "MathConstants.h"
#include "Frustum.h"
#include "PortalData.h"
#include <vcclr.h> // gcroot
#include <Windows.h> // CopyMemory

namespace GameEng {
	namespace Graphics {
		// Shaders
		// note: A vertex shader plus a fragment shader makes a program.  It's possible to use these in any combination, and provide custom vertex and fragment shaders.

		// normal maps use RGB for XYZ.  0 to 255, 0 => -1.0, 255 => 1.0, 127/128 => 0.0.  Seems to be the standard methodology for normal maps (usual outward normal is 127, 127, 255)

		using namespace GameEng::Math;
		using namespace GameEng::Storage;
		using namespace GameEng::PortalEngine;

		enum class GraphicsFrameBufferTypeEnum
		{
			None,
			Renderbuffer,
			Texture
		};

		enum class GraphicsFrameBufferColorFormatEnum
		{
			RGB, // standard render buffer, diffuse color, fragment normal converted to bumpmap normal values
			Vector2d16Bit, // motion blur screen space offset for velocity based blur
			Vector3d16Bit, // lighting values
			Vector3d32Bit // lighting values
		};

		enum class GraphicsAttachedFrameBufferUsageEnum
		{
			// required formats for attachments in comments below, validated before shader call

			// standard rendering
			StandardColor, // RGB

			// Motion blur
			MotionBlurFragmentScreenOffset, // Vector2d16Bit

			// Q-buffer data collection for deferred lighting
			DiffuseColor, // RGB
			FragmentNormal, // RGB -1..1 (0 = -1, 128 = 0, 255 = 1)
			FragmentWorldPosition, // Vector3d32Bit
			LightColor, // Vector3d32Bit
			SpecularColor // Vector3d32Bit
		};

		class GraphicsAttachedFrameBufferUsageHelper
		{
		public:
			static int ConvertEnumToInt(GraphicsAttachedFrameBufferUsageEnum p_enum)
			{
				switch (p_enum)
				{
				case GraphicsAttachedFrameBufferUsageEnum::StandardColor:
					return 0;
					break;
				case GraphicsAttachedFrameBufferUsageEnum::MotionBlurFragmentScreenOffset:
					return 1;
					break;
				case GraphicsAttachedFrameBufferUsageEnum::DiffuseColor:
					return 2;
					break;
				case GraphicsAttachedFrameBufferUsageEnum::FragmentNormal:
					return 3;
					break;
				case GraphicsAttachedFrameBufferUsageEnum::FragmentWorldPosition:
					return 4;
					break;
				case GraphicsAttachedFrameBufferUsageEnum::LightColor:
					return 5;
					break;
				case GraphicsAttachedFrameBufferUsageEnum::SpecularColor:
					return 6;
					break;
				default:
					throw gcnew Exception("Unsupported usage");
					break;
				}
			}
		};

		class GraphicsFrameBufferContainer
		{
		public:
			void *frameBuffer; // converted to OpenGLGraphicsFrameBuffer

			GraphicsFrameBufferTypeEnum colorBufferType;
			GraphicsFrameBufferTypeEnum depthBufferType;

			// can be single place or cubemap
			// IMPORTANT: These are NOT registered in the API list to be destroyed.  DestroyFrameBuffer should get rid of these entirely!
			gcroot<GameTexture ^> colorBufferTexture;
			gcroot<GameTexture ^> depthBufferTexture;

			int width, height;
			int faceQty; // 1 for single plane (normal), 6 for sixe-sided (cubemap)
			int frameBufferQty; // need 1 (single face or 6 face cubemap textures) or 6 (6 faces and ANY renderbuffers used)
			// if 1, can evoke a single render with a geometry shader.  If 6, must call 6 renders for each framebuffer
			// note that faces are in order: posX, negX, posY, negY, posZ, negZ to be consistent with how cubemap faces are defined in OpenGL

#define MAX_FRAMEBUFFER_ATTACHMENT_QTY 7
			gcroot<GameTexture ^> attachments[MAX_FRAMEBUFFER_ATTACHMENT_QTY]; // additional buffers attached that are rendered to textures for future use
			int attachmentQty;

			// assigned draw buffers (initialized in CreateFramebuffer, modified in SetDrawBuffers)
			GraphicsFrameBufferColorFormatEnum drawBufferFormats[MAX_FRAMEBUFFER_ATTACHMENT_QTY + 1];
			int drawBufferFormatQty;

			GraphicsFrameBufferContainer()
			{
				frameBuffer = nullptr;
				colorBufferType = GraphicsFrameBufferTypeEnum::None;
				depthBufferType = GraphicsFrameBufferTypeEnum::None;

				colorBufferTexture = nullptr;
				depthBufferTexture = nullptr;

				width = 0;
				height = 0;

				faceQty = 1;
				frameBufferQty = 1;

				for (int i = 0; i < MAX_FRAMEBUFFER_ATTACHMENT_QTY; i++)
					attachments[i] = nullptr;
				attachmentQty = 0;

				drawBufferFormatQty = 0;
			}

			bool IsCubeMap()
			{
				return (faceQty == 6);
			}

			~GraphicsFrameBufferContainer()
			{
				if (frameBuffer != nullptr)
					throw gcnew Exception("Framebuffer pointer is not null - did you allow the graphics API to destroy framebuffer resources first?");

				// note: graphics API should be getting rid of the textures by this point
				if (static_cast<GameTexture^>(colorBufferTexture) != nullptr)
				{
					// don't need API to remove its native resources here - the graphics resources have already been cleared by API:ClearFrameBuffer, just getting rid of pointer storage
					delete colorBufferTexture->GetRendererResource()->rendererResource;
					delete colorBufferTexture->GetRendererResource();
					delete colorBufferTexture;
					colorBufferTexture = nullptr;
				}
				if (static_cast<GameTexture^>(depthBufferTexture) != nullptr)
				{
					// don't need API to remove its native resources here - the graphics resources have already been cleared by API:ClearFrameBuffer, just getting rid of pointer storage
					delete depthBufferTexture->GetRendererResource()->rendererResource;
					delete depthBufferTexture->GetRendererResource();
					delete depthBufferTexture;
					depthBufferTexture = nullptr;
				}
				for (int i = 0; i < attachmentQty; i++)
				{
					if (static_cast<GameTexture^>(attachments[i]) != nullptr)
					{
						// don't need API to remove its native resources here - the graphics resources have already been cleared by API:ClearFrameBuffer, just getting rid of pointer storage
						delete attachments[i]->GetRendererResource()->rendererResource;
						delete attachments[i]->GetRendererResource();
						delete attachments[i];
						attachments[i] = nullptr;
					}
				}
				attachmentQty = 0;
			}

		};

		// only for API to register usage to destroy when the API is released
		typedef GraphicsFrameBufferContainer * GraphicsFrameBufferContainerPtr;

		////////////////////////////////////////////////
		// GraphicsShaderComposition
		// Used to dynamically create shader source to prevent having to create complete shader code for every permutation (reduces maintenance too - corrections only have to be made in each snippet)
		// Important note: Once a vao structure is created, it cannot be changed (vertices, colors, texcoordinates, normals, tangents, binormals in that order)
		// however, how the data is used is determined by the shader composition options below.  normals, tangents and binormals won't be used if lighting is not chosen.  texcoords will be ignored if
		//   all textures are cleared, etc.  The data will still need to exist in the uniforms so that they are placed in the proper variables, but the code won't use them.  If a vao did not place the
		//   data at all because of the initial create options, the variables and associated code will not be added to the shader no matter what kind of override render options are provided.
		// Required data in render options:
		// - lighting (never an override - this situation changes constantly)
		// Other data supported in render override options: 
		// - use vertex color, single color value provided or use no color

		// once this data is set during native object creation, it CANNOT be changed. (todo: code that way)
		// All of this data must be represented in the 'in' section of the vertex shader in the same order it was added to the vaos, to be calculated upon or passed to the fragment shader.  Uniforms can be either in the vertex or fragment shader code as needed, in any order
		// So regardless of any options used, if the data is to be ignored, it must still have an 'in' representation, and if an option requiring missing data is requested, the operation will be ignored
		public class GraphicsNativeObjectComposition
		{
		public:
			// all data is at the vertex level for now.  In the case of many shared vertices, an element array as part of the vao can call for triplets of vertices to be used for rendering triangles (like terrain)
			bool vertices; // 3 floats each - should pretty much always be true - can't render something without vertices
			int jointIndexQty; // bones - 0 if none.  Note: This number, if > 0 can change if the vao data uploaded was changed to include a different list of indices that before, but this is currently not supported
			bool vertexColors; // 4 floats each - if all vertices are a single color, then single color will be in default options and can be overridden, otherwise color is provided for each vertex
			int texCoordQtyPerVertex; // 0, 2, 4 floats each - if any textures are on the surfaces, texCoords will be provided (0: none, 2: s and t, 4: s, t, r, q; 0,2,4 are the only valid values)
			int texBlendCoordQtyPerVertex; // 0, 2 or 4 (0: none, 2: st, 4:strq)
			bool vertexNormals; // models should always have normals, and are only provided if the original creation calls for lighting use.  If these aren't there, no lighting can occur, including bumpmapping
			// both of these are either true or false together and are only used if there is a bumpmap on the surfaces provided and lighting is requested during native object creation.  If these aren't there, all bumpmapping operations are ignored and only the surface normal is used for lighting if provided
			bool vertexTangents;
			bool vertexBinormals;

		public:
			GraphicsNativeObjectComposition()
			{
				vertices = true;
				jointIndexQty = 0;
				vertexColors = false;
				texCoordQtyPerVertex = 0;
				texBlendCoordQtyPerVertex = 0;
				vertexNormals = false;
				vertexTangents = false;
				vertexBinormals = false;
			}
		};

		///////////////////////////////////
		// data provided to the shader includes:
		// single color (optional, can override vertex colors for usage)
		// mvp (if bones not being used and transformation is required)
		// bone mvp, light positions and camera positions (bones only, light positions and camera positions not provided if lighting not used) - mvp will be used in vertex, light and camera in fragment
		// light colors (bones, if lighting used)
		// light positions and colors (if bones not used, but lighting is used)
		// bumpmap aspect (if lighting and bumpmapping is used)
		// material (each vao is separated my material.  the same material will be used for the entire vao)

		//////////////////////////////////
		// render options available:
		// use no color, use single color - can override vertex colors.  However you must either use no color or a single color when no vertex colors are in the vao
		// diffuse texture overrides, or use no textures - textures are ignored if no texcoords were provided in the data
		// bumpmap override - ignored if no tangents or binormals provided
		// bumpmap aspect - if 0.0, no bumpmap code is provided although the data still has placeholders
		// specular map overrides for textures

		// texture usage
		// texture1 is the first texture applied, then texture2 is placed on top and blended with first, etc. up to 4 textures - possible for all the textures to be modulated at the end all at once
		//   or modulated individually if their options differ in the stack
		// note: if a texture has a specular component to it, it will be completely overwritten by the next texture unless alpha on that texture is not 1.0
		// note: if a texture lower in the stack has a specular component, that aspect will not modulate the lower textures
		// note: if no tex coords are provided in the data, all texture operations are ignored
		public class GraphicsShaderCompositionTexture
		{
		public:
			bool specularMap; // how should this texture be lit in specular fashion?  Later textures will overwrite this if alpha = 1.0 (specular reduced by 1.0 - its alpha).
												 // if no specular map provided along the stack, just do specular at the end of the stack as appropriate (if t1 has a specmap and t2-t4 do not, then
												 //    calculate spec for t1, and let the diffuse results for t2-t4 overwrite it, then calculate spec on those at the end - tex blending should reduce specular.. think more about this later)
			GraphicsShaderCompositionTextureLightOption lightOption; // is texture lit diffusely or does it emit?
			GraphicsShaderCompositionTextureModulateOption modulateOption; // should texture be taken as is or modulate with single or vertex color
			GraphicsShaderCompositionTextureBlendOption blendOption; // texture1 should never have a blend option - no prior texture to blend with
			GraphicsShaderCompositionSpecularBlendOption specularBlendOption; // texture1 should never have a blend option - no prior texture to blend with

			GraphicsShaderCompositionTexture()
			{
				specularMap = false;
				modulateOption = GraphicsShaderCompositionTextureModulateOption::ModulateWithColor;
				blendOption = GraphicsShaderCompositionTextureBlendOption::NoBlend;
				lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse;
				specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate;
			}
		};

		// if lighting is used, then it is expect that there will be a material aspect along with lights
		public class GraphicsShaderCompositionLightOptions
		{
		public:
			bool useLighting; // if lighting not used, no light variables (lights(color, position), material, camera position for specular, bumpmap aspect) or code that operates on them are provided
			bool vertexLighting; // vertex level lighting (light calculated at vertex level, which provides final lit diffuse color (modulated with provided color) and specular color from vertex shader to fragment shader), or fragment level lighting?
			int lightQty; // 0 also supported, in which case only ambient is applied at all
			float bumpMapAspect; // 1.0 is default, 0.0 flattens, < 1.0 reduces, > 1.0 pronounces.  If 1.0 no code or variable provided.  If 0.0 all bumpmap code is removed even though tangents and binormals may still be in data.  If there is no tangent/birnomal data, this is ignored
			GraphicsShaderCompositionLightType type[8];
			GraphicsShaderCompositionLightShadowMapType shadowMapType[8];
			bool useShadowMap;
			bool useDarkvision;

			GraphicsShaderCompositionLightOptions()
			{
				useLighting = false;
				vertexLighting = false;
				lightQty = 0;
				bumpMapAspect = 1.0f;
				useShadowMap = false;
				useDarkvision = false;
			}
		};

		public class GraphicsShaderCompositionPostProcessOptions
		{
		public:
			bool useGrayScale;
			bool useGamma;
			bool useFade;

			GraphicsShaderCompositionPostProcessOptions()
			{
				useGrayScale = false; // use if shaderOptions.grayScale != 0.0
				useGamma = false; // use shaderOptions.gamma != 1.0
				useFade = false; // use if shaderOptions.fade != 0.0
			}
		};

		// overrides lighting and many aspects, does not override grayscale.
		enum class GraphicsShaderSilhouetteEnumType
		{
			Normal = 1, // render normally with everything
			SolidColor = 2, // color only, no lighting or texturing
			ColorScale = 3, // with texture, grayscale, multiply by color, no lighting
			ColorGhost = 4 // color only, no lighting or texturing, with alpha blend for depth depending on how deep the fragment is (not currently supported)
		};

		public class GraphicsShaderCompositionCheckSum
		{
		public:
			_int64 result1;
			_int64 result2;
			_int64 result3;
			_int64 result4;

			GraphicsShaderCompositionCheckSum()
			{
				Initialize();
			}

			void Initialize()
			{
				result1 = 0;
				result2 = 0;
				result3 = 0;
				result4 = 0;
			}

			GraphicsShaderCompositionCheckSum(int p_result1, int p_result2, int p_result3, int p_result4)
			{
				Set(p_result1, p_result2, p_result3, p_result4);
			}

			void Set(int p_result1, int p_result2, int p_result3, int p_result4)
			{
				result1 = p_result1;
				result2 = p_result2;
				result3 = p_result3;
				result4 = p_result4;
			}

			bool Compare(GraphicsShaderCompositionCheckSum &p_checksum)
			{
				return (result1 == p_checksum.result1 && result2 == p_checksum.result2 && result3 == p_checksum.result3 && result4 == p_checksum.result4);
			}
		};

		// options that determine how to build the shader with snippets of code - also determines uniform variables to populate
		public class GraphicsShaderComposition
		{
		public:
			GraphicsNativeObjectComposition vaoComposition; // which data is part of the vao? (determines required in data)
			GraphicsShaderCompositionColorOption colorOption; // how should colors be used if provided? (if no colors in vaos, only NoColor and SingleColor are valid)
			GraphicsShaderCompositionVertexTransformationOption transformOption; // shoudl vertices be transformed to screen space (default) or accepted as is?
			int textureQty; // total textures used, stacked 0,1,2,3 no gaps, unused ones ignored
			GraphicsShaderCompositionTexture textures[4]; // diffuse textures.  0 is first applied, then 1 2 3 on top
			bool bumpMapUsed; // defines shape of surface for lighting (all textures in stack will be lit this way - will be applied one texture at a time or on the entire stack afterwards depending on options)
			bool blendMapUsed; // blendmap used to blend textures.  Note: blendmap is expected to use a separate set of texture coordinates than all the rest.  All the rest use the SAME texture coordinates
			GraphicsShaderCompositionLightOptions lightOptions; // is lighting used this time?  If so, how many lights are we supporting, and is it at the vertex level?  How should bumpmapping if any be used?
			GraphicsShaderCompositionPostProcessOptions postProcessOptions;
			GraphicsShaderSilhouetteEnumType silhouetteType;
			GraphicsAttachedFrameBufferUsageEnum drawBufferUsage[8];
			int drawBufferQty;
			int usageOccurrence[16]; // GraphicsAttachedFrameBufferUsageEnum is index here, count of how the buffers are being used 

			GraphicsShaderComposition()
			{
				textureQty = 0;
				colorOption = GraphicsShaderCompositionColorOption::VertexColor;
				transformOption = GraphicsShaderCompositionVertexTransformationOption::Transform;
				bumpMapUsed = false;
				drawBufferQty = 0;
				for (int i = 0; i < 16; i++)
					usageOccurrence[i] = 0;
			}

			GraphicsShaderCompositionCheckSum GetCompositionCheckSum()
			{
				// up to 19 digits (9.223x10^19)
				// returns a number representating a composition, which directly determines the shader text constructed.
				// this can be upgraded later to return a number more quickly

				// careful with _int64 multiplication here.  Make sure operations aren't being doen as int32 then promoted to int64.  cast where appropriate.

				GraphicsShaderCompositionCheckSum result;

				// treat booleans like binary
				if (vaoComposition.vertices == true)
					result.result1 += 1;
				if (silhouetteType == GraphicsShaderSilhouetteEnumType::Normal)
				{
					if (vaoComposition.vertexColors == true)
						result.result1 += 2;
					if (vaoComposition.vertexNormals == true)
						result.result1 += 4;
					if (vaoComposition.vertexTangents == true)
						result.result1 += 8;
					if (vaoComposition.vertexBinormals == true)
						result.result1 += 16;
				} // silhouette
				if (vaoComposition.jointIndexQty > 0)
				{
					if (vaoComposition.jointIndexQty > 100)
						throw gcnew Exception("> 100 joints not supported");
					result.result1 += (int((vaoComposition.jointIndexQty - 1) / 20) + 1) * 100000; // shader supports multiples of 20 joints up to 100
				}
				if (silhouetteType == GraphicsShaderSilhouetteEnumType::Normal)
				{
					if (vaoComposition.texCoordQtyPerVertex > 0)
						result.result1 += vaoComposition.texCoordQtyPerVertex * 1000000; // 0, 2 or 4

					switch (colorOption)
					{
					case GraphicsShaderCompositionColorOption::NoColor:
						result.result1 += 0 * 10000000;
						break;
					case GraphicsShaderCompositionColorOption::SingleColor:
						result.result1 += 1 * 10000000;
						break;
					case GraphicsShaderCompositionColorOption::VertexColor:
						result.result1 += 2 * 10000000;
						break;
					}
				} // silhouette
				// transform option: bitwise switch
				switch (transformOption)
				{
				case GraphicsShaderCompositionVertexTransformationOption::NoTransform:
					result.result1 += 0 * 100000000;
					break;
				case GraphicsShaderCompositionVertexTransformationOption::Transform:
					result.result1 += 1 * 100000000;
					break;
				}
				if (silhouetteType == GraphicsShaderSilhouetteEnumType::Normal)
				{
					if (blendMapUsed == true)
						result.result1 += 64;
				}

				if (lightOptions.useLighting == true)
				{
					result.result1 += 128;
					if (lightOptions.vertexLighting == true)
						result.result1 += 256;
					if (lightOptions.useDarkvision == true)
						result.result1 += 512;
					if (lightOptions.lightQty != 0)
					{
						if (lightOptions.bumpMapAspect != 0.0f) // if 0.0 no bumpmapping anyway
						{
							if (bumpMapUsed == true)
								result.result1 += 1024;
							if (lightOptions.bumpMapAspect != 1.0f) // if 1.0 no need for a bumpmapaspect uniform
								result.result1 += 2048;
						}
						result.result1 += lightOptions.lightQty * 1000000000; // up to 8

						if (lightOptions.useShadowMap == true)
							result.result3 += 1;
						_int64 lightFactor = 2;
						for (int i = 0; i < lightOptions.lightQty; i++)
						{
							switch (lightOptions.type[i])
							{
							case GraphicsShaderCompositionLightType::Point:
								result.result3 += _int64(lightFactor) * 0;
								break;
							case GraphicsShaderCompositionLightType::Spotlight:
								result.result3 += _int64(lightFactor) * 1;
								break;
							case GraphicsShaderCompositionLightType::SpotlightTexture:
								result.result3 += _int64(lightFactor) * 2;
								break;
							case GraphicsShaderCompositionLightType::Directional:
								result.result3 += _int64(lightFactor) * 4;
								break;
							}
							if (lightOptions.useShadowMap == true)
							{
								switch (lightOptions.shadowMapType[i])
								{
								case GraphicsShaderCompositionLightShadowMapType::FlatMap:
									result.result3 += _int64(lightFactor) * 8;
									break;
								case GraphicsShaderCompositionLightShadowMapType::CubeMap:
									result.result3 += _int64(lightFactor) * 16;
									break;
								}
							}
							lightFactor *= _int64(32);
						}
					}
				}

				if (silhouetteType == GraphicsShaderSilhouetteEnumType::Normal)
				{
					// use result2 for textures, room getting too tight
					result.result2 += textureQty; // up to 4
					_int64 factor = 1000;
					int specularNumber = 10; // 1-15 * 10
					for (int i = 0; i < textureQty; i++)
					{
						if (textures[i].specularMap == true)
							result.result2 += specularNumber;
						switch (textures[i].modulateOption)
						{
						case GraphicsShaderCompositionTextureModulateOption::ModulateWithColor:
							result.result2 += 0 * factor * 1;
							break;
						case GraphicsShaderCompositionTextureModulateOption::NoModulate:
							result.result2 += 1 * factor * 1;
							break;
						}
						switch (textures[i].lightOption)
						{
						case GraphicsShaderCompositionTextureLightOption::Diffuse:
							result.result2 += 0 * factor * 2;
							break;
						case GraphicsShaderCompositionTextureLightOption::Emittive:
							result.result2 += 1 * factor * 2;
							break;
						}
						switch (textures[i].blendOption)
						{
						case GraphicsShaderCompositionTextureBlendOption::NoBlend:
							result.result2 += 0 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::Modulate:
							result.result2 += 1 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithBlendMap_Red:
							result.result2 += 2 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithBlendMap_Green:
							result.result2 += 3 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithBlendMap_Blue:
							result.result2 += 4 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithBlendMap_Alpha:
							result.result2 += 5 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithColor_Red:
							result.result2 += 6 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithColor_Green:
							result.result2 += 7 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithColor_Blue:
							result.result2 += 8 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendWithColor_Alpha:
							result.result2 += 9 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendInverseLight:
							result.result2 += 10 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::BlendInverseSqrtLight:
							result.result2 += 11 * factor * 10;
							break;
						case GraphicsShaderCompositionTextureBlendOption::DecalSaturateAlpha:
							result.result2 += 12 * factor * 10;
							break;
						}
						switch (textures[i].specularBlendOption)
						{
						case GraphicsShaderCompositionSpecularBlendOption::NoModulate:
							result.result2 += 0 * factor * 4;
							break;
						case GraphicsShaderCompositionSpecularBlendOption::Modulate:
							result.result2 += 1 * factor * 4;
							break;
						}

						factor = factor * 1000;
						specularNumber = specularNumber * 2;
					}
				} // silhouette

				// result 4 stuff
				switch (silhouetteType)
				{
				case GraphicsShaderSilhouetteEnumType::Normal:
					result.result4 += 1;
					break;
				case GraphicsShaderSilhouetteEnumType::SolidColor:
					result.result4 += 2;
					break;
				case GraphicsShaderSilhouetteEnumType::ColorScale:
					result.result4 += 3;
					break;
				case GraphicsShaderSilhouetteEnumType::ColorGhost:
					result.result4 += 4;
					break;
				}

				// bit booleans
				if (postProcessOptions.useGrayScale == true)
					result.result4 += 10; // 1
				if (postProcessOptions.useGamma == true)
					result.result4 += 20; // 2
				if (postProcessOptions.useFade == true)
					result.result4 += 40; // 4

				// buffer usage
				result.result4 += 100 * drawBufferQty; // 1-8
				int bufferFactor = 1000;
				for (int i = 0; i < drawBufferQty; i++)
				{
					switch (drawBufferUsage[i])
					{
					case GraphicsAttachedFrameBufferUsageEnum::StandardColor:
						result.result4 += bufferFactor * 0;
						break;
					case GraphicsAttachedFrameBufferUsageEnum::MotionBlurFragmentScreenOffset:
						result.result4 += bufferFactor * 1;
						break;
					case GraphicsAttachedFrameBufferUsageEnum::DiffuseColor:
						result.result4 += bufferFactor * 2;
						break;
					case GraphicsAttachedFrameBufferUsageEnum::LightColor:
						result.result4 += bufferFactor * 3;
						break;
					case GraphicsAttachedFrameBufferUsageEnum::SpecularColor:
						result.result4 += bufferFactor * 4;
						break;
					case GraphicsAttachedFrameBufferUsageEnum::FragmentWorldPosition:
						result.result4 += bufferFactor * 5;
						break;
					case GraphicsAttachedFrameBufferUsageEnum::FragmentNormal:
						result.result4 += bufferFactor * 6;
						break;
					default:
						throw gcnew Exception("Unsupported frame buffer usage");
						break;
					}
					bufferFactor *= 10;
				}

				return result;
			}

			bool Compare(GraphicsShaderComposition *p_composition)
			{
				if (p_composition->silhouetteType != silhouetteType)
					return false;

				if (p_composition->postProcessOptions.useGrayScale != postProcessOptions.useGrayScale)
					return false;
				if (p_composition->postProcessOptions.useGamma != postProcessOptions.useGamma)
					return false;
				if (p_composition->postProcessOptions.useFade != postProcessOptions.useFade)
					return false;

				if (p_composition->silhouetteType == GraphicsShaderSilhouetteEnumType::Normal)
				{
					if (p_composition->blendMapUsed != blendMapUsed)
						return false;
					if (p_composition->bumpMapUsed != bumpMapUsed)
						return false;
					if (p_composition->colorOption != colorOption)
						return false;
					if (p_composition->lightOptions.lightQty != lightOptions.lightQty)
						return false;
					if (p_composition->lightOptions.bumpMapAspect != lightOptions.bumpMapAspect)
						return false;
					if (p_composition->lightOptions.useLighting != lightOptions.useLighting)
						return false;
					if (p_composition->lightOptions.useShadowMap != lightOptions.useShadowMap)
						return false;
					if (p_composition->lightOptions.vertexLighting != lightOptions.vertexLighting)
						return false;
					if (p_composition->lightOptions.useDarkvision != lightOptions.useDarkvision)
						return false;
					for (int i = 0; i < lightOptions.lightQty; i++)
					{
						if (p_composition->lightOptions.type[i] != lightOptions.type[i])
							return false;
						if (p_composition->lightOptions.shadowMapType[i] != lightOptions.shadowMapType[i])
							return false;
					}
					if (p_composition->textureQty != textureQty)
						return false;
					for (int i = 0; i < textureQty; i++)
					{
						if (p_composition->textures[i].blendOption != textures[i].blendOption)
							return false;
						if (p_composition->textures[i].lightOption != textures[i].lightOption)
							return false;
						if (p_composition->textures[i].modulateOption != textures[i].modulateOption)
							return false;
						if (p_composition->textures[i].specularBlendOption != textures[i].specularBlendOption)
							return false;
						if (p_composition->textures[i].specularMap != textures[i].specularMap)
							return false;
					}
				}
				if (p_composition->transformOption != transformOption)
					return false;
				if (p_composition->vaoComposition.vertices != vaoComposition.vertices)
					return false;
				if (p_composition->vaoComposition.jointIndexQty != vaoComposition.jointIndexQty)
					return false;
				if (p_composition->silhouetteType == GraphicsShaderSilhouetteEnumType::Normal)
				{
					if (p_composition->vaoComposition.vertexColors != vaoComposition.vertexColors)
						return false;
					if (p_composition->vaoComposition.vertexNormals != vaoComposition.vertexNormals)
						return false;
					if (p_composition->vaoComposition.vertexTangents != vaoComposition.vertexTangents)
						return false;
					if (p_composition->vaoComposition.vertexBinormals != vaoComposition.vertexBinormals)
						return false;
					if (p_composition->vaoComposition.texCoordQtyPerVertex != vaoComposition.texCoordQtyPerVertex)
						return false;
					if (p_composition->vaoComposition.texBlendCoordQtyPerVertex != vaoComposition.texBlendCoordQtyPerVertex)
						return false;
				}
				if (p_composition->drawBufferQty != drawBufferQty)
					return false;
				for (int i = 0; i < p_composition->drawBufferQty; i++)
				{
					if (p_composition->drawBufferUsage[i] != drawBufferUsage[i])
						return false;
				}

				return true;
			}
		};

		////////////////////////////
		// specifically for particles
		public class GraphicsNativeParticlesComposition
		{
		public:
			bool positions; // all particle systems need this
			bool color; // with alpha
			bool textures; // are textures being used or are they just polygons?
			bool axes; // L and U plus radius for rotation of particles
			// todo: what about radius only?  using default up and left for axes?

			GraphicsNativeParticlesComposition()
			{
				positions = true;
				color = true;
				textures = true;
				axes = true;
			}
		};

		public enum class GraphicsParticlesShaderCompositionSortType
		{
			None = 0,
			Dead = 1, // move dead particles to the end with one pass - use this sort for additive blending (fire, flashes, etc.)
			DepthAndDead = 2 // use bitonic sort to move dead particles to the end and sort by depth back to front - use this sort for occlusion blending (smoke, etc.)
		};

		// animate before sorting
		public class GraphicsParticlesShaderAnimationOptions
		{
		public:
			// what to calculate based on the particles new lifeMS value
			bool position;
			bool life; // determines if particle has died
			bool radius;
			bool alpha;
			// changing texture and color, etc.

			GraphicsParticlesShaderAnimationOptions()
			{
				position = false;
				life = false;
				radius = false;
				alpha = false;
			}
		};

		// assume for now that all particles use position as their center
		public enum class GraphicsParticlesTransformType
		{
			Position = 0, // use radius 1 with default up and left
			PositionRadius = 1,
			PositionRadiusAxes = 2,
			ViewpointAxesPosition = 3, // viewpoint = rotate so that particle spins with the viewpoint
			ViewpointAxesPositionRadius = 4,
			ViewpointAxesPositionRadiusAxes = 5
		};

		public class GraphicsParticlesShaderComposition
		{
		public:
			GraphicsNativeParticlesComposition vaoComposition; // what elements make up the data buffer?
			GraphicsParticlesShaderAnimationOptions animationOptions; // animate before sorting
			GraphicsParticlesShaderCompositionSortType sortType; // note: sorting within the GPU will require depth value and a way of telling when particles are dead
			GraphicsParticlesTransformType transformType; // how should particle polygons be calculated for the render using the position as the center?
			GraphicsShaderCompositionPostProcessOptions postProcessOptions;

			GraphicsShaderCompositionCheckSum GetCompositionCheckSum() // same checksum structure as main shader
			{
				GraphicsShaderCompositionCheckSum checkSum;
				checkSum.Initialize();

				// main composition
				if (vaoComposition.positions == true)
				{
					checkSum.result1 += 1;
				}
				if (vaoComposition.color == true)
				{
					checkSum.result1 += 2;
				}
				if (vaoComposition.axes == true)
				{
					checkSum.result1 += 4;
				}
				if (vaoComposition.textures == true)
				{
					checkSum.result1 += 8;
				}

				// animation
				if (animationOptions.position == true)
				{
					checkSum.result1 += 16;
				}
				if (animationOptions.life == true)
				{
					checkSum.result1 += 32;
				}
				if (animationOptions.radius == true)
				{
					checkSum.result1 += 64;
				}
				if (animationOptions.alpha == true)
				{
					checkSum.result1 += 128;
				}

				int factor = 256; // must be power of 2 > max adjustment from animation options
				switch (sortType)
				{
				case GraphicsParticlesShaderCompositionSortType::None:
					checkSum.result1 += 0 * factor;
					break;
				case GraphicsParticlesShaderCompositionSortType::Dead:
					checkSum.result1 += 1 * factor;
					break;
				case GraphicsParticlesShaderCompositionSortType::DepthAndDead:
					checkSum.result1 += 2 * factor;
					break;
				}

				factor = 1024; // must be power of 2 > max adjustment from sort type
				switch (transformType)
				{
				case GraphicsParticlesTransformType::Position:
					checkSum.result1 += 1 * factor;
					break;
				case GraphicsParticlesTransformType::PositionRadius:
					checkSum.result1 += 2 * factor;
					break;
				case GraphicsParticlesTransformType::PositionRadiusAxes:
					checkSum.result1 += 3 * factor;
					break;
				case GraphicsParticlesTransformType::ViewpointAxesPosition:
					checkSum.result1 += 4 * factor;
					break;
				case GraphicsParticlesTransformType::ViewpointAxesPositionRadius:
					checkSum.result1 += 5 * factor;
					break;
				case GraphicsParticlesTransformType::ViewpointAxesPositionRadiusAxes:
					checkSum.result1 += 6 * factor;
					break;
				}

				// post processing options
				if (postProcessOptions.useFade == true)
					checkSum.result2 += 1;
				if (postProcessOptions.useGrayScale == true)
					checkSum.result2 += 2;
				if (postProcessOptions.useGamma == true)
					checkSum.result2 += 4;

				return checkSum;
			}

			bool Compare(GraphicsParticlesShaderComposition &p_composition)
			{
				if (p_composition.vaoComposition.positions != vaoComposition.positions)
					return false;
				if (p_composition.vaoComposition.axes != vaoComposition.axes)
					return false;
				if (p_composition.vaoComposition.color != vaoComposition.color)
					return false;
				if (p_composition.vaoComposition.textures != vaoComposition.textures)
					return false;

				if (p_composition.sortType != sortType)
					return false;

				if (p_composition.transformType != transformType)
					return false;

				if (p_composition.animationOptions.alpha != animationOptions.alpha)
					return false;
				if (p_composition.animationOptions.radius != animationOptions.radius)
					return false;
				if (p_composition.animationOptions.life != animationOptions.life)
					return false;
				if (p_composition.animationOptions.position != animationOptions.position)
					return false;

				if (p_composition.postProcessOptions.useFade != postProcessOptions.useFade)
					return false;
				if (p_composition.postProcessOptions.useGamma != postProcessOptions.useGamma)
					return false;
				if (p_composition.postProcessOptions.useGrayScale != postProcessOptions.useGrayScale)
					return false;

				return true;
			}
		};
		// particles
		////////////

		////////////
		// polygons
		public class GraphicsNativePolygonComposition
		{
		public:
			bool vertices; // all particle systems need this
			bool colors; // with alpha
			bool textures; // are textures being used or are they just polygons?
			int texCoordQty;
			// todo: what about radius only?  using default up and left for axes?

			GraphicsNativePolygonComposition()
			{
				vertices = true;
				colors = true;
				textures = true;
				texCoordQty = 4; // by default
			}
		};

		public class GraphicsPolygonShaderComposition
		{
		public:
			GraphicsNativePolygonComposition vaoComposition; // what elements make up the data buffer?

			GraphicsShaderCompositionCheckSum GetCompositionCheckSum() // same checksum structure as main shader
			{
				GraphicsShaderCompositionCheckSum checkSum;
				checkSum.Initialize();

				// main composition
				if (vaoComposition.vertices == true)
				{
					checkSum.result1 += 1;
				}
				if (vaoComposition.colors == true)
				{
					checkSum.result1 += 2;
				}
				if (vaoComposition.texCoordQty == 2)
				{
					checkSum.result1 += 4;
				}
				if (vaoComposition.texCoordQty == 4)
				{
					checkSum.result1 += 8;
				}
				if (vaoComposition.textures == true)
				{
					checkSum.result1 += 16;
				}

				return checkSum;
			}

			bool Compare(GraphicsPolygonShaderComposition &p_composition)
			{
				if (p_composition.vaoComposition.vertices != vaoComposition.vertices)
					return false;
				if (p_composition.vaoComposition.colors != vaoComposition.colors)
					return false;
				if (p_composition.vaoComposition.texCoordQty != vaoComposition.texCoordQty)
					return false;
				if (p_composition.vaoComposition.textures != vaoComposition.textures)
					return false;

				return true;
			}
		};
		// polygons
		////////////

		////////////
		// post processing

		enum class GraphicsMotionBlurModeEnum
		{
			None = 0,
			CameraOnly = 1,
			CameraAndFragmentVelocity = 2
		};

		class GraphicsPostProcessShaderComposition
		{
		public:
			bool noOptions; // just a simple copy, texture to output

			// which operations are we performing on the screen texture while rendering to the view buffer?
			// if all false, jsut perform a direct copy (FragColor = texture(tex,uv))
			// two-pass - one or the other, never both
			bool blurHorizontal; // full screen blur, uniform throughout
			bool blurVertical; // full screen blur, uniform throughout
			// two-pass - one or the other, never both
			bool focusByDistance; // distance formula in focus code
			bool focusHorizontal; // selective depth-bases blur for depth of field
			bool focusVertical; // selective depth-bases blur for depth of field
			bool lens; // distort the scene in a curve
			bool fade; // fade to color
			bool grayScale; // fade to grayscale
			bool gamma; // brighten scene

			bool vector2dDebug; // ignore all processing and display the contents of the buffer
			bool vector3dDebug;

			GraphicsMotionBlurModeEnum motionBlurMode;

			GraphicsPostProcessShaderComposition()
			{
				noOptions = true;

				blurHorizontal = false;
				blurVertical = false;
				focusByDistance = false;
				focusHorizontal = false;
				focusVertical = false;
				gamma = false;
				lens = false;
				fade = false;
				grayScale = false;

				vector2dDebug = false;
				vector3dDebug = false;

				motionBlurMode = GraphicsMotionBlurModeEnum::None;
			}

			GraphicsShaderCompositionCheckSum GetCompositionCheckSum() // same checksum structure as main shader
			{
				GraphicsShaderCompositionCheckSum checkSum;
				checkSum.Initialize();

				if (vector2dDebug == true)
				{
					checkSum.result2 = 1;
				}
				else if (vector3dDebug == true)
				{
					checkSum.result2 = 2;
				}
				// else the other debugs
				else
				{
					// main composition
					if (blurHorizontal == true)
					{
						checkSum.result1 += 1;
					}
					if (blurVertical == true)
					{
						checkSum.result1 += 2;
					}
					if (focusByDistance == true)
					{
						checkSum.result1 += 4;
					}
					if (focusHorizontal == true)
					{
						checkSum.result1 += 8;
					}
					if (focusVertical == true)
					{
						checkSum.result1 += 16;
					}
					if (gamma == true)
					{
						checkSum.result1 += 32;
					}
					if (lens == true)
					{
						checkSum.result1 += 64;
					}
					if (fade == true)
					{
						checkSum.result1 += 128;
					}
					if (grayScale == true)
					{
						checkSum.result1 += 256;
					}

					switch (motionBlurMode)
					{
					case GraphicsMotionBlurModeEnum::None:
						// no value
						break;
					case GraphicsMotionBlurModeEnum::CameraOnly:
						checkSum.result1 += 512;
						break;
					case GraphicsMotionBlurModeEnum::CameraAndFragmentVelocity:
						checkSum.result1 += 1024;
						break;
					}

					// next: 2048
				} // no debugging

				if ((checkSum.result1 != 0 && checkSum.result2 != 0) && noOptions == true)
					throw gcnew Exception("Resulting checksum != 0 when no options were determined!");

				return checkSum;
			}

			bool Compare(GraphicsPostProcessShaderComposition &p_composition)
			{
				// if debugging, only check those
				if (vector2dDebug == true)
					return (p_composition.vector2dDebug == vector2dDebug);
				if (vector3dDebug == true)
					return (p_composition.vector3dDebug == vector3dDebug);

				// normal check
				if (p_composition.blurHorizontal != blurHorizontal)
					return false;
				if (p_composition.blurVertical != blurVertical)
					return false;
				if (p_composition.focusByDistance != focusByDistance)
					return false;
				if (p_composition.focusHorizontal != focusHorizontal)
					return false;
				if (p_composition.focusVertical != focusVertical)
					return false;
				if (p_composition.gamma != gamma)
					return false;
				if (p_composition.lens != lens)
					return false;
				if (p_composition.fade != fade)
					return false;
				if (p_composition.grayScale != grayScale)
					return false;
				if (p_composition.motionBlurMode != motionBlurMode)
					return false;

				return true;
			}
		};

		// all data necessary to make post process operations work
		// it's assumed that all textures involved are identical in similarity if not in size, so texcoords correspond entirely to each other
#define MAX_BLUR_KERNEL_ELEMENT_QTY 6
		class GraphicsPostProcessShaderOptions
		{
		public:
			float *blurKernelRef; // 2-4 values used to weight surrounding pixels, starting from center and working out (corresponds to 3x3 to 7x7 blur kernel)
			// let implementation calculate this kernel and hold it so that this class doesn't ened to calcualte it every render
			// note: kernel values do not have to represent a grid that entirely sums to one.  Instead, total them up and set blurKernelValueTotal
			float blurKernelValueTotal; // after fragments are weighted, divide by this value so taht they all add up to 1
			// note: the
			int kernelElementQty; // 2-4
			// how many pixels to go for blurring (not including the center), only of these gets set since blur is two-pass, once in each direction
			// scaling of texture access for blurring
			float blurScaleS; // if != 0.0f, blur Horizontal
			float blurScaleT; // if != 0.0f, blur Vertical
			// note: whena  scale is 1/0f / the size of the texture in that dimension, it will be blurred as many pixels out as the kernel qty.  Less than that amount tightens the blur
			//   witht eh same number of samples.  Greater than that amount will still blur but might have 'gaps' per se in the accuracy of the result.
			// so ultimately, the number of kernal elements shoudl be balanced with the scale chosen to get the fastest blur (fewest possible samples) for the desired radius (element qty + scale)
			// ideally, scale will always be 1.0f / the size of the texture in that dimension but can stand a small level of tweaking to prevent having a lot of kernels or larger ones.

			// either blur or focus depth of field is used, never both)
			// use blur
			bool blur;
			
			// use focus (depth of field)
			// one options or the other
			bool focusByDepth; // focuses at a specific depth for a quicker longer lens calculation
			bool focusByDistance; // focuses on a specific point, blurs everything around it, good for zooming in on something tiny
			// between focusHighDepthRangeMin and focusLowDepthRangeMax, there will be no blur.
			// higher than focusHighDepthRangeMax or lower then focusLowDepthRangeMin, max blur
			// max blur determined by kernel
			// blurs horizontally or vertically depending on kernel settings.
			// Depth and Distance are the same here, depending on which focus option used.
			float focusHighDepthRangeMin;
			float focusHighDepthRangeMax;
			float focusLowDepthRangeMin;
			float focusLowDepthRangeMax;
			// todo: transformation values that allow shader to convert tex coords and depth to distance (only needed when focusByDistance used)
			// ??
			
			Matrix4d *mvpMatrixRef;
			// textures to work with for blurring, and depthTexture for depth of field blurring
			gcroot<GameTexture^> srcTextureRef;
			//gcroot<GameTexture^> dstTextureRef; // no!!!  Dst is just the framebuffer the API is currently bound to render to!! We don't need this here!
			gcroot<GameTexture^> depthTextureRef;

			//bool motionBlur;
			// todo: old and new matrix, blur factor for severity
			// todo: movement blurring vs. viewpoint rotation blurring

			float lens; // 1.0 = none, > 1.0 widens center, < 1.0 compresses it
			// center, shape (elliptical, circular), warp factor (+[center expands to become larger] or -[center retracts and sides become larger])?  to be determined
			// lens shape and toggling between + and - can be used to simulate a vibrating screen, like tapping a suspended drop of water

			float fadeFactor; // 0.0f none, 1.0f full
			GameColor *fadeColorRef;

			float grayScale; // 0.0f none, 1.0f full

			float gamma; // 1.0f is normal.  > 1.0f brighten  2.0f acceptable max

			GraphicsMotionBlurModeEnum motionBlurMode;
			Matrix4d *motionBlurPriorCurrentInverseMvpMatrixRef;
			gcroot<GameTexture^> motionBlurFragmentVelocityTextureRef; // 3d data (xy = unit, z = magnitude)
			int motionBlurSamples; // samples in each direction, so 3 results in 7 samples total (main, 3 positive and 3 negative with main in center)

			// debugging - only one allowed to be true - ignore all processing and just display the contents of the supplied buffer texture (DebugTexture)
			bool debugVector2dBuffer;
			bool debugVector3dBuffer;
			gcroot<GameTexture^> debugTextureRef;

		public:
			GraphicsPostProcessShaderOptions()
			{
				mvpMatrixRef = nullptr;
				srcTextureRef = nullptr;

				// only one of these should be set
				blur = false;
				focusByDepth = false;
				focusByDistance = false;
				// disable blurring
				blurScaleS = 0.0f;
				blurScaleT = 0.0f;

				srcTextureRef = nullptr;
				//dstTextureRef = nullptr; // no!  We don't need this!
				depthTextureRef = nullptr;

				// todo
				lens = 1.0f;

				// applied after blurring
				fadeFactor = 0.0f;
				fadeColorRef = nullptr;

				// applied next to last
				grayScale = 0.0f;

				// applied after EVERYTHING
				gamma = 1.0f;

				motionBlurMode = GraphicsMotionBlurModeEnum::None;
				motionBlurPriorCurrentInverseMvpMatrixRef = nullptr;
				motionBlurFragmentVelocityTextureRef = nullptr;
				motionBlurSamples = 3;

				debugVector2dBuffer = false;
				debugVector3dBuffer = false;
				debugTextureRef = nullptr;
			}
		};
		
		// post processing
		////////////

		public class GraphicsShaderLightModelviewData
		{
		public:
			// IMPORTANT: This data lines up with how the shader expects to receive it in the LightModelviewData Struct!!!!
			Vector3d modelViewPosition; // light position in SAME SPACE as the vertices being rendered
			/*
			Vector3d directionUnit;
			Vector3d sAxis; // used to convert to texcoord S
			Vector3d tAxis; // used to convert to texcoord T
			*/

			GraphicsShaderLightModelviewData()
			{
				modelViewPosition = Vector3d(0, 0, 0);
				//directionUnit = Vector3d(0, 0, 0);
				//sAxis = Vector3d(0.5f, 0, 0);
				//tAxis = Vector3d(0, 0.5f, 0);
			}
		};

		public class GraphicsShaderLight
		{
		public:
			GraphicsShaderLight()
			{
				spotlightCosineMax = 0.707f;
				directionUnitWorldReversed = Vector3d(0, 0, 1);
				sAxisWorld = Vector3d(0.5f, 0, 0);
				tAxisWorld = Vector3d(0, 0.5f, 0);
				type = GraphicsShaderCompositionLightType::Directional;
				shadowMapType = GraphicsShaderCompositionLightShadowMapType::FlatMap;
				color = Vector3d(1, 1, 1);
				worldPosition = Vector3d(0, 0, 0);
				diffuseAttenuationFactor = 0.25;
				specularAttenuationFactor = 0.125;
				spotlightTextureRef = nullptr;

				shadowMapTextureRef = nullptr;
				shadowMapFrameBufferRef = nullptr;
				//ignoreShadow = false;
				renderId = -1;

				// transformed data

				Initialize();
			}

			~GraphicsShaderLight()
			{
			}

			void Initialize()
			{
				brightness = 1.0f;
			}

			Vector3d worldPosition; // position before transforming to model space

			Vector3d color; // color at brightness 1.0
			float brightness;
			// lower attenuation means light shines farther
			float diffuseAttenuationFactor; // coefficient determining how light intensity reduces with distance (implementation needs to decide if light should be included at all - don't force shader to determine this!!!)
			float specularAttenuationFactor; // specular attenuated differently, generally slower than diffuse so that reflected light can be seen a bit farther on a surface

			GraphicsShaderCompositionLightType type; // what is it? (Point, Spotlight, SpotlightTexture, Directional)
			GraphicsShaderCompositionLightShadowMapType shadowMapType; // what code logic should it use to render? (what kind of light and what kind of shadowmap)
			Vector3d directionUnitWorldReversed; // used for spotlight, spotlight texture and directional
			Vector3d sAxisWorld; // used to convert to texcoord S
			Vector3d tAxisWorld; // used to convert to texcoord T

			// transformed data - this is used when only one mvp is sent to the shader.  otherwise there is a structure within renderoptions that holds this data for every mvp
			// todo: get rid of this after old shader code doesn't require it anymore
			GraphicsShaderLightModelviewData modelviewData;

			gcroot<GameTexture^> spotlightTextureRef; // note - no alpha needed in this texture, just color
			float spotlightCosineMax; // only if spotlight

			Matrix4d shadowMVP; // mvp used to render this light's shadow map (will need more than this for jointed figures) - unscaled for spotlights, scaled for directional to include all ortho geometry (does not include anything for scaling the models later)
			gcroot<GameTexture^> shadowMapTextureRef;
			GraphicsFrameBufferContainer *shadowMapFrameBufferRef;

			float maxAngleDegrees; // used by implementation for ligth shadow map preparation

			float intensity; // value of brightest color component (combine with brightness for meaningful use)
			float maxDistance; // approximation of max distance that light can work at (no consideration for world scale here)

			int shadowPreparationId; // id tracker to prevent a light from having its shadow prepped more than once during a scene render (up to implementation to set and use this)
			int renderId; // current scene render id to match with the currentRenderId (which increments every time the scene renderer is called - twice during anaglyph, even more when rendering mirrors -
						  // basically any time the viewpoint changes and the scene is rendered again without calling another game tick.  If a light has a shadow map and this is = the currentRenderId,
						  // the light is being parsed again and its shadowmap should be checked or updated.

			//////////////////////////////////////////
			// values that sould not be copied with Set
			LinkedList<PortalNodeIndex> shadowNodesPrepared; // nodes that are part of the shadow map for this light (clear when shadow map is cleared from this light)

			// note: after calling these, modelviewposition still needs to be transformed from world Position, as well as all the direction, sAxis and tAxis vectors.
		private:
			float LightIntensity()
			{
				float maxComponent = color.x;
				if (color.y > maxComponent)
					maxComponent = color.y;
				if (color.z > maxComponent)
					maxComponent = color.z;

				return maxComponent;
			}

			float LightMaxDistance()
			{
				if (diffuseAttenuationFactor == 0.0f || specularAttenuationFactor == 0.0f)
					return 100000.0f;

				if (diffuseAttenuationFactor < specularAttenuationFactor)
					return intensity * brightness * 1.25f / diffuseAttenuationFactor;
				else
					return intensity * brightness * 1.25f / specularAttenuationFactor;
			}

		public:

			void SetSpotlightTexture(GameTexture ^p_spotlightTexture, Vector3d &p_worldPosition, Vector3d &p_directionWorld, Vector3d &p_leftUnitWorld, Vector3d &p_upUnitWorld, float p_maxAngleDegrees, Vector3d &p_colorModulate, float p_diffuseAttenuate, float p_specularAttenuate)
			{
				// assumes square texture, only one degree supported anyway
				// when rectangular textures are supported, make angle vertical and convert to side angle based on size of texture

				if (p_maxAngleDegrees < 0.0f)
				{
					throw gcnew System::Exception("Spotlight texture max angle must be >= 0.0 degrees");
				}
				if (p_maxAngleDegrees > 89.9f)
				{
					throw gcnew System::Exception("Spotlight texture max angle must be <= 89.9 degrees");
				}
				type = GraphicsShaderCompositionLightType::SpotlightTexture;
				worldPosition = p_worldPosition;
				spotlightTextureRef = p_spotlightTexture;
				spotlightCosineMax = cos(MathUtilities::DegreesToRadians(p_maxAngleDegrees)); // not used, not sent to shader, instead calc s and t and test for 0.0-1.0 range
				float factor = tan(MathUtilities::DegreesToRadians(p_maxAngleDegrees)); // offset to light will be projected to 1.0 out along direction then dot multipled with sAxis and tAxis

				directionUnitWorldReversed = p_directionWorld.ScalarMult(-1.0f); // reverse it for the shader
				directionUnitWorldReversed.Normalize();
				// This will be dot multiplied with offsetProjectedToOne to get -0.5 to 0.5, to be added to 0.5 to get a tex coordinate for s and t
				sAxisWorld = p_leftUnitWorld.ScalarMult(1.0f / (2.0f * factor)); // positive because was negative to get -0.5 to the left (texture coordinate), but negative again because offsetUnit in shader is pointing backwards, so positive
				tAxisWorld = p_upUnitWorld.ScalarMult(1.0f / (2.0f * factor));

				color = p_colorModulate;
				diffuseAttenuationFactor = p_diffuseAttenuate;
				specularAttenuationFactor = p_specularAttenuate;

				maxAngleDegrees = p_maxAngleDegrees;
				if (maxAngleDegrees <= 45.0f)
					shadowMapType = GraphicsShaderCompositionLightShadowMapType::FlatMap;
				else
					shadowMapType = GraphicsShaderCompositionLightShadowMapType::CubeMap;

				intensity = LightIntensity();
				maxDistance = LightMaxDistance();
			}

			void SetSpotlight(Vector3d &p_worldPosition, Vector3d &p_directionWorld, float p_maxAngleDegrees, Vector3d &p_color, float p_diffuseAttenuate, float p_specularAttenuate)
			{
				if (p_maxAngleDegrees < 0.0f)
				{
					throw gcnew System::Exception("Spotlight texture max angle must be >= 0.0 degrees");
				}
				if (p_maxAngleDegrees > 180.0f)
				{
					throw gcnew System::Exception("Spotlight texture max angle must be <= 180.0 degrees");
				}
				type = GraphicsShaderCompositionLightType::Spotlight;
				worldPosition = p_worldPosition;
				spotlightCosineMax = cos(MathUtilities::DegreesToRadians(p_maxAngleDegrees));

				directionUnitWorldReversed = p_directionWorld.ScalarMult(-1.0f); // reverse it for the shader
				directionUnitWorldReversed.Normalize();
				color = p_color;
				diffuseAttenuationFactor = p_diffuseAttenuate;
				specularAttenuationFactor = p_specularAttenuate;

				maxAngleDegrees = p_maxAngleDegrees;
				if (maxAngleDegrees <= 45.0f)
					shadowMapType = GraphicsShaderCompositionLightShadowMapType::FlatMap;
				else
					shadowMapType = GraphicsShaderCompositionLightShadowMapType::CubeMap;

				intensity = LightIntensity();
				maxDistance = LightMaxDistance();
			}

			void SetDirectional(Vector3d &p_directionWorld, Vector3d &p_color)
			{
				type = GraphicsShaderCompositionLightType::Directional;

				directionUnitWorldReversed = p_directionWorld.ScalarMult(-1.0f); // reverse it for the shader
				directionUnitWorldReversed.Normalize();
				color = p_color;
				shadowMapType = GraphicsShaderCompositionLightShadowMapType::FlatMap;

				intensity = LightIntensity();
				maxDistance = 100000.0f;
			}

			void SetPoint(Vector3d &p_worldPosition, Vector3d p_color, float p_diffuseAttenuate, float p_specularAttenuate)
			{
				type = GraphicsShaderCompositionLightType::Point;

				worldPosition = p_worldPosition;
				color = p_color;
				diffuseAttenuationFactor = p_diffuseAttenuate;
				specularAttenuationFactor = p_specularAttenuate;
				shadowMapType = GraphicsShaderCompositionLightShadowMapType::CubeMap;

				intensity = LightIntensity();
				maxDistance = LightMaxDistance();
			}

			// set equal to another light
			void Set(GraphicsShaderLight &p_light)
			{
				worldPosition = p_light.worldPosition;
				color = p_light.color;
				brightness = p_light.brightness;
				diffuseAttenuationFactor = p_light.diffuseAttenuationFactor;
				specularAttenuationFactor = p_light.specularAttenuationFactor;
				type = p_light.type;
				shadowMapType = p_light.shadowMapType;
				directionUnitWorldReversed = p_light.directionUnitWorldReversed;
				sAxisWorld = p_light.sAxisWorld;
				tAxisWorld = p_light.tAxisWorld;
				spotlightTextureRef = p_light.spotlightTextureRef;
				spotlightCosineMax = p_light.spotlightCosineMax;
				shadowMapTextureRef = p_light.shadowMapTextureRef;
				shadowMapFrameBufferRef = p_light.shadowMapFrameBufferRef;
				shadowMVP = p_light.shadowMVP;
				maxAngleDegrees = p_light.maxAngleDegrees;

				// this isn't really needed since shadow map prep is done at the implementation light level
				shadowPreparationId = p_light.shadowPreparationId;

				intensity = p_light.intensity;
				maxDistance = p_light.maxDistance;
			}

			// build frustum that represents light's view and effect for portal use
			// note: even though cubemaps will be used for spotlights > 45 degrees, we can still build an actual frustum for deciding which nodes to render for the light's shadowmap, so
			//   don't create a cubemap frustum for angles > 45 degrees
			void MakeFrustum(Frustum &p_frustum, Vector3d *p_originOverride = nullptr)
			{
				p_frustum.Initialize();
				if (p_originOverride == nullptr)
					p_frustum.SetOrigin(worldPosition);
				else
					p_frustum.SetOrigin(*p_originOverride);
				if (type == GraphicsShaderCompositionLightType::Point)
					return; // leave null, faces in all directions
				if (type == GraphicsShaderCompositionLightType::Spotlight)
				{
					// if angle is zero, there is no frustum
					if (spotlightCosineMax == 1.0f)
					{
						p_frustum.Empty();
						return;
					}

					Orient3d spotlightOrient;

					// build frustum out of max angle and direction
					// need a vertical and horizontal axis - orientation does NOT matter.
					spotlightOrient.f = directionUnitWorldReversed.ScalarMult(-1.0f);
					spotlightOrient.l = Vector3d(directionUnitWorldReversed.z, 0.0f, -directionUnitWorldReversed.x);
					if (spotlightOrient.l.Normalize() == false)
					{
						// vertical direction
						spotlightOrient.l = Vector3d(1, 0, 0);
					}
					spotlightOrient.u = spotlightOrient.f.CrossProd(spotlightOrient.l); // u = f x l
					spotlightOrient.p = worldPosition;
					float sideAxisFactor = sqrt(1.0f - (spotlightCosineMax * spotlightCosineMax));

					// now we have a set of coordinates.  Make a frustum.
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(sideAxisFactor) + spotlightOrient.l.ScalarMult(spotlightCosineMax));
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(sideAxisFactor) + spotlightOrient.u.ScalarMult(spotlightCosineMax));
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(sideAxisFactor) - spotlightOrient.l.ScalarMult(spotlightCosineMax));
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(sideAxisFactor) - spotlightOrient.u.ScalarMult(spotlightCosineMax));
				}
				else if (type == GraphicsShaderCompositionLightType::SpotlightTexture)
				{
					// if angle is zero, there is no frustum
					if (spotlightCosineMax == 1.0f)
					{
						p_frustum.Empty();
						return;
					}

					Orient3d spotlightOrient;

					// build frustum out of direction, sAxis and tAxis
					// need a vertical and horizontal axis - orientation must match the square shape of the texture
					spotlightOrient.f = directionUnitWorldReversed.ScalarMult(-1.0f);
					spotlightOrient.l = sAxisWorld;
					spotlightOrient.l.Normalize();
					spotlightOrient.u = tAxisWorld;
					spotlightOrient.u.Normalize();
					// remember, s and t axis are 1/2 because they are used to calculate texture coordinates (-0.5 to 0.5 on each side), so double to get actual length, and they are inverse
					float lAxisfactor = 1.0f / (sAxisWorld.Magnitude() * 2.0f);
					float uAxisfactor = 1.0f / (tAxisWorld.Magnitude() * 2.0f);

					// now we have a set of coordinates.  Make a frustum.
					// axisfactor for f is always 1.0 so just add l and u
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(lAxisfactor) + spotlightOrient.l);
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(uAxisfactor) + spotlightOrient.u);
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(lAxisfactor) - spotlightOrient.l);
					p_frustum.AddPlane(spotlightOrient.f.ScalarMult(uAxisfactor) - spotlightOrient.u);
				}
				else
				{
					// will need an origin point for each new plane.  Otherwise the insertion of the plane and its logic for containing other planes stands.
					throw gcnew System::Exception("Directional Light not yet supported for frustums");
				}
			}
		};

		typedef GraphicsShaderLight * GraphicsShaderLightPtr; // for linked list use

		class GraphicsShaderLightTallyNode
		{
		public:
			GraphicsShaderLightPtr lightRef;
			float precedenceValue; // lower is more important

			GraphicsShaderLightTallyNode()
			{
				// for linked list header and footer
			}

			GraphicsShaderLightTallyNode(GraphicsShaderLight *p_lightRef, float p_precedenceValue)
			{
				lightRef = p_lightRef;
				precedenceValue = p_precedenceValue;
			}

		};

		// standard set of data to prepare for a native object to render, supporting up to 100 joints
		class GraphicsNativeObjectRenderOptionsTransformData
		{
		public:
			Orient3dSimple orients[100]; // corresponding world orients used to calculate camera and light positions (for uploading to uniforms as array of vectors)

			GraphicsNativeObjectRenderOptionsTransformData()
			{
			}

			Orient3dSimple * GetOrients()
			{
				return &orients[0];
			}
		};

		public class GraphicsShaderMaterial
		{
		public:
			Vector3d diffuseReflectivity;
			Vector3d ambientReflectivity;
			Vector3d specularReflectivity;
			float shininess; // 0 to 128 usually
			float alphaSpecularFactor; // 0.0 means alpha does nothing to it, 1.0 means alpha is fully considered (note: final alpha after texture multiplication)

			GraphicsShaderMaterial()
			{
				alphaSpecularFactor = 0.0f; // default - alpha does not affect specular (alpha should affect specular for a faded object or holes in a texture, not on a solid invisible or barely visible surface)
			}
		};

		// render-time options
		public ref class GraphicsShaderOptions
		{
		public:
			// each required
			int vertexShaderOperation;
			int fragmentShaderOperation;

			// optional depending on vertex shader
			Matrix4d *modelViewMatrixRef;
			Matrix4d *projectionMatrixRef;
			Matrix4d *eyeMVPMatrixRef;
			Orient3d *modelWorldOrientRef; // a single orient3d fit for uploading into a shader uniform (copy 48 bytes, or 4 vec3s ONLY - ignore the normalization counter)

			// optional, depending on fragment shader, also serve as overrides
			GameTexture ^ texture0Ref; // texture 0 populated first, then 2, 3, 4.  
			GameTexture ^ texture1Ref;
			GameTexture ^ texture2Ref;
			GameTexture ^ texture3Ref;
			GameTexture ^textureSpecularMapRef;
			GameTexture ^textureBlendMapRef; // independent from texture 1-4.  Blends in order on r(1), g(2), b(3), a(4) so that a appears topmost.  if 3 and 4 are null for example, only 1 and 2 are blended using r and g.
			bool vertexBlend; // should blend map be accessed at the vertex level and passed to fragment? (good for low resolution blend maps)
			GameTexture ^textureBumpMapRef;

			GameColor *singleColorRef;

			bool lighting; // are we using lighting at all?
			float vertexScale; // use when scaling an object - same scale per axis for now
			bool vertexLighting; // is the lighting per-vertex or fragment? (fragment is slower but looks much better on large polygons) - determines shader
			Vector3d *ambientLightRef;
			GraphicsShaderMaterial *lightingMaterialRef;
			Vector3d *cameraPositionRef; // in object space
			bool shadowMaps;
			int useHighShadowBias;

			bool darkvision;
			float darkvisionWorldRange;
			Vector3d *darkvisionSourcePositionRef;

			float grayScale; // 0.0 to 1.0 - 0.0 is no grayscale, 1.0 is full grayscale

			GraphicsShaderSilhouetteEnumType silhouetteType;
			GameColor *silhouetteColorRef;

			Matrix4d *pointLightCubeMVPRef; // array of 6 MVPs on each axis ONLY for rendering to the cube shadow map - for the final render, only light position is needed - this can remain null
			// order is +x, -x, +y, -y, +z, -z, same order as in OpenGL
			Vector3d *pointLightPositionRef; // position of light for render to cube shadow map

			GraphicsShaderLightPtr *lightRefs; // pointer to light array - array is an array of light pointers so that implementation lights don't need to be copied
			int lightQty; // if 0, no lights - quantity determines shader

			float gamma; // 1.0 means ignore, 2.0-2.4 is usual (higher number means brighter)

			float fade; // 0.0-1.0
			GameColor *fadeColorRef;

			GraphicsNativeObjectRenderOptionsTransformData *transformDataRef; // multiple joint mvp, light position and camera position data

			// drawbuffer usage - indeices correspond to drawbufferformats of selected framebuffer (not supported when selected framebuffer is nullptr (main))
			// if null, assume only 1 draw buffer is selected and its format is RGB (usage will be Standard).  If any of this is not the case, exception in render
			GraphicsAttachedFrameBufferUsageEnum *drawBuffersUsageArrayRef;

			Matrix4d *motionBlurScreenOffsetPriorMVPMatrixRef;

			GraphicsShaderOptions()
			{
				texture0Ref = nullptr;
				texture1Ref = nullptr;
				texture2Ref = nullptr;
				texture3Ref = nullptr;
				textureBlendMapRef = nullptr;
				vertexBlend = false;
				textureBumpMapRef = nullptr;

				singleColorRef = nullptr;

				vertexShaderOperation = GraphicsVertexShaderOperationEnum::None;
				fragmentShaderOperation = GraphicsFragmentShaderOperationEnum::None;

				modelViewMatrixRef = nullptr;
				projectionMatrixRef = nullptr;
				eyeMVPMatrixRef = nullptr;
				modelWorldOrientRef = nullptr; // orientation of model in world space - used to transform lights in shader

				lighting = false;
				ambientLightRef = nullptr;
				lightingMaterialRef = nullptr;
				lightRefs = nullptr;
				lightQty = 0;
				shadowMaps = false;
				vertexScale = 1.0f;
				useHighShadowBias = 0;

				darkvision = false;
				darkvisionSourcePositionRef = nullptr;

				transformDataRef = nullptr;

				silhouetteType = GraphicsShaderSilhouetteEnumType::Normal;
				silhouetteColorRef = nullptr;

				pointLightCubeMVPRef = nullptr;

				gamma = 1.0f; // default ignore

				drawBuffersUsageArrayRef = nullptr;

				// other usages
				// MotionBlurScreenOffset (Vector3d buffer)
				motionBlurScreenOffsetPriorMVPMatrixRef = nullptr;
			}
		};

		// particles
		class GraphicsNativeParticlesDefaultOptions
		{
		public:
			// if null, use default.  If not null, ignore if element was provided
			// currently, colors, alpha and radius will always be provided
			GameColor *singleColor;  // storage - delete it
			float *singleAlpha;
			float *singleRadius;

			gcroot<GameTexture ^> textures[8]; // references. DO NOT DESTROY

			GraphicsNativeParticlesDefaultOptions()
			{
				singleColor = nullptr;
				singleAlpha = nullptr;
				singleRadius = nullptr;
				for (int i = 0; i < 8; i++)
					textures[i] = nullptr;
			}
			
			~GraphicsNativeParticlesDefaultOptions()
			{
				if (singleColor != nullptr)
					delete singleColor;
			}
		};

		// assumes an array storage of floats
		// leave offsets as -1 to not use
		class GraphicsParticlesStorageOptions
		{
		public:
			int storageSize; // full stride
			int positionXOffset;
			int positionYOffset;
			int positionZOffset;
			int colorROffset;
			int colorGOffset;
			int colorBOffset;
			int colorAOffset;
			int textureIdOffset; // actually an int
			int rotationAxisLXOffset;
			int rotationAxisLYOffset;
			int rotationAxisUXOffset;
			int rotationAxisUYOffset;

			// default for now
			GraphicsParticlesStorageOptions()
			{
				storageSize = 12;
				positionXOffset = 0;
				positionYOffset = 1;
				positionZOffset = 2;
				colorROffset = 3;
				colorGOffset = 4;
				colorBOffset = 5;
				colorAOffset = 6;
				textureIdOffset = 7; // actually an int
				rotationAxisLXOffset = 8;
				rotationAxisLYOffset = 9;
				rotationAxisUXOffset = 10;
				rotationAxisUYOffset = 11;
			}
		};

		// used for rendering, contains only references, different from GraphicsNativeParticleDefaultOptions - also has slots for mvpMatrix, viewpoint axes, etc.
		class GraphicsShaderParticlesOptions
		{
		public:
			int particleQty; // how many should we render, starting with element 0?  This is required.

			GameColor *singleColorRef; // if null, use default.  If not null, ignore if colors where provided - this is a reference - DO NOT DESTROY
			float *singleRadiusRef;
			float *singleAlphaRef;

			// viewpoint
			Matrix4d *mvpMatrixRef;

			// viewpoint axes along left and up axes - for particle polygon generation in shader
			Vector3d *leftVPAxisRef;
			Vector3d *upVPAxisRef;
			float minimumZ; // below this Z, don't render (only used in particle queues)

			gcroot<GameTexture ^> textures[8]; // references. DO NOT DESTROY

			// post processing
			float fade;
			GameColor *fadeColorRef;
			float grayScale;
			float gamma;
			// todo: incorporate darkvision only when lighting is used, for occlusive particles only, not emittive/additive ones

			GraphicsShaderParticlesOptions()
			{
				particleQty = 0;

				singleColorRef = nullptr;
				singleAlphaRef = nullptr;
				singleRadiusRef = nullptr;
				for (int i = 0; i < 8; i++)
					textures[i] = nullptr;

				mvpMatrixRef = nullptr;
				leftVPAxisRef = nullptr;
				upVPAxisRef = nullptr;

				minimumZ = 0.01f;  // only used in particle queues

				fade = 0.0f;
				fadeColorRef = nullptr;
				grayScale = 0.0f;
				gamma = 1.0f;
			}
		};

		/////////////////
		// Polygon queue
		class GraphicsPolygonQueueStorageOptions
		{
		public:
			int storageSize; // full stride
			int vertexXOffset;
			int vertexYOffset;
			int vertexZOffset;
			int texCoordSOffset; // gl format.  always store 4 coords since we may render with a relevant r or q
			int texCoordTOffset;
			int texCoordROffset;
			int texCoordQOffset;
			int colorROffset;
			int colorGOffset;
			int colorBOffset;
			int colorAOffset;
			int textureIdOffset; // actually an int

			// default for now
			GraphicsPolygonQueueStorageOptions()
			{
				vertexXOffset = 0;
				vertexYOffset = 1;
				vertexZOffset = 2;
				texCoordSOffset = 3;
				texCoordTOffset = 4;
				texCoordROffset = 5;
				texCoordQOffset = 6;
				colorROffset = 7;
				colorGOffset = 8;
				colorBOffset = 9;
				colorAOffset = 10;
				textureIdOffset = 11; // actually an int

				storageSize = 12;
			}
		};

		class GraphicsPolygonQueue
		{
		public:
			float *triangleStorage;
			int arraySize; // multiple of 3 since we are storing triangles
			void *nativePolygonQueueRef;
			int triangleQty; // triangle quantity (vertexQty is *3)
			GraphicsPolygonQueueStorageOptions storageOptions;
			bool firstRender; // if first render, create full buffer, otherwise update first n elements

			GraphicsPolygonQueue()
			{
				triangleStorage = nullptr;
				nativePolygonQueueRef = nullptr;
				firstRender = true;
				triangleQty = 0;
				arraySize = 0;
			}

			~GraphicsPolygonQueue()
			{
				if (triangleStorage != nullptr)
					throw gcnew Exception("Triangle storage not deallocated - graphics resources must be destroyed before game resources are destroyed");
				if (nativePolygonQueueRef != nullptr)
					throw gcnew Exception("Native polygon queue object not deallocated - graphics resources must be destroyed before game resources are destroyed");
			}

			bool IsCreated()
			{
				return (nativePolygonQueueRef != nullptr);
			}
		};

		typedef GraphicsPolygonQueue * GraphicsPolygonQueuePtr;

		class GraphicsShaderPolygonOptions
		{
		public:
			gcroot<GameTexture^> textures[8];
			int textureQty;
		private:
			int maxTextureQty;

		public:
			Matrix4d *mvpMatrixRef;

			GraphicsShaderPolygonOptions()
			{
				maxTextureQty = 8;
				ResetTextures();
				mvpMatrixRef = nullptr;
			}

			void AddTexture(GameTexture ^p_texture)
			{
				if (TexturesAreFull())
					throw gcnew Exception("Texture Qty already at max");

				textures[textureQty] = p_texture;
				textureQty++;
			}

			int GetTextureIndex(GameTexture ^p_texture)
			{
				for (int i = 0; i < textureQty; i++)
				{
					if (static_cast<GameTexture^>(textures[i]) == p_texture)
						return i;
				}

				return -1; // not found
			}

			// Clear for new set of polygons to render
			void ResetTextures()
			{
				for (int i = 0; i < maxTextureQty; i++)
				{
					textures[i] = nullptr;
				}
				textureQty = 0;
			}

			bool TexturesAreFull()
			{
				return (textureQty >= maxTextureQty);
			}
		};

		// structure used to help tally lights for rendering out of many available - implementation must assign a precedence to each light
		class GraphicsShaderLightTally
		{
		public:
			LinkedList<GraphicsShaderLightTallyNode> lights;
			int maxLightQty;
			int lightQty;

			GraphicsShaderLightTally(int p_maxLightQty)
			{
				maxLightQty = p_maxLightQty;
				lightQty = 0;
			}

			GraphicsShaderLightTally()
			{
				maxLightQty = 0;
				lightQty = 0;
			}

			void Clear()
			{
				lights.Clear();
				lightQty = 0;
			}

			void SetMaxLights(int p_maxLightQty)
			{
				maxLightQty = p_maxLightQty;
			}

			bool LightIsInList(void *p_lightRef)
			{
				LinkedListEnumerator<GraphicsShaderLightTallyNode> lightEnumerator = LinkedListEnumerator<GraphicsShaderLightTallyNode>(lights);
				while (lightEnumerator.MoveNext())
				{
					if (lightEnumerator.Current()->data.lightRef == p_lightRef)
					{
						return true;
					}
				}
				return false;
			}

			LinkedListEnumerator<GraphicsShaderLightTallyNode> GetEnumerator()
			{
				return LinkedListEnumerator<GraphicsShaderLightTallyNode>(lights);
			}

			void TallyLight(GraphicsShaderLightPtr p_lightRef, float p_precedenceValue)
			{
				if (maxLightQty == 0)
					// no lights allowed
					return;

				// if no way this will insert, leave
				if (lightQty == maxLightQty && lights.GetLastNode()->data.precedenceValue <= p_precedenceValue)
					return;

				// if light is already in list, do nothing
				// we don't actualy need this if implementation avoids calling this more than once for the same light, so removing this might speed things up
				if (LightIsInList(p_lightRef) == true)
					return;

				LinkedListEnumerator<GraphicsShaderLightTallyNode> lightEnumerator = LinkedListEnumerator<GraphicsShaderLightTallyNode>(lights);
				int index = 0;
				bool inserted = false;
				while (lightEnumerator.MoveNext())
				{
					if (lightEnumerator.Current()->data.precedenceValue > p_precedenceValue)
					{
						// insert node
						LinkedListNode<GraphicsShaderLightTallyNode> *newNode = lights.GetNewNode();
						newNode->data.lightRef = p_lightRef;
						newNode->data.precedenceValue = p_precedenceValue;
						if (index == 0)
							lights.InsertNode(newNode); // put first in list
						else
							lights.InsertNode(newNode, lightEnumerator.Current()->prev); // second or later
						inserted = true;
						lightQty++;

						// maintain max size of list
						while (lightQty > maxLightQty)
						{
							lights.DeleteNode(lights.GetLastNode());
							lightQty--;
						}

						break;
					}

					index++;
				}
				// if wasn't inserted, put it at the end if we have room
				if (inserted == false && lightQty < maxLightQty)
				{
					LinkedListNode<GraphicsShaderLightTallyNode> *newNode = lights.GetNewNode();
					newNode->data.lightRef = p_lightRef;
					newNode->data.precedenceValue = p_precedenceValue;
					lights.AddNode(newNode);
					lightQty++;
				}
			}

			// add light without regard to any tallying based on precedence
			// usually used to copy over an already prepped list of lights with no plans to tally based on precedence for this iteration
			void AddLight(GraphicsShaderLightPtr p_lightRef)
			{
				if (lightQty < maxLightQty)
				{
					LinkedListNode<GraphicsShaderLightTallyNode> *newNode = lights.GetNewNode();
					newNode->data.lightRef = p_lightRef;
					newNode->data.precedenceValue = -1; // doesn't matter when using Add
					lights.AddNode(newNode);
					lightQty++;
				}
			}

			// implementation is responsible for prepping any shadow maps before the render
			void SetLightsInShaderOptions(GraphicsShaderOptions %p_shaderOptions)
			{
				int index = 0;
				bool breakOut = false;
				// sort by type to reduce shader composition permutations
				for (int i = 0; i < 6; i++)
				{
					LinkedListEnumerator<GraphicsShaderLightTallyNode> lightEnumerator = LinkedListEnumerator<GraphicsShaderLightTallyNode>(lights);
					while (lightEnumerator.MoveNext())
					{
						bool valid = false;
						// more common ones first so that less time is spent in this loop (it can detect when we have max lights, and when that is true, we know we are done and the rest don't need checking)
						switch (i)
						{
						case 0:
							if (lightEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::Point) // always cube
								valid = true;
							break;
						case 1:
							if (lightEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::Spotlight && lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
								valid = true;
							break;
						case 2:
							if (lightEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::SpotlightTexture && lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
								valid = true;
							break;
						case 3:
							if (lightEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::Spotlight && lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
								valid = true;
							break;
						case 4:
							if (lightEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::SpotlightTexture && lightEnumerator.Current()->data.lightRef->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
								valid = true;
							break;
						case 5:
							if (lightEnumerator.Current()->data.lightRef->type == GraphicsShaderCompositionLightType::Directional) // always flat
								valid = true;
							break;
						}

						if (valid == true)
						{
							p_shaderOptions.lightRefs[index] = lightEnumerator.Current()->data.lightRef;
							index++;
							// stop early if we have all of our lights
							if (index == lightQty)
							{
								break;
							}
						}
					}

					// stop early if we have all of our lights
					if (index == lightQty)
					{
						break;
					}
				}
				p_shaderOptions.lightQty = index;
			}
		};


		// base class meant to hold a native object specific to a rendering API (OpenGL, DirectX)
		class GraphicsNativeObjectBase
		{

		};
		class GraphicsNativeObjectContainer
		{
		public:
			GraphicsNativeObjectBase *nativeObjectRef;

			GraphicsNativeObjectContainer()
			{
				nativeObjectRef = nullptr;
			}

			~GraphicsNativeObjectContainer()
			{
				if (nativeObjectRef != nullptr)
					throw gcnew Exception("Contained native object pointer is not null - are you allowing the graphics to destroy the native objects before you destroy the container?");
			}
		};
		typedef GraphicsNativeObjectContainer * GraphicsNativeObjectContainerPtr;

		class GraphicsNativeObjectAttributes
		{
		public:
			bool singleColor; // if true, no color will be part of the arrays, but a color can be submitted curing rendering (single color across ENTIRE model ONLY, otherwise too granular)
			ModelSurfaceTexture textures[4];
			gcroot<GameTexture^> bumpMapTextureRef; // if null, no tangent or binormal vectors are necessary - could put one in later for rendering, but not currently supported
			bool allowElementArray; // can the VAO be index based?  (only allowed if the colors are the same per vertex - that is, no overrides)

			// just data, doesn't determine type
			int triangleQty; // how many triangles are there? (and by extension, how many colors if not single, and how many texture coordinates, if there is a texture)
			int texCoordSize; // 0 means no textures, 2 means ST, 4 means STRQ - IMPORTANT NOTE: This number does NOT establish different types.  All surfaces of a given type will use this number.

			GraphicsNativeObjectAttributes()
			{
				singleColor = false;

				bumpMapTextureRef = nullptr;
				allowElementArray = true;

				triangleQty = 0;
				texCoordSize = 0;
			}

			bool CompareType(GraphicsNativeObjectAttributes &p_attributes)
			{
				// do NOT compare texCoordSize here. It does not separate types.
				return (p_attributes.allowElementArray == allowElementArray &&
					p_attributes.singleColor == singleColor &&
					static_cast<GameTexture^>(p_attributes.textures[0].textureRef) == static_cast<GameTexture^>(textures[0].textureRef) &&
					static_cast<GameTexture^>(p_attributes.textures[0].specularMapTextureRef) == static_cast<GameTexture^>(textures[0].specularMapTextureRef) &&
					p_attributes.textures[0].blendOption == textures[0].blendOption &&
					p_attributes.textures[0].lightOption == textures[0].lightOption &&
					p_attributes.textures[0].specularBlendOption == textures[0].specularBlendOption &&
					static_cast<GameTexture^>(p_attributes.textures[1].textureRef) == static_cast<GameTexture^>(textures[1].textureRef) &&
					static_cast<GameTexture^>(p_attributes.textures[1].specularMapTextureRef) == static_cast<GameTexture^>(textures[1].specularMapTextureRef) &&
					p_attributes.textures[1].blendOption == textures[1].blendOption &&
					p_attributes.textures[1].lightOption == textures[1].lightOption &&
					p_attributes.textures[1].specularBlendOption == textures[1].specularBlendOption &&
					static_cast<GameTexture^>(p_attributes.textures[2].textureRef) == static_cast<GameTexture^>(textures[2].textureRef) &&
					static_cast<GameTexture^>(p_attributes.textures[2].specularMapTextureRef) == static_cast<GameTexture^>(textures[2].specularMapTextureRef) &&
					p_attributes.textures[2].blendOption == textures[2].blendOption &&
					p_attributes.textures[2].lightOption == textures[2].lightOption &&
					p_attributes.textures[2].specularBlendOption == textures[2].specularBlendOption &&
					static_cast<GameTexture^>(p_attributes.textures[3].textureRef) == static_cast<GameTexture^>(textures[3].textureRef) &&
					static_cast<GameTexture^>(p_attributes.textures[3].specularMapTextureRef) == static_cast<GameTexture^>(textures[3].specularMapTextureRef) &&
					p_attributes.textures[3].blendOption == textures[3].blendOption &&
					p_attributes.textures[3].lightOption == textures[3].lightOption &&
					p_attributes.textures[3].specularBlendOption == textures[3].specularBlendOption &&
					static_cast<GameTexture^>(p_attributes.bumpMapTextureRef) == static_cast<GameTexture^>(bumpMapTextureRef)
					);
			}
		};

		class GraphicsNativeObjectRenderDefaultOptions
		{
		public:
			GameColor *singleColor; // if true, no color will be part of the arrays, but a color can be submitted curing rendering (single color across ENTIRE model ONLY, otherwise too granular)
			gcroot<GameTexture^> textureRef[4]; // if null, no texture coordinates are necessary, BUT a texture could be submitted later - for now, no support for that
			GraphicsShaderCompositionTextureBlendOption textureBlendOption[4];
			GraphicsShaderCompositionTextureLightOption textureLightOption[4];
			gcroot<GameTexture^> textureSpecularMapRef[4];
			GraphicsShaderCompositionSpecularBlendOption textureSpecularBlendOption[4];
			gcroot<GameTexture^> textureBlendMapRef;
			gcroot<GameTexture^> textureBumpMapRef;

			GraphicsNativeObjectRenderDefaultOptions()
			{
				singleColor = nullptr;
				textureRef[0] = nullptr;
				textureRef[1] = nullptr;
				textureRef[2] = nullptr;
				textureRef[3] = nullptr;
				textureSpecularMapRef[0] = nullptr;
				textureSpecularMapRef[1] = nullptr;
				textureSpecularMapRef[2] = nullptr;
				textureSpecularMapRef[3] = nullptr;
				textureBlendOption[0] = GraphicsShaderCompositionTextureBlendOption::NoBlend;
				textureBlendOption[1] = GraphicsShaderCompositionTextureBlendOption::NoBlend;
				textureBlendOption[2] = GraphicsShaderCompositionTextureBlendOption::NoBlend;
				textureBlendOption[3] = GraphicsShaderCompositionTextureBlendOption::NoBlend;
				textureLightOption[0] = GraphicsShaderCompositionTextureLightOption::Diffuse;
				textureLightOption[1] = GraphicsShaderCompositionTextureLightOption::Diffuse;
				textureLightOption[2] = GraphicsShaderCompositionTextureLightOption::Diffuse;
				textureLightOption[3] = GraphicsShaderCompositionTextureLightOption::Diffuse;
				textureSpecularBlendOption[0] = GraphicsShaderCompositionSpecularBlendOption::NoModulate;
				textureSpecularBlendOption[1] = GraphicsShaderCompositionSpecularBlendOption::NoModulate;
				textureSpecularBlendOption[2] = GraphicsShaderCompositionSpecularBlendOption::NoModulate;
				textureSpecularBlendOption[3] = GraphicsShaderCompositionSpecularBlendOption::NoModulate;
				textureBlendMapRef = nullptr;
				textureBumpMapRef = nullptr;
			}
		};

		//class GraphicsNativeObjectRenderOptions
		//{
		//	Matrix4d MVPMatrix; // required
		//	GameColor *singleColor; // only valid if it's a single color model, will override if populated
		//	gcroot<GameTexture^> textureRef; // override existing texture in default options

		//	GraphicsNativeObjectRenderOptions()
		//	{
		//		singleColor = nullptr;
		//		textureRef = nullptr;
		//	}
		//};

		class GraphicsNativeProgramContainer
		{
		public:
			int vertexEnum;
			int fragmentEnum;
			GraphicsShaderCompositionCheckSum checkSum;
#ifdef _DEBUG
			GraphicsShaderComposition composition;
			GraphicsParticlesShaderComposition particleComposition;
			GraphicsPolygonShaderComposition polygonComposition;
			GraphicsPostProcessShaderComposition postProcessComposition;
#endif

			void *programIdPtr; // pointer to API-Specific representation of linked program

			GraphicsNativeProgramContainer()
			{
				programIdPtr = nullptr;
			}

			~GraphicsNativeProgramContainer()
			{
				if (programIdPtr != nullptr)
				{
					delete programIdPtr;
					programIdPtr = nullptr;
				}
			}
		};

		class GraphicsNativeProgramContainerList : LinkedList<GraphicsNativeProgramContainer>
		{
		public:
			void * GetNativeProgramContainer(int p_vertexEnum, int p_fragmentEnum)
			{
				LinkedListEnumerator<GraphicsNativeProgramContainer> enumerator = LinkedListEnumerator<GraphicsNativeProgramContainer>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.vertexEnum == p_vertexEnum && enumerator.Current()->data.fragmentEnum == p_fragmentEnum)
					{
						// move node to front so that finding it again is faster
						MoveNodeToFront(enumerator.Current());
						return enumerator.Current()->data.programIdPtr;
					}
				}

				return nullptr;
			}

			void * GetNativeProgramContainer(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsShaderComposition *p_composition)
			{
				LinkedListEnumerator<GraphicsNativeProgramContainer> enumerator = LinkedListEnumerator<GraphicsNativeProgramContainer>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.checkSum.Compare(p_checkSum) == true)
					{
#ifdef _DEBUG
						GraphicsShaderComposition temp = enumerator.Current()->data.composition;
						if (temp.Compare(p_composition) == false)
							throw gcnew Exception("Compositions for found checksum are not equal!  Are you properly promoting values to int64 for the checksum calculation?");
#endif _DEBUG
						// move node to front so that finding it again is faster
						MoveNodeToFront(enumerator.Current());
						return enumerator.Current()->data.programIdPtr;
					}
				}

				return nullptr;
			}

			void * GetNativeProgramContainer(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsParticlesShaderComposition *p_composition)
			{
				LinkedListEnumerator<GraphicsNativeProgramContainer> enumerator = LinkedListEnumerator<GraphicsNativeProgramContainer>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.checkSum.Compare(p_checkSum) == true)
					{
#ifdef _DEBUG
						GraphicsParticlesShaderComposition temp = enumerator.Current()->data.particleComposition;
						if (temp.Compare(*p_composition) == false)
							throw gcnew Exception("Particle compositions for found checksum are not equal!  Are you properly promoting values to int64 for the checksum calculation?");
#endif _DEBUG
						// move node to front so that finding it again is faster
						MoveNodeToFront(enumerator.Current());
						return enumerator.Current()->data.programIdPtr;
					}
				}

				return nullptr;
			}

			void * GetNativeProgramContainer(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsPolygonShaderComposition *p_composition)
			{
				LinkedListEnumerator<GraphicsNativeProgramContainer> enumerator = LinkedListEnumerator<GraphicsNativeProgramContainer>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.checkSum.Compare(p_checkSum) == true)
					{
#ifdef _DEBUG
						GraphicsPolygonShaderComposition temp = enumerator.Current()->data.polygonComposition;
						if (temp.Compare(*p_composition) == false)
							throw gcnew Exception("Polygon compositions for found checksum are not equal!  Are you properly promoting values to int64 for the checksum calculation?");
#endif _DEBUG
						// move node to front so that finding it again is faster
						MoveNodeToFront(enumerator.Current());
						return enumerator.Current()->data.programIdPtr;
					}
				}

				return nullptr;
			}

			void * GetNativeProgramContainer(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsPostProcessShaderComposition *p_composition)
			{
				LinkedListEnumerator<GraphicsNativeProgramContainer> enumerator = LinkedListEnumerator<GraphicsNativeProgramContainer>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.checkSum.Compare(p_checkSum) == true)
					{
#ifdef _DEBUG
						GraphicsPostProcessShaderComposition temp = enumerator.Current()->data.postProcessComposition;
						if (temp.Compare(*p_composition) == false)
							throw gcnew Exception("Post process compositions for found checksum are not equal!  Are you properly promoting values to int64 for the checksum calculation?");
#endif _DEBUG
						// move node to front so that finding it again is faster
						MoveNodeToFront(enumerator.Current());
						return enumerator.Current()->data.programIdPtr;
					}
				}

				return nullptr;
			}

			LinkedListNode<GraphicsNativeProgramContainer> * AddProgram(int p_vertexEnum, int p_fragmentEnum, void *p_programIdPtr)
			{
				LinkedListNode<GraphicsNativeProgramContainer> *newNode = GetNewNode();
				newNode->data.vertexEnum = p_vertexEnum;
				newNode->data.fragmentEnum = p_fragmentEnum;
				newNode->data.checkSum = GraphicsShaderCompositionCheckSum(-1,-1,-1, -1);
				newNode->data.programIdPtr = p_programIdPtr;
				this->AddNode(newNode);
				return newNode;
			}

			LinkedListNode<GraphicsNativeProgramContainer> * AddProgram(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsShaderComposition *p_composition, void *p_programIdPtr)
			{
				LinkedListNode<GraphicsNativeProgramContainer> *newNode = GetNewNode();
				newNode->data.vertexEnum = -1;
				newNode->data.fragmentEnum = -1;
				newNode->data.checkSum = p_checkSum;
#ifdef _DEBUG
				newNode->data.composition = *p_composition; // not really needed, but good for verification tha checksum system is working
#endif
				newNode->data.programIdPtr = p_programIdPtr;
				this->AddNode(newNode);
				return newNode;
			}

			LinkedListNode<GraphicsNativeProgramContainer> * AddProgram(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsParticlesShaderComposition *p_composition, void *p_programIdPtr)
			{
				LinkedListNode<GraphicsNativeProgramContainer> *newNode = GetNewNode();
				newNode->data.vertexEnum = -1;
				newNode->data.fragmentEnum = -1;
				newNode->data.checkSum = p_checkSum;
#ifdef _DEBUG
				newNode->data.particleComposition = *p_composition; // not really needed, but good for verification tha checksum system is working
#endif
				newNode->data.programIdPtr = p_programIdPtr;
				this->AddNode(newNode);
				return newNode;
			}

			LinkedListNode<GraphicsNativeProgramContainer> * AddProgram(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsPolygonShaderComposition *p_composition, void *p_programIdPtr)
			{
				LinkedListNode<GraphicsNativeProgramContainer> *newNode = GetNewNode();
				newNode->data.vertexEnum = -1;
				newNode->data.fragmentEnum = -1;
				newNode->data.checkSum = p_checkSum;
#ifdef _DEBUG
				newNode->data.polygonComposition = *p_composition; // not really needed, but good for verification tha checksum system is working
#endif
				newNode->data.programIdPtr = p_programIdPtr;
				this->AddNode(newNode);
				return newNode;
			}

			LinkedListNode<GraphicsNativeProgramContainer> * AddProgram(GraphicsShaderCompositionCheckSum &p_checkSum, GraphicsPostProcessShaderComposition *p_composition, void *p_programIdPtr)
			{
				LinkedListNode<GraphicsNativeProgramContainer> *newNode = GetNewNode();
				newNode->data.vertexEnum = -1;
				newNode->data.fragmentEnum = -1;
				newNode->data.checkSum = p_checkSum;
#ifdef _DEBUG
				newNode->data.postProcessComposition = *p_composition; // not really needed, but good for verification tha checksum system is working
#endif
				newNode->data.programIdPtr = p_programIdPtr;
				this->AddNode(newNode);
				return newNode;
			}

			LinkedListNode<GraphicsNativeProgramContainer> * AddProgram(void *p_programIdPtr)
			{
				LinkedListNode<GraphicsNativeProgramContainer> *newNode = GetNewNode();
				newNode->data.vertexEnum = -1;
				newNode->data.fragmentEnum = -1;
				newNode->data.checkSum.Set(-1, -1, -1, -1);
				newNode->data.programIdPtr = p_programIdPtr;
				this->AddNode(newNode);
				return newNode;
			}

			LinkedListEnumerator<GraphicsNativeProgramContainer> GetEnumerator()
			{
				return LinkedListEnumerator<GraphicsNativeProgramContainer>(*this);
			}

			void Clear()
			{
				LinkedList<GraphicsNativeProgramContainer>::Clear();
			}
		};

		// particles
		class GraphicsNativeParticlesContainer
		{
		public:
			GraphicsNativeObjectBase *nativeParticlesRef;

			GraphicsNativeParticlesContainer()
			{
				nativeParticlesRef = nullptr;
			}

			~GraphicsNativeParticlesContainer()
			{
				if (nativeParticlesRef != nullptr)
					throw gcnew Exception("~GraphicsNativeParticlesContainer: Contained native particles pointer is not null - are you allowing the graphics to destroy the native particles before you destroy the container?");
			}
		};
		typedef GraphicsNativeParticlesContainer * GraphicsNativeParticlesContainerPtr;

		// each API uses this differently, but its creation is registered so that destruction of the API will properly dispose of it
		class GraphicsParticleQueue
		{
		public:
			GraphicsNativeObjectBase *nativeParticlesRef;
			float *particleStorage; // for now assume both GL and DX will use float arrays
			int particleArraySize;
			int particleQty;
			bool firstRender; // during first render, establish size of GPU buffer as particleQty, otherwise just update first particleQty entries in buffer
			GraphicsParticlesStorageOptions storageOptions; // characteristics of cpu-side array for upload to GPU

			GraphicsParticleQueue()
			{
				nativeParticlesRef = nullptr;
				particleStorage = nullptr;
				particleQty = 0;
				firstRender = true;
			}

			~GraphicsParticleQueue()
			{
				if (nativeParticlesRef != nullptr)
					throw gcnew Exception("~GraphicsParticleQueue: Contained native particles pointer is not null - are you allowing the graphics to destroy the native particles before you destroy the container?");
				if (particleStorage != nullptr)
					throw gcnew Exception("~GraphicsParticleQueue: Contained particleStorage pointer is not null - are you allowing the graphics to destroy the native particles before you destroy the container?");
			}

			bool IsInitialized()
			{
				return (nativeParticlesRef != nullptr);
			}
		};
		typedef GraphicsParticleQueue * GraphicsParticleQueuePtr;

		class GraphicsLoadedTextureContainer
		{
		public:
			gcroot<GameTexture^> textureRef;

			GraphicsLoadedTextureContainer()
			{
			}
		};

		class GraphicsLoadedTexturesList : LinkedList<GraphicsLoadedTextureContainer>
		{
		public:
			LinkedListEnumerator<GraphicsLoadedTextureContainer> GetEnumerator()
			{
				return LinkedListEnumerator<GraphicsLoadedTextureContainer>(*this);
			}

			void Clear()
			{
				LinkedList<GraphicsLoadedTextureContainer>::Clear();
			}

			void AddTexture(GameTexture ^p_texture)
			{
				LinkedListNode<GraphicsLoadedTextureContainer> *newNode = GetNewNode();
				newNode->data.textureRef = p_texture;
				AddNode(newNode);
			}
		};

		class GraphicsTexCoord
		{
		public:
			float s;
			float t;

			GraphicsTexCoord() // not used
			{
			}

			GraphicsTexCoord(ModelVertexTextureCoords &p_texCoord)
			{
				s = p_texCoord.s;
				t = p_texCoord.t;
			}

			GraphicsTexCoord(float p_s, float p_t)
			{
				s = p_s;
				t = p_t;
			}
		};

		class GraphicsVertexData
		{
		public:
			GraphicsVertexData() // required to be a <T> in linkedlist
			{
			}

			GameColor color;
			GraphicsTexCoord texCoord;
			GraphicsTexCoord texCoordBlendMap;
			Vector3d vertex;
		};

		enum class GraphicsVertexDataListTypeEnum
		{
			Triangle = 1,
			TriangleFan = 2,
			TriangleStrip = 3
		};

		class GraphicsVertexDataList : public LinkedList<GraphicsVertexData>
		{
		public:
			GraphicsVertexDataListTypeEnum listType;
			bool startNewNode;

			GraphicsVertexDataList() // required to be a <T> in linkedlist
			{
				startNewNode = true;
			}

			~GraphicsVertexDataList()
			{
				LinkedList<GraphicsVertexData>::Destroy();
			}

			LinkedListEnumerator<GraphicsVertexData> GetEnumerator()
			{
				return LinkedListEnumerator<GraphicsVertexData>(*this);
			}

			void Vertex(Vector3d &p_vertex)
			{
				CheckStartNewNode();

				LinkedListNode<GraphicsVertexData> *lastNode = GetLastNode();
				lastNode->data.vertex = p_vertex;

				// start a new node for next piece of data
				startNewNode = true;
			}

			void Color(GameColor &p_color)
			{
				CheckStartNewNode();

				LinkedListNode<GraphicsVertexData> *lastNode = GetLastNode();
				lastNode->data.color = p_color;
			}

			void TexCoord(GraphicsTexCoord &p_texCoord)
			{
				CheckStartNewNode();

				LinkedListNode<GraphicsVertexData> *lastNode = GetLastNode();
				lastNode->data.texCoord = p_texCoord;
			}

			void TexCoordBlendMap(GraphicsTexCoord &p_texCoordBlendMap)
			{
				CheckStartNewNode();

				LinkedListNode<GraphicsVertexData> *lastNode = GetLastNode();
				lastNode->data.texCoordBlendMap = p_texCoordBlendMap;
			}

		private:
			void CheckStartNewNode()
			{
				if (startNewNode == true)
				{
					LinkedListNode<GraphicsVertexData> *newNode = GetNewNode();
					AddNode(newNode);

					startNewNode = false;
				}
			}
		};

		// API agnostic pool of vertices, submitted in triangle style (vertices will be calculated more than once)
		// todo: upgrade to support triangle strip and triangle fan, automatically split into element style shader
		class GraphicsVertexPool
		{
			LinkedList<GraphicsVertexDataList> listData;
			bool startNewNode = true;

			LinkedListNode<GraphicsVertexDataList> *currentList;

		public:
			// vertex always exists
			// these are optional - if true, use that data for the VBOs
			// note: there is currently no requirement that every list have the same data - but this is assumed.  So make sure
			//   the implementation code uses all of them consistently for every vertex
			bool color;
			bool texCoord;
			bool texCoordBlendMap;

			GraphicsVertexPool()
			{
				Reset();
			}

			int GetVertexCount()
			{
				int total = 0;
				LinkedListEnumerator<GraphicsVertexDataList> enumerator = GetEnumerator();
				while (enumerator.MoveNext())
				{
					switch (enumerator.Current()->data.listType)
					{
						case GraphicsVertexDataListTypeEnum::Triangle:
							total += enumerator.Current()->data.Count();
							break;
						case GraphicsVertexDataListTypeEnum::TriangleStrip:
							total += (enumerator.Current()->data.Count() - 2) * 3;
							break;
						case GraphicsVertexDataListTypeEnum::TriangleFan:
							total += (enumerator.Current()->data.Count() - 2) * 3;
							break;
					}
				}
				return total;
			}

			LinkedListEnumerator<GraphicsVertexDataList> GetEnumerator()
			{
				return LinkedListEnumerator<GraphicsVertexDataList>(listData);
			}

			void Reset()
			{
				currentList = nullptr;
				listData.Clear();
				color = false;
				texCoord = false;
				texCoordBlendMap = false;
			}

			void Begin(GraphicsVertexDataListTypeEnum p_type)
			{
				if (currentList != nullptr)
					throw gcnew Exception("Cannot start a new list until current list is Ended");

				LinkedListNode<GraphicsVertexDataList> *newNode = listData.GetNewNode();
				// make sure data list is cleared!!!
				newNode->data.Clear();
				listData.AddNode(newNode);

				newNode->data.listType = p_type;
				currentList = newNode;
			}

			void End()
			{
				if (currentList == nullptr)
					throw gcnew System::Exception("Begin() not called yet");
				currentList = nullptr;
			}

			bool IsClosed()
			{
				return (currentList == nullptr);
			}

			void Vertex(Vector3d &p_vertex)
			{
				if (currentList == nullptr)
					throw gcnew Exception("List not started - call Begin(type)");
				currentList->data.Vertex(p_vertex);
			}

			void Color(GameColor &p_color)
			{
				if (currentList == nullptr)
					throw gcnew Exception("List not started - call Begin(type)");
				currentList->data.Color(p_color);
				color = true;
			}

			void TexCoord(GraphicsTexCoord &p_texCoord)
			{
				if (currentList == nullptr)
					throw gcnew Exception("List not started - call Begin(type)");
				currentList->data.TexCoord(p_texCoord);
				texCoord = true;
			}

			void TexCoordBlendMap(GraphicsTexCoord &p_texCoordBlendMap)
			{
				if (currentList == nullptr)
					throw gcnew Exception("List not started - call Begin(type)");
				currentList->data.TexCoordBlendMap(p_texCoordBlendMap);
				texCoordBlendMap = true;
			}
		};
	}
}