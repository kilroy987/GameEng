#pragma once

#include "ModelSurface.h"

// this file provides helper classes that joitned models can use to prepare data so that the graphicsbase class can receive the data and prep a native object with it
// this prevents circular dependencies, since graphicsbase cannot know what a jointedmodel is because jointedmodel needs to know what graphcisbase is

namespace GameEng {
	namespace Graphics {

		public class JointedModelNativeData
		{
		public:
			int orientIndex; // which gameobject orientation is this surface transformed by for rendering? (always populated)

			ModelSurface *surfaceRef; // surface with vertex data
			int surfaceQty;
			ModelVertex *verticesRef; // vertex data that surfaces use
			int vertexQty;
			GameColor *colorsRef; // colors that vertices use

			JointedModelNativeData()
			{
				orientIndex = -1; // if at the end this is not -1, is invalid
				surfaceRef = nullptr;
				surfaceQty = 0;
				vertexQty = 0;
			}
		};
	}
}