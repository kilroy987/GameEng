#pragma once

#include <Windows.h> // CopyMemory

namespace GameEng {
	namespace Math {
		class Matrix4d
		{
		public:
			float m11, m21, m31, m41, m12, m22, m32, m42, m13, m23, m33, m43, m14, m24, m34, m44; // this is how OpenGL copy will get the values correct, direct copy from glMultMatrix()
			/*
			m11, m12, m13, m14
			m21, m22, m23, m24
			m31, m32, m33, m34
			m41, m42, m43, m44
			*/

			Matrix4d()
			{
			}

			Matrix4d(Matrix4d &p_matrix)
			{
				Set(p_matrix);
			}

			void Set(Matrix4d &p_matrix)
			{
				CopyMemory(&m11, &p_matrix, 16 * 4);
			}

			// note: this representation is transposed - no real reason, just be aware
			Matrix4d(float p_m11, float p_m12, float p_m13, float p_m14,
					 float p_m21, float p_m22, float p_m23, float p_m24,
					 float p_m31, float p_m32, float p_m33, float p_m34,
					 float p_m41, float p_m42, float p_m43, float p_m44)
			{
				m11 = p_m11;
				m12 = p_m12;
				m13 = p_m13;
				m14 = p_m14;

				m21 = p_m21;
				m22 = p_m22;
				m23 = p_m23;
				m24 = p_m24;

				m31 = p_m31;
				m32 = p_m32;
				m33 = p_m33;
				m34 = p_m34;

				m41 = p_m41;
				m42 = p_m42;
				m43 = p_m43;
				m44 = p_m44;
			}

			bool Equals(Matrix4d &p_matrix)
			{
				return (
					m11 == p_matrix.m11 &&
					m12 == p_matrix.m12 &&
					m13 == p_matrix.m13 &&
					m14 == p_matrix.m14 &&
					m21 == p_matrix.m21 &&
					m22 == p_matrix.m22 &&
					m23 == p_matrix.m23 &&
					m24 == p_matrix.m24 &&
					m31 == p_matrix.m31 &&
					m32 == p_matrix.m32 &&
					m33 == p_matrix.m33 &&
					m34 == p_matrix.m34 &&
					m41 == p_matrix.m41 &&
					m42 == p_matrix.m42 &&
					m43 == p_matrix.m43 &&
					m44 == p_matrix.m44
					);
			}

			// correct for OpenGL's glMultMatrix()
			Matrix4d Matrix4d::operator * (const Matrix4d &p_matrix)
			{
				Matrix4d result = Matrix4d(
				m11 * p_matrix.m11 + m12 * p_matrix.m21 + m13 * p_matrix.m31 + m14 * p_matrix.m41,
				m11 * p_matrix.m12 + m12 * p_matrix.m22 + m13 * p_matrix.m32 + m14 * p_matrix.m42,
				m11 * p_matrix.m13 + m12 * p_matrix.m23 + m13 * p_matrix.m33 + m14 * p_matrix.m43,
				m11 * p_matrix.m14 + m12 * p_matrix.m24 + m13 * p_matrix.m34 + m14 * p_matrix.m44,

				m21 * p_matrix.m11 + m22 * p_matrix.m21 + m23 * p_matrix.m31 + m24 * p_matrix.m41,
				m21 * p_matrix.m12 + m22 * p_matrix.m22 + m23 * p_matrix.m32 + m24 * p_matrix.m42,
				m21 * p_matrix.m13 + m22 * p_matrix.m23 + m23 * p_matrix.m33 + m24 * p_matrix.m43,
				m21 * p_matrix.m14 + m22 * p_matrix.m24 + m23 * p_matrix.m34 + m24 * p_matrix.m44,

				m31 * p_matrix.m11 + m32 * p_matrix.m21 + m33 * p_matrix.m31 + m34 * p_matrix.m41,
				m31 * p_matrix.m12 + m32 * p_matrix.m22 + m33 * p_matrix.m32 + m34 * p_matrix.m42,
				m31 * p_matrix.m13 + m32 * p_matrix.m23 + m33 * p_matrix.m33 + m34 * p_matrix.m43,
				m31 * p_matrix.m14 + m32 * p_matrix.m24 + m33 * p_matrix.m34 + m34 * p_matrix.m44,

				m41 * p_matrix.m11 + m42 * p_matrix.m21 + m43 * p_matrix.m31 + m44 * p_matrix.m41,
				m41 * p_matrix.m12 + m42 * p_matrix.m22 + m43 * p_matrix.m32 + m44 * p_matrix.m42,
				m41 * p_matrix.m13 + m42 * p_matrix.m23 + m43 * p_matrix.m33 + m44 * p_matrix.m43,
				m41 * p_matrix.m14 + m42 * p_matrix.m24 + m43 * p_matrix.m34 + m44 * p_matrix.m44);

				return result;
			}

			Vector4d Matrix4d::operator * (const Vector4d &p_vector)
			{
				Vector4d result = Vector4d(
					m11 * p_vector.x + m12 * p_vector.y + m13 * p_vector.z + m14 * p_vector.w,
					m21 * p_vector.x + m22 * p_vector.y + m23 * p_vector.z + m24 * p_vector.w,
					m31 * p_vector.x + m32 * p_vector.y + m33 * p_vector.z + m34 * p_vector.w,
					m41 * p_vector.x + m42 * p_vector.y + m43 * p_vector.z + m44 * p_vector.w
					);

				return result;
			}

			// pipes a world position through a camera-set mvp matrix and provides the corresponding depth value that would be stored in the depth buffer
			// if the mvp is already transformed by modelview, p_worldPosition is a model-space position
			float GetDepthBufferValue(const Vector3d &p_worldPosition)
			{
				// assume p_worldPosition.w = 1.0f
				// note: this may not match the depth buffer values of some implementations exactly depending on how calculation optimizations are applied in vendor hardware, software, etc.
				float z = m31 * p_worldPosition.x + m32 * p_worldPosition.y + m33 * p_worldPosition.z + m34;
				float w = m41 * p_worldPosition.x + m42 * p_worldPosition.y + m43 * p_worldPosition.z + m44;
				if (abs(w) < 0.00001f)
					throw gcnew System::Exception("w = 0.0f; ensure world position is within the render clip planes");
				return z / w * 0.5f + 0.5f;
			}

			Matrix4d ScalarMult(float p_scalar)
			{
				Matrix4d result;
				result.m11 = m11 * p_scalar;
				result.m12 = m12 * p_scalar;
				result.m13 = m13 * p_scalar;
				result.m14 = m14 * p_scalar;

				result.m21 = m21 * p_scalar;
				result.m22 = m22 * p_scalar;
				result.m23 = m23 * p_scalar;
				result.m24 = m24 * p_scalar;

				result.m31 = m31 * p_scalar;
				result.m32 = m32 * p_scalar;
				result.m33 = m33 * p_scalar;
				result.m34 = m34 * p_scalar;

				result.m41 = m41 * p_scalar;
				result.m42 = m42 * p_scalar;
				result.m43 = m43 * p_scalar;
				result.m44 = m44 * p_scalar;
				return result;
			}

			// http://www.cg.info.hiroshima-cu.ac.jp/~miyazaki/knowledge/teche23.html
			float GetDeterminant()
			{
				float result = m11*m22*m33*m44 + m11*m23*m34*m42 + m11*m24*m32*m43
					+ m12*m21*m34*m43 + m12*m23*m31*m44 + m12*m24*m33*m41
					+ m13*m21*m32*m44 + m13*m22*m34*m41 + m13*m24*m31*m42
					+ m14*m21*m33*m42 + m14*m22*m31*m43 + m14*m23*m32*m41
					- m11*m22*m34*m43 - m11*m23*m32*m44 - m11*m24*m33*m42
					- m12*m21*m33*m44 - m12*m23*m34*m41 - m12*m24*m31*m43
					- m13*m21*m34*m42 - m13*m22*m31*m44 - m13*m24*m32*m41
					- m14*m21*m32*m43 - m14*m22*m33*m41 - m14*m23*m31*m42;
				return result;
			}

			// http://www.cg.info.hiroshima-cu.ac.jp/~miyazaki/knowledge/teche23.html
			Matrix4d GetInverse()
			{
				// calculate the inverse of this matrix.
				Matrix4d result;

				float determinant = GetDeterminant();
				if (abs(determinant) < 0.00001f)
					throw gcnew System::Exception("Determinant is zero - no inverse is possible");

				result.m11 = m22*m33*m44 + m23*m34*m42 + m24*m32*m43 - m22*m34*m43 - m23*m32*m44 - m24*m33*m42;
				result.m12 = m12*m34*m43 + m13*m32*m44 + m14*m33*m42 - m12*m33*m44 - m13*m34*m42 - m14*m32*m43;
				result.m13 = m12*m23*m44 + m13*m24*m42 + m14*m22*m43 - m12*m24*m43 - m13*m22*m44 - m14*m23*m42;
				result.m14 = m12*m24*m33 + m13*m22*m34 + m14*m23*m32 - m12*m23*m34 - m13*m24*m32 - m14*m22*m33;

				result.m21 = m21*m34*m43 + m23*m31*m44 + m24*m33*m41 - m21*m33*m44 - m23*m34*m41 - m24*m31*m43;
				result.m22 = m11*m33*m44 + m13*m34*m41 + m14*m31*m43 - m11*m34*m43 - m13*m31*m44 - m14*m33*m41;
				result.m23 = m11*m24*m43 + m13*m21*m44 + m14*m23*m41 - m11*m23*m44 - m13*m24*m41 - m14*m21*m43;
				result.m24 = m11*m23*m34 + m13*m24*m31 + m14*m21*m33 - m11*m24*m33 - m13*m21*m34 - m14*m23*m31;

				result.m31 = m21*m32*m44 + m22*m34*m41 + m24*m31*m42 - m21*m34*m42 - m22*m31*m44 - m24*m32*m41;
				result.m32 = m11*m34*m42 + m12*m31*m44 + m14*m32*m41 - m11*m32*m44 - m12*m34*m41 - m14*m31*m42;
				result.m33 = m11*m22*m44 + m12*m24*m41 + m14*m21*m42 - m11*m24*m42 - m12*m21*m44 - m14*m22*m41;
				result.m34 = m11*m24*m32 + m12*m21*m34 + m14*m22*m31 - m11*m22*m34 - m12*m24*m31 - m14*m21*m32;

				result.m41 = m21*m33*m42 + m22*m31*m43 + m23*m32*m41 - m21*m32*m43 - m22*m33*m41 - m23*m31*m42;
				result.m42 = m11*m32*m43 + m12*m33*m41 + m13*m31*m42 - m11*m33*m42 - m12*m31*m43 - m13*m32*m41;
				result.m43 = m11*m23*m42 + m12*m21*m43 + m13*m22*m41 - m11*m22*m43 - m12*m23*m41 - m13*m21*m42;
				result.m44 = m11*m22*m33 + m12*m23*m31 + m13*m21*m32 - m11*m23*m32 - m12*m21*m33 - m13*m22*m31;

				return result.ScalarMult(1.0f / determinant);
			}

			bool ApproximatelyEquals(Matrix4d &p_matrix)
			{
				if (abs(m11 - p_matrix.m11) > 0.0001f)
					return false;
				if (abs(m12 - p_matrix.m12) > 0.0001f)
					return false;
				if (abs(m13 - p_matrix.m13) > 0.0001f)
					return false;
				if (abs(m14 - p_matrix.m14) > 0.0001f)
					return false;
				if (abs(m21 - p_matrix.m21) > 0.0001f)
					return false;
				if (abs(m22 - p_matrix.m22) > 0.0001f)
					return false;
				if (abs(m23 - p_matrix.m23) > 0.0001f)
					return false;
				if (abs(m24 - p_matrix.m24) > 0.0001f)
					return false;
				if (abs(m31 - p_matrix.m31) > 0.0001f)
					return false;
				if (abs(m32 - p_matrix.m32) > 0.0001f)
					return false;
				if (abs(m33 - p_matrix.m33) > 0.0001f)
					return false;
				if (abs(m34 - p_matrix.m34) > 0.0001f)
					return false;
				if (abs(m41 - p_matrix.m41) > 0.0001f)
					return false;
				if (abs(m42 - p_matrix.m42) > 0.0001f)
					return false;
				if (abs(m43 - p_matrix.m43) > 0.0001f)
					return false;
				if (abs(m44 - p_matrix.m44) > 0.0001f)
					return false;

				return true;
			}

		};

		class Matrix3d
		{
		public:
			float m11, m21, m31, m12, m22, m32, m13, m23, m33; // consistency with Matrix4d

			/*
			m11 m12 m13
			m21 m22 m23
			m31 m32 m33
			*/

			/* When solving system of equations
			ax + by + cz = j
			dx + ey + fz = k
			gx + hy + iz = l

			get the inverse matrix for
			a b c
			d e f
			g h i
			
			and multiply it be the vector [j k l] to get the solution, [x y z]
			*/

			Matrix3d()
			{
			}

			Matrix3d(Matrix3d &p_matrix)
			{
				Set(p_matrix);
			}

			void Set(Matrix3d &p_matrix)
			{
				CopyMemory(&m11, &p_matrix, 9 * 4);
			}

			// consistency with Matrix4d, across top first
			Matrix3d(float p_m11, float p_m12, float p_m13,
				float p_m21, float p_m22, float p_m23,
				float p_m31, float p_m32, float p_m33)
			{
				m11 = p_m11;
				m12 = p_m12;
				m13 = p_m13;

				m21 = p_m21;
				m22 = p_m22;
				m23 = p_m23;

				m31 = p_m31;
				m32 = p_m32;
				m33 = p_m33;
			}

			Matrix3d Matrix3d::operator * (const Matrix3d &p_matrix)
			{
				Matrix3d result = Matrix3d(
					m11 * p_matrix.m11 + m12 * p_matrix.m21 + m13 * p_matrix.m31,
					m11 * p_matrix.m12 + m12 * p_matrix.m22 + m13 * p_matrix.m32,
					m11 * p_matrix.m13 + m12 * p_matrix.m23 + m13 * p_matrix.m33,

					m21 * p_matrix.m11 + m22 * p_matrix.m21 + m23 * p_matrix.m31,
					m21 * p_matrix.m12 + m22 * p_matrix.m22 + m23 * p_matrix.m32,
					m21 * p_matrix.m13 + m22 * p_matrix.m23 + m23 * p_matrix.m33,

					m31 * p_matrix.m11 + m32 * p_matrix.m21 + m33 * p_matrix.m31,
					m31 * p_matrix.m12 + m32 * p_matrix.m22 + m33 * p_matrix.m32,
					m31 * p_matrix.m13 + m32 * p_matrix.m23 + m33 * p_matrix.m33);

				return result;
			}

			Matrix3d Transpose()
			{
				Matrix3d result = Matrix3d(
					m11, m21, m31,
					m12, m22, m32,
					m13, m23, m33
					);

				return result;
			}

			Vector3d Matrix3d::operator * (const Vector3d &p_vector)
			{
				Vector3d result = Vector3d(
					m11 * p_vector.x + m12 * p_vector.y + m13 * p_vector.z,
					m21 * p_vector.x + m22 * p_vector.y + m23 * p_vector.z,
					m31 * p_vector.x + m32 * p_vector.y + m33 * p_vector.z
					);

				return result;
			}

			Matrix3d Matrix3d::ScalarMult(float p_factor)
			{
				Matrix3d result = Matrix3d(
						m11 * p_factor,
						m12 * p_factor,
						m13 * p_factor,
						m21 * p_factor,
						m22 * p_factor,
						m23 * p_factor,
						m31 * p_factor,
						m32 * p_factor,
						m33 * p_factor
						);

				return result;
			}

			/*
			m11 m12 m13
			m21 m22 m23
			m31 m32 m33
			*/
			float Determinant()
			{
				//float determinant = (m11 * m22 - m21 * m12) + (m22 * m33 - m32 * m23) - (m21 * m32 - m31 * m22) - (m12 * m23 - m22 * m13);
				// I do NOT remember it this way.. but.. it works, so... whatever.  Why only go across the top!?   I don't feel the complete math here.
				float determinant = m11 * (m22 * m33 - m32 * m23) - m12 * (m21 * m33 - m31 * m23) + m13 * (m21 * m32 - m31 * m22);
				return determinant;
			}

			Matrix3d Inverse()
			{
				Matrix3d transpose = Transpose();
				float determinant = Determinant();
				if (abs(determinant) < 0.00001f)
					throw gcnew System::Exception("No solution for inverse of this 3x3 matrix");
				float factor = 1.0f / determinant; // if determinant is zero, no solution (two segments are parallel trying to solve system of equations, etc.)

				Matrix3d inverse = Matrix3d(
					(transpose.m22 * transpose.m33 - transpose.m32 * transpose.m23),
					-(transpose.m21 * transpose.m33 - transpose.m31 * transpose.m23),
					(transpose.m21 * transpose.m32 - transpose.m31 * transpose.m22),
					-(transpose.m12 * transpose.m33 - transpose.m32 * transpose.m13),
					(transpose.m11 * transpose.m33 - transpose.m31 * transpose.m13),
					-(transpose.m11 * transpose.m32 - transpose.m31 * transpose.m12),
					(transpose.m12 * transpose.m23 - transpose.m22 * transpose.m13),
					-(transpose.m11 * transpose.m23 - transpose.m21 * transpose.m13),
					(transpose.m11 * transpose.m22 - transpose.m21 * transpose.m12)
					).ScalarMult(factor);

				return inverse;
			}
		};
	}
}