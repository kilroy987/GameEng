#pragma once

#include "Frustum.h"

// simpler portal structures separated out to prevent circular header dependency

namespace GameEng {
	namespace PortalEngine {

		// for simplicity of linked list handling of deleted nodes
		class PortalNodeIndex
		{
		public:
			int index;

			PortalNodeIndex(int p_index)
			{
				index = p_index;
			}

			PortalNodeIndex()
			{
				// to support linked list header and footer only
			}
		};

		class PortalNodeIndexAndDistance
		{
		public:
			int portalIndex; // index in portal registry
			int nodePortalIndex; // id of portal within a node
			float distance;

			PortalNodeIndexAndDistance(int p_portalIndex, int p_nodePortalIndex, float p_distance)
			{
				portalIndex = p_portalIndex;
				nodePortalIndex = p_nodePortalIndex;
				distance = p_distance;
			}

			PortalNodeIndexAndDistance()
			{
				// to support linked list header and footer only
			}
		};
	}
}
