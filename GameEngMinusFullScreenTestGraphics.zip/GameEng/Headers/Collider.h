#pragma once

#include "Vector.h"
#include "MathConstants.h"

namespace GameEng {
	namespace Collider {

		using namespace GameEng::Math;

		enum class ColliderObjectType
		{
			Surface,
			Segment,
			Point
		};

		class ColliderPoint
		{
		public:
			Vector3d position;

			// p_maxCollisionT is the upper limit of a collision that can occur (caller can initialize to > 1.0 but should sent values from 0.0-1.0 as collisions are detected elsewhere
			// if a collision is detected, it will be modified
			bool SphereCollision(Vector3d &p_start, Vector3d &p_travel, float p_radius, float &p_maxCollisionT)
			{
				float collisionT = 10.0f;
				if (MathUtilities::SpherePointCollision(p_start, p_travel, p_radius, position, collisionT) == true)
				{
					if (collisionT < p_maxCollisionT)
					{
						p_maxCollisionT = collisionT;
						return true;
					}
				}

				return false;
			}

			bool SphereIntersection(Vector3d &p_position, float p_radius, float &p_distance, Vector3d &p_normal)
			{
				if (MathUtilities::SpherePointIntersection(p_position, p_radius, position, p_distance) == true)
				{
					p_normal = p_position - position;
					p_normal.Normalize();
					return true;
				}

				return false;
			}
		};

		class ColliderSegment
		{
		public:
			Vector3d point0;
			Vector3d point1;
			Vector3d segmentUnit;
			float segmentLength; // not used currently

			void SetData(Vector3d &p_point0, Vector3d &p_point1)
			{
				point0 = p_point0;
				point1 = p_point1;
				segmentUnit = p_point1 - p_point0;
				segmentLength = segmentUnit.Magnitude();
				segmentUnit.Normalize();
			}

			// p_maxCollisionT is the upper limit of a collision that can occur (caller can initialize to > 1.0 but should sent values from 0.0-1.0 as collisions are detected elsewhere
			// if a collision is detected, it will be modified
			bool SphereCollision(Vector3d &p_start, Vector3d &p_travel, float p_radius, float &p_maxCollisionT)
			{
				float collisionT = 10.0f;
				if (MathUtilities::SphereLineSegmentCollision(p_start, p_travel, p_radius, point0, point1, &segmentUnit, collisionT) == true)
				{
					if (collisionT < p_maxCollisionT)
					{
						p_maxCollisionT = collisionT;
						return true;
					}
				}

				return false;
			}

			bool SphereIntersection(Vector3d &p_position, float p_radius, float &p_distance, Vector3d &p_normal)
			{
				if (MathUtilities::SphereLineSegmentIntersection(p_position, p_radius, point0, point1, &segmentUnit, p_distance) == true)
				{
					Vector3d collisionOffset = p_position - point0;
					p_normal = p_position - (point0 + segmentUnit.ScalarMult(collisionOffset * segmentUnit));
					p_normal.Normalize();
					return true;
				}

				return false;
			}
		};

		class ColliderSurface
		{
		public:
			Vector3d point0; // world point on the plane
			Vector3d normal; // normal for the plane
			Vector3d tangentX; // axis for X of surfacePoints
			Vector3d tangentY; // axis for Y of surfacePoints

			int surfacePointQty;
			Vector2d *surfacePoints;

			ColliderSurface()
			{
				surfacePointQty = 0;
				surfacePoints = nullptr;
			}

			~ColliderSurface()
			{
				if (surfacePoints != nullptr)
				{
					delete [] surfacePoints;
					surfacePoints = nullptr;
					surfacePointQty = 0;
				}
			}

			void Initialize(int p_surfacePointQty)
			{
				surfacePoints = new Vector2d[p_surfacePointQty];
				surfacePointQty = p_surfacePointQty;
			}

			void SetSurfacePoint(int p_index, Vector2d &p_point)
			{
				surfacePoints[p_index] = p_point;
			}

			void SetPrimaryData(Vector3d &p_point0, Vector3d &p_point1, Vector3d &p_normal)
			{
				// point 0 and 1 of 3d surface and normal are enough to generate the primary data needed for conversion
				point0 = p_point0;
				normal = p_normal;
				tangentX = p_point1 - p_point0;
				if (tangentX.Normalize() == false)
					throw gcnew System::Exception("Bad Segment for TangentX");
				tangentY = normal.CrossProd(tangentX); // correct direction really doesn't matter since all points will be converted and checked according to this
				if (tangentY.Normalize() == false)
					throw gcnew System::Exception("Bad CrossProduct for TangentY");
			}

			// convert to 2d surface after point0 and tangents set up
			void SetSurfacePoint(int p_index, Vector3d &p_point)
			{
				surfacePoints[p_index] = Vector2d((p_point - point0) * tangentX, (p_point - point0) * tangentY);
			}

			// note: p_point doesn't have to be parallel with the plane - it can also be projected in or out from it
			bool PointInSurface(Vector3d &p_point)
			{
				Vector3d pointOffsetFromPoint0 = p_point - point0;
				Vector2d pointOnPlane(pointOffsetFromPoint0 * tangentX, pointOffsetFromPoint0 * tangentY);

				// this algorithm uses a method from Game Programming gems - draw a straight line inifinitely down from the point, and if it intersects with an odd number of segments, it is inside
				Vector2d *compare0 = nullptr;
				Vector2d *compare1 = nullptr;
				int count = 0;
				for (int i = 0; i < surfacePointQty; i++)
				{
					if (i == surfacePointQty - 1)
					{
						compare0 = &surfacePoints[i];
						compare1 = &surfacePoints[0];
					}
					else
					{
						compare0 = &surfacePoints[i];
						compare1 = &surfacePoints[i + 1];
					}

					if ((pointOnPlane.x > compare0->x && pointOnPlane.x < compare1->x) || (pointOnPlane.x < compare0->x && pointOnPlane.x > compare1->x))
					{
						// point is between the endpoints, keep testing
						if (pointOnPlane.y < compare0->y && pointOnPlane.y < compare1->y)
						{
							// point is absolutely above
							count++;
						}
						else if (pointOnPlane.y > compare0->y && pointOnPlane.y > compare1->y)
						{
							// do nothing, point is below
						}
						else
						{
							// see if segment is below the point being tested
							// at this point it's impossible to get a verticle line because the x's are guaranteed to be different
							// todo: store the slope so that the compare is faster
							float compareY = compare0->y + (pointOnPlane.x - compare0->x) / (compare1->x - compare0->x) * (compare1->y - compare0->y);
							if (compareY > pointOnPlane.y)
								count++;
						}
					}
				}

				if (count % 2 == 1)
					// odd number of collisions - point is inside so sphere collided with surface
					return true;

				return false;
			}

			// p_maxCollisionT is the upper limit of a collision that can occur (caller can initialize to > 1.0 but should sent values from 0.0-1.0 as collisions are detected elsewhere
			// if a collision is detected, it will be modified
			bool SphereCollision(Vector3d &p_start, Vector3d &p_travel, float p_radius, float &p_maxCollisionT)
			{
				float collisionT = 10.0f;
				if (MathUtilities::SpherePlaneCollision(p_start, p_travel, p_radius, point0, normal, collisionT) == true)
				{
					if (collisionT < p_maxCollisionT)
					{
						// now see if the sphere is touching the plane at a point that is contained within the surface
						Vector3d collisionSphereCenter = p_start + p_travel.ScalarMult(collisionT);

						if (PointInSurface(collisionSphereCenter))
						{
							p_maxCollisionT = collisionT;
							return true;
						}
					}
				}

				return false;
			}

			bool SphereIntersection(Vector3d &p_position, float p_radius, float &p_distance, Vector3d &p_normal)
			{
				float distance = 10.0f;
				if (MathUtilities::SpherePlaneIntersection(p_position, p_radius, point0, normal, p_distance) == true)
				{
					if (PointInSurface(p_position))
					{
						p_normal = normal;
						return true;
					}
				}

				return false;
			}
		};

		class ColliderSet
		{
		public:
			ColliderSurface *surfaces;
			ColliderSegment *segments;
			ColliderPoint *points;

			int surfaceQty;
			int segmentQty;
			int pointQty;

			ColliderSet()
			{
				surfaces = nullptr;
				segments = nullptr;
				points = nullptr;

				surfaces = 0;
				segments = 0;
				points = 0;
			}

			~ColliderSet()
			{
				if (surfaces != nullptr)
				{
					delete[] surfaces;
					surfaceQty = 0;
				}
				if (segments != nullptr)
				{
					delete[] segments;
					segmentQty = 0;
				}
				if (points != nullptr)
				{
					delete[] points;
					pointQty = 0;
				}
			}

			void InitializeSurfaces(int p_surfaceQty)
			{
				surfaces = new ColliderSurface[p_surfaceQty];
				surfaceQty = p_surfaceQty;
			}
			void InitializeSegments(int p_segmentQty)
			{
				segments = new ColliderSegment[p_segmentQty];
				segmentQty = p_segmentQty;
			}
			void InitializePoints(int p_pointQty)
			{
				points = new ColliderPoint[p_pointQty];
				pointQty = p_pointQty;
			}

			ColliderSurface * GetSurface(int p_index)
			{
				return &surfaces[p_index];
			}
			ColliderSegment * GetSegment(int p_index)
			{
				return &segments[p_index];
			}
			ColliderPoint * GetPoint(int p_index)
			{
				return &points[p_index];
			}

			bool SphereCollision(Vector3d &p_start, Vector3d &p_travel, float p_radius, float &p_maxCollisionT, void **p_colliderObject, ColliderObjectType &p_type, Vector3d &p_collisionPoint, Vector3d &p_collisionNormal)
			{
				// p_maxCollisionT WILL be modifed if there is a collision
				bool result = false;

				// loop through all surfaces, segments and points.  Get earliest collision, the normal of the collision, and the contact point of the collision
				// if a collision with a surface occurs, no need to check segments or points.  If a collision with a segment occurs, no need to check points.

				for (int i = 0; i < surfaceQty; i++)
				{
					if (surfaces[i].SphereCollision(p_start, p_travel, p_radius, p_maxCollisionT) == true)
					{
						p_type = ColliderObjectType::Surface;
						*p_colliderObject = &surfaces[i];
						result = true;
					}
				}

				if (result == false)
				{
					for (int i = 0; i < segmentQty; i++)
					{
						if (segments[i].SphereCollision(p_start, p_travel, p_radius, p_maxCollisionT) == true)
						{
							p_type = ColliderObjectType::Segment;
							*p_colliderObject = &segments[i];
							result = true;
						}
					}
				}

				if (result == false)
				{
					for (int i = 0; i < pointQty; i++)
					{
						if (points[i].SphereCollision(p_start, p_travel, p_radius, p_maxCollisionT) == true)
						{
							p_type = ColliderObjectType::Point;
							*p_colliderObject = &points[i];
							result = true;
						}
					}
				}

				// if a collision happened, get the rest of the information
				if (result == true)
				{
					Vector3d collisionCenter = p_start + p_travel.ScalarMult(p_maxCollisionT);
					switch (p_type)
					{
					case ColliderObjectType::Surface:
						{
							ColliderSurface *surface = (ColliderSurface *)(*p_colliderObject);
							p_collisionPoint = surface->point0 + surface->normal.ScalarMult((surface->point0 - collisionCenter) * surface->normal);
							p_collisionNormal = surface->normal;
							p_collisionNormal.Normalize();
						}
						break;
					case ColliderObjectType::Segment:
						{
							ColliderSegment *segment = (ColliderSegment *)(*p_colliderObject);
							Vector3d collisionOffset = collisionCenter - segment->point0;
							p_collisionPoint = segment->point0 + segment->segmentUnit.ScalarMult(collisionOffset * segment->segmentUnit);
							p_collisionNormal = collisionCenter - p_collisionPoint;
							p_collisionNormal.Normalize();
						}
						break;
					case ColliderObjectType::Point:
						{
							ColliderPoint *point = (ColliderPoint *)(*p_colliderObject);
							p_collisionNormal = collisionCenter - point->position;
							p_collisionNormal.Normalize();
							p_collisionPoint = point->position;
						}
						break;
					}
				}

				return result;
			}

			bool SphereIntersection(Vector3d &p_position, float p_radius, float &p_distance, Vector3d &p_normal)
			{
				for (int i = 0; i < surfaceQty; i++)
				{
					if (surfaces[i].SphereIntersection(p_position, p_radius, p_distance, p_normal) == true)
					{
						return true;
					}
				}

				for (int i = 0; i < segmentQty; i++)
				{
					if (segments[i].SphereIntersection(p_position, p_radius, p_distance, p_normal) == true)
					{
						return true;
					}
				}

				for (int i = 0; i < pointQty; i++)
				{
					if (points[i].SphereIntersection(p_position, p_radius, p_distance, p_normal) == true)
					{
						return true;
					}
				}

				return false;
			}

			bool ContainSphere(Vector3d &p_position, float p_radius)
			{
				float distance;
				Vector3d normal;
				// get rid of while loop until we have a better way
				//bool done = false;
				//while (done == false)
				//{
					//done = true;

					for (int i = 0; i < surfaceQty; i++)
					{
						// make sure sphere is actually inside the sphere and deeply inside beyond it
						if (surfaces[i].SphereIntersection(p_position, p_radius, distance, normal) == true && p_radius > -distance)
						{
							p_position = p_position + normal.ScalarMult(p_radius - distance);
							//done = false;
						}
					}

					for (int i = 0; i < segmentQty; i++)
					{
						if (segments[i].SphereIntersection(p_position, p_radius, distance, normal) == true)
						{
							p_position = p_position + normal.ScalarMult(p_radius - distance);
							//done = false;
						}
					}

					for (int i = 0; i < pointQty; i++)
					{
						if (points[i].SphereIntersection(p_position, p_radius, distance, normal) == true)
						{
							p_position = p_position + normal.ScalarMult(p_radius - distance);
							//done = false;
						}
					}
				//}

				return false;
			}
		};
	}
}