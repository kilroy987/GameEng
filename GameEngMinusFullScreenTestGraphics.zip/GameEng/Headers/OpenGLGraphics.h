#pragma once

#include "GraphicsBase.h"

// standard gl headers from Microsoft - OpenGL 1.1
#include <gl\gl.h>
#include <gl\glu.h>
// from user SDK directory - access to constants and method pointer types for OpenGL 1.2 and up
#include <gl\glext.h>
#include <gl\wglext.h> // wglARB routine (core version for shader)

namespace GameEng {
	namespace Graphics {

		class OpenGLGraphicsTextureResource
		{
		public:
			GLuint textureId;

			OpenGLGraphicsTextureResource()
			{
				textureId = 0;
			}

			// destruction of this object must be handled at the parent level (see OpenGLGraphics::ClearTextureRendererResources)
		};

		class OpenGLGraphicsFontResource
		{
		public:
			GLuint fontTextureId;

			OpenGLGraphicsFontResource()
			{
				fontTextureId = 0;
			}
			
			// destruction of this object must be handled at the parent level (see OpenGLGraphics::ClearFontRendererResources)
		};

		class OpenGLGraphicsNativeObjectVAO
		{
		public:
			bool dynamicShaderCode; // should shader use dynamic code generation?
			GLuint vaoId;
			GLuint *vboIds;
			int vboQty;
			int triangleQty;
			bool elementArray; // is it set up as an element array?

			GraphicsNativeObjectRenderDefaultOptions defaultOptions;
			GraphicsNativeObjectComposition composition;

			OpenGLGraphicsNativeObjectVAO()
			{
				vaoId = -1;
				dynamicShaderCode = false;
				vboIds = nullptr;
				vboQty = 0;
				elementArray = false;
			}

			~OpenGLGraphicsNativeObjectVAO()
			{
				if (vboIds != nullptr)
				{
					delete[] vboIds;
					vboQty = 0;
				}

				if (defaultOptions.singleColor != nullptr)
				{
					delete defaultOptions.singleColor;
					defaultOptions.singleColor = nullptr;
				}
			}

			void Initialize(int p_vboQty)
			{
				vboIds = new GLuint[p_vboQty];
				vboQty = p_vboQty;
			}

			bool VaoIsSet()
			{
				return (vaoId != -1);
			}

			// use ONLY after clearing the resources!!! (OpenGLGraphics::ClearVAOResources)
			void UnsetVao()
			{
				vaoId = -1;
			}
		};

		class OpenGLGraphicsNativeObject
		{
		public:
			OpenGLGraphicsNativeObjectVAO *vaos;
			int vaoQty;

			OpenGLGraphicsNativeObject()
			{
				vaos = nullptr;
				vaoQty = 0;		
			}

			~OpenGLGraphicsNativeObject()
			{
				if (vaos != nullptr)
				{
					delete[] vaos;
					vaoQty = 0;
				}
			}

			void Initialize(int p_vaoQty)
			{
				vaos = new OpenGLGraphicsNativeObjectVAO[p_vaoQty];
				vaoQty = p_vaoQty;
			}
		};

		class OpenGLGraphicsNativeParticlesVAO
		{
		public:
			bool dynamicShaderCode; // should shader use dynamic code generation?
			GLuint vaoId;
			GLuint *vboIds;
			int vboQty;
			int pointQty; // total size of the array
			bool elementArray; // is it set up as an element array?

			GraphicsNativeParticlesDefaultOptions defaultOptions;
			GraphicsNativeParticlesComposition composition;

			OpenGLGraphicsNativeParticlesVAO()
			{
				dynamicShaderCode = false;
				vboIds = nullptr;
				vboQty = 0;
				elementArray = false;
			}

			~OpenGLGraphicsNativeParticlesVAO()
			{
				if (vboIds != nullptr)
				{
					delete[] vboIds;
					vboQty = 0;
				}

				if (defaultOptions.singleColor != nullptr)
				{
					delete defaultOptions.singleColor;
					defaultOptions.singleColor = nullptr;
				}
			}

			void Initialize(int p_vboQty)
			{
				vboIds = new GLuint[p_vboQty];
				vboQty = p_vboQty;
			}

		};

		class OpenGLGraphicsNativeParticles
		{
		public:
			OpenGLGraphicsNativeParticlesVAO *vaos;
			int vaoQty; 
			bool uploaded;

			OpenGLGraphicsNativeParticles()
			{
				vaos = nullptr;
				vaoQty = 0;
				uploaded = false;
			}

			~OpenGLGraphicsNativeParticles()
			{
				if (vaos != nullptr)
				{
					delete[] vaos;
					vaoQty = 0;
				}
			}

			void Initialize(int p_vaoQty)
			{
				vaos = new OpenGLGraphicsNativeParticlesVAO[p_vaoQty];
				vaoQty = p_vaoQty;
			}
		};

		class OpenGLGraphicsNativePolygonVAO
		{
		public:
			GLuint vaoId;
			GLuint *vboIds;
			int vboQty;
			bool elementArray; // is it set up as an element array?
			int triangleQty;

			GraphicsNativePolygonComposition composition;

			OpenGLGraphicsNativePolygonVAO()
			{
				vboIds = nullptr;
				vboQty = 0;
				elementArray = false;
				triangleQty = 0;
			}

			~OpenGLGraphicsNativePolygonVAO()
			{
				if (vboIds != nullptr)
				{
					delete[] vboIds;
					vboQty = 0;
				}
			}

			void Initialize(int p_vboQty)
			{
				vboIds = new GLuint[p_vboQty];
				vboQty = p_vboQty;
			}
		};

		class OpenGLGraphicsNativePolygonQueue
		{
		public:
			OpenGLGraphicsNativePolygonVAO *vaos;
			int vaoQty;
			bool uploaded;

			OpenGLGraphicsNativePolygonQueue()
			{
				vaos = nullptr;
				vaoQty = 0;
				uploaded = false;
			}

			~OpenGLGraphicsNativePolygonQueue()
			{
				if (vaos != nullptr)
				{
					delete[] vaos;
					vaoQty = 0;
				}
			}

			void Initialize(int p_vaoQty)
			{
				vaos = new OpenGLGraphicsNativePolygonVAO[p_vaoQty];
				vaoQty = p_vaoQty;
			}
		};


		class OpenGLGraphicsNativeProgramContainer
		{
		public:
			GLuint programId;
		};

		// resources used by OpenGL to be created and destroyed for GraphicsFrameBuffer
		class OpenGLFramebuffer
		{
		public:
			GLuint framebufferId[6]; // always have this, only 1 used when only one render buffer or texture is necessary

			// one or the other, never both
			GLuint colorRenderbufferId[6]; // for cubemap, 1 for each face - if single, only [0] is meaningful
			GLuint colorTextureId;

			// one or the other, never both
			GLuint depthRenderbufferId[6]; // for cubemap, 1 for each face - if single, only [0] is meaningful
			GLuint depthTextureId;

			// additional attachments beyond main
			// todo: track formats of each if necessary
			GLuint attachmentTextureIds[7]; // variable number of attachment textures
			int attachmentTextureQty;

			OpenGLFramebuffer()
			{
				for (int i = 0; i < 6; i++)
				{
					framebufferId[i] = 0;
					colorRenderbufferId[i] = 0;
					depthRenderbufferId[i] = 0;
				}
				colorTextureId = 0;
				depthTextureId = 0;

				attachmentTextureQty = 0;
			}

			// destuction of this object must be handled at parent level - see OpenGLGraphics::ClearFramebufferResources
		};

		// Primary todos:
		// - Finish multiple output buffer routines (usage, validation, splicing out component calculations for outputs (ex. normal that would be used for single pass lighting or output to a normal
		//      buffer for deferred lighting), etc.)
		// - Fragment velocity motion blur, Light shafts (including 'god light'), ambient occlusion, deferred lighting
		// - Fix 4-texture terrain rendering - integrate it into the auto-written shader code and get rid of the hard-coded shader code, to remove confusion.
		// - Fix any remaining exceptions from the framework test code (some tests exception out because of graphic shader routine upgrades)
		// Questions:
		// - (answered) If fragment calculation is truly multithreaded, what happens with a number of layered polygons that are occlusively alpha blended?  Since particle sorting works
		//    for smoke, I can only assume that within a triangle, its fragments are multithreaded, but each triangle (or whatever element is identified in glDrawArrays) is rendered
		//    in the order specified by the vertex array.
		// - is there a way to alter the position of a fragment inside the fragment shader?  I assume not since then multiple threads could write to the same output.  But this isn't necessarily
		//    a bad thing as long as nothing is reading from the output until all are finished.
		// - what happens when an input texture is also the output buffer?  Is the result written to the texture AFTER all the fragments are complete, or are they each written as they are completed?
		//    If the latter is true, there is no guarantee that the input texture won't change in a location that is being read for another fragment that hasn't been rendered yet, causing undefined
		//    (that is, wacky) results.
		class OpenGLGraphics : public GraphicsBase
		{
		private:
			HWND hWnd; // window handle
			HDC glDC; // device context
			HGLRC glRC; // rendering context

			gcroot<System::String^> version;
			int majorVersion;
			int minorVersion;
			int releaseVersion;

			int viewportWidth, viewportHeight; // needed at initialize so that first gluPerspective call has data it needs
			float pixelToWorldScale; // convenience when projection set, used to convert viewport XY to world Vector

			GLint currentCullFace;

			GLenum GetClipPlaneEnum(int p_clipPlaneId);

			GLenum ConvertBlendFuncEnum(GraphicsBlendFuncEnum p_enum)
			{
				switch (p_enum)
				{
				case GraphicsBlendFuncEnum::Source_Alpha:
					return GL_SRC_ALPHA;
					break;
				case GraphicsBlendFuncEnum::One_Minus_Source_Alpha:
					return GL_ONE_MINUS_SRC_ALPHA;
					break;
				case GraphicsBlendFuncEnum::One:
					return GL_ONE;
					break;
				default:
					throw gcnew System::Exception("Unsupported GraphicsBlendFuncEnum - make sure all are handled int he case statement");
				}
			}

			// extension routines (glext.h)
			PFNGLGENERATEMIPMAPPROC glGenerateMipmap;
			PFNGLGETPROGRAMIVPROC glGetProgramiv;
			PFNGLGETPROGRAMINFOLOGPROC glGetProgramInfoLog;
			PFNGLDELETEPROGRAMPROC glDeleteProgram;
			PFNGLCREATEPROGRAMPROC glCreateProgram;
			PFNGLATTACHSHADERPROC glAttachShader;
			PFNGLDELETESHADERPROC glDeleteShader;
			PFNGLCREATESHADERPROC glCreateShader;
			PFNGLSHADERSOURCEPROC glShaderSource;
			PFNGLGETSHADERIVPROC glGetShaderiv;
			PFNGLGETSHADERINFOLOGPROC glGetShaderInfoLog;
			PFNGLGETUNIFORMLOCATIONPROC glGetUniformLocation;
			PFNGLUSEPROGRAMPROC glUseProgram;
			PFNGLUNIFORM3FVARBPROC glUniform3fvARB;
			PFNGLLINKPROGRAMPROC glLinkProgram;
			PFNGLCOMPILESHADERPROC glCompileShader;
			PFNGLDELETEBUFFERSPROC glDeleteBuffers;
			PFNGLDELETEVERTEXARRAYSPROC glDeleteVertexArrays;
			PFNGLGENBUFFERSPROC glGenBuffers;
			PFNGLBINDBUFFERPROC glBindBuffer;
			PFNGLBUFFERDATAPROC glBufferData;
			PFNGLBUFFERSUBDATAPROC glBufferSubData;
			PFNGLGENVERTEXARRAYSPROC glGenVertexArrays;
			PFNGLBINDVERTEXARRAYPROC glBindVertexArray;
			PFNGLENABLEVERTEXATTRIBARRAYPROC glEnableVertexAttribArray;
			PFNGLVERTEXATTRIBPOINTERPROC glVertexAttribPointer;
			PFNGLVERTEXATTRIBIPOINTERPROC glVertexAttribIPointer; // critical for using ints in vbos - otherwise GL will convert them to floats with glVertexAttribPointer even if the format given is INT because you are only telling GL the data you're sending, not what you want to keep it as
			PFNGLACTIVETEXTUREPROC glActiveTexture;
			// uniform
			PFNGLUNIFORM4FVPROC glUniform4fv;
			PFNGLUNIFORMMATRIX4FVPROC glUniformMatrix4fv;
			PFNGLUNIFORM1IPROC glUniform1i;
			PFNGLUNIFORM1FPROC glUniform1f;
			PFNGLUNIFORM1FVPROC glUniform1fv;
			PFNGLUNIFORM3FVPROC glUniform3fv;
			PFNGLGETUNIFORMFVPROC glGetUniformfv;
			// FRAME BUFFERS
			// for GameEng, a GraphicsFrameBuffer is the primary container object with a color and/or depth render buffer that are either a renderbuffer, texture, or combo.  
			// When destroyed, all of these resource are destroyed when the frame buffer is destroyed
			// for GL, a frame buffer is the ultimate rendering target and is made up of a combination of render buffers and textures.  Textures can be rendered decaling other geometry later.  Render buffers are just resources for processing to accomplish the task without being a persistent texture.
			PFNGLGENFRAMEBUFFERSPROC glGenFramebuffers;
			PFNGLBINDFRAMEBUFFERPROC glBindFramebuffer; // if 0, render to screen, otherwise set a frame buffer as the render target, or the framebuffer currently being configures (bind 0 when done)
			PFNGLFRAMEBUFFERRENDERBUFFERPROC glFramebufferRenderbuffer; // attach a render buffer
			PFNGLFRAMEBUFFERTEXTURE2DPROC glFramebufferTexture2D; // attach a texture
			PFNGLFRAMEBUFFERTEXTUREPROC glFramebufferTexture; // another way of attaching a texture
			PFNGLDELETEFRAMEBUFFERSPROC glDeleteFramebuffers;
			PFNGLGENFRAMEBUFFERSPROC glGenRenderbuffers;
			PFNGLBINDFRAMEBUFFERPROC glBindRenderbuffer;
			PFNGLRENDERBUFFERSTORAGEPROC glRenderbufferStorage;
			PFNGLDELETEFRAMEBUFFERSPROC glDeleteRenderbuffers;
			PFNGLDRAWBUFFERSPROC glDrawBuffers; // used to determine where colors will be drawn to for the bound frame buffer (depth is automatically written to anything that is a depth attachment and doesn't need to be configured)
			PFNGLCHECKFRAMEBUFFERSTATUSPROC glCheckFramebufferStatus;

			// wglext.h
			PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB;
			// vsync enabling/disabling
			PFNWGLSWAPINTERVALEXTPROC wglSwapIntervalEXT;
			PFNWGLGETSWAPINTERVALEXTPROC wglGetSwapIntervalEXT;

			// vertex and fragment shaders are compiled live as each program is built so that they don't continue to take up memory, so no need to hold on to their Ids.
			// Implementation should provide the source for custom shaders so they can be compiled later. (Implementation Id 0, 1, 2, etc which this class converts to ImplementationStartIndex, +1, +2, etc,)
			// not currently used, could be removed
			GLuint **shaderProgramIds; // 2d array: dimensions vertexQty * fragmentQty
			//GLuint *vertexShaderIds;
			int vertexShaderQty;
			//GLuint *fragmentShaderIds;
			int fragmentShaderQty;

			// prevents extra state switching
			// store information of selected frame buffer, so that when CreateFramebuffer is called, the original framebuffer can be reactivated again
			GLuint currentShaderProgramId;
			GLuint currentFramebufferUsage;
			GraphicsFrameBufferContainer *currentFramebuffer;
			int currentFramebufferFaceIndex;
			// when rendering to a depth buffer, these get set to GL_NONE, so when we restore back to render to the main screen, we will have to set them to GL_BACK again.
			GLuint currentDrawBuffer;
			GLuint currentReadBuffer;
			GLint mainFramebufferId; // original frame buffer id, in case it isn't zero

			OpenGLGraphicsNativeObjectVAO postProcessingShaderVao;

		public:
			void Initialize(System::Windows::Forms::PictureBox ^p_pictureBoxRef, HWND p_hWnd, int p_viewportWidth, int p_viewportHeight) override;
			void Destroy() override;

			OpenGLGraphics()
			{
				version = nullptr;

				majorVersion = 0;
				minorVersion = 0;
				releaseVersion = 0;

				currentCullFace = 0;

				pixelToWorldScale = 0;

				InitializeExtensionRoutines();

				shaderProgramIds = nullptr;
				//vertexShaderIds = nullptr;
				vertexShaderQty = 0;
				//fragmentShaderIds = nullptr;
				fragmentShaderQty = 0;

				compositionShaderQty = 0;

				currentShaderProgramId = 0;

				currentFramebufferUsage = GL_FRAMEBUFFER;
				currentFramebuffer = nullptr;
				currentFramebufferFaceIndex = 0;

				ClearShaderPrograms();

				shadowMapTextureQuadNativeObject = nullptr;
				cubeShadowMapFaceTextureQuadNativeObject = nullptr;
			}
			virtual ~OpenGLGraphics()
			{
				Destroy();
			}

			void InitializeExtensionRoutines();
			void GetExtensionRoutines();

			System::String^ GetAPIVersion(int &p_major, int &p_minor, int &p_release);

			void MakeCurrent() override;
			void SetViewportSize(int p_width, int p_height) override;
			void ClearScreen(GameColor &p_color) override;
			void ClearBuffer(int p_bufferIndex, Vector4d &p_values) override;

			void SetDrawBuffers(int *p_bufferIndices, int p_bufferIndexQty) override;

			void ClearDepth();
			void ColorMask(bool p_red, bool p_green, bool p_blue, bool p_alpha);

			void SetStencilEnabled(bool p_enable);
			void ClearStencil();
			void StencilTest(GraphicsStencilTestFuncEnum p_stencilTest, int p_value, unsigned char p_mask);
			void StencilMask(unsigned char p_mask);
			void StencilOperations(GraphicsStencilOperationEnum p_onStencilPass, GraphicsStencilOperationEnum p_onStencilPassAndDepthFail, GraphicsStencilOperationEnum p_onStencilPassAndDepthPass);

			void SetPerspectiveProjection(float p_yAngleDegrees, double p_near, double p_far) override;
			private:
			void CalculateProjectionFrustum(float p_yAngleDegrees, float p_aspect, double p_near, double p_far);
			public:
			void SetPerspectiveProjectionStereoscopicLeft(float p_yAngleDegrees, double p_near, double p_far, StereoscopicCamera &p_camera) override;
			void SetPerspectiveProjectionStereoscopicRight(float p_yAngleDegrees, double p_near, double p_far, StereoscopicCamera &p_camera) override;
			void SetOrthoProjection(double p_near, double p_far) override;
			void Set2dWindowProjection(float p_minZ = -1.0f, float p_maxZ = 1.0f) override;

			Vector3d ConvertViewportCoordinatesToWorldVector(int p_viewportX, int p_viewportY) override;

			// matrix data
			Matrix4d GetMVPMatrix() override;

			void DefaultTransform() override;
			void DefaultTransformStereoscopicLeft(StereoscopicCamera &p_camera) override;
			void DefaultTransformStereoscopicRight(StereoscopicCamera &p_camera) override;
			void Rotate(float p_angle, Vector3d &p_vector) override;
			void Translate(float p_x, float p_y, float p_z) override;
			void Translate(Vector3d &p_offset) override;
			void Transform(Orient3d &p_orient) override;
			void ReverseTransform(Orient3d &p_orient) override;
			void Scale(float p_x, float p_y, float p_z) override;

			void PushMatrix() override;
			void PopMatrix() override;

			void SetDepthWriteEnabled(bool p_enabled) override;
			void SetDepthTestEnabled(bool p_enabled) override;
			void SetDepthFunc(GraphicsDepthFuncEnum p_depthFunc) override;
			void SetDepthRange(float p_minZ, float p_maxZ) override;
			void SetBlendFunc(GraphicsBlendFuncEnum p_srcFunc, GraphicsBlendFuncEnum p_dstFunc) override;
			void SetPolygonFill(bool p_fill) override;

			void SetClipPlane(int p_clipPlaneId, Vector3d &p_position, Vector3d &p_renderSpaceNormal, bool p_prepareForShader = true) override;
			void DisableClipPlane(int p_clipPlaneId, bool p_prepareforShader = true) override;
			void SetZBias(float p_factor, float p_units) override;
			void DisableZBias() override;
			void FlipCullFace() override;

			void LoadTexture(GameTexture ^p_texture) override;

			void RenderTestTriangle() override;
			void RenderSurfaces(GameColor *p_colors, int p_colorQty, ModelSurface *p_surfaces, int p_surfaceQty, ModelVertex *p_vertices, int p_vertexQty) override;
			void RenderTerrainRegion(TerrainMeshLevelOfDetail &p_region, TerrainMeshStitchMap &p_stitchMap, gcroot<GameTexture ^> *p_textures = nullptr, float p_XZPerWrap = 0.0f) override;
			// OpenGL only, not GraphicsBase
			void RenderTerrainRegionWithTexture(TerrainMeshLevelOfDetail &p_region, TerrainMeshStitchMap &p_stitchMap, gcroot<GameTexture ^> *p_textures = nullptr, float p_XZPerWrap = 0.0f);

			void RenderStarfieldPoints(StarfieldPoint *p_stars, int p_starQty, Orient3d &p_currentOrient, Orient3d *p_priorOrient = nullptr) override;
			void RenderLineStrip(float p_lineWidth, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, bool p_alphaBlend = false) override;
			void RenderFilledQuad(GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, bool p_alphaBlend = false, GameTexture ^p_texture = nullptr, ModelVertexTextureCoords *p_texCoords = nullptr, int p_texCoordsQty = 0, float p_startS = 0.0f, float p_startT = 0.0f, float p_scaleS = 1.0f, float p_scaleT = 1.0f, float p_trapezoidTopSize = 1.0f, float p_trapezoidBottomSize = 1.0f) override;

			// 2d rendering
			void RenderFont(String ^p_string, GameFont ^p_font, float p_x, float p_y, GameColor &p_color) override;
			void RenderFont(String ^p_string, GameFont ^p_font, int p_x, int p_y, GameColor &p_color) override;
			void RenderFilledRectangle(System::Drawing::RectangleF &p_rect, GameColor &p_color) override;

			void FinishRender() override;
			void SwapBuffers() override;
			void SetVSyncEnabled(bool p_enabled) override;
			bool VSyncIsEnabled() override;

private:
			void ClearVAOResources(OpenGLGraphicsNativeObjectVAO &p_vao);
public:
			void ClearFontRendererResources(void *) override;
			void ClearTextureRendererResources(void *) override;
			void ClearNativeObjectResources(void *) override;
			void ClearNativeParticlesResources(void *) override;
			void ClearNativePolygonQueueResources(void *) override;
			void ClearFrameBufferResources(void *) override;

			// Shader operations
private:
			void SelectShaderProgram(int p_programId);

			const GLchar* GetVertexShaderSource(int p_vertexShaderOperation, GraphicsShaderComposition *p_shaderComposition = nullptr, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			const GLchar* GetFragmentShaderSource(int p_fragmentShaderOperation, GraphicsShaderComposition *p_shaderComposition = nullptr, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			GLuint CompileVertexShader(int p_vertexShaderOperation, const GLchar* p_source);
			GLuint CompileGeometryShader(int p_geometryShaderOperation, const GLchar* p_source);
			GLuint CompileFragmentShader(int p_fragmentShaderOperation, const GLchar* p_source);
			GLuint LinkShaderProgram(int p_vertexShaderOperation, int p_fragmentShaderOperation, GraphicsShaderComposition *p_composition = nullptr);
			void PrepareTextureForShader(GameTexture ^p_texture, GLuint p_textureSlot, bool p_allowMipMap = true);
			void PrepareCubeTextureForShader(GameTexture ^p_texture, GLuint p_textureSlot, bool p_allowMipMap = true);
			GLuint PrepareProgramForShader(int p_vertexShaderOperation, int p_fragmentShaderOperation, GraphicsShaderComposition *p_composition = nullptr);
			void ClearNativeProgram(OpenGLGraphicsNativeProgramContainer *p_programPtr);
public:
			void InitializeShaders(int p_vertexShaderQty, int p_fragmentShaderQty) override;
			void RenderQuadShader(GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, GraphicsShaderOptions %p_shaderOptions) override;
			// pointer created will be tracked so that the graphics class can destroy the object when the graphics API is destroyed
			void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, gcroot<GameTexture^> *p_textures, int p_textureQty, ModelVertexTextureCoords *p_texCoords, int p_texCoordsQty, ModelVertexTextureCoords *p_texCoordsBlendMap = nullptr, int p_texCoordsBlendMapQty = 0, Vector3d *p_vertexNormals = nullptr, int p_vertexNormalQty = 0, Vector3d *p_vertexTangents = nullptr, Vector3d *p_vertexBinormals = nullptr, gcroot<GameTexture^> p_bumpMapTexture = nullptr) override;
			void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, ModelSurface *p_surfaces, int p_surfaceQty, bool p_lightingNormals = false) override;
			void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, JointedModelNativeData *p_jointedModelNativeData, int p_jointedModelQty, bool p_lightingNormals = false) override;
			void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, TerrainMeshLevelOfDetail &p_region, gcroot<GameTexture^> *p_textures, float p_XZPerWrap, int p_startH, int p_endH, int p_startV, int p_endV);
			void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsVertexPool &p_vertexPool, gcroot<GameTexture^> *p_textures);
			void RenderNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsShaderOptions %p_renderOptions) override;
			// render specifically to a framebuffer target that is a shadow map - uses only mvps, vertices and joint mvps
			void RenderNativeObjectToShadowMap(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsShaderOptions %p_renderOptions) override;
			void RenderNativeObjectToCubeShadowMap(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsShaderOptions %p_renderOptions) override;
			// render a shadowmap texture to a quad for debugging - uses only the shadowmap texture, mvp and quad vertices, reuses native data by uploading quad vertices before render
			void RenderShadowMap(Vector3d *p_vertices, GraphicsShaderOptions %p_renderOptions) override;
			void RenderCubeShadowMapFace(Vector3d *p_vertices, ModelVertexTextureCoords3d *p_texCoords, GraphicsShaderOptions %p_renderOptions) override;
			void ClearShaderPrograms() override;

			// particles
			void CreateNativeParticles(GraphicsNativeParticlesContainer *p_nativeObjectPtr, ParticleArray *p_particles) override;
			void RenderNativeParticles(GraphicsNativeParticlesContainer *p_nativeObjectPtr, GraphicsShaderParticlesOptions %p_renderOptions, ParticleArray *p_particleArray) override;
			void UploadParticleStorageToNativeParticles(GraphicsParticlesStorageOptions &p_storageOptions, OpenGLGraphicsNativeParticlesVAO *p_vao, ParticleArray *p_particleArray, bool p_initialize = true, int p_particleQty = -1);
private:
			GLuint PrepareParticlesProgramForShader(GraphicsParticlesShaderComposition &p_composition);
			const GLchar* GetParticleVertexShaderSource(GraphicsParticlesShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			const GLchar* GetParticleGeometryShaderSource(GraphicsParticlesShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			const GLchar* GetParticleFragmentShaderSource(GraphicsParticlesShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			GLuint LinkParticleShaderProgram(GraphicsParticlesShaderComposition &p_composition);

public:
			void CreateParticleQueue(GraphicsParticleQueue *p_particleQueue, int p_particleQty);
			void SubmitParticlesToQueue(GraphicsParticleQueue *p_particleQueue, LinkedList<Particle> &p_particles, GraphicsShaderParticlesOptions &p_particleOptions);
			void CommitParticleQueue(GraphicsParticleQueue *p_particleQueue, GraphicsShaderParticlesOptions &p_particleOptions);
private:
			void RenderParticleQueue(GraphicsParticleQueue *p_particleQueue, GraphicsShaderParticlesOptions &p_particleOptions);
public:
			// polygon queue
			void CreatePolygonQueue(GraphicsPolygonQueue *p_polygonQueue, int p_triangleQty);
			void SubmitPolygonToQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, bool p_alphaBlend = false, GameTexture ^p_texture = nullptr, ModelVertexTextureCoords *p_texCoords = nullptr, int p_texCoordsQty = 0, float p_startS = 0.0f, float p_startT = 0.0f, float p_scaleS = 1.0f, float p_scaleT = 1.0f, float p_trapezoidTopSize = 1.0f, float p_trapezoidBottomSize = 1.0f);
			void SubmitModelToPolygonQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions, GameColor *p_colors, int p_colorQty, ModelSurface *p_surfaces, int p_surfaceQty, ModelVertex *p_vertices, int p_vertexQty, Orient3d &p_orient, Vector3d &p_scale);
			void CommitPolygonQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions);
private:
			void RenderPolygonQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions);
			GLuint PreparePolygonProgramForShader(GraphicsPolygonShaderComposition &p_composition);
			const GLchar* GetPolygonVertexShaderSource(GraphicsPolygonShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			const GLchar* GetPolygonFragmentShaderSource(GraphicsPolygonShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			GLuint LinkPolygonShaderProgram(GraphicsPolygonShaderComposition &p_composition);

public:
			// post processing
			void RenderPostProcessingShaderQuad(ModelVertex *p_surfaceVertices, ModelVertexTextureCoords *p_quadTexCoords, GraphicsPostProcessShaderOptions %p_renderOptions);
private:
			GLuint PreparePostProcessingProgramForShader(GraphicsPostProcessShaderComposition &p_composition);
			const GLchar*  GetPostProcessingVertexShaderSource(GraphicsPostProcessShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			const GLchar*  GetPostProcessingFragmentShaderSource(GraphicsPostProcessShaderComposition *p_shaderComposition, char *p_sourceStorage = nullptr, int p_maxSourceStorageLength = -1);
			GLuint LinkPostProcessingShaderProgram(GraphicsPostProcessShaderComposition &p_composition);

public:
			// render buffers
			void CreateFrameBuffer(GraphicsFrameBufferContainer *p_frameBufferPtr, GraphicsFrameBufferTypeEnum p_colorBufferType, GraphicsFrameBufferTypeEnum p_depthBufferType, int p_width, int p_height, int p_faces = 1, bool p_supportDepthStencil = false, GraphicsFrameBufferColorFormatEnum *p_attachmentColorFormats = nullptr, int p_attachmentColorFormatQty = 0) override;
			void SetCurrentFrameBuffer(GraphicsFrameBufferContainer* p_framebuffer = nullptr, int p_faceIndex = 0);
			// only for special circumstances in implementation
			void DestroyFrameBuffer(GraphicsFrameBufferContainer *p_frameBufferPtr);
		};
	}
}