#pragma once

#include <Windows.h> // HWND

#include "GraphicsBase.h"
#include "OpenGLGraphics.h"

namespace GameEng {
	namespace Graphics {

		using namespace System;

		public ref class GameViewport {
			System::Windows::Forms::PictureBox ^pictureBoxRef;	// only needed if GDI
			HWND hWnd;
			String ^name;
			int width, height; // only really needed on first initialize to set the size of the renderer viewport, for now
			System::Drawing::Point screenLocation; // upper left corner

			GraphicsBase *graphics;

		public:
			GameViewport(String ^p_name, HWND p_hWnd, int p_width, int p_height)
			{
				pictureBoxRef = nullptr;
				hWnd = p_hWnd;
				name = p_name;
				width = p_width;
				height = p_height;
				// todo: screen location?
			}

			GameViewport(String ^p_name, System::Windows::Forms::PictureBox ^p_pictureBoxRef)
			{
				pictureBoxRef = p_pictureBoxRef;
				hWnd = static_cast<HWND>(pictureBoxRef->Handle.ToPointer());
				name = p_name;
				width = p_pictureBoxRef->Size.Width;
				height = p_pictureBoxRef->Size.Height;
				screenLocation = p_pictureBoxRef->PointToScreen(p_pictureBoxRef->Location);
			}

			~GameViewport()
			{
				DestroyGraphics();
			}

			void SetViewportSizeAndScreenLocation(int p_width, int p_height, System::Drawing::Point &p_screenLocation)
			{
				width = p_width;
				height = p_height;

				screenLocation = p_screenLocation;

				if (graphics != nullptr)
					graphics->SetViewportSize(p_width, p_height);
			}

			void SetGraphics(GraphicsTypeEnum p_graphicsTypeEnum)
			{
				DestroyGraphics();

				switch (p_graphicsTypeEnum)
				{
				case GraphicsTypeEnum::OpenGL:
					graphics = new OpenGLGraphics();
					break;
				case GraphicsTypeEnum::None:
					throw gcnew Exception("Cannot set no graphics");
					break;
				case GraphicsTypeEnum::GDI:
					throw gcnew Exception("GDI not yet supported");
					break;
				case GraphicsTypeEnum::DirectX:
					throw gcnew Exception("DirectX not yet supported");
					break;
				}

				graphics->Initialize(pictureBoxRef, hWnd, width, height); // only GDI uses the picturebox, height and width are only necessary for initial setting of the viewport size to the renderer
			}

			String ^ GetName()
			{
				return name;
			}

			GraphicsBase * GetGraphics()
			{
				return graphics;
			}

			void DestroyGraphics()
			{
				if (graphics != nullptr)
				{
					delete graphics;
					graphics = nullptr;
				}
			}

			HWND GetWindowHandle()
			{
				return hWnd;
			}

			int GetWidth()
			{
				return width;
			}

			int GetHeight()
			{
				return height;
			}

			System::Drawing::Point GetScreenLocation()
			{
				return screenLocation;
			}
		};

		public ref class GameViewportRegistry
		{
			System::Collections::Generic::List<GameViewport^> Viewports;

		public:
			int RegisterViewport(String ^p_name, System::Windows::Forms::PictureBox ^p_pictureBox)
			{
				Viewports.Add(gcnew GameViewport(p_name, p_pictureBox));
				return Viewports.Count - 1;
			}
			int RegisterViewport(String ^p_name, HWND p_hWnd, int p_width, int p_height)
			{
				Viewports.Add(gcnew GameViewport(p_name, p_hWnd, p_width, p_height));
				return Viewports.Count - 1;
			}

			GameViewport^ GetViewport(String ^p_name)
			{
				for each (GameViewport ^vp in Viewports)
				{
					if (vp->GetName() == p_name)
						return vp;
				}

				return nullptr;
			}

			GameViewport^ GetViewport(int p_index)
			{
				if (p_index >= 0 && Viewports.Count > p_index)
					return Viewports[p_index];

				return nullptr;
			}

			void Destroy()
			{
				for each(GameViewport ^vp in Viewports)
				{
					delete vp;
				}
			}

			void DestroyGraphics()
			{
				for each (GameViewport ^vp in Viewports)
					vp->DestroyGraphics();
			}
		};
	}
}