#pragma once

#include "ModelSurface.h"
#include "Frustum.h"
#include "GraphicsBase.h"
#include "Collider.h"
#include "BoundingVolume.h"
#include "Partition.h"
#include "PortalData.h"

namespace GameEng {
	namespace PortalEngine {

		using namespace GameEng::Graphics;
		using namespace GameEng::Collider;
		using namespace GameEng::Geometry;

		// a single 'room'
		// note: for now, all surfaces are intended to be concave so that which room a point is in can be determined.  Until this is upgraded, this requirement stands

		// yes, I know, it's just a portal that is part of the Portal separation of code.  Shuuup.
		class PortalPortal
		{
		public:
			// front sides of portals are situated clockwise (order of vertices).  Backsides, then, are ccw and opposite of the normal
			// index of -1 means no node on that side
			int frontNodeIndex;
			int backNodeIndex;

			// no visible nodes, just start in the current node and render the mirrored universe - stencil, clipplane and reverse view to render
			bool mirror;

			// a floating portal leading into a new area - like a portal on a wide wall leading out of a thin pillar - stencil and clipplane it to render because it defies physics
			bool gateWay;

			Vector3d *vertices;
			int vertexQty;
			Vector3d normal; // faces outward from the vertices defined in clockwise fashion.  Always ([2]-[1]) x ([1]-[0])
			Vector3d center; // center of all points in portal for various purposes (not needed for portal rendering or determining node containment)

			// ready for use
			bool committed;

			PortalPortal()
			{
				frontNodeIndex = -1;
				backNodeIndex = -1;
				mirror = false;
				gateWay = false;

				vertices = nullptr;
				vertexQty = 0;

				committed = false;
			}

			void Initialize(int p_vertexQty)
			{
				vertices = new Vector3d[p_vertexQty];
				vertexQty = p_vertexQty;
			}

			void Commit()
			{
				if (vertexQty < 3)
					throw gcnew System::Exception(String::Format("Vertex Qty must be >= 3, found {0}", vertexQty));
				CalculateNormal();
				CalculateCenter();

				committed = true;
			}

			void Enlarge(float p_worldSize)
			{
				// get offsets of each vertex from center and move them out by that world value
				// enlarging helps prevent corner-corner artifacts in rendering but does not endanger any infinite loops
				for (int v = 0; v < vertexQty; v++)
				{
					Vector3d offset = vertices[v] - center;
					if (offset.Normalize() == false)
						throw gcnew Exception("offset from center is zero - is this portal correct?");

					vertices[v] = vertices[v] + offset.ScalarMult(p_worldSize);
				}
			}

			// don't use - there is some bug preventing frustum assumptions from remaining true
			bool WillEmptyFrustum(Frustum *p_frustum)
			{
				int startIndex = 0;
				int stopIndex = vertexQty;
				int offset = 1;

				// todo: watch out for being even with portal - special case
				if (PointInFront(p_frustum->origin) == false)
				{
					// handle counter clockwise
					startIndex = vertexQty - 1;
					stopIndex = -1;
					offset = -1;
				}

				Vector3d portalSegment;
				Vector3d originSegment;
				for (int i = startIndex; i != stopIndex; i += offset)
				{
					if ((i + offset) == stopIndex)
						portalSegment = vertices[startIndex] - vertices[i];
					else
						portalSegment = vertices[i + offset] - vertices[i];

					originSegment = p_frustum->origin - vertices[i];

					if (p_frustum->PlaneWillEmptyFrustum(portalSegment.CrossProd(originSegment)) == true)
						return true;
				}

				return false;
			}

			// further intersect frustum with element of portal
			// return false if frustum has been emptied (portal cannot be 'seen' by frustum)
			bool AddToFrustum(Frustum *p_frustum, bool p_willNotEmpty = false)
			{
				// don't call with p_willNotEmpty = true - causes bug that breaks frustum assumptions

				// call with p_willNotEmpty == true ONLY if WillEmptyFrustum was called and returned false!!!

				int startIndex = 0;
				int stopIndex = vertexQty;
				int offset = 1;

#ifdef _DEBUG
				Frustum originalFrustum;
				p_frustum->CopyTo(&originalFrustum);
#endif

				// todo: watch out for being even with portal - special case
				if (PointInFront(p_frustum->origin) == false)
				{
					// handle counter clockwise
					startIndex = vertexQty - 1;
					stopIndex = -1;
					offset = -1;
				}

				Vector3d portalSegment;
				Vector3d originSegment;
				for (int i = startIndex; i != stopIndex; i += offset)
				{
					if ((i + offset) == stopIndex)
						portalSegment = vertices[startIndex] - vertices[i];
					else
						portalSegment = vertices[i + offset] - vertices[i];

					originSegment = p_frustum->origin - vertices[i];

					if (p_frustum->AddPlane(portalSegment.CrossProd(originSegment), p_willNotEmpty) == false)
						return false;
				}

#ifdef _DEBUG
				// verify that the original p_frustum contains the new one
				float failedResult;
				if (originalFrustum.Contains(p_frustum, failedResult) == false)
				{
					// make some analysis code that can be pasted somewhere
					String ^analysisCode = "";
					analysisCode += "Frustum testFrustum;\r\n";
					analysisCode += String::Format("testFrustum.origin = Vector3d({0:F12}f, {1:F12}f, {2:F12}f);\r\n", originalFrustum.origin.x, originalFrustum.origin.y, originalFrustum.origin.z);
					LinkedListEnumerator<FrustumPlane> enumerator = originalFrustum.GetPlaneEnumerator();
					while (enumerator.MoveNext())
					{
						analysisCode += String::Format("testFrustum.AddPlane(Vector3d({0:F12}f, {1:F12}f, {2:F12}f));\r\n", enumerator.Current()->data.normalUnit.x, enumerator.Current()->data.normalUnit.y, enumerator.Current()->data.normalUnit.z);
					}
					analysisCode += "// add planes that cause problem\r\n";
					analysisCode += "Frustum originalFrustum;\r\n";
					analysisCode += "testFrustum.CopyTo(&originalFrustum);\r\n";
					for (int i = startIndex; i != stopIndex; i += offset)
					{
						if ((i + offset) == stopIndex)
							portalSegment = vertices[startIndex] - vertices[i];
						else
							portalSegment = vertices[i + offset] - vertices[i];

						originSegment = p_frustum->origin - vertices[i];

						Vector3d normalToAdd = portalSegment.CrossProd(originSegment);
						analysisCode += String::Format("testFrustum.AddPlane(Vector3d({0:F12}f, {1:F12}f, {2:F12}f));\r\n", normalToAdd.x, normalToAdd.y, normalToAdd.z);
					}

					analysisCode += String::Format("// all planes added (final count {0}):\r\n", p_frustum->count);
					analysisCode += "Frustum addedPlaneFrustum;\r\n";
					LinkedListEnumerator<FrustumPlaneNormalAndResult> addedPlaneEnumerator = p_frustum->addedPlanes.GetEnumerator();
					while (addedPlaneEnumerator.MoveNext())
					{
						analysisCode += "\r\n";
						int index = 0;
						LinkedListEnumerator<FrustumPlaneNormal> normalEnumerator = LinkedListEnumerator<FrustumPlaneNormal>(addedPlaneEnumerator.Current()->data.resultPlanes);
						while (normalEnumerator.MoveNext())
						{
							analysisCode += System::String::Format("// {0}: {1:F12}f, {2:F12}f, {3:F12}f));\r\n", index, normalEnumerator.Current()->data.normal.x, normalEnumerator.Current()->data.normal.y, normalEnumerator.Current()->data.normal.z);
							index++;
						}
						analysisCode += String::Format("addedPlaneFrustum.AddPlane(Vector3d({0:F12}f, {1:F12}f, {2:F12}f));\r\n", addedPlaneEnumerator.Current()->data.normal.x, addedPlaneEnumerator.Current()->data.normal.y, addedPlaneEnumerator.Current()->data.normal.z);
					}

					analysisCode += originalFrustum.WriteFrustumCreationCode();
					analysisCode += p_frustum->WriteFrustumCreationCode();
					throw gcnew Exception(String::Format("Original frustum does not contain result frustum! (result = {0:F8})", failedResult));
				}
#endif

				return true;
			}

			bool PointInFront(Vector3d &p_origin)
			{
				// watch for >= 0, allow == 0 to be friendly to finding mode that point is inside
				return ((p_origin - vertices[0]) * normal >= 0.0f);
			}

		private:
			void CalculateNormal()
			{
				normal = (vertices[2] - vertices[1]).CrossProd(vertices[1] - vertices[0]);
				if (normal.Normalize() == false)
					throw gcnew Exception("Normal has zero length");
			}

			void CalculateCenter()
			{
				// just take average of all the vertices.  This currently weights the center towards the great number of vertices in that direction
				center = Vector3d(0, 0, 0);
				for (int i = 0; i < vertexQty; i++)
				{
					center = center + vertices[i];
				}
				center = center.ScalarMult(1.0f / float(vertexQty));
			}
		};

		class PortalMirror
		{
		public:
			PortalPortal mirrorPortal; // portal used to determine mirror visibility (only checked if portal parse is told mirrors should be checked

			// geometry used to render the mirror (for stenciling, clearing the depth buffer within the stencil and rendering the mirror's surface after the mirror world is rendered)
			// note: surfaces use vertex references from the portal map
			ModelSurface *surfaces;
			int surfaceQty;

			GameColor color; // color for mirror, including alpha

			GraphicsNativeObjectContainer nativeObject;

			PortalMirror()
			{
				surfaces = nullptr;
				surfaceQty = 0;
			}

			~PortalMirror()
			{
				if (surfaces != nullptr)
				{
					delete[] surfaces;
					surfaceQty = 0;
				}

				if (nativeObject.nativeObjectRef != nullptr)
					throw gcnew Exception("PortalMirror nativeObjectRef is not null - the graphics API should destroy its resources before the app destroys the game data");
			}

			bool PointIsInFrontOfMirror(Vector3d &p_point)
			{
				return mirrorPortal.PointInFront(p_point);
			}

			float DistanceFromViewpoint(Vector3d &p_point)
			{
				return (p_point - mirrorPortal.center).MagnitudeSquared();
			}

			bool MirrorIsVisibleToFrustum(Frustum *p_frustum, Frustum *p_dstReflectedFrustum)
			{
				// if mirror is visible to the frustum, p_destReflectedFrustum will receive the reflected frustum
				if (PointIsInFrontOfMirror(p_frustum->origin) == false)
					return false;

				Frustum testFrustum;
				p_frustum->CopyTo(&testFrustum);
				if (mirrorPortal.AddToFrustum(&testFrustum) != false)
				{
					testFrustum.ReflectThroughPlane(mirrorPortal.vertices[0], mirrorPortal.normal, p_dstReflectedFrustum);
					return true;
				}
				else
					return false;
			}

			void Initialize(int p_surfaceQty, GameColor &p_color)
			{
				surfaces = new ModelSurface[p_surfaceQty];
				surfaceQty = p_surfaceQty;

				color = p_color;
			}

			// only render to main screen, no need to render a mirror to a shadow map (yet)
			// use colorOverride for altering the color and/or alpha for the mirror (such as rendering it as solid to prevent deeper rendering because max mirror depth was reached)
			// todo: texture override?
			void Render(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, ModelVertex *p_vertices, int p_vertexQty, GameColor *p_colorOverride = nullptr)
			{
				// always create native object with default color (single)
				if (nativeObject.nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(&nativeObject, &color, 1, p_vertices, p_vertexQty, surfaces, surfaceQty, true);

				// optionally override it (note: can't override color if multiple colors are used)
				p_shaderOptions.singleColorRef = p_colorOverride;
				p_graphics->RenderNativeObject(&nativeObject, p_shaderOptions);
			}

			void RenderToFlatMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, ModelVertex *p_vertices, int p_vertexQty)
			{
				GameColor *colorToUse = &color;

				if (nativeObject.nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(&nativeObject, colorToUse, 1, p_vertices, p_vertexQty, surfaces, surfaceQty, true);

				p_graphics->RenderNativeObjectToShadowMap(&nativeObject, p_shaderOptions);
			}

			void RenderToCubeMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, ModelVertex *p_vertices, int p_vertexQty)
			{
				GameColor *colorToUse = &color;

				if (nativeObject.nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(&nativeObject, colorToUse, 1, p_vertices, p_vertexQty, surfaces, surfaceQty, true);

				p_graphics->RenderNativeObjectToCubeShadowMap(&nativeObject, p_shaderOptions);
			}

			ModelSurface * GetSurface(int p_surfaceIndex)
			{
				return &(surfaces[p_surfaceIndex]);
			}
		};

		class PortalMirrorAndDistance
		{
		public:
			// these values identify the mirror to prevent duplicates in the resulting list
			int nodeIndex; // node that mirror is in (when rendering the mirror and parsing the portals, start in this node index regardless of where the viewpoint reflects to) 
			int mirrorIndex; // index of mirror within node
			int depth; // at what depth did this mirror occur?

			float distance; // z distance of center from viewpoint, just as an indicator of order to handle the mirrors to encourage depth culling for fragment shader

			Orient3d reflectedViewpoint; // viewpoint that will see back through the mirror for rendering its contents
			Frustum reflectedFrustum; // view frustum that will see back through the mirror for rendering its contents

			bool mergedFullFrustum; // is the frustum used an intersection between the mirror and a full frustum?  (covers multiple frustum splices striking the same mirror, preventing visual bugs)

			// PortalParseResult data - cast by PortalParseResult method calls
			void *parseResultRef;

			void Initialize()
			{
				reflectedFrustum.Initialize();
				mergedFullFrustum = false;

				parseResultRef = nullptr;
			}
		};

		class PortalParseResult
		{
		public:
			PortalMirrorAndDistance *mirror; // two way pointer to mirror whose parse this is the result for
			LinkedList<PortalNodeIndex> nodes;
			LinkedList<PortalMirrorAndDistance> mirrors;

			PortalParseResult()
			{
				Initialize();
			}

			void Initialize()
			{
				mirror = nullptr;
				nodes.Clear();
				mirrors.Clear();
			}
		};

		class PortalNodePlane {

		public:
			Vector3d position;
			Vector3d normal;

			bool PointIsInside(Vector3d &p_point)
			{
				if ((p_point - position) * normal >= 0.0f)
					return true;
				else
					return false;
			}

			void Set(Vector3d &p_position, Vector3d &p_normal)
			{
				position = p_position;
				normal = p_normal;
			}
		};

		class PortalNode {
		public:
			int index; // array index within master array

			ModelSurface *surfaces; // set of concave surfaces that make up node
			int surfaceQty;

			// portals visible to this node (front or backside faces into the node as appropriate)
			int *portalIndices;
			int portalIndexQty;

			bool committed;

			GraphicsNativeObjectContainer nativeObject;

			PortalNodePlane *nodePlanes; // planes meant to contain node
			int nodePlaneQty;

			BoundingVolume3d boundingVolume;
			Vector3d center;

			ColliderSet colliderSet; // in case colliders are to be used at node level (good for using via partitioning, etc.) - could be moved to an implementation array, too.

			//s tationary mirrors, using portal map vertices for the rendering geometry (but their own surfaces and color, and portal for visibility testing)
			PortalMirror *mirrors;
			int mirrorQty;

			PortalNodePlane * GetNodePlane(int p_index)
			{
				if (p_index < nodePlaneQty)
					return &(nodePlanes[p_index]);
				else
					throw gcnew Exception("Index out of range");
			}

			// assumes nodes (renderable surfaces and mirrors) are fully concave (todo: upgrade to be a simple containment structure with few planes)
			bool PointIsInside(Vector3d &p_point, ModelVertex *p_vertices, PortalPortal *p_portals)
			{
				//	// check bounding box - great way to exclude fast
				if (boundingVolume.PointIsInside(p_point) == false)
					return false;

				for (int n = 0; n < nodePlaneQty; n++)
				{
					if (nodePlanes[n].PointIsInside(p_point) == false)
						return false;
				}

				return true;

				// this code is obsolete.
				//	// check renderable surfaces
				//	for (int s = 0; s < surfaceQty; s++)
				//	{
				//		if (surfaces[s].GetVertexQty() == 0)
				//			continue;

				//		// allow zero, because a point exactly between two nodes has to pick one - might as well be the first
				//		if ((p_point - p_vertices[surfaces[s].GetSurfaceVertex(0)->vertexIndex].vertex) * surfaces[s].GetNormal() < 0.0f)
				//			return false;
				//	}
				//	// check mirrors
				//	for (int m = 0; m < mirrorQty; m++)
				//	{
				//		for (int s = 0; s < mirrors[m].surfaceQty; s++)
				//		{
				//			if (mirrors[m].surfaces[s].GetVertexQty() == 0)
				//				continue;

				//			// allow zero, because a point exactly between two nodes has to pick one - might as well be the first
				//			if ((p_point - p_vertices[mirrors[m].surfaces[s].GetSurfaceVertex(0)->vertexIndex].vertex) * mirrors[m].surfaces[s].GetNormal() < 0.0f)
				//				return false;
				//		}
				//	}

				//	for (int p = 0; p < portalIndexQty; p++)
				//	{
				//		if (p_portals[portalIndices[p]].PointInFront(p_point) == true)
				//		{
				//			if (p_portals[portalIndices[p]].frontNodeIndex != index)
				//				return false;
				//		}
				//		else
				//		{
				//			if (p_portals[portalIndices[p]].backNodeIndex != index)
				//				return false;
				//		}
				//	}
				//
				// return true;
			}

			void Initialize(int p_surfaceQty, int p_portalIndexQty, int p_nodePlaneQty, int p_mirrorQty = 0)
			{
				surfaces = new ModelSurface[p_surfaceQty];
				surfaceQty = p_surfaceQty;

				portalIndices = new int[p_portalIndexQty];
				portalIndexQty = p_portalIndexQty;

				nodePlanes = new PortalNodePlane[p_nodePlaneQty];
				nodePlaneQty = p_nodePlaneQty;

				if (p_mirrorQty != 0)
				{
					mirrors = new PortalMirror[p_mirrorQty];
					mirrorQty = p_mirrorQty;
				}
			}

			ModelSurface * GetSurface(int p_surfaceIndex)
			{
				return &surfaces[p_surfaceIndex];
			}

			void Commit(ModelVertex *p_vertices)
			{
				for (int s = 0; s < surfaceQty; s++)
				{
					surfaces[s].CalculateNormals(p_vertices);

					// determine bounding volume for node (min max inclusive)
					for (int v = 0; v < surfaces[s].GetVertexQty(); v++)
					{
						boundingVolume.ProcessPoint(p_vertices[surfaces[s].GetSurfaceVertex(v)->vertexIndex].vertex);
					}
				}

				for (int m = 0; m < mirrorQty; m++)
				{
					for (int s = 0; s < mirrors[m].surfaceQty; s++)
					{
						mirrors[m].surfaces[s].CalculateNormals(p_vertices);

						// determine bounding volume for node (min max inclusive)
						for (int v = 0; v < mirrors[m].surfaces[s].GetVertexQty(); v++)
						{
							boundingVolume.ProcessPoint(p_vertices[mirrors[m].surfaces[s].GetSurfaceVertex(v)->vertexIndex].vertex);
						}
					}
					mirrors[m].mirrorPortal.Commit();
				}

				center = Vector3d(boundingVolume.minX + boundingVolume.maxX, boundingVolume.minY + boundingVolume.maxY, boundingVolume.minZ + boundingVolume.maxZ).ScalarMult(0.5f);

				committed = true;
			}

			void Render(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, ModelVertex *p_vertices, int p_vertexQty)
			{
				GameColor color(255, 255, 255);

				if (nativeObject.nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(&nativeObject, &color, 1, p_vertices, p_vertexQty, surfaces, surfaceQty, true);

				p_graphics->RenderNativeObject(&nativeObject, p_shaderOptions);
			}

			void RenderToFlatMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, ModelVertex *p_vertices, int p_vertexQty)
			{
				GameColor color(255, 255, 255);

				if (nativeObject.nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(&nativeObject, &color, 1, p_vertices, p_vertexQty, surfaces, surfaceQty, true);

				p_graphics->RenderNativeObjectToShadowMap(&nativeObject, p_shaderOptions);
			}

			void RenderToCubeMap(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, ModelVertex *p_vertices, int p_vertexQty)
			{
				GameColor color(255, 255, 255);

				if (nativeObject.nativeObjectRef == nullptr)
					p_graphics->CreateNativeObject(&nativeObject, &color, 1, p_vertices, p_vertexQty, surfaces, surfaceQty, true);

				p_graphics->RenderNativeObjectToCubeShadowMap(&nativeObject, p_shaderOptions);
			}

			PortalNode()
			{
				surfaces = nullptr;
				surfaceQty = 0;

				portalIndices = nullptr;
				portalIndexQty = 0;

				nodePlanes = nullptr;
				nodePlaneQty = 0;

				mirrors = nullptr;
				mirrorQty = 0;

				committed = false;
			}

			~PortalNode()
			{
				Destroy();
			}

		private:
			void Destroy()
			{
				if (surfaces != nullptr)
				{
					delete[] surfaces;
					surfaces = nullptr;
					surfaceQty = 0;
				}
				if (portalIndices != nullptr)
				{
					delete[] portalIndices;
					portalIndices = nullptr;
					portalIndexQty = 0;
				}
				if (mirrors != nullptr)
				{
					delete[] mirrors;
					mirrors = nullptr;
					mirrorQty = 0;
				}
				if (nodePlanes != nullptr)
				{
					delete[] nodePlanes;
					nodePlanes = nullptr;
					nodePlaneQty = 0;
				}
			}
		};

		// Each node in this represents a single call to render a scene (the first node is the main world render with all mirror surfaces.  The later nodes are all
		//    a render of the mirror reflections for the various depths.  It is possible for a mirror to have more than one result at the same depth (its reflection could be part
		//    of several other parent mirrors whose reflections include it).  Each occurrence will involve a unique listing of that mirror within a parent result.
		class PortalParseResultList : public LinkedList<PortalParseResult>
		{
		public:

			// when any parse is performed, this is the list of unique nodes that will be rendered in entirety
			// speeds up prepping of shadow maps or any other analysis of all nodes being rendered
			LinkedList<PortalNodeIndex> uniqueNodes;
			int uniqueNodeQty;

			PortalParseResultList()
			{
				uniqueNodeQty = 0;
			}

			BoundingVolume3d GetFullBoundingVolume(PortalNode *p_nodes)
			{
				BoundingVolume3d result;

				LinkedListEnumerator<PortalParseResult> enumerator = GetEnumerator();
				while (enumerator.MoveNext())
				{
					LinkedListEnumerator<PortalNodeIndex> nodeEnumerator = LinkedListEnumerator<PortalNodeIndex>(enumerator.Current()->data.nodes);
					while (nodeEnumerator.MoveNext())
					{
						result.ProcessVolume(p_nodes[nodeEnumerator.Current()->data.index].boundingVolume);
					}
				}

				return result;
			}

			LinkedListEnumerator<PortalParseResult> GetEnumerator()
			{
				return LinkedListEnumerator<PortalParseResult>(*this);
			}

			LinkedListNode<PortalParseResult> * GetNewAddedNode(bool p_add = true)
			{
				LinkedListNode<PortalParseResult> *newNode = LinkedList<PortalParseResult>::GetNewNode();
				newNode->data.Initialize();
				if (p_add == true)
					AddNode(newNode);
				return newNode;
			}

			static PortalParseResult * GetResultNode(PortalMirrorAndDistance *p_mirror)
			{
				return (PortalParseResult *)(p_mirror->parseResultRef);
			}

			void Clear()
			{
				LinkedList<PortalParseResult>::Clear();
				uniqueNodes.Clear();
				uniqueNodeQty = 0;
			}

			String^ DebugOutput()
			{
				String ^result = "";

				// first node is always the primary result
				LinkedListNode<PortalParseResult> *firstNode = GetFirstNode();
				if (firstNode == nullptr)
				{
					result += "null";
					result += "\r\n";
				}
				else
				{
					result += "Parse Result: ";
					result += DebugNodeList(firstNode->data.nodes);
					result += "\r\n";

					if (firstNode->next != &footer)
					{
						// there are mirrors!
						LinkedListNode<PortalParseResult> *node = firstNode->next;
						while (node != &footer)
						{
							result += String::Format("Mirror (node {0}, index {1}, depth {2}):\r\n", node->data.mirror->nodeIndex, node->data.mirror->mirrorIndex, node->data.mirror->depth);
							result += DebugNodeList(node->data.nodes);
							result += "\r\n";

							node = node->next;
						}
					}

					result += "Unique nodes: ";
					result += DebugNodeList(uniqueNodes);
					result += "\r\n";
				}

				return result;
			}

			String^ DebugNodeList(LinkedList<PortalNodeIndex> &p_list)
			{
				String ^result = "";

				LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(p_list);
				while (enumerator.MoveNext())
				{
					result += String::Format("{0} ", enumerator.Current()->data.index);
				}

				return result;
			}
		};

		// an entire environment to be rendered
		class PortalMap
		{
		public:
			PortalNode *nodes;
			int nodeQty;

			ModelVertex *vertices;
			int vertexQty;

			// define portals with as few segments as possible to keep testing fast
			PortalPortal *portals;
			int portalQty;

			BoundingVolume3d boundingVolume;

		private:
			bool committed;
			bool *nodeInUniqueList; // used in parse to collect unique nodes, cleared when parse is done so all elements are always false
			// this element is removed because it is invalid for recursive parses, and it's unrealistic to create a thousands of elements array and initialize it for
			//   every parse - a new way will need to be found
			//bool *nodeInList; // used in parse to quickly determine if a node is in the current parse list being assembled

		public:
			PortalMap()
			{
				nodes = nullptr;
				nodeInUniqueList = nullptr;
				//nodeInList = nullptr;
				nodeQty = 0;

				vertices = nullptr;
				vertexQty = 0;

				portals = nullptr;
				portalQty = 0;

				committed = false;
			}

			~PortalMap()
			{
				Destroy();
			}

			void Initialize(int p_nodeQty, int p_vertexQty, int p_portalQty)
			{
				nodes = new PortalNode[p_nodeQty];
				nodeInUniqueList = new bool[p_nodeQty];
				//nodeInList = new bool[p_nodeQty];
				nodeQty = p_nodeQty;
				for (int i = 0; i < nodeQty; i++)
				{
					nodes[i].index = i;
					nodeInUniqueList[i] = false;
					//nodeInList[i] = false;
				}

				vertices = new ModelVertex[p_vertexQty];
				vertexQty = p_vertexQty;

				portals = new PortalPortal[p_portalQty];
				portalQty = p_portalQty;
			}

			// for incremental setup when all vertices aren't yet known, but their indices can be determined while nodes are being generated
			void Initialize(int p_nodeQty, int p_portalQty)
			{
				nodes = new PortalNode[p_nodeQty];
				nodeInUniqueList = new bool[p_nodeQty];
				//nodeInList = new bool[p_nodeQty];
				nodeQty = p_nodeQty;
				for (int i = 0; i < nodeQty; i++)
				{
					nodes[i].index = i;
					nodeInUniqueList[i] = false;
					//nodeInList[i] = false;
				}

				portals = new PortalPortal[p_portalQty];
				portalQty = p_portalQty;
			}

			void InitializeVertices(int p_vertexQty)
			{
				vertices = new ModelVertex[p_vertexQty];
				vertexQty = p_vertexQty;
			}

			void Destroy()
			{
				if (nodes != nullptr)
				{
					delete[] nodes;
					nodes = nullptr;
					nodeQty = 0;
				}
				if (nodeInUniqueList != nullptr)
				{
					delete[] nodeInUniqueList;
					nodeInUniqueList = nullptr;
				}
				//if (nodeInList != nullptr)
				//{
				//	delete[] nodeInList;
				//	nodeInList = nullptr;
				//}
				if (vertices != nullptr)
				{
					delete[] vertices;
					vertices = nullptr;
					vertexQty = 0;
				}
				if (portals != nullptr)
				{
					delete[] portals;
					portals = nullptr;
					portalQty = 0;
				}
			}

			void RenderNode(GraphicsBase *p_graphics, int p_nodeIndex, GraphicsShaderOptions %p_shaderOptions)
			{
				nodes[p_nodeIndex].Render(p_graphics, p_shaderOptions, vertices, vertexQty);
			}

			void RenderMirror(GraphicsBase *p_graphics, int p_nodeIndex, int p_mirrorIndex, GraphicsShaderOptions %p_shaderOptions, GameColor *p_colorOverride = nullptr)
			{
				nodes[p_nodeIndex].mirrors[p_mirrorIndex].Render(p_graphics, p_shaderOptions, vertices, vertexQty, p_colorOverride);
			}

			// shadow map rendering
			void RenderNodeToFlatMap(GraphicsBase *p_graphics, int p_nodeIndex, GraphicsShaderOptions %p_shaderOptions)
			{
				nodes[p_nodeIndex].RenderToFlatMap(p_graphics, p_shaderOptions, vertices, vertexQty);
			}

			void RenderNodeToCubeMap(GraphicsBase *p_graphics, int p_nodeIndex, GraphicsShaderOptions %p_shaderOptions)
			{
				nodes[p_nodeIndex].RenderToCubeMap(p_graphics, p_shaderOptions, vertices, vertexQty);
			}

			// mirrors have to cast shadows too!
			void RenderMirrorToFlatMap(GraphicsBase *p_graphics, int p_nodeIndex, int p_mirrorIndex, GraphicsShaderOptions %p_shaderOptions)
			{
				nodes[p_nodeIndex].mirrors[p_mirrorIndex].RenderToFlatMap(p_graphics, p_shaderOptions, vertices, vertexQty);
			}

			void RenderMirrorToCubeMap(GraphicsBase *p_graphics, int p_nodeIndex, int p_mirrorIndex, GraphicsShaderOptions %p_shaderOptions)
			{
				nodes[p_nodeIndex].mirrors[p_mirrorIndex].RenderToCubeMap(p_graphics, p_shaderOptions, vertices, vertexQty);
			}

			int NodeThatPointIsInside(Vector3d &p_point, int &p_nodesParsed)
			{
				for (int n = 0; n < nodeQty; n++)
				{
					p_nodesParsed = n + 1;
					if (nodes[n].PointIsInside(p_point, vertices, portals) == true)
						return n;
				}

				return -1;
			}

			int NodeThatPointIsInside(Vector3d &p_point, VolumePartition<LinkedList<PortalNodeIndex>> &p_partition, int &p_nodesParsed)
			{
				int xIndex, yIndex, zIndex;
				p_partition.GetPartitionSectionIndices(p_point.x, p_point.y, p_point.z, xIndex, yIndex, zIndex);

				LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(p_partition.GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data);
				p_nodesParsed = 0;
				while (enumerator.MoveNext())
				{
					p_nodesParsed++;

					if (nodes[enumerator.Current()->data.index].PointIsInside(p_point, vertices, portals) == true)
						return enumerator.Current()->data.index;
				}

				return -1;
			}

			void PopulateNodesToRender(PortalParseResultList &p_resultList, Frustum *p_frustum, int &p_nodesParsedForFirstNode, int p_startingNode = -1, bool p_trackUniqueNodes = false, bool p_detectMirrors = false, bool p_nodesRepeatAlongOnePath = false, int p_maxMirrorDepth = 0, int p_currentMirrorDepth = 0, LinkedListNode<PortalParseResult> *p_resultNode = nullptr)
			{
				// note: it is perfectly valid to send a null frustum - it will simply render in all directions, which is great for point light cube map preparation
				//   just make sure it has a proper positional origin
				// todo: support frustums for spotlights
				// todo: support linear frustums for directional lights

				// if p_mainPortalMirrorList is provided, then we are also checking for mirrors (mirrors are usually checked during rendering, but not while checking for node visibility for a light,
				//   unless the engine plans to involve mirrors with lighting)

				if (p_resultNode == nullptr) // if nullptr, is main call
				{
					p_resultList.Clear();
					p_resultNode = p_resultList.GetNewAddedNode();
				}

				// not to be confused with a null frustum (null means look for visibility in all directions - empty means nothing is valid)
				if (p_frustum->IsEmpty())
					return;

				int nodeIndex = p_startingNode;
				if (nodeIndex == -1)
					nodeIndex = NodeThatPointIsInside(p_frustum->origin, p_nodesParsedForFirstNode);
				if (nodeIndex < 0)
					// not in determinant area of map, leave empty
					return;

				// add node to map, always make it the first one to render
				p_resultNode->data.nodes.Add(PortalNodeIndex(nodeIndex));
				if (p_trackUniqueNodes == true)
				{
					if (nodeInUniqueList[nodeIndex] == false)
					{
						p_resultList.uniqueNodes.Add(PortalNodeIndex(nodeIndex));
						p_resultList.uniqueNodeQty++;

						nodeInUniqueList[nodeIndex] = true;
					}
				}

				// get order of nodes to check (checking closest portals first should maximize front to back rendering to help fragment shaders)
				LinkedList<PortalNodeIndexAndDistance> sortedNodes;
				int portalIndexQty = nodes[nodeIndex].portalIndexQty;
				bool sortNodes = false;
				for (int p = 0; p < portalIndexQty; p++)
				{
					int parsedNodeIndex = nodes[nodeIndex].portalIndices[p];
					PortalPortal *portal = &(portals[parsedNodeIndex]);

					// just in case, if origin cannot see the correct side of the portal from its position, don't bother with it (this shouldn't be a problem with concave nodes, but with convex nodes it's possible)
					bool portalValid = true;
					if (portal->PointInFront(p_frustum->origin) == true)
					{
						if (portal->frontNodeIndex != nodeIndex)
							portalValid = false;
					}
					else
					{
						if (portal->backNodeIndex != nodeIndex)
							portalValid = false;
					}
					if (portalValid == false)
						continue;

					// todo: shouldn't this really be the distance forward from the f vector of the viewpoint if the goal is to truly encourage depth culling?
					float distance = (p_frustum->origin - portal->center).MagnitudeSquared();
					bool inserted = false;
					if (sortNodes == true)
					{
						int index = 0;
						LinkedListEnumerator<PortalNodeIndexAndDistance> enumerator = LinkedListEnumerator<PortalNodeIndexAndDistance>(sortedNodes);
						while (enumerator.MoveNext())
						{
							if (enumerator.Current()->data.distance > distance)
							{
								inserted = true;
								if (index == 0)
									sortedNodes.Insert(PortalNodeIndexAndDistance(parsedNodeIndex, p, distance));
								else
									sortedNodes.Insert(PortalNodeIndexAndDistance(parsedNodeIndex, p, distance), enumerator.Current()->prev);
								break;
							}
							index++;
						}
					}
					if (inserted == false)
					{
						sortedNodes.Add(PortalNodeIndexAndDistance(parsedNodeIndex, p, distance));
					}
				}

				// now start the parsing, looking for nodes that are visible and continuing until none can be seen
				// if a node is parsed more than once along a path, add its nodes just before the one in the main list (this can occur multiple times in a list of indices being added, so 
				//   check for existence constantly.  If none are found, add all to the end of the list, otherwise add all up to that point to just before that node in the final list
				Frustum testFrustum;
				LinkedListEnumerator<PortalNodeIndexAndDistance> enumerator = LinkedListEnumerator<PortalNodeIndexAndDistance>(sortedNodes);
				int parseQty = 0;
				while (enumerator.MoveNext())
				{
					p_frustum->CopyTo(&testFrustum);
					int portalIndex = enumerator.Current()->data.portalIndex;
					PortalPortal *portal = &(portals[portalIndex]);

					// do NOT use this! has a bug that breaks frustum assumptions
					//					if (portal->WillEmptyFrustum(&testFrustum) == false)
					//					{
					//						portal->AddToFrustum(&testFrustum, true);
					if (portal->AddToFrustum(&testFrustum) != false)
					{
						// todo: watch out for origin being even with portal (test in 90 degree hallways with portal at 45 degree angle from concave corner to convex corner)
						int nextNodeIndex = portal->backNodeIndex;
						if (portal->PointInFront(testFrustum.origin) == false)
							nextNodeIndex = portal->frontNodeIndex;

						if (nextNodeIndex == nodeIndex)
							throw gcnew Exception(String::Format("Node Index {0} sees back into itself with portal {1} without being a mirror or gateway - invalid portal definition", nodeIndex, enumerator.Current()->data.nodePortalIndex));

						if (nextNodeIndex != -1)
						{
							// parse that way!
							// keep adding mirrors to the SAME list while we populate node list separately for insertion
							if (parseQty == 0 && p_nodesRepeatAlongOnePath == false)
							{
								// parse along one line - just add nodes to the main list
								// IMPORTANT NOTE: This is with the understanding that along one parse path, the same node cannot be encountered again!  If this is not the case, we must use the other call below!
								if (p_detectMirrors == true)
									PopulateNodesToRenderParse(p_resultNode->data.nodes, p_resultNode->data, &testFrustum, nextNodeIndex, portalIndex, p_trackUniqueNodes, p_nodesRepeatAlongOnePath, &(p_resultNode->data.mirrors), p_resultList, p_currentMirrorDepth, p_frustum);
								else
									PopulateNodesToRenderParse(p_resultNode->data.nodes, p_resultNode->data, &testFrustum, nextNodeIndex, portalIndex, p_trackUniqueNodes, p_nodesRepeatAlongOnePath, nullptr, p_resultList, p_currentMirrorDepth, p_frustum);
							}
							else
							{
								LinkedList<PortalNodeIndex> indexList;
								if (p_detectMirrors == true)
									PopulateNodesToRenderParse(indexList, p_resultNode->data, &testFrustum, nextNodeIndex, portalIndex, p_trackUniqueNodes, p_nodesRepeatAlongOnePath, &(p_resultNode->data.mirrors), p_resultList, p_currentMirrorDepth, p_frustum);
								else
									PopulateNodesToRenderParse(indexList, p_resultNode->data, &testFrustum, nextNodeIndex, portalIndex, p_trackUniqueNodes, p_nodesRepeatAlongOnePath, nullptr, p_resultList, p_currentMirrorDepth, p_frustum);

								AddNodesToNodeList(indexList, p_resultNode->data.nodes, p_resultList);
							}

							parseQty++;
						}
					}
				}

				// clear the node in list array for next call
				//				LinkedListNode<PortalNodeIndex> *node = resultNode->data.nodes.GetFirstNode();
				//				if (node != nullptr)
				//				{
				//					while (node != &(resultNode->data.nodes.footer))
				//					{
				//#ifdef _DEBUG
				//						if (nodeInList[node->data.index] == false)
				//							throw gcnew Exception("nodeInList was not set!");
				//#endif
				//						nodeInList[node->data.index] = false;
				//						node = node->next;
				//					}
				//				}

				//#ifdef _DEBUG
				//				// debug: check to make sure entire array is false - if not, exception
				//				for (int i = 0; i < nodeQty; i++)
				//				{
				//					if (nodeInList[i] == true)
				//						throw gcnew Exception("nodeInList array not cleared!");
				//				}
				//#endif

				// checking mirrors - only list mirrors also seen in the current node - do NOT collect the deep mirror list seen through the mirror!  The render routine requests that.
				if (p_detectMirrors == true)
				{
					CheckMirrors(nodeIndex, p_frustum, &(p_resultNode->data.mirrors), p_frustum, p_currentMirrorDepth);
				}

				// deep mirror parse!
				// note: the reflected frustums do NOT have any sort of adjustment that prevents artifacting
				if (p_detectMirrors == true && p_currentMirrorDepth < p_maxMirrorDepth)
				{
					// loop through mirrors list of result node, create a result list, 
					LinkedListEnumerator<PortalMirrorAndDistance> mirrorEnumerator = LinkedListEnumerator<PortalMirrorAndDistance>(p_resultNode->data.mirrors);
					while (mirrorEnumerator.MoveNext())
					{
						// when new parse list node is created, set up two way pointer to mirror used to call
						LinkedListNode<PortalParseResult> *newResultNode = p_resultList.GetNewAddedNode();
						// todo: possible bug here - mirrorEnumerator points at null node?  how?  is a recursive parse haveing a problem?
						mirrorEnumerator.Current()->data.parseResultRef = (void *)&(newResultNode->data);
						newResultNode->data.mirror = &(mirrorEnumerator.Current()->data);

						// call this routine again 
						// recursive call!
						int x = 0; // don't contribute to number of nodes parsed to determine first node
						PopulateNodesToRender(p_resultList, &(mirrorEnumerator.Current()->data.reflectedFrustum), x, mirrorEnumerator.Current()->data.nodeIndex, true, true, p_nodesRepeatAlongOnePath, p_maxMirrorDepth, p_currentMirrorDepth + 1, newResultNode);
					}
				}

				// clear the unique node in list array for next call
				if (p_trackUniqueNodes == true && p_currentMirrorDepth == 0)
				{
					LinkedListNode<PortalNodeIndex> *uniqueNode = p_resultList.uniqueNodes.GetFirstNode();
					if (uniqueNode != nullptr)
					{
						while (uniqueNode != &(p_resultList.uniqueNodes.footer))
						{
#ifdef _DEBUG
							if (nodeInUniqueList[uniqueNode->data.index] == false)
								throw gcnew Exception("nodeInUniqueList was not set!");

							//Trace::WriteLine(String::Format("Resetting unique ID {0}", uniqueNode->data.index));
#endif
							nodeInUniqueList[uniqueNode->data.index] = false;
							uniqueNode = uniqueNode->next;
						}
					}
				}

#ifdef _DEBUG
				// debug: check to make sure entire array is false - if not, exception
				if (p_currentMirrorDepth == 0 && p_trackUniqueNodes == true)
				{
					bool trace = false;
					if (trace == true)
					{
						Trace::WriteLine(p_resultList.DebugOutput());
					}

					for (int i = 0; i < nodeQty; i++)
					{
						if (nodeInUniqueList[i] == true)
							throw gcnew Exception("nodeInUniqueList array not cleared!");
					}
				}
#endif

				// validation
				if (p_currentMirrorDepth == 0)
				{
					if (p_resultList.GetFirstNode()->data.mirror != nullptr)
						throw gcnew Exception("First node must be the main world render, not a mirror!");
#ifdef _DEBUG
					// verify no nodes are repeated in final lists using array, and clear it again for next time
					LinkedListEnumerator<PortalParseResult> indexList1 = LinkedListEnumerator<PortalParseResult>(p_resultList);
					while (indexList1.MoveNext())
					{
						PortalParseResult *parseResult = &(indexList1.Current()->data);
						LinkedListEnumerator<PortalNodeIndex> indexList2 = LinkedListEnumerator<PortalNodeIndex>(parseResult->nodes);
						while (indexList2.MoveNext())
						{
							int index = indexList2.Current()->data.index;
							if (nodeInUniqueList[index] == true)
								throw gcnew Exception("Debug Error: Node IDs repeat in final list!");
							else
								nodeInUniqueList[index] = true;
						}
						indexList2 = LinkedListEnumerator<PortalNodeIndex>(parseResult->nodes);
						while (indexList2.MoveNext())
						{
							nodeInUniqueList[indexList2.Current()->data.index] = false;
						}
					}
#endif _DEBUG
				}
			}

		private:
			void CheckMirrors(int p_nodeIndex, Frustum *p_frustum, LinkedList<PortalMirrorAndDistance> *p_mirrorResultList, Frustum *p_rootFrustum, int p_mirrorDepth)
			{
				// we only need the p_rootFrustum here for when multiple frustum splices encounter the same mirror.  In that case, get the intersection between the mirror and the original frustum
				//    for simplicity.  This only happens when two portals splice a frustum on their way to the same mirror.  Either we need to merge the frustums (which can be problematic
				//    since they might not even touch) or we just take the intersection of the mirror with the original frustum that started the root parse, which is guaranteed to be enough
				//    and much simpler.

				// now look at mirrors in the node
				int mirrorQty = nodes[p_nodeIndex].mirrorQty;
				for (int m = 0; m < mirrorQty; m++)
				{
					Frustum reflectedFrustum;
					PortalMirror *mirror = &(nodes[p_nodeIndex].mirrors[m]);
					if (mirror->MirrorIsVisibleToFrustum(p_frustum, &reflectedFrustum) == true)
					{
						float distance = mirror->DistanceFromViewpoint(p_frustum->origin);

						// add mirror to list, sorted
						PortalMirrorAndDistance *foundNode = nullptr;
						bool insert = false;
						LinkedListEnumerator<PortalMirrorAndDistance> mirrorEnumerator = LinkedListEnumerator<PortalMirrorAndDistance>(*p_mirrorResultList);
						LinkedListNode<PortalMirrorAndDistance> *insertAfter = nullptr;

						while (mirrorEnumerator.MoveNext())
						{
							LinkedListNode<PortalMirrorAndDistance> *parseMirrorNode = mirrorEnumerator.Current();

							// don't allow duplicates in final list (distance will be == so the if below will not fire first)
							if (parseMirrorNode->data.nodeIndex == p_nodeIndex && parseMirrorNode->data.mirrorIndex == m)
							{
								foundNode = &(parseMirrorNode->data);
								break;
							}
							else
							{
								// and sort them by distance
								if (distance < parseMirrorNode->data.distance)
								{
									// insert it here
									if (parseMirrorNode != p_mirrorResultList->GetFirstNode())
										insertAfter = parseMirrorNode->prev;

									insert = true;
									break;
								}
							}
						}
						if (foundNode == nullptr)
						{
							LinkedListNode<PortalMirrorAndDistance> *newNode = p_mirrorResultList->GetNewNode();
							newNode->data.Initialize();
							newNode->data.distance = distance;
							newNode->data.nodeIndex = p_nodeIndex;
							newNode->data.mirrorIndex = m;
							newNode->data.depth = p_mirrorDepth;
							reflectedFrustum.CopyTo(&(newNode->data.reflectedFrustum));

							if (insert == true)
								p_mirrorResultList->InsertNode(newNode, insertAfter);
							else
								p_mirrorResultList->AddNode(newNode);
						}
						else // found node
						{
							// this mirror has been hit by multiple frustum splices - if it hasn't been handled already, just intersect the mirror with the full frustum 
							//   used to start the root parse to make sure it fully renders its reflection.  p_rootFrustum entirely contains p_frustum so this should work.
							if (foundNode->mergedFullFrustum == false)
							{
#ifdef _DEBUG
								bool testContainment = false;
								if (testContainment == true)
								{
									// there is an assumption that p_rootFrustum fully contains p_frustum
									// so if p_rootFrustum's planes are added to p_frustum, it shouldn't change.
									// verify.
									Frustum testFrustum;
									p_frustum->CopyTo(&testFrustum);
									LinkedListEnumerator<FrustumPlane> planeEnumerator = p_rootFrustum->GetPlaneEnumerator();
									while (planeEnumerator.MoveNext())
									{
										testFrustum.AddPlane(planeEnumerator.Current()->data.normalUnit);
									}
									if (p_frustum->Equals(&testFrustum) == false)
									{
										throw gcnew Exception("p_rootFrustum does not contain p_frustum! Assumption failed!");
									}
								}
#endif _DEBUG
								foundNode->reflectedFrustum.Initialize();
								if (nodes[foundNode->nodeIndex].mirrors[foundNode->mirrorIndex].MirrorIsVisibleToFrustum(p_rootFrustum, &(foundNode->reflectedFrustum)) == false)
								{
#ifdef _DEBUG
									// make code to generate each frustum and render them in another test to examine.
									String ^analysisCode = "";
									analysisCode += p_frustum->WriteFrustumCreationCode();
									analysisCode += p_rootFrustum->WriteFrustumCreationCode();
#endif _DEBUG
									throw gcnew Exception("Tried to acquire full root frustum intersection with mirror in order to handle visibility from multiple frustum splices and got null!");
								}
								foundNode->mergedFullFrustum = true;
							}
						}
					} // mirror is visible to frustum
				} // each mirror
			}

			void PopulateNodesToRenderParse(LinkedList<PortalNodeIndex> &p_nodesList, PortalParseResult &p_result, Frustum *p_frustum, int p_rootNodeIndex, int p_portalIndexUsed, bool p_trackUniqueNodes, bool p_nodesRepeatAlongOnePath, LinkedList<PortalMirrorAndDistance> *p_mirrorList, PortalParseResultList &p_resultList, int p_currentMirrorDepth, Frustum *p_rootFrustum = nullptr)
			{
				// add node to map, always make it the first one to render
				p_nodesList.Add(PortalNodeIndex(p_rootNodeIndex));

				// indices < -1 are special and don't have portals that will come back into the map (like outside terrain, etc.)
				// todo: special values will be handled later
				if (p_rootNodeIndex < 0)
					return;

				// add to unique node list
				if (p_trackUniqueNodes == true)
				{
					if (nodeInUniqueList[p_rootNodeIndex] == false)
					{
						p_resultList.uniqueNodes.Add(PortalNodeIndex(p_rootNodeIndex));
						p_resultList.uniqueNodeQty++;

						nodeInUniqueList[p_rootNodeIndex] = true;
					}
				}

				// get order of nodes to check (checking closest portals first should maximize front to back rendering to help fragment shaders)
				LinkedList<PortalNodeIndexAndDistance> sortedNodes;
				int portalIndexQty = nodes[p_rootNodeIndex].portalIndexQty;
				for (int p = 0; p < portalIndexQty; p++)
				{
					// do NOT reuse the portal we entered with!!  Infinite loop!
					if (nodes[p_rootNodeIndex].portalIndices[p] == p_portalIndexUsed)
						continue;

					int parsedNodeIndex = nodes[p_rootNodeIndex].portalIndices[p];
					PortalPortal *portal = &(portals[parsedNodeIndex]);

					// just in case, if origin cannot see the correct side of the portal from its position, don't bother with it (this shouldn't be a problem with concave nodes, but with convex nodes it's possible)
					bool portalValid = true;
					if (portal->PointInFront(p_frustum->origin) == true)
					{
						if (portal->frontNodeIndex != p_rootNodeIndex)
							portalValid = false;
					}
					else
					{
						if (portal->backNodeIndex != p_rootNodeIndex)
							portalValid = false;
					}
					if (portalValid == false)
						continue;

					// todo: shouldn't this really be the distance forward from the f vector of the viewpoint if the goal is to truly encourage depth culling?
					float distance = (p_frustum->origin - portal->center).MagnitudeSquared();
					bool inserted = false;
					bool sortNodes = false;
					if (sortNodes == true)
					{
						int index = 0;
						LinkedListEnumerator<PortalNodeIndexAndDistance> enumerator = LinkedListEnumerator<PortalNodeIndexAndDistance>(sortedNodes);
						while (enumerator.MoveNext())
						{
							if (enumerator.Current()->data.distance > distance)
							{
								inserted = true;
								if (index == 0)
									sortedNodes.Insert(PortalNodeIndexAndDistance(parsedNodeIndex, p, distance));
								else
									sortedNodes.Insert(PortalNodeIndexAndDistance(parsedNodeIndex, p, distance), enumerator.Current()->prev);
								break;
							}
							index++;
						}
					}
					if (inserted == false)
					{
						sortedNodes.Add(PortalNodeIndexAndDistance(parsedNodeIndex, p, distance));
					}
				}

				// now start the parsing, looking for nodes that are visible and continuing until none can be seen
				// if a node is parsed more than once along a path, add its nodes just before the one in the main list (this can occur multiple times in a list of indices being added, so 
				//   check for existence constantly.  If none are found, add all to the end of the list, otherwise add all up to that point to just before that node in the final list
				Frustum testFrustum;
				LinkedListEnumerator<PortalNodeIndexAndDistance> enumerator = LinkedListEnumerator<PortalNodeIndexAndDistance>(sortedNodes);
				int parseQty = 0;
				while (enumerator.MoveNext())
				{
					p_frustum->CopyTo(&testFrustum);
					int portalIndex = enumerator.Current()->data.portalIndex;
					PortalPortal *portal = &(portals[portalIndex]);

					// do NOT use this! has a bug that breaks frustum assumptions
//					if (portal->WillEmptyFrustum(&testFrustum) == false)
//					{
//						portal->AddToFrustum(&testFrustum, true);
					if (portal->AddToFrustum(&testFrustum) != false)
					{
						// todo: watch out for origin being even with portal (test in 90 degree hallways with portal at 45 degree angle from concave corner to convex corner)
						int nextNodeIndex = portal->backNodeIndex;
						if (portal->PointInFront(testFrustum.origin) == false)
							nextNodeIndex = portal->frontNodeIndex;

						if (nextNodeIndex == p_rootNodeIndex)
							// todo: fix portalIndex to be a portalIndices index for exception (store the index on the node and keep it)
							throw gcnew Exception(String::Format("Node Index {0} sees back into itself with portal {1} without being a mirror or gateway - invalid portal definition", p_rootNodeIndex, enumerator.Current()->data.nodePortalIndex));

						if (nextNodeIndex != -1)
						{
							// parse that way!
							// keep adding to same mirror list while we populate the nodes list separately
							if (parseQty == 0 && p_nodesRepeatAlongOnePath == false)
							{
								PopulateNodesToRenderParse(p_nodesList, p_result, &testFrustum, nextNodeIndex, portalIndex, p_trackUniqueNodes, p_nodesRepeatAlongOnePath, p_mirrorList, p_resultList, p_currentMirrorDepth, p_rootFrustum);
							}
							else
							{
								LinkedList<PortalNodeIndex> indexList;
								PopulateNodesToRenderParse(indexList, p_result, &testFrustum, nextNodeIndex, portalIndex, p_trackUniqueNodes, p_nodesRepeatAlongOnePath, p_mirrorList, p_resultList, p_currentMirrorDepth, p_rootFrustum);

								AddNodesToNodeList(indexList, p_nodesList, p_resultList);
							}

							parseQty++;
						}
					}
				}

				// checking mirrors - only list mirrors also seen in the current node - do NOT collect the deep mirror list seen through the mirror!  The render routine requests that.
				if (p_mirrorList != nullptr)
				{
					CheckMirrors(p_rootNodeIndex, p_frustum, p_mirrorList, p_rootFrustum, p_currentMirrorDepth);
				}
			}

//			void TallyNodesAndAddToUniqueList(LinkedListNode<PortalNodeIndex> *p_startNode, LinkedListNode<PortalNodeIndex> *p_stopNode, PortalParseResultList &p_resultList)
//			{
//				LinkedListNode<PortalNodeIndex> *node = p_startNode;
//				bool done = false; // no real use for this, break is used
//				while (done == false)
//				{
//#ifdef _DEBUG
//					if (nodeInList[node->data.index] == true)
//						throw gcnew Exception("nodeInList already set!");
//#endif
//					nodeInList[node->data.index] = true;
//
//					if (nodeInUniqueList[node->data.index] == false)
//					{
//						p_resultList.uniqueNodes.Add(node->data);
//						nodeInUniqueList[node->data.index] = true;
//					}
//
//					if (node == p_stopNode)
//						break;
//
//					node = node->next;
//				}
//			}

			void AddNodesToNodeList(LinkedList<PortalNodeIndex> &p_srcNodeList, LinkedList<PortalNodeIndex> &p_dstNodeList, PortalParseResultList &p_resultList)
			{
				// add nodes to list - watch for duplicates and add remaining nodes just before that node
				p_srcNodeList.DebugValidate();
				p_dstNodeList.DebugValidate();

				LinkedListNode<PortalNodeIndex> *srcListNode = p_srcNodeList.GetFirstNode();
				while (srcListNode != &(p_srcNodeList.footer))
				{
					LinkedListNode<PortalNodeIndex> *nextNode = srcListNode->next;

					// see if index is in destination list
					LinkedListNode<PortalNodeIndex> *insertNode = NodeExistsInNodeList(srcListNode->data.index, p_dstNodeList);
					if (insertNode != nullptr)
					{
						if (insertNode == p_dstNodeList.GetFirstNode())
							throw gcnew Exception("Insert node is first node - this should never happen and happens because a node is not concave, which is a current requirement");

						// insert first node of srcNodeList up to srcListNode and insert just before insertNode
						// if search index has no nodes behind it, do nothing, otherwise add everything behind it just before insertNode
						if (p_srcNodeList.GetFirstNode() != srcListNode)
						{
							// we have nodes to insert - insert everything behind srcListNode in front of insertNode

							p_srcNodeList.DebugValidate();
							p_dstNodeList.DebugValidate();

							//TallyNodesAndAddToUniqueList(p_srcNodeList.GetFirstNode(), srcListNode->prev, p_resultList);

							p_srcNodeList.GetFirstNode()->prev = insertNode->prev;
							insertNode->prev->next = p_srcNodeList.GetFirstNode();

							insertNode->prev = srcListNode->prev;
							srcListNode->prev->next = insertNode;

							// clear added nodes from source list (search node still hanging, handled next)
							// (srcListNode is now detached)
							p_srcNodeList.header.next = nextNode;
							nextNode->prev = &(p_srcNodeList.header);

							p_srcNodeList.DebugValidate();
							p_dstNodeList.DebugValidate();
						}
						else
						{
							// detach srcListNode before moving to the deleted list so that srcList is still good
							p_srcNodeList.DetachNode(srcListNode);
						}

						// move the search index node to the deleted list
						LinkedList<PortalNodeIndex>::DeletedList.DebugValidate();

						srcListNode->prev = &(LinkedList<PortalNodeIndex>::DeletedList.header);
						srcListNode->next = LinkedList<PortalNodeIndex>::DeletedList.header.next;
						LinkedList<PortalNodeIndex>::DeletedList.header.next->prev = srcListNode;
						LinkedList<PortalNodeIndex>::DeletedList.header.next = srcListNode;

						LinkedList<PortalNodeIndex>::DeletedList.DebugValidate();
					}

					srcListNode = nextNode;
				}

				if (p_srcNodeList.IsEmpty() == false)
				{
					p_srcNodeList.DebugValidate();
					p_dstNodeList.DebugValidate();

					//TallyNodesAndAddToUniqueList(p_srcNodeList.GetFirstNode(), p_srcNodeList.GetLastNode(), p_resultList);

					// insert them all at the end of dstList
					p_dstNodeList.GetLastNode()->next = p_srcNodeList.GetFirstNode();
					p_srcNodeList.GetFirstNode()->prev = p_dstNodeList.GetLastNode();
					p_dstNodeList.footer.prev = p_srcNodeList.GetLastNode();
					p_srcNodeList.GetLastNode()->next = &(p_dstNodeList.footer);
					p_srcNodeList.header.next = &(p_srcNodeList.footer);
					p_srcNodeList.footer.prev = &(p_srcNodeList.header);

					p_srcNodeList.DebugValidate();
					p_dstNodeList.DebugValidate();
				}
			}

			LinkedListNode<PortalNodeIndex> * NodeExistsInNodeList(int p_index, LinkedList<PortalNodeIndex> &p_nodeList)
			{
				// check boolean array for quick check
				//if (nodeInList[p_index] == false)
				//	return nullptr;

				LinkedListNode<PortalNodeIndex> *node = p_nodeList.GetFirstNode();
				while (node != &(p_nodeList.footer))
				{
					// see if index is in list, if so, return the node
					if (p_index == node->data.index)
						return node;

					node = node->next;
				}

				// exception if not found even though boolean tally says it is there
				//throw gcnew Exception("Node not in list - array says otherwise!");

				return nullptr;
			}

		public:
			void MakeColliderSet(ColliderSet &p_set)
			{
				p_set.InitializePoints(vertexQty);
				int segmentQty = 0;
				int surfaceQty = 0;
				for (int n = 0; n < nodeQty; n++)
				{
					surfaceQty += nodes[n].surfaceQty;
					for (int s = 0; s < nodes[n].surfaceQty; s++)
						// assumes no lines or point surfaces
						segmentQty += nodes[n].GetSurface(s)->GetVertexQty();
				}
				p_set.InitializeSurfaces(surfaceQty);
				p_set.InitializeSegments(segmentQty);

				for (int p = 0; p < vertexQty; p++)
					p_set.points[p].position = vertices[p].vertex;
				int surfaceIndex = 0;
				int segmentIndex = 0;
				for (int n = 0; n < nodeQty; n++)
				{
					for (int s = 0; s < nodes[n].surfaceQty; s++)
					{
						p_set.surfaces[surfaceIndex].SetPrimaryData(vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(0)->vertexIndex].vertex, vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(1)->vertexIndex].vertex, nodes[n].GetSurface(s)->GetNormal());
						p_set.surfaces[surfaceIndex].Initialize(nodes[n].GetSurface(s)->GetVertexQty());

						for (int p = 0; p < nodes[n].surfaces[s].GetVertexQty(); p++)
						{
							p_set.surfaces[surfaceIndex].SetSurfacePoint(p, vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex);
							// debug
							Vector2d point = p_set.surfaces[surfaceIndex].surfacePoints[p];

							int nextP = p + 1;
							if (nextP == nodes[n].surfaces[s].GetVertexQty())
								nextP = 0;
							p_set.segments[segmentIndex].SetData(vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex, vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(nextP)->vertexIndex].vertex);
							segmentIndex++;
						}

						surfaceIndex++;
					}
				}

				if (surfaceIndex != surfaceQty)
					throw gcnew Exception(String::Format("Surface Index != surface Qty: {0}, {1}", surfaceIndex, surfaceQty));
				if (segmentIndex != segmentQty)
					throw gcnew Exception(String::Format("Segment Index != segment Qty: {0}, {1}", segmentIndex, segmentQty));
			}

			void MakeNodeColliderSets()
			{
				// this routine is for making collider sets that will be accessed at the node level
				// it turns all rendering geometry into collider sets, which may not always be so fast if a simple shape is made up of a lot of triangles.
				LinkedList<PortalNodeIndex> vertexIndices;
				for (int n = 0; n < nodeQty; n++)
				{
					int segmentQty = 0;
					int segmentIndex = 0;

					// count unique vertices
					// surfaces
					for (int s = 0; s < nodes[n].surfaceQty; s++)
					{
						// count segments while we're here
						segmentQty += nodes[n].surfaces[s].GetVertexQty();
						for (int v = 0; v < nodes[n].surfaces[s].GetVertexQty(); v++)
						{
							bool found = false;
							LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(vertexIndices);
							while (enumerator.MoveNext())
							{
								if (enumerator.Current()->data.index == nodes[n].surfaces[s].GetSurfaceVertex(v)->vertexIndex)
								{
									found = true;
									break;
								}
							}
							if (found == false)
								vertexIndices.Add(PortalNodeIndex(nodes[n].surfaces[s].GetSurfaceVertex(v)->vertexIndex));
						}
					} // surfaces
					// mirrors
					for (int m = 0; m < nodes[n].mirrorQty; m++)
					{
						for (int s = 0; s < nodes[n].mirrors[m].surfaceQty; s++)
						{
							// count segments while we're here
							segmentQty += nodes[n].mirrors[m].surfaces[s].GetVertexQty();
							for (int v = 0; v < nodes[n].mirrors[m].surfaces[s].GetVertexQty(); v++)
							{
								bool found = false;
								LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(vertexIndices);
								while (enumerator.MoveNext())
								{
									if (enumerator.Current()->data.index == nodes[n].mirrors[m].surfaces[s].GetSurfaceVertex(v)->vertexIndex)
									{
										found = true;
										break;
									}
								}
								if (found == false)
									vertexIndices.Add(PortalNodeIndex(nodes[n].mirrors[m].surfaces[s].GetSurfaceVertex(v)->vertexIndex));
							}
						}
					} // mirrors
					// set up points
					nodes[n].colliderSet.InitializePoints(vertexIndices.Count());
					LinkedListEnumerator<PortalNodeIndex> enumerator = LinkedListEnumerator<PortalNodeIndex>(vertexIndices);
					int p = 0;
					while (enumerator.MoveNext())
					{
						nodes[n].colliderSet.points[p].position = vertices[enumerator.Current()->data.index].vertex;
						p++;
					}

					// segments and surfaces
					nodes[n].colliderSet.InitializeSegments(segmentQty);
					nodes[n].colliderSet.InitializeSurfaces(nodes[n].surfaceQty);
					// surfaces
					for (int s = 0; s < nodes[n].surfaceQty; s++)
					{
						nodes[n].colliderSet.surfaces[s].SetPrimaryData(vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(0)->vertexIndex].vertex, vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(1)->vertexIndex].vertex, nodes[n].GetSurface(s)->GetNormal());
						nodes[n].colliderSet.surfaces[s].Initialize(nodes[n].GetSurface(s)->GetVertexQty());

						for (int p = 0; p < nodes[n].surfaces[s].GetVertexQty(); p++)
						{
							nodes[n].colliderSet.surfaces[s].SetSurfacePoint(p, vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex);
							// debug
							Vector2d point = nodes[n].colliderSet.surfaces[s].surfacePoints[p];

							int nextP = p + 1;
							if (nextP == nodes[n].surfaces[s].GetVertexQty())
								nextP = 0;
							nodes[n].colliderSet.segments[segmentIndex].SetData(vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex, vertices[nodes[n].GetSurface(s)->GetSurfaceVertex(nextP)->vertexIndex].vertex);
							segmentIndex++;
						}
					}
					// mirrors
					for (int m = 0; m < nodes[n].mirrorQty; m++)
					{
						for (int s = 0; s < nodes[n].mirrors[m].surfaceQty; s++)
						{
							nodes[n].colliderSet.surfaces[s].SetPrimaryData(vertices[nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(0)->vertexIndex].vertex, vertices[nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(1)->vertexIndex].vertex, nodes[n].mirrors[m].GetSurface(s)->GetNormal());
							nodes[n].colliderSet.surfaces[s].Initialize(nodes[n].mirrors[m].GetSurface(s)->GetVertexQty());

							for (int p = 0; p < nodes[n].surfaces[s].GetVertexQty(); p++)
							{
								nodes[n].colliderSet.surfaces[s].SetSurfacePoint(p, vertices[nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex);
								// debug
								Vector2d point = nodes[n].colliderSet.surfaces[s].surfacePoints[p];

								int nextP = p + 1;
								if (nextP == nodes[n].mirrors[m].surfaces[s].GetVertexQty())
									nextP = 0;
								nodes[n].colliderSet.segments[segmentIndex].SetData(vertices[nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(p)->vertexIndex].vertex, vertices[nodes[n].mirrors[m].GetSurface(s)->GetSurfaceVertex(nextP)->vertexIndex].vertex);
								segmentIndex++;
							}
						}
					}

					if (segmentIndex != segmentQty)
						throw gcnew Exception(String::Format("Segment Index != segment Qty: {0}, {1}", segmentIndex, segmentQty));

					vertexIndices.Clear();
				}

			}

			void Commit()
			{
				for (int n = 0; n < nodeQty; n++)
				{
					nodes[n].Commit(vertices);

					boundingVolume.ProcessPoint(Vector3d(nodes[n].boundingVolume.minX, nodes[n].boundingVolume.minY, nodes[n].boundingVolume.minZ));
					boundingVolume.ProcessPoint(Vector3d(nodes[n].boundingVolume.maxX, nodes[n].boundingVolume.maxY, nodes[n].boundingVolume.maxZ));
				}

				for (int p = 0; p < portalQty; p++)
				{
					portals[p].Commit();
				}

				committed = true;
			}

			void EnlargePortals(float p_worldSize)
			{
				if (committed == false)
					throw gcnew Exception("Portal map not committed!");

				for (int n = 0; n < nodeQty; n++)
				{
					for (int m = 0; m < nodes[n].mirrorQty; m++)
					{
						nodes[n].mirrors[m].mirrorPortal.Enlarge(p_worldSize);
					}
				}

				for (int p = 0; p < portalQty; p++)
				{
					portals[p].Enlarge(p_worldSize);
				}
			}

			void PopulatePartition(VolumePartition<LinkedList<PortalNodeIndex>> &p_partition)
			{
				for (int n = 0; n < nodeQty; n++)
				{
					int xIndexMin, yIndexMin, zIndexMin;
					int xIndexMax, yIndexMax, zIndexMax;
					p_partition.GetPartitionSectionIndices(nodes[n].boundingVolume.minX, nodes[n].boundingVolume.minY, nodes[n].boundingVolume.minZ, xIndexMin, yIndexMin, zIndexMin);
					p_partition.GetPartitionSectionIndices(nodes[n].boundingVolume.maxX, nodes[n].boundingVolume.maxY, nodes[n].boundingVolume.maxZ, xIndexMax, yIndexMax, zIndexMax);
					for (int xIndex = xIndexMin; xIndex <= xIndexMax; xIndex++)
					{
						for (int yIndex = yIndexMin; yIndex <= yIndexMax; yIndex++)
						{
							for (int zIndex = zIndexMin; zIndex <= zIndexMax; zIndex++)
							{
								p_partition.GetPartitionSectionByIndex(xIndex, yIndex, zIndex)->data.Add(PortalNodeIndex(n));
							}
						}
					}
				}
			}

			BoundingVolume3d GetBoundingVolume()
			{
				return boundingVolume;
			}

		};
	}
}