#pragma once

#include "GameTexture.h"
#include "GraphicsBase.h"

namespace GameEng {
	namespace Graphics {
		public ref class GameTextureRegistry
		{
		private:
			System::Collections::Generic::Dictionary<System::String ^, GameTexture^> textures;

		public:
			// member of a static class - can't have a destructor
			//virtual ~GameTextureRegistry()
			//{
			//	Destroy();
			//}

			void Clear()
			{
				for each (System::String ^key in textures.Keys)
				{
					delete textures[key];
				}
				textures.Clear();
			}

			void Destroy()
			{
				Clear();
			}

			GameTexture ^ RegisterTexture(System::String ^p_textureName, GameTextureInternalFormatEnum p_internalFormat, GameTextureFileComponentUsageEnum p_fileUsage, GameFileResource ^p_fileResource)
			{
				if (textures.ContainsKey(p_textureName) == false)
				{
					GameTexture ^newTexture = gcnew GameTexture(p_textureName, p_internalFormat, p_fileUsage, p_fileResource);
					textures.Add(p_textureName, newTexture);
					return newTexture;
				}
				else
					throw gcnew System::Exception("Texture '" + p_textureName + "' already registered");
			}

			GameTexture ^ RegisterTexture(System::String ^p_textureName, GameTextureInternalFormatEnum p_internalFormat, GameTextureFileComponentUsageEnum p_fileUsage, GameFileResource ^p_fileResource, GameColor &p_colorToConvertToZeroOnLoad)
			{
				if (textures.ContainsKey(p_textureName) == false)
				{
					GameTexture ^newTexture = gcnew GameTexture(p_textureName, p_internalFormat, p_fileUsage, p_fileResource, p_colorToConvertToZeroOnLoad);
					textures.Add(p_textureName, newTexture);
					return newTexture;
				}
				else
					throw gcnew System::Exception("Texture '" + p_textureName + "' already registered");
			}

			// use this one when an override is provided to update the diskfilepath properly
			//GameFileResource ^ RegisterTexture(System::String ^p_resourceFilePath, System::String ^p_diskFilePath)
			//{

			//}

			// todo: routine that parses a reousrce folder and populates this entire structure
			// todo: routine that parses a provided resource folder and updates the entire structure

			GameTexture^ GetTexture(System::String ^p_textureName)
			{
				if (textures.ContainsKey(p_textureName))
					return textures[p_textureName];
				else
					throw gcnew System::Exception("Texture '" + p_textureName + "' not registered");
			}

			// in GraphicsBase.h there is a loadedTexture structure that also tracks this as textures are loaded - the API will release the resources when it is destroyed.
			//   that operation also handles runtime textures, where this does not
			void ClearRendererResources(GraphicsBase &p_graphics)
			{
				// not removing dictionary items, so no need to copy to an array
				for each (System::String ^key in textures.Keys)
				{
					GameTextureRendererResource ^resource = textures[key]->GetRendererResource();
					// texture might not have been loaded
					if (resource != nullptr)
					{
						void *rendererResource = resource->rendererResource;
						p_graphics.ClearTextureRendererResources(rendererResource);
						textures[key]->GetRendererResource()->ClearResource();
					}
				}
			}

		};
	}
}