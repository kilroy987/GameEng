#pragma once

#include "GraphicsBase.h"
#include "Model.h"
#include "JointedModelNative.h"
#include "Matrix.h"

namespace GameEng{
	namespace Graphics {

		using namespace GameEng::Math;

		class JointedModelStanceOrient
		{
		public:
			Orient3d orient; // the orientation
			int orientIndex; // where should this orientation be applied on the game object?
		};

		class JointedModelStance
		{
		public:
			// a set of orientations
			JointedModelStanceOrient *orients;
			int orientQty;
			JointedModelStance()
			{
				orients = nullptr;
				orientQty = 0;
			}
			~JointedModelStance()
			{
				if (orients != nullptr)
				{
					delete[] orients;
					orients = nullptr;
				}
			}
		};

		class JointedModelAnimationKeyframe
		{
		public:
			JointedModelStance stance; // destination stance
			float intervalMSf; // how long to reach the stance?  zero is supported, but not zero for an entire animation!

			void Initialize(int p_orientQty, float p_intervalMSf)
			{
				intervalMSf = p_intervalMSf;
				stance.orients = new JointedModelStanceOrient[p_orientQty];
				stance.orientQty = p_orientQty;
			}

			JointedModelStanceOrient * GetStanceOrient(int p_index)
			{
				return &(stance.orients[p_index]);
			}
		};

		class JointedModelAnimation
		{
		public:
			float totalTimeMSf;
			JointedModelAnimationKeyframe *keyframes;
			int keyframeQty;
			bool looping; // does the animation loop?
			bool committed;
			JointedModelAnimation()
			{
				totalTimeMSf = 0;
				keyframeQty = 0;
				keyframes = nullptr;
				looping = true;
				committed = false;
			}
			~JointedModelAnimation()
			{
				totalTimeMSf = 0;
				if (keyframes != nullptr)
				{
					delete[] keyframes;
					keyframes = nullptr;
				}
			}
			void Initialize(int p_keyframeQty, bool p_looping = true)
			{
				keyframes = new JointedModelAnimationKeyframe[p_keyframeQty];
				keyframeQty = p_keyframeQty;
				looping = p_looping;
			}
			JointedModelAnimationKeyframe * GetKeyframe(int p_index)
			{
				return &keyframes[p_index];
			}
			void Commit()
			{
				totalTimeMSf = 0;
				for (int i = 0; i < keyframeQty; i++)
					totalTimeMSf += keyframes[i].intervalMSf;
				committed = true;
			}

			// for simplicity of coded setup only, could also be used by a tool
			void CopyKeyframeToKeyframe(int p_sourceKeyframeIndex, int p_destinationKeyframeIndex)
			{
				JointedModelAnimationKeyframe *srcKeyframe = &keyframes[p_sourceKeyframeIndex];
				JointedModelAnimationKeyframe *dstKeyframe = &keyframes[p_destinationKeyframeIndex];
				if (dstKeyframe->stance.orients != nullptr)
				{
					// prevent memory leak in case was aready initialized
					delete[] dstKeyframe->stance.orients;
					dstKeyframe->stance.orients = nullptr;
				}
				dstKeyframe->Initialize(srcKeyframe->stance.orientQty, srcKeyframe->intervalMSf);
				for (int i = 0; i < srcKeyframe->stance.orientQty; i++)
				{
					// copy orient and index
					dstKeyframe->stance.orients[i] = srcKeyframe->stance.orients[i];
				}
			}
		};

		// primary todos:
		// support non-looping animations with all permutations of possibility
		// support determining initial key frame when set animation with large time within the animation
		// etc. bulletproof and complete the SetAnimation with timeMS and the aniamtion loop in a way that makes sense.
		// Rules: an animation tracker is assumed to work with a specific set of orients for all animations that could ever be set.  For example,
		//    a tracker works with orients 1 3 4 and 6, and ALL stances and animations used by that tracker works only with and with all of those orients
		//    So an object might have multiple animation trackers to handle distinct animations for different distinct sets of orients (another tracker works with 0 2 and 5, etc.)
		// So a future todo: establish the distinct set of orients a tracker is meant to work with and verify the stances for all the animations it would ever use use ONLY and ALL of those
		//    orients.
		class JointedModelAnimationTracker
		{
			// todo: support sound triggers, pauses, and conditional looping
			// todo: support creating stored interpolation data for the animation, so that it's faster
			// assumed all keyframes deal with the same orientations and quantity
			// not recommended to have multiple trackers operating on a model that overlap orients!  exclusive orients for multiple trackers are fine.
			// todo: support a last time animated vs always sending an elapsedtime.  elapsedTime in this case is the difference between current game time and the lastgametime animated.

		public:
			JointedModelAnimation *animationRef;
			float timeWithinAnimationMSf; // time into animation, support slow motion
			float timeWithinCurrentKeyframef; // time into current keyframe
			int currentKeyframeIndex;
			Orient3d *originalOrients; // where to start orients for this animation - destination orients are in keyframe
			JointedModelAnimationTracker()
			{
				timeWithinAnimationMSf = 0;
				timeWithinCurrentKeyframef = 0;
				originalOrients = nullptr;
				currentKeyframeIndex = -1;
			}

			~JointedModelAnimationTracker()
			{
				if (originalOrients != nullptr)
				{
					delete[] originalOrients;
					originalOrients = nullptr;
				}
			}

			void SetAnimation(JointedModelAnimation *p_animation)
			{
				animationRef = p_animation;
				// no setting of keyframe, or time within animation yet - consider if that is set that normally at the start currentKeyFrame = -1, no originals recorded yet and no game orients initialized
				// so that data will need to be set properly if timeWithin is set
			}

			void SetAnimation(JointedModelAnimation *p_animation, float p_timeWithinAnimationMSf)
			{
				animationRef = p_animation;
				timeWithinAnimationMSf = p_timeWithinAnimationMSf;
				// todo: determine proper currentKeyframeIndex - and important note - if it's not the first one, that doesn't necessarily mean we want to use the original values from the prior keyframe
				//   because we might be setting this animation and time is response to smoothly going from the current stance to this one
				// todo: determine proper time within determined keyframe
				// todo: boolean to force stance to prior keyframe for animation we are setting animation to
				currentKeyframeIndex = 0;
				timeWithinCurrentKeyframef = 0;
				// no setting of keyframe, or time within animation yet - consider if that is set that normally at the start currentKeyFrame = -1, no originals recorded yet and no game orients initialized
				// so that data will need to be set properly if timeWithin is set
			}

			void SetAnimation(JointedModelAnimation *p_animation, float p_timeWithinAnimationMSf, Orient3d *p_gameObjectOrients)
			{
				// this version initializes the orients, used when objects are created
				animationRef = p_animation;
				timeWithinAnimationMSf = p_timeWithinAnimationMSf;
				// todo: determine proper currentKeyframeIndex - and important note - if it's not the first one, that doesn't necessarily mean we want to use the original values from the prior keyframe
				//   because we might be setting this animation and time is response to smoothly going from the current stance to this one
				// todo: determine proper time within determined keyframe
				// todo: boolean to force stance to prior keyframe for animation we are setting animation to
				currentKeyframeIndex = 0;
				timeWithinCurrentKeyframef = 0;
				// no setting of keyframe, or time within animation yet - consider if that is set that normally at the start currentKeyFrame = -1, no originals recorded yet and no game orients initialized
				// so that data will need to be set properly if timeWithin is set
				if (animationRef->looping == false)
				{
					if (p_gameObjectOrients == nullptr)
						throw gcnew Exception("Game orients pointer is null - system needs pointer to obejct's game orients when setting a non-looping animation!");

					// we better copy over the current orients, assuming they've been initialized
					CopyGameObjectOrients(animationRef->GetKeyframe(currentKeyframeIndex)->stance, p_gameObjectOrients, originalOrients);
				}
			}

			void Animate(float p_elapsedTimeMSf, Orient3d *p_gameObjectOrients, bool p_interpolate = true)
			{
				// if p_interpolate is true, aniamte will calculate the orients for rendering.  otherwise, only the tracker will advance with copying of original orients as
				//   keyframes are passed

				if (animationRef->committed == false)
					animationRef->Commit();

				// allocate original storage
				if (originalOrients == nullptr)
				{
					originalOrients = new Orient3d[animationRef->GetKeyframe(0)->stance.orientQty];
				}

				// initialize current frame if not already set - put it at the end so it automatically advances and starts over
				if (currentKeyframeIndex == -1)
				{
					if (animationRef->looping == true)
					{
						currentKeyframeIndex = animationRef->keyframeQty - 1;
						timeWithinAnimationMSf = animationRef->totalTimeMSf;
						timeWithinCurrentKeyframef = animationRef->GetKeyframe(currentKeyframeIndex)->intervalMSf;
						// this will inevitably be advanced by the code below unless elapsedTime is negative... (not handled)
					}
					else
					{
						// what should we do if looping is false?  Trust that the current orients are good values?  This is up to implementation for now,
						//   until we work in safeguards to make sure the object orients have good values if they aren't set.
						// implementation should initialize the object by assigning a full set of stance orients + whatever orients the implement sets on its own.
						currentKeyframeIndex = 0;
						timeWithinAnimationMSf = 0;
						timeWithinCurrentKeyframef = 0;
					}
				}

				// elapsed time, orientations to modify
				JointedModelAnimationKeyframe *currentFrame = animationRef->GetKeyframe(currentKeyframeIndex);

				timeWithinAnimationMSf += p_elapsedTimeMSf;
				timeWithinCurrentKeyframef += p_elapsedTimeMSf;

				// fix loop timer
				if (timeWithinAnimationMSf >= animationRef->totalTimeMSf)
				{
					if (animationRef->looping == true)
					{
						while (timeWithinAnimationMSf >= animationRef->totalTimeMSf)
						{
							timeWithinAnimationMSf -= animationRef->totalTimeMSf;
						}
					}
					else
					{
						// put animation at the end.  we're done.  period.
						currentKeyframeIndex = animationRef->keyframeQty - 1;
						timeWithinAnimationMSf = animationRef->totalTimeMSf;
						timeWithinCurrentKeyframef = animationRef->GetKeyframe(currentKeyframeIndex)->intervalMSf;
					}
				}

				// fix keyframe timer if it got far too large
				// final result keeps it in the same place in the current frame, then we see if the frame is done
				// for now, don't do this - if it's a single frame animation, we need the next loop to properly set the original orients rather than fail to detect the change at all
				// todo: eventually this will need to go back for a very long amount of time passing since the object was animated
				//if (timeWithinCurrentKeyframef >= animationRef->totalTimeMSf)
				//{
				//	while (timeWithinCurrentKeyframef >= animationRef->totalTimeMSf)
				//	{
				//		timeWithinCurrentKeyframef -= animationRef->totalTimeMSf;
				//	}
				//}

				// fix keyframe timer
				if (timeWithinCurrentKeyframef >= currentFrame->intervalMSf)
				{
					JointedModelAnimationKeyframe *priorFrame = nullptr;
					while (timeWithinCurrentKeyframef >= currentFrame->intervalMSf) // zero interval is support to force keyframe past it and apply the orients
					{
						priorFrame = currentFrame;
						timeWithinCurrentKeyframef -= currentFrame->intervalMSf;
						currentKeyframeIndex++;
						if (currentKeyframeIndex >= animationRef->keyframeQty)
						{
							if (animationRef->looping == true)
							{
								currentKeyframeIndex = 0;
								currentFrame = animationRef->GetKeyframe(currentKeyframeIndex);
							}
							else
							{
								// put animation at the end.  we're done.  period.
								currentKeyframeIndex = animationRef->keyframeQty - 1;
								currentFrame = animationRef->GetKeyframe(currentKeyframeIndex);
								timeWithinAnimationMSf = animationRef->totalTimeMSf;
								timeWithinCurrentKeyframef = currentFrame->intervalMSf;
								break;
							}
						}
					}
					// if not looping (support later), do something different!
					// initialize game object orients from last keyframe we passed
					CopyOrientsToGameObject(priorFrame->stance, p_gameObjectOrients);
					CopyStanceOrients(priorFrame->stance, originalOrients);
					// todo: generate data for interpolation
				}

				// now that we are well placed, calculate the game object orients
				if (p_interpolate == true)
				{
					InterpolateOrients(p_gameObjectOrients);
				}
			}

			void InterpolateOrients(Orient3d *p_gameObjectOrients)
			{
				JointedModelAnimationKeyframe *currentFrame = animationRef->GetKeyframe(currentKeyframeIndex);

				// call this when you want to forcibly prepare the orientations for rendering, but do not allow this to be called if Animation was called with interpolate = true
				float t = timeWithinCurrentKeyframef / currentFrame->intervalMSf; // timeWithinCurrentKeyframef should never be greater then currentFrame->intervalMSf at this point
				if (t > 1.0f)
					t = 1.0f; // just in case some oddity with division gives us a t > 1.0f;
				for (int i = 0; i < currentFrame->stance.orientQty; i++)
				{
					// todo: use stored data for interpolation
					p_gameObjectOrients[currentFrame->stance.orients[i].orientIndex] = Orient3d::Interpolate(originalOrients[i], currentFrame->stance.orients[i].orient, t);
				}
			}

			// used to initialize an object with good stance orients, use set animation's stance zero for the initization
			void InitializeStance(Orient3d *p_gameObjectOrients)
			{
				JointedModelAnimationKeyframe *currentFrame = animationRef->GetKeyframe(0);

				for (int i = 0; i < currentFrame->stance.orientQty; i++)
				{
					p_gameObjectOrients[currentFrame->stance.orients[i].orientIndex] = currentFrame->stance.orients[i].orient;
				}
			}

		private:
			void CopyOrientsToGameObject(JointedModelStance &p_stance, Orient3d *p_destinationOrients)
			{
				for (int i = 0; i < p_stance.orientQty; i++)
				{
					p_destinationOrients[p_stance.orients[i].orientIndex] = p_stance.orients[i].orient;
				}
			}
			void CopyStanceOrients(JointedModelStance &p_stance, Orient3d *p_storageOrients)
			{
				for (int i = 0; i < p_stance.orientQty; i++)
				{
					// todo: this should be CopyMemory
					p_storageOrients[i] = p_stance.orients[i].orient;
				}
			}
			void CopyGameObjectOrients(JointedModelStance &p_stance, Orient3d *p_gameObjectOrients, Orient3d *p_destinationOrients)
			{
				for (int i = 0; i < p_stance.orientQty; i++)
				{
					// todo: this should be CopyMemory
					p_destinationOrients[i] = p_gameObjectOrients[p_stance.orients[i].orientIndex];
				}
			}
		};

		class JointedModelOrientIndex
		{
		public:
			int index;

			JointedModelOrientIndex()
			{
				// to support deleted list and base list creation
			}

			JointedModelOrientIndex(int p_index)
			{
				index = p_index;
			}
		};

		// current limitation - do NOT reuse orientIndices in the tree structure, and there must be at least one orientIndex encountered before the first model encountered
		class JointedModel3d
		{
			Model3d *modelRef; // if nullptr no render on this joint
			int orientIndex; // index of gameobject orient array to use - if -1 do not use on this joint.  It's assumed that no joint orients are shared currently, so every orientIndex != -1 counts as a gameobject orient needed.  Sharing complicates the counting and other requirements (like orients needed for shaders to render the joints => a shared orient still requires two joint transforms).
			JointedModel3d *childJoints; // a jointed figure is a tree starting at the world orientation and working towards its endpoints
			int childJointQty;
			int totalJointQty; // total for whole model

			// models that make up the jointed model
			Model3d *models;

			// animations specific to this jointed model - more can be added in implementation, but not to this structure after initialization
			JointedModelAnimation *animations;
			int animationQty;
			JointedModelAnimation *defaultAnimationRef; // do not deallocate this.  It's a reference.

		public:
			JointedModel3d()
			{
				modelRef = nullptr;
				orientIndex = -1;
				childJointQty = 0;
				childJoints = nullptr;

				totalJointQty = 0;

				models = nullptr;
				animations = nullptr;
				animationQty = 0;
				defaultAnimationRef = nullptr;
			}

			~JointedModel3d()
			{
				if (childJoints != nullptr)
				{
					delete[] childJoints;
					childJoints = nullptr;
				}
				if (models != nullptr)
				{
					delete[] models;
					models = nullptr;
				}
				if (animations != nullptr)
				{
					delete[] animations;
					animations = nullptr;
					animationQty = 0;
				}
				// do NOT deallocate, it's a reference
				defaultAnimationRef = nullptr;
			}

			void AllocateAnimations(int p_animationQty)
			{
				if (animationQty == 0 && p_animationQty > 0)
				{
					animations = new JointedModelAnimation[p_animationQty];
					animationQty = p_animationQty;
				}
			}

			Model3d * GetJointModel()
			{
				return modelRef;
			}

			void Initialize(Model3d *p_modelRef = nullptr, int p_orientIndex = -1, int p_childJointQty = 0)
			{
				modelRef = p_modelRef;
				orientIndex = p_orientIndex;

				if (p_childJointQty != 0)
				{
					childJoints = new JointedModel3d[p_childJointQty];
					childJointQty = p_childJointQty;
				}
			}

			JointedModel3d * GetJoint(int p_jointIndex)
			{
				if (childJoints == nullptr)
					throw gcnew Exception("No child joints allocated");

				if (p_jointIndex <= childJointQty)
					return &(childJoints[p_jointIndex]);
				else
					throw gcnew Exception("Joint Qty Index is too high");
			}

			int GetTotalJointOrientQty()
			{
				// recursive - todo: register this number so that the recursive call isn't used all the time
				int total = 0;
				if (orientIndex != -1)
					total = 1;
				for (int i = 0; i < childJointQty; i++)
					total += childJoints[i].GetTotalJointOrientQty();

				return total;
			}

			// caller is responsible for destroying this array
			Orient3d * CreateGameObjectJointOrients()
			{
				if (totalJointQty == 0)
					totalJointQty = GetTotalJointOrientQty();
				if (totalJointQty != 0)
					return new Orient3d[totalJointQty];
				else
					return nullptr;
			}

			void GetOrientProgression(int p_targetIndex, LinkedList<JointedModelOrientIndex> &p_outProgression)
			{
				if (GetOrientProgressionParse(p_targetIndex, p_outProgression) == false)
					throw gcnew Exception(String::Format("Unable to find orient index {0} in parse", p_targetIndex));
			}

		private:
			bool GetOrientProgressionParse(int p_targetIndex, LinkedList<JointedModelOrientIndex> &p_outProgression)
			{
				if (orientIndex == p_targetIndex)
				{
					p_outProgression.Insert(JointedModelOrientIndex(orientIndex));
					return true;
				}
				else
				{
					for (int i = 0; i < childJointQty; i++)
					{
						if (childJoints[i].GetOrientProgressionParse(p_targetIndex, p_outProgression) == true)
						{
							p_outProgression.Insert(JointedModelOrientIndex(orientIndex));
							return true;
						}
					}
				}

				return false;
			}

		public:
			Orient3d CalculateOrientProgression(Orient3d &p_orient, LinkedList<JointedModelOrientIndex> &p_outProgression, Orient3d *p_gameObjectOrients)
			{
				Orient3d result = p_orient;
				LinkedListEnumerator<JointedModelOrientIndex> orientIndexEnum = LinkedListEnumerator<JointedModelOrientIndex>(p_outProgression);
				while (orientIndexEnum.MoveNext())
				{
					int index = orientIndexEnum.Current()->data.index;
					result = result.TransformToSameSpace(p_gameObjectOrients[index]);
				}
				return result;
			}

			JointedModelAnimation * GetAnimation(int p_index)
			{
				return &animations[p_index];
			}

			JointedModelAnimation * GetDefaultAnimation()
			{
				return defaultAnimationRef;
			}

			void Render(GraphicsBase &p_graphics, Orient3d *p_orients, int p_orientQty)
			{
				// kick off parse with transformation tracking
				Render(p_graphics, p_orients, p_orientQty, false);
			}

			private:
				void Render(GraphicsBase &p_graphics, Orient3d *p_orients, int p_orientQty, bool p_transformed)
				{
					if (orientIndex != -1)
					{
						if (orientIndex >= p_orientQty)
							throw gcnew Exception("Orient Index is too high");

						p_graphics.PushMatrix();
						p_graphics.Transform(p_orients[orientIndex]);

						p_transformed = true;
					}
					if (modelRef != nullptr)
					{
						if (p_transformed == false)
							throw gcnew Exception("Model encountered in jointed model tree without a transformation being encountered - first model along any parse path (including root) must have an orient index != -1");

						modelRef->Render(p_graphics);
					}
					for (int i = 0; i < childJointQty; i++)
					{
						childJoints[i].Render(p_graphics, p_orients, p_orientQty, p_transformed);
					}
					if (orientIndex != -1)
					{
						p_graphics.PopMatrix();
					}
				}

			public:

			///////////////////////
			// helper.  TriGuy!!!
			void MakeTriGuy(GameTexture ^p_faceTexture)
			{
				// animations[0] = standing
				// animations[1] = walking forward
				// animations[2] = running forward

				models = new Model3d[4];
				Model3d *fingerKnuckle = &models[0];
				Model3d *handPalm = &models[1];
				Model3d *foot = &models[2];
				Model3d *head = &models[3];

				fingerKnuckle->Initialize(6, 6, 5);
				fingerKnuckle->GetVertex(0)->colorIndex = 0;
				fingerKnuckle->GetVertex(0)->vertex.Set(0.0f, 0.1f, 0.0f);
				fingerKnuckle->GetVertex(1)->colorIndex = 1;
				fingerKnuckle->GetVertex(1)->vertex.Set(0.09f, -0.09f, 0.0f);
				fingerKnuckle->GetVertex(2)->colorIndex = 2;
				fingerKnuckle->GetVertex(2)->vertex.Set(-0.09f, -0.09f, 0.0f);
				fingerKnuckle->GetVertex(3)->colorIndex = 3;
				fingerKnuckle->GetVertex(3)->vertex.Set(0.0f, 0.1f, 0.5f);
				fingerKnuckle->GetVertex(4)->colorIndex = 4;
				fingerKnuckle->GetVertex(4)->vertex.Set(0.09f, -0.09f, 0.5f);
				fingerKnuckle->GetVertex(5)->colorIndex = 5;
				fingerKnuckle->GetVertex(5)->vertex.Set(-0.09f, -0.09f, 0.5f);
				fingerKnuckle->GetColor(0)->Set(128, 128, 128);
				fingerKnuckle->GetColor(1)->Set(255, 0, 0);
				fingerKnuckle->GetColor(2)->Set(0, 0, 255);
				fingerKnuckle->GetColor(3)->Set(0, 255, 0);
				fingerKnuckle->GetColor(4)->Set(255, 255, 255);
				fingerKnuckle->GetColor(5)->Set(255, 128, 0);
				fingerKnuckle->GetSurface(0)->Initialize(3, true);
				fingerKnuckle->GetSurface(1)->Initialize(4, true);
				fingerKnuckle->GetSurface(2)->Initialize(4, true);
				fingerKnuckle->GetSurface(3)->Initialize(4, true);
				fingerKnuckle->GetSurface(4)->Initialize(3, true);
				fingerKnuckle->GetSurface(0)->SetVertexIndex(0, 0);
				fingerKnuckle->GetSurface(0)->SetVertexIndex(1, 2);
				fingerKnuckle->GetSurface(0)->SetVertexIndex(2, 1);
				fingerKnuckle->GetSurface(1)->SetVertexIndex(0, 0);
				fingerKnuckle->GetSurface(1)->SetVertexIndex(1, 1);
				fingerKnuckle->GetSurface(1)->SetVertexIndex(2, 4);
				fingerKnuckle->GetSurface(1)->SetVertexIndex(3, 3);
				fingerKnuckle->GetSurface(2)->SetVertexIndex(0, 0);
				fingerKnuckle->GetSurface(2)->SetVertexIndex(1, 3);
				fingerKnuckle->GetSurface(2)->SetVertexIndex(2, 5);
				fingerKnuckle->GetSurface(2)->SetVertexIndex(3, 2);
				fingerKnuckle->GetSurface(3)->SetVertexIndex(0, 1);
				fingerKnuckle->GetSurface(3)->SetVertexIndex(1, 2);
				fingerKnuckle->GetSurface(3)->SetVertexIndex(2, 5);
				fingerKnuckle->GetSurface(3)->SetVertexIndex(3, 4);
				fingerKnuckle->GetSurface(4)->SetVertexIndex(0, 3);
				fingerKnuckle->GetSurface(4)->SetVertexIndex(1, 4);
				fingerKnuckle->GetSurface(4)->SetVertexIndex(2, 5);
				fingerKnuckle->CalculateNormals();

				handPalm->Initialize(1, 8, 6);
				handPalm->GetVertex(0)->colorIndex = 0;
				handPalm->GetVertex(1)->colorIndex = 0;
				handPalm->GetVertex(2)->colorIndex = 0;
				handPalm->GetVertex(3)->colorIndex = 0;
				handPalm->GetVertex(4)->colorIndex = 0;
				handPalm->GetVertex(5)->colorIndex = 0;
				handPalm->GetVertex(6)->colorIndex = 0;
				handPalm->GetVertex(7)->colorIndex = 0;
				handPalm->GetVertex(0)->vertex.Set(0.3f, 0.075f, 0.0f);
				handPalm->GetVertex(1)->vertex.Set(0.3f, -0.075f, 0.0f);
				handPalm->GetVertex(2)->vertex.Set(-0.3f, -0.075f, 0.0f);
				handPalm->GetVertex(3)->vertex.Set(-0.3f, 0.075f, 0.0f);
				handPalm->GetVertex(4)->vertex.Set(0.4f, 0.1f, 1.0f);
				handPalm->GetVertex(5)->vertex.Set(0.4f, -0.1f, 1.0f);
				handPalm->GetVertex(6)->vertex.Set(-0.4f, -0.1f, 1.0f);
				handPalm->GetVertex(7)->vertex.Set(-0.4f, 0.1f, 1.0f);
				handPalm->GetColor(0)->Set(128, 128, 128);
				handPalm->GetSurface(0)->Initialize(4, true);
				handPalm->GetSurface(1)->Initialize(4, true);
				handPalm->GetSurface(2)->Initialize(4, true);
				handPalm->GetSurface(3)->Initialize(4, true);
				handPalm->GetSurface(4)->Initialize(4, true);
				handPalm->GetSurface(5)->Initialize(4, true);
				handPalm->GetSurface(0)->SetVertexIndex(0, 0);
				handPalm->GetSurface(0)->SetVertexIndex(1, 3);
				handPalm->GetSurface(0)->SetVertexIndex(2, 2);
				handPalm->GetSurface(0)->SetVertexIndex(3, 1);
				handPalm->GetSurface(1)->SetVertexIndex(0, 0);
				handPalm->GetSurface(1)->SetVertexIndex(1, 1);
				handPalm->GetSurface(1)->SetVertexIndex(2, 5);
				handPalm->GetSurface(1)->SetVertexIndex(3, 4);
				handPalm->GetSurface(2)->SetVertexIndex(0, 7);
				handPalm->GetSurface(2)->SetVertexIndex(1, 4);
				handPalm->GetSurface(2)->SetVertexIndex(2, 5);
				handPalm->GetSurface(2)->SetVertexIndex(3, 6);
				handPalm->GetSurface(3)->SetVertexIndex(0, 7);
				handPalm->GetSurface(3)->SetVertexIndex(1, 6);
				handPalm->GetSurface(3)->SetVertexIndex(2, 2);
				handPalm->GetSurface(3)->SetVertexIndex(3, 3);
				handPalm->GetSurface(4)->SetVertexIndex(0, 0);
				handPalm->GetSurface(4)->SetVertexIndex(1, 4);
				handPalm->GetSurface(4)->SetVertexIndex(2, 7);
				handPalm->GetSurface(4)->SetVertexIndex(3, 3);
				handPalm->GetSurface(5)->SetVertexIndex(0, 1);
				handPalm->GetSurface(5)->SetVertexIndex(1, 2);
				handPalm->GetSurface(5)->SetVertexIndex(2, 6);
				handPalm->GetSurface(5)->SetVertexIndex(3, 5);
				handPalm->CalculateNormals();

				foot->Initialize(5, 5, 5);
				foot->GetVertex(0)->colorIndex = 0;
				foot->GetVertex(1)->colorIndex = 1;
				foot->GetVertex(2)->colorIndex = 2;
				foot->GetVertex(3)->colorIndex = 3;
				foot->GetVertex(4)->colorIndex = 4;
				foot->GetVertex(0)->vertex.Set(0.0f, 0.25f, 0.0f);
				foot->GetVertex(1)->vertex.Set(0.5f, -0.25f, 1.5f);
				foot->GetVertex(2)->vertex.Set(-0.5f, -0.25f, 1.5f);
				foot->GetVertex(3)->vertex.Set(-0.5f, -0.25f, -0.5f);
				foot->GetVertex(4)->vertex.Set(0.5f, -0.25f, -0.5f);
				foot->GetColor(0)->Set(128, 128, 128);
				foot->GetColor(1)->Set(255, 0, 0);
				foot->GetColor(2)->Set(255, 255, 255);
				foot->GetColor(3)->Set(0, 0, 255);
				foot->GetColor(4)->Set(0, 255, 0);
				foot->GetSurface(0)->Initialize(3, true);
				foot->GetSurface(1)->Initialize(3, true);
				foot->GetSurface(2)->Initialize(3, true);
				foot->GetSurface(3)->Initialize(3, true);
				foot->GetSurface(4)->Initialize(4, true);
				foot->GetSurface(0)->SetVertexIndex(0, 0);
				foot->GetSurface(0)->SetVertexIndex(1, 1);
				foot->GetSurface(0)->SetVertexIndex(2, 2);
				foot->GetSurface(1)->SetVertexIndex(0, 0);
				foot->GetSurface(1)->SetVertexIndex(1, 2);
				foot->GetSurface(1)->SetVertexIndex(2, 3);
				foot->GetSurface(2)->SetVertexIndex(0, 0);
				foot->GetSurface(2)->SetVertexIndex(1, 3);
				foot->GetSurface(2)->SetVertexIndex(2, 4);
				foot->GetSurface(3)->SetVertexIndex(0, 0);
				foot->GetSurface(3)->SetVertexIndex(1, 4);
				foot->GetSurface(3)->SetVertexIndex(2, 1);
				foot->GetSurface(4)->SetVertexIndex(0, 4);
				foot->GetSurface(4)->SetVertexIndex(1, 3);
				foot->GetSurface(4)->SetVertexIndex(2, 2);
				foot->GetSurface(4)->SetVertexIndex(3, 1);
				foot->CalculateNormals();

				head->Initialize(3, 5, 5);
				head->GetVertex(0)->colorIndex = 0;
				head->GetVertex(1)->colorIndex = 0;
				head->GetVertex(2)->colorIndex = 0;
				head->GetVertex(3)->colorIndex = 1;
				head->GetVertex(4)->colorIndex = 2;
				head->GetColor(0)->Set(255, 255, 255);
				head->GetColor(1)->Set(255, 0, 0);
				head->GetColor(2)->Set(0, 0, 255);
				head->GetVertex(0)->vertex.Set(0.0f, 1.0f, 0.5f);
				head->GetVertex(1)->vertex.Set(1.5f, -1.0f, 1.5f);
				head->GetVertex(2)->vertex.Set(-1.5f, -1.0f, 1.5f);
				head->GetVertex(3)->vertex.Set(-1.5f, -1.0f, -1.5f);
				head->GetVertex(4)->vertex.Set(1.5f, -1.0f, -1.5f);
				head->GetSurface(0)->Initialize(3, true);
				head->GetSurface(1)->Initialize(3, true);
				head->GetSurface(2)->Initialize(3, true);
				head->GetSurface(3)->Initialize(3, true);
				head->GetSurface(4)->Initialize(4, true);
				head->GetSurface(0)->SetVertexIndex(0, 0);
				head->GetSurface(0)->SetVertexIndex(1, 1);
				head->GetSurface(0)->SetVertexIndex(2, 2);
				// face texture used here
				head->GetSurface(0)->SetTexture0(p_faceTexture);
				head->GetSurface(0)->SetVertexTexCoords(0, 0.5f, 0.1f);
				head->GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.9f);
				head->GetSurface(0)->SetVertexTexCoords(2, 0.0f, 0.9f);
				head->GetSurface(1)->SetVertexIndex(0, 0);
				head->GetSurface(1)->SetVertexIndex(1, 2);
				head->GetSurface(1)->SetVertexIndex(2, 3);
				head->GetSurface(2)->SetVertexIndex(0, 0);
				head->GetSurface(2)->SetVertexIndex(1, 3);
				head->GetSurface(2)->SetVertexIndex(2, 4);
				head->GetSurface(3)->SetVertexIndex(0, 0);
				head->GetSurface(3)->SetVertexIndex(1, 4);
				head->GetSurface(3)->SetVertexIndex(2, 1);
				head->GetSurface(4)->SetVertexIndex(0, 4);
				head->GetSurface(4)->SetVertexIndex(1, 3);
				head->GetSurface(4)->SetVertexIndex(2, 2);
				head->GetSurface(4)->SetVertexIndex(3, 1);
				head->CalculateNormals();

				// set up joint structure
				// orients: 0 head, 1 right hand, 2 left hand, 3 right foot, 4 left foot, 5-12 right fingers (5-6 thumb), 13-20 left fingers (13-14 thumb)
				Initialize(nullptr, -1, 5); // head, hand, hand, foot, foot
				// head
				GetJoint(0)->Initialize(head, 0);
				// right hand
				GetJoint(1)->Initialize(handPalm, 1, 4);
				GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 5, 1);
				GetJoint(1)->GetJoint(1)->Initialize(fingerKnuckle, 6, 1);
				GetJoint(1)->GetJoint(2)->Initialize(fingerKnuckle, 7, 1);
				GetJoint(1)->GetJoint(3)->Initialize(fingerKnuckle, 8, 1);
				GetJoint(1)->GetJoint(0)->GetJoint(0)->Initialize(fingerKnuckle, 9);
				GetJoint(1)->GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 10);
				GetJoint(1)->GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 11);
				GetJoint(1)->GetJoint(3)->GetJoint(0)->Initialize(fingerKnuckle, 12);
				// left hand
				GetJoint(2)->Initialize(handPalm, 2, 4);
				GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 13, 1);
				GetJoint(2)->GetJoint(1)->Initialize(fingerKnuckle, 14, 1);
				GetJoint(2)->GetJoint(2)->Initialize(fingerKnuckle, 15, 1);
				GetJoint(2)->GetJoint(3)->Initialize(fingerKnuckle, 16, 1);
				GetJoint(2)->GetJoint(0)->GetJoint(0)->Initialize(fingerKnuckle, 17);
				GetJoint(2)->GetJoint(1)->GetJoint(0)->Initialize(fingerKnuckle, 18);
				GetJoint(2)->GetJoint(2)->GetJoint(0)->Initialize(fingerKnuckle, 19);
				GetJoint(2)->GetJoint(3)->GetJoint(0)->Initialize(fingerKnuckle, 20);
				// right foot
				GetJoint(3)->Initialize(foot, 3);
				// left foot
				GetJoint(4)->Initialize(foot, 4);

				// set up animations and stances
				animations = new JointedModelAnimation[3];
				CreateTriguyStandingAnimation(&animations[0]);
				CreateTriguyWalkingAnimation(&animations[1]);
				CreateTriguyRunningAnimation(&animations[2]);
				defaultAnimationRef = &animations[0];
			}

		private:
			void CreateTriguyStandingAnimation(JointedModelAnimation *animation)
			{
				int orientQty = GetTotalJointOrientQty();

				animation->Initialize(3);
				animation->GetKeyframe(2)->Initialize(orientQty, 1000.0f);
				animation->GetKeyframe(2)->GetStanceOrient(0)->orientIndex = 0;
				animation->GetKeyframe(2)->GetStanceOrient(0)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 1.0f, 0.0f);
				//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
				//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
				animation->GetKeyframe(2)->GetStanceOrient(1)->orientIndex = 3;
				animation->GetKeyframe(2)->GetStanceOrient(1)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(1)->orient.p = Vector3d(-1.0f, -2.5f, 0.0f);
				animation->GetKeyframe(2)->GetStanceOrient(2)->orientIndex = 4;
				animation->GetKeyframe(2)->GetStanceOrient(2)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = Vector3d(1.0f, -2.5f, 0.0f);
				animation->GetKeyframe(2)->GetStanceOrient(3)->orientIndex = 1;
				animation->GetKeyframe(2)->GetStanceOrient(3)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, 0.5f, 0.0f);
				animation->GetKeyframe(2)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(3)->orient.u, 90.0f);
				animation->GetKeyframe(2)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(3)->orient.l, -45.0f);
				animation->GetKeyframe(2)->GetStanceOrient(4)->orientIndex = 2;
				animation->GetKeyframe(2)->GetStanceOrient(4)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, 0.5f, 0.0f);
				animation->GetKeyframe(2)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(4)->orient.u, -90.0f);
				animation->GetKeyframe(2)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(4)->orient.l, -45.0f);
				// right fingers
				// thumb
				animation->GetKeyframe(2)->GetStanceOrient(5)->orientIndex = 5;
				animation->GetKeyframe(2)->GetStanceOrient(5)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
				animation->GetKeyframe(2)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(5)->orient.u, -90.0f);
				// index
				animation->GetKeyframe(2)->GetStanceOrient(6)->orientIndex = 6;
				animation->GetKeyframe(2)->GetStanceOrient(6)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(2)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(6)->orient.u, -10.0f);
				// middle
				animation->GetKeyframe(2)->GetStanceOrient(7)->orientIndex = 7;
				animation->GetKeyframe(2)->GetStanceOrient(7)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
				// pinky
				animation->GetKeyframe(2)->GetStanceOrient(8)->orientIndex = 8;
				animation->GetKeyframe(2)->GetStanceOrient(8)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(2)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(8)->orient.u, 10.0f);
				// 4 digits
				animation->GetKeyframe(2)->GetStanceOrient(9)->orientIndex = 9;
				animation->GetKeyframe(2)->GetStanceOrient(9)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(2)->GetStanceOrient(10)->orientIndex = 10;
				animation->GetKeyframe(2)->GetStanceOrient(10)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(2)->GetStanceOrient(11)->orientIndex = 11;
				animation->GetKeyframe(2)->GetStanceOrient(11)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(2)->GetStanceOrient(12)->orientIndex = 12;
				animation->GetKeyframe(2)->GetStanceOrient(12)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				// left fingers
				// thumb
				animation->GetKeyframe(2)->GetStanceOrient(13)->orientIndex = 13;
				animation->GetKeyframe(2)->GetStanceOrient(13)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
				animation->GetKeyframe(2)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(13)->orient.u, 90.0f);
				// index
				animation->GetKeyframe(2)->GetStanceOrient(14)->orientIndex = 14;
				animation->GetKeyframe(2)->GetStanceOrient(14)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(2)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(14)->orient.u, 10.0f);
				// middle
				animation->GetKeyframe(2)->GetStanceOrient(15)->orientIndex = 15;
				animation->GetKeyframe(2)->GetStanceOrient(15)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
				// pinky
				animation->GetKeyframe(2)->GetStanceOrient(16)->orientIndex = 16;
				animation->GetKeyframe(2)->GetStanceOrient(16)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(2)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(16)->orient.u, -10.0f);
				// digits
				animation->GetKeyframe(2)->GetStanceOrient(17)->orientIndex = 17;
				animation->GetKeyframe(2)->GetStanceOrient(17)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(2)->GetStanceOrient(18)->orientIndex = 18;
				animation->GetKeyframe(2)->GetStanceOrient(18)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(2)->GetStanceOrient(19)->orientIndex = 19;
				animation->GetKeyframe(2)->GetStanceOrient(19)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(2)->GetStanceOrient(20)->orientIndex = 20;
				animation->GetKeyframe(2)->GetStanceOrient(20)->orient.LoadIdentity();
				animation->GetKeyframe(2)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);

				//animation->GetKeyframe(1)->Initialize(orientQty, 875.0f); // copy initializes!
				animation->CopyKeyframeToKeyframe(2, 1);
				animation->GetKeyframe(1)->intervalMSf = 875.0f;
				// dip head
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 0.8f, 0.0f);
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -5.0f);
				// tip feet up
				animation->GetKeyframe(1)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(1)->orient.l, 10.0f);
				animation->GetKeyframe(1)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(2)->orient.l, 10.0f);
				// lower hands
				animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p.y = 0.4f;
				animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p.y = 0.4f;
				// bend all fingers
				animation->GetKeyframe(1)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(5)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(6)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(7)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(8)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(9)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(10)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(11)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(12)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(13)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(14)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(15)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(16)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(17)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(18)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(19)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(20)->orient.l, -45.0f);

				// this stance allows quick recovery from walking, running and jumping
				//animation->GetKeyframe(0)->Initialize(orientQty, 125.0f);  // copy initializes!
				animation->CopyKeyframeToKeyframe(2, 0);
				animation->GetKeyframe(0)->intervalMSf = 125.0f;
				// dip head
				animation->GetKeyframe(0)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 0.975f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -0.625f);
				// tip feet up
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(1)->orient.l, 1.25f);
				animation->GetKeyframe(0)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(2)->orient.l, 1.25f);
				// lower hands
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p.y = 0.49875f;
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p.y = 0.49875f;
				// bend all fingers
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -5.625f);
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -5.625f);

				animation->Commit();
			}

			void CreateTriguyWalkingAnimation(JointedModelAnimation *animation)
			{
				int orientQty = GetTotalJointOrientQty();

				animation->Initialize(4);
				// set up base stance
				animation->GetKeyframe(0)->Initialize(orientQty, 125.0f);
				animation->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
				animation->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 1.0f, 0.0f);
				//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
				//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
				animation->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 3;
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = Vector3d(-1.0f, -2.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 4;
				animation->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(2)->orient.p = Vector3d(1.0f, -2.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 1;
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, 0.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.u, 90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.l, -45.0f);
				animation->GetKeyframe(0)->GetStanceOrient(4)->orientIndex = 2;
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, 0.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.u, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.l, -45.0f);
				// right fingers
				// thumb
				animation->GetKeyframe(0)->GetStanceOrient(5)->orientIndex = 5;
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.u, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -90.0f);
				// index
				animation->GetKeyframe(0)->GetStanceOrient(6)->orientIndex = 6;
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.u, -10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -90.0f);
				// middle
				animation->GetKeyframe(0)->GetStanceOrient(7)->orientIndex = 7;
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -90.0f);
				// pinky
				animation->GetKeyframe(0)->GetStanceOrient(8)->orientIndex = 8;
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.u, 10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -90.0f);
				// 4 digits
				animation->GetKeyframe(0)->GetStanceOrient(9)->orientIndex = 9;
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(10)->orientIndex = 10;
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(11)->orientIndex = 11;
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(12)->orientIndex = 12;
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -90.0f);
				// left fingers
				// thumb
				animation->GetKeyframe(0)->GetStanceOrient(13)->orientIndex = 13;
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.u, 90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -90.0f);
				// index
				animation->GetKeyframe(0)->GetStanceOrient(14)->orientIndex = 14;
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.u, 10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -90.0f);
				// middle
				animation->GetKeyframe(0)->GetStanceOrient(15)->orientIndex = 15;
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -90.0f);
				// pinky
				animation->GetKeyframe(0)->GetStanceOrient(16)->orientIndex = 16;
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.u, -10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -90.0f);
				// digits
				animation->GetKeyframe(0)->GetStanceOrient(17)->orientIndex = 17;
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(18)->orientIndex = 18;
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(19)->orientIndex = 19;
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(20)->orientIndex = 20;
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -90.0f);

				// copy to other stances
				animation->CopyKeyframeToKeyframe(0, 1);
				animation->GetKeyframe(1)->intervalMSf = 250.0f;
				animation->CopyKeyframeToKeyframe(0, 2);
				animation->GetKeyframe(2)->intervalMSf = 125.0f;
				animation->CopyKeyframeToKeyframe(0, 3);
				animation->GetKeyframe(3)->intervalMSf = 250.0f;

				// now modify each so it looks like walking

				// right foot stepping up
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(1)->orient.l, 45.0f);

				// right foot down
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p + Vector3d(0.5f, -0.5f, 0.5f);
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -10.0f);
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.u, -5.0f);
				animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
				animation->GetKeyframe(1)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(2)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -1.0f, 0.0f));
				animation->GetKeyframe(1)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(3)->orient.u, 45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -0.5f, 0.0f));
				animation->GetKeyframe(1)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(4)->orient.u, 45.0f);

				// left foot stepping up
				animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
				animation->GetKeyframe(2)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(2)->orient.l, 45.0f);

				// left foot down
				animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p + Vector3d(-0.5f, -0.5f, 0.5f);
				animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.l, -10.0f);
				animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.u, 5.0f);
				animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
				animation->GetKeyframe(3)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(1)->orient.l, -45.0f);
				animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -0.5f, 0.0f));
				animation->GetKeyframe(3)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(3)->orient.u, -45.0f);
				animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -1.0f, 0.0f));
				animation->GetKeyframe(3)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(4)->orient.u, -45.0f);
			}

			void CreateTriguyRunningAnimation(JointedModelAnimation *animation)
			{
				int orientQty = GetTotalJointOrientQty();

				animation->Initialize(4);
				// set up base stance
				animation->GetKeyframe(0)->Initialize(orientQty, 85.0f);
				animation->GetKeyframe(0)->GetStanceOrient(0)->orientIndex = 0;
				animation->GetKeyframe(0)->GetStanceOrient(0)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(0)->orient.p = Vector3d(0.0f, 1.0f, 0.0f);
				//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.u, -30.0f);
				//animation->GetKeyframe(0)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(0)->orient.l, -30.0f);
				animation->GetKeyframe(0)->GetStanceOrient(1)->orientIndex = 3;
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = Vector3d(-1.0f, -2.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(2)->orientIndex = 4;
				animation->GetKeyframe(0)->GetStanceOrient(2)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(2)->orient.p = Vector3d(1.0f, -2.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(3)->orientIndex = 1;
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.p = Vector3d(-2.0f, 0.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.u, 90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(3)->orient.l, -45.0f);
				animation->GetKeyframe(0)->GetStanceOrient(4)->orientIndex = 2;
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.p = Vector3d(2.0f, 0.5f, 0.0f);
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.u, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(4)->orient.l, -45.0f);
				// right fingers
				// thumb
				animation->GetKeyframe(0)->GetStanceOrient(5)->orientIndex = 5;
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.p = Vector3d(0.3f, 0.0f, 0.3f);
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.u, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(5)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(5)->orient.l, -90.0f);
				// index
				animation->GetKeyframe(0)->GetStanceOrient(6)->orientIndex = 6;
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.u, -10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(6)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(6)->orient.l, -90.0f);
				// middle
				animation->GetKeyframe(0)->GetStanceOrient(7)->orientIndex = 7;
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(7)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(7)->orient.l, -90.0f);
				// pinky
				animation->GetKeyframe(0)->GetStanceOrient(8)->orientIndex = 8;
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.u, 10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(8)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(8)->orient.l, -90.0f);
				// 4 digits
				animation->GetKeyframe(0)->GetStanceOrient(9)->orientIndex = 9;
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(9)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(9)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(10)->orientIndex = 10;
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(10)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(10)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(11)->orientIndex = 11;
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(11)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(11)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(12)->orientIndex = 12;
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(12)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(12)->orient.l, -90.0f);
				// left fingers
				// thumb
				animation->GetKeyframe(0)->GetStanceOrient(13)->orientIndex = 13;
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.p = Vector3d(-0.3f, 0.0f, 0.3f);
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.u, 90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(13)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(13)->orient.l, -90.0f);
				// index
				animation->GetKeyframe(0)->GetStanceOrient(14)->orientIndex = 14;
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.p = Vector3d(-0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.u, 10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(14)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(14)->orient.l, -90.0f);
				// middle
				animation->GetKeyframe(0)->GetStanceOrient(15)->orientIndex = 15;
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.p = Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(15)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(15)->orient.l, -90.0f);
				// pinky
				animation->GetKeyframe(0)->GetStanceOrient(16)->orientIndex = 16;
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.p = Vector3d(0.3f, 0.0f, 1.0f);
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.u, -10.0f);
				animation->GetKeyframe(0)->GetStanceOrient(16)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(16)->orient.l, -90.0f);
				// digits
				animation->GetKeyframe(0)->GetStanceOrient(17)->orientIndex = 17;
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(17)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(17)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(18)->orientIndex = 18;
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(18)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(18)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(19)->orientIndex = 19;
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(19)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(19)->orient.l, -90.0f);
				animation->GetKeyframe(0)->GetStanceOrient(20)->orientIndex = 20;
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.LoadIdentity();
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.p = Vector3d(0.0f, 0.0f, 0.5f);
				animation->GetKeyframe(0)->GetStanceOrient(20)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(20)->orient.l, -90.0f);

				// copy to other stances
				animation->CopyKeyframeToKeyframe(0, 1);
				animation->GetKeyframe(1)->intervalMSf = 179.0f;
				animation->CopyKeyframeToKeyframe(0, 2);
				animation->GetKeyframe(2)->intervalMSf = 85.0f;
				animation->CopyKeyframeToKeyframe(0, 3);
				animation->GetKeyframe(3)->intervalMSf = 170.0f;

				// now modify each so it looks like walking

				// right foot stepping up
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(0)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
				animation->GetKeyframe(0)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(0)->GetStanceOrient(1)->orient.l, 45.0f);

				// right foot down
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(0)->orient.p + Vector3d(0.5f, -0.5f, 0.5f);
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.l, -10.0f);
				animation->GetKeyframe(1)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(0)->orient.u, -5.0f);
				animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
				animation->GetKeyframe(1)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(2)->orient.l, -45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -1.0f, 0.0f));
				animation->GetKeyframe(1)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(3)->orient.u, 45.0f);
				animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(1)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(1)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(-2.0f, -0.5f, 0.0f));
				animation->GetKeyframe(1)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(1)->GetStanceOrient(4)->orient.u, 45.0f);

				// left foot stepping up
				animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(2)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 1.3f, 1.2f);
				animation->GetKeyframe(2)->GetStanceOrient(2)->orient.Rotate(animation->GetKeyframe(2)->GetStanceOrient(2)->orient.l, 45.0f);

				// left foot down
				animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(0)->orient.p + Vector3d(-0.5f, -0.5f, 0.5f);
				animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.l, -10.0f);
				animation->GetKeyframe(3)->GetStanceOrient(0)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(0)->orient.u, 5.0f);
				animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(1)->orient.p + Vector3d(0.0f, 1.0f, -1.0f);
				animation->GetKeyframe(3)->GetStanceOrient(1)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(1)->orient.l, -45.0f);
				animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(2)->orient.p + Vector3d(0.0f, 0.0f, 1.0f);
				animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(3)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(3)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -0.5f, 0.0f));
				animation->GetKeyframe(3)->GetStanceOrient(3)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(3)->orient.u, -45.0f);
				animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p = animation->GetKeyframe(3)->GetStanceOrient(4)->orient.p + animation->GetKeyframe(3)->GetStanceOrient(4)->orient.TransformToWorldSpaceOffset(Vector3d(2.0f, -1.0f, 0.0f));
				animation->GetKeyframe(3)->GetStanceOrient(4)->orient.Rotate(animation->GetKeyframe(3)->GetStanceOrient(4)->orient.u, -45.0f);
			}

		public:
			//////////////////
			// Native (shader) support
			void CreateNativeObject(GraphicsBase *p_graphics, GraphicsNativeObjectContainer *p_container, bool p_lightingNormals)
			{
				int size = 0;
				JointedModelNativeData *nativeData = PrepareNativeObjectData(size);
				p_graphics->CreateNativeObject(p_container, nativeData, size, p_lightingNormals);
				delete[] nativeData;
			}

		private:
			JointedModelNativeData * PrepareNativeObjectData(int &p_arraySize)
			{
				// return an array of native data to prepare a native object with
				// call this routine, then when the array returned, call createnative object
				// caller should delete the array after its use
				p_arraySize = CountModelInstances();

				JointedModelNativeData *nativeData = new JointedModelNativeData[p_arraySize];
				int nativeIndex = 0;
				PopulateNativeObjectData(nativeData, nativeIndex);

				return nativeData;
			}

			int CountModelInstances()
			{
				int total = 0;
				if (modelRef != nullptr)
					total++;

				for (int i = 0; i < childJointQty; i++)
				{
					total += childJoints[i].CountModelInstances();
				}

				return total;
			}

		private:
			void PopulateNativeObjectData(JointedModelNativeData *p_nativeData)
			{
				// kicks off recursive
				int nativeIndex = 0;
				PopulateNativeObjectData(p_nativeData, nativeIndex);
			}

			void PopulateNativeObjectData(JointedModelNativeData *p_nativeData, int &p_currentNativeDataIndex, int p_currentOrientIndex = -1)
			{
				// any joint that has a model, record references to its data in the array
				// and note each orientIndex used by that model

				// if orient on this joint not used, use whatever was sent in
				// IMPORTANT NOTE: The root join on any model shoudl have an orient used otherwise this breaks down!
				int orientIndexToUse;
				if (orientIndex != -1)
					orientIndexToUse = orientIndex;
				else
					// no orient here, so use parent orient
					orientIndexToUse = p_currentOrientIndex;

				if (modelRef != nullptr)
				{
					if (orientIndexToUse == -1)
						throw gcnew Exception("Orient Index is -1 - it must be a valid index (>=0) for every joint model that would be rendered - that is, the first model encountered along any parse path from the root (including the root) must have an orientIndex != -1");

					p_nativeData[p_currentNativeDataIndex].surfaceRef = modelRef->GetSurfaces();
					p_nativeData[p_currentNativeDataIndex].surfaceQty = modelRef->GetSurfaceQty();
					p_nativeData[p_currentNativeDataIndex].verticesRef = modelRef->GetVertices();
					p_nativeData[p_currentNativeDataIndex].vertexQty = modelRef->GetVertexQty();
					p_nativeData[p_currentNativeDataIndex].colorsRef = modelRef->GetColors();
					p_nativeData[p_currentNativeDataIndex].orientIndex = orientIndexToUse;

					p_currentNativeDataIndex++;
				}

				for (int i = 0; i < childJointQty; i++)
				{
					childJoints[i].PopulateNativeObjectData(p_nativeData, p_currentNativeDataIndex, orientIndexToUse);
				}
			}

		public:
			void PrepareNativeObjectJointOrients(Orient3dSimple *p_orients, Orient3d *p_gameObjectOrients, Orient3d &p_worldRootOrient, float p_positionScale = 1.0f)
			{
				// p_prepareLightOrients would be false when not rendering for lights or rendering into shadowmaps only
				// use p_lightPositionScale when model is rendered scaled

				// populate an array of matrices (assumed to be large enough) with the progressive results of transforming along the child joints
				// index in game object orients = index in matrices
				if (orientIndex != -1)
				{
					// for transforming vertices and light data prior to rendering
					Orient3d transformedOrient = p_worldRootOrient.TransformToSameSpace(p_gameObjectOrients[orientIndex], p_positionScale);
					p_orients[orientIndex].Set(transformedOrient); // if orientIndex is re-used down the chain, this breaks down!!!

					for (int i = 0; i < childJointQty; i++)
					{
						// use this joint's parent as the result for the 
						childJoints[i].PrepareNativeObjectJointOrients(p_orients, p_gameObjectOrients, transformedOrient, p_positionScale);
					}
				}
				else
				{
					for (int i = 0; i < childJointQty; i++)
					{
						// use this joint's parent as the result for the 
						childJoints[i].PrepareNativeObjectJointOrients(p_orients, p_gameObjectOrients, p_worldRootOrient, p_positionScale);
					}
				}
			}

		};
	}
}