#pragma once

#include "Vector.h"

namespace GameEng {
	namespace Geometry {

		using namespace GameEng::Math;

		// just a volume meant to contain points, edge planes always lined up with the axis system of the space
		class BoundingVolume3d
		{
		public:
			// inclusive of all points
			float minX, minY, minZ;
			float maxX, maxY, maxZ;
			bool empty;

			BoundingVolume3d()
			{
				Clear();
			}

			void Clear()
			{
				empty = true; // invalidates current values, accepts first point as initialization
			}

			void ProcessPoint(Vector3d &p_point)
			{
				// determine bounds of volume based on points within it, one at a time
				if (empty == true)
				{
					minX = p_point.x;
					minY = p_point.y;
					minZ = p_point.z;
					maxX = p_point.x;
					maxY = p_point.y;
					maxZ = p_point.z;

					empty = false;
				}
				else
				{
					if (p_point.x < minX)
						minX = p_point.x;
					if (p_point.x > maxX)
						maxX = p_point.x;
					if (p_point.y < minY)
						minY = p_point.y;
					if (p_point.y > maxY)
						maxY = p_point.y;
					if (p_point.z < minZ)
						minZ = p_point.z;
					if (p_point.z > maxZ)
						maxZ = p_point.z;
				}
			}

			bool IsBehind(Vector3d &p_position, Vector3d &p_forward)
			{
				if (empty == true)
					return false;

				// if any corner point is in front of the position with the forward vector, return false
				// if all are behind, return true
				// (todo: upgrade later with a frustrum intersect)
				if (((Vector3d::Vector(minX, minY, minZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(minX, maxY, minZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(minX, minY, maxZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(minX, maxY, maxZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(maxX, minY, minZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(maxX, maxY, minZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(maxX, minY, maxZ) - p_position) * p_forward) > 0.0f)
					return false;
				if (((Vector3d::Vector(maxX, maxY, maxZ) - p_position) * p_forward) > 0.0f)
					return false;

				return true;
			}

			bool PointIsInside(Vector3d &p_position)
			{
				if (empty == true)
					return false;

				if (p_position.x < minX)
					return false;
				if (p_position.x > maxX)
					return false;
				if (p_position.y < minY)
					return false;
				if (p_position.y > maxY)
					return false;
				if (p_position.z < minZ)
					return false;
				if (p_position.z > maxZ)
					return false;

				return true;
			}

			// simple distance along an orthogonal axis
			float PointOrthogonalDistance(Vector3d &p_position)
			{
				if (empty == true)
					return 0.0f;

				// this actually doesn't speed it up
				//if (PointIsInside(p_position))
				//	return 0.0f;

				float distance = 0.0f;
				float tempDistance = 0.0f;

				if (p_position.x < minX)
				{
					tempDistance = minX - p_position.x;
					if (distance < tempDistance)
						distance = tempDistance;
				}
				if (p_position.x > maxX)
				{
					tempDistance = p_position.x - maxX;
					if (distance < tempDistance)
						distance = tempDistance;
				}
				if (p_position.y < minY)
				{
					tempDistance = minY - p_position.y;
					if (distance < tempDistance)
						distance = tempDistance;
				}
				if (p_position.y > maxY)
				{
					tempDistance = p_position.y - maxY;
					if (distance < tempDistance)
						distance = tempDistance;
				}
				if (p_position.z < minZ)
				{
					tempDistance = minZ - p_position.z;
					if (distance < tempDistance)
						distance = tempDistance;
				}
				if (p_position.z > maxZ)
				{
					tempDistance = p_position.z - maxZ;
					if (distance < tempDistance)
						distance = tempDistance;
				}

				return distance;
			}

			// include volume in bounding volume limits
			void ProcessVolume(BoundingVolume3d &p_volume)
			{
				if (empty == true)
				{
					minX = p_volume.minX;
					minY = p_volume.minY;
					minZ = p_volume.minZ;
					maxX = p_volume.maxX;
					maxY = p_volume.maxY;
					maxZ = p_volume.maxZ;

					empty = false;
				}
				else
				{
					if (minX > p_volume.minX)
						minX = p_volume.minX;
					if (minY > p_volume.minY)
						minY = p_volume.minY;
					if (minZ > p_volume.minZ)
						minZ = p_volume.minZ;

					if (maxX < p_volume.maxX)
						maxX = p_volume.maxX;
					if (maxY < p_volume.maxY)
						maxY = p_volume.maxY;
					if (maxZ < p_volume.maxZ)
						maxZ = p_volume.maxZ;
				}
			}

			bool Intersects(BoundingVolume3d &p_volume)
			{
				// equal boundary does not constitute intersection
				if (minX >= p_volume.maxX)
					return false;
				if (minY >= p_volume.maxY)
					return false;
				if (minZ >= p_volume.maxZ)
					return false;

				if (maxX <= p_volume.minX)
					return false;
				if (maxY <= p_volume.minY)
					return false;
				if (maxZ <= p_volume.minZ)
					return false;

				return true;
			}
		};
	}
}