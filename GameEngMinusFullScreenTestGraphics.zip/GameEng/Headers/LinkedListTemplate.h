#pragma once

#include "string.h"

namespace GameEng {
	namespace Storage{

		using namespace System::Diagnostics;

		// node for linked list
		// Obvious to note, but make sure that prev and next point at nodes that are in the SAME list at all times.  If a node in one list has a next or prev that points at a node in a different
		//   list, the bugs will be difficult to track (unless an id for which list a node belongs to is added - a void pointer may suffice, but this would have to be updated
		//   whenever a node is created for or moved to another list)
		template <class T> class LinkedListNode
		{
		public:
			LinkedListNode<T> *prev;
			LinkedListNode<T> *next;

			T data;
		};


		// double linked list
		// IMPORTANT: Take care setting a linked list equal to another linked list.  Header and Footer will be unique, but the nodes of the list will not be unique, and if either list is
		//   deconstructed for any reason, the other list's nodes will now reside in the DeleteList despite still accessing them with its pointers, and its header->prev and footer->next will
		//   be invalid for the list, and any call to GetNewNode() will further corrupt the list because that node's pointers will be altered in a way that further disobeys the list.
		template <class T> class LinkedList
		{
		private:
			char name[100]; // for debugging only

			void Initialize()
			{
				header.prev = nullptr;
				header.next = &footer;
				footer.prev = &header;
				footer.next = nullptr;
			}

		public:
			LinkedList()
			{
				strcpy_s(name, 100, "");
				Initialize();
			}

			LinkedList(char *p_name)
			{
				strcpy_s(name, 100, p_name);
				Initialize();
			}

			static LinkedList<T> DeletedList; // every lined list of a given type will have a deleted list
			// for instance, if you declare a data type of MyGameObject
			// and end up with a list structure of type LinkedList<MyGameObject>
			// then in a .cpp file somewhere you'll need: LinkedList<MyGameObject> LinkedList<MyGameObject>::DeletedList;
			// And it will handle deleted nodes for ALL your occurrences of LinkedList<MyGameObject>.

			virtual ~LinkedList()
			{
				Destroy();
			}

			LinkedListNode<T> header;
			LinkedListNode<T> footer;

			bool IsEmpty()
			{
				return (header.next == &footer);
			}

			LinkedListNode<T> * Add(T p_data)
			{
				LinkedListNode<T> *newNode = GetNewNode();
				newNode->data = p_data;
				AddNode(newNode);
				return newNode;
			}

			void AddNode(LinkedListNode<T> *p_node)
			{
				p_node->next = &footer;
				p_node->prev = footer.prev;
				footer.prev->next = p_node;
				footer.prev = p_node;
			}

			void Insert(T p_data, LinkedListNode<T> *p_insertAfter = nullptr)
			{
				LinkedListNode<T> *newNode = GetNewNode();
				newNode->data = p_data;
				InsertNode(newNode, p_insertAfter);
			}

			void InsertNode(LinkedListNode<T> *p_node, LinkedListNode<T> *p_insertAfter = nullptr)
			{
				if (p_insertAfter == nullptr)
				{
					// insert as first node
					header.next->prev = p_node;
					p_node->next = header.next;
					header.next = p_node;
					p_node->prev = &header;
				}
				else
				{
					// insert after specified node
					p_insertAfter->next->prev = p_node;
					p_node->next = p_insertAfter->next;
					p_insertAfter->next = p_node;
					p_node->prev = p_insertAfter;
				}
			}

			LinkedListNode<T> * GetFirstNode()
			{
				if (IsEmpty() == false)
				{
					return header.next;
				}
				else
					return nullptr;
			}

			LinkedListNode<T> * GetLastNode()
			{
				if (IsEmpty() == false)
				{
					return footer.prev;
				}
				else
					return nullptr;
			}

			LinkedListNode<T> * DetachFirstNode()
			{
				LinkedListNode<T> *node = GetFirstNode();
				if (node != nullptr)
					DetachNode(node);

				return node;
			}

			LinkedListNode<T> * GetNewNode()
			{
				LinkedListNode<T> *result = DeletedList.DetachFirstNode();
				if (result != nullptr)
					return result;
				else
					return new LinkedListNode<T>();
			}

			void DetachNode(LinkedListNode<T> *p_node)
			{
				p_node->prev->next = p_node->next;
				p_node->next->prev = p_node->prev;
			}

			void MoveNodeToFront(LinkedListNode<T> *p_node)
			{
				DetachNode(p_node);
				InsertNode(p_node);
			}

			// delete is a removal, not a flagging that the node is deleted.
			void DeleteNode(LinkedListNode<T> *p_node)
			{
				DetachNode(p_node);
				DeletedList.AddNode(p_node);
			}

			// move all nodes to deleted list
			void Clear()
			{
				if (IsEmpty() == false)
				{
					LinkedListNode<T> *firstNode = GetFirstNode();
					LinkedListNode<T> *lastNode = GetLastNode();

					firstNode->prev = &DeletedList.header;
					lastNode->next = DeletedList.header.next;
					DeletedList.header.next->prev = lastNode;
					DeletedList.header.next = firstNode;

					// reset main list
					header.next = &footer;
					footer.prev = &header;
				}
			}

			int Count()
			{
				int count = 0;
				LinkedListNode<T> *node = header.next;
				while (node != &footer)
				{
					node = node->next;
					count++;
				}
				return count;
			}

			void DebugValidate()
			{
#ifdef _DEBUG
				// throw exception if any problems encountered
				if (header.next->prev != &header)
					throw gcnew System::Exception("Prev of node next of header does not point back to header!");
				if (footer.prev->next != &footer)
					throw gcnew System::Exception("Next of node prev of footer does not point back to header!");

				// check integrity of list
				LinkedListNode<T> *node = header.next;
				int nodeCount = 0;
				while (node != nullptr)
				{
					if (node->next == nullptr)
					{
						if (node != &(footer))
							throw gcnew System::Exception("Last node encountered is not the footer for this list!!");
					}
					else
					{
						if (node->next->prev != node)
							throw gcnew System::Exception(String::Format("Node {0}: Prev of node next of current does not point back to current!", nodeCount));

					}

					node = node->next;
					nodeCount++;
				}

				// list is ok
#endif _DEBUG
			}

			// delegate just needs to look like: int MethodName(T *p_data1, T *p_data2) and pass its pointer into BubbleSort
			typedef bool (_cdecl *BubbleSortCompareInvalidMethod)(T *p_data1, T *p_data2);

			void BubbleSortLastToFirst(BubbleSortCompareInvalidMethod compareInvalidMethod)
			{
				// This routine works best when the node inserted that might be in a bad place is at the end of an already sorted list, since each main loop starts at the end and works backwards

				// todo: take a detach node, work backwards and place node where it fits approach rather than constantly swapping it to bubble it up

				// 10 7 2 1
				// =
				// 10 7 (1 2)
				// 10 (1 7) 2
				// (1 10) 7 2
				// -
				// 1 10 (2 7)
				// 1 (2 10) 7
				// -
				// 1 2 (7 10)

				// nothing to stort
				if (IsEmpty())
					return;
				// only one item, no need to sort
				if (header.next->next == &footer)
					return;

				LinkedListNode<T> *stopNode = &header;
				if (stopNode != nullptr)
				{
					while (stopNode != footer.prev->prev) // stop when we just finished a list and only one node is left to parse
					{
						LinkedListNode<T> *node = GetLastNode();
						bool anySwap = false;
						while (node->prev != stopNode) // stop when we approach the stop node
						{
							// node compare values (determined by delegate) should be in valid order of comparison from header to footer
							// todo: consider avoiding delegates, they are slower
							if (compareInvalidMethod(&(node->prev->data), &(node->data)) == true)
							{
								// swap the nodes
								LinkedListNode<T> *preNode = node->prev->prev; // node before the two being swapped
								LinkedListNode<T> *postNode = node->next; // node after the two being swapped
								LinkedListNode<T> *firstNode = node->prev; // the first of the two nodes (node = firstNode->next)

								preNode->next = node;
								node->prev = preNode;
								node->next = firstNode;
								firstNode->prev = node;
								firstNode->next = postNode;
								postNode->prev = firstNode;

								anySwap = true;

								// leave node pointing where it is.  It just auto advanced
							}
							else
								node = node->prev;
						}

						// if nothing fixed, leave.  We are done.
						if (anySwap == false)
							break;

						// move the stop node forwards
						stopNode = stopNode->next;
					}
				}

				// check results
				bool checkResults = false;
				if (checkResults == true)
				{
					int nodeQty = 0;
					LinkedListNode<T> *node = GetFirstNode();
					bool anyBad = false;
					while (node->next != &(footer))
					{
						nodeQty++;

						if (compareInvalidMethod(&(node->data), &(node->next->data)) == true)
						{
							anyBad = true;
							break;
						}

						node = node->next;
					}
					if (anyBad == true && nodeQty > 0) // nodeQty > 0 here to prevent Release build from optimizing it out
					{
						throw gcnew Exception("BubbleSortLastToFirst: Sort failed - nodes still out of order");
					}
				}
			}

			void BubbleSortFirstToLast(BubbleSortCompareInvalidMethod compareInvalidMethod)
			{
				// This routine works best when the node inserted that might be in a bad place is at the end of an already sorted list, since each main loop starts at the end and works backwards

				// todo: take a detach node, work backwards and place node where it fits approach rather than constantly swapping it to bubble it up

				// 10 7 2 1
				// =
				// (7 10) 2 1
				// 7 (2 10) 1
				// 7 2 (1 10)
				// -
				// (2 7) 1 10
				// 2 (1 7) 10
				// -
				// (1 2) 7 10

				// nothing to stort
				if (IsEmpty())
					return;
				// only one item, no need to sort
				if (header.next->next == &footer)
					return;

				LinkedListNode<T> *stopNode = &footer;
				if (stopNode != nullptr)
				{
					while (stopNode != header.next->next) // stop when we just finished a list and only one node is left to parse
					{
						LinkedListNode<T> *node = GetFirstNode();
						bool anySwap = false;
						while (node->next != stopNode) // stop when we approach the stop node
						{
							// node compare values (determined by delegate) should be in valid order of comparison from header to footer
							// todo: consider avoiding delegates, they are slower
							if (compareInvalidMethod(&(node->data), &(node->next->data)) == true)
							{
								// swap the nodes
								LinkedListNode<T> *preNode = node->prev; // node before the two being swapped
								LinkedListNode<T> *postNode = node->next->next; // node after the two being swapped
								LinkedListNode<T> *secondNode = node->next; // the second of the two nodes (firstNode = node)

								preNode->next = secondNode;
								secondNode->prev = preNode;
								secondNode->next = node;
								node->prev = secondNode;
								node->next = postNode;
								postNode->prev = node;

								anySwap = true;

								// leave node pointing where it is.  It just auto advanced
							}
							else
								node = node->next;
						}

						// if nothing fixed, leave.  We are done.
						if (anySwap == false)
							break;

						// move the stop node forwards
						stopNode = stopNode->prev;
					}
				}

				// check results
				bool checkResults = false;
				if (checkResults == true)
				{
					int nodeQty = 0;
					LinkedListNode<T> *node = GetFirstNode();
					bool anyBad = false;
					while (node->next != &(footer))
					{
						nodeQty++;

						if (compareInvalidMethod(&(node->data), &(node->next->data)) == true)
						{
							anyBad = true;
							break;
						}

						node = node->next;
					}
					if (anyBad == true && nodeQty > 0) // nodeQty > 0 here to prevent Release build from optimizing it out
					{
						throw gcnew Exception("BubbleSortFirstToLast: Sort failed - nodes still out of order");
					}
				}
			}

		protected:
			void Destroy()
			{

				// if not a deleted list, move nodes to the deleted list
				if (&header != &(DeletedList.header))
				{
					Clear();
				}
				else
				{
					if (name[0] != '\0')
						System::Diagnostics::Trace::WriteLine("Destroying list '" + gcnew System::String(name) + "'");

					// otherwise, wipe out the nodes
					while (IsEmpty() == false)
					{
						LinkedListNode<T> *node = GetFirstNode();
						DetachNode(node);
						delete node;
					}
				}
			}
		};

		// usage:
		// enumerator = new LinkedListEnumerator<type>(linkedList);
		// while (enumerator->MoveNext() != nullptr)
		// { work with Current() }
		template <class T> class LinkedListEnumerator
		{
		private:
			LinkedListNode<T> *currentRef;
			LinkedListNode<T> *firstNodeRef; // haven't advanced yet
			LinkedListNode<T> *lastNodeRef;
			bool forward;
			bool firstMoveNext;

		public:
			LinkedListEnumerator(LinkedList<T> &p_linkedList, bool p_forward = true)
			{
				if (p_forward == true)
				{
					currentRef = &p_linkedList.header;
					firstNodeRef = currentRef;
					lastNodeRef = &p_linkedList.footer;
				}
				else
				{
					currentRef = &p_linkedList.footer;
					firstNodeRef = currentRef;
					lastNodeRef = &p_linkedList.header;
				}
				forward = p_forward;
				firstMoveNext = false;
			}

			LinkedListEnumerator(LinkedList<T> &p_linkedList, LinkedListNode<T> *p_startNodeExcluded, bool p_forward = true)
			{
				// startNode is NOT included in the parse. The actual list starts with the node AFTER it. (for now) - if you change this, be VERY aware of where this is used!

				if (p_startNodeExcluded == nullptr)
					throw gcnew System::Exception("Starting node must not be null");

				if (p_forward == true)
				{
					currentRef = p_startNodeExcluded;
					lastNodeRef = &p_linkedList.footer;
				}
				else
				{
					currentRef = p_startNodeExcluded;
					lastNodeRef = &p_linkedList.header;
				}
				forward = p_forward;
				firstMoveNext = true;
				firstNodeRef = nullptr;
			}

			bool MoveNext()
			{
				if (firstMoveNext == true)
				{
					firstMoveNext = false;
				}

				if (currentRef == lastNodeRef)
					throw gcnew System::Exception("Enumerator past end of list");

				if (forward == true)
					currentRef = currentRef->next;
				else
					currentRef = currentRef->prev;

				if (currentRef == lastNodeRef)
					return false;
				else
					return true;
			}

			LinkedListNode<T> * PeekNext()
			{
				if (currentRef == lastNodeRef)
					throw gcnew Exception("Enumerator past end of list");

				LinkedListNode<T> *tempNext;
				if (forward == true)
					tempNext = currentRef->next;
				else
					tempNext = currentRef->prev;

				if (tempNext == lastNodeRef)
					return nullptr;
				else
					return tempNext;
			}

			// avoid calling this too often - get a safe value pointer in the calling code and use that instead
			LinkedListNode<T> * Current()
			{
				if (currentRef == firstNodeRef)
					throw gcnew System::Exception("Call MoveNext() once before accessing Current()");
				if (firstMoveNext == true)
					throw gcnew System::Exception("Call MoveNext() once before accessing Current()");

				if (currentRef == lastNodeRef)
					throw gcnew System::Exception("Enumerator past end of list");

				return currentRef;
			}

		};
	}
}