#pragma once

#include "GameInput.h"
#include "GameViewport.h"

namespace GameEng {
namespace Game {

	using namespace GameEng::Input;
	using namespace GameEng::Graphics;
	using namespace System::Diagnostics;

	public ref class GameBase
	{
	public:
		bool appActivated; // is the app the active window? (maintained by outer UI layer before AppActivated/Deactivated is called)

	protected:
		GameInputEventList *inputEvents;
		GameKeyboardKeys keyboardKeys;
		GameMouse mouse;
		GameJoystick *joystick;

	public:
		// standard methods not to be overridden - communicated from outer layer
		void KeyUp(int p_keyValue, bool p_shift, bool p_alt, bool p_ctrl);
		void KeyDown(int p_keyValue, bool p_shift, bool p_alt, bool p_ctrl);
		void MouseMove(int p_x, int p_y);
		void MouseButtonEvent(MouseButton p_button, bool p_down);
		void MouseWheel(int p_delta);

		GameBase(HWND p_hWnd)
		{
			appActivated = true;
			joystick = new GameJoystick(p_hWnd);
			inputEvents = new GameInputEventList();
		}

		virtual ~GameBase()
		{
			// game is officially ending

			Trace::WriteLine("GameBase::Destroy");
			Destroy();
			Trace::WriteLine("GameBase::Destroy finished");

			// show mouse cursor
			if (mouse.IsVisible() == false)
			{
				mouse.Show();
			}

			if (joystick != nullptr)
			{
				delete joystick;
				joystick = nullptr;
			}

			if (inputEvents != nullptr)
			{
				delete inputEvents;
				inputEvents = nullptr;
			}
		}

	public:
		// virtual methods to be overridden
		virtual void ApplicationActivated();
		virtual void ApplicationDeactivated();
		virtual void ViewportSizeChanged(GameViewport ^p_viewport) {};
		virtual void ViewportSizeChanged(int p_width, int p_height) {};

		virtual String^ ApplicationName() { return ""; }; // text that appears in the caption of the app window, and the minimized app bar

		virtual void Initialize();

		// return false to stop everything
		virtual bool DoGameLoop();

		virtual void PerformRender();

		// use this routine to do a lesser render from inside DoGameLoop ONLY for purposes of showing user information on a blocking process, like reporting a network connecting message or loading levels/textures.
		virtual void BlockRender(); // call only from inside a process running DoGameLoop, NEVER from inside PerformRender process!

		virtual void Destroy();

		JoystickValues * GetJoystickValues();

		bool BaseGameLoop()
		{
			// return false if app is supposed to stop (DoGameLoop() is responsible for that)

			mouse.CheckMouseUp(); // reset mouse down target if all mouse buttons are up so that ui and game can allocate mousedown to target when it happens again

			bool retValue = DoGameLoop();

			// better consume these in game loop because we aren't keeping them!
			inputEvents->Clear();

			return retValue;
		}
	};

	} // namespace Game
} // namespace GameEng
