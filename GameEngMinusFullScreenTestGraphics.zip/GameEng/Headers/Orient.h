#pragma once

#include "Vector.h"
#include "Matrix.h"

namespace GameEng {
	namespace Math {

		using namespace System;

		enum Orient3dAxis
		{
			Left, Up, Forward
		};

		// data used to interpolate between two orientation structures
		class OrientInterpolationData
		{
		public:
			Vector3d movementVector; // from p0 to p1
			// if axis1 == 0.0f, don't do any rotation
			// primary axis of rotation
			Vector3d axis1;
			float degrees1;
			// secondary axis of rotation
			// if axis2 == 0.0f, ignore second rotation
			Vector3d axis2;
			float degrees2;
		};

		class Orient3d
		{
		public:
			// when uploading to shader uniforms, only copy these 4 vectors.  Ignore the int.  When an array of Orients need to be copied, the Orient3dSimple structure is used to store the array.
			Vector3d l; // left direction in parent space (world, model joint, etc.)
			Vector3d u; // up
			Vector3d f; // forward
			Vector3d p; // position
			// all these vectors and points lie within the world space that the orient resides in

			int normalizeCounter;

#define ORIENT3D_NORMALIZECOUNTERMAXVALUE 32
			static int NextNormalizeCounter;

			// rules:
			// l, u, and f are unit vectors (length 1.0)
			// I call these the 'flu' rules to make them easier to remember:
			// l = u x f;
			// u = f x l;
			// f = l x u;
			// so that they can represent a coordinate system within the parent space
			// circumstances where they are meant to follow different rules are up to the implementer

			Orient3d();
			Orient3d(Vector3d p_left, Vector3d p_up, Vector3d p_forward, Vector3d p_position);
			Orient3d(Vector3d p_left, Vector3d p_up, Vector3d p_forward);
			void Set(Orient3d p_orient3d);
			void Set(Vector3d p_left, Vector3d p_up, Vector3d p_forward, Vector3d p_position);
			void SetAxes(float p_lx, float p_ly, float p_lz,
				float p_ux, float p_uy, float p_uz,
				float p_fx, float p_fy, float p_fz);
			bool Equals(Orient3d &p_orient);
			void LoadIdentity();
			void LoadIdentity(Vector3d &p_position);
			// factor is the tangent value (1.0 = 45.0 degrees of rotation, -1.0 = -45.0 degree, etc.)
			void Rotate(Orient3dAxis p_direction, float p_factor);
			// rotate on an arbitiray vector axis
			void Rotate(Vector3d &p_rotationAxis, float p_degrees, bool p_axisIsUnitLength = true);
			// Interpolate between two orients, using 'time' t (0.0 to 1.0)
			static Orient3d Interpolate(Orient3d &p_beginOrient, Orient3d &p_endOrient, float p_t, OrientInterpolationData *p_data = nullptr, bool p_populateInterpolationData = false);
			// transform a point that resides in the same space that the orient resides in to the orient's space
			Vector3d TransformToOrientSpace(Vector3d &p_vertex);
			// transform a point in the orient's sapce to the space the orient resides in
			// include p
			Vector3d TransformToWorldSpace(Vector3d &p_vertex);
			// don't include p, just return the offset - used for child orient location calculation through tree parse
			Vector3d TransformToWorldSpaceOffset(Vector3d &p_vertex);
			Matrix4d ConvertToMatrix4d();
			Orient3d TransformToSameSpace(Orient3d &p_orient, float p_positionScale = 1.0f);
			Orient3d ScaleAxes(float p_scale);
			Orient3d ReflectThroughPlane(Vector3d &p_planePoint, Vector3d &p_planeNormal);
			Matrix4d MakeMatrix();
			Matrix4d MakeInverseMatrix();

			System::String ^ToString()
			{
				return "l: (" + l.ToString() + "); u: (" + u.ToString() + "); f: (" + f.ToString() + "); p: (" + p.ToString() + ")";
			}

		private:
			void InitializeNormalizationCounter();
			void CheckNormalize();
			void Normalize();
		};

		class Orient3dSimple
		{
		public:
			// simple data class used to populate shader uniforms, not meant to be used it regular game operations

			// note: this data lines up with the TransformData struct in the shaders
			Vector3d l; // left direction in parent space (world, model joint, etc.)
			Vector3d u; // up
			Vector3d f; // forward
			Vector3d p; // position

			void Set(Orient3d &p_orient)
			{
				l = p_orient.l;
				u = p_orient.u;
				f = p_orient.f;
				p = p_orient.p;
			}
		};
	}
}
