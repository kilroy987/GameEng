#pragma once

#include "LinkedListTemplate.h"
#include "Vector.h"

namespace GameEng {
	namespace Math {

		using namespace GameEng::Storage;

		class FrustumPlane
		{
		public:
			Vector3d intersectSegmentLeft; // intersection with next plane, radiating out from origin (this plane's left is the NEXT plane's right)

			Vector3d normalUnit; // faces inward, doesn't even have to be normalized

			Vector3d intersectSegmentRight; // intersection with prior plane, radiating out from origin (this plane's right is tbe PREV plane's left)

			bool calculateLeftSegment; // if left segment has to be calculated, right segment of next plane should be replaced by it

			void Initialize()
			{
				calculateLeftSegment = true;
			}
		};

		// just for a debug linked list
		class FrustumPlaneNormal
		{
		public:
			Vector3d normal;

			FrustumPlaneNormal(Vector3d &p_normal)
			{
				normal = p_normal;
			}

			FrustumPlaneNormal()
			{
				// just to support linked list
			}
		};

		class FrustumPlaneNormalAndResult
		{
		public:
			Vector3d normal;
			LinkedList<FrustumPlaneNormal> resultPlanes;

			void Initialize()
			{
				resultPlanes.Clear();
			}

			FrustumPlaneNormalAndResult(Vector3d &p_normal)
			{
				normal = p_normal;
				resultPlanes.Clear();
			}

			FrustumPlaneNormalAndResult()
			{
				// just to support linked list
			}
		};

		class FrustumPlaneNormalList : public LinkedList<FrustumPlaneNormalAndResult>
		{
		public:
			int count;

			void Initialize()
			{
				Clear();
			}

			LinkedListNode<FrustumPlaneNormalAndResult> * AddNormal(Vector3d &p_normal)
			{
				LinkedListNode<FrustumPlaneNormalAndResult> *newNode = GetNewNode();
				newNode->data.Initialize();
				newNode->data.normal = p_normal;
				AddNode(newNode);
				count++;
				return newNode;
			}

			void Clear()
			{
				LinkedList<FrustumPlaneNormalAndResult>::Clear();
				count = 0;
			}

			LinkedListEnumerator<FrustumPlaneNormalAndResult> GetEnumerator()
			{
				return LinkedListEnumerator<FrustumPlaneNormalAndResult>(*this);
			}
		};

		class Frustum {
		public:
			// defined clockwise along inner surface
			Vector3d origin; // starting point for all plains
			LinkedList<FrustumPlane> planes; // situated clockwise with planes adqjacent to each other to allow for easy analysis of where to add planes, and calculating of intersection segments.  
			// (New planes are inserted between planes they only cut the left and right segments of, respectively, etc.)
			// a plane's left segment = current plane's normal X next plane's normal, normalized.  a plane's right segment = the previous plane's left segment.

			// if empty, new planes can't be added - intersection is zero
			bool empty; 

			// planes can be added to a null set
			bool nullSet;

			// how many planes?
			int count;

		public:
#ifdef _DEBUG
			FrustumPlaneNormalList addedPlanes;
#endif

			// prepare for additions - empty the list
			void Initialize();
			Frustum();
			void Empty();
			bool IsEmpty();
			void SetOrigin(Vector3d &p_origin);
		private:
			// need these routines because float dot products aren't accurate enough to prevent 'equal' or 'opposite' planes from entering a frustum and disrupting future calculations
			bool VectorsApproximatelyEqual(Vector3d &p_vector1, Vector3d &p_vector2);
			bool VectorsApproximatelyOpposite(Vector3d &p_vector1, Vector3d &p_vector2);
		public:
			bool PlaneWillEmptyFrustum(Vector3d &p_normal, bool p_IsUnit = false);
			bool AddPlane(Vector3d &p_normal, bool p_IsUnit = false, bool p_willNotEmpty = false);
			LinkedListEnumerator<FrustumPlane> GetPlaneEnumerator(LinkedListNode<FrustumPlane> *p_startingNode = nullptr);
			void CopyTo(Frustum *p_dstFrustum);
			void ReflectThroughPlane(Vector3d &p_position, Vector3d &p_normal, Frustum *p_dstFrustum);
			bool Equals(Frustum *p_frustum);
			bool Contains(Frustum *p_frustum, float &p_failedresult);
			System::String^ WriteFrustumCreationCode();
			void Test();
		private:
			void TestDebugCode();

		}; // class
	}
}