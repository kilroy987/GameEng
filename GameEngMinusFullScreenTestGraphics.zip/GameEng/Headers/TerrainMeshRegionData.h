#pragma once

#include "Vector.h"
#include "GameColor.h"
// Kept separate so that it can successfully compile with GraphicsBase rendering a terrain

#include "GraphicsNative.h"

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;

		class TerrainMeshCell
		{
			// a cell is made up of point heights at the four corners, a normal for the lower right and a normal for the upper left.
			// remember, a cell's shape is:
			// ----- z
			// | / |
			// ----- 0
			// x   0

			// Stored as vectors to speed up rendering as a point to the vectors (but takes up more space)

			// a cell can exist at the main terrain level or at a lod level.  
			// Normals are used in the main terrain level to perform AI decisions and collision detection.
			// the regions are used for rendering.

		public:
			// important note: X/Z are the horizontal coordinates, Y is the height.
			Vector3d lowerRightVertex;
			Vector3d lowerLeftVertex;
			Vector3d upperRightVertex;
			Vector3d upperLeftVertex;

			// for collision detection
			Vector3d upperLeftNormal;
			Vector3d lowerRightNormal;
			Vector3d leftSegmentUnit;
			Vector3d diagonalSegmentUnit;
			Vector3d upperSegmentUnit;

			GameColor lowerRightColor;
			GameColor lowerLeftColor;
			GameColor upperRightColor;
			GameColor upperLeftColor;

			float minY, maxY; // only used in main mesh for collision detection, for now.

			void CalculateNormalsAndSegments();
			void CalculateBounds();

			void SetXZ(float p_lowerRightX, float p_lowerRightZ, float p_upperLeftX, float p_upperLeftZ)
			{
				lowerRightVertex.x = p_lowerRightX;
				upperRightVertex.x = p_lowerRightX;
				lowerRightVertex.z = p_lowerRightZ;
				lowerLeftVertex.z = p_lowerRightZ;
				upperLeftVertex.x = p_upperLeftX;
				lowerLeftVertex.x = p_upperLeftX;
				upperLeftVertex.z = p_upperLeftZ;
				upperRightVertex.z = p_upperLeftZ;
			}

			void SetY(float p_lowerRightY, float p_lowerLeftY, float p_upperRightY, float p_upperLeftY)
			{
				lowerRightVertex.y = p_lowerRightY;
				lowerLeftVertex.y = p_lowerLeftY;
				upperRightVertex.y = p_upperRightY;
				upperLeftVertex.y = p_upperLeftY;
			}

			void SetColor(GameColor p_lowerRightColor, GameColor p_lowerLeftColor, GameColor p_upperRightColor, GameColor p_upperLeftColor)
			{
				lowerRightColor = p_lowerRightColor;
				lowerLeftColor = p_lowerLeftColor;
				upperRightColor = p_upperRightColor;
				upperLeftColor = p_upperLeftColor;
			}
		};

		class TerrainStitchNativeObjectContainer
		{
		public:
			int stitchId;
			GraphicsNativeObjectContainer container;

			TerrainStitchNativeObjectContainer()
			{
				stitchId = -1;
			}
		};

		class TerrainStaticNativeObjectList : LinkedList<TerrainStitchNativeObjectContainer>
		{
		public:
			LinkedListNode<TerrainStitchNativeObjectContainer> * GetStitchNode(int p_stitchId)
			{
				LinkedListEnumerator<TerrainStitchNativeObjectContainer> enumerator = LinkedListEnumerator<TerrainStitchNativeObjectContainer>(*this);
				while (enumerator.MoveNext())
				{
					if (enumerator.Current()->data.stitchId == p_stitchId)
						return enumerator.Current();
				}

				return nullptr;
			}

			LinkedListNode<TerrainStitchNativeObjectContainer> * AddStitchNode(int p_stitchId)
			{
				LinkedListNode<TerrainStitchNativeObjectContainer> *newNode = GetNewNode();
				if (newNode->data.container.nativeObjectRef != nullptr)
					throw gcnew Exception("New TerrainStitchNativeObjectContainer has a non-null nativeObjectRef - it should be null - GL is not destroying the native object");
				newNode->data.stitchId = p_stitchId;
				AddNode(newNode);
				return newNode;
			}

			static int CalculateStitchId(int p_val1, int p_val2, int p_val3)
			{
				return 10000 * p_val1 + 100 * p_val2 + p_val3;
			}

			static int CalculateStitchId(int p_val1)
			{
				return p_val1;
			}
		};

		class TerrainMeshLevelOfDetail
		{
		public:
			int cellHorizontalQty;
			int cellVerticalQty;
			TerrainMeshCell *cells;

			float startX, startZ, endX, endZ; // start and end X and Z for each region as they appear in the main mesh
			int levelOfDetail; // which level of detail is this? (1 is best, down to whatever provided a 2x2 mesh)

			GraphicsNativeObjectContainer outerGridNative;
			GraphicsNativeObjectContainer innerGridNative;

			TerrainStaticNativeObjectList lowerStitchNativeObjects;
			TerrainStaticNativeObjectList upperStitchNativeObjects;
			TerrainStaticNativeObjectList leftStitchNativeObjects;
			TerrainStaticNativeObjectList rightStitchNativeObjects;
			TerrainStaticNativeObjectList lowerRightStitchNativeObjects;
			TerrainStaticNativeObjectList lowerLeftStitchNativeObjects;
			TerrainStaticNativeObjectList upperRightStitchNativeObjects;
			TerrainStaticNativeObjectList upperLeftStitchNativeObjects;

			TerrainMeshLevelOfDetail()
			{
				cellHorizontalQty = 0;
				cellVerticalQty = 0;
				cells = nullptr;
				levelOfDetail = 0;
			}

			~TerrainMeshLevelOfDetail()
			{
				Destroy();
			}

			void Destroy()
			{
				if (cells != nullptr)
				{
					delete[] cells;
					cells = nullptr;
					cellHorizontalQty = 0;
					cellVerticalQty = 0;
					levelOfDetail = 0;
				}
			}

			void Initialize(int p_cellHorizontalQty, int p_cellVerticalQty, int p_levelOfDetail);
		private:
			int lowerRightCellIndex, lowerLeftCellIndex, upperRightCellIndex, upperLeftCellIndex;
		public:
			TerrainMeshCell * LowerRightMostCell() { return &cells[lowerRightCellIndex]; }
			TerrainMeshCell * UpperRightMostCell() { return &cells[upperRightCellIndex]; }
			TerrainMeshCell * LowerLeftMostCell() { return &cells[lowerLeftCellIndex]; }
			TerrainMeshCell * UpperLeftMostCell() { return &cells[upperLeftCellIndex]; }

			// assumed at least one is set - but can all be null too
			static TerrainMeshLevelOfDetail * GetHighestTerrainLevelOfDetail(TerrainMeshLevelOfDetail *lod1, TerrainMeshLevelOfDetail *lod2, TerrainMeshLevelOfDetail *lod3)
			{
				int highestLevelOfDetail = -1;
				TerrainMeshLevelOfDetail *result = nullptr;

				if (lod1 != nullptr)
				{
					if (lod1->levelOfDetail > highestLevelOfDetail)
					{
						highestLevelOfDetail = lod1->levelOfDetail;
						result = lod1;
					}
				}
				if (lod2 != nullptr)
				{
					if (lod2->levelOfDetail > highestLevelOfDetail)
					{
						highestLevelOfDetail = lod2->levelOfDetail;
						result = lod2;
					}
				}
				if (lod3 != nullptr)
				{
					if (lod3->levelOfDetail > highestLevelOfDetail)
					{
						highestLevelOfDetail = lod3->levelOfDetail;
						result = lod3;
					}
				}

				return result;
			}
		};

		class TerrainMeshStitchMap
		{
		public:
			TerrainMeshLevelOfDetail *upperLeftLOD;
			TerrainMeshLevelOfDetail *upperLOD;
			TerrainMeshLevelOfDetail *upperRightLOD;
			TerrainMeshLevelOfDetail *leftLOD;
			TerrainMeshLevelOfDetail *thisLOD;
			TerrainMeshLevelOfDetail *rightLOD;
			TerrainMeshLevelOfDetail *lowerLeftLOD;
			TerrainMeshLevelOfDetail *lowerLOD;
			TerrainMeshLevelOfDetail *lowerRightLOD;
		};

	}
}