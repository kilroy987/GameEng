#pragma once

#include "Vector.h"
#include "GameColor.h"
#include "GameTexture.h"
#include "GraphicsNativeEnums.h"

#include <vcclr.h> // gcroot

namespace GameEng {
	namespace Graphics {
		using namespace GameEng::Math;

		using namespace GameEng::Math;

		class ModelVertex
		{
		public:
			Vector3d vertex; // position of the vertex in space
			int colorIndex; // default color to be used for this vertex any time it is rendered, unless overridden
			Vector3d normal;

			// for bumpmaps
			Vector3d bumpMapTangent;
			Vector3d bumpMapBinormal;

			ModelVertex()
			{
				colorIndex = -1;
			}

			ModelVertex(Vector3d &p_vertex, int p_colorIndex)
			{
				vertex = p_vertex;
				colorIndex = p_colorIndex;
			}

			ModelVertex(Vector3d &p_vertex, int p_colorIndex, Vector3d &p_normal)
			{
				vertex = p_vertex;
				colorIndex = p_colorIndex;
				normal = p_normal;
			}

			ModelVertex(Vector3d &p_vertex, int p_colorIndex, Vector3d &p_normal, Vector3d &p_bumpMapTangent, Vector3d &p_bumpMapBinormal)
			{
				vertex = p_vertex;
				colorIndex = p_colorIndex;
				normal = p_normal;
				bumpMapTangent = p_bumpMapTangent;
				bumpMapBinormal = p_bumpMapBinormal;
			}
		};

		// expected to be part of ModelSurfaceVertex, but can be sent separately with an array of ModelVertex too
		class ModelVertexTextureCoords
		{
		public:
			float s, t, r, q;
			// usually q = 1.0f unless rendering a trapezoidal quad that requires special handling
			// don't change r until future upgrades.  placement of floats is important for glTexCoords2fv and glTexCoords4fv

			ModelVertexTextureCoords()
			{
				s = 0.0f;
				t = 0.0f;
				q = 1.0f;

				r = 0.0f; // used for 3d texture
			}

			ModelVertexTextureCoords(float p_s, float p_t, float p_q = 1.0f, bool p_multiplyQ = true)
			{
				Set(p_s, p_t, p_q, p_multiplyQ);
			}

			void Set(float p_s, float p_t, float p_q = 1.0f, bool p_multiplyQ = true)
			{
				if (p_multiplyQ == true)
				{
					s = p_s * p_q;
					t = p_t * p_q;
				}
				else
				{
					s = p_s;
					t = p_t;
				}

				q = p_q;
				r = 0.0f;
			}
		};

		// offers unambiguous constructurs for 3d implementation of texture
		class ModelVertexTextureCoords3d : public ModelVertexTextureCoords
		{
		public:
			ModelVertexTextureCoords3d(float p_s, float p_t, float p_r, float p_q = 1.0f, bool p_multiplyQ = true)
			{
				Set(p_s, p_t, p_r, p_q, p_multiplyQ);
			}

			void Set(float p_s, float p_t, float p_r, float p_q = 1.0f, bool p_multiplyQ = true)
			{
				if (p_multiplyQ == true)
				{
					s = p_s * p_q;
					t = p_t * p_q;
					r = p_r * p_q;
				}
				else
				{
					s = p_s;
					t = p_t;
					r = p_r;
				}

				q = p_q;
			}
		};


		class ModelSurfaceVertex
		{
		public:
			int vertexIndex;
			int colorOverrideIndex;
			ModelVertexTextureCoords texCoords;

			ModelSurfaceVertex()
			{
				vertexIndex = -1;
				colorOverrideIndex = -1;
			}
		};

		class ModelSurfaceTexture
		{
		public:
			gcroot<GameTexture ^>textureRef;
			GraphicsShaderCompositionTextureBlendOption blendOption; // only used with textureRef
			GraphicsShaderCompositionTextureLightOption lightOption; // only used with textureRef

			gcroot<GameTexture ^>specularMapTextureRef;
			GraphicsShaderCompositionSpecularBlendOption specularBlendOption; // only used with specularMapTextureRef

			ModelSurfaceTexture()
			{
				textureRef = nullptr;
				specularMapTextureRef = nullptr;
				blendOption = GraphicsShaderCompositionTextureBlendOption::NoBlend;
				lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse;
				specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::Modulate;
			}

		};

		class ModelSurface
		{
		private:
			int vertexQty;
			ModelSurfaceVertex *vertexIndices;
			ModelSurfaceTexture diffuseTextures[4];
			gcroot<GameTexture ^>bumpMapTextureRef; // assumed to use same coordinates as diffuse texture - shader also makes this assumption - normal map for light illumination (diffuse and specular)
			bool useSurfaceNormalForLighting;
			Vector3d normal;
			// so that shader can make vectors out of the bumpmap texture (normal is already the blue RGB portion)
			Vector3d bumpMapTangent;
			Vector3d bumpMapBinormal;

		public:
			ModelSurface()
			{
				vertexQty = 0;
				vertexIndices = nullptr;
				bumpMapTextureRef = nullptr;
				useSurfaceNormalForLighting = false;
			}
			~ModelSurface()
			{
				if (vertexIndices != nullptr)
				{
					delete[] vertexIndices;
					vertexIndices = nullptr;
					vertexQty = 0;

					// do NOT delete!
					diffuseTextures[0].textureRef = nullptr;
					diffuseTextures[0].specularMapTextureRef = nullptr;
					diffuseTextures[1].textureRef = nullptr;
					diffuseTextures[1].specularMapTextureRef = nullptr;
					diffuseTextures[2].textureRef = nullptr;
					diffuseTextures[2].specularMapTextureRef = nullptr;
					diffuseTextures[3].textureRef = nullptr;
					diffuseTextures[3].specularMapTextureRef = nullptr;
					bumpMapTextureRef = nullptr;
				}
			}

			void Initialize(int p_vertexQty, bool p_useSurfaceNormalForLighting = false)
			{
				vertexIndices = new ModelSurfaceVertex[p_vertexQty];
				vertexQty = p_vertexQty;
				useSurfaceNormalForLighting = p_useSurfaceNormalForLighting;
			}
			void SetTexture0(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption = GraphicsShaderCompositionTextureBlendOption::NoBlend, GraphicsShaderCompositionTextureLightOption p_lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse)
			{
				diffuseTextures[0].textureRef = p_texture;
				diffuseTextures[0].blendOption = p_blendOption;
				diffuseTextures[0].lightOption = p_lightOption;
			}
			void SetSpecularMapTexture0(GameTexture ^p_specularMapTexture, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				diffuseTextures[0].specularMapTextureRef = p_specularMapTexture;
				diffuseTextures[0].specularBlendOption = p_specularBlendOption;
			}
			void SetTexture1(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption = GraphicsShaderCompositionTextureBlendOption::NoBlend, GraphicsShaderCompositionTextureLightOption p_lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse)
			{
				diffuseTextures[1].textureRef = p_texture;
				diffuseTextures[1].blendOption = p_blendOption;
				diffuseTextures[1].lightOption = p_lightOption;
			}
			void SetSpecularMapTexture1(GameTexture ^p_specularMapTexture, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				diffuseTextures[1].specularMapTextureRef = p_specularMapTexture;
				diffuseTextures[1].specularBlendOption = p_specularBlendOption;
			}
			void SetTexture2(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption = GraphicsShaderCompositionTextureBlendOption::NoBlend, GraphicsShaderCompositionTextureLightOption p_lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse)
			{
				diffuseTextures[2].textureRef = p_texture;
				diffuseTextures[2].blendOption = p_blendOption;
				diffuseTextures[2].lightOption = p_lightOption;
			}
			void SetSpecularMapTexture2(GameTexture ^p_specularMapTexture, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				diffuseTextures[2].specularMapTextureRef = p_specularMapTexture;
				diffuseTextures[2].specularBlendOption = p_specularBlendOption;
			}
			void SetTexture3(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption = GraphicsShaderCompositionTextureBlendOption::NoBlend, GraphicsShaderCompositionTextureLightOption p_lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse)
			{
				diffuseTextures[3].textureRef = p_texture;
				diffuseTextures[3].blendOption = p_blendOption;
				diffuseTextures[3].lightOption = p_lightOption;
			}
			void SetSpecularMapTexture3(GameTexture ^p_specularMapTexture, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				diffuseTextures[3].specularMapTextureRef = p_specularMapTexture;
				diffuseTextures[3].specularBlendOption = p_specularBlendOption;
			}
			void SetBumpMapTexture(GameTexture ^p_bumpMapTexture)
			{
				bumpMapTextureRef = p_bumpMapTexture;
			}
			ModelSurfaceVertex * GetSurfaceVertex(int p_index)
			{
				if (p_index < vertexQty)
					return &vertexIndices[p_index];

				throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}
			GameTexture ^ GetTexture0()
			{
				return diffuseTextures[0].textureRef;
			}
			GameTexture ^ GetSpecularMapTexture0()
			{
				return diffuseTextures[0].specularMapTextureRef;
			}
			GraphicsShaderCompositionSpecularBlendOption GetSpecularMapTexture0BlendOption()
			{
				return diffuseTextures[0].specularBlendOption;
			}
			GameTexture ^ GetTexture1()
			{
				return diffuseTextures[1].textureRef;
			}
			GameTexture ^ GetSpecularMapTexture1()
			{
				return diffuseTextures[1].specularMapTextureRef;
			}
			GraphicsShaderCompositionSpecularBlendOption GetSpecularMapTexture1BlendOption()
			{
				return diffuseTextures[1].specularBlendOption;
			}
			GameTexture ^ GetTexture2()
			{
				return diffuseTextures[2].textureRef;
			}
			GameTexture ^ GetSpecularMapTexture2()
			{
				return diffuseTextures[2].specularMapTextureRef;
			}
			GraphicsShaderCompositionSpecularBlendOption GetSpecularMapTexture2BlendOption()
			{
				return diffuseTextures[2].specularBlendOption;
			}
			GameTexture ^ GetTexture3()
			{
				return diffuseTextures[3].textureRef;
			}
			GameTexture ^ GetSpecularMapTexture3()
			{
				return diffuseTextures[3].specularMapTextureRef;
			}
			GraphicsShaderCompositionSpecularBlendOption GetSpecularMapTexture3BlendOption()
			{
				return diffuseTextures[3].specularBlendOption;
			}
			GameTexture ^ GetBumpMapTexture()
			{
				return bumpMapTextureRef;
			}
			GraphicsShaderCompositionTextureBlendOption GetTexture0BlendOption()
			{
				return diffuseTextures[0].blendOption;
			}
			GraphicsShaderCompositionTextureBlendOption GetTexture1BlendOption()
			{
				return diffuseTextures[1].blendOption;
			}
			GraphicsShaderCompositionTextureBlendOption GetTexture2BlendOption()
			{
				return diffuseTextures[2].blendOption;
			}
			GraphicsShaderCompositionTextureBlendOption GetTexture3BlendOption()
			{
				return diffuseTextures[3].blendOption;
			}
			GraphicsShaderCompositionTextureLightOption GetTexture0LightOption()
			{
				return diffuseTextures[0].lightOption;
			}
			GraphicsShaderCompositionTextureLightOption GetTexture1LightOption()
			{
				return diffuseTextures[1].lightOption;
			}
			GraphicsShaderCompositionTextureLightOption GetTexture2LightOption()
			{
				return diffuseTextures[2].lightOption;
			}
			GraphicsShaderCompositionTextureLightOption GetTexture3LightOption()
			{
				return diffuseTextures[3].lightOption;
			}
			void SetVertexIndex(int p_index, int p_vertexIndex)
			{
				if (p_index < vertexQty)
					vertexIndices[p_index].vertexIndex = p_vertexIndex;
				else
					throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}
			void SetVertexColorOverrideIndex(int p_index, int p_colorIndex)
			{
				if (p_index < vertexQty)
					vertexIndices[p_index].colorOverrideIndex = p_colorIndex;
				else
					throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}
			void SetVertexTexCoords(int p_index, float p_s, float p_t, float p_q = 1.0f, bool p_qMultiply = true)
			{
				if (p_index < vertexQty)
				{
					if (p_qMultiply == true)
					{
						vertexIndices[p_index].texCoords.s = p_s * p_q;
						vertexIndices[p_index].texCoords.t = p_t * p_q;
					}
					else
					{
						vertexIndices[p_index].texCoords.s = p_s;
						vertexIndices[p_index].texCoords.t = p_t;

					}
					if (p_q <= 0.0f)
						throw gcnew Exception("Q MUST be > 0!");

					vertexIndices[p_index].texCoords.q = p_q;
				}
				else
					throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}
			ModelVertexTextureCoords & GetVertexTexCoords(int p_index)
			{
				if (p_index < vertexQty)
				{
					return vertexIndices[p_index].texCoords;
				}
				else
					throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}

			int GetVertexQty()
			{
				return vertexQty;
			}

			bool UseSurfaceNormalForLighting()
			{
				return useSurfaceNormalForLighting;
			}

			Vector3d & GetNormal()
			{
				return normal;
			}

			Vector3d & GetBumpMapTangent()
			{
				return bumpMapTangent;
			}
			Vector3d & GetBumpMapBinormal()
			{
				return bumpMapBinormal;
			}

			// call after texcoords are established so that tangent and binormal can be calculated
			void CalculateNormals(ModelVertex *p_vertices)
			{
				if (vertexQty >= 3)
				{
					int index1 = 1;
					bool normalValid = false;
					while (normalValid == false)
					{
						if (index1 > vertexQty - 2)
							throw gcnew System::Exception("Unable to find suitable vertices for calculation of surface normal");
						Vector3d crossprod = (p_vertices[vertexIndices[index1+1].vertexIndex].vertex - p_vertices[vertexIndices[index1].vertexIndex].vertex).CrossProd(p_vertices[vertexIndices[index1].vertexIndex].vertex - p_vertices[vertexIndices[0].vertexIndex].vertex);
						if (crossprod.Normalize() == true)
						{
							normal = crossprod;
							normalValid = true;
						}
						else
							index1++;
					}

					// calculate bumpmap tangent and binormal just in case there is a bumpmap - not much waste here
					// we need texture coordinates to make this part work
					if (static_cast<GameTexture^>(diffuseTextures[0].textureRef) != nullptr)
					{
						// assuming textures are consider 'upright' with 0,0 at the upper left...
						// the concept behind this messy code is simple:
						// - take 3 non linear points in the polygon
						// - given their S and T coordinates, extend them both to a safe target S or T (less than both end point S and T) and also determine the resulting T or S (don't use vector offsets that are 0 for S or T respectively)
						// - comparing the resulting T or S, subtract one resulting point from the other and normalize
						// - this gets you both the binormal and the tangent.

						Vector3d v0, v1, v2;
						Vector3d vOffset0, vOffset1, vOffset2;
						float s0, s1, s2;
						float t0, t1, t2;
						float sOffset0, sOffset1, sOffset2;
						float tOffset0, tOffset1, tOffset2;
						int v2Index;

						// find 3 points not on the same line
						bool valid = false;
						for (int i = 0; i < vertexQty; i++)
						{
							if (i == 0)
							{
								v0 = p_vertices[vertexIndices[i].vertexIndex].vertex;
							}
							else if (i == 1)
							{
								v1 = p_vertices[vertexIndices[i].vertexIndex].vertex;
							}
							else
							{
								if ((v1 - v0).CrossProd(p_vertices[vertexIndices[i].vertexIndex].vertex - v0).Magnitude() > 0.00001f)
								{
									v2 = p_vertices[vertexIndices[i].vertexIndex].vertex;
									v2Index = i;
									valid = true;
									break;
								}
							}
						}
						if (valid == false)
							throw gcnew Exception("Unable to find two vectors on polygon that are not coincident");
						vOffset0 = v1 - v0;
						vOffset1 = v2 - v1;
						vOffset2 = v2 - v0;
						s0 = vertexIndices[0].texCoords.s;
						s1 = vertexIndices[1].texCoords.s;
						s2 = vertexIndices[0].texCoords.s;
						t0 = vertexIndices[0].texCoords.t;
						t1 = vertexIndices[1].texCoords.t;
						t2 = vertexIndices[0].texCoords.t;
						sOffset0 = vertexIndices[1].texCoords.s - vertexIndices[0].texCoords.s;
						sOffset1 = vertexIndices[v2Index].texCoords.s - vertexIndices[1].texCoords.s;
						sOffset2 = vertexIndices[v2Index].texCoords.s - vertexIndices[0].texCoords.s;
						tOffset0 = vertexIndices[1].texCoords.t - vertexIndices[0].texCoords.t;
						tOffset1 = vertexIndices[v2Index].texCoords.t - vertexIndices[1].texCoords.t;
						tOffset2 = vertexIndices[v2Index].texCoords.t - vertexIndices[0].texCoords.t;

						Vector3d *offset0 = nullptr;
						Vector3d *offset1 = nullptr;
						float *sStart0, *sStart1;
						float *tStart0, *tStart1;
						float *so0 = nullptr;
						float *so1 = nullptr;
						float *to0 = nullptr;
						float *to1 = nullptr;
						Vector3d *vStart0, *vStart1;
						float time0, time1;
						float targetS, targetT;
						Vector3d p0, p1;
						float resultS0, resultS1;
						float resultT0, resultT1;

						// find binormal
						if (sOffset0 != 0.0f)
						{
							vStart0 = &v0;
							offset0 = &vOffset0;
							so0 = &sOffset0;
							sStart0 = &s0;
							to0 = &tOffset0;
							tStart0 = &t0;

							if (sOffset1 != 0.0f)
							{
								vStart1 = &v1;
								offset1 = &vOffset1;
								so1 = &sOffset1;
								sStart1 = &s1;
								to1 = &tOffset1;
								tStart1 = &t1;
							}
							else if (sOffset2 != 0.0f)
							{
								vStart1 = &v0;
								offset1 = &vOffset2;
								so1 = &sOffset2;
								sStart1 = &s2;
								to1 = &tOffset2;
								tStart1 = &t2;
							}
							else
							{
								throw gcnew System::Exception("Cannot solve for any S - texture coordinates are too linear");
							}
						}
						else if (sOffset1 != 0.0f)
						{
							vStart0 = &v1;
							offset0 = &vOffset1;
							so0 = &sOffset1;
							sStart0 = &s1;
							to0 = &tOffset1;
							tStart0 = &t1;

							if (sOffset2 != 0.0f)
							{
								vStart1 = &v0;
								offset1 = &vOffset2;
								so1 = &sOffset2;
								sStart1 = &s2;
								to1 = &tOffset2;
								tStart1 = &t2;
							}
							else
							{
								throw gcnew System::Exception("Cannot solve for any S - texture coordinates are too linear");
							}
						}
						else
						{
							throw gcnew System::Exception("Cannot solve for any S - texture coordinates are too linear");
						}

						// choose a target that isn't on either endpoint
						if (*sStart0 < *sStart1)
							targetS = *sStart0 - 10.0f;
						else
							targetS = *sStart1 - 10.0f;
						time0 = (targetS - *sStart0) / (*so0);
						time1 = (targetS - *sStart1) / (*so1);
						resultT0 = *tStart0 + *to0 * time0;
						resultT1 = *tStart1 + *to1 * time1;
						p0 = *vStart0 + (*offset0).ScalarMult(time0);
						p1 = *vStart1 + (*offset1).ScalarMult(time1);
						// calculate it
						if (resultT0 > resultT1) // green positive up
							bumpMapBinormal = p1 - p0;
						else
							bumpMapBinormal = p0 - p1;
						// clean it up and normalize it
						bumpMapBinormal = bumpMapBinormal - normal.ScalarMult(bumpMapBinormal * normal);
						bumpMapBinormal.Normalize();

						// find tangent
						if (tOffset0 != 0.0f)
						{
							vStart0 = &v0;
							offset0 = &vOffset0;
							so0 = &sOffset0;
							sStart0 = &s0;
							to0 = &tOffset0;
							tStart0 = &t0;

							if (tOffset1 != 0.0f)
							{
								vStart1 = &v1;
								offset1 = &vOffset1;
								so1 = &sOffset1;
								sStart1 = &s1;
								to1 = &tOffset1;
								tStart1 = &t1;
							}
							else if (tOffset2 != 0.0f)
							{
								vStart1 = &v0;
								offset1 = &vOffset2;
								so1 = &sOffset2;
								sStart1 = &s2;
								to1 = &tOffset2;
								tStart1 = &t2;
							}
							else
							{
								throw gcnew System::Exception("Cannot solve for any S - texture coordinates are too linear");
							}
						}
						else if (tOffset1 != 0.0f)
						{
							vStart0 = &v1;
							offset0 = &vOffset1;
							so0 = &sOffset1;
							sStart0 = &s1;
							to0 = &tOffset1;
							tStart0 = &t1;

							if (tOffset2 != 0.0f)
							{
								vStart1 = &v0;
								offset1 = &vOffset2;
								so1 = &sOffset2;
								sStart1 = &s2;
								to1 = &tOffset2;
								tStart1 = &t2;
							}
							else
							{
								throw gcnew System::Exception("Cannot solve for any S - texture coordinates are too linear");
							}
						}
						else
						{
							throw gcnew System::Exception("Cannot solve for any S - texture coordinates are too linear");
						}

						// choose a target that isn't on either endpoint
						if (*tStart0 < *tStart1)
							targetT = *tStart0 - 10.0f;
						else
							targetT = *tStart1 - 10.0f;
						time0 = (targetT - *tStart0) / (*to0);
						time1 = (targetT - *tStart1) / (*to1);
						resultS0 = *sStart0 + *so0 * time0;
						resultS1 = *sStart1 + *so1 * time1;
						p0 = *vStart0 + (*offset0).ScalarMult(time0);
						p1 = *vStart1 + (*offset1).ScalarMult(time1);
						// calculate it
						if (resultS0 < resultS1) // red positive to the left
							bumpMapTangent = p1 - p0;
						else
							bumpMapTangent = p0 - p1;
						// clean it up and normalize it
						bumpMapTangent = bumpMapTangent - normal.ScalarMult(bumpMapTangent * normal);
						bumpMapTangent.Normalize();
					}
				}
			}
		};
	}
}