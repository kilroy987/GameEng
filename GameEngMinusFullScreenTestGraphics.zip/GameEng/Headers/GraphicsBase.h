#pragma once

#include <Windows.h> // HWND, CopyMemory

// important note - if GraphicsBase needs an object within any of its argument lists, that object class cannot reference GraphicsBase.  This is why
//   ModelSurface is separate from Model - GraphicsBase renders a set of ModelSurfaces, not the Model.
#include "GameColor.h"
#include "Orient.h"
#include "Matrix.h"
#include "Frustum.h"
#include "Particle.h"

#include "LinkedListTemplate.h"
#include "GraphicsNative.h"

// classes graphics is prepared to render (generally sub-objects of the main container to prevent circular dependency errors during compile)
#include "ModelSurface.h" // model
#include "TerrainMeshRegionData.h" // terrain Region
#include "StarfieldPoint.h" // starfield
#include "GameFont.h" // fonts
#include "GameTexture.h" // textures
#include "JointedModelNative.h"

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;
		using namespace GameEng::Storage;

		enum GraphicsTypeEnum
		{
			None,
			GDI,
			OpenGL,
			DirectX
		};

		enum GraphicsBlendFuncEnum
		{
			Source_Alpha,
			One_Minus_Source_Alpha,
			One
		};

		enum GraphicsDepthFuncEnum
		{
			LessThan,
			LessThanEqual,
			GreaterThan,
			Never
		};

		enum GraphicsStencilTestFuncEnum
		{
			Always,
			Equal,
			LessEqual
		};

		enum GraphicsStencilOperationEnum
		{
			Keep,	// do not modify stored stencil
			Replace, // replace stored stencil with value specified in StencilFunc
			Increment, // increment to the next higher value
			Decrement // decrement to the next lower value
		};

		class GraphicsShaderClipPlaneRegistry
		{
		public:

#define MAX_CLIP_PLANES 6
			float clipPlanes[4 * MAX_CLIP_PLANES]; // 4 floats per plane for easy upload to API
			bool clipPlaneEnabled[MAX_CLIP_PLANES];
			int uploadQty; // id of highest clip plane that is enabled (will upload plane 0-n to API)

			GraphicsShaderClipPlaneRegistry()
			{
				DisableAllClipPlanes();
			}

			void DisableAllClipPlanes()
			{
				for (int i = 0; i < MAX_CLIP_PLANES; i++)
					clipPlaneEnabled[i] = false;
				uploadQty = 0;
			}

			void SetClipPlane(int p_planeId, Vector3d &p_position, Vector3d &p_normal)
			{
				clipPlaneEnabled[p_planeId] = true;
				EvaluateUploadQty();

				float *clipPlane = &(clipPlanes[p_planeId * 4]);
				*clipPlane = p_normal.x;
				*(clipPlane + 1) = p_normal.y;
				*(clipPlane + 2) = p_normal.z;
				*(clipPlane + 3) = -(p_position * p_normal);
			}

			void DisableClipPlane(int p_planeId)
			{
				clipPlaneEnabled[p_planeId] = false;
				EvaluateUploadQty();
			}

			void EvaluateUploadQty()
			{
				for (uploadQty = MAX_CLIP_PLANES; uploadQty > 0; uploadQty--)
					if (clipPlaneEnabled[uploadQty - 1] == false)
						break;
			}
		};

		enum class StereoscopicCameraMode
		{
			SharedScreenSpace, // convergence point and eye separation distance used
			SplitScreen // division amount between screens (rest is used equally for each eye scene render), position of vanishing point in left scene in xy (transposed for right), and eye separation used
		};

		class StereoscopicCamera
		{
		public:

			StereoscopicCamera(float p_convergenceDistance, float p_eyeSeparationLength)
			{
				Set(p_convergenceDistance, p_eyeSeparationLength);
			}

			StereoscopicCamera(float p_divisionWidth, float p_leftVanishingPointX, float p_leftVanishingPointY, float p_eyeSeparationLength)
			{
				Set(p_divisionWidth, p_leftVanishingPointX, p_leftVanishingPointY, p_eyeSeparationLength);
			}

			StereoscopicCameraMode mode;

			float eyeSeparationLength; // greater distance pronounces the 3d effect in front of and behind the convergence plane, which stays fixed as eye separation changes
			float screenWidthPercentage; // default 1.0, use whole width and height.  otherwise use center percentage (for calibration with wider smartphones that only partially use the viewport)
			// The end result is that surfaces at the convergence distance will focus at the same depth of vision as the mouse pointer (that is, the monitor screen - the physical eyes converge on the object at the screen surface), 
			//   and eye separation determines how pronounced the 3d effect is in front of and behind the convergence depth
			// note: convergence / eyeSeparation - the smaller this is, the deeper the scene appears to be
			// note: the larger convergence is, the farther that objects will pop out at the user, and the smaller they will appear
			// a too deep scene causes far away object to be hard to perceive.  A too high convergence with large eye separation makes close objects painful to view (the user must crosss their eyes)
			// ratio of 10 is a fair balance
			// ratio of 6.666 provides nicely enhanced depth for deep scene effects
			// ratio of 5 is too extreme
			// these are on a 16:9 22" monitor 2 feet away with eyes 3" apart.
			// for larger monitors or eyes closer together, use a larger ratio.  eyes closer together or a larger monitor will get more perceived depth out of a scene.  eyes too close or a monitor too large will require a larger ratio to perceive deep objects comfortably.
			// objects rendered at the convergence plane do not suffer a much noticable ghosting and can easily be the focus of play that scrolls

			// shared screen space
			float convergenceDistance; // determines world rendered distance that appears even with the screen.  Anything rendered with less depth will poke out of the screen, anything greater will appear receded

			// split screen
			float divisionWidth; // 0.0-1.0, amount of screen width taken up by the division, the rest is used equally of the full logical viewport for rendering
			float leftVanishingPointX; // for left sceen only.  -1.0-1.0.  0.0 is centered.  -1.0 and 1.0 are the left and right edges.  Transposed for the right eye scene.
			float leftVanishingPointY;

			void Set(float p_convergenceDistance, float p_eyeSeparationLength)
			{
				mode = StereoscopicCameraMode::SharedScreenSpace;
				convergenceDistance = p_convergenceDistance;
				eyeSeparationLength = p_eyeSeparationLength;
			}

			void Set(float p_divisionWidth, float p_leftVanishingPointX, float p_leftVanishingPointY, float p_eyeSeparationLength, float p_screenWidthPercentage = 1.0f)
			{
				mode = StereoscopicCameraMode::SplitScreen;
				divisionWidth = p_divisionWidth;
				leftVanishingPointX = p_leftVanishingPointX;
				leftVanishingPointY = p_leftVanishingPointY;
				eyeSeparationLength = p_eyeSeparationLength;
				screenWidthPercentage = p_screenWidthPercentage;
			}

			// use these ONLY for calculating where the eye is in space for purposes of shader-rendered reflected lighting effects (specular)
			// any calculations for placing lens flares because of lights should still use the default camera without eye correction, since the projection will handle placing those obejcts in anaglyph
			// The reason these work is: imagine a surface half the convergence distance away from the viewpoint, with a light right at the viewpoint.  For the correct effect, the light has to reflect off that surface and hit each eye, 
			//    with the resulting rendered specular effect appearing exactly the convergence distance away (that is, the mouse pointer will be in focus when the specular effect is in focus).  Algebra says this is the correct offset
			//    to get that effect.  The resulting vector offsets from each eye to the reflected position on the surface in the world space converge at the convergence distance in the world, resulting in
			//    the effect being focused exactly on the monitor screen.  Because it works in this case, correcting the eyes by that amount works for all other cases.
			Vector3d CorrectedEyePositionLeft(Orient3d &p_viewpointOrient)
			{
				return p_viewpointOrient.p + p_viewpointOrient.l.ScalarMult(eyeSeparationLength / 2.0f);
			}

			Vector3d CorrectedEyePositionRight(Orient3d &p_viewpointOrient)
			{
				return p_viewpointOrient.p - p_viewpointOrient.l.ScalarMult(eyeSeparationLength / 2.0f);
			}
		};

		class FrustumData
		{
		public:
			float left, right, top, bottom, nearPlane, farPlane;
		};

		// guides dynamic creation of shaders.  Set using SetShaderAppSettings, which wipes out any existing shaders and forces them to be rebuilt
		class GraphicsShaderAppSettings
		{
		public:
			// bias used to offset shadow acne (problem when shadow maps prepped from any front faces)
			bool useShadowDepthBias;
			float flatLowShadowMapMinBias;
			float flatLowShadowMapMaxBias;
			float cubeLowShadowMapMinBias;
			float cubeLowShadowMapMaxBias;

			float flatHighShadowMapMinBias;
			float flatHighShadowMapMaxBias;
			float cubeHighShadowMapMinBias;
			float cubeHighShadowMapMaxBias;

			// shadows appear smoother
			float flatShadowMapPcfDepth; // multiple of 0.5
			float cubeShadowMapPcfOffset; // cube - offset between iterations
			int cubeShadowMapPcfDepth; // cube - number of iterations on an axis

			// logic rearranging
			// in all cases this is faster, so later, take this out and remove code that handles the false condition in the shader generation code
			bool escalateLightAspectCheck; // if light is known to be behind the normal being used to illuminate a fragment, don't even check spotlight, shadowmap or specular values (extra if statement in shader)

			// when highest component of resulting light is <= minimumLightResult, light is nullified (after all lights accumulated)
			// when result is <= maxLightInterpolation result, value is interpolated to zero. (light is multiplied by factor 1.0 to 0.0)
			// if minumumLightResult is 0.0, this methodology is skipped (faster lighting but very distance surfaces show hint of light and specular)
			float minimumLightResult;
			float maximumLightInterpolationResult;

			GraphicsShaderAppSettings()
			{
				useShadowDepthBias = false;

				// reduce gaps on geometry whose back faces were used to generate shadows (descreases gaps, but increases acne on tight edges on faces that are lit)
				flatLowShadowMapMinBias = 0.0f;
				flatLowShadowMapMaxBias = 0.0f;
				cubeLowShadowMapMinBias = 0.0f;
				cubeLowShadowMapMaxBias = 0.0f;

				// prevent shadow acne on geometry whose front faces were used to generate shadows (increases gaps but reduces acne)
				flatHighShadowMapMinBias = 0.00005f;
				flatHighShadowMapMaxBias = 0.0005f;
				cubeHighShadowMapMinBias = 0.003f;
				cubeHighShadowMapMaxBias = 0.1f;

				flatShadowMapPcfDepth = 0.5f;
				cubeShadowMapPcfOffset = 0.005f;
				cubeShadowMapPcfDepth = 2;

				// this combats shadow acne alone a long surface at a large angle against a light source at a distance
				minimumLightResult = 0.04f; // about 100 feet in a 10 ft/1.0 world with 0.25 attentuation
				maximumLightInterpolationResult = 0.052f; // about 85 feet in a 10 ft/1.0 world with 0.25 attentuation

				escalateLightAspectCheck = true; // much faster with surface redraw (when a surface drawn is being drawn over other already rendered fragments, back to front), slightly faster in other cases
			}
		};

		class GraphicsBase
		{
		protected:

			// Shader app settings
			GraphicsShaderAppSettings shaderAppSettings;

			// Frustum of main viewport
			FrustumData frustumData;

			// clip planes shader data
			GraphicsShaderClipPlaneRegistry clipPlaneRegistry;

			LinkedList<GraphicsNativeObjectContainerPtr> nativeObjects;
			LinkedList<GraphicsNativeParticlesContainerPtr> nativeParticles;
			LinkedList<GraphicsParticleQueuePtr> particleQueues;
			LinkedList<GraphicsPolygonQueuePtr> polygonQueues;
			LinkedList<GraphicsFrameBufferContainerPtr> frameBuffers;
			GraphicsNativeProgramContainerList nativePrograms; // polygon shaders
			GraphicsNativeProgramContainerList nativeParticlePrograms; // particle shaders, to keep them separate
			GraphicsNativeProgramContainerList nativePolygonQueuePrograms; // polygon queue shaders, to keep them separate
			GraphicsNativeProgramContainerList nativePostProcessPrograms; // postprocess shaders, to keep them separate
			GraphicsLoadedTexturesList loadedTextures; // does NOT handle fonts.  only polygon textures (registered and created during runtime (also, not framebuffer textures))

			// quick access to shadow map programs (no need to destroy these)
			LinkedListNode<GraphicsNativeProgramContainer> *renderToShadowMapSingleMVPProgramNode;
			LinkedListNode<GraphicsNativeProgramContainer> *renderToShadowMapMultipleMVPProgramNode;
			LinkedListNode<GraphicsNativeProgramContainer> *renderShadowMapProgramNode;
			LinkedListNode<GraphicsNativeProgramContainer> *renderCubeShadowMapFaceProgramNode;
			LinkedListNode<GraphicsNativeProgramContainer> *renderToCubeShadowMapMultipleMVPProgramNode;
			LinkedListNode<GraphicsNativeProgramContainer> *renderToCubeShadowMapSingleMVPProgramNode;
			GraphicsNativeObjectContainer *shadowMapTextureQuadNativeObject; // quad to render shadow map
			GraphicsNativeObjectContainer *cubeShadowMapFaceTextureQuadNativeObject; // quad to render cube shadow map face

			GraphicsFrameBufferColorFormatEnum drawBufferFormats[MAX_FRAMEBUFFER_ATTACHMENT_QTY + 1]; // primary plus attachments
			int drawBufferFormatQty; // how many are defined?

			int compositionShaderQty;

		public:
			GraphicsBase()
			{
				compositionShaderQty = 0;

				// default color buffer drawing
				drawBufferFormats[0] = GraphicsFrameBufferColorFormatEnum::RGB;
				drawBufferFormatQty = 1;
			}

			virtual ~GraphicsBase()  // without this, derived class destructor won't get called
			{
				Destroy();
			}
			virtual void Initialize(System::Windows::Forms::PictureBox ^p_pictureBoxRef, HWND p_hWnd, int p_viewportWidth, int p_viewportHeight) {}
			virtual void Destroy() {}

			virtual System::String^ GetAPIVersion(int &p_major, int &p_minor, int &p_release) { p_major = 0; p_minor = 0; p_release = 0; return "0.0.0 Base class (no functionality) - override with a derived renderer, like OpenGLGraphics"; }

			// rendering begin
			virtual void MakeCurrent() {}
			virtual void SetViewportSize(int p_width, int p_height) {}
			virtual void ClearScreen(GameColor &p_color) {}
			virtual void ClearBuffer(int p_bufferIndex, Vector4d &p_values) {}

			// setting draw buffers
			virtual void SetDrawBuffers(int *p_bufferIndices, int p_bufferIndexQty) {}

			// Other rendering setup
			virtual void ClearDepth() {}
			virtual void ColorMask(bool p_red, bool p_green, bool p_blue, bool p_alpha) {}

			// stencil
			virtual void SetStencilEnabled(bool p_enable) {}
			virtual void ClearStencil() {}
			virtual void StencilTest(GraphicsStencilTestFuncEnum p_stencilTest, int p_value, unsigned char p_mask) {}
			virtual void StencilMask(unsigned char p_mask) {}
			virtual void StencilOperations(GraphicsStencilOperationEnum p_onStencilPass, GraphicsStencilOperationEnum p_onStencilPassAndDepthFail, GraphicsStencilOperationEnum p_onStencilPassAndDepthPass) {}

			// projection
			virtual void SetPerspectiveProjection(float p_yAngleDegrees, double p_near, double p_far) {}
			virtual void SetPerspectiveProjectionStereoscopicLeft(float p_yAngleDegrees, double p_near, double p_far, StereoscopicCamera &p_camera) {}
			virtual void SetPerspectiveProjectionStereoscopicRight(float p_yAngleDegrees, double p_near, double p_far, StereoscopicCamera &p_camera) {}
			virtual void SetOrthoProjection(double p_near, double p_far) {}
			// get screen ready for flat 2d rendering (text, sprite graphics, etc.) on the next command
			virtual void Set2dWindowProjection(float p_minZ = -1.0f, float p_maxZ = 1.0f) {}

			virtual Vector3d ConvertViewportCoordinatesToWorldVector(int p_x, int p_y) { return Vector3d(0, 0, 0); }

			// matrix data
			virtual Matrix4d GetMVPMatrix() { return Matrix4d(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);  }

			// transformation
			virtual void DefaultTransform() {}
			virtual void DefaultTransformStereoscopicLeft(StereoscopicCamera &p_camera) {}
			virtual void DefaultTransformStereoscopicRight(StereoscopicCamera &p_camera) {}
			virtual void Rotate(float p_angle, Vector3d &p_vector) {}
			virtual void Translate(float p_x, float p_y, float p_z) {}
			virtual void Translate(Vector3d &p_offset) {}
			virtual void Transform(Orient3d &p_orient) {}
			virtual void ReverseTransform(Orient3d &p_orient) {}
			virtual void Scale(float p_x, float p_y, float p_z) {}

			// matrix
			virtual void PushMatrix() {}
			virtual void PopMatrix() {}

			// state management
			virtual void SetDepthWriteEnabled(bool p_enabled) {}
			virtual void SetDepthTestEnabled(bool p_enabled) {}
			virtual void SetDepthFunc(GraphicsDepthFuncEnum p_depthFunc) {}
			virtual void SetDepthRange(float p_minZ, float p_maxZ) {}
			virtual void SetBlendFunc(GraphicsBlendFuncEnum p_srcFunc, GraphicsBlendFuncEnum p_dstFunc) {}
			virtual void SetPolygonFill(bool p_fill) {}

			// if called when modelview is transformed to the world for rendering (camera position), use world positions and vectors.  Transform appropriately.
			// i.e. the position and normal provided are transformed to the inverse of the current modelview for storage in the API state.
			virtual void SetClipPlane(int p_clipPlaneId, Vector3d &p_position, Vector3d &p_renderSpaceNormal, bool p_prepareForShader = true) {}
			virtual void DisableClipPlane(int p_clipPlaneId, bool p_prepareforShader = true) {}
			virtual void SetZBias(float p_factor, float p_units) {}
			virtual void DisableZBias() {}
			virtual void FlipCullFace() {}

			virtual void LoadTexture(GameTexture ^p_texture) {}

			// rendering
			virtual void RenderTestTriangle() {}
			virtual void RenderSurfaces(GameColor *p_colors, int p_colorQty, ModelSurface *p_surfaces, int p_surfaceQty, ModelVertex *p_vertices, int p_vertexQty) {}
			virtual void RenderTerrainRegion(TerrainMeshLevelOfDetail &p_region, TerrainMeshStitchMap &p_stitchMap, gcroot<GameTexture ^> *p_textures = nullptr, float p_XZPerWrap = 0.0f) {}
			// note: you should initially transform to the identity orientation at the camera's position to render points only, but internally it will re-transform again when lines needs to be drawn
			virtual void RenderStarfieldPoints(StarfieldPoint *p_stars, int p_starQty, Orient3d &p_currentOrient, Orient3d *p_priorOrient = nullptr) {}
			virtual void RenderLineStrip(float p_lineWidth, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, bool p_alphaBlend = false) {}
			virtual void RenderFilledQuad(GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, bool p_alphaBlend = false, GameTexture ^p_texture = nullptr, ModelVertexTextureCoords *p_texCoords = nullptr, int p_texCoordsQty = 0, float p_startS = 0.0f, float p_startT = 0.0f, float p_scaleS = 1.0f, float p_scaleT = 1.0f, float p_trapezoidTopSize = 1.0f, float p_trapezoidBottomSize = 1.0f) {}

			// buffer finish and swap, vsync state
			virtual void FinishRender() {}
			virtual void SwapBuffers() {}
			virtual void SetVSyncEnabled(bool p_enabled) {}
			virtual bool VSyncIsEnabled() { return false; }

			// resource handling
			virtual void ClearFontRendererResources(void *) {} // delete what this pointer is pointing to after casting to the type to delete
			virtual void ClearTextureRendererResources(void *) {} // delete what this pointer is pointing to after casting to the type to delete
			virtual void ClearNativeObjectResources(void *) {} // clear a created native object
			virtual void ClearNativeParticlesResources(void *) {} // clear a created native particles object
			virtual void ClearNativePolygonQueueResources(void *) {} // clear a create polygon queue
			virtual void ClearFrameBufferResources(void *) {} // clear a created frame buffer

			// shader routines
			int GetCompositionShaderQty()
			{
				return compositionShaderQty;
			}
			virtual void InitializeShaders(int p_vertexShaderQty, int p_fragmentShaderQty) {} // not used
			virtual void RenderQuadShader(GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, GraphicsShaderOptions %p_shaderOptions) {}
			// pointer created will be tracked so that the graphics class can destroy the object when the graphics API is destroyed
			virtual void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, gcroot<GameTexture^> *p_textures, int p_textureQty, ModelVertexTextureCoords *p_texCoords, int p_texCoordsQty, ModelVertexTextureCoords *p_texCoordsBlendMap = nullptr, int p_texCoordsBlendMapQty = 0, Vector3d *p_vertexNormals = nullptr, int p_vertexNormalQty = 0, Vector3d *p_vertexTangents = nullptr, Vector3d *p_vertexBinormals = nullptr, gcroot<GameTexture^> p_bumpMapTexture = nullptr) {}
			virtual void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, ModelSurface *p_surfaces, int p_surfaceQty, bool p_lightingNormals = false) {}
			virtual void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, JointedModelNativeData *p_jointedModelNativeData, int p_jointedModelQty, bool p_lightingNormals = false) {}
			virtual void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, TerrainMeshLevelOfDetail &p_region, cli::array<GameTexture^, 1> ^p_textures, float p_XZPerWrap, int p_startH, int p_endH, int p_startV, int p_endV) {}
			virtual void CreateNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsVertexPool &p_vertexPool, gcroot<GameTexture^> *p_textures) {}
			virtual void RenderNativeObject(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsShaderOptions %p_renderOptions) {}
			// render specifically to a framebuffer target that is a shadow map - uses only mvps, vertices and joint mvps
			virtual void RenderNativeObjectToShadowMap(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsShaderOptions %p_renderOptions) {}
			virtual void RenderNativeObjectToCubeShadowMap(GraphicsNativeObjectContainer *p_nativeObjectPtr, GraphicsShaderOptions %p_renderOptions) {}
			// render a shadowmap texture to a quad for debugging - uses only the shadowmap texture, mvp and quad vertices, reuses native data by uploading quad vertices before render
			virtual void RenderShadowMap(Vector3d *p_vertices, GraphicsShaderOptions %p_renderOptions) {}
			virtual void RenderCubeShadowMapFace(Vector3d *p_vertices, ModelVertexTextureCoords3d *p_texCoords, GraphicsShaderOptions %p_renderOptions) {}
			virtual void ClearShaderPrograms() {}
			void SetShaderAppSettings(GraphicsShaderAppSettings &p_appSettings)
			{
				shaderAppSettings = p_appSettings;
				ClearShaderPrograms();
			}

			// particles
			void RenderParticles(float p_elapsedTimeMSf, Orient3d &p_viewpoint, ParticleArray &p_particleArray)
			{
				p_particleArray.PrepareParticlesForRendering(p_elapsedTimeMSf, p_viewpoint.p, p_viewpoint.f);

				SetDepthWriteEnabled(false);

				// set up render as a billboard (using a quad that faces the origin along the space's z axis)
				PushMatrix();
				DefaultTransform();

				// it is assumed that a single particle array is always made up of the same texture and blend aspects.  However each particle can have its own rotation, position and alpha
				// render the particles
				GameColor particleColor;
				ModelVertex particleVertices[4] = { ModelVertex(Vector3d(1, 1, 0), 0), ModelVertex(Vector3d(-1, 1, 0), 0), ModelVertex(Vector3d(-1, -1, 0), 0), ModelVertex(Vector3d(1, -1, 0), 0) };
				ModelVertexTextureCoords particleTexCoords[4] = { ModelVertexTextureCoords(0.0f, 0.0f), ModelVertexTextureCoords(1.0f, 0.0f), ModelVertexTextureCoords(1.0f, 1.0f), ModelVertexTextureCoords(0.0f, 1.0f) };

				Particle *particle = &p_particleArray.particles[0];
				for (int i = 0; i < p_particleArray.deadParticleIndex; i++)
				{
					// render it!
					if (particle->zDepth > 0.0f)
					{
						PushMatrix();
						Translate(particle->CalculateRenderOffset(p_viewpoint));
						if (particle->radius != 1.0f)
							Scale(particle->radius, particle->radius, particle->radius);
						if (particle->rotationAngleDegrees != 0.0f)
							Rotate(particle->rotationAngleDegrees, Vector3d(0, 0, 1));
						// color
						particleColor = particle->color;
						particleColor.alpha = int(255.0f * particle->alpha);
						// render it as a quad facing the viewpoint
						RenderFilledQuad(&particleColor, 1, particleVertices, 4, true, p_particleArray.textures[particle->textureIndex], particleTexCoords, 4);
						PopMatrix();
					}
					else
					{
						// if additive, we aren't sorting them, so we can't depend on zDepth to be <=0 to stop
						// but for sorted ones, we can...
						break;
						// todo:
					}

					particle++;
				}

				// restore original render volume
				PopMatrix();

				SetDepthWriteEnabled(true);
			}
			virtual void CreateNativeParticles(GraphicsNativeParticlesContainer *p_nativeObjectPtr, ParticleArray *p_particles) {}
			virtual void RenderNativeParticles(GraphicsNativeParticlesContainer *p_nativeObjectPtr, GraphicsShaderParticlesOptions %p_renderOptions, ParticleArray *p_particleArray) {}
			// particle queue
			virtual void CreateParticleQueue(GraphicsParticleQueue *p_particleQueue, int p_particleQty) {}
			virtual void SubmitParticlesToQueue(GraphicsParticleQueue *p_particleQueue, LinkedList<Particle> &p_particles, GraphicsShaderParticlesOptions &p_particleOptions) {}
			virtual void CommitParticleQueue(GraphicsParticleQueue *p_particleQueue, GraphicsShaderParticlesOptions &p_particleOptions) {}

			// polygon queue
			virtual void CreatePolygonQueue(GraphicsPolygonQueue *p_polygonQueue, int p_triangleQty) {}
			virtual void SubmitPolygonToQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions, GameColor *p_colors, int p_colorQty, ModelVertex *p_vertices, int p_vertexQty, bool p_alphaBlend = false, GameTexture ^p_texture = nullptr, ModelVertexTextureCoords *p_texCoords = nullptr, int p_texCoordsQty = 0, float p_startS = 0.0f, float p_startT = 0.0f, float p_scaleS = 1.0f, float p_scaleT = 1.0f, float p_trapezoidTopSize = 1.0f, float p_trapezoidBottomSize = 1.0f) {}
			virtual void SubmitModelToPolygonQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions, GameColor *p_colors, int p_colorQty, ModelSurface *p_surfaces, int p_surfaceQty, ModelVertex *p_vertices, int p_vertexQty, Orient3d &p_orient, Vector3d &p_scale) {}
			virtual void CommitPolygonQueue(GraphicsPolygonQueue *p_polygonQueue, GraphicsShaderPolygonOptions &p_polygonOptions) {}

			// post processing
			virtual void RenderPostProcessingShaderQuad(ModelVertex *p_surfaceVertices, ModelVertexTextureCoords *p_quadTexCoords, GraphicsPostProcessShaderOptions %p_renderOptions) {}

			// 2d rendering
			virtual void RenderFont(String ^p_string, GameFont ^p_font, float p_x, float p_y, GameColor &p_color) {}
			virtual void RenderFont(String ^p_string, GameFont ^p_font, int p_x, int p_y, GameColor &p_color) {}
			virtual void RenderFilledRectangle(System::Drawing::RectangleF &p_rect, GameColor &p_color) {}

			// render buffers
			virtual void CreateFrameBuffer(GraphicsFrameBufferContainer *p_frameBufferPtr, GraphicsFrameBufferTypeEnum p_colorBufferType, GraphicsFrameBufferTypeEnum p_depthBufferType, int p_width, int p_height, int p_faces = 1, bool p_supportDepthStencil = false, GraphicsFrameBufferColorFormatEnum *p_attachmentColorFormats = nullptr, int p_attachmentColorFormatQty = 0) {}
			virtual void SetCurrentFrameBuffer(GraphicsFrameBufferContainer* p_framebuffer = nullptr, int p_faceIndex = 0) {}
			// only for special circumstances in implementation
			virtual void DestroyFrameBuffer(GraphicsFrameBufferContainer *p_frameBufferPtr) {}

			// utility
			void RenderTextBlock(String ^p_block, GameFont ^p_font, float p_startX, float p_startY, GameColor &p_color);
			void RenderTextBlock(String ^p_block, GameFont ^p_font, int p_startX, int p_startY, GameColor &p_color);
			void RenderTextLines(array<String^, 1> ^p_lines, GameFont ^p_font, float p_startX, float p_startY, GameColor &p_color);
			void RenderTextLines(array<String^, 1> ^p_lines, GameFont ^p_font, int p_startX, int p_startY, GameColor &p_color);
			void BuildViewFrustum(Orient3d &p_viewOrient, Frustum *p_frustum, float p_scale = 1.0f, bool p_left = true, StereoscopicCamera *p_camera = nullptr);
		};
	}
}