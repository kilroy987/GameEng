#pragma once

#include "BoundingVolume.h"

namespace GameEng {
	namespace Storage {

		// A volume partition is a regular 3d box partition with edges that stretch to infinity, each meant to hold a data item.
		using namespace GameEng::Geometry;

		// a single section of a VOlume Partition
		template <class T> class VolumePartitionSection
		{
		public:
			bool minXValid, maxXValid; // at edges of volume partition, limits don't matter
			bool minYValid, maxYValid;
			bool minZValid, maxZValid;

			float minX, maxX;
			float minY, maxY;
			float minZ, maxZ;

			int xIndex, yIndex, zIndex;

			T data;

			bool BoundingVolumeIntersects(BoundingVolume3d &p_boundingVolume)
			{
				if (minXValid == true && p_boundingVolume.maxX < minX)
					return false;
				if (minYValid == true && p_boundingVolume.maxY < minY)
					return false;
				if (minZValid == true && p_boundingVolume.maxZ < minZ)
					return false;
				if (maxXValid == true && p_boundingVolume.minX >= maxX)
					return false;
				if (maxYValid == true && p_boundingVolume.minY >= minY)
					return false;
				if (maxZValid == true && p_boundingVolume.minZ >= minZ)
					return false;

				return true;
			}
		};

		template <class T> class VolumePartition
		{
			VolumePartitionSection<T> *sections;

		public:
			int xSectionQty;
			int ySectionQty;
			int zSectionQty;

			float minX, minY, minZ;
			float maxX, maxY, maxZ;
			float sizeX, sizeY, sizeZ;

			VolumePartition(float p_minX, float p_minY, float p_minZ, float p_maxX, float p_maxY, float p_maxZ, float p_preferredSizeX, float p_preferredSizeY, float p_preferredSizeZ)
			{
				minX = p_minX;
				minY = p_minY;
				minZ = p_minZ;

				maxX = p_maxX;
				maxY = p_maxY;
				maxZ = p_maxZ;

				xSectionQty = int((maxX - minX) / p_preferredSizeX);
				ySectionQty = int((maxY - minY) / p_preferredSizeY);
				zSectionQty = int((maxZ - minZ) / p_preferredSizeZ);
				if (float(xSectionQty) * p_preferredSizeX < (maxX - minX))
					xSectionQty += 1;
				if (float(ySectionQty) * p_preferredSizeY < (maxY - minY))
					ySectionQty += 1;
				if (float(zSectionQty) * p_preferredSizeZ < (maxZ - minZ))
					zSectionQty += 1;

				sizeX = (maxX - minX) / float(xSectionQty);
				sizeY = (maxY - minY) / float(ySectionQty);
				sizeZ = (maxZ - minZ) / float(zSectionQty);

				// make room for the infinite cells on the borders
				// todo: support NOT requring this
				xSectionQty += 2;
				ySectionQty += 2;
				zSectionQty += 2;

				sections = new VolumePartitionSection<T>[xSectionQty * ySectionQty * zSectionQty];

				PopulateSectionValues();
			}

			virtual ~VolumePartition()
			{
				if (sections != nullptr)
				{
					delete[] sections;
					sections = nullptr;
				}
			}

		private:
			void PopulateSectionValues()
			{
				for (int x = 0; x < xSectionQty; x++)
				{
					for (int y = 0; y < ySectionQty; y++)
					{
						for (int z = 0; z < zSectionQty; z++)
						{
							VolumePartitionSection<T> *section = GetPartitionSectionByIndex(x, y, z);

							section->minXValid = true;
							section->minYValid = true;
							section->minZValid = true;
							section->maxXValid = true;
							section->maxYValid = true;
							section->maxZValid = true;

							if (x == 0)
								section->minXValid = false;
							else if (x == xSectionQty - 1)
								section->maxXValid = false;
							if (y == 0)
								section->minYValid = false;
							else if (y == ySectionQty - 1)
								section->maxYValid = false;
							if (z == 0)
								section->minZValid = false;
							else if (z == zSectionQty - 1)
								section->maxZValid = false;

							section->minX = minX + float(x - 1) * sizeX;
							section->maxX = minX + float(x) * sizeX;
							section->minY = minY + float(y - 1) * sizeY;
							section->maxY = minY + float(y) * sizeY;
							section->minZ = minZ + float(z - 1) * sizeZ;
							section->maxZ = minZ + float(z) * sizeZ;

							section->xIndex = x;
							section->yIndex = y;
							section->zIndex = z;
						}
					}
				}
			}

		public:
			VolumePartitionSection<T> * GetPartitionSection(float p_x, float p_y, float p_z)
			{
				// max values are NOT inclusive of each section!  min values are.
				int xIndex = int((p_x - minX) / sizeX) + 1;
				int yIndex = int((p_y - minY) / sizeY) + 1;
				int zIndex = int((p_z - minZ) / sizeZ) + 1;
				if (xIndex < 0)
					xIndex = 0;
				if (xIndex > xSectionQty - 1)
					xIndex = xSectionQty - 1;
				if (yIndex < 0)
					yIndex = 0;
				if (yIndex > ySectionQty - 1)
					yIndex = ySectionQty - 1;
				if (zIndex < 0)
					zIndex = 0;
				if (zIndex > zSectionQty - 1)
					zIndex = zSectionQty - 1;

				return GetPartitionSectionByIndex(xIndex, yIndex, zIndex);
			}
			void GetPartitionSectionIndices(float p_x, float p_y, float p_z, int &p_xIndex, int &p_yIndex, int &p_zIndex)
			{
				// max values are NOT inclusive of each section!  min values are.
				p_xIndex = int((p_x - minX) / sizeX) + 1;
				p_yIndex = int((p_y - minY) / sizeY) + 1;
				p_zIndex = int((p_z - minZ) / sizeZ) + 1;
				if (p_xIndex < 0)
					p_xIndex = 0;
				if (p_xIndex > xSectionQty - 1)
					p_xIndex = xSectionQty - 1;
				if (p_yIndex < 0)
					p_yIndex = 0;
				if (p_yIndex > ySectionQty - 1)
					p_yIndex = ySectionQty - 1;
				if (p_zIndex < 0)
					p_zIndex = 0;
				if (p_zIndex > zSectionQty - 1)
					p_zIndex = zSectionQty - 1;
			}

			VolumePartitionSection<T> * GetPartitionSectionByIndex(int p_xIndex, int p_yIndex, int p_zIndex)
			{
				return &(sections[p_zIndex * (xSectionQty * ySectionQty) + p_yIndex * xSectionQty + p_xIndex]);
			}
		};
	}
}