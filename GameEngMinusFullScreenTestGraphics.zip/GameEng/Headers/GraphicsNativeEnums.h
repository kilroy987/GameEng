#pragma once

namespace GameEng {
	namespace Graphics {
		// 0 = nothing
		class GraphicsVertexShaderOperationEnum
		{
		public:
			static const int None = 0;
			static const int NoTransform = 1; // take vertices exactly as they are
			static const int MVP_Matrix = 2; // ModelViewProjection matrix provided (actually matrix = projection * view * model)
			static const int MVP_Matrix_SingleColorPassThrough = 3; // ModelViewProjection matrix provided (actually matrix = projection * view * model), witha single color passed to fragment
			static const int MVP_Matrix_Texture = 4; // ModelViewProjection matrix provided (actually matrix = projection * view * model) with UV coords
			static const int MVP_Matrix_TextureWithBlendMap_FragmentBlend = 5; // ModelViewProjection matrix provided (actually matrix = projection * view * model) with two sets of UV coords
			static const int MVP_Matrix_TextureWithBlendMap_VertexBlend = 6; // ModelViewProjection matrix provided (actually matrix = projection * view * model) with two sets of UV coords
			static const int MVP_Matrix_Texture_SingleColorPassThrough = 7;
			static const int MVP_Matrix_TextureWithBlendMap_SingleColorPassThrough = 8;
			static const int Projection_ModelView_Matrix = 9; // 2 matrices provided
			// lighting
			static const int MVP_Matrix_SingleColorPassThrough_FragmentLighting = 10;
			static const int MVP_Matrix_Texture_SingleColorPassThrough_FragmentLighting = 11;
			static const int MVP_Matrix_Texture_BumpMap_SingleColorPassThrough_FragmentLighting = 12;
			static const int MVP_Matrix_Texture_BumpMap_VertexColor_FragmentLighting = 13;

			static const int MVP_Matrix_SingleColorPassThrough_VertexLighting_Light0 = 14;
			static const int MVP_Matrix_Texture_SingleColorPassThrough_VertexLighting_Light0 = 15;

			static const int MVP_Matrix_SingleColorPassThrough_VertexLighting_Light1 = 16;
			static const int MVP_Matrix_Texture_SingleColorPassThrough_VertexLighting_Light1 = 17;

			static const int MVP_Matrix_SingleColorPassThrough_VertexLighting_Light2 = 18;
			static const int MVP_Matrix_Texture_SingleColorPassThrough_VertexLighting_Light2 = 19;

			static const int MVP_Matrix_SingleColorPassThrough_VertexLighting_Light3 = 20;
			static const int MVP_Matrix_Texture_SingleColorPassThrough_VertexLighting_Light3 = 21;

			static const int MVP_Matrix_SingleColorPassThrough_VertexLighting_Light4 = 22;
			static const int MVP_Matrix_Texture_SingleColorPassThrough_VertexLighting_Light4 = 23;

			static const int Vertex_Dynamic = 24;

			static const int FirstImplementationVertexShaderEnum = 25;
		};

		// 0 = nothing
		class GraphicsFragmentShaderOperationEnum
		{
		public:
			static const int None = 0;
			static const int NoTextureSingleColor = 1;
			static const int NoTextureVertexColor = 2;
			static const int SingleTextureNoColor = 3;
			static const int SingleTextureModulateSingleColor = 4;
			static const int SingleTextureModulateVertexColor = 5;
			static const int DoubleTextureWithBlendMapModulateSingleColor = 6;
			static const int DoubleTextureWithBlendMapModulateVertexColor = 7;
			static const int TripleTextureWithBlendMapModulateSingleColor = 8;
			static const int TripleTextureWithBlendMapModulateVertexColor = 9;
			static const int QuadTextureWithBlendMapModulateSingleColor = 10;
			static const int QuadTextureWithBlendMapModulateVertexColor_VertexBlend = 11;
			static const int QuadTextureWithBlendMapModulateVertexColor_FragmentBlend = 12;

			// lighting
			static const int NoTextureSingleColor_VertexLighting = 13;
			static const int SingleTextureSingleColor_VertexLighting = 14;

			static const int NoTextureSingleColor_FragmentLighting_Light0 = 15;
			static const int SingleTextureSingleColor_FragmentLighting_Light0 = 16;
			static const int SingleTextureVertexColor_FragmentLighting_Light0 = 17;

			static const int NoTextureSingleColor_FragmentLighting_Light1 = 18;
			static const int SingleTextureSingleColor_FragmentLighting_Light1 = 19;
			static const int SingleTextureBumpMapSingleColor_FragmentLighting_Light1 = 20;
			static const int SingleTextureBumpMapVertexColor_FragmentLighting_Light1 = 21;

			static const int NoTextureSingleColor_FragmentLighting_Light2 = 22;
			static const int SingleTextureSingleColor_FragmentLighting_Light2 = 23;
			static const int SingleTextureBumpMapSingleColor_FragmentLighting_Light2 = 24;
			static const int SingleTextureBumpMapVertexColor_FragmentLighting_Light2 = 25;

			static const int NoTextureSingleColor_FragmentLighting_Light3 = 26;
			static const int SingleTextureSingleColor_FragmentLighting_Light3 = 27;
			static const int SingleTextureBumpMapSingleColor_FragmentLighting_Light3 = 28;
			static const int SingleTextureBumpMapVertexColor_FragmentLighting_Light3 = 29;

			static const int NoTextureSingleColor_FragmentLighting_Light4 = 30;
			static const int SingleTextureSingleColor_FragmentLighting_Light4 = 31;
			static const int SingleTextureBumpMapSingleColor_FragmentLighting_Light4 = 32;
			static const int SingleTextureBumpMapVertexColor_FragmentLighting_Light4 = 33;

			static const int SingleTextureBumpMapSpecularMapVertexColor_FragmentLighting_Light1 = 34; // based on SingleTextureBumpMapVertexColor_FragmentLighting_Light1
			static const int SingleTextureBumpMapSpecularMapVertexColor_FragmentLighting_Light2 = 35;
			static const int SingleTextureBumpMapSpecularMapVertexColor_FragmentLighting_Light3 = 36;
			static const int SingleTextureBumpMapSpecularMapVertexColor_FragmentLighting_Light4 = 37;

			static const int Fragment_Dynamic = 38;

			static const int FirstImplementationFragmentShaderEnum = 39;
		};

		////////////////////////////////////////
		// Shader composition can change with each render, but is based on an existing native object.  If the native obejct has a portion of data, that data must have a placement in the 'in' list in 
		//   the proper order
		// Any other data provided must be in uniform variables
		enum GraphicsShaderCompositionVertexTransformationOption
		{
			NoTransform, // use vertex data as is, no mvp provided
			Transform, // mvp provided, use to get vertex location (if joints, have multiple)
		};

		enum GraphicsShaderCompositionVertexBonesOption
		{
			NoBones,
			Bones // multiple mvps, (and light positions and camera positions if lighting is used) will be provided
		};

		// which color should be used to used for a fragment (this is the rendered color)
		enum class GraphicsShaderCompositionColorOption
		{
			NoColor, // don't modulate textures with any color, take as is (default white if no color provided in the end) - no vertex color data
			SingleColor, // use color provided in options, not colors at surface vertex level - no vertex color data - modulate texture if any modulate option used
			VertexColor // use color at vertex or surface vertex level from data, modulate texture if any modulate option used
		};

		// should a texture's fragment color be modulated with the fragment color?
		enum class GraphicsShaderCompositionTextureModulateOption
		{
			NoModulate,
			ModulateWithColor // whatever color was sent to fragment
		};

		public enum class GraphicsShaderCompositionTextureLightOption
		{
			// if all textures in the stack emit, ignore light entirely
			// if some emit, use light individually on the textures that are diffuse
			// if none emit, mix all textures then modulte with light at the end
			Diffuse = 0, // allow light to be lit diffusely
			Emittive = 1 // emits - ignore light
		};

		// textures are always blended with the latest result until some other enhancement is needed
		// (texture 0 provides a result, then texture 1 is blended with 0, then texture 2 is blended with the result of the blend of 1 and 0, etc.)
		public enum class GraphicsShaderCompositionTextureBlendOption
		{
			NoBlend = 0, // take as is, decal over prior texture using texture's alpha component (if not texture 1, preferred to have some alpha component otherwise it compeltely decals over and is a waste)
			Modulate = 1, // modulate with latest texture result
			BlendWithColor_Red = 2, // blend using red component of used color (mix => 1.0 = use this texture entirely, 0.0 = use latest entirely)
			BlendWithColor_Green = 3, // blend using green component of used color
			BlendWithColor_Blue = 4, // blend using blue component of used color
			BlendWithColor_Alpha = 5, // blend using alpha component of used color
			BlendWithBlendMap_Red = 6, // blend with prior using blend map, use red component (mix => 1.0 = use this texture entirely, 0.0 = use prior entirely)
			BlendWithBlendMap_Green = 7, // blend with prior using blend map, use green component
			BlendWithBlendMap_Blue = 8, // blend with prior using blend map, use blue component
			BlendWithBlendMap_Alpha = 9, // blend with prior using blend map, use alpha component
			BlendInverseLight = 10, // take brightest light component and use 1.0 - value to mix with latest result - recommended use light option Emittive for this texture otherwise the light will modulate it to black
			BlendInverseSqrtLight = 11, // same but fades much faster, same however at 0.0 and 1.0
			DecalSaturateAlpha = 12 // decal over texture, saturating alpha with decal's alpha
		};

		public enum class GraphicsShaderCompositionSpecularBlendOption
		{
			NoModulate = 0, // just multiply by specular and add to existing result of stack (normal operation)
			Modulate = 1 // multiply by existing result of stack and replace it with the result
		};

		public enum class GraphicsShaderCompositionLightType
		{
			Point,			// light at a position, shines in all directions, attentuates
			Spotlight,		// light at a position, shines in a direction, max angle off direction, attentuates
			SpotlightTexture, // light at a position, shines in a direction, conversion along tangent and binormal axes, use color of texture when resulting coords within (0,0)-(1,1), attentuates
			Directional		// light shines from a direction, does not attentuate
		};

		// code and shadowmap type to use to render
		public enum class GraphicsShaderCompositionLightShadowMapType
		{
			FlatMap, // mvp used to generate depth values, multiply by fragment world position, divide by w, * 0.5 and add 0.5, use xy to access texture, compare z to depth value in texture
			CubeMap // light world position to world fragment position offset, get length, divide by far plane, use original offset to access cubemap, compare with depth value
		};
	}
}
