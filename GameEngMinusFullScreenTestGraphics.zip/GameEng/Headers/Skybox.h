#pragma once

#include "Vector.h"
#include "Orient.h"
#include "GameColor.h"
#include "ModelSurface.h"
#include "GraphicsBase.h"
#include "StarfieldPoint.h"
#include "Tools.h"

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;
		using namespace GameEng::Tools::Random;

		class SkyboxColorDome {
			// a form of model but made up only of colors, initialized with a progression of values and angle incremenets
			// the result is a dome with colors established working up from the horizon to the central point at the top
			// rings exist at regular intervals by angle.  2 rings would be 45 degrees apart.  9 rings would be 10 degrees apart, etc.
			// requirement is 1 color per ring + 1 for the upper vertex.

		public:

			// total number of vertices = verticesPerRing * ringQty + 1 for the top vertex
			int verticesPerRingQty;
			int ringQty;
			ModelVertex *vertices;
			GameColor *colors;
			ModelSurface *surfaces;
			int vertexQty, surfaceQty, colorQty;

			SkyboxColorDome()
			{
				verticesPerRingQty = 0;
				ringQty = 0;

				vertices = nullptr;
				colors = nullptr;
				surfaces = nullptr;

				vertexQty = 0;
				surfaceQty = 0;
				colorQty = 0;
			}

			virtual ~SkyboxColorDome()
			{
				Destroy();
			}

			void Destroy()
			{
				if (vertices != nullptr)
				{
					delete [] vertices;
					vertices = nullptr;
				}

				if (colors != nullptr)
				{
					delete [] colors;
					colors = nullptr;
				}

				if (surfaces != nullptr)
				{
					delete[] surfaces;
					surfaces = nullptr;
				}

				vertexQty = 0;
				surfaceQty = 0;
				colorQty = 0;

				verticesPerRingQty = 0;
				ringQty = 0;
			}

			// rings exist at regular intervals by angle.  2 rings would be 45 degrees apart.  9 rings would be 10 degrees apart, etc.
			// requirement is 1 color per ring + 1 for the upper vertex.
			// list colors in order from horizon to upper vertex
			// WARNING: DO NOT put a new [] {} element in the p_colors argument - use a hard defined array or existing array variable.  Callign initialization twice with a 
			//  new [] as an argument causes an exception for some reason.
			void Initialize(int p_ringQty, int p_verticesPerRingQty, GameColor *p_colors)
			{
				ringQty = p_ringQty;
				verticesPerRingQty = p_verticesPerRingQty;

				// set up storage
				vertexQty = ringQty * verticesPerRingQty + 1;
				vertices = new ModelVertex[vertexQty];
				colorQty = ringQty + 1;
				colors = new GameColor[colorQty];
				surfaceQty = ringQty * verticesPerRingQty;
				surfaces = new ModelSurface[surfaceQty];

				// copy over colors
				int index = 0;
				while (p_ringQty >= 0)
				{
					colors[index] = p_colors[index];
					p_ringQty--;
					index++;
				}

				CalculateVertices();
			}

			void Render(GraphicsBase &p_graphics)
			{
				p_graphics.RenderSurfaces(colors, colorQty, surfaces, surfaceQty, vertices, vertexQty);
			}

		private:
			void CalculateVertices()
			{
				// vertices go clockwise around the base of the dome

				// vertex 0..verticesPerRing are the horizon vertices
				// vertex verticesPerRing+1..verticesPerRing*2 are the next set up
				// ..
				// vertex vertexQty-1 is the top vertex
				
				// set up surfaces
				for (int r = 0; r < ringQty; r++)
				{
					for (int v = 0; v < verticesPerRingQty; v++)
					{
						int surfaceIndex = r * verticesPerRingQty + v;
						int vertexIndex = r * verticesPerRingQty + v;

						if (v < verticesPerRingQty - 1)
						{
							if (r < ringQty - 1)
							{
								surfaces[surfaceIndex].Initialize(4);
								surfaces[surfaceIndex].SetVertexIndex(0, vertexIndex+1);
								surfaces[surfaceIndex].SetVertexIndex(1, vertexIndex);
								surfaces[surfaceIndex].SetVertexIndex(2, vertexIndex + verticesPerRingQty);
								surfaces[surfaceIndex].SetVertexIndex(3, vertexIndex + verticesPerRingQty + 1);
							}
							else
							{
								// top ring
								surfaces[surfaceIndex].Initialize(3);
								surfaces[surfaceIndex].SetVertexIndex(0, vertexIndex + 1);
								surfaces[surfaceIndex].SetVertexIndex(1, vertexIndex);
								surfaces[surfaceIndex].SetVertexIndex(2, vertexQty - 1);
							}
						}
						else
						{
							// last surface of a ring
							if (r < ringQty - 1)
							{
								// join with vertex 0 of the ring
								surfaces[surfaceIndex].Initialize(4);
								surfaces[surfaceIndex].SetVertexIndex(0, r * verticesPerRingQty);
								surfaces[surfaceIndex].SetVertexIndex(1, vertexIndex);
								surfaces[surfaceIndex].SetVertexIndex(2, vertexIndex + verticesPerRingQty);
								surfaces[surfaceIndex].SetVertexIndex(3, r * verticesPerRingQty + verticesPerRingQty);
							}
							else
							{
								// join with vertex 0 of the ring

								// top ring
								surfaces[surfaceIndex].Initialize(3);
								surfaces[surfaceIndex].SetVertexIndex(0, r * verticesPerRingQty);
								surfaces[surfaceIndex].SetVertexIndex(1, vertexIndex);
								surfaces[surfaceIndex].SetVertexIndex(2, vertexQty - 1);
							}
						}
					}
				} // set up surfaces

				// calculate vertices
				// top vertex is 0,10,0 always
				vertices[vertexQty - 1].vertex.Set(0, 10, 0);
				// calculate the rest in clockwise fashion with unit length of 10.0f
				float horizontalAngleIncrement = 360.0f / float(verticesPerRingQty);
				float verticalAngleIncrement = 90.0f / float(ringQty);
				Orient3d orient; // use an orientation structure to easily get the values we need
				for (int v = 0; v < verticesPerRingQty; v++)
				{
					orient.LoadIdentity();
					orient.Rotate(orient.u, horizontalAngleIncrement * float(v));
					for (int r = 0; r < ringQty; r++)
					{
						int vertexIndex = r * verticesPerRingQty + v;
						vertices[vertexIndex].vertex.Set(orient.f.ScalarMult(10));

						// tilt up
						orient.Rotate(orient.l, verticalAngleIncrement);
					}
				}

				// set colors on vertices
				int vertexRingCount = verticesPerRingQty;
				int colorIndex = 0;
				for (int v = 0; v < vertexQty; v++)
				{
					vertices[v].colorIndex = colorIndex;

					vertexRingCount--;
					if (vertexRingCount == 0)
					{
						vertexRingCount = verticesPerRingQty;
						colorIndex++;
					}
				}
			}
		};

		class Starfield {

		private:
			StarfieldPoint *stars;
			int starQty;

		public:
			Starfield()
			{

			}

			virtual ~Starfield()
			{
				Destroy();
			}

			void Destroy()
			{
				if (stars != nullptr)
				{
					delete[] stars;
					starQty = 0;
				}
			}

			// p_minimumColorValue should range from 0 to 255
			// p_minY should range from < 1.0f to -1.0f - -1.0f has no effect.  1.0f would cause a near infinite loop
			void Initialize(int p_starQty, GameColor &p_color1, GameColor &p_color2, int p_minimumColorValue, float p_minY = -1.0f)
			{
				LecuyerRandom random = LecuyerRandom();

				stars = new StarfieldPoint[p_starQty];
				starQty = p_starQty;

				// for simplicity, discard stars that are beyond the radius, at the origin, and below p_minY until we get the stars we want
				// if this algorithm were to be run many times constantly, a better option would be needed
				for (int s = 0; s < starQty; s++)
				{
					stars[s].point.Set(2.0f * random.GetRandomFloat() - 1.0f, 2.0f * random.GetRandomFloat() - 1.0f, 2.0f * random.GetRandomFloat() - 1.0f);

					// discard if too close to origin or too far away
					if (stars[s].point.Magnitude() < 0.0001f || stars[s].point.Magnitude() > 1.0f)
					{
						s--;
						continue;
					}

					stars[s].point.Normalize();

					if (stars[s].point.y < p_minY)
					{
						s--;
						continue;
					}

					int color = random.GetRandomInteger(p_minimumColorValue, 255);
					float interpolationFactor = random.GetRandomFloat();
					GameColor starColor = GameColor::Interpolate(p_color1, p_color2, interpolationFactor);
					starColor = starColor.Modulate(float(color) / 255.0f);
					stars[s].color.Set(starColor);
				}
			}

			// note: the orients should be at p (0,0,0)
			void Render(GraphicsBase &p_graphics, Orient3d &p_currentOrient, Orient3d *p_priorOrient = nullptr)
			{
				p_graphics.RenderStarfieldPoints(stars, starQty, p_currentOrient, p_priorOrient);
			}
		};
	}
}