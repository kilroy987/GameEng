#pragma once

#include "ModelSurface.h"
#include "GraphicsBase.h"
#include "MathConstants.h"

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Math;

		class Model3d
		{
		private:
			GameColor *colors;
			ModelVertex *vertices;
			ModelSurface *surfaces;
			int colorQty;
			int vertexQty;
			int surfaceQty;

		public:
			void Initialize(int p_colorQty, int p_vertexQty, int p_surfaceQty)
			{
				colors = new GameColor[p_colorQty];
				colorQty = p_colorQty;
				vertices = new ModelVertex[p_vertexQty];
				vertexQty = p_vertexQty;
				surfaces = new ModelSurface[p_surfaceQty];
				surfaceQty = p_surfaceQty;
			}

			Model3d()
			{
				surfaceQty = 0;
				surfaces = nullptr;

				vertexQty = 0;
				vertices = nullptr;

				colorQty = 0;
				colors = nullptr;
			}
			~Model3d()
			{
				Destroy();
			}

			void Destroy()
			{
				if (surfaces != nullptr)
				{
					delete[] surfaces;
					surfaces = nullptr;
					surfaceQty = 0;
				}

				if (vertices != nullptr)
				{
					delete[] vertices;
					vertices = nullptr;
					vertexQty = 0;
				}

				if (colors != nullptr)
				{
					delete[] colors;
					colors = nullptr;
					colorQty = 0;
				}
			}

			GameColor * GetColors()
			{
				return colors;
			}

			int GetColorQty()
			{
				return colorQty;
			}

			ModelSurface * GetSurfaces()
			{
				return surfaces;
			}

			int GetSurfaceQty()
			{
				return surfaceQty;
			}

			ModelSurface * GetSurface(int p_index)
			{
				if (p_index < surfaceQty)
					return &surfaces[p_index];

				throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}

			int GetVertexQty()
			{
				return vertexQty;
			}

			ModelVertex * GetVertices()
			{
				return vertices;
			}

			ModelVertex * GetVertex(int p_index)
			{
				if (p_index < vertexQty)
					return &vertices[p_index];

				throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}

			GameColor * GetColor(int p_index)
			{
				if (p_index < colorQty)
					return &colors[p_index];

				throw gcnew Exception("Index '" + Convert::ToString(p_index) + "' is out of bounds");
			}

			void SkinTexture0(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption = GraphicsShaderCompositionTextureBlendOption::Modulate, GraphicsShaderCompositionTextureLightOption p_lightOption = GraphicsShaderCompositionTextureLightOption::Diffuse, GameTexture ^p_specularTexture = nullptr, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				for (int s = 0; s < surfaceQty; s++)
				{
					surfaces[s].SetTexture0(p_texture, p_blendOption, p_lightOption);
					surfaces[s].SetSpecularMapTexture0(p_specularTexture, p_specularBlendOption);
				}
			}
			void SkinTexture1(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption, GraphicsShaderCompositionTextureLightOption p_lightOption, GameTexture ^p_specularTexture = nullptr, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				for (int s = 0; s < surfaceQty; s++)
				{
					surfaces[s].SetTexture1(p_texture, p_blendOption, p_lightOption);
					surfaces[s].SetSpecularMapTexture1(p_specularTexture, p_specularBlendOption);
				}
			}
			void SkinTexture2(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption, GraphicsShaderCompositionTextureLightOption p_lightOption, GameTexture ^p_specularTexture = nullptr, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				for (int s = 0; s < surfaceQty; s++)
				{
					surfaces[s].SetTexture2(p_texture, p_blendOption, p_lightOption);
					surfaces[s].SetSpecularMapTexture2(p_specularTexture, p_specularBlendOption);
				}
			}
			void SkinTexture3(GameTexture ^p_texture, GraphicsShaderCompositionTextureBlendOption p_blendOption, GraphicsShaderCompositionTextureLightOption p_lightOption, GameTexture ^p_specularTexture = nullptr, GraphicsShaderCompositionSpecularBlendOption p_specularBlendOption = GraphicsShaderCompositionSpecularBlendOption::NoModulate)
			{
				for (int s = 0; s < surfaceQty; s++)
				{
					surfaces[s].SetTexture3(p_texture, p_blendOption, p_lightOption);
					surfaces[s].SetSpecularMapTexture3(p_specularTexture, p_specularBlendOption);
				}
			}

			void ReScale(float p_scale)
			{
				for (int v = 0; v < vertexQty; v++)
					vertices[v].vertex = vertices[v].vertex.ScalarMult(p_scale);
				// normals won't change in this case
			}

			void ReScale(Vector3d &p_scale)
			{
				for (int v = 0; v < vertexQty; v++)
					vertices[v].vertex = Vector3d(vertices[v].vertex.x * p_scale.x, vertices[v].vertex.y * p_scale.y, vertices[v].vertex.z * p_scale.z);
				CalculateNormals();
			}

			void CalculateNormals()
			{
				// surface level
				// calculate normal for each surface (tangents and binormals will only be valid if texture coordinates are set)
				for (int s = 0; s < surfaceQty; s++)
				{
					ModelSurface *surface = &surfaces[s];
					if (surface->GetVertexQty() < 3)
					{
						surface->GetNormal().Set(0.0f, 0.0f, 0.0f);
					}
					else
					{
						surface->CalculateNormals(vertices);

						//Vector3d *vertex0 = &vertices[surface->GetSurfaceVertex(0)->vertexIndex].vertex;
						//Vector3d *vertex1 = &vertices[surface->GetSurfaceVertex(1)->vertexIndex].vertex;
						//Vector3d *vertex2 = &vertices[surface->GetSurfaceVertex(2)->vertexIndex].vertex;
						//Vector3d offset0 = *vertex0 - *vertex1;
						//Vector3d offset1 = *vertex2 - *vertex1;
						//Vector3d crossProduct = offset0.CrossProd(offset1); // u = f x l rule
						//crossProduct.Normalize();
						//surface->GetNormal().Set(crossProduct);
					}
				}

				// vertex level
				// add up surface normals for each surface a vertex is on, and normalize (would average them but normalize does what it needs to here)
				// tangents will be horizontal (either to the left or right depending on normal map standards), and the binormal will be a cross product pointing 'upward'
				// textures for vertex normal lit models are imagined to be skinned horizontally, like earth.
				for (int v = 0; v < vertexQty; v++)
				{
					ModelVertex *vertex = &vertices[v];
					Vector3d normalSum = Vector3d(0.0f, 0.0f, 0.0f);
					for (int s = 0; s < surfaceQty; s++)
					{
						ModelSurface *surface = &surfaces[s];
						if (surface->GetVertexQty() >= 3)
						{
							for (int sv = 0; sv < surface->GetVertexQty(); sv++)
							{
								if (surface->GetSurfaceVertex(sv)->vertexIndex == v)
								{
									normalSum = normalSum + surface->GetNormal();
									break;
								}
							}
						}
					}
					normalSum.Normalize();
					vertex->normal = normalSum;

					// get tangent - make it perfectly horizontal going to the right, for now (standard for normal maps)
					vertex->bumpMapTangent.x = vertex->normal.z;
					vertex->bumpMapTangent.y = 0.0f;
					vertex->bumpMapTangent.z = -vertex->normal.x;
					if (vertex->bumpMapTangent.Normalize() == false)
					{
						// so the normal is vertical... that's kind of awful.  But not invalid.  Just pick a constant one for now, we'll worry about cleaning this up later
						// A really bad example about this would be having the vertex at the apex of a sphere, where a horizontal tangent really doesn't apply very well since the triangle shared by the vertex would demand
						//    a different tangent each. If the normal map data there is only vertical, then that isn't too bad because artifacts created by a bad tangent or binormal wouldn't be visible
						vertex->bumpMapTangent = Vector3d(-1.0f, 0.0f, 0.0f);
					}

					// now take crossproduct of normal and tangent to get the binormal (should face 'up' unless the normal is vertical) - standard for normal maps
					//vertex->bumpMapBinormal = vertex->bumpMapTangent.CrossProd(vertex->normal);
					vertex->bumpMapBinormal = vertex->normal.CrossProd(vertex->bumpMapTangent);
				}
			}

			void MakeCube()
			{
				Destroy();

				Initialize(8, 8, 6);

				GetColor(0)->Set(GameColor(255, 0, 0));
				GetColor(1)->Set(GameColor(0, 255, 0));
				GetColor(2)->Set(GameColor(0, 0, 255));
				GetColor(3)->Set(GameColor(0, 0, 0));
				GetColor(4)->Set(GameColor(255, 255, 0));
				GetColor(5)->Set(GameColor(255, 0, 255));
				GetColor(6)->Set(GameColor(0, 255, 255));
				GetColor(7)->Set(GameColor(255, 255, 255));

				GetVertex(0)->vertex = Vector3d(-1, -1, 1);
				GetVertex(1)->vertex = Vector3d(-1, 1, 1);
				GetVertex(2)->vertex = Vector3d(1, 1, 1);
				GetVertex(3)->vertex = Vector3d(1, -1, 1);
				GetVertex(4)->vertex = Vector3d(-1, -1, -1);
				GetVertex(5)->vertex = Vector3d(-1, 1, -1);
				GetVertex(6)->vertex = Vector3d(1, 1, -1);
				GetVertex(7)->vertex = Vector3d(1, -1, -1);

				GetVertex(0)->colorIndex = 0;
				GetVertex(1)->colorIndex = 1;
				GetVertex(2)->colorIndex = 2;
				GetVertex(3)->colorIndex = 3;
				GetVertex(4)->colorIndex = 4;
				GetVertex(5)->colorIndex = 5;
				GetVertex(6)->colorIndex = 6;
				GetVertex(7)->colorIndex = 7;

				// set up texcoords even if we don't have textures yet
				GetSurface(0)->Initialize(4, true);
				GetSurface(0)->SetVertexIndex(0, 0);
				GetSurface(0)->SetVertexIndex(1, 1);
				GetSurface(0)->SetVertexIndex(2, 2);
				GetSurface(0)->SetVertexIndex(3, 3);
				GetSurface(0)->SetVertexTexCoords(0, 0.0f, 0.0f);
				GetSurface(0)->SetVertexTexCoords(1, 1.0f, 0.0f);
				GetSurface(0)->SetVertexTexCoords(2, 1.0f, 1.0f);
				GetSurface(0)->SetVertexTexCoords(3, 0.0f, 1.0f);

				GetSurface(1)->Initialize(4, true);
				GetSurface(1)->SetVertexIndex(0, 3);
				GetSurface(1)->SetVertexIndex(1, 2);
				GetSurface(1)->SetVertexIndex(2, 6);
				GetSurface(1)->SetVertexIndex(3, 7);
				GetSurface(1)->SetVertexTexCoords(0, 0.0f, 0.0f);
				GetSurface(1)->SetVertexTexCoords(1, 1.0f, 0.0f);
				GetSurface(1)->SetVertexTexCoords(2, 1.0f, 1.0f);
				GetSurface(1)->SetVertexTexCoords(3, 0.0f, 1.0f);

				GetSurface(2)->Initialize(4, true);
				GetSurface(2)->SetVertexIndex(0, 0);
				GetSurface(2)->SetVertexIndex(1, 4);
				GetSurface(2)->SetVertexIndex(2, 5);
				GetSurface(2)->SetVertexIndex(3, 1);
				GetSurface(2)->SetVertexTexCoords(0, 0.0f, 0.0f);
				GetSurface(2)->SetVertexTexCoords(1, 1.0f, 0.0f);
				GetSurface(2)->SetVertexTexCoords(2, 1.0f, 1.0f);
				GetSurface(2)->SetVertexTexCoords(3, 0.0f, 1.0f);

				GetSurface(3)->Initialize(4, true);
				GetSurface(3)->SetVertexIndex(0, 6);
				GetSurface(3)->SetVertexIndex(1, 5);
				GetSurface(3)->SetVertexIndex(2, 4);
				GetSurface(3)->SetVertexIndex(3, 7);
				GetSurface(3)->SetVertexTexCoords(0, 0.0f, 0.0f);
				GetSurface(3)->SetVertexTexCoords(1, 1.0f, 0.0f);
				GetSurface(3)->SetVertexTexCoords(2, 1.0f, 1.0f);
				GetSurface(3)->SetVertexTexCoords(3, 0.0f, 1.0f);

				GetSurface(4)->Initialize(4, true);
				GetSurface(4)->SetVertexIndex(0, 1);
				GetSurface(4)->SetVertexIndex(1, 5);
				GetSurface(4)->SetVertexIndex(2, 6);
				GetSurface(4)->SetVertexIndex(3, 2);
				GetSurface(4)->SetVertexTexCoords(0, 0.0f, 0.0f);
				GetSurface(4)->SetVertexTexCoords(1, 1.0f, 0.0f);
				GetSurface(4)->SetVertexTexCoords(2, 1.0f, 1.0f);
				GetSurface(4)->SetVertexTexCoords(3, 0.0f, 1.0f);

				GetSurface(5)->Initialize(4, true);
				GetSurface(5)->SetVertexIndex(0, 0);
				GetSurface(5)->SetVertexIndex(1, 3);
				GetSurface(5)->SetVertexIndex(2, 7);
				GetSurface(5)->SetVertexIndex(3, 4);
				GetSurface(5)->SetVertexTexCoords(0, 0.0f, 0.0f);
				GetSurface(5)->SetVertexTexCoords(1, 1.0f, 0.0f);
				GetSurface(5)->SetVertexTexCoords(2, 1.0f, 1.0f);
				GetSurface(5)->SetVertexTexCoords(3, 0.0f, 1.0f);

				CalculateNormals();
			}

			void MakeJet(float p_scale = 1.0f)
			{
				Initialize(5, 10, 13);

				GameColor base(0, 0, 255);
				// sort of a cool sheen given off by making the cockpit 2 colors
				GameColor cockpitColor1(128, 128, 255);
				GameColor cockpitColor2(0, 255, 255);

				GetColor(0)->Set(base.Modulate(5.0f / 6.0f));
				GetColor(1)->Set(base.Modulate(2.0f / 3.0f));
				GetColor(2)->Set(base.Modulate(1.0f / 3.0f));
				GetColor(3)->Set(cockpitColor1);
				GetColor(4)->Set(cockpitColor2);

				GetVertex(0)->vertex = Vector3d(0.0f, -0.3f, 2.0f).ScalarMult(p_scale);
				GetVertex(1)->vertex = Vector3d(-0.3f, 0.2f, 1.0f).ScalarMult(p_scale);
				GetVertex(2)->vertex = Vector3d(0.3f, 0.2f, 1.0f).ScalarMult(p_scale);
				GetVertex(3)->vertex = Vector3d(0.3f, -0.3f, 0.8f).ScalarMult(p_scale);
				GetVertex(4)->vertex = Vector3d(-0.3f, -0.3f, 0.8f).ScalarMult(p_scale);
				GetVertex(5)->vertex = Vector3d(0.0f, 0.0f, -1.7f).ScalarMult(p_scale);
				GetVertex(6)->vertex = Vector3d(0.0f, -0.3f, -2.0f).ScalarMult(p_scale);
				GetVertex(7)->vertex = Vector3d(0.0f, 0.8f, -2.3f).ScalarMult(p_scale);
				GetVertex(8)->vertex = Vector3d(-1.5f, -0.3f, -2.0f).ScalarMult(p_scale);
				GetVertex(9)->vertex = Vector3d(1.5f, -0.3f, -2.0f).ScalarMult(p_scale);

				GetVertex(0)->colorIndex = 0;
				GetVertex(1)->colorIndex = 3;
				GetVertex(2)->colorIndex = 4;
				GetVertex(3)->colorIndex = 0;
				GetVertex(4)->colorIndex = 0;
				GetVertex(5)->colorIndex = 1;
				GetVertex(6)->colorIndex = 2;
				GetVertex(7)->colorIndex = 2;
				GetVertex(8)->colorIndex = 2;
				GetVertex(9)->colorIndex = 2;

				GetSurface(0)->Initialize(3);
				GetSurface(1)->Initialize(3);
				GetSurface(2)->Initialize(4);
				GetSurface(3)->Initialize(3);
				GetSurface(4)->Initialize(3);
				GetSurface(5)->Initialize(4);
				GetSurface(6)->Initialize(3);
				GetSurface(7)->Initialize(3);
				GetSurface(8)->Initialize(4);
				GetSurface(9)->Initialize(3);
				GetSurface(10)->Initialize(3);
				GetSurface(11)->Initialize(3);
				GetSurface(12)->Initialize(3);

				GetSurface(0)->SetVertexIndex(0, 0);
				GetSurface(0)->SetVertexIndex(1, 1);
				GetSurface(0)->SetVertexIndex(2, 2);
				GetSurface(1)->SetVertexIndex(0, 3);
				GetSurface(1)->SetVertexIndex(1, 0);
				GetSurface(1)->SetVertexIndex(2, 2);
				GetSurface(2)->SetVertexIndex(0, 0);
				GetSurface(2)->SetVertexColorOverrideIndex(0, 0);
				GetSurface(2)->SetVertexIndex(1, 3);
				GetSurface(2)->SetVertexIndex(2, 6);
				GetSurface(2)->SetVertexIndex(3, 4);
				GetSurface(3)->SetVertexIndex(0, 0);
				GetSurface(3)->SetVertexIndex(1, 4);
				GetSurface(3)->SetVertexIndex(2, 1);
				GetSurface(4)->SetVertexIndex(0, 1);
				GetSurface(4)->SetVertexColorOverrideIndex(0, 0);
				GetSurface(4)->SetVertexIndex(1, 5);
				GetSurface(4)->SetVertexIndex(2, 2);
				GetSurface(4)->SetVertexColorOverrideIndex(2, 0);

				GetSurface(5)->SetVertexIndex(0, 2);
				GetSurface(5)->SetVertexColorOverrideIndex(0, 0);
				GetSurface(5)->SetVertexIndex(1, 5);
				GetSurface(5)->SetVertexIndex(2, 6);
				GetSurface(5)->SetVertexIndex(3, 3);
				GetSurface(6)->SetVertexIndex(0, 3);
				GetSurface(6)->SetVertexIndex(1, 6);
				GetSurface(6)->SetVertexIndex(2, 9);
				GetSurface(7)->SetVertexIndex(0, 5);
				GetSurface(7)->SetVertexIndex(1, 7);
				GetSurface(7)->SetVertexIndex(2, 6);
				GetSurface(8)->SetVertexIndex(0, 1);
				GetSurface(8)->SetVertexColorOverrideIndex(0, 0);
				GetSurface(8)->SetVertexIndex(1, 4);
				GetSurface(8)->SetVertexIndex(2, 6);
				GetSurface(8)->SetVertexIndex(3, 5);
				GetSurface(9)->SetVertexIndex(0, 4);
				GetSurface(9)->SetVertexIndex(1, 8);
				GetSurface(9)->SetVertexIndex(2, 6);

				GetSurface(10)->SetVertexIndex(0, 3);
				GetSurface(10)->SetVertexIndex(1, 9);
				GetSurface(10)->SetVertexIndex(2, 6);
				GetSurface(11)->SetVertexIndex(0, 4);
				GetSurface(11)->SetVertexIndex(1, 6);
				GetSurface(11)->SetVertexIndex(2, 8);
				GetSurface(12)->SetVertexIndex(0, 5);
				GetSurface(12)->SetVertexIndex(1, 6);
				GetSurface(12)->SetVertexIndex(2, 7);
			}

			void MakeSphere(GameTexture ^p_skinTexture = nullptr, GameTexture ^p_skinBumpMapTexture = nullptr, GameTexture ^p_skinSpecularMapTexture = nullptr)
			{
				Initialize(18, 18, 32);

				vertices[0].vertex.Set(0, 1, 0);
				vertices[1].vertex.Set(0.0f, 0.5f, 0.5f);
				vertices[2].vertex.Set(0.5f, 0.5f, 0.0f);
				vertices[3].vertex.Set(0.0f, 0.5f, -0.5f);
				vertices[4].vertex.Set(-0.5f, 0.5f, 0.0f);
				vertices[5].vertex.Set(0, 0, 1);
				vertices[6].vertex.Set(0.5f, 0.0f, 0.5f);
				vertices[7].vertex.Set(1, 0, 0);
				vertices[8].vertex.Set(0.5f, 0.0f, -0.5f);
				vertices[9].vertex.Set(0, 0, -1);
				vertices[10].vertex.Set(-0.5f, 0.0f, -0.5f);
				vertices[11].vertex.Set(-1, 0, 0);
				vertices[12].vertex.Set(-0.5f, 0.0f, 0.5f);
				vertices[13].vertex.Set(0.0f, -0.5f, 0.5f);
				vertices[14].vertex.Set(0.5f, -0.5f, 0.0f);
				vertices[15].vertex.Set(0.0f, -0.5f, -0.5f);
				vertices[16].vertex.Set(-0.5f, -0.5f, 0.0f);
				vertices[17].vertex.Set(0, -1, 0);

				int i;
				for (i = 0; i <= 17; i++)
				{
					vertices[i].vertex.Normalize();
					vertices[i].colorIndex = i;
				}

				for (i = 0; i <= 3; i++)
				{
					surfaces[i].Initialize(3);

					surfaces[i].SetVertexIndex(0, 0);
					if (i < 3)
						surfaces[i].SetVertexIndex(1, i + 2);
					else
						surfaces[i].SetVertexIndex(1, 1);
					surfaces[i].SetVertexIndex(2, i + 1);

					surfaces[31 - i].Initialize(3);
					surfaces[31 - i].SetVertexIndex(0, 17);
					surfaces[31 - i].SetVertexIndex(1, i + 13);
					if (i < 3)
						surfaces[31 - i].SetVertexIndex(2, i + 14);
					else
						surfaces[31 - i].SetVertexIndex(2, 13);
				}

				for (i = 0; i <= 3; i++)
				{
					surfaces[i + 4].Initialize(3);
					surfaces[i + 4].SetVertexIndex(0, i + 1);
					if (i < 3)
						surfaces[i + 4].SetVertexIndex(1, i + 2);
					else
						surfaces[i + 4].SetVertexIndex(1, 1);
					surfaces[i + 4].SetVertexIndex(2, 6 + i * 2);

					surfaces[i + 8].Initialize(3);
					surfaces[i + 8].SetVertexIndex(0, 6 + i * 2);
					if (i < 3)
						surfaces[i + 8].SetVertexIndex(1, i + 14);
					else
						surfaces[i + 8].SetVertexIndex(1, 13);
					surfaces[i + 8].SetVertexIndex(2, 13 + i);
				}

				for (i = 0; i <= 7; i++)
				{
					surfaces[i + 12].Initialize(3);
					surfaces[i + 12].SetVertexIndex(0, int((i + 2) / 2));
					surfaces[i + 12].SetVertexIndex(1, 5 + i);
					if (i > 0)
						surfaces[i + 12].SetVertexIndex(2, 4 + i);
					else
						surfaces[i + 12].SetVertexIndex(2, 12);

					surfaces[i + 20].Initialize(3);
					if (i > 0)
						surfaces[i + 20].SetVertexIndex(0, 4 + i);
					else
						surfaces[i + 20].SetVertexIndex(0, 12);
					surfaces[i + 20].SetVertexIndex(1, 5 + i);
					surfaces[i + 20].SetVertexIndex(2, 13 + int(i / 2));
				}

				for (i = 0; i <= 17; i++)
				{
					colors[i].red = BYTE(255 * (vertices[i].vertex.z + 1.0f) / 2);
					colors[i].green = BYTE(255 * (vertices[i].vertex.x + 1.0f) / 2);
					colors[i].blue = BYTE(255 * (vertices[i].vertex.y + 1.0f) / 2);
					// Set not used, so set alpha explicitly
					colors[i].alpha = 255;
				}

				colors[0].red = 255;
				colors[0].green = 255;
				colors[0].blue = 255;

				colors[17].red = 255;
				colors[17].green = 255;
				colors[17].blue = 255;

				colors[5].red = 255;
				colors[5].green = 255;
				colors[5].blue = 255;

				colors[7].red = 255;
				colors[7].green = 255;
				colors[7].blue = 255;

				colors[9].red = 255;
				colors[9].green = 255;
				colors[9].blue = 255;

				colors[11].red = 255;
				colors[11].green = 255;
				colors[11].blue = 255;

				// get surface normals, then skin and calculate the vertex normals
				CalculateNormals();

				// set texture coordinates and textures, if any
				for (int s1 = 0; s1 < surfaceQty; s1++)
				{
					surfaces[s1].SetTexture0(p_skinTexture);
					surfaces[s1].SetSpecularMapTexture0(p_skinSpecularMapTexture);

					surfaces[s1].SetBumpMapTexture(p_skinBumpMapTexture);

					for (int v = 0; v < surfaces[s1].GetVertexQty(); v++)
					{
						// set s and t texture coordinates according to vertex's position on a circle

						// s keys off z with an adjustment depending on x
						float spinAngle = float(acos(vertices[surfaces[s1].GetSurfaceVertex(v)->vertexIndex].vertex.z)); // 0 to pi
						if (vertices[surfaces[s1].GetSurfaceVertex(v)->vertexIndex].vertex.x < 0.0f)
							spinAngle = 2.0f * MathConstants::Pi() - spinAngle; // 0 to 2pi, with a tweak to force it into the 359.999 degree area so that the other side uses 1.0 instead of 0.0
						float s = spinAngle / (2.0f * MathConstants::Pi()); // converts to 0 to 1
						// cleanup
						if (s < 0.0f)
							s = 0.0f;
						if (s > 1.0f)
							s = 1.0f;	
						// fix far edge values so that texture doesn't warp at the decaling start point
						if (s == 0.0f && surfaces[s1].GetNormal().x < 0.0f)
							s = 1.0f;				
						if (s == 1.0f && surfaces[s1].GetNormal().x > 0.0f)
							s = 0.0f;

						// t keys off position of pitch value of y
						// this assumes we are working with a skin texture whose y positions are the angle along the surface (for instance, Michigan would be 1/4 of the way down an earth texture, not 0.15)
						float pitchAngle = float(asin(vertices[surfaces[s1].GetSurfaceVertex(v)->vertexIndex].vertex.y)); // -pi/2 to pi/2
						float t = (MathConstants::Pi() / 2.0f - pitchAngle) / MathConstants::Pi(); // converts to 0 to 1
						//float t = -(vertices[surfaces[s1].GetSurfaceVertex(v)->vertexIndex].vertex.y - 1.0f) / 2.0f; // convert 1 to -1 to 0 to 1
						// cleanup
						if (t < 0.0f)
							t = 0.0f;
						if (t > 1.0f)
							t = 1.0f;

						surfaces[s1].GetSurfaceVertex(v)->texCoords.Set(s, t);
					}
				}
				
				CalculateNormals();
			}

			void Render(GameEng::Graphics::GraphicsBase &p_graphics)
			{
				p_graphics.RenderSurfaces(colors, colorQty, surfaces, surfaceQty, vertices, vertexQty);
			}

			// useful for rendering skyboxes that change colors
			void Render(GameEng::Graphics::GraphicsBase &p_graphics, GameColor *p_colorOverrides, int p_colorOverrideQty)
			{
				p_graphics.RenderSurfaces(p_colorOverrides, p_colorOverrideQty, surfaces, surfaceQty, vertices, vertexQty);
			}

			///////////////////
			// Shader support
			void CreateNativeObject(GraphicsBase *p_graphics, GraphicsNativeObjectContainer *p_container, bool p_lightingNormals)
			{
				p_graphics->CreateNativeObject(p_container, GetColors(), colorQty, GetVertices(), vertexQty, GetSurfaces(), surfaceQty, p_lightingNormals);
			}

			// create a copy into a new pointer
			void CopyTo(Model3d *p_model)
			{
				p_model->Initialize(colorQty, vertexQty, surfaceQty);

				for (int i = 0; i < colorQty; i++)
					p_model->GetColor(i)->Set(colors[i]);
				for (int i = 0; i < vertexQty; i++)
					*(p_model->GetVertex(i)) = vertices[i];
				for (int i = 0; i < surfaceQty; i++)
				{
					p_model->surfaces[i].Initialize(surfaces[i].GetVertexQty(), surfaces[i].UseSurfaceNormalForLighting());

					p_model->surfaces[i].SetTexture0(surfaces[i].GetTexture0(), surfaces[i].GetTexture0BlendOption(), surfaces[i].GetTexture0LightOption());
					p_model->surfaces[i].SetTexture1(surfaces[i].GetTexture1(), surfaces[i].GetTexture1BlendOption(), surfaces[i].GetTexture1LightOption());
					p_model->surfaces[i].SetTexture2(surfaces[i].GetTexture2(), surfaces[i].GetTexture2BlendOption(), surfaces[i].GetTexture2LightOption());
					p_model->surfaces[i].SetTexture3(surfaces[i].GetTexture3(), surfaces[i].GetTexture3BlendOption(), surfaces[i].GetTexture3LightOption());

					p_model->surfaces[i].SetBumpMapTexture(surfaces[i].GetBumpMapTexture());

					p_model->surfaces[i].SetSpecularMapTexture0(surfaces[i].GetSpecularMapTexture0(), surfaces[i].GetSpecularMapTexture0BlendOption());
					p_model->surfaces[i].SetSpecularMapTexture1(surfaces[i].GetSpecularMapTexture1(), surfaces[i].GetSpecularMapTexture1BlendOption());
					p_model->surfaces[i].SetSpecularMapTexture2(surfaces[i].GetSpecularMapTexture2(), surfaces[i].GetSpecularMapTexture2BlendOption());
					p_model->surfaces[i].SetSpecularMapTexture3(surfaces[i].GetSpecularMapTexture3(), surfaces[i].GetSpecularMapTexture3BlendOption());

					for (int v = 0; v < surfaces[i].GetVertexQty(); v++)
					{
						p_model->surfaces[i].SetVertexIndex(v, surfaces[i].GetSurfaceVertex(v)->vertexIndex);
						p_model->surfaces[i].SetVertexTexCoords(v, surfaces[i].GetSurfaceVertex(v)->texCoords.s, surfaces[i].GetSurfaceVertex(v)->texCoords.t, surfaces[i].GetSurfaceVertex(v)->texCoords.q, false); // they are already multiplied
						p_model->surfaces[i].SetVertexColorOverrideIndex(v, surfaces[i].GetSurfaceVertex(v)->colorOverrideIndex);
					}
				}

				// note: this assumes there is no implementation side tweaking of these results.
				p_model->CalculateNormals();
			}
		};
	}
}