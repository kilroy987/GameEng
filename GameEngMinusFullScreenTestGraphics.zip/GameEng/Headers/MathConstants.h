#pragma once

#include "Vector.h"

namespace GameEng {
	namespace Math {
		class MathConstants {
		public:
			static float Pi()
			{
				return 3.14159266f;
			}
		};
		
		class MathUtilities {
		public:		
			static float RadiansToDegrees(float p_radians)
			{
				return p_radians * 180.0f / MathConstants::Pi();
			}

			static float DegreesToRadians(float p_degrees)
			{
				return p_degrees *  MathConstants::Pi() / 180.0f;
			}

			static bool SpherePlaneCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_planePoint, Vector3d &p_planeUnitNormal, float &p_collisionT);
			static bool SpherePlaneIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_planePoint, Vector3d &p_planeUnitNormal, float &p_distance);

			static bool SphereLineCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_linePoint, Vector3d &p_lineUnitVector, float &p_collisionT);
			static bool SphereLineIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_linePoint, Vector3d &p_lineUnitVector, float &p_distance);

			static bool SphereLineSegmentCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_linePoint0, Vector3d &p_linePoint1, Vector3d *p_lineUnitVector, float &p_collisionT);
			static bool SphereLineSegmentIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_linePoint0, Vector3d &p_linePoint1, Vector3d *p_lineUnitVector, float &p_distance);

			static bool SpherePointCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius, Vector3d &p_point, float &p_collisionT);
			static bool SpherePointIntersection(Vector3d &p_centerPoint, float p_radius, Vector3d &p_point, float &p_distance);

			static bool SphereSphereCollision(Vector3d &p_startPoint, Vector3d &p_travelVector, float p_radius1, Vector3d &p_point, float p_radius2, float &p_collisionT)
			{
				// sphere starting at startpoint, travelling along travelVector (t = 0 to 1) of radius, colliding with sphere at point of radius 2
				return SpherePointCollision(p_startPoint, p_travelVector, p_radius1 + p_radius2, p_point, p_collisionT);
			}

			static bool ProjectileStrikeObjectWithGravity(Vector3d &p_gunPosition, Vector3d &p_gunVelocity, float p_projectileSpeed, float p_gravityPerTimeSquared, Vector3d &p_objectPosition, Vector3d &p_objectVelocity, float &p_resultT, Vector3d &p_resultProjectileDirection)
			{
				// gun at position and velocity fires projectile of known speed that will be affected by gravity on its way to an object travelling at its own velocity.
				// fine the earliest T at which the projectile will strike the object, and the exit velocity of the projectile

				// of course all values must be within same domain (same world dimension, etc.), 
				//   and t solved for will be of the same unit of gravityPerTimeSquared and the velocities (usually per MS^2 and per MS)
				// system of equations:
				// 1: sqrt(px^2+py^2+pz^2) = projectile speed
				// 2: gpx + (gvx + px)*t = opx + ovx*t
				// 3: gpz + (gvz + pz)*t = opz + ovz*t
				// 4: gpy + (gvy + py)*t - 1/2*gravity*t^2 = opy + ovy*t
				// solve for earliest t (or later t for lobbing high shots), then solve for px, py and pz
				// 4 equations, 4 variables.
				// get py from 1 equation and substitute in 4.  then solve for px and pz in 2 and 3 and substitute in 4.  this leaves nothing but t to solve for
				// 1 solve for py = +/- sqrt(projectile speed^2 - px^2 - pz^2)
				// 2 solve for px = (opx + ovx*t - gpx - gvx*t)/t
				// 3 solve for pz = (opz + ovz*t - gpz - gvz*t)/t
				// might not be a quadratic - might be cubic... or worse...
				// substitute 2 and 3 into 1: py = +/- sqrt(projectile speed^2 - yeah...
				// plug 1 into 4
				// solve it! (looks like a potential t^6 with a +/- py possibility)
				// so... not doing this for now. (but still need something for artillery firing at a moving target)

				return false;
			}

			static bool ProjectileStrikeObjectNoGravity(Vector3d &p_gunPosition, Vector3d &p_gunVelocity, float p_projectileSpeed, Vector3d &p_objectPosition, Vector3d &p_objectVelocity, float &p_resultT, Vector3d &p_resultProjectileDirection);
			static bool ProjectileStrikeObjectApproximateGravity(Vector3d &p_gunPosition, Vector3d &p_gunVelocity, float p_projectileSpeed, float p_gravityPerTimeSquared, Vector3d &p_objectPosition, Vector3d &p_objectVelocity, float &p_resultT, Vector3d &p_resultProjectileDirection);

			static float NormalizeCyclicDegrees(float p_degrees)
			{
				while (p_degrees >= 360.0f)
					p_degrees -= 360.0f;
				while (p_degrees < 0.0f)
					p_degrees += 360.0f;

				return p_degrees;
			}

			// spin current degrees to intended degrees, obey no more than 360 degrees in either direction as the difference
			static void InterpolateCyclicDegrees(float &p_currentAngleDegrees, float p_intendedAngleDegrees, float p_degreesToRotate)
			{
				if (p_currentAngleDegrees == p_intendedAngleDegrees)
					return;

				float degreesDifference = p_intendedAngleDegrees - p_currentAngleDegrees;
				while (degreesDifference > 180.0f)
					degreesDifference -= 360.0f;
				while (degreesDifference < -180.0f)
					degreesDifference += 360.0f;
				if (abs(degreesDifference) < p_degreesToRotate)
				{
					p_currentAngleDegrees = p_intendedAngleDegrees;
				}
				else
				{
					float sign = 1.0f;
					if (degreesDifference < 0.0f)
						sign = -1.0f;

					p_currentAngleDegrees += (p_degreesToRotate * sign);
				}

				// keep between [0, 360) degrees
				p_currentAngleDegrees = NormalizeCyclicDegrees(p_currentAngleDegrees);
			}

			static bool LineIntersectPlane(Vector3d &p_linePoint, Vector3d &p_lineVector, Vector3d &p_planePoint, Vector3d &p_planeUnitNormal, Vector3d &p_intersectionPoint)
			{
				float vectorProduct = p_lineVector * p_planeUnitNormal;
				if (abs(vectorProduct) < 0.00001f)
					return false;

				float offset = (p_planeUnitNormal * (p_planePoint - p_linePoint)) / vectorProduct;
				p_intersectionPoint = p_linePoint + p_lineVector.ScalarMult(offset);
				return true;
			}
		};
	}
}