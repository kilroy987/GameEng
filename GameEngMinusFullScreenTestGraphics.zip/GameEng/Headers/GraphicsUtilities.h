#pragma once

#include "GraphicsBase.h"
#include "GraphicsNative.h"

namespace GameEng {
	namespace Graphics {
		class GraphicsUtilities
		{
		public:
			static void PreparePointLightShadowCubeMapMVPs(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, GraphicsShaderLight *p_light, Matrix4d *p_lightMVPs, float p_near, float p_far, Vector3d *p_worldPositionOverride = nullptr)
			{
				// shadowmap frame buffer must be active now to use its viewport dimensions for the projection!

				// p_lightMVPs is a 6-matrix array
				p_graphics->SetPerspectiveProjection(90.0f, p_near, p_far);

				p_graphics->DefaultTransform();
				// make an orient out of the light's information
				// doesn't matter what the orient is since the same mvp will be sent to render the object with shadows, as long as it shines the light in the right direction
				//    from the right position
				// todo: do something different with point lights (face straight left, then right, then up, down, forward back
				for (int j = 0; j < 6; j++)
				{
					Orient3d lightOrient;
					lightOrient.LoadIdentity();
					lightOrient.p = p_light->worldPosition;

					// +x, -x, +y, -y, +z, -z, same order as OpenGL
					switch (j)
					{
					case 0: // +x
					{
						//lightOrient.Rotate(lightOrient.u, -90.0f);
						lightOrient.f = Vector3d(1, 0, 0);
						lightOrient.l = Vector3d(0, 0, -1);
					}
					break;
					case 1: // -x
					{
						//lightOrient.Rotate(lightOrient.u, 90.0f);
						lightOrient.f = Vector3d(-1, 0, 0);
						lightOrient.l = Vector3d(0, 0, 1);
					}
					break;
					case 2: // +y
					{
						//lightOrient.Rotate(lightOrient.l, 90.0f);
						lightOrient.f = Vector3d(0, 1, 0);
						lightOrient.u = Vector3d(0, 0, -1);
					}
					break;
					case 3: // -y
					{
						//lightOrient.Rotate(lightOrient.l, -90.0f);
						lightOrient.f = Vector3d(0, -1, 0);
						lightOrient.u = Vector3d(0, 0, 1);
					}
					break;
					case 4: // +z
					{
						// all done
					}
					break;
					case 5: // -z
					{
						//lightOrient.Rotate(lightOrient.u, 180.0f);
						lightOrient.f = Vector3d(0, 0, -1);
						lightOrient.l = Vector3d(-1, 0, 0);
					}
					break;
					}

					// spin so that x and y are upside down and end tex coords in render target are consistent with what shader needs to access cube during final render
					// this must happen for the results in the cube map to be usable!
					lightOrient.Rotate(lightOrient.f, 180.0f);

					p_graphics->PushMatrix();
					p_graphics->ReverseTransform(lightOrient);
					p_lightMVPs[j] = p_graphics->GetMVPMatrix();
					p_graphics->PopMatrix();
				}

				p_shaderOptions.pointLightCubeMVPRef = p_lightMVPs;
				p_shaderOptions.pointLightPositionRef = &(p_light->worldPosition);
			}

			static void PrepareSpotlightShadowFlatMapMVP(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, GraphicsShaderLight *p_light, float p_near, float p_far)
			{
				// shadowmap frame buffer must be active now to use its viewport dimensions for the projection!

				// assume a spotlight <= 45.0f degrees
				p_graphics->SetPerspectiveProjection(p_light->maxAngleDegrees * 2.0f, p_near, p_far);

				p_graphics->DefaultTransform();

				// make an orient out of the light's information
				// doesn't matter what the orient is since the same mvp will be sent to render the object with shadows, as long as it shines the light in the right direction
				//    from the right position
				Orient3d lightOrient;
				lightOrient.LoadIdentity();
				lightOrient.p = p_light->worldPosition;
				lightOrient.f = p_light->directionUnitWorldReversed.ScalarMult(-1.0f);
				lightOrient.l = Vector3d(lightOrient.f.z, 0.0f, -lightOrient.f.x);
				if (lightOrient.l.Normalize() == false)
					lightOrient.l = Vector3d(1, 0, 0);
				lightOrient.u = lightOrient.f.CrossProd(lightOrient.l);
				p_graphics->ReverseTransform(lightOrient);

				p_shaderOptions.eyeMVPMatrixRef->Set(p_graphics->GetMVPMatrix());
				p_light->shadowMVP = p_graphics->GetMVPMatrix();
			}

			static void PrepareDirectionalShadowFlatMapMVP(GraphicsBase *p_graphics, GraphicsShaderOptions %p_shaderOptions, GraphicsShaderLight *p_light, float p_near, float p_far, Vector3d &p_sceneWorldCenter, float p_sceneWorldRadius)
			{
				// shadowmap frame buffer must be active now to use its viewport dimensions for the projection!

				// p_lightMVP is a pointer to a single matrix

				// make depth buffer as accurate as possible for scene
				p_graphics->SetOrthoProjection(p_near / p_sceneWorldRadius, p_far / p_sceneWorldRadius);

				p_graphics->DefaultTransform();

				// make an orient out of the light's information
				// doesn't matter what the orient is since the same mvp will be sent to render the object with shadows, as long as it shines the light in the right direction
				//    from the right position
				// position light source a distance away and with the right scale so that nothing fails close z-depth or is rendered outside of the framebuffer
				Orient3d lightOrient;
				lightOrient.LoadIdentity();
				// note: we need to scale this because we are scaling the environment, which is not centered on 0,0,0 - same would be true if this was a perspective projection
				lightOrient.p = p_sceneWorldCenter.ScalarMult(1.0f / (p_sceneWorldRadius + 0.1f));
				lightOrient.f = p_light->directionUnitWorldReversed.ScalarMult(-1.0f);
				lightOrient.l = Vector3d(lightOrient.f.z, 0.0f, -lightOrient.f.x);
				if (lightOrient.l.Normalize() == false)
					lightOrient.l = Vector3d(1, 0, 0);
				lightOrient.u = lightOrient.f.CrossProd(lightOrient.l);
				lightOrient.p = lightOrient.p - lightOrient.f.ScalarMult(p_sceneWorldRadius * 10.0f + 0.01f / p_sceneWorldRadius); // include nearZ - the * 10.0f just makes sure z doesn't fail close
				p_graphics->ReverseTransform(lightOrient);

				// scale it so we don't miss anything
				p_graphics->Scale(1.0f / (p_sceneWorldRadius + 0.1f), 1.0f / (p_sceneWorldRadius + 0.1f), 1.0f / (p_sceneWorldRadius + 0.1f));
				p_shaderOptions.eyeMVPMatrixRef->Set(p_graphics->GetMVPMatrix());
				p_light->shadowMVP = p_graphics->GetMVPMatrix();
			}
		};

		class GraphicsLightShadowMapAssignment
		{
		public:
			GraphicsShaderLight *lightRef;
			GraphicsFrameBufferContainer *shadowMapArrayRef;
			int arrayIndex;
			bool locked; // CANNOT reassign this light!!

			GraphicsLightShadowMapAssignment()
			{
				lightRef = nullptr;
				shadowMapArrayRef = nullptr;
				arrayIndex = -1;
				locked = false;
			}

			void Clear()
			{
				if (lightRef != nullptr)
				{
					lightRef->shadowMapFrameBufferRef = nullptr;
					lightRef->shadowMapTextureRef = nullptr;

					// force light to re-prepare shadow map entirely if it is parsed again for the current main render
					lightRef->shadowNodesPrepared.Clear();
					lightRef->renderId = -1;

					lightRef = nullptr;
					shadowMapArrayRef = nullptr;
					arrayIndex = -1;
					locked = false;
				}
			}
		};

		// class that stores shadowmaps and keeps them ready for lights that need them
		// using:
		// 0 - during render, check ShadowMapsCreated.  If they aren't create them using CreateShadowMaps(graphics)
		// 1 - ClearAssignments() at very beginning of PerformRender - this assumes that all assigned lights somehow have changed and MUST have everything cleared, which is fair because objects move,
		//      etc. and shadowmaps just need to be rerendered.
		// (as a rule of thumb, light types should be set before the render and should NEVER change DURING the render - that will confuse this registry)
		// 2 - when you have the lights you know you will be using to render:
		//   - loop through the lights that already have shadowmaps assigned and lock them (Lock(light))
		//   - loop through the lights that do not have shadowmaps assigned and assign them (AssignShadowMap(light))
		//   - copy the lights into shaderOptions by using Set() for the render
		// once assigned, a light type should NOT change, since assignments depend on the shadow type!!! (in other words, ONLY assign during rendering, and NEVER change the light type during rendering)
		// note: assignments can be left over after rendering, but those assignments should be cleared as rendering starts to wipe out any problems with lights that changed since
		class GraphicsShadowMapRegistry
		{
		private:
			GraphicsFrameBufferContainer *flatShadowMapBuffers;
			GraphicsFrameBufferContainer *cubeShadowMapBuffers;
			GraphicsFrameBufferContainer *hiresShadowMapBuffers;

			int flatShadowMapQty;
			int cubeShadowMapQty;
			int hiresShadowMapQty;

			int shadowMapTextureDimension;
			int hiresShadowMapTextureDimension;

			// assignment arrays correspond exactly to buffer arrays, for now, until code is made mroe friendly to find the first unlocked AND unassigned buffer
			GraphicsLightShadowMapAssignment *flatAssignments;
			GraphicsLightShadowMapAssignment *cubeAssignments;
			GraphicsLightShadowMapAssignment *hiresAssignments;

			// helps avoid needing to re-render shadowmaps with many available
			int lastFlatMapAssigned;
			int lastCubeMapAssigned;
			int lastHiresMapAssigned;

		public:
			GraphicsShadowMapRegistry(int p_flatShadowMapQty, int p_cubeShadowMapQty, int p_hiresShadowMapQty, int p_shadowMapTextureDimension, int p_hiresShadowMapTextureDimension)
			{
				flatShadowMapBuffers = nullptr;
				cubeShadowMapBuffers = nullptr;
				hiresShadowMapBuffers = nullptr;

				flatShadowMapQty = p_flatShadowMapQty;
				cubeShadowMapQty = p_cubeShadowMapQty;
				hiresShadowMapQty = p_hiresShadowMapQty;

				shadowMapTextureDimension = p_shadowMapTextureDimension;
				hiresShadowMapTextureDimension = p_hiresShadowMapTextureDimension;

				flatAssignments = new GraphicsLightShadowMapAssignment[flatShadowMapQty];
				cubeAssignments = new GraphicsLightShadowMapAssignment[cubeShadowMapQty];
				hiresAssignments = new GraphicsLightShadowMapAssignment[hiresShadowMapQty];

				lastFlatMapAssigned = -1;
				lastCubeMapAssigned = -1;
				lastHiresMapAssigned = -1;
			}

			~GraphicsShadowMapRegistry()
			{
				if (flatShadowMapBuffers != nullptr)
				{
					delete[] flatShadowMapBuffers;
					flatShadowMapBuffers = nullptr;
					flatShadowMapQty = 0;
				}
				if (cubeShadowMapBuffers != nullptr)
				{
					delete[] cubeShadowMapBuffers;
					cubeShadowMapBuffers = nullptr;
					cubeShadowMapQty = 0;
				}
				if (hiresShadowMapBuffers != nullptr)
				{
					delete[] hiresShadowMapBuffers;
					hiresShadowMapBuffers = nullptr;
					hiresShadowMapQty = 0;
				}
				if (flatAssignments != nullptr)
				{
					delete[] flatAssignments;
					flatAssignments = nullptr;
				}
				if (cubeAssignments != nullptr)
				{
					delete[] cubeAssignments;
					cubeAssignments = nullptr;
				}
				if (hiresAssignments != nullptr)
				{
					delete[] hiresAssignments;
					hiresAssignments = nullptr;
				}
			}

			bool ShadowMapsCreated()
			{
				return (flatShadowMapBuffers != nullptr || cubeShadowMapBuffers != nullptr || hiresShadowMapBuffers != nullptr);
			}

			void CreateShadowMaps(GraphicsBase *p_graphics)
			{
				if (flatShadowMapQty != 0)
				{
					flatShadowMapBuffers = new GraphicsFrameBufferContainer[flatShadowMapQty];
					for (int i = 0; i < flatShadowMapQty; i++)
					{
						p_graphics->CreateFrameBuffer(&(flatShadowMapBuffers[i]), GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, shadowMapTextureDimension, shadowMapTextureDimension);
					}
				}
				if (cubeShadowMapQty != 0)
				{
					cubeShadowMapBuffers = new GraphicsFrameBufferContainer[cubeShadowMapQty];
					for (int i = 0; i < cubeShadowMapQty; i++)
					{
						p_graphics->CreateFrameBuffer(&(cubeShadowMapBuffers[i]), GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, shadowMapTextureDimension, shadowMapTextureDimension, 6);
					}
				}
				if (hiresShadowMapQty != 0)
				{
					hiresShadowMapBuffers = new GraphicsFrameBufferContainer[hiresShadowMapQty];
					for (int i = 0; i < hiresShadowMapQty; i++)
					{
						p_graphics->CreateFrameBuffer(&(hiresShadowMapBuffers[i]), GraphicsFrameBufferTypeEnum::None, GraphicsFrameBufferTypeEnum::Texture, hiresShadowMapTextureDimension, hiresShadowMapTextureDimension);
					}
				}
			}

			void ClearLocks()
			{
				// if in the registry this light has an assignment, lock it!  Check all 3 assignments.
				for (int i = 0; i < hiresShadowMapQty; i++)
				{
					hiresAssignments[i].locked = false;
				}
				for (int i = 0; i < flatShadowMapQty; i++)
				{
					flatAssignments[i].locked = false;
				}
				for (int i = 0; i < cubeShadowMapQty; i++)
				{
					cubeAssignments[i].locked = false;
				}
			}

			void LockShadowMap(GraphicsShaderLight *p_light)
			{
				// if in the registry this light has an assignment, lock it!  Check all 3 assignments.
				bool done = false;
				for (int i = 0; i < flatShadowMapQty; i++)
				{
					if (flatAssignments[i].lightRef == p_light)
					{
						flatAssignments[i].locked = true;
						done = true;
						break;
					}
				}
				if (done == false)
				{
					for (int i = 0; i < cubeShadowMapQty; i++)
					{
						if (cubeAssignments[i].lightRef == p_light)
						{
							cubeAssignments[i].locked = true;
							done = true;
							break;
						}
					}
				}
				if (done == false)
				{
					for (int i = 0; i < hiresShadowMapQty; i++)
					{
						if (hiresAssignments[i].lightRef == p_light)
						{
							hiresAssignments[i].locked = true;
							done = true;
							break;
						}
					}
				}

				if (done == false)
					throw gcnew Exception("Unable to lock light");
			}

			void ClearAssignments()
			{
				for (int i = 0; i < flatShadowMapQty; i++)
				{
					flatAssignments[i].Clear();
				}
				for (int i = 0; i < cubeShadowMapQty; i++)
				{
					cubeAssignments[i].Clear();
				}
				for (int i = 0; i < hiresShadowMapQty; i++)
				{
					hiresAssignments[i].Clear();
				}
			}

			void AssignShadowMap(GraphicsShaderLight *p_light)
			{
				// todo: if already assigned, error

				if (p_light->type == GraphicsShaderCompositionLightType::Directional)
				{
					// always hires
					bool found = false;
					for (int i = 0; i < hiresShadowMapQty; i++)
					{
						lastHiresMapAssigned++;
						if (lastHiresMapAssigned >= hiresShadowMapQty)
							lastHiresMapAssigned = 0;
						if (hiresAssignments[lastHiresMapAssigned].locked == false)
						{
							found = true;

							// clear existing assignment
							hiresAssignments[lastHiresMapAssigned].Clear();

							p_light->shadowMapFrameBufferRef = &hiresShadowMapBuffers[lastHiresMapAssigned];
							p_light->shadowMapTextureRef = hiresShadowMapBuffers[lastHiresMapAssigned].depthBufferTexture;
							hiresAssignments[lastHiresMapAssigned].lightRef = p_light;
							// no real need for this right now, but will be later when assign is made more friendly
							hiresAssignments[lastHiresMapAssigned].shadowMapArrayRef = hiresShadowMapBuffers;
							hiresAssignments[lastHiresMapAssigned].arrayIndex = lastHiresMapAssigned;
							hiresAssignments[lastHiresMapAssigned].locked = true;

							break;
						}
					}
					if (found == false)
						throw gcnew Exception("Unable to assign hires shadow map");
				}
				else if (p_light->shadowMapType == GraphicsShaderCompositionLightShadowMapType::FlatMap)
				{
					bool found = false;
					for (int i = 0; i < flatShadowMapQty; i++)
					{
						lastFlatMapAssigned++;
						if (lastFlatMapAssigned >= flatShadowMapQty)
							lastFlatMapAssigned = 0;
						if (flatAssignments[lastFlatMapAssigned].locked == false)
						{
							found = true;

							// clear existing assignment
							flatAssignments[lastFlatMapAssigned].Clear();

							p_light->shadowMapFrameBufferRef = &flatShadowMapBuffers[lastFlatMapAssigned];
							p_light->shadowMapTextureRef = flatShadowMapBuffers[lastFlatMapAssigned].depthBufferTexture;
							flatAssignments[lastFlatMapAssigned].lightRef = p_light;
							// no real need for this right now, but will be later when assign is made more friendly
							flatAssignments[lastFlatMapAssigned].shadowMapArrayRef = flatShadowMapBuffers;
							flatAssignments[lastFlatMapAssigned].arrayIndex = lastFlatMapAssigned;
							flatAssignments[lastFlatMapAssigned].locked = true;

							break;
						}
					}
					if (found == false)
						throw gcnew Exception("Unable to assign flat shadow map");
				}
				else if (p_light->shadowMapType == GraphicsShaderCompositionLightShadowMapType::CubeMap)
				{
					bool found = false;
					for (int i = 0; i < cubeShadowMapQty; i++)
					{
						lastCubeMapAssigned++;
						if (lastCubeMapAssigned >= cubeShadowMapQty)
							lastCubeMapAssigned = 0;
						if (cubeAssignments[lastCubeMapAssigned].locked == false)
						{
							found = true;

							// clear existing assignment
							cubeAssignments[lastCubeMapAssigned].Clear();

							p_light->shadowMapFrameBufferRef = &cubeShadowMapBuffers[lastCubeMapAssigned];
							p_light->shadowMapTextureRef = cubeShadowMapBuffers[lastCubeMapAssigned].depthBufferTexture;
							cubeAssignments[lastCubeMapAssigned].lightRef = p_light;
							// no real need for this right now, but will be later when assign is made more friendly
							cubeAssignments[lastCubeMapAssigned].shadowMapArrayRef = cubeShadowMapBuffers;
							cubeAssignments[lastCubeMapAssigned].arrayIndex = lastCubeMapAssigned;
							cubeAssignments[lastCubeMapAssigned].locked = true;

							break;
						}
					}
					if (found == false)
						throw gcnew Exception("Unable to assign cube shadow map");
				}
			}
		};
	}
}