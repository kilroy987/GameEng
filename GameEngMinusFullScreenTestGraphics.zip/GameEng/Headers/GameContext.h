#pragma once

#include "GameFontRegistry.h"
#include "GameFileResourceRegistry.h"
#include "GameTextureRegistry.h"
#include "Tools.h"
#include "GameNetwork.h"
#include "GameBase.h"

namespace GameEng {
	namespace UI {
		// this is here so that GameContext can return something meaningful with GameUI forms and controls need access to the parent UI class
		using namespace GameEng::Storage;
		using namespace GameEng::Graphics;

		class GameUIControlBase
		{

		};
		class GameUIFormBase
		{
		public:
			virtual void Close() = 0;
			virtual bool IsClosed() = 0;
		};
		class GameUIBase
		{
		public:
			virtual void ShowForm(GameUIFormBase *p_form, bool p_modal = false) = 0;
			virtual void CloseForm(GameUIFormBase *p_form) = 0;
			virtual void CloseAllForms() = 0;
			virtual void HideForm(GameUIFormBase *p_form) = 0;
			virtual void HideControl(GameUIControlBase *p_control) = 0;
			virtual void SetControlFocus(GameUIFormBase *p_form, GameUIControlBase *p_control) = 0;
			virtual void MoveFormToFront(GameUIFormBase *p_form) = 0;
			virtual void MoveFocusToNextControl(bool p_forward = true) = 0;
			virtual void ResetCaret() = 0;
			virtual bool CaretIsVisible() = 0;
			virtual GameUIFormBase * MessageBox(String ^p_string, bool p_userClosable = true, bool p_userCloseByEscOnly = false) = 0;
			virtual GameUIFormBase * MessageBox(LinkedList<GameRichText> &p_richText, bool p_userClosable = true, bool p_userCloseByEscOnly = false) = 0;
		};
	}
	namespace Game {

		using namespace System; // String
		using namespace GameEng::Graphics;
		using namespace GameEng::Resource;
		using namespace GameEng::Tools::Metrics;
		using namespace GameEng::Network;
		using namespace GameEng::UI;

		// app-level resources include viewports and should not be destroyed just because the game itself is destroyed.
		// - another game structure could be created with the same app that reuses the viewports registered, input structures initialized, etc.
		// however, whenever a game is destroyed, any data resources or graphics initialized for that game should be destroyed
		// currently, the Name of each viewport is left intact - but ideally, each game should be able to name its own viewports as needed, and the app level
		//   should never access the viewports by name (index is ok) after initializing them, except to destroy them when the application ends.

		public ref class GameContext
		{
			// a singleton instance that is reference statically throughout the framework

		public:
			static property GameContext^ Instance { GameContext^ get() { return %instance; }}

			static String ^Name; // name of game
			static GameFontRegistry FontRegistry; // any fonts to display using renderer
			static GameMetrics Metrics;
			static GameFileResourceRegistry FileRegistry; // any files needing loading
			static GameTextureRegistry TextureRegistry; // specific on textures and the files they use
			static System::Collections::Generic::List<System::String^> Log;
			static bool LoggingEnabled;

			// provides implementation data class access to network for purposes of sending packets to other machines
			static GameNetworkBase *networkRef; // NOT destroyed, only set to nullptr - implementation is responsible for holding, creating and destroying its network
			static GameUIBase *uiRef; // NOT destroyed, only set to nullptr - implementation responsible for destroying it
			static GameBase ^gameRef; // reference to game

		private:
			GameContext()
			{
				Name = "";
				LoggingEnabled = false;
				networkRef = nullptr;
				uiRef = nullptr;
				gameRef = nullptr;
			}
			GameContext(const GameContext%) { throw gcnew Exception("singleton cannot be copy constructed"); }
			static GameContext instance;

		public:
			// cannot have destructor on static class
			//virtual ~GameContext()
			//{
			//	Destroy();
			//}

			void Destroy()
			{
				DestroyApp();
			}

			// ending the game on this process - might start up another one
			void DestroyGame()
			{
				// todo: Get rid of game specific structures, leave app-level resources alone
				// todo: Asusming only 1 viewport and renderer for now, getting rid of resources for that renderer.  Later, will need to support more
				//   than 1 viewport which supports more than one rendering context, each with their own resources (like textures, etc.)

				FontRegistry.Clear();
				FileRegistry.Clear();
				TextureRegistry.Clear();
				Log.Clear();

				networkRef = nullptr;
				uiRef = nullptr;
				gameRef = nullptr;
			}

			// ending the program
			void DestroyApp()
			{
				DestroyGame();

				// get rid of app-level resources
				FontRegistry.Destroy();
				FileRegistry.Destroy();
				TextureRegistry.Destroy();
			}

			// call when ending the game, or changing graphics provider
			void StopGraphicsRenderer(GraphicsBase &p_currentGraphics)
			{
				FontRegistry.ClearRendererResources(p_currentGraphics); // get rid of font-specific resources for that renderer
				TextureRegistry.ClearRendererResources(p_currentGraphics); // get rid of texture-specific resources for that renderer
			}

			void AddLog(System::String ^p_message)
			{
				if (LoggingEnabled == true)
				{
					while (Log.Count > 200)
						Log.RemoveAt(0);
					Log.Add(p_message);
				}
			}

			void SetNetwork(GameNetworkBase *p_network)
			{
				networkRef = p_network;
			}
			GameNetworkBase *  GetNetwork()
			{
				if (networkRef == nullptr)
					throw gcnew Exception("Network not registered.  In game Initialize(), call GameContext::Instance->SetNetwork(network)");
				return networkRef;
			}

			void SetUI(GameUIBase *p_ui)
			{
				uiRef = p_ui;
			}
			GameUIBase * GetUI()
			{
				if (uiRef == nullptr)
					throw gcnew Exception("UI not registered.  In game Initialize(), call GameContext::Instance->SetUI(ui)");

				return uiRef;
			}

			void SetGame(GameBase ^p_game)
			{
				gameRef = p_game;
			}
			GameBase ^ GetGame()
			{
				if (gameRef == nullptr)
					throw gcnew Exception("Game not registered.  In game Initialize(), call GameContext::Instance->SetGame(this)");

				return gameRef;
			}
		};
	}
}