#pragma once

#include <stdlib.h> // srand, rand

namespace GameEng {
	namespace Tools {

		namespace Random {
			// uses the L'Ecuyer algorithm to generate random numbers
			class LecuyerRandom {

			private:
				double s10, s11, s12, s13, s14, s20, s21, s22, s23, s24;

			public:
				LecuyerRandom()
				{
					Seed(System::DateTime::Now.Ticks & 0xffffffff);
				}

				LecuyerRandom(unsigned int p_seed)
				{
					Seed(p_seed);
				}

				void Seed(int p_seed)
				{
					// seed it using windows' rng
					srand(p_seed);

					// So the values can be accessed in the debugger (s10, s11, etc. are global and won't show up in scope)
					double inits10 = rand();
					double inits11 = rand();
					double inits12 = rand();
					double inits13 = rand();
					double inits14 = rand();

					double inits20 = rand();
					double inits21 = rand();
					double inits22 = rand();
					double inits23 = rand();
					double inits24 = rand();

					s10 = inits10;
					s11 = inits11;
					s12 = inits12;
					s13 = inits13;
					s14 = inits14;

					s20 = inits20;
					s21 = inits21;
					s22 = inits22;
					s23 = inits23;
					s24 = inits24;
				}

			private:
				double Rng()
				{
					double norm = 2.3283163396834613e-10;
					double m1 = 4294949027.0;
					double m2 = 4294934327.0;
					double a12 = 1154721.0;
					double a14 = 1739991.0;
					double a15n = 1108499.0;
					double a21 = 1776413.0;
					double a23 = 865203.0;
					double a25n = 1641052.0;

					long k;
					double p1, p2;

					/* Component 1 */
					p1 = a12*s13 - a15n*s10;
					if (p1 > 0.0) p1 -= a14*m1;
					p1 += a14*s11;
					k = (long)(p1 / m1);
					p1 -= ((double)(k))*m1;
					if (p1 < 0.0) p1 += m1;
					s10 = s11;
					s11 = s12;
					s12 = s13;
					s13 = s14;
					s14 = p1;

					/* Component 2 */
					p2 = a21*s24 - a25n * s20;
					if (p2 > 0.0) p2 -= a23 * m2;
					p2 += a23*s22;
					k = (long)(p2 / m2);
					p2 -= ((double)(k))*m2;
					if (p2 < 0.0) p2 += m2;
					s20 = s21;
					s21 = s22;
					s22 = s23;
					s23 = s24;
					s24 = p2;

					/* Debugging only */
					double localS10 = s10;
					double localS11 = s11;
					double localS12 = s12;
					double localS13 = s13;
					double localS14 = s14;
					double localS20 = s20;
					double localS21 = s21;
					double localS22 = s22;
					double localS23 = s23;
					double localS24 = s24;

					/* Combination */
					if (p1 <= p2)
					{
						return ((double)((p1 - p2 + m1)*norm));
					}
					else
					{
						return ((double)((p1 - p2)*norm));
					}
				}

			public:
				// result: 0.0 to 0.999999
				float GetRandomFloat()
				{
					return float(Rng());
				}

				// suitable for up to 8 digits between p_min and p_max
				int GetRandomInteger(int p_min, int p_max)
				{
					double rng = Rng();

					// just in case
					if (rng <= 0.0) rng = 0.0;
					if (rng >= 1.0f) rng = 0.99999999;

					int result = p_min + int((p_max - p_min + 1) * rng);
					return result;
				}
			};

			// repeats every 65536 calls
			class FastRandom {
				// based on
				// http://engr.case.edu/merat_francis/eeap282f97/labs/Random_Lab.pdf

				int seed;
				const int multiplier = 25173;
				const int increment = 13849;
				const int modulus = 65536;

			public:
				FastRandom()
				{
					Seed(System::DateTime::Now.Ticks & 0xffff);
				}

				FastRandom(int p_seed)
				{
					Seed(p_seed % modulus);
				}

				void Seed(int p_seed)
				{
					seed = p_seed;
				}

			private:
				int Rng()
				{
					seed = (multiplier * seed + increment) % modulus;
					return seed;
				}

			public:
				// result: 0 to 65535
				int GetRandom()
				{
					return Rng();
				}

				int GetRandomInteger(int p_min, int p_max)
				{
					return p_min + (unsigned int)(((p_max - p_min + 1) * Rng()) / modulus);
				}
			};

		} // namespace Random

		namespace Timer {

#define CONVERT_FROM_DATETIMETICKS_TO_MILLISECONDS 10000

			// deals with game time in milliseconds

			// when game starts, call ResetGameTime
			// when elapsed time between two ticks has been fully applied, call ResetElapsedTime
			// Important: GetGameTimeMS() should be the basis for the any times recorded within the game, such as lastTimeUpdated, or current game time, etc.
			//
			// Specs:
			// GameTimeMS on a system where GameTimeMS is never adjusted usually starts at 0 and proceeds forward at the same rate as the system clock, and is the
			//    basis for syncing the game times between the host machine (where GameTimeMS is never adjusted after the game starts) and the clients (half ping is added to the
			//    gameTime sent by the server to determine the client time - use the smallest ping for this.)
			// Once GameTimeMS is set on a client and the game state is sent down from the host, all of the objects on a client should be caught up to the gameTimer's gameTimeMS in Animate().
			//    Track this GameTimeMS for that tick in a variable in the game data, because after Animate(), in network->Process(), it is possible to get more gameTimeMS adjustments due to 
			//    a smaller ping.  This should affect the next tick's elapsedTimeMS, resulting in a pause as it catches up to zero again or extra elapsed time to advance the gamestate.
			//    Until that happens, further object sends from teh host should always use the tracked gameTimeMS to catch them up to the local gamestate, NOT the timer's gameTimeMS, since that
			//    isn't guaranteed to match the gamestate.  If the gamestate doesn't need all obejcts to have the same gametime at the end of Animate() for consistency, this doesn't matter.  But keeping
			//    object values within the same domain so that from one Animate to the next the entire game state updated from one gameTimeMS to another, that helps with interpolating for
			//    collision detection between two objects.
			// currentTime should NEVER be altered.  that is the basis for PureTimeMS() which is used to determine pings.
			class GameTimer
			{
				_int64 currentTime;

				_int64 gameTimeConversion;

				unsigned long gameTimeMS; // good for 49.7 days - might want to reset your game by then...
				unsigned long priorGameTimeMS;
				unsigned long elapsedTimeMS;
				float elapsedTimeMSf;
				bool paused;
				_int64 pausedGameTime;

			public:
				GameTimer()
				{
					paused = false; // do this first so that Poll works
					Poll();
					ResetGameTime();
					ResetElapsedTime();
				}

				// note: Pausing is discouraged in multiplayer games - but it is possible, you'll just need to communicate the amount of gameTimeConversion adjustment to all clients
				//   when the game is unpaused, in addition to any other problem solving
				void Pause()
				{
					if (paused == false)
					{
						paused = true;
						pausedGameTime = System::DateTime::Now.Ticks;
					}
				}

				_int64 Unpause()
				{
					if (paused == true)
					{
						paused = false;
						// alter conversion so that game time proceeds forward naturally after unpause
						_int64 gameTimeConversionAdjustment = System::DateTime::Now.Ticks - pausedGameTime;
						gameTimeConversion += gameTimeConversionAdjustment;
						ResetElapsedTime();
						return gameTimeConversionAdjustment;
					}
					else
						return 0;
				}

				bool IsPaused()
				{
					return paused;
				}

				void Poll()
				{
					if (paused == false)
					{
						currentTime = System::DateTime::Now.Ticks; // not sure why we need System:: here, had to add it after adding Metrics class

						gameTimeMS = (unsigned long)((currentTime - gameTimeConversion) / CONVERT_FROM_DATETIMETICKS_TO_MILLISECONDS);

						elapsedTimeMS = gameTimeMS - priorGameTimeMS;
						elapsedTimeMSf = float(elapsedTimeMS);
					}
					else
					{
						elapsedTimeMS = 0;
						elapsedTimeMSf = 0;
					}
				}

				// when an app needs to set its local game time explicitly - for instance, a client asks the server what its game time is and sets its own to be in sync
				// Use this to start a game's time at 0 on a host or local-only machine
				void SetGameTime(unsigned long p_gameTimeMS)
				{
					Poll(); // get current time
					gameTimeConversion = currentTime - _int64(p_gameTimeMS) * CONVERT_FROM_DATETIMETICKS_TO_MILLISECONDS;
					gameTimeMS = unsigned long((currentTime - gameTimeConversion) / CONVERT_FROM_DATETIMETICKS_TO_MILLISECONDS); // should get same values as p_gameTimeMS
					if (gameTimeMS != p_gameTimeMS)
						throw gcnew System::Exception("Setting of game time failed");
					ResetElapsedTime();
				}

				// Adjusting the game time affects the next tick's elapsed time.  After adjusting, Animate() and setting of gamestate's gameTimeMS should not be called 
				//   until elapsedTimeMS > 0, and always, new object updates from
				//   the server should be caught up to the gameTimeMS stored by Animate() that notes the time of the game state, NOT the new gameTimeMS set here.
				// Setting the gametime to a value higher than its current value causes a negative adjustment to the next elapsedTimeMS on a Poll()
				// After a client's gameTime has been set by SetGameTime() and a gamestate with objects based on that gametime now exists, ONLY call this routine to
				//   adjust the gamestate and do not animate when elapsedTimeMS <= 0.  Until then, continue to use the gamestate's tracked gameTimeMS to catch new objects
				//   from the server up to the current gamestate for consistency.
				// Adjusting the gametime from 300 to 400 will add an additional 100ms to the next Poll()'s elapsed time, causing the gamestate to advance extra
				// Adjusting the gametime from 400 to 300 will subtract from the next Poll()'s elapsed time, requiring the gamestate to not advance until 400 is reached again
				//   (that is, elapsedTime > 0 again), since the gamestate is not typically updated backwards.
				// Important: In extreme circumstance, it is possible for a server to send an object update with a gameTimeMS that is actually AFTER the current game state's gameTime.
				//   In these circumstances, the gamestate should support moving the object backwards to place it properly.  But this should be extremely rare given the approximation
				//   of gamestate due to smallest ping and the continued latency of data sends.
				void AdjustGameTime(unsigned long p_gameTimeMS)
				{
					gameTimeConversion += ((int(gameTimeMS) - int(p_gameTimeMS)) * CONVERT_FROM_DATETIMETICKS_TO_MILLISECONDS);
					gameTimeMS = p_gameTimeMS;
				}

				void ResetGameTime()
				{
					SetGameTime(0);
					ResetElapsedTime();
				}

				void ResetElapsedTime()
				{
					priorGameTimeMS = gameTimeMS;
					elapsedTimeMS = 0;
					elapsedTimeMSf = 0;
				}

				unsigned long GetElapsedTimeMS()
				{
					return elapsedTimeMS;
				}

				float GetElapsedTimeMSFloat()
				{
					return elapsedTimeMSf;
				}

				unsigned long GetGameTimeMS()
				{
					return gameTimeMS;
				}

				unsigned int GetPureTimeMS() // cycles every 49.7 days
				{
					return (currentTime / CONVERT_FROM_DATETIMETICKS_TO_MILLISECONDS) & 0xffffffff;
				}
			};
		} // namespace Timer

		public ref class FramesPerSecondMetric
		{
#define FRAMESPERSECOND_FRAME_COUNT 20
			array<int,1> ^frameMS;
			int frameCount;
			float framesPerSecond;

		public:
			FramesPerSecondMetric()
			{
				frameMS = gcnew array<int, 1>(FRAMESPERSECOND_FRAME_COUNT);
			}

			// can't do this since it is part of a static class (no destructor allowed)
			//~FramesPerSecondMetric()
			//{
			//	if (frameMS != nullptr)
			//	{
			//		delete frameMS;
			//		frameMS = nullptr;
			//	}
			//}

			void Reset()
			{
				frameCount = 0;
				framesPerSecond = 0.0f;
			}

			float GetFramesPerSecond()
			{
				return framesPerSecond;
			}

			void SubmitFrameMS(int p_frameMS)
			{
				if (p_frameMS < 0)
					return;

				if (frameCount < FRAMESPERSECOND_FRAME_COUNT)
				{
					frameMS[frameCount] = p_frameMS;
					frameCount++;
				}
				else
				{
					// copy all the values up one and put the value at the end
					// todo: this could be faster, but CopyMemory isn't allowed
					for (int i = 0; i < frameCount - 1; i++)
						frameMS[i] = frameMS[i+1];

					// frameCount = FRAMESPERSECOND_FRAME_COUNT right now
					frameMS[frameCount-1] = p_frameMS;
				}

				CalculateFramesPerSecond();
			}

		private:
			void CalculateFramesPerSecond()
			{
				int totalFrameMS = 0;
				int totalSeconds = 0;
				for (int i = 0; i < frameCount; i++)
				{
					totalFrameMS += frameMS[i];
					totalSeconds += 1000;
				}

				if (totalFrameMS > 0)
					framesPerSecond = float((totalSeconds * 10 / totalFrameMS) / 10.0f); // 1 decimal place
				else
					framesPerSecond = 0.0f;
			}
		};

		public ref class CountMetric
		{
		private:
			unsigned int count;

		public: 
			CountMetric()
			{
				Clear();
			}

			void Clear()
			{
				count = 0;
			}

			void Increase(unsigned int p_qty)
			{
				count += p_qty;
			}

			unsigned int GetCount()
			{
				return count;
			}

		};

		public ref class StopwatchMetric
		{
		private:
			_int64 beginTicks;
			//_int64 endTicks;
			_int64 totalTicks;
			bool started;
			System::Diagnostics::Stopwatch stopWatch;  // apparently it's higher resolution than DateTime::Now.Ticks

		public:
			StopwatchMetric()
			{
				Reset();
			}

			void Reset()
			{
				totalTicks = 0;
				started = false;
				//stopWatch.Reset();
			}

			void Start()
			{
				_int64 ticksTemp;
				QueryPerformanceCounter((LARGE_INTEGER *)&ticksTemp);
				beginTicks = ticksTemp;
				started = true;
				//stopWatch.Start();
			}

			void Stop()
			{
				if (started == true)
				{
					_int64 nowTicks;
					QueryPerformanceCounter((LARGE_INTEGER *)&nowTicks);
					totalTicks += _int64(nowTicks - beginTicks);
					started = false;
				}
				//stopWatch.Stop();
			}

			int GetElapsedMS()
			{
				_int64 freq;
				QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
				return int(totalTicks * (1000.0f / freq)); // translates seconds to ms
				//return int(stopWatch.ElapsedTicks / 10000);
			}
		};

		namespace Metrics {
			public ref class GameMetrics
			{
			private:

			public:
				CountMetric RenderedTriangles;
				CountMetric RenderedPoints;
				CountMetric RenderedLines;
				CountMetric RenderedVertexArrays;
				FramesPerSecondMetric FramesPerSecond;
				StopwatchMetric PreppingVAOTimer;
				StopwatchMetric RenderingVAOTimer;
				StopwatchMetric RenderingTerrainTimer;
				StopwatchMetric SwapBuffersTimer;
				StopwatchMetric RenderingTimer;
				StopwatchMetric GameloopTimer;
				StopwatchMetric WindowsIdleTimer;
				StopwatchMetric FullLoopTimer;
				StopwatchMetric FinishRenderTimer;

				GameMetrics()
				{
					RenderedTriangles.Clear();
					RenderedPoints.Clear();
					RenderedLines.Clear();
					RenderedVertexArrays.Clear();
					FramesPerSecond.Reset();
				}
			};
		} // namespace Metrics

		public class Utilities
		{
		public:
			// todo: this is really really slow.  But it serves the purpose.  Don't use too often.
			static void CopyStringToCharArray(char *p_Dest, System::String ^p_Source)
			{
				int length = p_Source->Length;
				for (int i = 0; i<length; i++)
				{
					char c = (char)p_Source[i];
					//char c = i % 10 + 48;
					p_Dest[i] = c;
				}
				p_Dest[length] = '\0';
			}
		};
	}
}