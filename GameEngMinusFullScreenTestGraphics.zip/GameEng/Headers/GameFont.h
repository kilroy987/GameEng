#pragma once

#include "LinkedListTemplate.h"
#include "GameColor.h"
#include <vcclr.h> // gcroot
#include <math.h>

namespace GameEng {
	namespace Graphics {

		using namespace System;
		using namespace GameEng::Storage;

		public ref class GameFontRendererResource
		{
		public:
			void *rendererResource; // instance, not a reference, so this has to be destroyed at the renderer level before the parnet object is destroyed

			GameFontRendererResource()
			{
				rendererResource = nullptr;
			}

			void SetResource(void *p_resource)
			{
				rendererResource = p_resource;
			}

			void ClearResource()
			{
				// do this after the renderer has destroyed what this is pointing to - the renderer will have to cast its own type to this void pointer
				rendererResource = nullptr;
			}
		};

		class GameFontCharacter
		{
		public:
			bool valid;

			unsigned int width;
			unsigned int height; // usually the height of the font

			unsigned int textureBeginS;
			unsigned int textureBeginT;
			unsigned int textureEndS;
			unsigned int textureEndT;
		};

		public ref class GameFont
		{
		private:
			System::Drawing::Font ^windowsFont;
			GameFontRendererResource ^rendererResource; // resource specific to the rendering API, if needed - destroy this at the renderer level before destroying the GameFont
			unsigned char *alphaTextureBytes; // storage used to generate texture (usable by both DirectX and OpenGL) - alpha texture used by renderer with modulate
			int textureWidth;
			int textureHeight;

			int fontHeight;

			GameFontCharacter *characters; // need to allocate storage because main class is a ref

		public:
			GameFont(System::Drawing::Font ^p_font)
			{
				windowsFont = p_font;
				rendererResource = gcnew GameFontRendererResource();

				alphaTextureBytes = nullptr; // number of bytes = textureWidth * textureHeight
				textureWidth = 0;
				textureHeight = 0;

				fontHeight = 0;

				characters = new GameFontCharacter[256]; // allocate
			}

			virtual ~GameFont()
			{
				Destroy();
			}

			void Destroy()
			{
				if (alphaTextureBytes != nullptr)
				{
					delete[] alphaTextureBytes;
					alphaTextureBytes = nullptr;
					textureWidth = 0;
					textureHeight = 0;

					fontHeight = 0;
				}

				if (windowsFont != nullptr)
				{
					delete windowsFont;
					windowsFont = nullptr;
				}

				// note: internal resource for this object should already have been destroyed
				if (rendererResource != nullptr)
				{
					delete rendererResource;
					rendererResource = nullptr;
				}

				if (characters != nullptr)
				{
					delete[] characters;
					characters = nullptr;
				}
			}

			GameFontRendererResource ^GetRendererResource()
			{
				return rendererResource;
			}

			unsigned char * GetAlphaStorage()
			{
				return alphaTextureBytes;
			}

			bool AlphaTextureStorageIsEmpty()
			{
				if (alphaTextureBytes == nullptr)
					return true;
				else
					return false;
			}

			void GenerateAlphaTextureBytes()
			{
				if (alphaTextureBytes == nullptr)
				{
					// render text to a picture box, sample to get dimensions (power of 2 on each axis, max 512x512, otherwise exception)
					System::Windows::Forms::PictureBox ^pictureBox = gcnew System::Windows::Forms::PictureBox();
					pictureBox->Width = 100; // single character can't be more than 100 pixels wide
					pictureBox->Height = 100; // don't support fonts > 100 height for now
					System::Drawing::Graphics ^graphics = pictureBox->CreateGraphics();

					// assume 512 wide texture.  height will be a power of 2 up to 512.  If the font goes farther than that, exception for now (todo: support multiple 512x512 textures if needed)
					int proposedTextureWidth = 512;
					int proposedTextureHeight = GetHeight();

					// note: System::Drawing::StringFormat::GenericTypographic is used to force a well measured string instead of getting padding from rendering a single character
					// however, spaces are still measured normally.

					int currentWidthRemaining = proposedTextureWidth;
					for (int c = 0; c < 256; c++)
					{
						if (CharacterValidToInclude((char)c) == true)
						{
							String ^ch = Convert::ToString(char(c));
							int charWidth = (int)(graphics->MeasureString(ch, windowsFont, System::Drawing::PointF(0, 0), System::Drawing::StringFormat::GenericTypographic).Width);
							// tweak
							if (c == 32)
								charWidth = (int)(graphics->MeasureString(ch, windowsFont).Width);
							if (currentWidthRemaining < charWidth)
							{
								currentWidthRemaining = proposedTextureWidth;
								proposedTextureHeight += GetHeight();
							}
							else
								currentWidthRemaining -= charWidth;
						}
					}

					// make sure texture height is a power of 2
					int originalProposedTextureHeight = proposedTextureHeight;
					int power = 0;
					while (proposedTextureHeight > 1)
					{
						proposedTextureHeight = proposedTextureHeight / 2;
						power++;
					}
					double powerResult = pow(2.0, double(power));
					proposedTextureHeight = int(powerResult + 0.5);
					if (proposedTextureHeight < originalProposedTextureHeight)
						proposedTextureHeight *= 2;

					// create bytes array and collect texture locations for each character
					if (proposedTextureHeight <= 512)
					{
						alphaTextureBytes = new unsigned char[proposedTextureWidth * proposedTextureHeight];
						textureWidth = proposedTextureWidth;
						textureHeight = proposedTextureHeight;

						// collect character data

						// collect data for alpha texture (white = 255, black = 0, etc.)
						System::Drawing::SolidBrush ^brush = gcnew System::Drawing::SolidBrush(System::Drawing::Color(System::Drawing::Color::White));
						//pictureBox->BackColor = System::Drawing::Color::Black;

						int maxCharacterWidth = 100;
						int maxCharacterHeight = 100;
						System::Drawing::Bitmap ^bmp = gcnew System::Drawing::Bitmap(maxCharacterWidth, maxCharacterHeight); // should discard itself assuming .NET does its job
						delete graphics;
						graphics = System::Drawing::Graphics::FromImage(bmp);

						int currentWidthRemaining = textureWidth;
						int currentT = 0;
						int currentS = 0;
						for (int c = 0; c < 256; c++)
						{
							if (CharacterValidToInclude((unsigned char)c) == true)
							{
								char chArray[2];
								chArray[1] = '\0';
								chArray[0] = c;
								String ^ch = gcnew String(chArray);

								int charWidth = (int)(graphics->MeasureString(ch, windowsFont, System::Drawing::PointF(0, 0), System::Drawing::StringFormat::GenericTypographic).Width);
								// tweak
								if (c == 32)
									charWidth = (int)(graphics->MeasureString(ch, windowsFont).Width);
								if (charWidth > maxCharacterWidth)
									throw gcnew Exception("Character width max is 100 - found a character '" + ch + "' with width " + Convert::ToString(charWidth));
								if (currentWidthRemaining < charWidth)
								{
									currentWidthRemaining = textureWidth - charWidth;

									currentS = 0;
									currentT += GetHeight();
								}
								else
								{
									currentWidthRemaining -= charWidth;
								}

								characters[c].valid = true;
								characters[c].textureBeginS = currentS;
								characters[c].textureBeginT = currentT;
								characters[c].textureEndS = currentS + charWidth;
								characters[c].textureEndT = currentT + GetHeight();
								characters[c].width = charWidth;
								characters[c].height = GetHeight();

								// Draw the character at 0,0 in the picture box and collect its data into the alpha texture data
								graphics->Clear(System::Drawing::Color::Black);
								if (c != 32)
									graphics->DrawString(ch, windowsFont, brush, 0, 0, System::Drawing::StringFormat::GenericTypographic);
								else
									graphics->DrawString(ch, windowsFont, brush, 0, 0);

								for (int x = 0; x < charWidth; x++)
								{
									for (unsigned int y = 0; y < GetHeight(); y++)
									{
										System::Drawing::Color color = bmp->GetPixel(x+1, y); // x+1 to get better pixels
										unsigned char value = color.R; // red is fine, can be green or blue element too.  It's all the same since we rendered as white
										alphaTextureBytes[(currentT + y) * textureWidth + currentS + x] = value; 
									}
								}

								currentS += charWidth;
							}
							else
								characters[c].valid = false;
						} // collect character data

						delete graphics;
						delete bmp;
					}
					else
						throw gcnew Exception("Proposed texture height is " + Convert::ToString(proposedTextureHeight) + " - max is 512");

					delete graphics;
					delete pictureBox;
				}
			}

			unsigned int GetHeight()
			{
				if (fontHeight == 0)
				{
					System::Windows::Forms::PictureBox ^pictureBox = gcnew System::Windows::Forms::PictureBox();
					System::Drawing::Graphics ^graphics = pictureBox->CreateGraphics();
					fontHeight = (int)(graphics->MeasureString("W", windowsFont).Height);
					delete graphics;
					delete pictureBox;
				}

				return fontHeight;
			}

			bool CharacterIsValid(unsigned char p_ch)
			{
				return characters[p_ch].valid;
			}

			int GetCharacterWidth(unsigned char p_ch)
			{
				if (CharacterIsValid(p_ch))
					return characters[p_ch].width;
				else
					return 0;
			}

			GameFontCharacter * GetGameFontCharacter(unsigned char p_ch)
			{
				return &(characters[p_ch]);
			}

			int GetTextureWidth()
			{
				return textureWidth;
			}

			int GetTextureHeight()
			{
				return textureHeight;
			}

			// prepare font with API independent resources - alpha bitmap data and character sizes
			void Load()
			{
				// check binary storage.  If not there, generate it and make an id for it and store the id in the resource storage
				if (AlphaTextureStorageIsEmpty())
				{
					// generate binary storage
					GenerateAlphaTextureBytes();
				}
			}

			System::Drawing::Point GetTextBlockSize(String ^p_block)
			{
				array<String^, 1> ^separator = { "\n" };
				array<String ^, 1> ^lines = p_block->Split(separator, StringSplitOptions::None);
				return GetTextBlockSize(lines);
			}

			System::Drawing::Point GetTextBlockSize(array<String ^, 1> ^p_lines)
			{
				Load();

				int longestLength = 0;
				for each (String ^line in p_lines)
				{
					int length = GetTextSize(line).X;
					if (length > longestLength)
						longestLength = length;
				}
				System::Drawing::Point size;
				size.X = longestLength;
				size.Y = GetHeight() * p_lines->Length;

				return size;
			}

			System::Drawing::Point GetTextSize(String ^p_text)
			{
				Load();

				System::Drawing::Point size;
				size.Y = GetHeight();
				size.X = 0;

				for (int i = 0; i < p_text->Length; i++)
				{
					unsigned char ch = (unsigned char)(p_text[i]);
					size.X += GetCharacterWidth(ch);
				}

				return size;
			}

		private:
			bool CharacterValidToInclude(unsigned char p_character)
			{
				// just the usual stuff for now, worry about european characters, tm, etc. later
				if (p_character >= 32 && p_character < 128)
					return true;
				return false;
			}

		};

		// simple structure to hold one block of rich text
		public class GameRichText
		{
		public:
			gcroot<String ^>text;
			gcroot<GameFont ^>fontRef;
			GameColor foreColor;
		};

		public class GameRichTextList : public LinkedList<GameRichText>
		{
		public:
			void AddText(String ^p_text, GameFont ^p_font, GameColor &p_color)
			{
				LinkedListNode<GameRichText> *newNode = GetNewNode();
				newNode->data.text = p_text;
				newNode->data.fontRef = p_font;
				newNode->data.foreColor = p_color;
				AddNode(newNode);
			}
		};

		// a list of GameRichText nodes gets split into a list of these when sent into WrapText
		public class GameLinedRichText
		{
		public:
			int line; // number 0 up
			gcroot<String ^>text;
			gcroot<GameFont ^>fontRef;
			GameColor foreColor;
			System::Drawing::Point textSize;
		};

		public class GameFontHelper
		{
		public:
			// Wrap text lines given a list of rich text nodes, split into a lines rich text list
			static void WrapText(LinkedList<GameRichText> &p_richText, LinkedList<GameLinedRichText> &p_linedRichText, int p_fieldWidth)
			{
				// p_fieldWidth notes the largest width a full line can have before it is split into the next line.
				// p_richText WILL get modified.

				p_linedRichText.Clear();
				LinkedListNode<GameRichText> *node = p_richText.GetFirstNode();
				if (node == nullptr)
					return;

				int currentX = 0;
				int currentLine = 0;
				bool done = false;
				while (done == false)
				{
					int startIndex = 0;
					int separatorIndex = 0;
					String ^line = node->data.text;
					GameFont ^font = node->data.fontRef;
					String ^renderLine = "";
					bool hitASeparator = false;
					while (startIndex < line->Length)
					{
						String ^word = "";
						if (line[separatorIndex] == ' ' || line[separatorIndex] == '.' || line[separatorIndex] == ',' || line[separatorIndex] == '-')
						{
							word = line->Substring(startIndex, separatorIndex - startIndex + 1);
							hitASeparator = true;
						}
						else
						{
							if (separatorIndex == line->Length - 1)
							{
								// we have reached the end of this line
								if (hitASeparator == true) // have to have hit a separator to check the word, otherwise no splitting because the whole line is a word
									word = line->Substring(startIndex, separatorIndex - startIndex + 1);
							}
							else
							{
								separatorIndex++;
								continue;
							}
						}

						// we have a word.  Does it cut the max width?  If so, 0-startIndex is the word we keep.
						int testTextWidth = font->GetTextSize(word->TrimEnd()).X; // don't let spaces cause a line feed, only what comes after them
						int actualTextWidth = font->GetTextSize(word).X; // used to advance currentX
						if (currentX + testTextWidth > p_fieldWidth)
						{
							// it cuts!

							// trim off the existing string's right side, and the remaining string's left side
							renderLine = line->Substring(0, startIndex)->TrimEnd();
							LinkedListNode<GameLinedRichText> *newLinedNode = p_linedRichText.GetNewNode();
							newLinedNode->data.text = renderLine;
							newLinedNode->data.line = currentLine;
							newLinedNode->data.fontRef = node->data.fontRef;
							newLinedNode->data.foreColor = node->data.foreColor;
							newLinedNode->data.textSize = font->GetTextSize(renderLine);
							p_linedRichText.AddNode(newLinedNode);

							currentLine++;

							LinkedListNode<GameRichText> *newNode = p_richText.GetNewNode();
							newNode->data.foreColor = node->data.foreColor;
							newNode->data.fontRef = node->data.fontRef;
							newNode->data.text = line->Substring(startIndex)->TrimStart();
							// insert after node, and start working on that one.  nodes after this with the same line # are considered part of that same line
							p_richText.InsertNode(newNode, node);
							// advance
							node = newNode;
							line = node->data.text;

							startIndex = 0;
							separatorIndex = 0;
							currentX = 0;
						}
						else
						{
							// word didn't cut
							currentX += actualTextWidth;
							separatorIndex++;
							startIndex = separatorIndex;
						}
					}

					// add whats left from node to lined rich text
					if (static_cast<String^>(node->data.text) != "")
					{
						LinkedListNode<GameLinedRichText> *newLinedNode = p_linedRichText.GetNewNode();
						newLinedNode->data.text = node->data.text;
						newLinedNode->data.line = currentLine;
						newLinedNode->data.fontRef = node->data.fontRef;
						newLinedNode->data.foreColor = node->data.foreColor;
						newLinedNode->data.textSize = font->GetTextSize(node->data.text);
						p_linedRichText.AddNode(newLinedNode);
					}

					// continue!

					node = node->next;
					if (node == &(p_richText.footer))
						// all done with the text
						break;
				}

				// todo: if the final line has a lot of spaces at the end, this will betray the width of the visible text (it should be trimmed and the width adjusted)
				// but doing that adjustment here might return the wrong largestTextWidth, because a prior line might have been longer than the new trimmed last line, and that would
				//   need to be the value returned.  For now, in order to avoid this oddity, don't put a bunch of spaces at the end of rich text.

				// cleanup is the case of the rich text ending in many spaces - just safe code here.
				// if last node is nothing but spaces, get rid of it - all of them, actually
				while (p_linedRichText.GetLastNode() != nullptr && p_linedRichText.GetLastNode()->data.text->Trim() == "")
					p_linedRichText.DeleteNode(p_linedRichText.GetLastNode());

				// shave off ending spaces from last node (could be a lot of spaces that cut past the right edge - not detected because there wasn't another word to test against)
				if (p_linedRichText.GetLastNode() != nullptr)
				{
					p_linedRichText.GetLastNode()->data.text = p_linedRichText.GetLastNode()->data.text->TrimEnd();
					p_linedRichText.GetLastNode()->data.textSize = p_linedRichText.GetLastNode()->data.fontRef->GetTextSize(p_linedRichText.GetLastNode()->data.text);
				}
			}
		};

	}
}