#pragma once

#include "Vector.h"

namespace GameEng {
	namespace Graphics {

		using namespace System;
		using namespace GameEng::Math;

		class GameColor
		{
		public:
			// VERY important to keep them in this order so that pointer operations like glColor3ubv and glColor4ubv work properly
			unsigned char red;
			unsigned char green;
			unsigned char blue;
			unsigned char alpha;

			GameColor()
			{
			}

			GameColor(unsigned char p_red, unsigned char p_green, unsigned char p_blue, unsigned char p_alpha)
			{
				red = p_red;
				green = p_green;
				blue = p_blue;
				alpha = p_alpha;
			}

			GameColor(unsigned char p_red, unsigned char p_green, unsigned char p_blue)
			{
				red = p_red;
				green = p_green;
				blue = p_blue;
				alpha = 255;
			}

			GameColor(unsigned int p_color)
			{
				Set(p_color);
			}

			void Set(GameColor &p_color)
			{
				red = p_color.red;
				green = p_color.green;
				blue = p_color.blue;
				alpha = p_color.alpha;
			}

			void Set(unsigned char p_red, unsigned char p_green, unsigned char p_blue, unsigned char p_alpha = 255)
			{
				red = p_red;
				green = p_green;
				blue = p_blue;
				alpha = p_alpha;
			}

			// for simplicity of communication without a GameColor class element (such as in a network packet)
			void Set(unsigned int p_color)
			{
				// int is ARGB

				red = (p_color & 0xff0000) >> 16;
				green = (p_color & 0xff00) >> 8;
				blue = (p_color & 0xff);
				alpha = (p_color & 0xff000000) >> 24;
			}

			unsigned int ToInt()
			{
				// int is ARGB

				return alpha * 65536 * 256 + red * 65536 + green * 256 + blue;
			}

			GameColor Modulate(float p_factor, bool p_modulateAlpha = false)
			{
				if (p_factor < 0.0f)
					throw gcnew Exception("A negative factor is not supported");

				unsigned int newRed = (unsigned int)(((unsigned int )red) * p_factor);
				unsigned int newGreen = (unsigned int)(((unsigned int)green) * p_factor);
				unsigned int newBlue = (unsigned int)(((unsigned int)blue) * p_factor);

				if (newRed > 255)
					newRed = 255;
				if (newGreen > 255)
					newGreen = 255;
				if (newBlue > 255)
					newBlue = 255;
				if (p_modulateAlpha == true)
				{
					unsigned int newAlpha = (unsigned int)(((unsigned int)alpha) * p_factor);
					if (newAlpha > 255)
						newAlpha = 255;
					return GameColor(newRed, newGreen, newBlue, newAlpha);
				}
				else
					return GameColor(newRed, newGreen, newBlue);
			}

			static GameColor Interpolate(GameColor &p_color1, GameColor &p_color2, float p_factor)
			{
				if (p_factor <= 0.0)
					return p_color1;
				if (p_factor >= 1.0)
					return p_color2;
				else
				{
					return GameColor(
						unsigned char (p_color1.red + (p_color2.red - p_color1.red) * p_factor),
						unsigned char(p_color1.green + (p_color2.green - p_color1.green) * p_factor),
						unsigned char(p_color1.blue + (p_color2.blue - p_color1.blue) * p_factor),
						unsigned char(p_color1.alpha + (p_color2.alpha - p_color1.alpha) * p_factor)
						);
				}
			}

			bool CompareWithoutAlpha(System::Drawing::Color &p_color)
			{
				if (red == p_color.R && green == p_color.G && blue == p_color.B)
					return true;
				else
					return false;
			}

			bool Compare(System::Drawing::Color &p_color)
			{
				if (red == p_color.R && green == p_color.G && blue == p_color.B && alpha == p_color.A)
					return true;
				else
					return false;
			}

			bool CompareWithoutAlpha(GameColor &p_color)
			{
				if (red == p_color.red && green == p_color.green && blue == p_color.blue)
					return true;
				else
					return false;
			}

			bool Compare(GameColor &p_color)
			{
				if (red == p_color.red && green == p_color.green && blue == p_color.blue && alpha == p_color.alpha)
					return true;
				else
					return false;
			}

			Vector3d ToVector3d()
			{
				return Vector3d(float(red) / 255.0f, float(green) / 255.0f, float(blue) / 255.0f);
			}

			// opportunity to see if a hex conversion won't cause an exception, when user can determine this string for themselves
			static bool FromHexStringIsValid(String ^p_string)
			{
				String ^clean = p_string->Replace(" ", "");
				int result;
				return Int32::TryParse(clean, System::Globalization::NumberStyles::HexNumber, gcnew System::Globalization::CultureInfo("en-US"), result);
			}

			static GameColor FromHexString(String ^p_string, bool p_alphaOptional = true)
			{
				// expect string is ARGB or RGB
				// sending just "ff" = blue, send "ff0000" for red
				String ^clean = p_string->Replace(" ", "");
				unsigned int number = Convert::ToInt32(clean, 16);
				if (p_string->Length < 7 && p_alphaOptional == true)
					number += 0xff000000; // force alpha to full
				if ((number & 0xf00000000) != 0) // too many hex digits
					number = number & 0x0ffffffff;

				GameColor result;
				result.Set(number);
				return result;
			}

			String^ ToString(bool p_noalpha = true)
			{
				// output is ARGB
				String^ result = ToInt().ToString("X8");
				if (p_noalpha == true)
					return result->Substring(2);
				else
					return result;
			}
		};
	}
}