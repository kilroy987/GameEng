#pragma once

#include "GameFileResource.h"

namespace GameEng {
	namespace Graphics {

		using namespace GameEng::Resource;

		public ref class GameTextureRendererResource
		{
		public:
			void *rendererResource; // instance, not a reference, so this has to be destroyed at the renderer level before the parnet object is destroyed

			GameTextureRendererResource()
			{
				rendererResource = nullptr;
			}

			void SetResource(void *p_resource)
			{
				rendererResource = p_resource;
			}

			void ClearResource()
			{
				// do this after the renderer has destroyed what this is pointing to - the renderer will have to cast its own type to this void pointer
				rendererResource = nullptr;
			}
		};

		enum class GameTextureInternalFormatEnum // 'class' necessary otherwise system complains that Alpha was reused in next enum
		{
			Alpha, // alpha only texture, Byte per texel in memory
			RGB, // color only texture, 8 bits per color, 3 bytes per texel in memory (RGB storage) (appears that GL downconverts to 16 bit for rendering)
			RGBA, // all 4 components are used, 8 bits per color, 4 bytes per texel
			RGBA16, // all 4 packed into 16 bits (4 bits each), 2 bytes per texel (BA/RG stored in reverse)
			RGBA8, // all 4 packed into 8 bits (2 bits each) - 2 bytes per texel in memory (BA/RG stored in reverse), truncated by API on load (appears that GL preserves as 16 bit)
			// currently RGB/A, RGB16 and RGB8 all render at the same quality.
			RGBSigned, // data only, not meant to be decaled
			// generally reserved for rendernig buffers, not loaded textures
			RG16F,	// 2d vector, 16-bit float for each element
			RGB16F, // 3d vector, 16-bit float for each element
			RGB32F  // 3d vector, 32-bit float for each element
		};

		// determines which part of the color in the bitmap is to be used
		enum class GameTextureFileComponentUsageEnum // 'class' necessary otherwise system complains that Alpha was reused from prior enum
		{
			Alpha, // usable for internal format Alpha only
			RGB, // if used for internal ARGB, alpha is set to 255
			ARGB, // if used for internal format RGB, alpha is clipped.   if used for internal format Alpha, RGB is clipped.
			Red, // usable for internal format Alpha only
			Green, // usable for internal format Alpha only
			Blue, // usable for internal format Alpha only
			WhiteColorAlphaRed, // internal RGBA only
			WhiteColorAlphaGreen, // internal RGBA only
			WhiteColorAlphaBlue, // internal RGBA only
			WhiteColorAlphaAlpha, // internal RGBA only
		};

		// holds common data for a texture ready to be loaded as a graphic api resource
		public ref class GameTexture
		{
		private:
			GameTextureRendererResource ^rendererResource;

		public:
			System::String ^name;
			GameTextureInternalFormatEnum internalFormat;
			GameTextureFileComponentUsageEnum fileUsage;
			int width, height;
			GameFileResource ^fileResource;
			GameColor *colorToConvertToAlphaZeroOnLoad;
			bool allowMipMap;
			bool cubeMap;

			unsigned char *graphicData;	// prepped data for loading into API texture storage

			GameTexture(System::String ^p_textureName, GameTextureInternalFormatEnum p_internalFormat, GameTextureFileComponentUsageEnum p_fileUsage, GameFileResource ^p_fileResource)
			{
				name = p_textureName;
				internalFormat = p_internalFormat;
				fileUsage = p_fileUsage;
				fileResource = p_fileResource;
				colorToConvertToAlphaZeroOnLoad = nullptr;

				// validate
				if (fileUsage == GameTextureFileComponentUsageEnum::Alpha || 
					fileUsage == GameTextureFileComponentUsageEnum::Red || 
					fileUsage == GameTextureFileComponentUsageEnum::Green || 
					fileUsage == GameTextureFileComponentUsageEnum::Blue)
				{
					if (internalFormat != GameTextureInternalFormatEnum::Alpha)
					{
						throw gcnew System::Exception("Only Internal format Alpha is allowed for graphic usage '" + ConvertFileComponentUsageEnumToString(fileUsage) + "'");
					}
				}
				if (internalFormat == GameTextureInternalFormatEnum::Alpha && fileUsage == GameTextureFileComponentUsageEnum::RGB)
					throw gcnew System::Exception("Internal format Alpha cannot allow RGB as file usage - specify a file usage with an alpha component (Alpha or ARGB)");
				if (internalFormat == GameTextureInternalFormatEnum::RGBA16 && (fileUsage != GameTextureFileComponentUsageEnum::RGB && fileUsage != GameTextureFileComponentUsageEnum::ARGB))
					throw gcnew System::Exception("Internal format RGBA16 requires component usage RGB or ARGB");
				if (internalFormat == GameTextureInternalFormatEnum::RGBA8 && (fileUsage != GameTextureFileComponentUsageEnum::RGB && fileUsage != GameTextureFileComponentUsageEnum::ARGB))
					throw gcnew System::Exception("Internal format RGBA8 requires component usage RGB or ARGB");
				if (internalFormat == GameTextureInternalFormatEnum::RGBSigned && (fileUsage != GameTextureFileComponentUsageEnum::RGB))
					throw gcnew System::Exception("Internal format RGBSigned requires component usage RGB");
				if (internalFormat == GameTextureInternalFormatEnum::RGBA && 
					(fileUsage != GameTextureFileComponentUsageEnum::RGB 
					&& fileUsage != GameTextureFileComponentUsageEnum::ARGB 
					&& fileUsage != GameTextureFileComponentUsageEnum::WhiteColorAlphaRed 
					&& fileUsage != GameTextureFileComponentUsageEnum::WhiteColorAlphaGreen 
					&& fileUsage != GameTextureFileComponentUsageEnum::WhiteColorAlphaBlue 
					&& fileUsage != GameTextureFileComponentUsageEnum::WhiteColorAlphaAlpha))
					throw gcnew System::Exception("Internal format RGBA requires component usage RGB, RGBA or WhiteColorAlphaxxx");

				rendererResource = gcnew GameTextureRendererResource();

				width = 0;
				height = 0;
				graphicData = nullptr;

				allowMipMap = true;
				cubeMap = false;
			}

			GameTexture(System::String ^p_textureName, GameTextureInternalFormatEnum p_internalFormat, GameTextureFileComponentUsageEnum p_fileUsage, GameFileResource ^p_fileResource, GameColor &p_colortoConvertToAlphaZeroOnLoad) : 
				GameTexture(p_textureName, p_internalFormat, p_fileUsage, p_fileResource)
			{
				colorToConvertToAlphaZeroOnLoad = new GameColor();
				*colorToConvertToAlphaZeroOnLoad = p_colortoConvertToAlphaZeroOnLoad;

				// validate
				if (internalFormat != GameTextureInternalFormatEnum::Alpha && internalFormat != GameTextureInternalFormatEnum::RGBA && internalFormat != GameTextureInternalFormatEnum::RGBA8 && internalFormat != GameTextureInternalFormatEnum::RGBA16)
					throw gcnew System::Exception("Converting color to alpha on load requires internal Alpha format (Alpha, RGBA, RGBA8 or RGBA16)");

				allowMipMap = true;
				cubeMap = false;
			}

			GameTexture(int p_width, int p_height, GameTextureInternalFormatEnum p_internalFormat)
			{
				rendererResource = gcnew GameTextureRendererResource();

				width = 0;
				height = 0;
				graphicData = nullptr;

				colorToConvertToAlphaZeroOnLoad = nullptr;

				CreateGraphicDataBuffer(p_width, p_height, p_internalFormat);

				allowMipMap = true;
				cubeMap = false;
			}

			// only good for render buffers - the graphics API forces size and internal format
			// API has to set the texture ID
			GameTexture(bool p_allowMipMap, bool p_cubeMap, int p_width, int p_height)
			{
				rendererResource = gcnew GameTextureRendererResource();
				allowMipMap = p_allowMipMap;
				cubeMap = p_cubeMap;
				width = p_width;
				height = p_height;
			}

			virtual ~GameTexture()
			{
				ClearGraphicData();

				if (colorToConvertToAlphaZeroOnLoad != nullptr)
				{
					delete colorToConvertToAlphaZeroOnLoad;
					colorToConvertToAlphaZeroOnLoad = nullptr;
				}
			}

			int GetWidth()
			{
				return width;
			}

			int GetHeight()
			{
				return height;
			}

			bool GraphicDataStorageEmpty()
			{
				return (graphicData == nullptr);
			}

			void LoadGraphicData()
			{
				// open file into bitmap
				// get dimensions
				// initialize storage according to internal format (Alpha = *1, RGB = *3, RGBA = *4)
				// parse bitmap pixels, sample data according to graphic usage, store in storage according to internal format
				// optionally, store as a .dat file that can be reloaded more quickly later (for now)

				// note: each line is 4 bytes always since the default alignment of a gpu is 4 bytes. (64-bit might be 8 bytes - be cautioned)
				// so the bytes usage for storage is not always = width*bytes*internalformatbytes

				int internalFormatBytesPerPixel = 0;
				switch (internalFormat)
				{
				case GameTextureInternalFormatEnum::Alpha:
					internalFormatBytesPerPixel = 1;
					break;
				case GameTextureInternalFormatEnum::RGBA8:
					internalFormatBytesPerPixel = 2; // can't support single byte for API load so use 2
					break;
				case GameTextureInternalFormatEnum::RGB:
					internalFormatBytesPerPixel = 3;
					break;
				case GameTextureInternalFormatEnum::RGBSigned:
					internalFormatBytesPerPixel = 3;
					break;
				case GameTextureInternalFormatEnum::RGBA:
					internalFormatBytesPerPixel = 4;
					break;
				case GameTextureInternalFormatEnum::RGBA16:
					internalFormatBytesPerPixel = 2;
					break;
				}

				// this gets the data without locking the file
				System::IO::Stream ^stream = gcnew System::IO::MemoryStream(System::IO::File::ReadAllBytes(fileResource->GetDiskFilePath()));
				System::Drawing::Bitmap ^bitmap = gcnew System::Drawing::Bitmap(System::Drawing::Bitmap::FromStream(stream));
				width = bitmap->Width;
				height = bitmap->Height;
				int bytesPerLine = width * internalFormatBytesPerPixel;
				// align on 4 byte boundary
				if ((bytesPerLine & 3) != 0)
					bytesPerLine = bytesPerLine - (bytesPerLine & 3) + 4;

				graphicData = new unsigned char[bytesPerLine * height];

				// examine the image
				for (int v = 0; v < height; v++)
				{
					unsigned char *currentByte = &(graphicData[v * bytesPerLine]);
					for (int h = 0; h < width; h++)
					{
						System::Drawing::Color color = bitmap->GetPixel(h, v);

						switch (fileUsage)
						{
						case GameTextureFileComponentUsageEnum::Alpha: // internal alpha only
							*currentByte = color.A;
							if (colorToConvertToAlphaZeroOnLoad != nullptr)
							{
								if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
									*currentByte = 0;
							}
							break;
						case GameTextureFileComponentUsageEnum::Red: // internal alpha only
							*currentByte = color.R;
							if (colorToConvertToAlphaZeroOnLoad != nullptr)
							{
								if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
									*currentByte = 0;
							}
							break;
						case GameTextureFileComponentUsageEnum::Green: // internal alpha only
							*currentByte = color.G;
							if (colorToConvertToAlphaZeroOnLoad != nullptr)
							{
								if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
									*currentByte = 0;
							}
							break;
						case GameTextureFileComponentUsageEnum::Blue: // internal alpha only
							*currentByte = color.B;
							if (colorToConvertToAlphaZeroOnLoad != nullptr)
							{
								if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
									*currentByte = 0;
							}
							break;
						case GameTextureFileComponentUsageEnum::WhiteColorAlphaAlpha: // internal rgba only
							{
								*currentByte = 255;
								*(currentByte + 1) = 255;
								*(currentByte + 2)= 255;
								*(currentByte + 3) = color.A;
							}
							break;
						case GameTextureFileComponentUsageEnum::WhiteColorAlphaRed: // internal rgba only
							{
								*currentByte = 255;
								*(currentByte + 1) = 255;
								*(currentByte + 2) = 255;
								*(currentByte + 3) = color.R;
						}
							break;
						case GameTextureFileComponentUsageEnum::WhiteColorAlphaGreen: // internal rgba only
							{
								*currentByte = 255;
								*(currentByte + 1) = 255;
								*(currentByte + 2) = 255;
								*(currentByte + 3) = color.G;
						}
							break;
						case GameTextureFileComponentUsageEnum::WhiteColorAlphaBlue: // internal rgba only
							{
								*currentByte = 255;
								*(currentByte + 1) = 255;
								*(currentByte + 2) = 255;
								*(currentByte + 3) = color.B;
							}
							break;
						case GameTextureFileComponentUsageEnum::RGB: // internal rgb and rgba and rgba16 only for now
						{
							if (internalFormat == GameTextureInternalFormatEnum::RGBA || internalFormat == GameTextureInternalFormatEnum::RGB || internalFormat == GameTextureInternalFormatEnum::RGBSigned)
							{
								*currentByte = color.R;
								*(currentByte + 1) = color.G;
								*(currentByte + 2) = color.B;
								if (internalFormat == GameTextureInternalFormatEnum::RGBA)
									*(currentByte + 3) = 255; // truncated!
								if (internalFormat == GameTextureInternalFormatEnum::RGBA && colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte + 3) = 0;
								}
							}
							else if (internalFormat == GameTextureInternalFormatEnum::RGBA16)
							{
								// integers are stored backwards in memory!!
								*(currentByte + 1) = (color.R >> 4) * 16 + (color.G >> 4);
								*(currentByte) = (color.B >> 4) * 16 + 15;
								if (colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte) = (color.B >> 4) * 16 + 0;
								}
							}
							else if (internalFormat == GameTextureInternalFormatEnum::RGBA8)
							{
								// integers are stored backwards in memory!!
								// unknown if GL implementation will upload this integer source as 16 bit data because it's from an integer source (in short, RGBA8 is ignored and forced to RGBA16)
								*(currentByte + 1) = (color.R >> 4) * 16 + (color.G >> 4);
								*(currentByte) = (color.B >> 4) * 16 + 15;
								// test force 2-bit quality
								//*(currentByte + 1) = (color.R >> 6) * 64 + (color.G >> 6) * 4;
								//*(currentByte) = (color.B >> 6) * 64 + 15;
								if (colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte) = (color.B >> 4) * 16 + 0;
								}
							}
						}
							break;
						case GameTextureFileComponentUsageEnum::ARGB: // internal rgb, rgba and Alpha and rgba16 only for now
						{
							if (internalFormat == GameTextureInternalFormatEnum::RGBA || internalFormat == GameTextureInternalFormatEnum::RGB)
							{
								*currentByte = color.R;
								*(currentByte + 1) = color.G;
								*(currentByte + 2) = color.B;
							}

							if (internalFormat == GameTextureInternalFormatEnum::Alpha)
							{
								*currentByte = color.A;
								if (colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte) = 0;
								}
							}
							else if (internalFormat == GameTextureInternalFormatEnum::RGBA)
							{
								*(currentByte + 3) = color.A;
								if (colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte + 3) = 0;
								}
							}
							else if (internalFormat == GameTextureInternalFormatEnum::RGBA16)
							{
								// integers are stored backwards in memory!!
								*(currentByte + 1) = (color.R >> 4) * 16 + (color.G >> 4);
								*(currentByte) = (color.B >> 4) * 16 + (color.A >> 4);
								// testing, force 2-bit quality
								//*(currentByte + 1) = (color.R >> 6) * 64 + (color.G >> 6) * 4;
								//*(currentByte) = (color.B >> 6) * 64 + (color.A >> 6) * 4;
								if (colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte) = (color.B >> 4) * 16 + 0;
								}
							}
							else if (internalFormat == GameTextureInternalFormatEnum::RGBA8)
							{
								// integers are stored backwards in memory!!
								// unknown if GL implementation will upload this integer source as 16 bit data because it's from an integer source (in short, RGBA8 is ignored and forced to RGBA16)
								*(currentByte + 1) = (color.R >> 4) * 16 + (color.G >> 4);
								*(currentByte) = (color.B >> 4) * 16 + (color.A >> 4);
								// test force 2-bit quality
								//*(currentByte + 1) = (color.R >> 6) * 64 + (color.G >> 6) * 4;
								//*(currentByte) = (color.B >> 6) * 64 + (color.A >> 4);
								if (colorToConvertToAlphaZeroOnLoad != nullptr)
								{
									if (colorToConvertToAlphaZeroOnLoad->CompareWithoutAlpha(color) == true)
										*(currentByte) = (color.B >> 4) * 16 + 0;
								}
							}
						}
							break;
						} // switch

						currentByte += internalFormatBytesPerPixel;
					}
				}

				delete stream;
				delete bitmap;
			}

			unsigned char * CreateGraphicDataBuffer(int p_width, int p_height, GameTextureInternalFormatEnum p_internalFormat)
			{
				if (graphicData != nullptr)
					throw gcnew System::Exception("GraphicData already initialized");

				internalFormat = p_internalFormat;
				width = p_width;
				height = p_height;

				// create buffer
				// align each row to a 4 byte boundary
				// return pointer to array
				int internalFormatBytesPerPixel = 0;
				switch (internalFormat)
				{
				case GameTextureInternalFormatEnum::Alpha:
					internalFormatBytesPerPixel = 1;
					break;
				case GameTextureInternalFormatEnum::RGB:
					internalFormatBytesPerPixel = 3;
					break;
				case GameTextureInternalFormatEnum::RGBSigned:
					internalFormatBytesPerPixel = 3;
					break;
				case GameTextureInternalFormatEnum::RGBA:
					internalFormatBytesPerPixel = 4;
					break;
				case GameTextureInternalFormatEnum::RGBA16:
				case GameTextureInternalFormatEnum::RGBA8:
					internalFormatBytesPerPixel = 2;
					break;
				}
				int bytesPerLine = width * internalFormatBytesPerPixel;
				// align on 4 byte boundary
				if ((bytesPerLine & 3) != 0)
					bytesPerLine = bytesPerLine - (bytesPerLine & 3) + 4;

				graphicData = new unsigned char[bytesPerLine * height];

				return graphicData;
			}

			unsigned char * GetTexelPointer(int p_x, int p_y)
			{
				if (p_x >= width)
					throw gcnew System::Exception(String::Format("x coordinate {0} is out of bounds, storage width is {1}", p_x, width));
				if (p_y >= width)
					throw gcnew System::Exception(String::Format("y coordinate {0} is out of bounds, storage width is {1}", p_y, height));

				int internalFormatBytesPerPixel = 0;
				switch (internalFormat)
				{
				case GameTextureInternalFormatEnum::Alpha:
					internalFormatBytesPerPixel = 1;
					break;
				case GameTextureInternalFormatEnum::RGB:
					internalFormatBytesPerPixel = 3;
					break;
				case GameTextureInternalFormatEnum::RGBSigned:
					internalFormatBytesPerPixel = 3;
					break;
				case GameTextureInternalFormatEnum::RGBA:
					internalFormatBytesPerPixel = 4;
					break;
				case GameTextureInternalFormatEnum::RGBA16:
				case GameTextureInternalFormatEnum::RGBA8:
					internalFormatBytesPerPixel = 2;
					break;
				}
				int bytesPerLine = width * internalFormatBytesPerPixel;
				// align on 4 byte boundary
				if ((bytesPerLine & 3) != 0)
					bytesPerLine = bytesPerLine - (bytesPerLine & 3) + 4;

				return &(graphicData[p_y * bytesPerLine + p_x * internalFormatBytesPerPixel]);
			}

			void * GetGraphicDataStorage()
			{
				return graphicData;
			}

			void ClearGraphicData()
			{
				if (graphicData != nullptr)
				{
					delete[] graphicData;
					graphicData = nullptr;
				}
			}

			GameTextureRendererResource ^GetRendererResource()
			{
				return rendererResource;
			}

			static System::String^ ConvertInternalFormatEnumToString(GameTextureInternalFormatEnum p_enum)
			{
				switch (p_enum)
				{
				case GameTextureInternalFormatEnum::Alpha:
					return "Alpha";
					break;
				case GameTextureInternalFormatEnum::RGBA:
					return "RGBA";
					break;
				case GameTextureInternalFormatEnum::RGB:
					return "RGB";
					break;
				case GameTextureInternalFormatEnum::RGBSigned:
					return "RGBSigned";
					break;
				case GameTextureInternalFormatEnum::RGBA16:
					return "RGBA16";
					break;
				case GameTextureInternalFormatEnum::RGBA8:
					return "RGBA8";
					break;
				default:
					throw gcnew System::Exception("Unknown GameTextureInternalFormatEnum... check ConvertInternalFormatEnumToString() method");
					break;
				}
			}

			static System::String^ ConvertFileComponentUsageEnumToString(GameTextureFileComponentUsageEnum p_enum)
			{
				switch (p_enum)
				{
				case GameTextureFileComponentUsageEnum::Alpha:
					return "Alpha";
					break;
				case GameTextureFileComponentUsageEnum::Red:
					return "Red";
					break;
				case GameTextureFileComponentUsageEnum::Green:
					return "Green";
					break;
				case GameTextureFileComponentUsageEnum::Blue:
					return "Blue";
					break;
				case GameTextureFileComponentUsageEnum::ARGB:
					return "ARGB";
					break;
				case GameTextureFileComponentUsageEnum::RGB:
					return "RGB";
					break;
				case GameTextureFileComponentUsageEnum::WhiteColorAlphaAlpha:
					return "WhiteColorAlphaAlpha";
					break;
				case GameTextureFileComponentUsageEnum::WhiteColorAlphaRed:
					return "WhiteColorAlphaRed";
					break;
				case GameTextureFileComponentUsageEnum::WhiteColorAlphaGreen:
					return "WhiteColorAlphaGreen";
					break;
				case GameTextureFileComponentUsageEnum::WhiteColorAlphaBlue:
					return "WhiteColorAlphaBlue";
					break;
				default:
					throw gcnew System::Exception("Unknown GameTextureFileComponentUsageEnum... check ConvertFileComponentUsageEnumToString() method");
					break;
				}
			}
		};
	}
}