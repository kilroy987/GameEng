#include <tchar.h> // _T macro
#include <Windows.h>
#include <Windowsx.h> // GET_X_LPARAM, GET_Y_LPARAM
#include "..\GameEngDev\TestGame.h"
#include "..\GameEngDev\TestNetwork.h"
#include "..\GameEngDev\JetGameHelper.h"
#include "..\Headers\LinkedListTemplate.h"
#include "..\GameEngDev\TestAsteroids.h"
#include "..\GameEngDev\TestFPS.h"

// for ms sleep accuracy
// can't do this when using clr
//#include <chrono>
//#include <thread>

using namespace GameEng::Storage;
using namespace GameEngDev;

bool activateMessage = false;
bool activated = true;
bool sized = false;

MINMAXINFO FAR *lpMinMaxInfo;
int windowMaxWidth;
int windowMaxHeight;
int proposedScreenWidth;
int proposedScreenHeight;

LRESULT CALLBACK MyWndProcHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_DESTROY)
	{
		PostQuitMessage(0);
	}

	if (uMsg == WM_ACTIVATE)
	{
		// hokey but it works - don't have access to game class here
		if (wParam == WA_ACTIVE || wParam == WA_CLICKACTIVE)
		{
			activateMessage = true;
			activated = true;
		}
		else if (wParam == WA_INACTIVE)
		{
			activateMessage = true;
			activated = false;
		}
	}

	if (uMsg == WM_SIZE)
	{
		RECT rect;
		GetWindowRect(hWnd, &rect);
		int width = LOWORD(lParam);
		int height = HIWORD(lParam);
		// width, height are client area here
		GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetViewportSizeAndScreenLocation(width, height, Point(rect.left, rect.top));
		sized = true;
	}

	if (uMsg == WM_MOVE)
	{
		RECT rect;
		GetWindowRect(hWnd, &rect);
		GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetViewportSizeAndScreenLocation(proposedScreenWidth, proposedScreenHeight, Point(rect.left, rect.top));
		// no need to call resized for this one
	}

	if (uMsg == WM_GETMINMAXINFO)
	{
		lpMinMaxInfo = (MINMAXINFO FAR *) lParam;
		lpMinMaxInfo->ptMinTrackSize.x = windowMaxWidth / 2;
		lpMinMaxInfo->ptMinTrackSize.y = windowMaxHeight / 2;
		lpMinMaxInfo->ptMaxTrackSize.x = windowMaxWidth;
		lpMinMaxInfo->ptMaxTrackSize.y = windowMaxHeight;
	}

	// not handled, let windows handle the message
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

////////////////////////////////////////
// Create fullscreen window
bool CreateFullScreenWindow(char *p_windowName, HWND &p_hWnd, int p_width, int p_height, bool p_changeRes)
{
	windowMaxWidth = p_width;
	windowMaxHeight = p_height;

	// register window
	// set message handler routine
	WNDCLASS wc;
	HINSTANCE hInstance = GetModuleHandle(NULL);
	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc = MyWndProcHandler;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL; 
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T("GameEngDevFullScreenTest");
	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, _T("Failed to Register The Window Class."), _T("ERROR"), MB_OK | MB_ICONEXCLAMATION);
		return false;
	}

	// set screen resolution

	if (p_changeRes == true)
	{
		DEVMODE dmScreenSettings;                   // Device Mode
		memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));       // Makes Sure Memory's Cleared
		dmScreenSettings.dmSize = sizeof(dmScreenSettings);       // Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth = p_width;            // Selected Screen Width
		dmScreenSettings.dmPelsHeight = p_height;           // Selected Screen Height
		dmScreenSettings.dmBitsPerPel = 32;             // Selected Bits Per Pixel
		dmScreenSettings.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		{
			MessageBox(NULL, _T("Unable to set screen res."), _T("ERROR"), MB_OK | MB_ICONEXCLAMATION);
			return false;
		}
	}

	DWORD dwExStyle = WS_EX_APPWINDOW;
	DWORD dwStyle = WS_POPUP;
	RECT WindowRect;
	WindowRect.left = 0;
	WindowRect.top = 0;
	WindowRect.right = p_width;
	WindowRect.bottom = p_height;

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle); // necessary for OpenGL to get DC

	if (!(p_hWnd = CreateWindowEx(dwExStyle, _T("GameEngDevFullScreenTest"), _T("GameEngDevFullScreen"), WS_CLIPSIBLINGS | WS_CLIPCHILDREN | dwStyle, 0, 0, p_width, p_height, NULL, NULL, hInstance, NULL)))
	{
		MessageBox(NULL, _T("Window Creation Error."), _T("ERROR"), MB_OK | MB_ICONEXCLAMATION);
	}

	GameApplicationContext::Instance->ViewportRegistry.RegisterViewport("Main", p_hWnd, p_width, p_height);
	//GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetViewportSizeAndScreenLocation(p_width, p_height, Point(0, 0));

	ShowWindow(p_hWnd, SW_SHOW);
	SetForegroundWindow(p_hWnd);
	SetFocus(p_hWnd);

	return true;
}

////////////////////////////////////////
// Create window
bool CreateWindowedScreenWindow(char *p_windowName, HWND &p_hWnd, int p_width, int p_height)
{
	// register window
	// set message handler routine
	WNDCLASS wc;
	HINSTANCE hInstance = GetModuleHandle(NULL);
	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc = MyWndProcHandler;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T("GameEngDevWindowedScreenTest");
	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, _T("Failed to Register The Window Class."), _T("ERROR"), MB_OK | MB_ICONEXCLAMATION);
		return false;
	}

	DWORD dwExStyle = WS_EX_APPWINDOW;
	//DWORD dwStyle = WS_SYSMENU | WS_CAPTION;
	DWORD dwStyle = WS_OVERLAPPEDWINDOW;
	RECT WindowRect;
	windowMaxWidth = p_width + GetSystemMetrics(SM_CXFRAME) + GetSystemMetrics(SM_CXFRAME) + GetSystemMetrics(SM_CXPADDEDBORDER) + GetSystemMetrics(SM_CXPADDEDBORDER);
	windowMaxHeight = p_height + GetSystemMetrics(SM_CYFRAME) + GetSystemMetrics(SM_CYFRAME) + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CXPADDEDBORDER) + GetSystemMetrics(SM_CXPADDEDBORDER);
	WindowRect.left = (GetSystemMetrics(SM_CXSCREEN) / 2) - (windowMaxWidth / 2);
	WindowRect.top = (GetSystemMetrics(SM_CYSCREEN) / 2) - (windowMaxHeight / 2);
	WindowRect.right = WindowRect.left + windowMaxWidth;
	WindowRect.bottom = WindowRect.top + windowMaxHeight;

	//AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle); // necessary for OpenGL to get DC

	if (!(p_hWnd = CreateWindowEx(dwExStyle, _T("GameEngDevWindowedScreenTest"), _T("GameEngDevWindowed"), WS_CLIPSIBLINGS | WS_CLIPCHILDREN | dwStyle, WindowRect.left, WindowRect.top, WindowRect.right - WindowRect.left, WindowRect.bottom - WindowRect.top, NULL, NULL, hInstance, NULL)))
	{
		MessageBox(NULL, _T("Window Creation Error."), _T("ERROR"), MB_OK | MB_ICONEXCLAMATION);
	}

	GameApplicationContext::Instance->ViewportRegistry.RegisterViewport("Main", p_hWnd, p_width, p_height);
	//GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetViewportSizeAndScreenLocation(p_width, p_height, Point(WindowRect.left, WindowRect.top));

	ShowWindow(p_hWnd, SW_SHOW);
	SetForegroundWindow(p_hWnd);
	SetFocus(p_hWnd);

	return true;
}

////////////////////////////////////////
// pipe mouse and keyboard into game
void KeyDown(GameEng::Game::GameBase ^p_game)
{

}

void KeyUp(GameEng::Game::GameBase ^p_game)
{

}

void MouseMove(GameEng::Game::GameBase ^p_game)
{

}

void MouseButton(GameEng::Game::GameBase ^p_game)
{

}

////////////////////////////////////////
// Main
[STAThread] // allows calls to Clipboard (OLE calls)
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevIsntance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	BOOL done = FALSE;

	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	bool changeRes = false;

	HWND hWnd;
	proposedScreenWidth = screenWidth;
	proposedScreenHeight = screenHeight;

	bool createFullScreen = true;

	int response = MessageBox(NULL, _T("Run windowed?"), _T("Window Mode Check"), MB_YESNOCANCEL);
	if (response == IDCANCEL)
	{
		return 0;
	}
	else if (response == IDYES)
	{
		createFullScreen = false;
	}
	else
	{
		response = MessageBox(NULL, _T("Run in 720p for Fraps?"), _T("Resolution Check"), MB_YESNOCANCEL);
		if (response == IDCANCEL)
		{
			return 0;
		}
		else if (response == IDYES)
		{
			proposedScreenWidth = 1280;
			proposedScreenHeight = 720;
			changeRes = true;
		}
	}

	if (createFullScreen == true)
	{
		if (CreateFullScreenWindow("GameEng Fullscreen Test", hWnd, proposedScreenWidth, proposedScreenHeight, changeRes) == false)
		{
			return 0; // fail if didn't create
		}
	}
	else
	{
		proposedScreenWidth = 1280;
		proposedScreenHeight = 720;

		if (CreateWindowedScreenWindow("GameEng Windowed Test", hWnd, proposedScreenWidth, proposedScreenHeight) == false)
		{
			return 0; // fail if didn't create
		}
	}

	GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::AsteroidsGame(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestFPSGame(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestNetwork(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestUI(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestRandomDungeon(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestGoogleCardboardStub(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestGoogleCardboardSceneStub(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::JetGameHelper::JetGame1(hWnd);

	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestMotionBlur(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::PostProcessShaderTest(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::DungeonHallTest(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::AsteroidsGame(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestGame(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::BitonicSortTest(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestParticles(hWnd);
	//GameEng::Game::GameBase ^currentGame = gcnew GameEngDev::TestMirror(hWnd);

	currentGame->Initialize();

	if (currentGame->ApplicationName() != "")
	{
		wchar_t windowName[256];
		GameNetworkPacketHelper::CopyStringToCharArray(windowName, 256, currentGame->ApplicationName());
		SetWindowText(hWnd, windowName);
	}
	else
		SetWindowText(hWnd, _T("GameEng Fullscreen Test"));

	// while(GetMessage(&Msg, NULL, 0, 0) > 0) does not work here because the window pauses when nothing is happening and the mouse is visible.  When mouse is invisible, window continued to
	//   run because gameloop is repeatedly repositioning the mouse (I believe) and still takes 35% CPU usage.  With a hard spin (while done == false), it takes 45% CPU usage.
	bool quitting = false;
	//while (GetMessage(&msg, NULL, 0, 0) > 0)
	while (done == false)
	{
		// process all messages before running a game loop, just like the WinForms app does via firing its timer tick
		while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE) != 0)  // message found when != 0 - IMPORTANT: If you put hWnd in here, program doesn't end!
		{
			if (msg.message == WM_QUIT) // comes after close via destroyWindow
			{
				done = true;
			}
			else if (msg.message == WM_CLOSE) // alt F4 or end process
			{
				quitting = true;
				DestroyWindow(hWnd);
			}
			else if (msg.message == WM_DESTROY)
			{
				PostQuitMessage(0);
			}
			else if (msg.message == WM_KEYDOWN)
			{
				// handle keys - done here because we have access to game here
				bool shift = GetKeyState(VK_SHIFT) < 0;
				bool alt = GetKeyState(VK_MENU) < 0;
				bool ctrl = GetKeyState(VK_CONTROL) < 0;
				// also preps a KeyPress for text controls
				currentGame->KeyDown(msg.wParam, shift, alt, ctrl);
			}
			else if (msg.message == WM_KEYUP)
			{
				// handle keys - done here because we have access to game here
				bool shift = GetKeyState(VK_SHIFT) < 0;
				bool alt = GetKeyState(VK_MENU) < 0;
				bool ctrl = GetKeyState(VK_CONTROL) < 0;
				currentGame->KeyUp(msg.wParam, shift, alt, ctrl);
			}
			else if (msg.message == WM_LBUTTONDOWN)
			{
				// handle mouse buttons - done here because we have access to game here
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Left, true);
			}
			else if (msg.message == WM_LBUTTONUP)
			{
				// handle mouse buttons - done here because we have access to game here
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Left, false);
			}
			else if (msg.message == WM_RBUTTONDOWN)
			{
				// handle mouse buttons - done here because we have access to game here
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Right, true);
			}
			else if (msg.message == WM_RBUTTONUP)
			{
				// handle mouse buttons - done here because we have access to game here
				currentGame->MouseButtonEvent(GameEng::Input::MouseButton::Right, false);
			}
			else if (msg.message == WM_MOUSEMOVE)
			{
				// handle mouse buttons - done here because we have access to game here
				currentGame->MouseMove(GET_X_LPARAM(msg.lParam), GET_Y_LPARAM(msg.lParam));
			}
			else if (msg.message == WM_ACTIVATE)
			{
				// not detected here, for whatever reason MyWndProcHandler catches it instead
				if (msg.wParam == WA_ACTIVE || msg.wParam == WA_CLICKACTIVE)
				{
					currentGame->appActivated = true;
					currentGame->ApplicationActivated();
				}
				else if (msg.wParam == WA_INACTIVE)
				{
					currentGame->appActivated = false;
					currentGame->ApplicationDeactivated();
				}
			}
			else if (msg.message == WM_SIZE)
			{
				// not captured here
				//GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main")->SetViewportSizeAndScreenLocation(LOWORD(msg.lParam), HIWORD(msg.lParam), Point(0, 0));
				//currentGame->ViewportSizeChanged(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"));
			}
			else if (msg.message == WM_KILLFOCUS)
			{
				// not detected here
				currentGame->appActivated = false;
				currentGame->ApplicationDeactivated();
			}
			else if (msg.message == WM_SETFOCUS)
			{
				// not detected here
				currentGame->appActivated = true;
				currentGame->ApplicationActivated();
			}
			else if (msg.message == WM_GETMINMAXINFO)
			{
				// not captured here

				// set the MINMAXINFO structure pointer 
				//lpMinMaxInfo = (MINMAXINFO FAR *) msg.lParam;
				//lpMinMaxInfo->ptMinTrackSize.x = proposedScreenWidth / 2;
				//lpMinMaxInfo->ptMinTrackSize.y = proposedScreenHeight / 2;
				//lpMinMaxInfo->ptMaxTrackSize.x = proposedScreenWidth;
				//lpMinMaxInfo->ptMaxTrackSize.y = proposedScreenHeight;
			}
			else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}

		if (quitting == false)
		{
			if (activateMessage == true)
			{
				if (activated == true)
				{
					currentGame->appActivated = true;
					currentGame->ApplicationActivated();
				}
				else
				{
					currentGame->appActivated = false;
					currentGame->ApplicationDeactivated();
				}
				activateMessage = false;
			}

			if (sized == true)
			{
				sized = false;
				currentGame->ViewportSizeChanged(GameApplicationContext::Instance->ViewportRegistry.GetViewport("Main"));
			}

			// don't handle any more game based messages if window is being destroyed
			if (currentGame->BaseGameLoop() == false) // hit esc to return false
			{
				// post quit message
				quitting = true;
				DestroyWindow(hWnd);
			}
			else
			{
				currentGame->PerformRender();
				// Keep PeekMessage going
				// nope, doesn't work
				//PostMessage(hWnd, WM_NULL, 0, 0);
			}

			// just give the app a chance to process anything else
			// multi-core box, not necessary to be concerned, keep the frame rate up!  Sleep(1) causes frame rate to sometimes be 64fps, sometimes 200fps, since there is no guarantee how long it sleeps
			// note: Sleep(1) sleeps for 10ms, and Sleep(0) has NO effect - same CPU usage.  But Sleep(1) significantly cuts down on CPU usage
			// update: even with Sleep(1) going, Asteroids in windowed mode with VSync on takes 45% cpu, but with VSync off gets 450fps and uses 13%.  So the CPU savings I guess depends on
			//   how much time is wasted with the process just waiting to vsync.
			Sleep(1);

			// this could work, but it denies the use of clr which prevents a lot of GameEng components
			//std::this_thread::sleep_for(std::chrono::millseconds(5));
		}
	}

	if (currentGame != nullptr)
	{
		currentGame->Destroy(); // get rid of game data and context data that isn't app level like viewports
		GameApplicationContext::Instance->DestroyApp(); // get rid of app level data like viewports
		GameContext::Instance->DestroyApp(); // get rid of app level data
		delete currentGame;
	}

	return (msg.wParam);
}

