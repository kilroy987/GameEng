Create as Empty CLR project
Make sure d:\SDK is in VC++ Include Directories (wherever the GL folder is for the OpenGL header)
Project options Linker/Subsystem, set to Windows
Add References under Assemblies/Framework:
- System
- System::Drawing
- System::Windows
- System::Windows::Forms

